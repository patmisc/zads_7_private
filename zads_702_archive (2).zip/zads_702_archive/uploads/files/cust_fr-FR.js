// JavaScript Document

// selection de plan

my_dictionary['fr_FR']["plan selection header title"] = "Le titre de la page atoutcoin"; 
my_dictionary['fr_FR']["plan selection header line1"] = "Le paragraphe d'introduction de la page de selection des plans atoutcoin"; 
my_dictionary['fr_FR']["plan selection footer line1"] = "Le bas de page de la page de selection des plans atoutcoin"; 



// navigation principale
// my_dictionary['fr_FR']["Main cat sell"] = "Autre nom pour offre";
// my_dictionary['fr_FR']["Main cat buy"] = "Autre nom pour cherche"; 
// my_dictionary['fr_FR']["Main cat user"] = "autre nom pour usagers"; 

// catégories :
// my_dictionary['fr_FR']["sell"] = "vend";
// my_dictionary['fr_FR']["buy"] = "cherche";


my_dictionary['fr_FR']["Main cat adtype3"] = "Echanges"; 
my_dictionary['fr_FR']["adtype3"] = "echange";
my_dictionary['fr_FR']["add a adtype3"] = "Créez votre annonce";

my_dictionary['fr_FR']["Main cat adtype4"] = "Dons"; 
my_dictionary['fr_FR']["adtype4"] = "don";
my_dictionary['fr_FR']["add a adtype4"] = "Créez votre annonce";



// // boutons de creation 
// my_dictionary['fr_FR']["add a sell"]  = "Ajouter une entr?e bottin";
// // my_dictionary['fr_FR']["add a buy"]  = "Cr?ez votre annonce";
// my_dictionary['fr_FR']["add a user"]  = "Cr?ez un Ariste";

// my_dictionary['fr_FR']["%s ads"] = "%s actualit?s" ;
// my_dictionary['fr_FR']["%s ad"] = "%s actualit?" ;
// my_dictionary['fr_FR']["no ad"] = "aucune actualit?";

// my_dictionary['fr_FR']["%s users"] = "%s artistes" ;
// my_dictionary['fr_FR']["%s user"] = "%s artiste" ;

// my_dictionary['fr_FR'][ "no user"] = "aucun artiste";


// my_dictionary['fr_FR'][ "par"] = "Membre";
// my_dictionary['fr_FR'][ "pro"] = "Membre Pro."; 
// my_dictionary['fr_FR']["user upload avatar"] = "Image";
// my_dictionary['fr_FR']["Send a messge to the seller"] = "Envoyez un message au destinataire";

// // footer
my_dictionary['fr_FR'][ "COPYRIGHT"] = "gruyereland.com 2015";
// my_dictionary['fr_FR'][ "title audiourl"] = "Ecouter";
// my_dictionary['fr_FR'][ "title audiourl user"] = "Ecouter";


// my_dictionary['fr_FR']["upload avatarimg"] = "ajouter une photo";
// my_dictionary['fr_FR']["user upload avatar help %s"] = "Charger une photo qui represente votre Logo (format : carte d'identit? 207 x 266) pour votre mini-fiche";
// my_dictionary['fr_FR']["user bio"] = "Votre Activit?";
// my_dictionary['fr_FR']["protype_pri"] = "Particulier";
// my_dictionary['fr_FR']["private"] = "Particulier";

