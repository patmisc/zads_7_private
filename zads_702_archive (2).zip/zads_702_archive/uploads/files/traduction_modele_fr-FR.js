// =========== EXEMPLE FICHIER DELTA DE TRADUCTIOn  ======================================================
// Ce document est un modéle qui permet de modifier les traductions de ZADS en FR à votre propre gout.
// Les elements indiqués ici écraserons selectivement la traduction prcincipale pour les mots clefs indiqués  
// uniquement les MOT CLEF DU SITE usuels sont indiqués ici mais vous pouvez en ajouterà volonté 
// Respectez le format my_dictionary['fr_FR']["MOT CLEF DU SITE"] = "MA NOUVELLE TRADUCTION";
// Pour trouver le MOT CLEF DU SITE, on peut dans l'administration descativer les traductions et le mot est alors celui indiqué sur le site
// Suppimer les "//" pour enlever les commentaires sur chaque ligne et ainsi le rendre actif 
// Vous pouvez éditer ce fichier directement avec un éditeur de texte (UTF-8 !) ou via la WEBADMIN > GESTION FICHIERS > EDITER 
//=======================================================================================================

//-- Bas de page 
// my_dictionary['fr_FR'][ "COPYRIGHT"] = "VOTRE SITE 2015";

//-- Navigation principale du site 
// my_dictionary['fr_FR']["Main cat sell"] = "Offre";
// my_dictionary['fr_FR']["Main cat buy"] = "Demandes"; 
// my_dictionary['fr_FR']["Main cat user"] = "Annonceurs"; 
// my_dictionary['fr_FR']["nav_zetvu_as_news"] = "News"; 


//-- Catégories d'annonces
// my_dictionary['fr_FR']["sell"] = "Offre";
// my_dictionary['fr_FR']["buy"] = "Demande";

// -- Boutons en haut de page
// my_dictionary['fr_FR']["create ad"] = "Ajouter une actualité";
// my_dictionary['fr_FR']["top register user"] = "S'inscrire";
// my_dictionary['fr_FR']["login"] = "Se connecter";

// -- Boutons divers
// my_dictionary['fr_FR']["add a sell"]  = "Ajouter une entrée";
// my_dictionary['fr_FR']["add a buy"]  = "Créez votre annonce";
// my_dictionary['fr_FR']["add a user"]  = "Créez un Usager";

// -- Autres textes
// my_dictionary['fr_FR']["%s ads"] = "%s actualités" ;
// my_dictionary['fr_FR']["%s ad"] = "%s actualité" ;
// my_dictionary['fr_FR']["no ad"] = "aucune actualité";
// my_dictionary['fr_FR']["%s users"] = "%s artistes" ;
// my_dictionary['fr_FR']["%s user"] = "%s artiste" ;
// my_dictionary['fr_FR'][ "no user"] = "aucun artiste";
// my_dictionary['fr_FR']["help_ad_type"] = "Petites annonces = Vendre, échanger ou donner ....";

// entête du formulaire d'usagers 
// my_dictionary['fr_FR'][" user form header title"] = "Enregistrement : " ;
// my_dictionary['fr_FR'][" user form header introduction"] = "A travers ce formulaire, enregistrez vous immédiatement.<br> Merci de pendre en compte les champs obligatoires marqués d'une étoile. " ;

// entête du formulaire d'annonces 
// my_dictionary['fr_FR'][" ad form header title"] = "Mon annonce: " ;
// my_dictionary['fr_FR'][" ad form header introduction"] = "A travers ce formulaire, déposez votre annonce. <br>Elle est GRATUITE et sera disponible après validation par le comité éditorial. Elle restera visible 60 jours. <br> Merci de pendre en compte les champs obligatoires marqués d'une étoile. " ;

// entête choix de l'abonnements 
// my_dictionary['fr_FR']["plan selection header title"] = "plan selection header title" ;
// my_dictionary['fr_FR']["plan selection header line1"] = "plan selection header line1" ;
// my_dictionary['fr_FR']["plan selection footer line1"] = "plan selection footer line1" ;

//-- Catégories d'usagers
// my_dictionary['fr_FR'][ "par"] = "Membre";
// my_dictionary['fr_FR'][ "pro"] = "Membre Pro."; 
// my_dictionary['fr_FR']["user upload avatar"] = "Image";
// my_dictionary['fr_FR']["Send a messge to the seller"] = "Envoyez un message au destinataire";
// my_dictionary['fr_FR']["protype_pri"] = "Particulier";
// my_dictionary['fr_FR']["private"] = "Particulier";

// my_dictionary['fr_FR']["upload avatarimg"] = "ajouter une photo";
// my_dictionary['fr_FR']["user upload avatar help %s"] = "Charger une photo qui represente voe";
// my_dictionary['fr_FR']["user bio"] = "Votre Activité";


// my_dictionary['fr_FR']["email contact form title"] = "Contacter le destinataire";
// my_dictionary['fr_FR']["email contact form introduction"] = "Utiliser ce formulaire pour contacter un destinataire ou répondre à une annonce.";

