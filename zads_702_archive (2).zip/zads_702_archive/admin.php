
<?php 

  // ----- SET Tag for Admin pages   ----// 
  $isPageAdmin = true; $preload_facebook_js=false; 
  if ($isPageAdmin) $bodyextraclass = "admin-page"; else $bodyextraclass="main-site-page";

  // ----- INIT ESSENTIAL SETTINGS =  LANGUAGE  ----// 
  include_once "./phpsvr/init_settings.php";

  // ----- BANNERS ----// 
  include_once "./phpsvr/banners.php"; 

  // ----- HTML SNAPSHOT FOR SEO   ----// 
  include_once "./phpsvr/html_snapshot_lib.php"; 
  $r= detect_escaped_fragment();

  //

?> 
 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" dir="<?php echo $cust_dir;?>">
<head>

  <!-- <base href="<?php echo $DOMAIN_FQDN;?>" />
-->

  <!-- CHARSET definition  -->
  <?php if ($cust_lang_short=="ar") { ?>
    <meta http-equiv="content-type" content="text/html; charset=windows-1256"/> 
  <?php } else { ?>
    <!-- <meta http-equiv="content-type" content="text/html; charset=iso-8859-15"/>   -->
    <!-- <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />     -->
  <?php } ?>



  <!-- SEO optimization = TITLE, DESC and META dynamically displayed -->
  <?php 

    if ( ($r==false) && !(isset($_GET['gplus'])) ) { 
       // DEFAULT HOME 
       $metasAr = Array('title'=> $cust_title, 'desc'=>$cust_description, 'image'=>$cust_logo_fb_uri, 'url'=>$DOMAIN_FQDN, 'gplus'=>$cust_gplus_url); 
    } else { 
      if (isset($_GET['gplus'])){
        // generate dynamically title & description depending on nav // 
        $metasAr = Array('title'=> trim($_GET['title']), 'desc'=>trim($_GET['desc']), 'image'=>trim($_GET['image']), 'url'=>trim($_GET['realurl'])); 
      } else {
        // HTML snapshop
        $metasAr = get_metas($r);


      }
    }

    // display METAS in all cases 
    echo display_metas($metasAr);  
   ?>


  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 

  <!-- not really used by SEO -->
	<meta name="keywords" lang="<?php echo $cust_lang;?>" content="<?php echo $cust_keywords;?>" />	
 

  <link rel="shortcut icon" type="image/x-icon" href="<?php echo $cust_favicon_uri;?>"> 
  <link rel="icon" type="image/x-icon" href="<?php echo $cust_favicon_uri;?>">
  <!-- <link rel="shortcut icon" href="favicon.ico" /> -->

  <!-- SRC image for FACEBOOK sharing  -->
  <link rel="image_src" href="<?php echo $cust_favicon_uri;?>" / >
	
	<!-- LIB stylesheets -->
   
 <!--  <link rel="stylesheet" media="all" type="text/css" href="css/skeleton.css"  />
  <link rel="stylesheet" media="all" type="text/css" href="css/chosen.css"  />
 -->

  <link rel="stylesheet" media="all" type="text/css" href="css/patmisc.lib.min.css"  />

   <!-- awesome font  -->
  <!-- <link rel="stylesheet" media="all" type="text/css" href="css/font-awesome.min.css"> -->
  <link rel="stylesheet" media="all" type="text/css" href="css/font-awesome.css">
  <!--[if IE 7]>
  <link rel="stylesheet" href="/css/font-awesome-ie7.css">
  <![endif]-->


  <!-- THEME and CUSTOM  stylesheets -->
  <?php if (isset($THEME_MASTER_CSS_URL) && $THEME_MASTER_CSS_URL!="") { ?> 
  <link rel="stylesheet" media="all" type="text/css" href="<?php echo $THEME_MASTER_CSS_URL;?> "  />
  <?php } else { ?>
    <link rel="stylesheet" media="all" type="text/css" href="css/theme_style.css"  />
  <?php } ?> 
  
  <?php if (isset($THEME_CSS_URL) && $THEME_CSS_URL!="") { ?> 
    <link rel="stylesheet" media="all" type="text/css" href="<?php echo $THEME_CSS_URL;?> "  />
  <?php } else { ?>
    <link rel="stylesheet" media="all" type="text/css" href="css/custom_style.css"  />
  <?php } ?> 


     <link rel="stylesheet" media="all" type="text/css" href="css/admin_style.css" />
  
    
  <!--[if IE 6]> 
  <link rel="stylesheet" href="theme_style_IE6.css" type="text/css" media="screen" /> 
  <![endif]-->
  
  <link rel="stylesheet" media="screen and (min-device-width: 320px) and (max-width:480px)" href="css/mobile.css" type="css/text/css" />
  <link rel="stylesheet" media="screen and (min-device-width: 481px) and (max-device-width: 799px)" type="text/css" href="css/tablet.css"/>
  <link rel="stylesheet" media="screen and (min-width: 481px) and (max-width: 799px)" type="text/css" href="css/tablet.css"/>
  
  
  <!--  special meta for tablets and smartphones -->
  <meta name="viewport" content="width=device-width" /> 
  <link rel="apple-touch-icon" href="zadsmobicon.png" /> 
  <meta name="apple-mobile-web-app-capable" content="yes" />
  <meta name="apple-mobile-web-app-status-bar-style" content="black" />
  <link rel="apple-touch-startup-image" href="bg/iphonestartup2.png"/>
  <!-- <link rel="apple-touch-icon-precomposed" href="/images/icon.png"/> -->
	
  <!-- RSS feeds --> 
	<link rel="alternate" type="application/rss+xml" href="phpsvr/tmp1.php?rss=sell"  title="<?php echo $cust_motto;?> 10 dernieres offres et demandes" />
  <?php if ($ZETVU_AS_NEWS) { ?> 
  <link rel="alternate" type="application/rss+xml" href="phpsvr/tmp1.php?rss=zetvu"  title="<?php echo $cust_motto;?> 10 derniers ZeTvu" />
  <?php } ?> 

  <!-- meta for crawling AJAX elements -->
  <meta name="fragment" content="!">

	
	<!-- native javascript functions (no jquery) to make some tests before starting HTML -->
  <script type="text/javascript" src="lib/patmisc.preload.toolkit.min.js"></script>

  <!-- adblocker detection  -->
  <script type="text/javascript" src="lib/ads.js"></script>
  

  <!-- google site verification --> 
  <?php if ($GOOGLE_SITE_VERIFICATION){?>
  <meta name="google-site-verification" content="<?php echo $GOOGLE_SITE_VERIFICATION;?>" />
  <?php } ?>


  <!-- set variable for admin  --> 
  
    <script type="text/javascript">
      var preload_facebook_js=false;  // default value
      <?php if ($isPageAdmin){?>
        var isPageAdmin=true; 
        
      <?php } else { ?>
        var isPageAdmin=false; 
    <?php } ?>
    </script>
  

</head>
    
<!-- Calculate the body style -->
  <?php
  if ($r==false){ 
    if ($thebanners['background_all']){
      $bodyextraclass .= " hasbanner"; 
    }
  }
  ?>


<body id="top" style="" class=" <?php echo $bodyextraclass ?> " lang="<?php echo $cust_lang; ?>" xzads-lang="<?php echo $cust_lang_long; ?>" xzads-lang-support="<?php echo $cust_lang_support; ?>">

  <!-- placeholder for Facebook javascript-->
  <div id="fb-root"></div>
 
    <!-- MODL BOX !!!! BUT BE PUT FIRST  after the body ********* --> 
      <div id="boxes" class="toplayer">
        <div id="dialog" class="mbox-window">
          <div id="mbox-close"> <a href="#" id="close" class="close"></a></div>
          <!-- empty space for mbox-header-->
          <div class="clearer">&nbsp;</div>
          <div id="mbox-body">
          </div>      
          <div id="mbox-footer"> <a href="#" class="close"></a></div>
        </div>
        <div id="mask" class="mask toplayer"></div>
        <div id="mask2" class="mask toplayer"></div><!-- mask for displaying "loading... banner-->
      </div>


      <div class="box midlayer">
        <div id="modal_form" class="modal_box mbox-window">
          <div class="mbox-close"> <a href="#" id="close" class="close"></a></div>
          <!-- empty space for mbox-header-->
          <div class="clearer">&nbsp;</div>
          <div id="mbox-body" class="mbox-body"></div>      
          <div id="mbox-footer" class="mbox-footer"> <a href="#" class="close"></a></div>
        </div>
            <div id="mask3" class="mask midlayer"></div>
      </div>

      <div class="box lowlayer">
        <div id="modal_display" class=" modal_box mbox-window">
          <div class="mbox-close"> <a href="#" id="close" class="close"></a></div>
          <div class="clearer">&nbsp;</div>
          <div id="mbox-body" class="mbox-body"></div>      
          <div id="mbox-footer" class="mbox-footer"> <a href="#" class="close"></a></div>
        </div>
            <div id="mask4" class="mask lowlayer"></div>
      </div>

      
      <!-- second box to go against IE ubg -->
      <div id="box2">
        <div id="mask3" class="mask"></div>

      </div>
      
      
<div id="network">
  <div id="network-wrapper" class="center-wrapper">
  
    <div id="network-wrapper-left"  class="left">
    <?php if (($cust_logo_uri!="") && !$LAYOUT_HEADER_WIDGETS_EN) { ?>
        <a href="" id="logo" class="left"><img  alt="<?php echo   (stripslashes($cust_site_name)); ?>"  src="<?php echo $cust_logo_uri; ?>" height="40" /></a>
    <?php } ?>
        <div id="info">
         
          <ul id="info-ul">
             <a href="./"><li id="site-name" class="quiet"><?php if ($r==false) echo   (stripslashes($cust_site_name)); ?></li></a>
            <li id="network-wrapper-ads" class="quiet"></li>
            <li class="text-separator">&nbsp;</li>
            <li id="cnx-label" class="allwhitespan inline"></li>
          </ul>
          <div class="clear"></div>
          <!-- motto -->
          <div id="site-motto" class=""><?php if ($r==false) echo   (stripslashes($cust_site_motto)); ?></div>
        </div>     
    </div> 
    
<!--     
    <div id="network-wrapper-help" class="right">
      <a href="http://www.zads.fr" class="allwhite" id="topbarhelp">aide</a>
   </div> -->
   
    
  <div id="network-wrapper-flags" class="right">
  	<a href="#" class="lang-menu-link">
      <span class="flags fr"></span>
      <span class="down-arrow" style="display:none"></span>
    </a>
    <div id="lang-drop_container" class="lang-menu"></div>
  </div>
  
  
   <div id="network-wrapper-right" class="right">
        <!-- placeholder for buttons and other links -->
   </div>

  </div>
  <div class="clearer">&nbsp;</div>
</div>



      
  <div id="site">
	<div class="center-wrapper">

    <!-- HEADER WIDGETS  section  -->
    <?php
    if ($LAYOUT_HEADER_WIDGETS_EN){ ?>
     <div id="header-widgets-section" class="">
      <div class="logo">
            <h1> <a href="">
                <img src="<?php echo $cust_logo_uri; ?>" alt="<?php echo   (stripslashes($cust_site_name)); ?>" style="opacity: 1;">
                </a> 
            </h1>
      </div>

      <div class="headerwidget">
        <div class="logowidget">
          <?php 
          if ($r==false){ 

            //if (has_banner($thebanners['headerwidget_right_top'])){ 
              if (1==1){
            ?>
            
            <div id="banner_pos_headerwidget_right_top" class="w480h80" style="">
              <!--  
              <?php display_banner($thebanners['headerwidget_right_top']); ?>
              -->
            <img src="adsense_ban/ad_480x80.gif" />

            </div>
          <?php } } ?>
          <div class="clear"></div>
        </div>
      </div>
      <div class="clear"></div>

     </div> 
    <?php } ?>
    <!-- END HEADER WIDGETS section  -->



	<div class="center-wrapper-inner">
	  
		<div id="header" > 

			<div id="navigation">
				<!-- old placeholder for navigation		 -->
				<div class="clearer">&nbsp;</div>

      </div>

					
          
 
		</div>
		
		
    <div class="clearer">&nbsp;</div>

		<div class="main" id="main-two-columns">

      <div class="left left-sidebar" id="admin-left-sidebar">
        <!-- AREA to display the navigation -->  
        <div id="main-nav">
          <div id="main-nav-links">
            <ul class="tabbed">
            <li></li>          
            </ul>
          </div>
        </div> 
      </div>


			<div class="left" id="main-left"> 

          <!-- Global message Area  --> 
          <div id="global_message" class="msg_banner" style="display:none;">
            <a href="" class="msg-close"></a> 
            <span id="inner"></span> 
          </div><div class="clearer">&nbsp;</div>   

          <!-- Notification AREA  --> 
          <div id="global_notif_wrapper" class="notif_banner" style="display:none;">
          </div><div class="clearer">&nbsp;</div> 


        <!-- Overlay message area --> 
        <div id="oe_wrap" class="oe_wrap" style="display:none;">
          <div class="icon"></div><div class="content"></div><div id="oe_close"></div>
        </div>    
        
        <!-- general loading box & Javascript control  --> 
        
          <div class="loadarea" id="mainloading">

          <!-- START version for Crawlers and browsers without Javascript  -->
          <noscript> 
            <?php 
             if (!isset($_GET['gplus'])){
                
                echo html_snapshot_display('content', $r);  
              }
            ?>
          </noscript>
          <!--  END version no-JS -->

          <!-- LOADING Section  --> 
          <?php 
            $noscript=1;  
            if (($r==false)) { ?>
            <div class="loadbox" id="b1"></div>
            <div class="loadbox" id="b2"></div>
            <div class="loadbox" id="b3"></div>
            <div class="loadbox" id="b4"></div>
            <div class="loadbox" id="b5"></div>
            
            <div class="loadspan" id="loadspan"><?php if ($noscript!=1) echo $cust_loading_msg;?></div>
          </div>
        
          <?php }  ?>


         <!-- AREA to display Breadcrumb  --> 
          <div id="breadcrumbs" class="clear" style="display:none;">
        	</div> 
        	
        	<div id="output"></div>

        
          <!-- AREA to display FORM to create/modify an Ad  --> 
          <div id="forminput" class="hideit" >
        	</div>
        	
        	
          <!-- AREA to display Ad details  --> 
          <div id="addetails" class="addetails" > 
          </div>
          
          <div class="clearer">&nbsp;</div>           

          <!-- AREA to display the List of Articles  -->
          <div id="adlist">
          </div>

        	<div class="clearer">&nbsp;</div>

			</div>

			<div class="right sidebar" id="sidebar">
  			<!-- AREA where other section will be displayed -->      				
			</div>

			<div class="clearer">&nbsp;</div>

		</div>

	</div>

	</div>


 <?php
    if ($r==false){ 
    ?>

    <div id="dashboard">
        <div id="dashboard-content">

      <?php  if ($cust_about_footer_desc) { ?>
      <div class="column left" id="column-1">
        <div class="column-content">
          <div class="column-title totranslate">A propos </div>
          <div class="about-desc"><?php echo   (stripslashes($cust_about_footer_desc));?> </div>
          <a class="learnmore totranslate" href="<?php echo $cust_aboutus_url;?>">En savoir plus</a>
        </div>
      </div>
      <?php } ?>

      <div class="column left help" id="column-3">
        <div class="column-content">
          <div class="column-title totranslate">Aide et Support</div>
          <ul class="plain-list">
           <li><a class=" " href="<?php echo $cust_faq_url;?> "><i class="icon-fa-info-sign mr6"></i><span class="totranslate">Questions Frequentes (FAQ)</span></a></li>
           <li><a class=" " href="<?php echo $cust_demo_url;?> "><i class="icon-fa-lightbulb mr6"></i><span class="totranslate">Tutoriels et d�mos</span></a></li>
           <li><a class=" " id="feedbackme" href="#"><i class="icon-fa-comments mr6"></i><span class="totranslate">Signaler un probl�me</span></a></li> 
          </ul>
        </div>

      </div>

      <div class="column right" id="column-4">

        <div class="column-content">
          <div class="column-title totranslate ">Suivre / Contact</div>
          <ul class="social-footer">


            <?php  if ($cust_facebook_url) { ?>
             <li class="social-elem">
              <a nottip="yes" href="<?php echo $cust_facebook_url;?>" title="page twitter " target="_blank">
                <i class="icon-fa-facebook-sign"></i>
              </a>
            </li>
            <?php } ?>

            <?php  if ($cust_twitter_url) { ?>
             <li class="social-elem">
              <a nottip="yes" href="<?php echo $cust_twitter_url;?>" title="page twitter " target="_blank">
                <i class="icon-fa-twitter-sign"></i>
              </a>
            </li>
            <?php } ?>


            <?php  if ($cust_gplus_url) { ?>
             <li class="social-elem">
              <a nottip="yes" href="<?php echo $cust_gplus_url;?>" title="page twitter " target="_blank">
                <i class="icon-fa-google-plus-sign"></i>
              </a>
            </li>
            <?php } ?>

            <?php  if ($cust_youtube_url) { ?>
             <li class="social-elem">
              <a nottip="yes" href="<?php echo $cust_youtube_url;?>" title="page twitter " target="_blank">
                <i class="icon-fa-youtube-sign"></i>
              </a>
            </li>
            <?php } ?>

          </ul>
          <div class="clear"></div> <!-- reset -->
          
          <!-- Newsletter section  -->
          <div class="newsletter-wrapper">
            <!-- placeholder for Newletters  -->
          </div>
          <!-- END newsletter section  -->


        </div> 
      </div> <!--  end COLUMN -->

      <div class="clearer">&nbsp;</div>
      </div> <!--  end DASHBOARD CONTENT  -->
    </div> <!--  end DASHBOARD  -->
    
    
     <!-- add FOOTER -->
    <?php include_once("footer.php"); ?>    
    <!-- END FOOTER -->

    <?php } ?>


</div>

<!-- VERY IMPORTANT -> Special zone for storing MEYWORDS for URL Rewritte to be used by JS  -->
<?php echo display_keywords_seo(); ?>

<!-- VERY IMPORTANT -> Special zone for storing SOCIAL URLs  -->
<?php echo display_social_urls(); ?>


  <!-- Jquery LIB -->                                                                    
  <!--<script type="text/javascript" src="lib/jquery.js"></script>-->  
<!--   
  <script type="text/javascript" src="lib/jquery-1.4.4.min.js"></script> 

 -->

  <script type="text/javascript" src="lib/jquery-1.7.min.js"></script> 

  
  <script type="text/javascript">
  function loadbarAnimStart(){
        $('#b1').animate({ opacity: 1}, 300, function() {
            $('#b1').animate({ opacity: 0.2}, 300, function() {});
        });
        
        t1=setTimeout(function() { 
        $('#b2').animate({opacity: 0.5}, 300, function() {
            $('#b2').animate({opacity: 0.2}, 300, function() {});
        })
        }, 200);
        
        t2=setTimeout(function() { 
        $('#b3').animate({opacity: 1}, 300, function() {
            $('#b3').animate({opacity: 0.2}, 300, function() {});
        })
        }, 400);
        
        t3=setTimeout(function() { 
        $('#b4').animate({opacity: 0.5}, 300, function() {
            $('#b4').animate({opacity: 0.2}, 300, function() {});
        })
        }, 600);
        
        t4=setTimeout(function() { 
        $('#b5').animate({opacity: 1}, 300, function() {
            $('#b5').animate({opacity: 0.2}, 300, function() {});
        })
        }, 800);
  };
  
  loadbarAnimStart();
  loadanim = setInterval(loadbarAnimStart, 1400);
  
  </script>
  
  <!-- Jquery plug-in -->
  <script type="text/javascript" src="lib/patmisc.postload.lib.min.js"></script>   

  <!-- HELLO- SSO plugin -->
  <?php if ($OAUTH_SSO_EN) { ?> 
  <script type="text/javascript" src="lib/hello.min.js"></script>    
  <?php }?> 
  
  <!--    
  <script type="text/javascript" src="lib/jquery.address-1.3.1.min.js"></script>                                                                 
  <script type="text/javascript" src="lib/jquery.easing.1.3.min.js"></script>                                                                
  <script type="text/javascript" src="lib/jquery.zads.toolkit.js"></script> 
  <script type="text/javascript" src="lib/chosen.jquery.min.js"></script> 
  -->


  <!-- LANGUAGE File (MASTER) -->
  <?php if (!$DISABLE_TRANSLATION) { ?> 
    <script type="text/javascript" charset="utf-8" src="lang/<?php echo str_replace('_','-',$cust_lang_long); ?>.js"></script>
  <?php }?>


  <!-- LANGUAGE File (CUSTOM) - COMING ON TOP OF EXISTING ONE -->
  <?php if (isset($THEME_CUST_LANG_URL) && $THEME_CUST_LANG_URL!="" && !$DISABLE_TRANSLATION) { ?> 
    <script type="text/javascript" charset="utf-8" src="<?php echo $THEME_CUST_LANG_URL.str_replace('_','-',$cust_lang_long); ?>.js"></script>
  <?php }?>
  

  <!-- DATE PICKER --> 
  <script type="text/javascript" src="lib/bootstrap-datepicker.js"></script>  

  <!-- moment language script -->
  <script type="text/javascript" charset="utf-8" src="<?php echo $ROOT_LIBS_URL;?>lib/moment-with-locales.min.js"></script> 


  <!-- Load graphical library and associated country map  -->
  <?php if ($ENABLE_COUNTRY_MAP) { ?>  
    <script type="text/javascript" src="lib/raphael-min.js"></script> 
    <script type="text/javascript" src="map/map_<?php if (!$LOCALE_DEFAULT_SUB_CODE) echo $LOCALE_DEFAULT_COUNTRY_CODE; else echo $LOCALE_DEFAULT_SUB_CODE
      ?>.js"  charset="utf-8" ></script> 
  <?php } ?>
  
  <!-- location Array (Javascript) --><!-- 
  <script type="text/javascript" src="lib/ArrayDept.js"></script>
   -->

  <!-- Core feature of ZADS--> 
  <script type="text/javascript" src="js/zads.js"></script> 
  <!-- SECOND STAGE  feature of ZADS--> 
  <script type="text/javascript" src="js/zads_post.js"></script> 
  

    <!-- ELEVATED ZOOM LIB if function is activated -->
  <?php if (isset($IMG_ZOOM_EN) && $IMG_ZOOM_EN) { ?> 
  <script  type="text/javascript" src='lib/jquery.elevateZoom.min.js'></script>
  <?php } ?>
  
   <!-- CUSTOM STAGE  feature of ZADS--> 
  <?php if (isset($THEME_EXTRA_JS_URL) && $THEME_EXTRA_JS_URL!="") { ?> 
   <script type="text/javascript" src="<?php echo $THEME_EXTRA_JS_URL;?>"></script> 
  <?php } ?>  
  <!-- google map API *** asynchronously loaded *** --> 
  
  <!-- evernote script *** asynchronously loaded *** --> 


</body>
</html>
