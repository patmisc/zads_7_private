<?php 
  // ----- INIT ESSENTIAL SETTINGS =  LANGUAGE  ----// 
  include_once "./phpsvr/init_settings.php";
  include_once "./phpsvr/html_snapshot_lib.php"; 

  $local_cust_title =  isset($forced_cust_title) ? $forced_cust_title : $cust_title ; 
  $local_cust_description =  isset($forced_cust_description) ? $forced_cust_description : $cust_description ; 
  $local_cust_keywords =  isset($forced_cust_keywords) ? $forced_cust_keywords : $cust_keywords ; 

?> 

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr">

<head>
<?php 
if (detect_googlebot()) display_header_comments();
?> 

<base href="<?php echo $DOMAIN_FQDN;?>" />

<!--   <meta http-equiv="content-type" content="text/html; charset=iso-8859-15"/>  -->

  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 

  <title><?php echo   (stripslashes($local_cust_title)); ?></title>
  <meta name="description" content="<?php echo   (stripslashes($local_cust_description));?>"/>
  <meta name="keywords" lang="<?php echo $cust_lang;?>" content="<?php echo $local_cust_keywords;?>" /> 
 
   <!-- THEME and CUSTOM  stylesheets -->
  <?php if (isset($THEME_MASTER_CSS_URL) && $THEME_MASTER_CSS_URL!="") { ?> 
  <link rel="stylesheet" media="all" type="text/css" href="<?php echo $THEME_MASTER_CSS_URL;?> "  />
  <?php } else { ?>
    <link rel="stylesheet" media="all" type="text/css" href="css/theme_style.css"  />
  <?php } ?> 
  
  <?php if (isset($THEME_CSS_URL) && $THEME_CSS_URL!="") { ?> 
    <link rel="stylesheet" media="all" type="text/css" href="<?php echo $THEME_CSS_URL;?> "  />
  <?php } else { ?>
    <link rel="stylesheet" media="all" type="text/css" href="css/custom_style.css"  />
  <?php } ?> 

  <!-- awesome font  -->
  <link rel="stylesheet" media="all" type="text/css" href="css/font-awesome.min.css">



  <!--[if IE 6]> 
  <link rel="stylesheet" href="theme_style_IE6.css" type="text/css" media="screen" /> 
  <![endif]-->
  <?php if (isset($NO_MOBILE_CSS) && $NO_MOBILE_CSS===true) $tdummy=1; else { ?> 
  <link rel="stylesheet" media="screen and (min-device-width: 320px) and (max-width:480px)" href="css/mobile.css" type="css/text/css" />
  <link rel="stylesheet" media="screen and (min-device-width: 481px) and (max-device-width: 799px)" type="text/css" href="css/tablet.css"/>
  <link rel="stylesheet" media="screen and (min-width: 481px) and (max-width: 799px)" type="text/css" href="css/tablet.css"/>
  <?php } ?> 
    <!-- theme for PRINT  -->
  <link rel="stylesheet" href="css/theme_print.css" type="text/css" media="print" charset="utf-8" />


  <link rel="shortcut icon" type="image/x-icon" href="<?php echo $cust_favicon_uri;?>"> 
  <link rel="icon" type="image/x-icon" href="<?php echo $cust_favicon_uri;?>">

</head>

<body id="top" class= "static-page" lang="<?php echo $cust_lang; ?>" xzads-lang="<?php echo $cust_lang_long; ?>" xzads-lang-support="<?php echo $cust_lang_support; ?>">



<!-- MODL BOX !!!! BUT BE PUT FIRST  after the body ********* --> 
  <!-- #customize your modal window here -->

        <div id="boxes">
        <div id="dialog" class="mbox-window">
          <div id="mbox-close"> <a href="#" id="close" class="close"></a></div>
          <!-- empty space for mbox-header-->
          <div class="clearer">&nbsp;</div>
          <div id="mbox-body">
          </div>      
          <div id="mbox-footer"> <a href="#" class="close"></a></div>
        </div>
        <div id="mask"></div>
        <div id="mask2"></div><!-- mask for displaying "loading... banner-->
      </div>

  <!-- TOP BAR  -->
  <div id="network">
    <div id="network-wrapper" class="center-wrapper">

      <div class="left"> 
      </div> 
 
      <div class="right">
        <ul class="tabbed" id="network-tabs">
          <li class="current-tab "><a href="<?php echo $DOMAIN_FQDN;?>"><i class="icon-fa-home mr6 fs13em"></i><span class="totranslate ">Back to main site</span></a></li>

        </ul>
        <div class="clearer">&nbsp;</div>
    </div>
          
      <div class="clearer">&nbsp;</div>
    </div>
  </div>

  <!-- !!! dont't forget to close he BODY TAG on the parent php file  !!!  -->