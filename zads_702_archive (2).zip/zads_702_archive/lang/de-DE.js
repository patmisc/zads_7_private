// JavaScript Document

if  (typeof monthnb_2_string == 'undefined')  var monthnb_2_string = []; 
if  (typeof daynb_2_string == 'undefined')  var daynb_2_string=[]; 
if  (typeof my_dictionary == 'undefined')  var my_dictionary=[]; 

 monthnb_2_string['de_DE'] ={
  1 : "Jan.",
  2 : "Feb.", 
  3 : "Mer.",
  4 : "Apr.",
  5 : "May",
  6 : "Jun.",
  7 : "Jul.",
  8 : "Aug.",
  9 : "Sep.",
  10 : "Oct.",
  11 : "Nov.",
  12 : "Dec."
}

 daynb_2_string['de_DE'] ={
  0 : "Sunday",
  1 : "Myday", 
  2 : "Tuesday",
  3 : "Wednesday",
  4 : "Thuersday",
  5 : "Friday",
  6 : "Sunday"
}

   my_dictionary['de_DE'] = { 
    // gen�ral dates : 
    "yesterday"  : "yesterday",
    "today"  : "today",
    "tomorrow" : "tomorrow",
    "%s day ago" :"%s day ago",
    "%s days ago" :"%s days ago",
    "till "  : "till ", 
    "yes" : "yes", 
    "no" : "no", 
    
    "in %s day" :"in %s day",
    "in %s days" :"in %s days",
    "days" : "days", 
    "day" : "day", 
    "the" : "the", 
    "the " : "the ",
    
    "%s ads" : "%s ads" ,
    "%s ad" : "%s ad" ,
    "no ad" : "no ads",
    
    "%s cats" : "%s categories" ,
    "%s cat" : "%s category" , 
    
    "%s users" : "%s users" ,
    "%s user" : "%s user" ,
    
    "no user" : "no users",

    // global 
    "more" : "more",
    "Load more" : "load more", 

    // general BROWSER detection messages
    "You're using IE8 or above" : "You are using IE 8 ou sup.",
    "You're using IE7.x" :  "You are using IE 7.x ",
    "You're using IE6.x" :  "You are using IE 6.x ",
    "You're using IE5.x" :  "ou are using IE 5.x ",
    //': this browser is partialy supported . See the list <a href="navsupported_fr.html">here</a>' : ' : ce navigateur est partiellement support�. Voir la liste <a href="navsupported_fr.html">ici</a>',
    
    // general navigation 
    "Main cat sell" : "Sell",
    "Main cat buy" : "Buy", 
    "Main cat user" : "Sellers", 
    "Zetvu" : "ISeenYou",
    "my admin" : "( Admin )", 
 
    // boutons de creation 
    "add a cat"  : "Create a category",
    "add a user"  : "Create a user",
    "add a sell"  : "Create your ad",
    "add a buy"  : "Create your ad",

    // texte d'introduction  aux formulaires 
    " ad form header title"  : "My ad: ",
    " ad form header introduction" : 
        "Create your clasified ad through this form <br> It will be published after approval from the site editor. Ad remains active for 60 days. <br>Thanks to care about mandatory field marked with a '*'<br> ",
    
    "preview ad form header title"  : "Validate your ad: ",
    "preview ad form header introduction"  : 
        "Checkout the content of your ad and our terms and conditions then validate to proceed",
    
    
    "modify ad form header title"  : "Modify My ad: ",
    "modify ad form header introduction" : 
        "Modify your ad through this form <br> It will be published after approval from the site editor.<br>Thanks to care about mandatory field marked with a '*'<br> ",

    " user form header title"  : "Register : ",
    " user form header introduction" : 
        "Register through this form to access the site immediatly <br>",

    " user form header introduction facebook" : 
        "You can also sign using <span class='icon-menu' id='facebook'><span class='icon'></span><a href='#' what='facebook'  name='action-on-elem' class='text'>your Facebook account.</a></span>",


    "preview user form header title"  : "Validate your account details : ",
    "preview user form header introduction"  : 
        "Checkout the details of your account, accept the terms and conditions and validate to continue",
    
    
    "modify user form header title"  : "Modify a user: ",
    "modify user form header introduction" : 
        "Modify user details  through this form <br>",

    "modify curuser form header title"  : "Modify my profile: ",
    "modify curuser form header introduction" : 
      "Modify your profile details  through this form <br>",


    " cat form header title"  : "New category: ",
    " cat form header introduction" : 
    "Create a category through this form <br> It will be available after site reload<br>",

    "modify cat form header title"  : "Modify a category: ",
    "modify cat form header introduction" : 
    "A travers ce formulaire, Modify a category. <br>Elle sera disponible imm�diatement.<br>Merci de pendre en compte les champs obligatoires marqu�s d'a �toile. <br> ",

    " zetvu form header title"  : "New ZeTVu: ",
    " zetvu form header introduction" : "Cr�er un message simple, ludique et anonyme par ce ZeTvu (prononcer 'ze t� vu').<br> ",
    
    "modify zetvu form header title"  : "Modify un ZeTVu:",
    "modify zetvu form header introduction" : 
        "Create your ISeenYou through this form <br> It will be published immedialty.<br>Thanks to care about mandatory field marked with a '*'<br> ",

    // Formulaire de saisie d'un user
    "username"  : "username",
    "firstname"  : "firstname",
    "lastname"  : "lastname",
    "password"  : "password",
    "password from "  : "password",
    "confirm password"  : "password (repeat)",
    "more user details" : "Details",
    "log-in details" : "Connect",
    "user email" : "Email address",
    "user phone" : "Main phone number",
    "phone" : "Phone.",
    "location" : "Localization",
    "user upload picture" : "Picture(s)",
    "change password"  : "Change password",
    "retype the password to confirm" : "confirm password",
    
    "help email rules" : "format should be name@service.ext",
    "help passord rules" : "must have 5 chars min.",
    
    /* am�liorations ZADS4.0 pour le formulaire User*/
    //"bio and skills details" :"",
    "user bio" : "Your motto",  
    "user skills" : "Skills",
    "skills" : "Skills",
    "contact details" : "details", 
    "contact actions" : "actions", 
    "selected skills" : "Your skills",
    "select a skills" : "Select your skills",
    // formulaire de saisie de comp�tances
    "rating_level_1" : "beginner", 
    "rating_level_2" : "amateur",
    "rating_level_3" : "skilled amateur",
    "rating_level_4" : "almost pro",
    "rating_level_5" : "professionnal",
    "rating please select something" : "select your rating", 
    "add_skills" : "add this skill",
    "remove_skill" : "remove",
    
    "user upload pictures" : "Picture / portfolio", 
    "upload folioimg" : "add a picture",
    "upload filename" : "add a picture",    
    "user upload portfolio help %s" : "upload pictures which highlight your portfolio. Up to %s pictures.",
    
    "user upload avatar" : "Avatar", 
    "upload avatarimg" : "add a picture", 
    "user upload avatar help %s" : "Upload a picture for your avatar (format :  207 x 266px) ",
    
    "declare pro user" : "Professionnal",
    "type of user account" : "Account type", 
    "professionnal details" : "Professionnal",
    "ad company name" : "Raison Sociale", 
    //"ad siret" : "SIRET",  
    "ad siret" : "VAT",  
    "ad website" : "web site",
    "link to website" : "web site",
    "ad banner" : "Banner", 
    "upload probannerimg" : "add a banner",
    "post ad banner" : "format xxx",
    "help ad banner" : "Upload a banner (format : Leaderboard 728 x 90). Will be displayed on top of your profile page.",

    "user location" : "Address",  
    "user loczipcode" : "zip code", 
    "user loccity" : "ciry", 
    "user locdept" :"department", 
    "user locregion" : "region",
    
    "usertype" : "rights",
    "registerdate" : "created ", 
    "lastvisitdate" : "last visit", 
    "id" : "id",
    
    /* messages pour les conseils du checker de passwords */ 
    "shortPass" :" Too short ! " ,   
    "badPass":" Not enough strong!", 
    "goodPass":" Good !",   
    "strongPass":" Robust !",   
    "samePassword":" Same as password... not good !",  
    
    "gender"  : "gender",
    "male" : "male", 
    "female" : "female",
    
    "locale"  : "Main language.",
    "fr_FR"  : "french",
    "en_GB"  : "english (UK)",
    "en_US"  : "english (USA)",
    "de_DE"  : "german",
    "nl_NL"  : "dutch",
    "ar_AR"  : "arabe",
    
    "user auth" : "Autentication", 
    "fb" : "Facebook",
    "auth type fb" : "Facebook",
    "auth type " : "local",
    "content via facebook" : "via Facebook", 
    "login_facebook" : "Use my Facebook account",
    "facebook login description" : "Use your Facebook account to log-in to this site",
    "or" : "or",  
    //"Error in FACEBOOK authentification" : "a erreur est survenue lors de l'autentification via Facebook.",
    
    "login_google" : "Use my Google account",
    
    // formulaire pour les categorys
    "cat title"  : "Name",
    "cat description"  : "category description",
    "cat upload picture" : "Picture(s)",
    "help cat title" : "category name ", 
    "desc cat type" : "Type of category", 
    
    "cattype_ad" : "for ads", 
    "cattype_user" : "for users",
    "cattype_" : "for all",  
    
    "help_on_cattype cattype_" : "This category can be used for users and ads", 
    "help_on_cattype cattype_user" : "This category can be used for users only", 
    "help_on_cattype cattype_ad" : "This category can be used for ads only", 
    
    // formulaire pour les zeTvu
    "<b>Je tai vu ...</b>" : "<b>I have seen you ...</b>",
    "zetvu title"  : "Intro",
    "zetvu desc"  : "Message",
    "zetvu location"  : "Where ?",
    
    // input de recherche : 
    "-- search through ads --" : "-- What, Where ? --", 
    "search" : "search", 
    
    // Formulaire de saisie de l'ad
    "ad title"  : "Title",
    "help title limited to 60 chars. Do not indicate buy of sell" : "60 chars max. Do not indicate sell or buy",
    "ad description"  : "Description",
    "ad categorie"  : "Category",
    "ad email"  : "Email",
    "ad sell or buy"  : "Type",
    "ad video embed" : "Video HTML code", 
    "ad video embed help" : "Entrer the HTML code from your video provider",
    "sell"  : "sell",
    "buy"  : "buy",
    "ad price"  : "Price",
    "$" : "(in $) :  set to 0 for free items. Indicate an estimated price if negociable",
    "�" : "(in �) :  set to 0 for free items. Indicate an estimated price if negociable",
    "ad upload picture" : "picture(s)",
    "ad upload image help %s" : 
    "You can add up to %s pictures. Max 500 ko per picture. Allowed extensions .jpeg, .jpg, .gif, .png",

    "cat upload picture help %s" : 
    "You can add up a picture which will be used for ads without a picture. Max 500 ko per picture. Allowed extensions .jpeg, .jpg, .gif, .png",

    "zetevu upload image help %s" : 
    "You can add up a picture. Max 500 ko per picture. Allowed extensions .jpeg, .jpg, .gif, .png",

    "ad details" : "Ad details",
    "ad contact me" : "Contact",
    "how to contact you for this ad" : "Contact me ?",
    "enable phone"  : "Phone",
    "show phone"  : "Phone",
    "show email"  : "Email",
    "show name"  : "Name",
    "ad help enusername" : "The name should be between 5 to 20 chars",
    "Show my email address together with this ad" : "show my email with the ad",
    "Show my name together with this ad" : "show my name with the ad",
    "display my phone number" : "show my phone number with the ad", 
    "Information on how to see it and get it" : "Location ? ", 
    "ad location and delivery": "Localization",
    "ad location": "Address",
    "help indicate for example a zip code or town" : 
    "format : [street,city,country] or [zipcode,country]. For auto-detection, leave this field blank",

      
    "help indicate format phone number" : "international telephon number  :+country-code Number .Example : +1 0390671234",
    "Not the right file extension." : "Not the right file extension.", 
    "file size exceed limit." : "File size exceed limit.",
    "id of article owner" :"ID of owner", 
    "userid" : "user identification",  
    

    // title of Menu which are close to the input texts. 
    "post menu loc" : "Auto-detect your location", 
    "check this loc" : "Check this address ", 
    
    // informations affich�es lors d'a modification
    "publishing state" : "Miscellaneous",
    "Publication status" : "Various information on your ad", 
    "ad pub date" :"Date", 
    "ad logs":"History", 
    "what" : "What?", 
    "whatid"  : "ID",
    "auth"  : "auth",
    "cron"  : "cron",
    "sec"  : "system",
    "daily"  : "daily",
    "weekl"  : "weekly",
    "severity" : "Sev.",
    "severity_0" :"-",
    "severity_1" :"Mid",
    "severity_2" :"High",
    "Only severity 0" :"Regular severity",
    "Only severity 1" :"mid severity",
    "Only severity 2" :"high severity",
    "-- select one severity --" : "-- filter per severity --",
    
    "-- select one action --" : "-- filter per type of log --",
    "Only Life-cycle" : "modification History", 
    "Only Auth" : "users connections", 
    "Only CRON" : "Automates/robots", 
    "Only SEC" : "System/security", 
     
    
    "I agree with the " : "I agree with the ", 
    "Terms and Conditions" : "Terms and Conditions", 
    
    "mandatory" : " * ",
    
    "upload picture" : "select a picture",
    
    // -------------------------------- END OF CHECKED TRANSLATION ----------------------------//

    "delete" : "delete",
    "submit" : "submit", 
    "cancel" : "cancel",
    "modify" : "modify",
    "edit" : "edit",
    "more actions" : "actions", 
    "no data found" : "No datas found", 
    
    "ad delete"  : "delete for life",
    "ad supress"  : "delete",
    
    // dialog button and content 
     "dialog cancel"  : "cancel",
     "dialog ok"  : "I confirm",
     "ad delete dialog title"  : "Delete a ad",
     "cat delete dialog title"  : "Delete a category",
     "user delete dialog title"  : "Delete un user",
     "profil delete dialog title"  : "Delete un user",
     "curuser delete dialog title"  : "Delete un user",

     "Confirm delete of ad :" : 
     "!! Warning, this action is definitive !!<br>Do you confirm deleting of ad : ",
     
     "Confirm delete of cat :" :
     "!! Warning, this action is definitive !!<br>Do you confirm deleting of category : ",
     
     "Confirm delete of user :" :      
     "!! Warning, this action is definitive !!<br>Do you confirm deleting of user : ",

     "Confirm delete of profil :" : 
     "!! Warning, this action is definitive !!<br>Do you confirm deleting of user : ",

     "Confirm delete of curuser :" : 
     "!! Warning, this action is definitive !!<br>Do you confirm deleting of user : ",
     
     // confirmation pour les logs 
     "Confirm deletion" : "Confirm deletion", 
     "Please confirm deletion of all logs entries with status :" : 
     "By clicking , <i>I confirm/i>, the logs below will all be deleted permanently.",
     
     "Action in progress ..." : "Update ongoing, please wait ...",
    // categorys 
    'select one categorie' : 'select one category',
    
    "-- select one reason --" : '-- select one reason --',
    "article sold though this site" : "article sold though this site",
    "article sold through another mean" : "article sold through another mean",
    "article no more available" : "article no more available",
    "auto" : "auto-deleting",
    "1_soldthru" : "Sold though this site", 
    "2_soldother" : "Sold through another mean", 
    "3_notavail" : "No more available", 
    
    "ad creation ongoing": "Ongoing creation of ad:",
    "zetvu creation ongoing": "Ongoing creation of ISeenYou :",
    "user creation ongoing": "Ongoing creation of user :",
    "cat creation ongoing": "Ongoing creation of category :",
    
    "(where?)" : "Localization ?", 
    
    "ad modification ongoing": "Ad modification ongoing :",
    "user modification ongoing": "User modification ongoing :",
    "curuser modification ongoing": "Profile modification ongoing :",
    "cat modification ongoing": "Category modification ongoing :",
    
    // erreurs sur les formulaires
    "You must select something." : "thanks to select semething.",
    "You must fill in something." : "thanks to enter a text.",
    "Incorrect format." : "incorrect format.", 
    "Incorrect rule." : "incorrect format.",
    "You must accept the Terms and conditions" : "You must accept the Terms and conditions",
    "Field does not match password" : "Field does not match password",
    "Text length exceeding limits." : "Text length exceeding limits.",
    "%s char remaining" : "%s char remaining",
    "%s chars remaining" : "%s chars remaining", 
    "%s chars max" : "%s chars max",
    "your must precise skills AND ratings." : "your must precise skills AND ratings.",
    
    // error in email formular
    "Incorrect email format" :  "Incorrect email format", 
    //"Incorrect SIRET number." :  "Incorrect SIRET number.", 
    "Incorrect SIRET number." :  "Incorrect VAT number. Must be BE0+9 chars", 

    // options payantes : 
    
    "ad payoptions" : "Upfront :", 
    "post payoptions" : "Paid options to put upfront you ad! ", 
    "help payoptions" : "Paid options to put upfront you ad! ", 

    "desc putontopgallery" : "Featured", 
    "post putontopgallery" : "Featured for 7 days", 
    "help putontopgallery" : "Featured for 7 days", 
    
    "desc pushtotop7days" :  "Top of the list", 
    "post pushtotop7days" :  "Force to top of the list for 7 days", 
     "help pushtotop7days" :  "Force to top of the list for 7 days", 
    
    "desc specialcolor"  :  "Highlighting", 
    "post specialcolor"  :  "Highlight with a special color", 
     "help specialcolor"  :  "Highlight with a special color", 
    
    "desc addpics"  :  "More photos" , 
    "post addpics"  :  "more photos" , 
    "help addpics"  :  "more photos" , 

    "desc paidvideo"  :  "add a video", 
    "post paidvideo" : "add a video via the embedd HTML code", 
    "help paidvideo" : "add a video via the embedd HTML code", 

    "pushtop" : "push to top",
    "pushgal" : "put featured",  

    // texte des boutons du formulaire
    "BTN ad NOT CREATED": "send",
    "BTN ad DRAFT": "save as draft",
    "BTN ad DRAFT PENDING PAYMENT" : "checkout", 
    "BTN ad PREVIEW": "validate",
    "BTN ad UNDER REVIEW": "submit for publishing",
    "BTN ad PUBLISHED": "publish",
    "BTN ad UNPUBLISHED": "un-publish",
    "BTN ad DELETED": "delete",
    "BTN ad REJECTED": "reject",
    "BTN ad WILLEXPIRE": "force to expiration",
    
    "BTN cat NOT CREATED": "send",
    "BTN cat DRAFT": "save as draft",
    "BTN cat UNDER REVIEW": "submit",
    "BTN cat PUBLISHED": "publish",
    "BTN cat UNPUBLISHED": "un-publish",
    "BTN cat DELETED": "delete",
    "BTN cat REJECTED": "reject",
    "BTN cat WILLEXPIRE": "force to expiration",
    
    "BTN user NOT CREATED": "send",
    "BTN user DRAFT": "save as draft",
    "BTN user DRAFT PENDING PAYMENT" : "checkout", 
    "BTN user UNDER REVIEW": "submit for publishing",
    "BTN user PUBLISHED": "register",
    "BTN user PREVIEW": "validate",
    "BTN user UNPUBLISHED": "un-publish",
    "BTN user DELETED": "delete",
    "BTN user REJECTED": "Rejeter",
    "BTN user WILLEXPIRE": "force to expiration",
    
    "BTN curuser NOT CREATED": "Envoyer",
    "BTN curuser DRAFT": "save as draft",
    "BTN curuser UNDER REVIEW": "submit for publishing",
    "BTN curuser PUBLISHED": "Register",
    "BTN curuser UNPUBLISHED": "un-publish",
    "BTN curuser DELETED": "delete",
    "BTN curuser REJECTED": "Reject",
    "BTN curuser WILLEXPIRE": "force to expiration",
    
    
    "BTN zetvu NOT CREATED": "envoyer",
    "BTN zetvu DRAFT": "sauvegarder draft",
    "BTN zetvu UNDER REVIEW": "submit for publishing",
    "BTN zetvu PUBLISHED": "publish",
    "BTN zetvu UNPUBLISHED": "un-publish",
    "BTN zetvu DELETED": "delete",
    "BTN zetvu REJECTED": "reject",
    
    

    "REGISTERED": "Registered",
    "EDITOR": "Editor",
    "SUPER-ADMIN": "Super Admin",
    
    "formular already exists" : "Form is already open. Close it to continue.",
    
    // sidebar 
    "Browse all": "see all",
    "latest ZeTvu" : "Latest ISeenYou", 
    "latest Tweet" : "Tweets", 
 
    // sidebar buttons 
    "Subscribe" : "Subscribe",
    "subscribe feed by email": "subscribe to feed by email", 
    "subscribe feed": "subscribe to RSS feed ",
    "follow us on twitter": "follow us on Twitter",
    "follow us on facebook": "follow us on Facebook",
  
    // texte des Status possibles d'un article
    "NOT CREATED": "draft",
    "DRAFT": "draft",
    "DRAFT PENDING PAYMENT": "Payment pending",
    "DRAFT PAYMENT OK": "Payment done",
    "UNDER REVIEW": "under review",
    "under review" : "under review",
    "PUBLISHED": "published",
    "UNPUBLISHED": "un-published",
    "DELETED": "deleted",
    "REJECTED": "rejected",
    "WILLEXPIRE": "will expire",
    
    // test descriptifs des LOGS 
    "create": "create",
    "update": "update",
    "delete": "delete",
    "updatehit": "update hit",
    "updatestatus": "update status",
    "resethits" : "reset hits", 
    
    "desc": "description",
    "state": "state",
    "No entries in logs." : "No entries in logs.",
    "No entries in payments." : "No entries in payments.",
    
    "log_resethits" : "reset of hit counter", 
    "log_create_DRAFT": "created as draft",
    "log_payment_DRAFT PAYMENT OK": "payment OK", 
    "log_create_UNDER REVIEW": "created and submitted",
    "log_create_PUBLISHED": "published",
    "log_update_DRAFT" : "modification and saved as draft",
    "log_update_DRAFT PENDING PAYMENT" : "set pending payment",
    "log_update_UNDER REVIEW": "modification and re-submit",
    "log_update_PUBLISHED": "published",
    "log_updatestatus_PUBLISHED": "published",
    "log_update_DELETED": "deleted ",
    "log_updatestatus_UNDER REVIEW" : "Submitted for review",
    "log_updatestatus_DELETED": "Deleted ",
    "log_update_UNPUBLISHED": "un-published ",
    "log_update_REJECTED": "Rehected by editor",
    "log_update_WILLEXPIRE": "set to will-expire ",
    "log_delete" : "final deleting",
    "log_auth_Access granted , welcome !" : "access granted", 
    "log_auth_incorrect LOCAL  password  - please check" : "access denied - bad password",
    "log_auth_incorrect Login name" : "access denied - bad user name",
    
    //valeur des priorit�s 
    "pty_normal" : "Normal",
    "pty_top" : "featured ",
    "pty_permanent" : "Permanent",
    "pty_news" : "News",  
    "top" : "Featured",
    "most viewed" : "Most viewed",

    // paypal 
    "You have paid options for <b>%s %s </b>" : "You have paid options for a total amount of <b>%s %s </b>", 
    "Payment successful": "Payment successful!", 
    "Thanks you for your payment ! Your ad will now be submitted for approval." : "Thanks you for your payment ! Your ad will now be submitted for approval.", 
    "Payment cancelled" : "Payment cancelled !", 
    "Your payment is cancelled. You can retrieve your ad into your dashboard." : "Your payment is cancelled. You can retrieve your ad into your dashboard.",
    "Paypal redirection ongoing" : "Paypal redirection ongoing ...", 
    "You will be redirected to paypal for finalizing payment." : "You will be redirected to paypal for finalizing payment.", 
    "Payment finalization"  : "Payment finalization ...", 
    "Thanks you for your payment ! We are updating your order, please wait." : "Thanks you for your payment ! We are updating your order, please wait.", 
    "paypal - This transaction does not exist or has already been processed" : "Sorry - This transaction does not exist or has already been processed",
    "paypal payment sucessfull" : "Payment sucessfull",     

    // champs du log des paiements
    "paymentdate" : "date", 
    "amt" : "amount", 
    "paymentstatus" : "status",
    "transactionid" : "transaction id",  

    // type comptes utilisateurs
     "protype_pri" : "Private",
     "protype_pub" : "Public",
     "protype_pro" : "Pro",
     "protype" : "Account",
     "private" : "Private",
     "public" : "Public", 
     "pro" : "Professionnal",
     "help_protype" : 
     "A private account is only visible for you. A public or pro. account is displayed for all users.",
     

     // ads relatives :
     "related ads " :  "ads ", 

    // actions
    "delete all auth logs" : "Delete all logs AUTHentication", 
    "delete all cron logs": "Delete all logs ROBOTS", 
    "delete all sec logs" : "Delete all logs SYSTEMS", 
    "batch actions" : "bulk actions >>",
    "help_logs_batch_actions_menu" :"Display the bulk modification menu.",
    "help_delete_logs_auth" : "This action delete all logs with  type  = authentication",
    "help_delete_logs_cron" :"This action delete all logs with  type  = cron",
    "help_delete_logs_sec" : "This action delete all logs with  type  = system",    
    
    // ecran de detail d'un article 
    "ad id" : "Ad number ",
    "ad status" : "Status ",
    "ad priority" : "Priority ",
    "ad moddate" : "modified by ",
    "ad publiched the" : "the",
    "ad hits" : "hit(s) ",
    "ad vendor info" : "Author",
    "ad info" : "Details",
    "ad actions" : "Actions",
    "ad admin" : "Manage ",
    "ad qr code" : "Retrieve this ad",
    "ad edit" : "edit",
    "ad reset hits" : "reset the hit(s) counter", 
    "ad savefav" : "add to favorites",
    "ad twitter" : "share on Twitter",
    "Share" : "share ... ",
    "more ... �" : "more ... �",
    "share on twitter" : "share on Twitter",
    "share on facebook" : "share on Facebook",
    "share on Linkedin" : "share on Linkedin",
    "share on Google+" : "share on Google+",
    "clip to Evernote" : "capture on Evernote",
    "bookmark this on Delicious" : "Link on Delicious",
    "ad facebook" : "share on Facebook",
    "One article of interest" : "One article of interest",
    "ad del savefav" : "remove from favorites",
    "ad email it" : "send by email",
    "ad print" : "print",
    "ad flag it abuse" : "flag this",
    /*
    "previous ad" : "pr�c�dent",
    "next ad" : "suivant",
    "next" : "suivant",
    "previous" : "pr�c�dent",
    */
    "previous ad" : "<",
    "next ad" : ">",
    "next" : ">",
    "previous" : "<",
    
    "elem logs": "History", 
    "Display elem logs": "display history", 
    

    "free" : "free",
    "more if registered" : "login for more",
    "Send a messge to the seller" : "Send a message to the seller",
    "Contact the user through the website" : "Connect through the site", 
    "send email" : "Send a message ",
    "call number" : "Call this num�ro",
      
    // help on buttons : 
      "title clip to Evernote" : "Clip it into Evernote",
      
    // login form title
    "You must be registered" : "You must be logged in for this action",
    "Login form title" : "Autentication",
    "login form introduction": "Autenticate yourself to access this site ",
    "register introduction": "If you are not already registered ",
    "login_register": "register here ",
    "login_lostpassword": "Forgot password ? ",
    "email address not known" : "Unknown email address", 
    "login": "login",
    "login name" : "user name",
    "login email" : "Email",
    "login_rememberme" : "remember me",
    "submit login" : "login",
    "logout": "logout",
    "welcome %s": "welcome <strong>%s</strong> ",
    "profil": "my profile",
    "Access granted , welcome !" : "Access granted , Welcome !", 
    "Correctly logout and cookies deleted" : "You are now logged out and all cookies are deleted.",
    "incorrect LOCAL  password  - please check" : "Error in autentication : incorrect password.",
    "incorrect Login name" : "Error in autentication : Unknown username.",
    "Register": "register",
    "Login in progress ..." : "Identification ongoing ...",
    "Loading in progress ..." : "Loading ...",
    
    // leaflet special texts
    "leaflet footer text"  : "This ad has been created, printed and available from ", 
    "Select the main picture, click <a id='print' href='#'>here</a> to print and clip along the line": 
    "Select the pictures to display, <a id='print' href='#'>print it</a> and and clip along the line",
    "ad leaflet print" :"Print leafler", // important sans espace pour IE 
    
    // email form title
    "email lost form title" : "Reset password", 
    "email support form title" : "Contact us", 
    "email feedback form title" : "Notify an issue", 
    "email remind form title" : "Remind me this message", 
    "email contact form title" : "Contact the seller", 
    "email abuse form title" : "Notify abuse", 
    "email contactuser form title" :  "Send a message to this user",
    
    "email lost form introduction" : 
    "Enter your email address. A new password will be sent to this address.", 
    
    "email support form introduction" : 
    "Use this form to contact us on all requests",

    "email feedback form introduction" : 
    "Use this form to give a feedback on missing functionalities or improvements.",

    "email abuse form introduction" : 
    "Use this form to notify us about an illicit content.",

    "email contact form introduction" : 
    "Use this form to contact a given seller on a given ad.", 

    "email remind form introduction" : 
    "Use this form to send me a reminder of this ad", 

    "email contactuser form introduction" : 
    "Use this form to contact a given user.",
    
    "your email" : "Your email", 
    "email title" : "Title", 
    "email description" : "Details", 
    
    "submit lost email" : "Reset", 
    "submit support email" : "send the message",
    "submit feedback email" : "send the request",  
    "submit abuse email" : "send the message",
    "submit contact email" : "send the message",  
    "submit remind email" : "send the message", 
    "submit contactuser email" : "send the message",  
    
    "Confirm modification" : "Confirm your modification ? ", 
    "Please confirm modification to status 40 of :" : 
    "By clicking, <i>I confirm</i>, this ad will be published. You can also send a message to the administrator at the ame time.",
    
    "Please confirm modification to status 90 of :" :     
    "By clicking, <i>I confirm</i>, the below ad will be rejected. Please indicate the reason which will be notified to the owner by email.",

    "Please confirm modification to status 80 of :" : 
    "By clicking, <i>I confirm</i>, the below ad will definitively deleted.",

    
    "your message": "Your message", 
    "Why ?": "Why ?",


    "Mysage sending in progress" : "Sending message ...", 
    "Mysage sucessufully sent !" : "Mysage sent sucessufully!",
    
    "This operation is not authorized !" :  "This operation is not authorized !", 
    "You have exceeded the commercial limits : MAX AD" :  
        "You have exceeded the commercial limits (MAX number of ads), please contact the site administrator.",

    "You are not authorised to access this section. You have been redirected to home page." : 
        "You are not authorised to access this section. You have been redirected to home page.", 

    "Login in progress" : "Login in progress ...", 
    "Error in Login form" : "Error in Login form",
    "incorrect Login/password" : "incorrect Login/password",
    "Your acount is created, please login to connect : ": "Your account is created, please login to connect :",
    "Congratulation !" : "Congratulation !", 
    
    "ZADS, I want to have more information on element :" : "I would like more information on : ",  
    "ZADS, I want to have more information" : "I would like more information on ...",
    "ZADS, I want to have more information" : "More information on  ?",
    
    "user vendor info" : "Main information",
    "user actions" : "Tools",
    "user info" : "Misc",
    "user id" : "ID",
    "user status" : "Status",
    "user type" : "Rights",
    "user register date" : "Created by",
    "user last visit date" : "Last visit",
    "ad registration date" : "Created by",
    "ad modification date" : "Modified by",
    
    "contact him" : "contact ",
    "Send him a message" : "Send a message",
    
    "user savefav" : "+ to favorites",
    "user email it" : "send by email",
    "user print" : "print",
    "user flag it abuse" : "abuse notification",
    
    "hits : %s times" : " %s hit(s)", 
      
    // modal box
    "modbox close" : "close",
    "info" : "Information",
    "error" : "Error",
    "success" : "Successful operation",
    "Server request timeout" : "Sorry, server is not responding.",
    
    // messages 
    "Action not yet available": "Action not yet available. Sorry !",
    "Yay! Everything went well!" : "Yay! Everything went well!",
    "ok ad under review" : 
        "We have received your request. it will be published after acceptance by the review commitee.",

    "ok ad deleted" : 
        "Your ad is deleted from site. However, you can reactiva it for 80 days if you change your mind.",

    "ok ad published" : 
        "Congratulation ! Your ad is now published and will remain visible for 30 days.",


    "ok user registered" : 
        "Votre access is now created and valid. Please login to acces the site.",

    "error in form checking" : 
        "The form is incompleted, thanks to verify and correct fields marked in red.",


    "Doh! Something happened : A user with this email already exist." : 
        "This email address is already in use. Thanks to select another one.",

    "Doh! Something happened : This username is not available.": 
        "this username is no more available. Thanks to select another one.",

    // main menu
    "containing <b>%s</b> word" : "containing <span class='highlight'>%s</span>",
 
    //user menu 
    "create ad" : "Post an ad", 
    "create zetvu" : "Post a ISeenYou", 
    "admin (dashboard)" : "Administration", 
    
    // geolocatization 
    "Geo-localization successful" : "Geo-localization successful : ", 
    "Selected Geo-localization successful" :  "Selected Geo-localization successful : ", 
    "Geo-localization failed" : "Geo-localization failed : ",
    "Geoloc not available in your navigator" : "Geoloc not available with your browser.",
    "Geo-localization time-out" :"Geo-localization : server time-out",
    "Geo-localization permission denied":"Geo-localization :  permission denied",
    "Geo-localization position unavailable":"Geo-localization : your position is unavailable",
    "Goecoding error : "  : "Goecoding error : ", 
    "your location" : "Your location",
    "Geo-localization in progress":"Geo-localization in progress ...",
    "Geo-localization error"  : "Geo-localization error",
    "Geo-localization can move marker to select other":"Geo-localization can move marker to select other ",
    "Release the Marker to the desired address" : "... Release the Marker to the desired address.", 
    "getting address...":"getting address..",
    "Error in Google Map loading. Check your internet connection." : "Error in Google Map loading. Check your internet connection.",
    "list view" : "", 
    "Sort by:" : "Sort by:",
    "Most recent" : "Most recent",
    "Lowest price" : "Lowest price",
    "Highest price" : "Highest price",
    "Highest hits": "Highest hits",
    "Sort by price desc" : "Sort by price descending",
    "Sort by price asc" : "Sort by price ascending",
    "Sort by date desc" : "Sort by date",
    "Sort by hits desc" : "Sort by hits",
    "Sort by name asc" : "Sort by name A to Z",
    "Sort by ad nb desc" : "Sort by ad number descending",
    "Sort by whatid desc" : "Sort by  par IDs descending",
    "Sort by what desc" : "Sort by type",
    
    "By " : "By ",
    "previous page" : "previous page",
    "next page" : "next page",
    "help prev" : "previous page",
    "help next" : "next page",
    
    "Ads <b>%s</b> to <b>%s</b> of <b>%s</b> ads" : "( <b>%s</b> to <b>%s</b> / <b>%s</b>)",
    "<b>%s</b>-<b>%s</b> of <b>%s</b>" : "<b>%s</b>-<b>%s</b> out of <b>%s</b>",
    
    "Back" : "back", 

    // sub-menu 
    "myads" : "My ads",
    "my_ad" : "My ads",
    "myadmin" : "My admin",
    "my_admin" : "My admin",
    "admin" : "Administration",
    
    "allads" : "All ads",
    "all ad" : "All ads",
    "admin_ad" : "All ads",
    "admin_user" : "All users",
    "allusers" : "All users",
    "admin_all" :"",
    
    "all logs" : "All logs entries",
    "all payments" : "All payments",
    "all status" : "all status",
    "manageother" : "Other ",
    "all cat" : "All categories",
    "all user" : "all users",
    "all admin_user" : "all users",
    "all admin_cat" : "All categories",
    
    "dashboard" : "Dashboard",
    "dash no data" : "no data",
    "mydashboard" : "My dashboard",
    "user" : "users",
    "cat" : "category", 
    "ad" : "ad", 
    "all myads" : "My ads",
    "all my_ad" : "All my ads",
    "all admin_ad" : "All ads",
    "myads_published" : "Published",
    "myads_all" : "All",
    "myads_pending" : "Pending",
    "myads_draft" : "Draft",
    "myads_draftpendingpayment" : "Payment pending",
    "myads_deleted" : "Expired",
    "published" : "published",
    "pending" : "pending",
    "willexpire" : "will expire",
    "draft" : "drafts",
    "draft pending payment" : "Payment pending", 
    "deleted_expired" : "expired",
    "deleted" : "expired",
    "ads_published" : "ads",
    "ads_draft" : "drafts",
    "admin_pending" : "pending",
    "admin_willexpire" : "Will expire",
    "admin_expired" : "Expired",
    "admin_deleted" : "Expired",
    "admin_published" : "Ads",
    "admin_draft" : "Drafts",
    "admin_pending" : "To validate",
    "admin_draftpendingpayment" : "Payment pending",
    "admin_draft pending payment" : "Payment pending", 
    "admin_willexpire" : "Will expire",
    "admin_expired" : "Expired",
    "admin_rejected" : "Rejected",
    "admin_under review" : "under review",
    "admin_user_draftpendingpayment" : "Payment pending",
    "myprofile" : "My profile",
    "myfav" : "My favorites",
    "manage_settings" : "Options",
    "manage_ads" : "ads (all)",
    "manage_users" : "users",
    "manage_cats" : "categories",
    "manage_twitter" : "Tweeter",
    "manage_logs" : "logs",
    "manage_payments" : "payment logs",
    
    "category":"categories",
    
    // tooltips 
    "Show List" : "Show as list with photos",
    "Show Gallery" : "Show as photo galleries",
    "Show simple List" : "Show as simple list",
    "Show map List" : "Show on a map",
    "help_on_status DRAFT" : "This elements is rdaft and not published",
    "help_on_status DRAFT PENDING PAYMENT" : "This elements is waiting payment",
    "help_on_status PUBLISHED" : "This element is published",
    "help_on_status UNDER REVIEW" : "This element is waiting valiation from editor",
    "help_on_status UNPUBLISHED" : "This element is removed from publication",
    "help_on_status REJECTED" : "this element has been rejected",
    "help_on_status DELETED" : "This elements is expired and will be deleted by  ",
    "help_on_status WILLEXPIRE" : "This element will expire ",
    "help_on_status pty_top" : "This element is a featured item",
    
    "help_on_status protype_pub" : "This account is public and visible for all",
    "help_on_status protype_pri" : "This account is private and only visible for owner",
    "help_on_status protype_pro" : "This account is Professionnal and visible for all",
    
    "view all" : "View all",
    "help link Main List" : "Back to initial list",

    "help password rules" : 
        "A good massword contains letters and chars and is different from username, email and password. Stick to the hints !",
    
    "help_myads_published" : "My ads published",
    "help_myads_all" : "All my ads",
    "help_myads_pending" : "My ads waiting approval",
    "help_myads_draft" : "My ads in draft or rejected",
    "help_myads_draftpendingpayment" : "My ads awaiting payment",
    "help_myads_deleted" : "My ads expired or deleted",
    "help_myprofile" : "See my profile",
    "help_myfav" : "See my favorite ads",
    "help_admin_pending" : "Ads to approve",
    "help_admin_willexpire" : "Ads which will expire",
    "help_admin_expired" : "Ads expired or deleted",
    "help_admin_deleted" : "Ads expired or deleted",
    "help_admin_draftpendingpayment" : "Ads awaiting payment",
    "help_admin_user_draftpendingpayment" : "Accounts awaiting payment",
    "help_manage_settings" : "Site settings",
    "help_manage_ads" : "all les ads dans all les �tats",
    "help_manage_cats" : "Manage categories",
    "help_manage_users" : "Manage users",
    "help_manage_twitter" : "Send Tweets directly",
    "help_dashboard" : "Display admin dashboard",
    "help_mydashboard" : "Display my dashboard",
    "help_manage_logs" : "Display logs",
    "help_manage_payments" : "Display received payments",


    "Sorry !":"Sorry !", 
    "No items found" : "No element found corresponding to your request. Some request need to be registered.",
    "No items found - No ad" : "No items found - No ads", 
    
    //tweeter
    "What are you doing?" : "What's new ?",
    "twitter header" : ": Tweet directly from ZADS",
    "Loading your tweets..." : "Loading your tweets...",
    "Timeline" : "Timeline",
    
    // global home page messages 
    "You have %s article(s) waiting for your approval" : "You have %s article(s) waiting for your approval : ", 

    "access here" : "access here",   
    
    // templates
    "some text"  : "a traduction de patrice  from patrice",
    "some more text"  : "another translation",
    "some text in french":"avec des � et des �",
    '%s text in french %s' : '%s exemple avec printf %s', 
    '%s text in french' : '%s exemple avec printf simple', 
    '%s comment' : '%s comment',
    '%s comments' : '%s comments', 
    'text in french' : 'texte en francais',
    
    // dashboard 
    'adsnb' : 'number',
    '%adsnb' : '%',
    'val' : 'number',
    '%val' : '%',
    'metrics' : 'number',
    '%metrics' : '%',
    'nb' : 'number',
    'nbusers' : 'number',
    '%nbusers' : '%',
    'cattitle' : 'category',
    'status' : 'status',
    'others' : 'others',
    
    "dash manage ads" : "(manage)", 
    "dash manage users" : "(manage)",
    "dash manage cats" : "(manage)",
    "cumul users"  : "# users (cumul)",
    
    "a10": "draft",
    "a20": "review ongoing",
    "a40": "published",
    "a60": "re-work",
    "a80": "ssuppressed",
    "a90": "rejet�(e)",
    "a45": "will expire",
    
    'fb' : 'Facebook',
    
    'stat dashboard title' : 'Dashboard (Admin)', 
    'stat mydashboard title' : 'My dashboard', 
    
    'top_dashboard' : 'Overview', 
    'ad_vol_per_cat' : 'Ads per category', 
    'ad_vol_per_type' : 'Ads per type', 
    'ad_vol_per_time' : 'Ads timeline', 
    'ad_vol_per_delete' : 'Cause of ad suppression',
    
    'ad_vol_per_status' : 'Ads per publiching status', 
    'user_vol_per_time' : 'User timeline', 
    'user_vol_per_age' : 'Users per age', 
    'ad_vol_per_age' : 'Ads per age', 
    'user_vol_per_type' : "Users per autentication method",
    'user_vol_per_protype' : "Users per profiles",  
    'ad_vol_per_user' : 'ads per user', 
    
    'Observation period : ' : 'Period : ', 
    'all' : 'all', 
    'thisyear' : 'this year', 
    'thismonth' : 'this month',
    'thisquarter' : 'this quarter',


    // footer translation 
    "A propos de ZADS" : "About", 
    "ZADS est une plateforme d'�change d'annonces entre particuliers dans un domaine priv� comme une entrepsie ou une collectivit�." :
        "ZADS is a classidied ads platform available in hosted or in script mode to enable community to exchange product and services", 

    "En savoir plus" : "Find our more", 
    "S'abonner": "Subsribe", 
    "Annonces par email":"Ads by email",    
    "Offres et Demandes" : "Sell and Buy", 
    "Aide et Support" : "Help and support", 


    "Aide et Support" : "Help and Support", 
    "Questions Frequentes (FAQ)" :"F.A.Q", 
    "Tutoriels et d�mos" :"Demo and Tutorials", 
    "Signaler un probl�me":"Notify us on an issue", 
    "Suivre / Contact" : "Follow / Contact",
    "suivre ZADS.FR sur Twitter"  : "Follow us on Twitter", 
    "suivre ZADS.FR sur Facebook"  : "Follow us on Facebook", 


    "Me contacter" : "Contact us", 
    "A propos" : "About this", 
    "Infos l�gales et CGU"  : "Terms and Conditions", 
    "Publicit�" : "Advertising",
    "Nous contacter" : "Contact us",
    "Aide" :  "Help", 
    "F.A.Q" :  "F.A.Q", 

    // new ZADS 4.6
    "around me :": "around me :", 
    ":unknown":":unknown", 
    "(change)" : "(change)",
    "(locate me)" :"(locate me)", 


    "display failed" : "Erreur", 
    "Doh! Something happened : no authorized - private profile" : "Doh! Something happened : no authorized.", 

    "post paidaccount" : "Service cost (price per year)  : ", 
    "help_protype_paid" : "Account to access the service. valid for 1 year. refers to terms and conditions",

    "Process ongoing ..." : "Process ongoing, please wait ...", 


    // banners management 
    "title" :"Title",
    "htmlcode": "HTML code",
    "clicktrackingurl": "Clicktracking URL", 
    "startdate": "Start Date", 
    "enddate": "End Date", 
    "position": "Position", 
    "clicks": "Clicks", 
    "impressions": "Print.", 
    "CTR": "CTR", 
    "resetclicks" : "Reset clicks and print counters",

    "desc_banner_title" :"Title",
    "desc_banner_htmlcode": "HTML code",
    "desc_banner_clicktrackingurl": "Clicktracking URL", 
    "desc_banner_startdate": "Start Date", 
    "desc_banner_enddate": "End Date", 
    "desc_banner_position": "Position", 
    "desc_banner_clicks": "Clicks", 
    "desc_banner_impressions": "Prints", 
    "desc_banner_CTR": "CTR", 

    "help_banner_title" :"Title of the banner to help you identifying it",
    "help_banner_htmlcode": "HTML code of the banner. Javascript is not supported yet. For Full background banner, just indocate the URL of the image",
    "help_banner_clicktrackingurl": "URL wich will redirect users clicking on this banner", 
    "help_banner_startdate": "Start date of publishing", 
    "help_banner_enddate": "End date of publishing", 
    "help_banner_position": "Position of the banner onto the site", 
    "help_banner_clicks": "Number of clicks received by this banner", 
    "help_banner_impressions": "Number of print/diplay of this banner", 
    "help_banner_CTR": "CTR =  Click Trhough Ratio  =  number of clicks / number of print",

    "add banner" :"ad a commercial banner",  
    "all banners" : "All the banners", 
    "manage_banners" : "Manage Banners",
    "help_manage_banners" : "Manage Banners",

    "Banner reset clicks confirmation" :"Confirmation of reset",
    "Banner reset clicks content" : "Confirmation of reset of clicks and prints metrics", 
    "Banner delete confirmation" : "Confirmation of definitive deleting",  

    " banner form header title" : "Creation of an advertising banner",
    " banner form header introduction" :"Below, create your advertising banner",
    "modify banner form header title" : "Modification f an advertising banner",
    "modify banner form header introduction" :"Below, modify your advertising banner",


    // extended contact form
    "contact reason" : "Request", 
    "procpny": "Company", 
    "to email" :"Destinator",

    '-- select one --' : '-- select one --',
    "Subscription" : "Subscription", 
    "Advertising" : "Advertising", 
    "Information" :"Information", 
    "Support" :"Support", 
    "Other" : "Other", 

    "Account fee is <b>%s %s </b> per year" : "Service is charged <b>%s %s</b> per year", 

    "Please validate the location" : "Thanks to Validate this location",

    "top register user" : "Subscribe", 

    // new zads 4.8 : 
    "show all" : "Sell all ads", 
    "Sort by hierarchy" : "Sort by Hierarchy",
    "desc_parentid" : "Parent Cat.", 
    "help_parentid" : "If you want to have two levels of categories, selectbelow the parent category.", 
    "cat order plus" : "Increase the rank of appearance",
    "cat order minus" : "Decrease  the rank of appearance",

    "pub users" : "Other users", 
    "Main list" : "Back to main list ", 

    // place to translate cat�gories 
    "Categorie initial" : "EXAMPLE OF NAME OF TRANSLATED CATEGORY", 




         // ----------  new zads 4.9 : 

    "plan_step1" : "Choose Subscription plan", 

    "plan selection header title" : "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
    "plan selection header line1" : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras commodo nec elit nec sollicitudin. Aenean rutrum, magna a venenatis lobortis, lacus nisi tristique est, id euismod ante dolor vel orci. Quisque porttitor augue at fermentum ultricies.",


    "us_protype" : "PRO directory",
    "us_skills"  : "Category",
    "us_avatarimg"  : "Logo",
    "us_bio"  : "Short Preso",
    "us_longdesc"  : "Long presentation",
    "us_portfolio"  : "Photo Gallery",
    "us_videoembed"  : "VideoLink",
    "us_phone" : "telephone",
    "us_dispemail" : "email",
    "us_subscription" : "days",
    "ad_nb" : "ads",
    "ad_nbpics" : "nb pictures",
    "ad_duration" : "",
    "ad_featured" : "",
    "ad_perm" : "",
    "ca_restricted" : "",
    "sign up" : "Signer pour ce plan",
    
    "plans_faq_1_question" : "Lorem ipsum dolor sit amet, consectetur",
    "plans_faq_1_response" : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras commodo nec elit nec sollicitudin. Aenean rutrum, magna a venenatis lobortis, lacus nisi tristique est, id euismod ante dolor vel orci. Quisque porttitor augue at fermentum ultricies.",

    "plans_faq_2_question" : "Lorem ipsum dolor sit amet, consectetur",
    "plans_faq_2_response" : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras commodo nec elit nec sollicitudin. Aenean rutrum, magna a venenatis lobortis, lacus nisi tristique est, id euismod ante dolor vel orci. Quisque porttitor augue at fermentum ultricies.",


    // nouvelles entr�se du formulaire 
    "desc_label_plan" : "Type of subscription", 
    "desc_plan" : "Subscription" ,
    "you selected the  plan  : " : "You selected the subscription plan : ", 
    "help_plan" : "This is the type of subscription you have signed for", 
    "desc_longdesc" :"Long presentation",

    "longdesc" : "Long presentation",
    "videoembed" : "Video presentation",

    // enhancements of zads 4.9
    "See details of this user" : "See details of this user", 
    "See all ads from this seller" : "See all ads from this user", 
    "See all ads" : "All ads",

    // pricing type 
    "desc_pricetype" : "Price (others)", 
    "help_pricetype" : "indicate other pricing model you propose", 
    "price" : "Fixed price",
    "to be discussed" : "to be discussed",
    "make an offer" : "Make offer",
    "on quote" : "on quote",
    "model dependant" : "Model dependant",

    "pricetype_tbdi" : "to be discussed",
    "pricetype_mano" : "make offer",
    "pricetype_onqo" : "on quote",
    "pricetype_mode" : "model dep.",

    "ad videoembed" : "Video", 
    //"(read more)" : "(lire la suite)",

    //"Ad creation forbidden from your current profile.": "La cr�ation d'annonces n'est pas autoris�e avec cet abonnement.", 
    //"You have exceeded quota of ad." : "La cr�ation d'annonce n'est pas possible car vous avez d�pass� les limites de votre abonnement.",

    // location based 
    "loccity" : "City", 
    "locdept" :"Department", 
    "locregion" : "Region",

    // traductions pour plan princing (customer specific)
    // SELECT INPUT 
    //"-- no plan -- " : "-- pas d'abonnement sp�cifique --", 
    //"options_Basic" : "Abonnement Basic", 
    //"options_Premium" : "Abonnement Premium", 
    //"options_Pro" : "Abonnement Pro", 

    "more cat" : "... more ...", 
    "less cat" : "... less ...",


    // end 
    'dummy' : 'dummy'
    }; 
