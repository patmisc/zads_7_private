// JavaScript Document

if  (typeof monthnb_2_string == 'undefined')  var monthnb_2_string = []; 
if  (typeof daynb_2_string == 'undefined')  var daynb_2_string=[]; 
if  (typeof my_dictionary == 'undefined')  var my_dictionary=[]; 

 monthnb_2_string['en_US'] ={
  1 : "Jan.",
  2 : "Feb.", 
  3 : "Mer.",
  4 : "Apr.",
  5 : "May",
  6 : "Jun.",
  7 : "Jul.",
  8 : "Aug.",
  9 : "Sep.",
  10 : "Oct.",
  11 : "Nov.",
  12 : "Dec."
}

 daynb_2_string['en_US'] ={
  0 : "Sunday",
  1 : "Myday", 
  2 : "Tuesday",
  3 : "Wednesday",
  4 : "Thuersday",
  5 : "Friday",
  6 : "Sunday"
}

   my_dictionary['en_US'] = { 
    // genéral dates : 
    "yesterday"  : "yesterday",
    "today"  : "today",
    "tomorrow" : "tomorrow",
    "%s day ago" :"%s day ago",
    "%s days ago" :"%s days ago",
    "till "  : "till ", 
    "yes" : "yes", 
    "no" : "no", 
    
    "in %s day" :"in %s day",
    "in %s days" :"in %s days",
    "days" : "days", 
    "day" : "day", 
    "the" : "the", 
    "the " : "the ",
    
    "%s ads" : "%s ads" ,
    "%s ad" : "%s ad" ,
    "no ad" : "no ads",
    
    "%s cats" : "%s categories" ,
    "%s cat" : "%s category" , 
    
    "%s users" : "%s users" ,
    "%s user" : "%s user" ,
    
    "no user" : "no users",

    // global 
    "more" : "more",
    "Load more" : "load more", 

    // general BROWSER detection messages
    "You're using IE8 or above" : "You are using IE 8 ou sup.",
    "You're using IE7.x" :  "You are using IE 7.x ",
    "You're using IE6.x" :  "You are using IE 6.x ",
    "You're using IE5.x" :  "ou are using IE 5.x ",
    //': this browser is partialy supported . See the list <a href="navsupported_fr.html">here</a>' : ' : ce navigateur est partiellement supporté. Voir la liste <a href="navsupported_fr.html">ici</a>',
    
    // general navigation 
    "Main cat sell" : "Sell",
    "Main cat buy" : "Buy", 
    "Main cat user" : "Sellers", 
    "Zetvu" : "ISeenYou",
    "my admin" : "( Admin )", 
 
    // boutons de creation 
    "add a cat"  : "Create a category",
    "add a user"  : "Create a user",
    "add a sell"  : "Create your ad",
    "add a buy"  : "Create your ad",

    // texte d'introduction  aux formulaires 
    " ad form header title"  : "My ad: ",
    " ad form header introduction" : 
        "Create your clasified ad through this form <br> It will be published after approval from the site editor. Ad remains active for 60 days. <br>Thanks to care about mandatory field marked with a '*'<br> ",
    
    "preview ad form header title"  : "Validate your ad: ",
    "preview ad form header introduction"  : 
        "Checkout the content of your ad and our terms and conditions then validate to proceed",
    
    
    "modify ad form header title"  : "Modify My ad: ",
    "modify ad form header introduction" : 
        "Modify your ad through this form <br> It will be published after approval from the site editor.<br>Thanks to care about mandatory field marked with a '*'<br> ",

    " user form header title"  : "Register : ",
    " user form header introduction" : 
        "Register through this form to access the site immediatly <br>",

    " user form header introduction facebook" : 
        "You can also sign using <span class='icon-menu' id='facebook'><span class='icon'></span><a href='#' what='facebook'  name='action-on-elem' class='text'>your Facebook account.</a></span>",


    "preview user form header title"  : "Validate your account details : ",
    "preview user form header introduction"  : 
        "Checkout the details of your account, accept the terms and conditions and validate to continue",
    
    
    "modify user form header title"  : "Modify a user: ",
    "modify user form header introduction" : 
        "Modify user details  through this form <br>",

    "modify curuser form header title"  : "Modify my profile: ",
    "modify curuser form header introduction" : 
      "Modify your profile details  through this form <br>",


    " cat form header title"  : "New category: ",
    " cat form header introduction" : 
    "Create a category through this form <br> It will be available after site reload<br>",

    "modify cat form header title"  : "Modify a category: ",
    "modify cat form header introduction" : 
    "A travers ce formulaire, Modify a category. <br>Elle sera disponible immédiatement.<br>Merci de pendre en compte les champs obligatoires marqués d'a étoile. <br> ",

    " zetvu form header title"  : "New ZeTVu: ",
    " zetvu form header introduction" : "Créer un message simple, ludique et anonyme par ce ZeTvu (prononcer 'ze té vu').<br> ",
    
    "modify zetvu form header title"  : "Modify un ZeTVu:",
    "modify zetvu form header introduction" : 
        "Create your ISeenYou through this form <br> It will be published immedialty.<br>Thanks to care about mandatory field marked with a '*'<br> ",

    // Formulaire de saisie d'un user
    "username"  : "username",
    "firstname"  : "firstname",
    "lastname"  : "lastname",
    "password"  : "password",
    "password from "  : "password",
    "confirm password"  : "password (repeat)",
    "more user details" : "Details",
    "log-in details" : "Connect",
    "user email" : "Email address",
    "user phone" : "Main phone number",
    "phone" : "Phone.",
    "location" : "Localization",
    "user upload picture" : "Picture(s)",
    "change password"  : "Change password",
    "retype the password to confirm" : "confirm password",
    
    "help email rules" : "format should be name@service.ext",
    "help passord rules" : "must have 5 chars min.",
    
    /* améliorations ZADS4.0 pour le formulaire User*/
    //"bio and skills details" :"",
    "user bio" : "Your motto",  
    "user skills" : "Skills",
    "skills" : "Skills",
    "contact details" : "details", 
    "contact actions" : "actions", 
    "selected skills" : "Your skills",
    "select a skills" : "Select your skills",
    // formulaire de saisie de compétances
    "rating_level_1" : "beginner", 
    "rating_level_2" : "amateur",
    "rating_level_3" : "skilled amateur",
    "rating_level_4" : "almost pro",
    "rating_level_5" : "professionnal",
    "rating please select something" : "select your rating", 
    "add_skills" : "add this skill",
    "remove_skill" : "remove",
    
    "user upload pictures" : "Picture / portfolio", 
    "upload folioimg" : "add a picture",
    "upload filename" : "add a picture",    
    "user upload portfolio help %s" : "upload pictures which highlight your portfolio. Up to %s pictures.",
    
    "user upload avatar" : "Avatar", 
    "upload avatarimg" : "add a picture", 
    "user upload avatar help %s" : "Upload a picture for your avatar (format :  207 x 266px) ",
    
    "declare pro user" : "Professionnal",
    "type of user account" : "Account type", 
    "professionnal details" : "Professionnal",
    "ad company name" : "Raison Sociale", 
    //"ad siret" : "SIRET",  
    "ad siret" : "VAT",  
    "ad website" : "web site",
    "link to website" : "web site",
    "ad banner" : "Banner", 
    "upload probannerimg" : "add a banner",
    "post ad banner" : "format xxx",
    "help ad banner" : "Upload a banner (format : Leaderboard 728 x 90). Will be displayed on top of your profile page.",

    "user location" : "Address",  
    "user loczipcode" : "zip code", 
    "user loccity" : "city", 
    "user locdept" :"department", 
    "user locregion" : "region",
    
    "usertype" : "rights",
    "registerdate" : "created ", 
    "lastvisitdate" : "last visit", 
    "id" : "id",
    
    /* messages pour les conseils du checker de passwords */ 
    "shortPass" :" Too short ! " ,   
    "badPass":" Not enough strong!", 
    "goodPass":" Good !",   
    "strongPass":" Robust !",   
    "samePassword":" Same as password... not good !",  
    
    "gender"  : "gender",
    "male" : "male", 
    "female" : "female",
    
    "locale"  : "Main language.",
    "fr_FR"  : "french",
    "en_GB"  : "english (UK)",
    "en_US"  : "english (USA)",
    "de_DE"  : "german",
    "nl_NL"  : "dutch",
    
    "user auth" : "Autentication", 
    "fb" : "Facebook",
    "auth type fb" : "Facebook",
    "auth type " : "local",
    "content via facebook" : "via Facebook", 
    "login_facebook" : "Use my Facebook account",
    "facebook login description" : "Use your Facebook account to log-in to this site",
    "or" : "or",  
    //"Error in FACEBOOK authentification" : "a erreur est survenue lors de l'autentification via Facebook.",
    
    "login_google" : "Use my Google account",
    
    // formulaire pour les categorys
    "cat title"  : "Name",
    "cat description"  : "category description",
    "cat upload picture" : "Picture(s)",
    "help cat title" : "category name ", 
    "desc cat type" : "Type of category", 
    
    "cattype_ad" : "for ads", 
    "cattype_user" : "for users",
    "cattype_" : "for all",  
    
    "help_on_cattype cattype_" : "This category can be used for users and ads", 
    "help_on_cattype cattype_user" : "This category can be used for users only", 
    "help_on_cattype cattype_ad" : "This category can be used for ads only", 
    
    // formulaire pour les zeTvu
    "<b>Je tai vu ...</b>" : "<b>I have seen you ...</b>",
    "zetvu title"  : "Intro",
    "zetvu desc"  : "Message",
    "zetvu location"  : "Where ?",
    
    // input de recherche : 
    "-- search through ads --" : "-- What, Where ? --", 
    "search" : "search", 
    
    // Formulaire de saisie de l'ad
    "ad title"  : "Title",
    "help title limited to 60 chars. Do not indicate buy of sell" : "60 chars max. Do not indicate sell or buy",
    "ad description"  : "Description",
    "ad categorie"  : "Category",
    "ad email"  : "Email",
    "ad sell or buy"  : "Type",
    "ad video embed" : "Video HTML code", 
    "ad video embed help" : "Entrer the HTML code from your video provider",
    "sell"  : "sell",
    "buy"  : "buy",
    "ad price"  : "Price",
    "$" : "(in $) :  set to 0 for free items. Indicate an estimated price if negociable",
    "€" : "(in €) :  set to 0 for free items. Indicate an estimated price if negociable",
    "ad upload picture" : "picture(s)",
    "ad upload image help %s" : 
    "You can add up to %s pictures. Max 500 ko per picture. Allowed extensions .jpeg, .jpg, .gif, .png",

    "cat upload picture help %s" : 
    "You can add up a picture which will be used for ads without a picture. Max 500 ko per picture. Allowed extensions .jpeg, .jpg, .gif, .png",

    "zetevu upload image help %s" : 
    "You can add up a picture. Max 500 ko per picture. Allowed extensions .jpeg, .jpg, .gif, .png",

    "ad details" : "Ad details",
    "ad contact me" : "Contact",
    "how to contact you for this ad" : "Contact me ?",
    "enable phone"  : "Phone",
    "show phone"  : "Phone",
    "show email"  : "Email",
    "show name"  : "Name",
    "ad help enusername" : "The name should be between 5 to 20 chars",
    "Show my email address together with this ad" : "show my email with the ad",
    "Show my name together with this ad" : "show my name with the ad",
    "display my phone number" : "show my phone number with the ad", 
    "Information on how to see it and get it" : "Location ? ", 
    "ad location and delivery": "Localization",
    "ad location": "Address",
    "help indicate for example a zip code or town" : 
    "format : [street,city,country] or [zipcode,country]. For auto-detection, leave this field blank",

      
    "help indicate format phone number" : "international phone number  :+country-code Number .Example : +1 0390671234",
    "Not the right file extension." : "Not the right file extension.", 
    "file size exceed limit." : "File size exceed limit.",
    "id of article owner" :"ID of owner", 
    "userid" : "user identification",  
    

    // title of Menu which are close to the input texts. 
    "post menu loc" : "Auto-detect your location", 
    "check this loc" : "Check this address ", 
    
    // informations affichées lors d'a modification
    "publishing state" : "Miscellaneous",
    "Publication status" : "Various information on your ad", 
    "ad pub date" :"Date", 
    "ad logs":"History", 
    "what" : "What?", 
    "whatid"  : "ID",
    "auth"  : "auth",
    "cron"  : "cron",
    "sec"  : "system",
    "daily"  : "daily",
    "weekl"  : "weekly",
    "severity" : "Sev.",
    "severity_0" :"-",
    "severity_1" :"Mid",
    "severity_2" :"High",
    "Only severity 0" :"Regular severity",
    "Only severity 1" :"mid severity",
    "Only severity 2" :"high severity",
    "-- select one severity --" : "-- filter per severity --",
    
    "-- select one action --" : "-- filter per type of log --",
    "Only Life-cycle" : "modification History", 
    "Only Auth" : "users connections", 
    "Only CRON" : "Automates/robots", 
    "Only SEC" : "System/security", 
     
    
    "I agree with the " : "I agree with the ", 
    "Terms and Conditions" : "Terms and Conditions", 
    
    "mandatory" : " * ",
    
    "upload picture" : "select a picture",
    
    // -------------------------------- END OF CHECKED TRANSLATION ----------------------------//

    "delete" : "delete",
    "submit" : "submit", 
    "cancel" : "cancel",
    "modify" : "modify",
    "edit" : "edit",
    "more actions" : "actions", 
    "no data found" : "No datas found", 
    
    "ad delete"  : "delete for life",
    "ad supress"  : "delete",
    
    // dialog button and content 
     "dialog cancel"  : "cancel",
     "dialog ok"  : "I confirm",
     "ad delete dialog title"  : "Delete a ad",
     "cat delete dialog title"  : "Delete a category",
     "user delete dialog title"  : "Delete un user",
     "profil delete dialog title"  : "Delete un user",
     "curuser delete dialog title"  : "Delete un user",

     "Confirm delete of ad :" : 
     "!! Warning, this action is definitive !!<br>Do you confirm deleting of ad : ",
     
     "Confirm delete of cat :" :
     "!! Warning, this action is definitive !!<br>Do you confirm deleting of category : ",
     
     "Confirm delete of user :" :      
     "!! Warning, this action is definitive !!<br>Do you confirm deleting of user : ",

     "Confirm delete of profil :" : 
     "!! Warning, this action is definitive !!<br>Do you confirm deleting of user : ",

     "Confirm delete of curuser :" : 
     "!! Warning, this action is definitive !!<br>Do you confirm deleting of user : ",
     
     // confirmation pour les logs 
     "Confirm deletion" : "Confirm deletion", 
     "Please confirm deletion of all logs entries with status :" : 
     "By clicking , <i>I confirm/i>, the logs below will all be deleted permanently.",
     
     "Action in progress ..." : "Update ongoing, please wait ...",
    // categorys 
    'select one categorie' : 'select one category',
    
    "-- select one reason --" : '-- select one reason --',
    "article sold though this site" : "article sold though this site",
    "article sold through another mean" : "article sold through another mean",
    "article no more available" : "article no more available",
    "auto" : "auto-deleting",
    "1_soldthru" : "Sold though this site", 
    "2_soldother" : "Sold through another mean", 
    "3_notavail" : "No more available", 
    
    "ad creation ongoing": "Ongoing creation of ad:",
    "zetvu creation ongoing": "Ongoing creation of ISeenYou :",
    "user creation ongoing": "Ongoing creation of user :",
    "cat creation ongoing": "Ongoing creation of category :",
    
    "(where?)" : "Localization ?", 
    
    "ad modification ongoing": "Ad modification ongoing :",
    "user modification ongoing": "User modification ongoing :",
    "curuser modification ongoing": "Profile modification ongoing :",
    "cat modification ongoing": "Category modification ongoing :",
    
    // erreurs sur les formulaires
    "You must select something." : "thanks to select semething.",
    "You must fill in something." : "thanks to enter a text.",
    "Incorrect format." : "incorrect format.", 
    "Incorrect rule." : "incorrect format.",
    "You must accept the Terms and conditions" : "You must accept the Terms and conditions",
    "Field does not match password" : "Field does not match password",
    "Text length exceeding limits." : "Text length exceeding limits.",
    "%s char remaining" : "%s char remaining",
    "%s chars remaining" : "%s chars remaining", 
    "%s chars max" : "%s chars max",
    "your must precise skills AND ratings." : "your must precise skills AND ratings.",
    
    // error in email formular
    "Incorrect email format" :  "Incorrect email format", 
    //"Incorrect SIRET number." :  "Incorrect SIRET number.", 
    "Incorrect SIRET number." :  "Incorrect VAT number. Must be BE0+9 chars", 

    // options payantes : 
    
    "ad payoptions" : "Upfront", 
    "post payoptions" : "Paid options to put upfront you ad! ", 
    "help payoptions" : "Paid options to put upfront you ad! ", 

    "desc putontopgallery" : "Featured", 
    "post putontopgallery" : "Featured for 7 days", 
    "help putontopgallery" : "Featured for 7 days", 
    
    "desc pushtotop7days" :  "Top of the list", 
    "post pushtotop7days" :  "Force to top of the list for 7 days", 
     "help pushtotop7days" :  "Force to top of the list for 7 days", 
    
    "desc specialcolor"  :  "Highlighting", 
    "post specialcolor"  :  "Highlight with a special color", 
     "help specialcolor"  :  "Highlight with a special color", 
    
    "desc addpics"  :  "More photos" , 
    "post addpics"  :  "more photos" , 
    "help addpics"  :  "more photos" , 

    "desc paidvideo"  :  "add a video", 
    "post paidvideo" : "add a video via the embedd HTML code", 
    "help paidvideo" : "add a video via the embedd HTML code", 

    "pushtop" : "push to top",
    "pushgal" : "put featured",  

    // texte des boutons du formulaire
    "BTN ad NOT CREATED": "send",
    "BTN ad DRAFT": "save as draft",
    "BTN ad DRAFT PENDING PAYMENT" : "checkout", 
    "BTN ad PREVIEW": "validate",
    "BTN ad UNDER REVIEW": "submit for publishing",
    "BTN ad PUBLISHED": "publish",
    "BTN ad UNPUBLISHED": "un-publish",
    "BTN ad DELETED": "delete",
    "BTN ad REJECTED": "reject",
    "BTN ad WILLEXPIRE": "force to expiration",
    
    "BTN cat NOT CREATED": "send",
    "BTN cat DRAFT": "save as draft",
    "BTN cat UNDER REVIEW": "submit",
    "BTN cat PUBLISHED": "publish",
    "BTN cat UNPUBLISHED": "un-publish",
    "BTN cat DELETED": "delete",
    "BTN cat REJECTED": "reject",
    "BTN cat WILLEXPIRE": "force to expiration",
    
    "BTN user NOT CREATED": "send",
    "BTN user DRAFT": "save as draft",
    "BTN user DRAFT PENDING PAYMENT" : "checkout", 
    "BTN user UNDER REVIEW": "submit for publishing",
    "BTN user PUBLISHED": "register",
    "BTN user PREVIEW": "validate",
    "BTN user UNPUBLISHED": "un-publish",
    "BTN user DELETED": "delete",
    "BTN user REJECTED": "Rejeter",
    "BTN user WILLEXPIRE": "force to expiration",
    
    "BTN curuser NOT CREATED": "Envoyer",
    "BTN curuser DRAFT": "save as draft",
    "BTN curuser UNDER REVIEW": "submit for publishing",
    "BTN curuser PUBLISHED": "Register",
    "BTN curuser UNPUBLISHED": "un-publish",
    "BTN curuser DELETED": "delete",
    "BTN curuser REJECTED": "Reject",
    "BTN curuser WILLEXPIRE": "force to expiration",
    
    
    "BTN zetvu NOT CREATED": "envoyer",
    "BTN zetvu DRAFT": "sauvegarder draft",
    "BTN zetvu UNDER REVIEW": "submit for publishing",
    "BTN zetvu PUBLISHED": "publish",
    "BTN zetvu UNPUBLISHED": "un-publish",
    "BTN zetvu DELETED": "delete",
    "BTN zetvu REJECTED": "reject",
    
    

    "REGISTERED": "Registered",
    "EDITOR": "Editor",
    "SUPER-ADMIN": "Super Admin",
    
    "formular already exists" : "Form is already open. Close it to continue.",
    
    // sidebar 
    "Browse all": "see all",
    "latest ZeTvu" : "Latest ISeenYou", 
    "latest Tweet" : "Tweets", 
 
    // sidebar buttons 
    "Subscribe" : "Subscribe",
    "subscribe feed by email": "subscribe to feed by email", 
    "subscribe feed": "subscribe to RSS feed ",
    "follow us on twitter": "follow us on Twitter",
    "follow us on facebook": "follow us on Facebook",
  
    // texte des Status possibles d'un article
    "NOT CREATED": "draft",
    "DRAFT": "draft",
    "DRAFT PENDING PAYMENT": "Payment pending",
    "DRAFT PAYMENT OK": "Payment done",
    "UNDER REVIEW": "under review",
    "under review" : "under review",
    "PUBLISHED": "published",
    "UNPUBLISHED": "un-published",
    "DELETED": "deleted",
    "REJECTED": "rejected",
    "WILLEXPIRE": "will expire",


    // short version for admin pages 
    "SHORT NOT CREATED": "00",
    "SHORT DRAFT": "draf",
    "SHORT DRAFT PENDING PAYMENT": "pay pend",
    "SHORT DRAFT PAYMENT CANCEL": "pay annul",
    "SHORT DRAFT PAYMENT OK": "payok",
    "SHORT UNDER REVIEW": "review",
    "SHORT under review" : "review",
    "SHORT PUBLISHED": "pub",
    "SHORT UNPUBLISHED": "un-pub",
    "SHORT DELETED": "supp",
    "SHORT REJECTED": "rejec",
    "SHORT WILLEXPIRE": "willexp",
    
    // test descriptifs des LOGS 
    "create": "create",
    "update": "update",
    "delete": "delete",
    "updatehit": "update hit",
    "updatestatus": "update status",
    "resethits" : "reset hits", 
    
    "desc": "description",
    "state": "state",
    "No entries in logs." : "No entries in logs.",
    "No entries in payments." : "No entries in payments.",
    
    "log_resethits" : "reset of hit counter", 
    "log_create_DRAFT": "created as draft",
    "log_payment_DRAFT PAYMENT OK": "payment OK", 
    "log_create_UNDER REVIEW": "created and submitted",
    "log_create_PUBLISHED": "published",
    "log_update_DRAFT" : "modification and saved as draft",
    "log_update_DRAFT PENDING PAYMENT" : "set pending payment",
    "log_update_UNDER REVIEW": "modification and re-submit",
    "log_update_PUBLISHED": "published",
    "log_updatestatus_PUBLISHED": "published",
    "log_update_DELETED": "deleted ",
    "log_updatestatus_UNDER REVIEW" : "Submitted for review",
    "log_updatestatus_DELETED": "Deleted ",
    "log_update_UNPUBLISHED": "un-published ",
    "log_update_REJECTED": "Rehected by editor",
    "log_update_WILLEXPIRE": "set to will-expire ",
    "log_delete" : "final deleting",
    "log_auth_Access granted , welcome !" : "access granted", 
    "log_auth_incorrect LOCAL  password  - please check" : "access denied - bad password",
    "log_auth_incorrect Login name" : "access denied - bad user name",
    
    //valeur des priorités 
    "pty_normal" : "Normal",
    "pty_top" : "featured ",
    "pty_permanent" : "Permanent",
    "pty_news" : "News",  
    "top" : "Featured",
    "most viewed" : "Most viewed",

    // paypal 
    "You have paid options for <b>%s %s </b>" : "You have paid options for a total amount of <b>%s %s </b>", 
    "Payment successful": "Payment successful!", 
    "Thanks you for your payment ! Your ad will now be submitted for approval." : "Thanks you for your payment ! Your ad will now be submitted for approval.", 
    "Payment cancelled" : "Payment cancelled !", 
    "Your payment is cancelled. You can retrieve your ad into your dashboard." : "Your payment is cancelled. You can retrieve your ad into your dashboard.",
    "Paypal redirection ongoing" : "Paypal redirection ongoing ...", 
    "You will be redirected to paypal for finalizing payment." : "You will be redirected to paypal for finalizing payment.", 
    "Payment finalization"  : "Payment finalization ...", 
    "Thanks you for your payment ! We are updating your order, please wait." : "Thanks you for your payment ! We are updating your order, please wait.", 
    "paypal - This transaction does not exist or has already been processed" : "Sorry - This transaction does not exist or has already been processed",
    "paypal payment sucessfull" : "Payment sucessfull",     

    // champs du log des paiements
    "paymentdate" : "date", 
    "amt" : "amount", 
    "paymentstatus" : "status",
    "transactionid" : "transaction id",  

    // type comptes utilisateurs
    "protype_pri" : "Private",
    "protype_pub" : "Public",
    "protype_pro" : "Pro",
    "protype" : "Account",
    "private" : "Private",
    "public" : "Public", 
    "pro" : "Professionnal",
    "par" : "Particulier", 
    "help_protype" : 
    "A private account is only visible for you. A public or pro. account is displayed for all users.",
    
    "desc_indir" : "In directory", 
    "help_indir" : "you willbe visible into the directory public part of the site ", 
    "desc_account_type" :"Account type", 

     // ads relatives :
    "related ads " :  "ads ", 

    // actions
    "delete all auth logs" : "Delete all logs AUTHentication", 
    "delete all cron logs": "Delete all logs ROBOTS", 
    "delete all sec logs" : "Delete all logs SYSTEMS", 
    "batch actions" : "bulk actions >>",
    "help_logs_batch_actions_menu" :"Display the bulk modification menu.",
    "help_delete_logs_auth" : "This action delete all logs with  type  = authentication",
    "help_delete_logs_cron" :"This action delete all logs with  type  = cron",
    "help_delete_logs_sec" : "This action delete all logs with  type  = system",    
    
    // ecran de detail d'un article 
    "ad id" : "Ad number ",
    "ad status" : "Status ",
    "ad priority" : "Priority ",
    "ad moddate" : "modified by ",
    "ad publiched the" : "the",
    "ad hits" : "hit(s) ",
    "ad vendor info" : "Author",
    "ad info" : "Details",
    "ad actions" : "Actions",
    "ad admin" : "Manage ",
    "ad qr code" : "Retrieve this ad",
    "ad edit" : "edit",
    "ad reset hits" : "reset the hit(s) counter", 
    "ad savefav" : "add to favorites",
    "ad twitter" : "share on Twitter",
    "Share" : "share ... ",
    "more ... »" : "more ... »",
    "share on twitter" : "share on Twitter",
    "share on facebook" : "share on Facebook",
    "share on Linkedin" : "share on Linkedin",
    "share on Google+" : "share on Google+",
    "clip to Evernote" : "capture on Evernote",
    "bookmark this on Delicious" : "Link on Delicious",
    "ad facebook" : "share on Facebook",
    "One article of interest" : "One article of interest",
    "ad del savefav" : "remove from favorites",
    "ad email it" : "send by email",
    "ad print" : "print",
    "ad flag it abuse" : "flag this",
    /*
    "previous ad" : "précédent",
    "next ad" : "suivant",
    "next" : "suivant",
    "previous" : "précédent",
    */
    "previous ad" : "<",
    "next ad" : ">",
    "next" : ">",
    "previous" : "<",
    
    "elem logs": "History", 
    "Display elem logs": "display history", 
    

    "free" : "free",
    "more if registered" : "login for more",
    "Send a messge to the seller" : "Send a message to the seller",
    "Contact the user through the website" : "Connect through the site", 
    "send email" : "Send a message ",
    "call number" : "Call this numéro",
      
    // help on buttons : 
      "title clip to Evernote" : "Clip it into Evernote",
      
    // login form title
    "You must be registered" : "You must be logged in for this action",
    "Login form title" : "Autentication",
    "login form introduction": "Autenticate yourself to access this site ",
    "register introduction": "If you are not already registered ",
    "login_register": "register here ",
    "login_lostpassword": "Forgot password ? ",
    "email address not known" : "Unknown email address", 
    "login": "login",
    "login name" : "user name",
    "login email" : "Email",
    "login_rememberme" : "remember me",
    "submit login" : "login",
    "logout": "Logout",
    "welcome %s": "welcome <strong>%s</strong> ",
    "profil": "my profile",
    "Access granted , welcome !" : "Access granted , Welcome !", 
    "Correctly logout and cookies deleted" : "You are now logged out and all cookies are deleted.",
    "incorrect LOCAL  password  - please check" : "Error in autentication : incorrect password.",
    "incorrect Login name" : "Error in autentication : Unknown username.",
    "Register": "register",
    "Login in progress ..." : "Identification ongoing ...",
    "Loading in progress ..." : "Loading ...",
    
    // leaflet special texts
    "leaflet footer text"  : "This ad has been created, printed and available from ", 
    "Select the main picture, click <a id='print' href='#'>here</a> to print and clip along the line": 
    "Select the pictures to display, <a id='print' href='#'>print it</a> and and clip along the line",
    "ad leaflet print" :"Print leafler", // important sans espace pour IE 
    
    // email form title
    "email lost form title" : "Reset password", 
    "email support form title" : "Contact us", 
    "email feedback form title" : "Notify an issue", 
    "email remind form title" : "Remind me this message", 
    "email contact form title" : "Contact the seller", 
    "email abuse form title" : "Notify abuse", 
    "email contactuser form title" :  "Send a message to this user",
    
    "email lost form introduction" : 
    "Enter your email address. A new password will be sent to this address.", 
    
    "email support form introduction" : 
    "Use this form to contact us on all requests",

    "email feedback form introduction" : 
    "Use this form to give a feedback on missing functionalities or improvements.",

    "email abuse form introduction" : 
    "Use this form to notify us about an illicit content.",

    "email contact form introduction" : 
    "Use this form to contact a given seller on a given ad.", 

    "email remind form introduction" : 
    "Use this form to send me a reminder of this ad", 

    "email contactuser form introduction" : 
    "Use this form to contact a given user.",
    
    "your email" : "Your email", 
    "email title" : "Title", 
    "email description" : "Details", 
    
    "submit lost email" : "Reset", 
    "submit support email" : "send the message",
    "submit feedback email" : "send the request",  
    "submit abuse email" : "send the message",
    "submit contact email" : "send the message",  
    "submit remind email" : "send the message", 
    "submit contactuser email" : "send the message",  
    
    "Confirm modification" : "Confirm your modification ? ", 
    "Please confirm modification to status 40 of :" : 
    "By clicking, <i>I confirm</i>, this ad will be published. You can also send a message to the administrator at the ame time.",
    
    "Please confirm modification to status 90 of :" :     
    "By clicking, <i>I confirm</i>, the below ad will be rejected. Please indicate the reason which will be notified to the owner by email.",

    "Please confirm modification to status 80 of :" : 
    "By clicking, <i>I confirm</i>, the below ad will definitively deleted.",

    
    "your message": "Your message", 
    "Why ?": "Why ?",


    "Mysage sending in progress" : "Sending message ...", 
    "Mysage sucessufully sent !" : "Mysage sent sucessufully!",
    
    "This operation is not authorized !" :  "This operation is not authorized !", 
    "You have exceeded the commercial limits : MAX AD" :  
        "You have exceeded the commercial limits (MAX number of ads), please contact the site administrator.",

    "You are not authorised to access this section. You have been redirected to home page." : 
        "You are not authorised to access this section. You have been redirected to home page.", 

    "Login in progress" : "Login in progress ...", 
    "Error in Login form" : "Error in Login form",
    "incorrect Login/password" : "incorrect Login/password",
    "Your acount is created, please login to connect : ": "Your account is created, please login to connect :",
    "Congratulation !" : "Congratulation !", 
    
    "ZADS, I want to have more information on element :" : "I would like more information on : ",  
    "ZADS, I want to have more information" : "I would like more information on ...",
    "ZADS, I want to have more information" : "More information on  ?",
    
    "user vendor info" : "Main information",
    "user actions" : "Tools",
    "user info" : "Misc",
    "user id" : "ID",
    "user status" : "Status",
    "user type" : "Rights",
    "user register date" : "Created by",
    "user last visit date" : "Last visit",
    "ad registration date" : "Created by",
    "ad modification date" : "Modified by",
    
    "contact him" : "contact ",
    "Send him a message" : "Send a message",
    
    "user savefav" : "+ to favorites",
    "user email it" : "send by email",
    "user print" : "print",
    "user flag it abuse" : "abuse notification",
    
    "hits : %s times" : " %s hit(s)", 
      
    // modal box
    "modbox close" : "close",
    "info" : "Information",
    "error" : "Error",
    "success" : "Successful operation",
    "Server request timeout" : "Sorry, server is not responding.",
    
    // messages 
    "Action not yet available": "Action not yet available. Sorry !",
    "Yay! Everything went well!" : "Yay! Everything went well!",
    "ok ad under review" : 
        "We have received your request. it will be published after acceptance by the review commitee.",

    "ok ad deleted" : 
        "Your ad is deleted from site. However, you can reactiva it for 80 days if you change your mind.",

    "ok ad published" : 
        "Congratulation ! Your ad is now published and will remain visible for 30 days.",


    "ok user registered" : 
        "Votre access is now created and valid. Please login to acces the site.",

    "error in form checking" : 
        "The form is incompleted, thanks to verify and correct fields marked in red.",


    "Doh! Something happened : A user with this email already exist." : 
        "This email address is already in use. Thanks to select another one.",

    "Doh! Something happened : This username is not available.": 
        "this username is no more available. Thanks to select another one.",

    // main menu
    "containing <b>%s</b> word" : "containing <span class='highlight'>%s</span>",
 
    //user menu 
    "create ad" : "Post an ad", 
    "create zetvu" : "Post a ISeenYou", 
    "admin (dashboard)" : "Administration", 
    
    // geolocatization 
    "Geo-localization successful" : "Geo-localization successful : ", 
    "Selected Geo-localization successful" :  "Selected Geo-localization successful : ", 
    "Geo-localization failed" : "Geo-localization failed : ",
    "Geoloc not available in your navigator" : "Geoloc not available with your browser.",
    "Geo-localization time-out" :"Geo-localization : server time-out",
    "Geo-localization permission denied":"Geo-localization :  permission denied",
    "Geo-localization position unavailable":"Geo-localization : your position is unavailable",
    "Goecoding error : "  : "Goecoding error : ", 
    "your location" : "Your location",
    "Geo-localization in progress":"Geo-localization in progress ...",
    "Geo-localization error"  : "Geo-localization error",
    "Geo-localization can move marker to select other":"Geo-localization can move marker to select other ",
    "Release the Marker to the desired address" : "... Release the Marker to the desired address.", 
    "getting address...":"getting address..",
    "Error in Google Map loading. Check your internet connection." : "Error in Google Map loading. Check your internet connection.",
    "list view" : "", 
    "Sort by:" : "Sort by:",
    "Most recent" : "Most recent",
    "Lowest price" : "Lowest price",
    "Highest price" : "Highest price",
    "Highest hits": "Highest hits",
    "Sort by price desc" : "Sort by price descending",
    "Sort by price asc" : "Sort by price ascending",
    "Sort by date desc" : "Sort by date",
    "Sort by hits desc" : "Sort by hits",
    "Sort by name asc" : "Sort by name A to Z",
    "Sort by ad nb desc" : "Sort by ad number descending",
    "Sort by whatid desc" : "Sort by  par IDs descending",
    "Sort by what desc" : "Sort by type",
    
    "By " : "By ",
    "previous page" : "previous page",
    "next page" : "next page",
    "help prev" : "previous page",
    "help next" : "next page",
    
    "Ads <b>%s</b> to <b>%s</b> of <b>%s</b> ads" : "( <b>%s</b> to <b>%s</b> / <b>%s</b>)",
    "<b>%s</b>-<b>%s</b> of <b>%s</b>" : "<b>%s</b>-<b>%s</b> out of <b>%s</b>",
    
    "Back" : "back", 

    // sub-menu 
    "myads" : "My ads",
    "my_ad" : "My ads",
    "myadmin" : "My admin",
    "my_admin" : "My admin",
    "admin" : "Administration",
    
    "allads" : "All ads",
    "all ad" : "All ads",
    "admin_ad" : "All ads",
    "admin_user" : "All users",
    "allusers" : "All users",
    "admin_all" :"",
    
    "all logs" : "All logs entries",
    "all payments" : "All payments",
    "all status" : "all status",
    "manageother" : "Other ",
    "all cat" : "All categories",
    "all user" : "all users",
    "all admin_user" : "all users",
    "all admin_cat" : "All categories",
    
    "dashboard" : "Dashboard",
    "dash no data" : "no data",
    "mydashboard" : "My dashboard",
    "user" : "users",
    "cat" : "category", 
    "ad" : "ad", 
    "all myads" : "My ads",
    "all my_ad" : "All my ads",
    "all admin_ad" : "All ads",
    "myads_published" : "Published",
    "myads_all" : "All",
    "myads_pending" : "Pending",
    "myads_draft" : "Draft",
    "myads_draftpendingpayment" : "Payment pending",
    "myads_deleted" : "Expired",
    "published" : "published",
    "pending" : "pending",
    "willexpire" : "will expire",
    "draft" : "drafts",
    "draft pending payment" : "Payment pending", 
    "deleted_expired" : "expired",
    "deleted" : "expired",
    "ads_published" : "ads",
    "ads_draft" : "drafts",
    "admin_pending" : "pending",
    "admin_willexpire" : "Will expire",
    "admin_expired" : "Expired",
    "admin_deleted" : "Expired",
    "admin_published" : "Ads",
    "admin_draft" : "Drafts",
    "admin_pending" : "To validate",
    "admin_draftpendingpayment" : "Payment pending",
    "admin_draft pending payment" : "Payment pending", 
    "admin_willexpire" : "Will expire",
    "admin_expired" : "Expired",
    "admin_rejected" : "Rejected",
    "admin_under review" : "under review",
    "admin_user_draftpendingpayment" : "Payment pending",
    "myprofile" : "My profile",
    "myfav" : "My favorites",
    "manage_settings" : "Options",
    "manage_ads" : "ads (all)",
    "manage_users" : "users",
    "manage_cats" : "categories",
    "manage_twitter" : "Tweeter",
    "manage_logs" : "logs",
    "manage_payments" : "payment logs",
    
    "category":"categories",
    
    // tooltips 
    "Show List" : "Show as list with photos",
    "Show Gallery" : "Show as photo galleries",
    "Show simple List" : "Show as simple list",
    "Show map List" : "Show on a map",
    "help_on_status DRAFT" : "This elements is rdaft and not published",
    "help_on_status DRAFT PENDING PAYMENT" : "This elements is waiting payment",
    "help_on_status PUBLISHED" : "This element is published",
    "help_on_status UNDER REVIEW" : "This element is waiting valiation from editor",
    "help_on_status UNPUBLISHED" : "This element is removed from publication",
    "help_on_status REJECTED" : "this element has been rejected",
    "help_on_status DELETED" : "This elements is expired and will be deleted by  ",
    "help_on_status WILLEXPIRE" : "This element will expire ",
    "help_on_status pty_top" : "This element is a featured item",
    
    "help_on_status protype_pub" : "This account is public and visible for all",
    "help_on_status protype_pri" : "This account is private and only visible for owner",
    "help_on_status protype_pro" : "This account is Professionnal and visible for all",
    
    "view all" : "View all",
    "help link Main List" : "Back to initial list",

    "help password rules" : 
        "A good massword contains letters and chars and is different from username, email and password. Stick to the hints !",
    
    "help_myads_published" : "My ads published",
    "help_myads_all" : "All my ads",
    "help_myads_pending" : "My ads waiting approval",
    "help_myads_draft" : "My ads in draft or rejected",
    "help_myads_draftpendingpayment" : "My ads awaiting payment",
    "help_myads_deleted" : "My ads expired or deleted",
    "help_myprofile" : "See my profile",
    "help_myfav" : "See my favorite ads",
    "help_admin_pending" : "Ads to approve",
    "help_admin_willexpire" : "Ads which will expire",
    "help_admin_expired" : "Ads expired or deleted",
    "help_admin_deleted" : "Ads expired or deleted",
    "help_admin_draftpendingpayment" : "Ads awaiting payment",
    "help_admin_user_draftpendingpayment" : "Accounts awaiting payment",
    "help_manage_settings" : "Site settings",
    "help_manage_ads" : "all les ads dans all les états",
    "help_manage_cats" : "Manage categories",
    "help_manage_users" : "Manage users",
    "help_manage_twitter" : "Send Tweets directly",
    "help_dashboard" : "Display admin dashboard",
    "help_mydashboard" : "Display my dashboard",
    "help_manage_logs" : "Display logs",
    "help_manage_payments" : "Display received payments",


    "Sorry !":"Sorry !", 
    "No items found" : "No element found corresponding to your request. Some request need to be registered.",
    "No items found - No ad" : "No items found - No ads", 
    
    //tweeter
    "What are you doing?" : "What's new ?",
    "twitter header" : ": Tweet directly from ZADS",
    "Loading your tweets..." : "Loading your tweets...",
    "Timeline" : "Timeline",
    
    // global home page messages 
    "You have %s article(s) waiting for your approval" : "You have %s article(s) waiting for your approval : ", 

    "access here" : "access here",   
    
    // templates
    "some text"  : "a traduction de patrice  from patrice",
    "some more text"  : "another translation",
    "some text in french":"avec des é et des è",
    '%s text in french %s' : '%s exemple avec printf %s', 
    '%s text in french' : '%s exemple avec printf simple', 
    '%s comment' : '%s comment',
    '%s comments' : '%s comments', 
    'text in french' : 'texte en francais',
    
    // dashboard 
    'adsnb' : 'number',
    '%adsnb' : '%',
    'val' : 'number',
    '%val' : '%',
    'metrics' : 'number',
    '%metrics' : '%',
    'nb' : 'number',
    'nbusers' : 'number',
    '%nbusers' : '%',
    'cattitle' : 'category',
    'status' : 'status',
    'others' : 'others',
    
    "dash manage ads" : "(manage)", 
    "dash manage users" : "(manage)",
    "dash manage cats" : "(manage)",
    "cumul users"  : "# users (cumul)",
    
    "a10": "draft",
    "a20": "review ongoing",
    "a40": "published",
    "a60": "re-work",
    "a80": "ssuppressed",
    "a90": "rejeté(e)",
    "a45": "will expire",
    
    'fb' : 'Facebook',
    
    'stat dashboard title' : 'Dashboard (Admin)', 
    'stat mydashboard title' : 'My dashboard', 
    
    'top_dashboard' : 'Overview', 
    'ad_vol_per_cat' : 'Ads per category', 
    'ad_vol_per_type' : 'Ads per type', 
    'ad_vol_per_time' : 'Ads timeline', 
    'ad_vol_per_delete' : 'Cause of ad suppression',
    
    'ad_vol_per_status' : 'Ads per publiching status', 
    'user_vol_per_time' : 'User timeline', 
    'user_vol_per_age' : 'Users per age', 
    'ad_vol_per_age' : 'Ads per age', 
    'user_vol_per_type' : "Users per autentication method",
    'user_vol_per_protype' : "Users per profiles",  
    'ad_vol_per_user' : 'ads per user', 
    
    'Observation period : ' : 'Period : ', 
    'all' : 'all', 
    'thisyear' : 'this year', 
    'thismonth' : 'this month',
    'thisquarter' : 'this quarter',


    // footer translation 
    "A propos de ZADS" : "About", 
    "ZADS est une plateforme d'échange d'annonces entre particuliers dans un domaine privé comme une entrepsie ou une collectivité." :
        "ZADS is a classidied ads platform available in hosted or in script mode to enable community to exchange product and services", 

    "En savoir plus" : "Find our more", 
    "S'abonner": "Subsribe", 
    "Annonces par email":"Ads by email",    
    "Offres et Demandes" : "Sell and Buy", 
    "Aide et Support" : "Help and support", 


    "Aide et Support" : "Help and Support", 
    "Questions Frequentes (FAQ)" :"F.A.Q", 
    "Tutoriels et démos" :"Demo and Tutorials", 
    "Signaler un probléme":"Notify us on an issue", 
    "Suivre / Contact" : "Follow / Contact",
    "suivre ZADS.FR sur Twitter"  : "Follow us on Twitter", 
    "suivre ZADS.FR sur Facebook"  : "Follow us on Facebook", 


    "Me contacter" : "Contact us", 
    "A propos" : "About this", 
    "Infos légales et CGU"  : "Terms and Conditions", 
    "Publicité" : "Advertising",
    "Nous contacter" : "Contact us",
    "Aide" :  "Help", 
    "F.A.Q" :  "F.A.Q", 

    // new ZADS 4.6
    "around me :": "around me :", 
    ":unknown":":unknown", 
    "(change)" : "(change)",
    "(locate me)" :"(locate me)", 


    "display failed" : "Erreur", 
    "Doh! Something happened : no authorized - private profile" : "Doh! Something happened : no authorized.", 

    "post paidaccount" : "Service cost (price per year)  : ", 
    "help_protype_paid" : "Account to access the service. valid for 1 year. refers to terms and conditions",

    "Process ongoing ..." : "Process ongoing, please wait ...", 


    // banners management 
    "title" :"Title",
    "htmlcode": "HTML code",
    "clicktrackingurl": "Clicktracking URL", 
    "startdate": "Start Date", 
    "enddate": "End Date", 
    "position": "Position", 
    "clicks": "Clicks", 
    "impressions": "Print.", 
    "CTR": "CTR", 
    "resetclicks" : "Reset clicks and print counters",

    "desc_banner_title" :"Title",
    "desc_banner_htmlcode": "HTML code",
    "desc_banner_clicktrackingurl": "Clicktracking URL", 
    "desc_banner_startdate": "Start Date", 
    "desc_banner_enddate": "End Date", 
    "desc_banner_position": "Position", 
    "desc_banner_clicks": "Clicks", 
    "desc_banner_impressions": "Prints", 
    "desc_banner_CTR": "CTR", 

    "help_banner_title" :"Title of the banner to help you identifying it",
    "help_banner_htmlcode": "HTML code of the banner. Javascript is not supported yet. For Full background banner, just indocate the URL of the image",
    "help_banner_clicktrackingurl": "URL wich will redirect users clicking on this banner", 
    "help_banner_startdate": "Start date of publishing", 
    "help_banner_enddate": "End date of publishing", 
    "help_banner_position": "Position of the banner onto the site", 
    "help_banner_clicks": "Number of clicks received by this banner", 
    "help_banner_impressions": "Number of print/diplay of this banner", 
    "help_banner_CTR": "CTR =  Click Trhough Ratio  =  number of clicks / number of print",

    "add banner" :"ad a commercial banner",  
    "all banners" : "All the banners", 
    "manage_banners" : "Manage Banners",
    "help_manage_banners" : "Manage Banners",

    "Banner reset clicks confirmation" :"Confirmation of reset",
    "Banner reset clicks content" : "Confirmation of reset of clicks and prints metrics", 
    "Banner delete confirmation" : "Confirmation of definitive deleting",  

    " banner form header title" : "Creation of an advertising banner",
    " banner form header introduction" :"Below, create your advertising banner",
    "modify banner form header title" : "Modification f an advertising banner",
    "modify banner form header introduction" :"Below, modify your advertising banner",


    // extended contact form
    "contact reason" : "Request", 
    "procpny": "Company", 
    "to email" :"Destinator",

    '-- select one --' : '-- select one --',
    "Subscription" : "Subscription", 
    "Advertising" : "Advertising", 
    "Information" :"Information", 
    "Support" :"Support", 
    "Other" : "Other", 

    "Account fee is <b>%s %s </b> per year" : "Service is charged <b>%s %s</b> per year", 

    "Please validate the location" : "Thanks to Validate this location",

    "top register user" : "Subscribe", 

    // new zads 4.8 : 
    "show all" : "Sell all ads", 
    "Sort by hierarchy" : "Sort by Hierarchy",
    "desc_parentid" : "Parent Cat.", 
    "help_parentid" : "If you want to have two levels of categories, selectbelow the parent category.", 
    "cat order plus" : "Increase the rank of appearance",
    "cat order minus" : "Decrease  the rank of appearance",

    "pub users" : "Other users", 
    "Main list" : "Back to main list ", 

    // place to translate catégories 
    "Categorie initial" : "EXAMPLE OF NAME OF TRANSLATED CATEGORY", 




         // ----------  new zads 4.9 : 

    "us_protype" : "Type usager",
    "us_skills"  : "Catégorie (s)",
    "us_avatarimg"  : "Logo",
    "us_bio"  : "Courte présentation",
    "us_longdesc"  : "Longue présentation",
    "us_folioimg"  : "Galerie photos",
    "us_videoembed"  : "Lien Video",
    "us_phone" : "Téléphone",
    "us_dispemail" : "E-mail",
    "us_subscription" : "jours accès",
    "us_prowebsite" : "URL site",
    "us_links" : "Liens usager",
    "ad_nb" : "annonces",
    "ad_nbpics" : "images",
    "ad_duration" : "",
    "ad_featured" : "",
    "ad_perm" : "",
    "ca_restricted" : "",
    "ad_videoembed" : "Lien Video", 
    "ad_links": "Liens An.", 
    "ad_enemail":"Contact E-mail", 
    "ad_enphone":"contact Tél.", 


    "settings_v" : "visible", 
    "settings_us_protype" : "Annuaire pro",
    "settings_us_skills"  : "Catégorie (s)",
    "settings_us_avatarimg"  : "Logo",
    "settings_us_bio"  : "Courte présentation",
    "settings_us_longdesc"  : "Longue présentation",
    "settings_us_folioimg"  : "Galerie photos",
    "settings_us_videoembed"  : "Lien Video",
    "settings_us_phone" : "Téléphone",
    "settings_us_dispemail" : "E-mail",
    "settings_us_subscription" : "Jours accès",
    "settings_ad_nb" : "Max annonces",
    "settings_ad_nbpics" : "Max images par annonce",
    "settings_ad_duration" : "",
    "settings_ad_featured" : "",
    "settings_ad_perm" : "",
    "settings_ca_restricted" : "",
    "settings_ad_videoembed" : "Lien Video", 
    "settings_ad_links": "Max liens", 
    "settings_ad_enemail":"Contact E-mail", 
    "settings_ad_enphone":"contact Tél.", 
    "settings_ad_duration":"Durée (jours) de l'annonce", 
    "settings_ad_duration":"*** ne pas utiliser ***", 
    "settings_ad_nbvideos" : "Max videos (embed)", 
    "settings_ad_urgent" : "Forcée URGENTE", 
    "settings_ad_featured":"Forcée A LA UNE",
    "settings_ad_perm":"Forcée PERMANENTE",

    // Z6.1.2 - temporary removed as no actions yet seesettings
    "settings_ad_urgent" : "*** ne pas utiliser ***", 
    "settings_ad_featured":"*** ne pas utiliser ***",
    "settings_ad_perm":"*** ne pas utiliser ***",


    "settings_us_social":"** do not use **",
    "settings_us_links":"Max liens",
    "settings_us_prowebsite" : "Site web pro", 
    "settings_ca_restriction" : "Uniquement Cat. ID",

    "settings_duration" : "Durée (jours)",
    "settings_bgcolor" : "CSS color",
    "settings_type" : "Type",
    "settings_xtype" : "XType",

    "settings_radio_base" : "Base", 
    "settings_radio_trial" : "Trial", 
    "settings_radio_" : "Service", 

    "settings_default" : "Par défaut",
    "settings_pricedesc" : "Description (prix)", 
    "settings_name" : "Nom", 
    "settings_payoption" : "Reference Cat.",
    "settings_price_type" : "Structure", 
    "settings_radio_flat" : "Unique", 
    "settings_radio_volume" : "Volume",
    "settings_ad_details" : "Contenu du pack (annonces)", 
    "settings_us_details" : "Contenu du pack (compte)",
    "settings_prices_details" : "Structure de prix",  
    "settings_n" : "Prix ID",
    "settings_ttc" : "Prix (TTC)",
    "settings_ht" : "Prix (HT)",
    "sign up" : "Signer pour ce plan",
    
    "plans_faq_1_question" : "Lorem ipsum dolor sit amet, consectetur",
    "plans_faq_1_response" : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras commodo nec elit nec sollicitudin. Aenean rutrum, magna a venenatis lobortis, lacus nisi tristique est, id euismod ante dolor vel orci. Quisque porttitor augue at fermentum ultricies.",

    "plans_faq_2_question" : "Lorem ipsum dolor sit amet, consectetur",
    "plans_faq_2_response" : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras commodo nec elit nec sollicitudin. Aenean rutrum, magna a venenatis lobortis, lacus nisi tristique est, id euismod ante dolor vel orci. Quisque porttitor augue at fermentum ultricies.",


    // nouvelles entrése du formulaire 
    "desc_label_plan" : "Type of subscription", 
    "desc_plan" : "Subscription" ,
    "you selected the  plan  : " : "You selected the subscription plan : ", 
    "help_plan" : "This is the type of subscription you have signed for", 
    "desc_longdesc" :"Long presentation",

    "longdesc" : "Long presentation",
    "videoembed" : "Video presentation",

    // enhancements of zads 4.9
    "See details of this user" : "See details of this user", 
    "See all ads from this seller" : "See all ads from this user", 
    "See all ads" : "All ads",

    // pricing type 
    "desc_pricetype" : "Price (others)", 
    "help_pricetype" : "indicate other pricing model you propose", 
    "price" : "Fixed price",
    "to be discussed" : "to be discussed",
    "make an offer" : "Make offer",
    "on quote" : "on quote",
    "model dependant" : "Model dependant",

    "pricetype_tbdi" : "to be discussed",
    "pricetype_mano" : "make offer",
    "pricetype_onqo" : "on quote",
    "pricetype_mode" : "model dep.",

    "ad videoembed" : "Video", 
    //"(read more)" : "(lire la suite)",

    //"Ad creation forbidden from your current profile.": "La création d'annonces n'est pas autorisée avec cet abonnement.", 
    //"You have exceeded quota of ad." : "La création d'annonce n'est pas possible car vous avez dépassé les limites de votre abonnement.",

    // location based 
    "loccity" : "City", 
    "locdept" :"Department", 
    "locregion" : "Region",

    // traductions pour plan princing (customer specific)
    // SELECT INPUT 
    //"-- no plan -- " : "-- pas d'abonnement spécifique --", 
    //"options_Basic" : "Abonnement Basic", 
    //"options_Premium" : "Abonnement Premium", 
    //"options_Pro" : "Abonnement Pro", 

    "more cat" : "... more ...", 
    "less cat" : "... less ...",


    // zads @4.9.2
    "edit my profile" : "Edit my profile", 


    // zads@4.9.5
    "a45": "Will expire",
    "a15" : "payment pending", 
    // -- payment logs
    // "<b>%s</b> payment(s) - total amount = <b>%s</b> %s" : "<b>%s</b> paiement(s) pour un montant de = <b>%s</b> %s", 
  
    "-- select what --" : "-- All payments type --",
    "Only Ads" :  "Paid options", 
    "Only Users" : "Paid subscriptions",
    "Only Services" : "Paid services",

    // zads@4.9.7
    "Map home page  - first paragraph" : " ",
    "Map home page  - last paragraph" :  " " ,

    // "user links" : "Liens Web(s)", 
    " add_links" : " add a link", 
    "url title placeholder" : "Link title",
    "url placeholder" : "http:// or www.monsite.com",
    // "save this link" : "sauvegarder ce lien", 
    // "link title" : "titre", 
    // "link url" :"url", 
    // "Incorrect URL format." : "format de l'url incorrect",
    // "remove this link" : "retirer ce lien", 
    "help_links (%s max)" :  "add external links up to %s links", 
    "settings" : "Settings",

    " settings form header title" : "Settings manager",
    // " settings form header introduction" : "A travers ces formulaires, gérer l'apparence et la configuration générale du site. Attention, certaines actions pourraient endommager le site. Veuillez consulter la documentation technique avant toute manipulation.",
    "BTN settings PUBLISHED" : "Save the settings",
    "Settings updated successfully" : "Settings saved !", 
    "settings creation ongoing" : "Saving settings ...", 

    "settings_menu_site_details" : "Details",
    "settings_menu_general" : "Details",
    "settings_menu_site_pages" : "Pages",
    "settings_menu_sitepages" : "Pages",
    "settings_menu_site_metas" : "Metas/SEO",
    "settings_menu_general2" : "Metas/SEO",
    "settings_menu_site_layout" : "Thème/Disposition",
    "settings_menu_layout" : "Thème/Disposition",
    "settings_menu_life_cycle" : "Cycle de vie",
    "settings_menu_lifecycle" : "Cycle de vie",
    "settings_menu_emails" : "Emails",
    "settings_menu_social" : "Social",
    "settings_menu_security" : "Securité",
    "settings_menu_site_locale" : "Locale",
    "settings_menu_locale" : "Locale",
    "settings_menu_others" : "Autre (SEO, HEADER)",
    "settings_menu_site_links" : "Liens",
    "settings_menu_links" : "Liens",
    "settings_menu_superadmin" : "Options Avancées",
    "settings_menu_site_badwords" : "Mots interdits",
    "settings_menu_badwords" : "Mots interdits",
    "settings_menu_site_theme" : "Theme",
    "settings_menu_theme" : "Theme",
    "settings_menu_fields" : "Champs",
    "settings_menu_multitenant" : "Multitenants",
    "settings_menu_site_nav" : "Nav/Recherche",
    "settings_menu_mainnav" : "Nav/Recherche",

    "desc_settings" : "Configuration", 
    "desc_settings_path" : "Variante (path)", 
    "help_settings_path" : "Variante (path) : chemin indiquant ou les paramétres de tenant sont stockés.Si vide, utilise le chemin par défaut = 'settings/' ", 

    "desc_domain_fqdn" : "Nom de Domaine FQDN",
    "desc_domain_fqdn_short" : "FQDN court (pour SEO)",
    "desc_logo_fqdn" : "Emails logo (url)",
    "desc_logo_paypal_fqdn" : "PAYPAL Logo (url) ",
    "desc_site_name" : "Nom du site",
    "desc_site_motto" : "Devise du site",
    "desc_site_customer" : "Nom du client",


    "help_domain_fqdn" : "Nom de Domaine FQDN : exemple http://www.monsite.com/ - Attention ne pas oublier le / à la fin ! ",
    "help_domain_fqdn_short" : "nom de domaine court utilisé pour le référencement",
    "help_logo_fqdn" : "Url du logo utilisé puor les notifications par emails",
    "help_logo_paypal_fqdn" : "Url (ABSOLUE !!!) du logo affiché dans PAYPAL lors du paiement. Taille max: largeur=90 px/ hauteur=60 px en .gif, .jpg, or .png.",
    "help_site_name" : "Nom du site (pour les emails)",
    "help_site_motto" : "Devise du site (pour les emails)",
    "help_site_customer" : "Nom du client (pour les emails)",

    "desc_cust_site_name" : "Nom du site",
    "desc_cust_site_motto" : "Devise du site",
    "desc_cust_site_owner_accronym" : "Propriétaire",
    "desc_cust_site_owner_long" : "Nom Long proprio.",
    "desc_cust_loading_msg" : "Message chargement",
    "desc_cust_title" : "Titre (meta) ",
    "desc_cust_description" : "Description (meta)",
    "desc_cust_about_footer_desc" : "A propos", 
    "desc_cust_keywords" : "mots clefs (meta)",
    "desc_enable_auto_sitemap" : "Sitemap automatique",
    "desc_seo_include_zetvu" : "Référencement des ZETEVU",
    "desc_cust_logo_uri" : "Logo URL",
    "desc_cust_favicon_uri" : "Favicon URL",
    "desc_enable_img_autoswipe" : "Image Auto-swipe",


    "help_cust_site_owner_accronym" : "Accronym / nom de la société propriétaire du site pour être utlilisé dans les termes et conditions.",
    "help_cust_site_owner_long" : "Nom  LONG du propriétaire du site pour être utlilisé dans les termes et conditions",
    "help_cust_site_name" : "Nom du site tel qu'il apparaitra sur la page web",
    "help_cust_site_motto" : "Devise du site tel qu'il apparaitra sur la page web",
    "help_cust_loading_msg" : "Message de bienvenue qui s'affichera lors du chargement de la page",
    "help_cust_title" : "Titre su site  ",
    "help_cust_about_footer_desc" : "Texte affiché dans le A PROPOS en bas de page . Laisser vide pour ne pas l'afficher", 
    "help_cust_description" : "Description courte du site qui sert au référencement",
    "help_cust_keywords" : "mots clefs servant au référencement",
    "help_enable_auto_sitemap" : "Génération automatique d'un sitemap.xml et dépot sur la racine su site",
    "help_seo_include_zetvu" : "Référencement des ZETEVUs/ NEWS dans la sitemap",
    "help_cust_logo_uri" : "Logo URL",
    "help_cust_favicon_uri" : "Favicon URL",
    "help_enable_img_autoswipe" : "Image Auto-swipe : active le défilement autatique des images quand on passe la souris dessus en mode affichage de détails.",


    "desc_page_map" : "Page Avec Carte",
    "desc_page_map_first_p" : "Texte HTML entête",
    "desc_page_map_center_p"  :"Texte HTML centre",
    "desc_page_map_last_p" : "Texte HTML pied",

    "help_page_map" : "Page Avec Carte",
    "help_page_map_first_p" : "Paragraphe d'entête de la page principale d'accueil (code HTML avec ZADS KEYWORDS)",
    "help_page_map_center_p" : "Paragraphe au centre la page principale d'accueil (code HTML avec ZADS KEYWORDS)",
    "help_page_map_last_p" : "Paragraphe de pied de page de la page principale d'accueil (code HTML avec ZADS KEYWORDS)",

    "desc_social_links":"Liens SOCIAL",
    "desc_cust_facebook_url":"FACEBOOK (url)",
    "desc_cust_twitter_url":"TWITTER (url)",
    "desc_cust_gplus_url":"GOOGLE+ (url)",
    "desc_cust_youtube_url":"YOUTUBE (url)",
    "desc_footer_links":"Liens bas de page",
    "desc_cust_tandc_url":"Termes et conditions (url)",
    "desc_cust_rgda_url":"Régles de Diffusion (url)",
    "desc_cust_pub_url":"Publicité (url)",
    "desc_cust_contactus_url":"Nous contacter (url)",
    "desc_cust_aboutus_url":"A propos .. (url)",
    "desc_cust_whoweare_url":"Qui sommes-nous .. (url)",
    "desc_cust_faq_url":"F.A.Q (url)",
    "desc_cust_demo_url":"Demo (url)",
    "desc_cust_help_url":"Aide (url)",
    "desc_cust_pricing_url":"Tarifs (url)",
    "desc_cust_blog_url":"Blog (url)",
    "desc_cust_forum_url":"Forum (url)",

    "help_social_links":"Liens SOCIAL",
    "help_cust_facebook_url":"FACEBOOK url affichée en bas de page ou dans le widget social",
    "help_cust_twitter_url":"TWITTER url affichée en bas de page ou dans le widget social",
    "help_cust_gplus_url":"GOOGLE+ url affichée en bas de page ou dans le widget social",
    "help_footer_links":"Liens bas de page",
    "help_cust_tandc_url":"Lien (url) vers la page des Termes et conditions du site",
    "help_cust_rgda_url":"Lien (url) vers la page des Régles de Diffusion du site",
    "help_cust_pub_url":"Lien (url) vers une page indiquant les conditions de publicité",
    "help_cust_contactus_url":"Lien vers la formulaire de contact. Indiquer 'contact' pour utiliser le formulaire intégré au site.",
    "help_cust_aboutus_url":"A propos de ..url",
    "help_cust_whoweare_url":"Qui sommes-nous .. (url)",
    "help_cust_faq_url":"Lien (url) vers lune page de Questions/Reponses",
    "help_cust_demo_url":"Lien (url) vers une page Demo",
    "help_cust_help_url":"Lien (url) vers une page d'aide sur ce site",
    "help_cust_youtube_url":"YOUTUBE url",
    "help_cust_pricing_url":"Lien (url) vers la page des tarifs.",
    "help_cust_blog_url":"Lien (url) vers votre  site de blogging",
    "help_cust_forum_url":"Lien (url) vers votre FORUM",

    "desc_general" :"Général",

    "desc_theme_style":"Théme (expert)",
    "desc_layout_bg_pattern":"Image de fond",
    "desc_theme_css_url" : "URL theme CSS (delta)", 
    "desc_theme_master_css_url" :"URL theme CSS (master)",
    "desc_theme_cust_lang_url" :"URL correctifs langues",
    "desc_layout_header_widgets_en" :"Header widget",
    "desc_layout_gallerie_widgets_forced_fullwidth" :"Gallerie 100% large",

    "desc_enable_infinite_nav" : "Navigation infinie",
    "desc_enable_infinite_scroll" : "Déroulement infini",
    "help_enable_infinite_nav" : "Navigation infinie : à la fin de chaque page, un bouton à cliquer vous propose de charger la suite.",
    "help_enable_infinite_scroll" : "Déroulement infini : chargemement automatique des pages suivantes quand vous arrivez en bas de page",

    
    "help_layout_bg_pattern":"Nom de l'image de fond par défaut. Ne rien indiquer pour avoir un fond vide. L'image doit être dans préalablement stockée dans le répertoire /bg/ du site.",
    "help_theme_css_url" : "Ce champ, si renseigné, permet d'ajouter au site en place des CSS personnels qui peuvent être chargés sur le site via l'interface de gestion de fichier ou simple des CSS venant d'une URL publique", 
    "help_theme_cust_lang_url" :"URL du fichier de langue qui viendra completer le master language . Attention, le format ne doit pas terminer ne nom du fichier (exemple pour un fchier custo_fr_FR.js, indoquez uniquement le chemin + custo_, le reste sera ajouté par le site fonction de la langue choisie.",

    "help_theme_master_css_url" :"URL theme MASTER : permet de remplacer la feuille de style maitre par une autre feuille de style . Laisser vide si vous souhaitez utiliser la feuille maitre de base.",
    "help_layout_header_widgets_en" :"Permet d'afficher une zone de 200px en haut du site (entre la barre et le début de l'affichage) et positionner le logo et une publicité",
    "help_layout_gallerie_widgets_forced_fullwidth" :"Force le module/widget Gallerie A la une a avoir 100% la taille du site. Par défaut, elle est limitée à la zone d'affichage des annonces, sans la barre latérale",

    "desc_enable_country_map":"Carte premiére page",
    "desc_max_pages_to_show":"Max page",
    "desc_max_items_per_page":"Nombre item/page",
    "desc_layout_bg_pattern":"Image de fond",
    "desc_header_show_nb_ads" : "Affic. nbr annonces en haut",
    "desc_widgets":"Widgets",
    "desc_max_items_per_mod":"MAX article/widget",
    "desc_nb_items_per_vmod":"Nbr articles/widget",
    "desc_enable_mostviewed_mod":"Les plus vus",
    "desc_enable_top_mod":"A la une",
    "desc_enable_topgallery_mod":"Galerie",
    "desc_enable_browsebyloc_mod":"Localisation",
    "desc_browsebyloc_fields_order":"Location order",
    "desc_categories":"Catégories",
    "desc_max_cat_per_column":"Catégories/col",
    "desc_show_empty_cat":"Affichage Ad Vides",
    
    "desc_hide_empty_cat_users":"Masquer Cat. vides",
    "desc_hide_empty_buy_ad":"Catégorie 'buy' vides",
    "desc_display_more_cat_link":"Afficher 'plus'",
    "desc_max_skills_nb":"Max compétences",
    "desc_zetvu":"Zetevu/NEWS",
    "desc_disable_zetvu":"Désactiver",
    "desc_zetvu_as_news":"Mode News",
    "desc_zetvu_create_by_admin_only":"Création par Admin",

    "desc_enable_latest_mod":"Derniers Ajouts",
    "desc_enable_urgent_mod":"Annonces urgentes",
    "desc_enable_social_widget":"Social toolbar",
    "desc_enable_newsletter_widget":"Newsletter",


    "help_enable_country_map":"Afficher en premiére page la carte des annonces. Mettre sur OFF pour arriver directement à la liste des annonces.",
    "help_max_pages_to_show":"Nombre maximum de pages à afficher",
    "help_max_items_per_page":"Nombre d'articles par page.",
    "help_header_show_nb_ads" : "Afficiche dans le barre du haut le nombre de d'annonces.",

    "help_widgets":"Widgets = Modules affichés",
    "help_max_items_per_mod":"Nombre d'articles maximum affichés par widget.",
    "help_nb_items_per_vmod":"Nombre d'articles visibles par widgets.",
    "help_enable_mostviewed_mod":"Module 'les plus vues'",
    "help_enable_top_mod":"Module 'a la une'",
    "help_enable_topgallery_mod":"Module Galerie tournante en haut de page des articles 'A la une' ",
    "help_enable_browsebyloc_mod":"Module 'localisation'",
    "help_browsebyloc_fields_order":"Ordre de navigation dans les champs de localisation . Mots acceptés : locregion;locdept;loccity. Séparation par | .",
    "help_categories":"Catégories",
    "help_max_cat_per_column":"Sous-menu de navigation :  Nombre max de catégories a afficher avant de changer de colonne d'affichage.",
    "help_show_empty_cat":"Sous-menu de navigation : Afficher les catégories sans annonces",
    "help_hide_empty_cat_users":"Sous-menu de navigation : Masquer les catégories sans annonceurs.",
    "help_hide_empty_buy_ad":"Sous-menu de navigation : Masquer les catégories sans annonces de type 'demandes'.",
    "help_display_more_cat_link":"Afficher le bouton 'plus' lorsque le nombre de sous-catégories dépasse 3.",
    "help_max_skills_nb":"Nombre maximum de conpétances qu'un annonceur peut choisir dans son profile",
    "help_zetvu":"Zetevu/NEWS",
    "help_disable_zetvu":"Désactiver la fonction zetevu/news.",
    "help_zetvu_as_news":"Mode News activé pour la fonction zetevu/news. Attention, le mode ZETEVu ci-dessus doit être activé",
    "help_zetvu_create_by_admin_only":"Création des ZETEVU/NEWS autorisée par administrateur uniquement. Sinon, tout le monde peut en créer un",

    "help_enable_latest_mod":"Module derniéres annononces ajoutées- Module sur la barre latérale",
    "help_enable_urgent_mod":"Module derniéres annonces urgentes - Module sur la barre latérale",
    "help_enable_social_widget":"Social toolbar qui s'affiche en statique sur le coin de la page",
    "help_enable_newsletter_widget":"Newsletter - champ de saisie disponible en bas de page pour s'enregistrer à la newsletter",


    "desc_ad_preview_before":"Mode pre-vue (annonces)",
    "desc_user_preview_before":"Mode pre-vue (usagers)",
    "desc_draft_purge_duration":"Purge Bouillons aprés ",
    "desc_publishing_duration":"Publication Ann. pendant",
    "desc_user_auto_approval":"Auto-approbation (usagers)",
    "desc_ad_auto_approval":"Auto-approbation (annonces)",
    "desc_desc_new_sincelastvisit_en" : "New (depuis edrniére visite)",
    "desc_dayskeepasnew":"Nb jours en 'new'",
    "desc_archive_duration":"Archive de tout pendant",
    "desc_notificationbefore_duration":"Notification expiration avant",
    "desc_user_maxinactive_duration":"Expirer Usagers inactifs aprés",
    "desc_ad_paid_nomods_aftercreation" : "NO-Mods options payantes", 


    "help_ad_preview_before":"Affichage de l'annnonce telle qu'elle apparaitra sur le site avant soumission ou publication",
    "help_user_preview_before":"Affichage de l'annonceur  telle qu'il apparaitra sur le site avant soumission ou publication",
    "help_draft_purge_duration":"Delai de retention des annonces brouillons",
    "help_publishing_duration":"Durée de publication des annonces",
    "help_user_auto_approval":"Auto-approbation des annonceurs",
    "help_ad_auto_approval":"Auto-approbation des annonces",
    "help_dayskeepasnew":"Nb jours ou afficher une annonce en 'new'",
    "help_desc_new_sincelastvisit_en" : "Afficheun indicateur NEW sur les annonces nouvelles depuis la derniére visite",
    "help_archive_duration":"Archive des annonces expirées pendant xx jours",
    "help_notificationbefore_duration":"Nombre de jours avant la fin de l'annonce ou une notification par email va être envoyée à l'annonceur",
    "help_user_maxinactive_duration":"Expiration automatique des comptes annonceurs aprés un délai de xx jours d'inactivité. Les comptes sont mis en archive.",
    "help_ad_paid_nomods_aftercreation" : "Desactive la capacité pour les annonceurs de changer les options payantes aprés publication", 

    "desc_email_fromadmin":"DE (email)",
    "desc_email_admin":"Admin email (TO)",
    "desc_email_admin_reports":"Rapports (TO)",
    "desc_email_support":"Support (TO)",
    "desc_email_sales":"Sales (TO)",
    "desc_emails_admin_essential_mode" : "Notification réduite", 

    "help_email_fromadmin":"Adresse email utilisée pour le champ FROM des emails envoyés. Format de type  : {prenom nom <adresse email>} ou {adresse email} autorisés",
    "help_email_admin":"Adresse email de l'administrateur pour recevoir les notifications. Format de type  : {prenom nom <adresse email>} ou {adresse email} autorisés",
    "help_email_admin_reports":"Adresse email(s) des personnes qui souhaitent recevoir les rapports journaliers d'activité.Format de type  : {prenom nom <adresse email>} ou {adresse email} autorisés",
    "help_email_support":"Adresse email de l'équipe support vers qui diriger les demandes. Format de type  : {prenom nom <adresse email>} ou {adresse email} autorisés",
    "help_email_sales":"Adresse email de l'équipe vente vers qui diriger les demandes. Format de type  : {prenom nom <adresse email>} ou {adresse email} autorisés",
    "help_emails_admin_essential_mode" : "Par défaut, chaque changement d'état d'une annonce ou d'un annonceur envoie une notification à l'administrateur. Activez cette option pour supprimer cette notification", 


    "desc_locale_default_currency":"Devise",
    "desc_locale_default_unit":"Unité mesure",
    "desc_locale_default_country_code":"Code pays",
    "desc_locale_default_sub_code":"Sous code pays",
    "desc_locale_default_lat":"Latitude",
    "desc_locale_default_lng":"Longitude",

    "help_locale_default_currency":"Devise d'affichage des prix (EUR, USD,, ) et paiement PAYPAL. Code ISO-4217. Mettre NO pour ne pas afficher la devise mais alors pas de PAYPAL !",
    "help_locale_default_unit":"Unité mesure : km (pour Kilomètres), m (pour miles)",
    "help_locale_default_country_code":"Code pays (ISO 3166-1) permettant d'afficher la bonne carte en première page et adapter les contrôles de code postaux, numéro de téléphones, ...",
    "help_locale_default_sub_code":"Sous code pays - ** reserved **",
    "help_locale_default_lat":"Latitude du point central permettant de positionner la cartes par défaut",
    "help_locale_default_lng":"Longitude du point central permettant de positionner la cartes par défaut",

    "desc_enable_badwords_filter":"Filtrage Mots Interdits",
    "desc_enable_ipblacklist_filter":"Filtrage IPs",
    "desc_enable_emailblaklist_filter":"Filtrage eMAILS",
    "desc_enable_contactthru_when_phone" : "Contract anonyme/phone", 

    "help_enable_badwords_filter":"Active le filtrage des mots interdits sur les annonces. La liste des mots se configure par langue.",
    "help_enable_ipblacklist_filter":"Active le filtrage des visiteurs sur l'adresse IP (IP BLACK LIST)",
    "help_enable_emailblaklist_filter":"Active le filtrage des connections sur adresse email",
    "help_enable_contactthru_when_phone" : "Contract anonyme/phone : permet, même quand l'annonceur indique une numero de telephone d'utiliser le formulaire de contract du site.", 


    "desc_google_analytics_account":"Google ANALYTICS",
    "desc_google_site_verification":"Google SITE CODE",
    "desc_extra_header_info" : "Code en + dans HEADER", 
    "desc_enable_debug_mode":"Mode Debug",
    "desc_auto_pics_resize" : "re-taille des images",

    "help_google_analytics_account":"Code Google Analytics pour le suivi de performance du site. Si vide, GoogleAnalytics n'est pas activé sur les pages.",
    "help_google_site_verification":"Code de vérification pour GOOGLE SITE VERIFIER",
    "help_enable_debug_mode":"Mode de debug - Administrateur uniquement - pour l'aide à la résolution de panne du site",
    "help_auto_pics_resize" : "correction automatique de la taille des images en 600x500px max.",
    "help_extra_header_info" : "Permet d'ajouter du code HTML en plus dans la section HEADE du site.", 


    "desc_sales_package": "Packaging", 
    "desc_max_tot_ads":"MAX annonces",
    "desc_max_tot_ads_per_users":"Max Annonces/user",
    "desc_max_pic_size":"Taille Image",
    "desc_max_pic_nb":"Max images/ad",
    "desc_auto_pics_resize":"Auto-resize",
    "desc_tbyb_end_date":"Fin Essai le",
    "desc_directory_mode":"Mode Annuaire",
    "desc_homepage_display_what":"Page principale",
    "desc_widgets_based_on_what":"Widget basé sur",
    "desc_security_logs":"Sécurité/logs", 
    "desc_backup_sqltable":"Backup", 
    "desc_enable_elem_logs":"Logs sur annonces",
    "desc_enable_user_logs":"Logs sur usagers",
    "desc_logs_duration":"Durée rétention",
    "desc_payment_logs_duration":"Durée PAYPAL logs",
    "desc_advanced_layout":"Mise en page avancée", 
    "desc_split_desc_ad_details":"Séparer texte ", 
    "desc_desc_ad_details_all_bottom":"Texte en bas", 

    "desc_files_manager":"Gestionnaire fichiers",
    "desc_enable_files_manager":"Activer",
    "desc_files_manager_dir":"repertoire destination",
    "desc_files_manager_max_size":"taille maxi",
    "desc_files_manager_max_nbr":"max fichiers",

    "desc_emails_manager" : "Gestion Emails",
    "desc_enable_emails_templates" : "Basé sur modèles ?",

    "desc_advanced_search":"Rech. avancée",
    "desc_adv_search_startup":"Rech. avancée",
    "desc_adv_search_autosuggest":"Auto-suggession",
    "desc_vfields":"Champs supplém.",
    "desc_enable_vfields":"Activer champs virtuels",
    "desc_vfields_search":"Rech. avec champs v.",

    "desc_access_profiles" : "Types de comptes", 
    "desc_user_profile_private_en" : "Type PRIVE", 
    "desc_user_profile_public_en" : "Type PUBLIC", 
    "desc_user_profile_pro_en" : "Auto. type PRO", 
    "desc_user_profile_par_en" : "Auto. type PARTICULIER",

    "desc_advanced theme" : "Theme (expert)", 
    "desc_theme_extra_js_url" : "URL extra JS", 
    "help_theme_extra_js_url" : "URL du fichier .JS qui devra être charger en plus du site pour ajouter du scripting personnel", 



    "desc_dpe_img_vfield_id" :"CE champ ID",
    "desc_ges_img_vfield_id" : "GES champ ID", 
    "help_dpe_img_vfield_id" :"Classe Enerie : identifiant du champ spécial contenant l'information. Permet d'afficher la carte dynamiquement. Laisser a vide pour ne pas afficher",
    "help_ges_img_vfield_id" : "Gaz a affet de serre : identifiant du champ spécial contenant l'information. Permet d'afficher la carte dynamiquement. Laisser a vide pour ne pas afficher", 


    "help_adv_search_startup":"Bloc de recherche avancée affiché par défaut au demarrage du site",
    "help_adv_search_autosuggest":"Auto-suggession activée",
    "help_enable_vfields":"Activer la gestion et usage de champs virtuals sur le site",
    "help_vfields_search":"Ajouter les champs virtuels comme critéres de recherche",

    "help_user_profile_private_en" : "Type PRIVE : permet de s'enregistrer avec unevisibilité privée (=publication uniquement d'annonces mais pas visible dans l'annuaire)", 
    "help_user_profile_public_en" : "Type PUBLIC : vompte visible dans l'annuaire mais simplifié", 
    "help_user_profile_pro_en" : "Type Professionnel : autoriser la creation de compte de type PROFESSIONNELS (plus de champs)", 
    "help_user_profile_par_en" : "Type PARticulier : autoriser la création de compte simple de type particulier.", 

    "help_sales_package": "Packaging", 
    "help_max_tot_ads":"Limiter au nombre total d'annonces indiqué.",
    "help_max_tot_ads_per_users":"Nombre d'annonces max par users",
    "help_max_pic_size":"Taille maximale des images téléchargées (en Octets).",
    "help_max_pic_nb":"Nombre max d'images par annonces",
    "help_auto_pics_resize":"Re-taille automatique des images téléchargées au format 672px max en largeur ou longueur en respectant les proportions.",
    "help_tbyb_end_date":"Date de fin de l'essai",
    "help_directory_mode":"Mode annuaire",
    "help_homepage_display_what":"Type d'affichage en page principale (user ou ad)",
    "help_widgets_based_on_what":"Widgets basés sur ... (ad ou user)",
    "help_security_logs":"Sécurité/logs", 
    "help_backup_sqltable":"Backup", 
    "help_enable_elem_logs":"Logs sur annonces",
    "help_enable_user_logs":"Logs sur usagers",
    "help_logs_duration":"Durée rétention des logs ",
    "help_payment_logs_duration":"Durée PAYPAL logs",
    "help_advanced_layout":"Mise en page avancée", 
    "help_split_help_ad_details":"Séparer le texte descriptif d'une annonce en 2 morceaux", 
    "help_help_ad_details_all_bottom":"Mettre tout le texte descriptif de l'annonce en dessous de la photo", 

    "help_enable_emails_templates" : "Gestion Emails sur la base de modéles HTML directment configurables via l'administration wbe. Si OFF, utilisation des modéles internes au site",

    "help_split_desc_ad_details":"Sépare texte de description des annnonces avec le debut sur le coté et la fin en dessous des photos", 
    "help_desc_ad_details_all_bottom":"Positionne 100% de la descritption d'une annonce en dessous des photos et plus sur le côté comme le mode par défaut.", 



    "desc_badwords":"Mots interdits",
    "desc_cust_badwords":"Mots interdits",
    "help_cust_badwords":"Liste des mots interdits. Attention : séparation par '|' uniquement. A la détection, l'annonce sera mise en quarantaine et nécessitera l'approbation de l'éditeur. Ne pas oublier d'activer l'option générale de filtrage des mots interdits.",
    "Bad words error notice text" : "Votre annnonce contient des mots interdits qui ne respectent pas les termes et conditions du site.",


    "desc_location_restricted_disp":"Cacher adresse (partiel)", 
    "help_location_restricted_disp":"Cette option permet de cacher aux visiteurs l'adresse exacte des annonces et annonceurs et aficher uniquement departement/ville", 


    "latest added" :"latest added", 
    
    // file manager @Z5.1
    "manage_files" : "Files management", 
    "help_manage_files" : "Files management", 
    "filesmanager" : "Files managemer",
    "upload file" : "Ajouter un fichier",
    "%s file":"%s fichier",
    "%s files":"%s fichiers",
    "%s Byte":"%s Byte",
    "%s Bytes":"%s Bytes",
    "No files in directory." : "Aucuns fichiers dans ce répertoire",

    // emails maagement //
    "manage_emails" :"Gestion emails",
    "help_manage_emails" :"Gestion emails",

    "emailsmanager" : "Gestionnaire des modéles de notifications email",
    "save" : "Sauvegarder", 
    "view it" : "prévisualiser",
    "send you a test email" : "Vous envoyer un email de test",

    "%s emails" : "%s modèles de notification" ,
    "%s email" : "%s modèle de notification" ,

    "help_admin_abuse_00.html":"Signaler un abus sur une annonce (Administrateur)", 
    "help_admin_ad_20.html":"Annonce à valider (Administrateur)",
    "help_admin_ad_15.html":"Annonce en attente de paiement (Administrateur)",  
    "help_admin_ad_40.html":"Annonce publiée (Administrateur)", 
    "help_admin_support_00.html":"Demande de support(Administrateur)", 
    "help_cron.html":"Tableau de bord journalier (Administrateur)", 

    "help_lost_password.html":"Changement de mot de passe (Propriétaire)", 
    "help_user_lost_00.html":"Changement de mot de passe (Propriétaire)", 

    "help_owner_ad_15.html":"Annonce ayant un paiment en attente (Annonceur)", 
    "help_owner_ad_20.html":"Annonce en attente de validation (Annonceur)", 
    "help_owner_ad_40.html":"Annonce publiée (Annonceur)", 
    "help_owner_ad_45.html":"Annonce qui va prochainement expirer (Annonceur)", 
    "help_owner_ad_80.html":"Annonce expirée (Annonceur)", 
    "help_owner_ad_90.html":"Annonce refusée par l'editeur (Annonceur)", 
    "help_owner_contactuser_00.html":"Demande de contact vers  Annonceur", 
    "help_owner_contact_00.html":"Demande de contact sur une annonce (Annonceur)", 
    
    "help_owner_support_00.html":"Demande de support (Visiteur)", 

    "help_owner_reminder_00.html":"Email de rappel d'une annonce (Visiteur) ", 
    "help_user_remind_00.html":"Email de rappel d'une annonce (Visiteur) ", 

    "help_admin_user_15.html":"Abonnement en attente de réglement (Administrateur)", 
    "help_admin_user_20.html":"Abonnement à valider (Administrateur)", 
    "help_admin_user_40.html":"Abonnement actif (Administrateur)", 
    "help_admin_user_45.html":"Abonnement va prochainement expirer (Administrateur)", 
    "help_admin_user_60.html":"Abonnement est bloqué (Administrateur)", 
    "help_admin_user_80.html":"Abonnement expiré (Administrateur)", 


    "help_owner_user_15.html":"Abonnement en attente de réglement (Annonceur)", 
    "help_owner_user_20.html":"Abonnement en cours de validation (Annonceur)",
    "help_owner_user_40.html":"Abonnement actif (Annonceur)", 
    "help_owner_user_45.html":"Abonnement va prochainement expirer (Annonceur)", 
    "help_owner_user_60.html":"Abonnement est bloqué (Annonceur)", 
    "help_owner_user_80.html":"Abonnement expiré (Annonceur)", 


    "help_user_contactuser_00.html":"Confirmation demande de contact (demandeur)", 
    "help_user_contact_00.html":"Demande de contact sur une annonce (Visiteur)", 
    "help_user_reminder_00.html":"Reppel d'une annonce interessante (Visiteur)", 
    "help_user_support_00.html":"Demande de support (Visiteur)", 

    "help_lost_password_link.html" : "Changement de mot de passe par lien",
    "help_user_lost-link_00.html": "Changement de mot de passe par lien (demandeur)",

    "help_notif.html" : "Email général de notification", 
    "help_user_abuse_00.html" : "Email de signalement d'un abus",
    "help_reactivate_account" : "Réactivation d'un compte", 
    "help_user_reactivateaccount_00.html" : "Réactivation d'un compte", 

    "help_admin_reports_cron_daily.html" : "Automate journalier (Administrateur)",
    "help_admin_reports_cron_hourly.html" : "Automate horaire (Administrateur)",
    "help_admin_reports_cron_weekly.html" : "Automate hebdomadaire (Administrateur)",

    "help_superadmin_notif_orange.html" : "Alarme Orange (Administrateur)",
    "help_superadmin_notif_red.html" : "Alarme Rouge (Administrateur)",  

    // fiels maagement //
    "manage_fields" :"Gestion des champs",
    "help_manage_fields" :"Gestion des champs",
    "fieldssmanager" : "Gestionnaire de champs personnalisés",

    "banner_pos_background_all":"Fond d'écran - arriére plan (taille infinite)", 
    "banner_pos_background_right_top":"Font d'écran - coin sup droit (taille 300x100)", 
    "banner_pos_sidebar_right_top":"Barre Latérale - droite - haut (taille 180x150) ", 
    "banner_pos_page_center_top":"Haut du listing (taille LEADERBOARD 728x90) ", 
    "banner_pos_mob_page_center_top":"Centre page - en haut du listing (Mobile) (taille 720x50)", 
    "banner_pos_ad_detail_sidebar":"Fiche d'une annonce (largeur max 260px - reco : 234x60)", 
    "banner_pos_user_detail_sidebar":"Fiche d'un annonceur (largeur max 340px - reco : 336x100)", 
    "banner_pos_news_main_center_top":"News centrale - en haut du listing", 
    "banner_pos_headerwidget_right_top":"Entête - en haut à droite (taille 480x80)", 
    "banner_pos_ad_list_center_top" : "Haut du listing - ANNONCES uniquement (taille 728x90) ", 
    "banner_pos_user_list_center_top" : "Haut du listing - VENDEURS uniquement (taille 728x90) ", 
    "-- all positions --" : "-- tous les emplacements --",
    "search for title" : "Rehercher dans le titre", 

    // zads 5.5
    // search 
    "Advanced search :" : "dvanced search :", 
    "Search" : "Search", 
    "No results" : "No results", 
 
    // VFIELDS management 
    "%s vfields" : "%s champs spéciaux" ,
    "%s vfield" : "%s champ spécial" ,
    "add vfield" : "Ajouter un champ spécial" ,
    "int_label" : "Nom",
    "disp_label" : "Label",
    "preview" : "Affiché comme ...",
    "moddatestamp" : "Date",
    "domtype" : "Type",
    "scope" : "Scope",
    "forwhat" : "Cible", 
    "id" : "Ident.", 

    "fieldsmanager" : "Gestionnaire de champs spéciaux",
    "all vfields" : "tous les champs",
    "id" : "id",

    "vfield creation ongoing" : "Création du champ spécial en cours", 

    " vfield form header title" : "Création d'un champ spécial",
    " vfield form header introduction" : "Les champs spéciaux permettent d'ajouter de caractéristiques particuliéres à certaines annonces dans certaines catégories. Définissez le champ spécial ici et ajoutez le aux catégories via l'interface admin", 

    "modify vfield form header title" : "Modification d'un champ spécial",
    "modify vfield form header introduction" : " ", 


    "desc_int_label" : "Nom interne",
    "desc_disp_label" : "Nom affiché",
    "desc_scope" : "Type de champ",
    "desc_forwhat" : "Pour...",
    "desc_domtype" : "Type HTML",
    "desc_domsubtype" : "Sous-type",
    "desc_values" : "Valeurs",
    "desc_unit" : "Unité",
    "desc_stype" : "Type (recherche)", 
    "desc_linkedvfield" : "Champ lié (recherche)",
    " add_values" : "ajouter une valeur",
    "add this value" : "ajouter cette valeur",
    "vfield value placeholder" : "entrer le valeur désirée",
    "No fields defined yet" : "Aucun champ défini pour l'instant",

    "help_scope" : "Indique si ce champ sera utilisé pour des informations supplémentaires dans les annonces ou un champ de recherche",
    "help_forwhat" : "Précise si ce champ peut etre ajouté à des usagers, annonces ou tout",
    "help_int_label" : "Nom interne du champ utilisé pour l'administration",
    "help_disp_label" : "Nom affiché du champ qui sera visible par les visiteurs et annonceurs",
    "help_domtype" : "Type HTML du champ (entrée simple, liste de choix, ...",
    "help_values" : "Liste des différentes veleurs que peut prendre un champ. Ne sert a rien sur les champs input",
    "help_unit" : "Unité, optionelle pour indiquer l'unité du champ saisi",
    "help_domsubtype" : "!! uniquement pour les champs INPUTs : sous type permettant de filtrer les données",
    "help_linkedvfield" : "!! Uniquement pour les champs de recherche :  indique le champ lié à cette recherche",
    "help_stype" : "!! champ de recherche uniquement !! <br> permet de spécifier si le champ est de type MIN, MAX ou simplement generique",
    "help_values" : "Permet de lister les valeures pour les champs CHECKBOX ou RADIO ou SELECT",  
    "help_values (%s max)" : "Permet de lister les valeures pour les champs CHECKBOX ou RADIO ou SELECT (%s max). Attention, les 10 premiers caractéres doivent être différents entre chaque valeur.",  
    
    "BTN vfield DRAFT" : "Draft",
    "BTN vfield PUBLISHED" : "Published",
    "BTN vfield UNPUBLISHED" : "un-published",
    "BTN vfield DELETED" : "Deleted",
    "BTN vfield WILLEXPIRE" : "will expire",

    "desc_catlvfields" : "Special fields", 
    "help_catlvfields" : "Special fields allow to collect more information on ads", 
    " add_catlvfields" : "ad a special field",
     "add this field" : "add this field",
     "ad vfields" : "Characteristics", 
     "Select something" : "--Select something--", 

     // "set/un-set in your favorites" : "Ajouter/Supprimer de votre liste de favorites", 

     // newsletter 
     "manage_subscribers" : "Subscribers management", 
     "help_manage_subscribers" : "Subscribers management", 
     "all subscribers" : "all subscribers", 
     "-- all status --" : "All statuses", 
     "-- all status ad --" : "-- status --", 
     "-- all status user --" : "-- status --", 
     "registration pending" : "registration pending", 
     "registered" : "registered", 
     // "-- unlimited --" : "Tous les résultats", 

     // "publish" : "Publier/valider", 
     // "un publish" : "Retirer de la publication / suspendre", 
     // "subscribers unpublish confirmation" : "Confirmation de l'arret de l'abonnement", 
     // "subscribers publish confirmation" : "Confirmation de l'activation de l'abonnement", 
     // "subscribers delete confirmation" : "Confirmation de l'effacement de l'abonnement",
     // "No entries in subscribers" : "Aucun abonné pour l'instant", 
     // "Export this table to xls" : "Exporter XLS", 
   
     // "Subscribe" : "S'abonner",
     // "Delete this" : "Effacer",
     // "Un-Subsrcibe"  : "de-enregistrer",
     // "Your email address": "Votre email",
     // "Subscribe to the newsletter": "S'abonner",
     // "Your subscription is already pending your approval on : %s": "Votre abonnement est déja en attente avec cette adresse email : %s",
     // "You are already subscribed under %s": "Vous étes déjà abonné sous l'adresse email : %s",
     // "un-subsribe to the newsletter": "Supprimer son abonnement",
     // "delete this pending approval": "Annuler cette demande",
     // "Newsletter": "Newsletter",
     // "Your subscription is correctly registered, check your inbox email for validation.": "Votre abonnement sera définitivement valide une fois votre confirmation. Véfrifiez votre boîte email.",
     // "Newsletter registration pending": "Enregistrement en attente de validation",
     // "A registration already exist for this email address : %s.": "Vous étes déjà abonné sous cette adresse email : %s",

     // "un-subsribe to the newsletter": "Supprimer son abonnement",
     // "Your subscripton is cancelled" : "Votre abonnement est annulé",
     // "Your are un-subscribed to our newsletter"  :  "Vous n'ètes plus abonné à notre newsletter.",
     // "You are correctly unsubscribed." : "Vous n'ètes plus abonné à notre newsletter.", 
     // "This email or hash is not known by us yet  : %s." : "Cet adresse email ou ce code d'activation n'est pas reconnu.", 
     // "Your subscription is validated" : "Votre abonnement est actif.", 
     // "Thank you for your registration to our newsletter" : "Merci de votre abonnement à notre newsletter.", 
     // "Your are registered to our newsletter":  "Votre abonnement est actif.", 

     // "details dpe" : "CLASSE ENERGIE",


     // gestion fichiers 
     "tn" : "Thumbnail", 
     "name" : "Name", 
     "size" : "Size", 
     // "modified" : "Modifié le",
     // "actions" : "Actions", 

     // nouveaux liens 
     // "General Rules of Diffusion" : "Régles Générales de Diffusion de Annonces (RGDA)", 
     // "Régles de Diffusion" : "Régles de Diffusion",
     // " and the " : " et les ", 
     "Qui nous sommes ?" : "Who we are ?", 
     "Tarifs" :"Pricing", 

     "user details vfields" : "Other information", 
     "desc_extra_user_fields" : "Other information",

     // "subscribed options" : "Vos options", 
     // "Test Mail sent successfully" : "L'email a bien été envoyé à votre adresse", 

     // post correction ZADS  5.5.1 - BUGs discovered //
     // "definitively delete" : "Delete definitively", 


     // zads 5.5.2
     "mydashboard" : "My dashboard",
     "my dashboard" : "My dashboard",

    "desc_new_sincelastvisit_en" : "New depuis derniére visite",
    "help_new_sincelastvisit_en" : "Active l'option d'affichage du bandeau NEW sur les annonces nouvelles depuis la derniére visite",

    "desc_social_widget_list" : "Elements barre social (site)", 
    "desc_sidebar_widgets_order_list":"Liste order des widgets", 
    "desc_siret_control_url":"Siret control (url)", 
    "desc_urgent_ads_en":"Annonces urgentes", 

    "help_social_widget_list" : "Liste par ordre d'affichage des réseaux sociaux à afficher dans la barre latérale et le bas de page du site. Codes : FB=FACEBOOK, GO=GOOGLE, YO=YOUTUBE, LK=LINKEDIN, TW=TWITTER,  CT=CONTACT, PT=IMPRIMER", 
    "help_sidebar_widgets_order_list":"Liste par ordre d'affichage des widgets en barre latérale", 
    "help_siret_control_url":"URL du site qui controle le champ SIRET. ajouter [NUMBER] le remplacer dynamiquement par le siret du client exemple :http://www.societe.com/cgi-bin/recherche?rncs=[NUMBER]. Si renseigné, le champ SIRET devient obligatoire à la saisie", 
    "help_urgent_ads_en":"Active l'option 'annonces urgentes' lors de la saisie des annonces et la recherche", 

    "help_siret_format_FR" : "Le numéro SIRET (Système d'identification du répertoire des établissements) est un numéro d'identification unique attribué à chaque établissement selon une codification INSEE. C'est une suite numérique de 14 chiffres : les neufs premiers représentent le numéro SIREN de l'entreprise à la quelle l'établissement est rattaché, les cinq derniers chiffres sont un numéro interne de classement (NIC) qui permet d'identifier l'établissement.",
    "check prosiret" : "vérifier", 

    /* zads 5.5.3 */ 
    "urgent"  :"Urgent", 
    "ad urgent" :"Urgent",
    "Search in ads" :" Annonces", 
    "urgents" : "urgents", 
    // "only" : "jelpuniquement",
    "desc_urgent_ads_en" : "Urgent ads", 
    "help_urgent_ads_en" : "Active l'option annonces urgentes pour l'administrateur et comme critére de recherche.", 
    "desc_ads fields" : "Ad options",
    "desc_user fields" : "User options", 
    "desc_others" : "Others",

    "ad createdate" : "Created", 
    "ad firstpublisheddate" :"Published", 

    "desc_otherpaidoptions" : "General", 
    "post otherpaidoptions" :" ",
    "addpics" : "Pictures", 
    "paidvideo" : "Video code",

    "desc_putontopgallery" : "Featured",
    "help_putontopgallery" : "Featured",
    "putontopgallery" : "Featured",  
    "post putontopgallery" : "Set my ad to featured",
    "desc_putontopgallery7days" : "Featured", 
    "desc_putontopgallery15days" : "Featured", 
    "desc_putontopgallery30days" : "Featured", 
    "post putontopgallery7days" : "Featured every day for 7 days", 
    "post putontopgallery15days" : "Featured every day for 15 days", 
    "post putontopgallery30days" : "Featured every day for 30 days", 


    "desc_pushtotop" : "Push to top", 
    "help_pushtotop" : "Push to top", 
    "pushtotop" : "Push to top", 
    "post pushtotop" :"Push to top my ad",
    "desc_pushtotoponceaweek"  : "Push to top once a week",
    "desc_pushtotop7days" : "Push to top", 
    "desc_pushtotop15days" : "Push to top", 
    "desc_pushtotop30days" : "Push to top", 
    "post pushtotoponceaweek" : "Push to top once a week", 
    "post desc_pushtotop7days" : "Push to top every day for 7 days", 
    "post desc_pushtotop15days" : "Push to top every day for 15 days", 
    "post desc_pushtotop30days" : "Push to top every day for 30 days", 
    "post pushtotop7days" :  "Push to top every day for 7 days", 
    "post pushtotop15days" :  "Push to top every day for 15 days", 
    "post pushtotop30days" :  "Push to top every day for 30 days", 


    "desc_urgentad" : "Urgent", 
    "help_urgentad" : "Urgent", 
    "urgentad" : "urgent", 
    "post urgentad":"Add an urgent logo",
    "desc_urgentad15days" : "Urgent", 
    "desc_urgentad7days" : "Urgent",
    "desc_urgentad30days" : "Urgent",
    "post urgentad7days" : "Set the urgent tag for 7 days",
    "post urgentad15days" : "Set the urgent tag for 15 days",
    "post urgentad30days" : "Set the urgent tag for 30 days",


    "desc_specialcolor" : "Highlighted",
    "help_specialcolor" : "Highlighted",
    "specialcolor " : "Highlighted",
    "post specialcolor" : "Highlighted for more visibility",
    "desc_specialcoloronceaweek" : "Highlighted", 
    "desc_specialcolor7days" : "Highlighted",
    "desc_specialcolor15days" : "Highlighted",
    "desc_specialcolor30days":"Highlighted",
    "post specialcoloronceaweek":"Highlighted once a week",
    "post specialcolor7days":"Highlighted every day for 7 days",
    "post specialcolor15days":"Highlighted every day for 15 days",
    "post specialcolor30days":"Highlighted every day for 30 days",

    "help_specialcoloronceaweek":"Highlighted once a week",
    "help_specialcolor7days":"Highlighted every day for 7 days",

    "banner_pos_userpro_register_sidebar":"Lateral banner when pro account registering",


    // traductions pour gestion des abonnements
    "service status PUBLISHED": "Active", 
    "service status DELETED": "Empty", 
    "service status UNPUBLISHED": "Inactive",
    "service status WILLEXPIRE": "Will expire",  

    // nouvelles dates de gestion ajoutées 
    "ad life-cycle dates" : "Key dates",
    "desc_moddate" : "Modified by",
    "desc_createdate" : "Created by",
    "desc_firstpublisheddate" : "First published by",
    "desc_crondate" : "Last CRON by", 
    "desc_urgent" : "Urgent", 
    

    // text for pre-image label 
    "ad upload photo post label" : "n adwith a photo is 7th timem more visited than none.",


    "list_locations" : "Localization", 
    "desc_audiourl" : "Audio messages",
    "help_audiourl %s" : "You can add up to %s audio message(s) in WAV or MP3format.", 

    // new label forpassword change title 
    "desc_passwordchange" : "Password", 
    "modify my password" : "modify", 

    "desc_newsletter" : "Newsletter", 
    "help_newsletter" : "Site newsletter", 
    // "I subscribe" : "Je m'abonne", 


    "Categories" : "Categories", 

    "desc_location_retricted_disp" : "Cacher localis. exacte", 
    "help_location_retricted_disp" : "Si cette option est affichée, la localisation exacte saisie au niveau de l'annonce et dans la boutique sera cachée et remplacée par Ville/departement sans afficher les détails", 

    "Location displayed is restricted" : "Confidentialité : uniquement la Ville/Département seront affichés sur le site", 
    
    "desc_login_form_inpage" : "Login à plat",
    "help_login_form_inpage" : "Login à plat : l'écran de login est affiché en direct sur la page et plus via une pop-up",

    "settings_menu_paypal" : "Paypal/Paiement",


    "desc_paypal_section" : "Paypal", 
    "desc_paypal_sandbox" : "Mode bac-a-sable", 
    "desc_paypal_user" : "PAYPAL compte",
    "desc_paypal_password" : "PAYPAL mot de passe",
    "desc_paypal_signature" : "PAYPAL signature",

    "help_paypal_sandbox" : "Mode bac-a-sable : permet de tester / suspendre le paiement en redirigeant sur un site paypal de test", 
    "help_paypal_user" : "PAYPAL nom de l'utilisateur ",
    "help_paypal_password" : "PAYPAL mot de passe du compte",
    "help_paypal_signature" : "PAYPAL signature du compte",

    // my services section 
    "My Subscribed services" : "Mes services", 
    "My current services":"Mes services courants",
    "Your trial will expire in %s days": "Votre pack d'essai va expirer dans %s jours",
    "Your trial is expired as of %s days , please consider buying a pack below": "Votre pack d'essai est expiré depuis %s jours, merci de choisir un pack pour publier des annonces",  
    "Till :":"Jusqu'au :", 
    "Expired :" : "Expiré ", 
    "You have used %s of your %s ads included onto the pack": "Vous avez utilisé %s des vos %s annonces incluses dans le pack",

    "Add new services" : "Ajouter des services", 
    "Services package selection" : "Choisir le type de pack", 
    "Select this service":"Choisir ce pack", 
    "Main introduction text to add services":"Lorel ipsum main introduction text to ADD SERVICE section", 
    "Services plan selection":"Choisir le plan", 
    "Your pack :" :"Votre pack :", 
    "Modify this":"modifier", 
    "Select plan :" : "Votre plan : ",
    "Your plan :" :"Votre plan :", 
    "Select this plan":"Choisir ce plan",
    "Press the buy button to finalize your transaction": "Cliquez sur le bouton ACHETER pour finaliser la transaction", 
    "Buy this pack":"Acheter", 
    "Service order confirmation":"Confirmation de votre choix", 
    "No services activated" : "Aucun service activé",

    "myservices" : "Mes Services", 
    "help_myservices" : "La liste de mes abonnements, packs ou services activés.", 

    "You have %s article(s) waiting for your paiement" : "Vous avez %s annonce(s) qui est en attente de votre réglement. ",
    "You have no active services any more, please consider buying new services" : "Vous n'avez plus de services de publication actifs, merci d'acheter de nouveaux services pour publier des annonces. ", 
    "You have %s service(s) waiting for your paiement" : "Vous avez %s service(s) qui est en attente de votre réglement. ", 

    // new modification after 10th of feb
    // "Pay now" : "Payer maintenant",
    // "buy services here" : "Acheter des services",
    // "pro buy services here" : "PRO : Acheter des services", 
    // "par buy services here" : "PARTICULIER : Acheter des services", 
    // "pri buy services here" : "Acheter des services",     
    // "Thanks you for your payment ! Your service is activated." : "Merci pour votre achat, votre pack de service est activé.", 
    // "service status DRAFT PENDING PAYMENT" : "Paiement en attente",
    // "service creation ongoing" : "Création du service en cours", 
    "myinvoices":"My invoices", 
    "help_myinvoices": "show my invoices", 
    "See your invoice %s": "show my invoices %s", 
    "displayinvoiceaction" : "+", 
    "display invoice details" : "Show invoice details", 

    "CURRENCY :" : "Currency : ",
    "Designation" : "Designation",
    "qty" : "quantity",
    "qty" : "quantity",
    "unit price" : "unit price",
    "total price" : "total price",
    // "invalid TRANSACTION request" : "Demande invalide", 


    // update on invoice
    "INVOICE :" : "Invoice n° : ", 
    "INVOICE PRINT BUTTON" : "PRINT", 

    "INVOICE DATE :" : "Date : ", 
    "BUYER INVOICING TOP LABEL" : "Invoice",
    "BUYER FIRSTNAME :":"First Name : ",
    "BUYER LASTNAME :":"Last Name : ",
    "BUYER USERNAME :":"User name : ",
    "BUYER PROCPNY :":"Company : ",
    "BUYER ADDRESS :":"Addresse : ",
    "BUYER PHONE :":"Phone : ",
    "BUYER PROWEBSITE :":"Website : ",
    "BUYER EMAIL :":"Email : ",


    "INVOICE DATE :":"Date : ",
    "INVOICE WHAT ID :":"Reference : ",
    "INVOICE CURRENCY :":"Currency : ",
    "INVOICE PAYMENT METHOD :":"Payment method : ",
    "INVOICE TRANSACTION ID :":"Transaction id : ",
    "INVOICE TOTAL AMOUNT :":"Total amount : ",


    "INVOICE DESC":"Description",
    "INVOICE UP":"Unitary price",
    "INVOICE QTY":" Qty",
    "INVOICE TOT PRICE":"Total",

    "INVOICE DESC TRANSACTION :":"Transaction id : ",
    "INVOICE total without tax":"Total without tax : ",
    "INVOICE tax":"Tax : ",
    "INVOICE total with tax":"Total with taxe : ",


    "-- services all status --":"-- all states --", 
    // "services pending payments" : "en attente de paiement" ,
    // "services active" : "actifs",
    // "services expired" : "expirés",  
    "Sort by sid asc" : "Sort by pack name", 

    // CONFIG PAGE  : for the menu 
    "allservices" : "Services", 
    "manage_services" : "Services", 
    // "No entries in services" : "Aucun résultats pour cette recherche", 
    // "services unpublish confirmation" : "Suspendre ce service ? ", 



    // CONFIG PAGE  :  the the service settings parameters 
    "settings_menu_services" : "Services", 
    "desc_services_version":"Version abonnement",
    "desc_services_force_default_at_start":"Forcer default",
    "desc_services_multi_en":"Multi services",
    "desc_services_notif_before_days":"Notif expiration",
    "desc_services_deleteall_after_days_expiration":"Effacer aprés",
    "desc_services_notify_en":"Changements notif",
    "desc_services_price_free_during_trial":"Options Gratuit/trial",


    "help_services_version":"Version abonnement : laisser V2 pour la version ZADS 6.0 qui accepteune gestion de services multiples sur un abonnement",
    "help_services_force_default_at_start":"Forcer default : Lors de l'inscription d'un usager, force a prendre un service du catalogue marqué 'defaut'",
    "help_services_multi_en":"Multi services : accepter le mode 'services multiple' au lieu de abonnement simple",
    "help_services_notif_before_days":"Notif expiration : nombre de jours avant l'expiration d'un service ou un email de rappel sera envoyé.",
    "help_services_deleteall_after_days_expiration":"Effacer aprés : nombre de jours aprés lequels, un service en archive sera effacé",
    "help_services_notify_en":"Changements notif : envoyer un email de notification sur chaque changement d'état d'un service",
    "help_services_price_free_during_trial":"Options Gratuit/trial : Si cette option est activée, les services 'sur annonces' sont gratuits pendant la phase de trial",
  


    "desc_invoice_section":"Paramétres de facture",
    "desc_invoice_companyname" : "Nom de la société",
    "desc_invoice_vat": "Numéro de SIRET/TVA",
    "desc_invoice_company_address": "Adresse compléte",
    "desc_invoice_footertext": "Texte bas de page",

    "help_invoice_companyname" : "Nom de la société telle qu'elle apparaitra en haut de la facture",
    "help_invoice_vat": "Numéro de SIRET/TVA tel qu'il apparaitra en haut de la facture",
    "help_invoice_company_address": "Adresse compléte de la compagnie a afficher sur la facture. Indiquer les sauts de ligne avec des <br> HTML",
    "help_invoice_footertext": "Texte bas de page",

    "desc_ad_nomods_afterexpiration" : "Pas réactiv. des expirées", 
    "help_ad_nomods_afterexpiration" : "Pas de reactivation des annonces aprés expiration ou suppression", 

    "desc_ad_video_size_width" : "Largeur Videos", 
    "help_ad_video_size_width" : "Largeur des videos affichées dans le détail des annonces. la hauteur est automatiquement calculée avec le ration 0.6", 

    
    "ad video2 embed" : "Video2 HTML code", 
    "ad video2 embed help" : "Entrer le code HTML de votre fournisseur de video. Par exemple, sous YOUTUBE, rendez vous dans le menu PARTAGER / INTEGRER pour extraire le code à coller dans ce champ.", 



    "desc_probannerurl" : "Banner (URL click)",
    "help_probannerurl" : "URL of the distination site when a visitor clicks no the banner.",


    "desc_banclicks" : "Clicks#", 
    "help_banclicks" : "Number of clicks on your banner", 
    "banclicks" : "Ban. clicks", 


    /// translation 26122015

    "paypal_status_Completed" : "Paid", 
    "paypal_status_Pending" : "Pending payment", 
    
    // abonnements paypal
    "paypal_status_ActiveProfile"  : "Active Sub.", 
    "paypal_status_PendingProfile"  : "Pending Sub.",

    "servi" : "service", 
    "Main List" : "Back",
    "help link retour": "back to main list", 

    "help_admin_service_15.html" : "Service/subscription pending payment (administrator)", 
    "help_admin_service_40.html" : "Service/subscription activé (administrator)",

    "help_owner_service_15.html" : "Service/subscription pending paymen (owner)", 
    "help_owner_service_40.html" : "Service/subscription activated (owner)",  
    "help_owner_service_45.html" : "Service/subscription vwill soon expire (owner)",  
    "help_owner_service_80.html" : "Service/subscription is expired (owner)",  

    "help_user_newsletter_unsubscribe_80.html" : "Newsletter subscription terminated (visitor)", 
    "help_user_newsletter_validation_20.html" : "Newsletter subscription pending validation (visiteur)", 

    "ad_nbvideos" : "Videos nb/ad",

    "username already in use" : "username already in use",
    "email already in use" : "email already in use",
    "Confirm this service" : "Confirm this service", 
    "no options" : "no options",
    "par" : "Particulier", 
    "pro" : "Professionnal", 
    "Click <a id='print' href='#'>here</a> to print and clip along the line": "Click <a id='print' href='#'>here</a> to print and clip along the line",

    "desc_enable_url_noself_filter" : "URL filtering", 
    "help_enable_url_noself_filter" : "Active le filtrage des URLs dans une annonce. Si une URL est présente, l'annonce est marquée comme non conforme et mise en validation chez l'éditeur quelque soit le mode de publication. Un message est aussi indiqué dans l'email de changement d'état à l'auteur.", 

    "desc_services_pro_free_options_list": "Options gratuites pour pros.", 
    "help_services_pro_free_options_list": "Pour les annonces, liste les options qui seront forcées et mise gratuites pour les annonceurs professionnels (specifique). Utiliser les noms tels que définit dans le catalogue et séparez les par un signe '+' . ", 

    "desc_indir_pro_only" : "Annu. pour pros. uniquement",
    "help_indir_pro_only" : "Si ON, limite la visibilité annuaire aux professionells uniquement. Les particulier ne pourront pas choisir l'option. Les pros auront le choix de figurer ou non dans l'annuaire",


    // footer links
    "Who we are ?" : "Who we are ?",  
    "COPYRIGHT" : "COPYRIGHT",
    "Legal information" : "Legal information",
    "General rules of diffusion" : "General rules of diffusion",
    "Advertising" : "Advertising",
    "Contact us" : "Contact us",
    "Pricing" : "Pricing",
    "The blog" : "The blog",
    "F.A.Q" : "F.A.Q",  
    "Back to main site" :"Back to main site",
    "Help" : "Help",

    "sdesc_" : " ",
    "sdesc_basepack" : " ",
    "sdesc_pack5" : "(plan 5)",
    "sdesc_pack10" : "(plan 10)",
    "sdesc_pack25" : "(plan 25)",
    "sdesc_pack50" : "(plan 50)",
    "sdesc_pack75" : "(plan 75)",
    "sdesc_pack100" : "(plan 100)",

    "short-desc_of_pack5" : "plan 5 ads",
    "short-desc_of_pack10" : "plan 10 ads",
    "short-desc_of_pack25" : "plan 25 ads",
    "short-desc_of_pack50" : "plan 50 ads",
    "short-desc_of_pack75" : "plan 75 ads",
    "short-desc_of_pack100" : "plan 100 ads",

    "desc_extra links on nav page" : "Links in navigation bar",
    "desc_extra_main_nav_link1_title" : "Link 1 - title ",
    "desc_extra_main_nav_link1_url" : "Link 1 - URL ",
    "desc_extra_main_nav_link2_title" : "Link 2 - title ",
    "desc_extra_main_nav_link2_url" : "Link 2 - URL ",
    "desc_extra_main_nav_link3_title" : "Link 3 - title ",
    "desc_extra_main_nav_link3_url" : "Link 3 - URL ",

    "help_extra_main_nav_link1_title" : "Link 1 - title du link qui s'affichera sur la barre de natigation en plus des autres.",
    "help_extra_main_nav_link1_url" : "Link 1 - URL ",
    "help_extra_main_nav_link2_title" : "Link 2 - title ",
    "help_extra_main_nav_link2_url" : "Link 2 - URL ",
    "help_extra_main_nav_link3_title" : "Link 3 - title ",
    "help_extra_main_nav_link3_url" : "Link 3 - URL ",


    "desc_max_cat_on_sidebar" : "Sidebar, max ligne", 
    "help_max_cat_on_sidebar" : "Sidebar, max ligne : nombre de ligne max avant d'afficher le bouton 'plus...' pour les modules CATEGORIES et LOCALISATION de la sidebar.", 

    "social link to %s" : "Lien vers la page ou formulaire  : %s", 


    "title share on facebook" : "Partager dans Facebook",
    "title share on twitter" : "Partager sur Twitter",
    "title share on Linkedin" : "Partager dans LinkedIn",
    "title share on Google+" : "Partager dans Google+",
    "title share on Pinterest" : "Partager dans Pinterest", 
    "title ad email it" : "M'envoyer cette annonce par email",

    "you selected the  plan  : " : "you selected the  plan  : ",
    "you selected the  plan  : " : "you selected the  plan  : ",
    "Tooltip of Export this table to xls" : "ooltip of Export this table to xls", 

    "settings_oi" : "Reference (PUK)", 
    "settings_desc" : "Description", 
    "settings_price" : "Price",
    "settings_priceHT" : "Price (no VAT)", 
    "settings_priceTTC" : "Price (VAT)",
    "settings_isrecurrent" : "Recurrent",
    "settings_billingperiod" : "Periode",
    "settings_billingfrequency" : "Billing frequency",
    "settings_nb_addpics" : "Number of additional pictures",
    "pictures" : "pictures", 
    "Services prices are managed into the packs" : "Services prices are managed into the packs",


    "header text settings payoptions":"Catalogue des Options payantes", 
    "header text paragraph payoptions" : "Paramétrez ci-dessous les options payantes qui seront disponiblespour les annonces . Attention, les prix doivent avoir un '.' comme séparateur de décimal", 


    "desc_max_cat_on_sidebar" : "Sidebar, max ligne", 
    "help_max_cat_on_sidebar" : "Sidebar, max ligne : nombre de ligne max avant d'afficher le bouton 'plus...' pour les modules CATEGORIES et LOCALISATION de la sidebar.", 

    
    "settings_menu_payoptions" : " Catalogue", 
    "This is the LABEL element used to group below options" : "ce champ controle le libéllé", 

    // packas d'abonnements et services
    "settings_menu_pricing_plan" : "Abonnements", 
    "header text settings pricingplan":"Détails du contenu des abonnements et packs", 
    "header text paragraph pricingplan" : "Paramétrez ci-dessous les abonnements et services sui seront disponibles pour les annonceurs.", 

    "desc_page_map_type" : "Page home Externe (TEMPLATE)", 
    "desc_page_home_type_url" : "Page externe(url)", 
    "help_page_home_type_url" : "Si activé, la page d'accueil est externe et a charcher à l'url indiquée plus bas. Sinon, on utilise les champs textes", 
    "desc_page_home_url" : "Url de la page externe",
    "help_page_home_url" : "Url de la page externe contenant le contenu HTML a charger sur la page d'accueil",
    "desc_page_map_content" : "Contenu page statique", 

    "users delete confirmation" : "Delete of user - confirmation", 
    "ads delete confirmation" : "Delete of ad - confirmation", 

    // totnbads 
    // translations of the admin section zads 6.1
    "totnbads":"Qty", 
    "a_moddate" : "Date",
    "a_type" : "Type", 
    "a_id" : 'ID',
    "a_email" :"E-mail",
    "a_priceid" : "Plan", 
    "a_sid" : "Service", 
    "a_remain" : "Remain",
    "a_startdate" : "Start date",
    "a_enddate" : "End date",
    "a_status" : "Status", 
    "a_userid" : "User ID",
    "a_username" : "Nane", 
    "a_price" : "Price" ,
    "a_pricevat" : "Taxe",
    "a_recurrent" : "Recurrent", 
    "a_firstname":"First name",
    "a_lastname" :"Last name",
    "a_procpny":"Company",
    "a_protype": "Type", 
    "a_totnbads": "Ann#", 
    "a_title":"Tittle",
    "a_catid":"CatID", 
    "a_hits":"Hits",
    "a_severity":"Sev.",
    "a_date":"Date",
    "a_whatid" : "ID",
    "a_what":"What?", 
    "a_action":"Action",
    "a_cattitle":"Tittle",
    "a_adtitle":"Tittle",
    "a_desc" : "Description",
    "a_state" : "State",
    "a_position":"Position", 
    "a_clicks":"Clicks #", 
    "a_CTR":"CTR", 
    "a_impressions" : "Imp.",
    "a_registerdate" : "Registered",
    "a_paymentdate" :"Date", 
    "a_transactionid":"ID transac.", 
    "a_paymentstatus":"Payment status", 
    "a_amt":"Amount", 
    "a_displayinvoiceaction" : "Details" ,
    "a_auth" : "Autent.", 
    "a_lastvisitdate" : "Last. visite", 
    "a_gender" : "Genrer", 
    "a_locale" : "Languege",
    "a_priority" : "Priority",
    "a_prosiret" : "Siret",
    "a_prowebsite" : "Website",
    "a_loccity" : "City",
    "a_locdept" : "Dept.",
    "a_locregion" : "Region.",
    "a_loczipcode" : "Zip code",
    "a_loclatlng" : "GPS coord.",
    "a_plan" : "Plan",
    "a_links" : "Links",
    "a_indir" : "In directory?",
    "a_phone" : "Phone",
    "a_phone2" : "Phone2",
    "a_email2" : "E-mail 2",
    "a_expiredate" : "Expire by",
    "a_banclicks" : "Click ban.",
    "a_newsletter" : "Newletter",
    'a_ip' : 'IP@',
    'a_order' : 'Or.', 

    "a_val" : "Val",
    "a_%val" : "%",
    "a_adsnb" :"#", 
    "a_%adsnb" :"%", 
    "a_metrics" :"#",
    "a_%metrics" : "%", 
    "a_nbusers" : "#",
    "a_%nbusers" : "%",


    "select_fields" : "Select fields", 
    "fields selection save & refresh" : "fields selection save & refresh", 
    "fields selection reset" : "fields selection reset", 


    // adult category disclamers 
    "ADULT-CATEGORY-DISCLAMER":
    "<strong>Dans cette cat</strong>é<strong>gorie, vous devez avoir plus de 18 ans et accepter les points suivants:</strong><br><br><span class='normal'><strong>1.</strong> J'ai au moins 18 ans. <br>         <br>         <strong>2.</strong> Je comprends la teneur potentiellement choquante des annonces          placées pour Adultes.<br>         <br>         <strong>3.</strong> Le contenu choquant ne m'offense pas.<br>         <br>         <strong>4.</strong> Je prends connaissance et accèpte la possibilité d'une modération de la part de l'équipe du site sur l'usage de certains mots pré-définis et laissés à l'entière discrétion des administrateurs.<br>         <br>         <strong>5.</strong> En cliquant sur le bouton <strong><span style='cursor: text; text-decoration: none'><font color='#cc0000'>'J'accepte'</font></span></strong> ci-dessous, je libère et décharge les fournisseurs d'accès, propriétaires et créateurs du site de toute responsabilité quant au contenu et à l'utilisation faite de cette section.<br> <br> N'hésitez pas à consulter nos </span><a href=''>conditions d'utilisation</a>",  

    "desc_adultflag"  : "Cat. Adulte", 
    "help_adultflag" : "Si coché, cette catégorie est reservée aux adultes et les annonces ne seront visibles qu'aprés acceptation des conditions.", 

    "title_ADULT-CATEGORY-DISCLAMER": "Avis de non-responsabilité", 
    "dialog disclamer accept" : "YES I'accepte", 
    "dialog disclamer refuse" : "NO, I refuse", 

    "desc_legal" : "Legal", 
    "desc_cookiename":"Cookie Prefixe",
    "desc_cookie_duration_adult_disclamer":"Durée Cookie Adulte",
    "desc_filter_adult_in_list":"Filter Cat. adultes",

    "help_cookiename":"Prefixe du Cookie qui sera utilisé pour sauvegarder sur le poste client des informations",
    "help_cookie_duration_adult_disclamer":"Durée Cookie Adulte : Durée en JOURS de persistance du cookie utilisé pour accepter les catégories adultes.",
    "help_filter_adult_in_list":"Filter Cat. adultes : quand le visiteur n'a pas accepté les conditions d'accés aux catégories ADULTES, les annonces ADULTES sont sont pas visibles.",


    // liens sur annonce et annonceurs
    "ad links" : "Links (url)", 
    "links" : "Links (url)",
    "desc_links_on_ad": "Links on ads",
    "desc_links_on_user": "Links on user",
    "help_links_on_ad": "Liens annonce : autoriser la saisie de liens webs vers d'autres sites. Indiquez le nombre max. Mettre 0 (zero) pour interdire",
    "help_links_on_user": "Liens usager : autoriser la saisie de liens webs vers d'autres sites. Indiquez le nombre max. Mettre 0 (zero) pour interdire",

    "List of links" : "Links", 
    "desc_newsletter" : "Newsletter", 
    "help_newsletter" : "Newsletter", 
    "I subscribe" : "I subscribe", 
    "desc_user_enable_newsletter" : "Newsletter subscription" ,
    "help_user_enable_newsletter" : "Abonnement newsletter : proposer l'abonnement à la newsletter lors de l'enregistrement" ,

    "desc_pictures" : "Pictures",
    "desc_img_zoom_en" : "Zomm on pictures", 
    "help_img_zoom_en" : "Zoom sur Images : permet d'activer un zoom sur les images affichées lorsque la souris passe au-dessus. La fonction de Auto-swipe doit etre DESACTIVEE.", 

    "desc_paid_options" : "Options payantes", 
    "desc_paid_options_price_free" : "Forcer TOUT gratuit", 
    "help_paid_options_price_free" : "Force toutes les options en GRATUIT tant que ce paramétre est activé", 

    "desc_other_payments" : "Moyens de paiements (BETA)",
    "desc_payment_method" : "Methode", 
    "help_payment_method" : "Ne pas utiliser pour l'instant !", 
    "desc_payment_manual_mode" : "Mode Manuel", 
    "help_payment_manual_mode" : "Mode manuel de paiement = lors de l'achat d'une option ou un abonnement, l'administrateur doit valier la publication s'être assuré manuellement que le paiement a été effectué par tout moyent (cash, chéque, ...) ",


    "desc_general field for ad" : "Champs Annonces", 
    "desc_ad vtags"  : "Etiquettes PERSO", 
    "desc_price_field_disable" : "Desactiver champ PRIX", 
    "desc_price_field_expression" : "Expression PRIX",
    "desc_vfields_display_hide_zerovalue" : "Cacher valeur NULL", 
    "help_price_field_disable" : "Desactiver le champ prix générique et utiliser l'expression ci-dessous.", 
    "help_price_field_expression" : "Expression PRIX : permet de remplacr le champ prix affiché ar une expression basée sur les champs virtuels. exemple : [VFIELD=18][ - ][VFIELD=19][ ][CURRENCY]",
    "help_vfields_display_hide_zerovalue" : "Cacher lors de l'affichage les champs viruels qui ont une valeur nulle ou zero.", 

    "desc_main_content_width_short_en" : "*FU ** Largeur reduite",
    "help_main_content_width_short_en" : "Spécifie un affichage de liste en utilisant une largeur réduite de la zone principale. ",

    "help_vtags_labels" : "Etiquettes apposées sur les annonces", 

    " Room." : " Room.", 
    " Peop." :" Peop.",
    " m2": " m2",

    // messages lors du login
    "account expired" : "account expired",
    "reactivate account" : "reactivate account",
    "account reactivated" : "account reactivated",
    "log_reactivate_PUBLISHED" : "Reactivated", 
    "desc_account_reactivate_en" : "reactivate expired accounts",
    "help_account_reactivate_en" : "Réactivation Comptes expirés  : l'usager lors de la connection est notifié et peut demander une réactivation de son compte. Il recoit en retour un email avec un nouveau mot de passe et son compte est de nouveau actif.",  

    // mise a jour traductions sur logs
    "log_auth_account reactivated" : "Demande de réactivation de compte", 
    "log_auth_account expired" : "Accés avec un compte expiré", 
    "access denied - bad password" : "Accés refusé - erreur de mot de passe", 

    // new ADMIN options 
    "desc_invoice_number_format" : "Format N° facture", 
    "help_invoice_number_format" : "Format N° facture : indiquez ici le format du numero automatique de facture. Les champs spéciaux autorisés sont [TIMESTAMP], [WHAT] et [ID] ",
    "desc_vtag1_en" : "Tags Virtuel 1", 
    "desc_vtag2_en" : "Tags Virtuel 2", 
    "desc_vtag3_en" : "Tags Virtuel 3", 
    "desc_vtag4_en" : "Tags Virtuel 4",
    "desc_vtag5_en" : "Tags Virtuel 5",

    "help_vtag1_en" : "Tags Virtuel 1 : permet de definir des champs en plus sur les annonces. Vous pouvez définir le nom via votre fichier personnel de traductions", 
    "help_vtag2_en" : "Tags Virtuel 2 : permet de definir des champs en plus sur les annonces. Vous pouvez définir le nom via votre fichier personnel de traductions", 
    "help_vtag3_en" : "Tags Virtuel 3 : permet de definir des champs en plus sur les annonces. Vous pouvez définir le nom via votre fichier personnel de traductions", 
    "help_vtag4_en" : "Tags Virtuel 4 : permet de definir des champs en plus sur les annonces. Vous pouvez définir le nom via votre fichier personnel de traductions",
    "help_vtag5_en" : "Tags Virtuel 5 : permet de definir des champs en plus sur les annonces. Vous pouvez définir le nom via votre fichier personnel de traductions",

    "desc_activate_text_scroll" : "Scroll texte",
    "help_activate_text_scroll" : "Scroll texte : en affichage en mode GALLERIE, permet de faire défiler le texte en overlay fonction des mouvements de la souris",
   
    "desc_dynamic_update_widgets" : "Mise à jour auto", 
    "help_dynamic_update_widgets" : "Mise à jour auto des widgets activées lors d'un changement de catégorie, région, pays, .. ", 

    "recurrent paiement" : "recurrent payment",
    "one-shot transaction" : "one-shot transaction",  
    "frecurrent" : "Recurrent", 

    // elements pour facture des abonnements récurrents
    "RECURRING PAIEMENT ID :" : "Payment ID :",
    "PROFILEID PRINT BUTTON" : "PRINT", 
    "PROFILE ID :" : "Profile ID : ", 
    "PROFILE STATUS :": "State : ", 
    "RECURRING PROFILESTARTDATE :": "Start: ", 
    "RECURRING BILLINGPERIOD :": "Billing period : ", 
    "RECURRING BILLINGFREQUENCY :": "Billing Frequency : ", 
    "RECURRING TOTAL AMOUNT :": "Amount : ", 
    "RECURRENT DESC :" : "Description : ", 
    "RECURRENT NEXTBILLINGDATE :" : "Next billing by : ",
    "BUYER RECURRENT TOP LABEL" : "Subscription confirmation", 
    "RECURRENT WHAT ID :":"Reference : ",

    // catalogue des options payantes et plans d'abonnements
    "desc_payoptions_enable" : "Activation globale", 
    "post paidplan_plan_1" : "Plan d'abonnement #1", 
    "post paidplan_plan_2" : "Plan d'abonnement #2", 
    "post paidplan_plan_3" : "Plan d'abonnement #3", 
    "post paidplan_plan_0" : "Plan d'abonnement #0", 

    "post plan_1" : "Plan d'abonnement #1", 
    "post plan_2" : "Plan d'abonnement #2", 
    "post plan_3" : "Plan d'abonnement #3", 
    "post plan_0" : "Plan d'abonnement #0", 

    "Get details directly from PAYPAL" : "et details directly from PAYPAL",
    "No entries in payments" : "No entries in payments",

    // new options for debug
    "desc_debug" : "Options de DEBUG/LOG", 
    "desc_debug_level" :  "Profondeur des logs",
    "desc_enable_trace_log" :  "Mesure temps execution",
    "desc_disable_translation" :  "Désactiver traductions",
    "desc_enable_debug_jstools" : "Outils JS de debug",
    "help_debug_level" :  "Quels types de messages ecrire dans le fichier SYSLOG ? : détermine quel types de messages doivent être écrits dans le fichier de debug/log - 7=ALL, 6=INFO, 5=NOTICE, 4=WARNINGS 3=ERRORS, 0=PANIC.",
    "help_enable_trace_log" :  "Mesaure et affiche pour chaque requéte AJAX les temps d'éxécution à travers le script",
    "help_disable_translation" :  "Désactiver les traductions permet de voir quel SPAN est utilisé en entrée du fichier de traduction.",
    "help_enable_debug_jstools" : "Outils Javascript de debug accessibles depuis le client",

    // ====== 6.1.2 ==============================================
    // welcome login text for users without ads
    "Welcome" :"Welcome", 
    "Welcome %s %s !" : "Welcome %s %s !", 
    "You don't have any ad yet. Do you want to create one ?" :"You don't have any ad yet. Do you want to create one ?",
    "Create my first ad" :"Create my first ad", 

    // lifecycle refactoring 
    "desc_ad life-cycle" : "Spécial Annonces",
    "desc_user life-cycle" : "Spécial Usagers",
    "desc_user_maxarchive_duration" : "Archive pendant", 
    "help_user_maxarchive_duration" : "Durée d'archive des usagers expirés.", 

    //livecheck
    "username already exist" : "username already exist", 
    "email already exist" : "email already exist",

    //protection côté serveur des validations d'annonces sur un pack "vide"
    "no tokens left on your subscribed services !" : "no tokens left on your subscribed services !", 

    //--tutoriels videos
    // lien dans le menu
    "myvideos" : "Tutorials",
    // nom du breadcrumb   
    "bread_zetvu_as_video" : "Tutorials", 
    "all zetvu_as_video" : "All tutorials", 
    "all my_zetvu_as_video" : "All tutorials",
    "all admin_zetvu_as_video" : "All les tutorials",
    "bread_zetvu_as_news" : "News", 
    "all zetvu_as_news" : "All News", 
    "all my_zetvu_as_news" : "All News",
    "all admin_zetvu_as_news" : "All News",
    "zetvu" : "Zetévu",
    "all zetvu" : "All Zetévu",  

    // barre principale de navigation 
    "nav_zetvu_as_video" : "Tutorials", 
    "nav_zetvu_as_news" : "News", 

    //create button 
    "create_zetvu_as_video" : "Post a tutorial", 
    "create_zetvu_as_news" : "Post a news", 

    // entete de la zone de creation
    " zetvu_as_video form header title" : "Créer votre tutorial", 
    " zetvu_as_video form header introduction" : " ", 
    " zetvu_as_news form header title" : "Créer votre nouvelle", 
    " zetvu_as_news form header introduction" : " ", 
    "modify zetvu_as_video form header title" : "Modifier un tutorial", 
    "modify zetvu_as_video form header introduction" : " ", 
    "modify zetvu_as_news form header title" : "Modifier une nouvelle", 
    "modify zetvu_as_news form header introduction" : " ", 

    // configuration
    "desc_zetvu_as_video_tuto" : "Mode VIDEOS tutos", 
    "help_zetvu_as_video_tuto" : "Mode VIDEOS tutos : dans ce mode, un champ video est disponible pour ajouter de viedos youtube ou autre. Elles sont alors affichées en mode gallerie",
    "desc_zetvu_visible_acl" : "Visible pour...",
    "help_zetvu_visible_acl" : "Niveau de control d'accés de visibilité des zetevu. 0=visible par tout le monde, 1=les utilisateurs enregistrés",

    // hover sur carte
    "This location has %s ad" : "%s annonce", 
    "This location has %s ads" : "%s annonces", 

        // hover sur carte
    "This location has %s user" : "%s annonceurs", 
    "This location has %s users" : "%s annonceurs", 

    // email direct en utilisant le client natif du PC/MAC 
    "Direct Mail - title - I want to have more information" : "Je souhaiterais plus d'information sur votre annonce", 
    "Direct Mail - body header - I want to have more information on element : " : "Je souhaiterais plus d'information sur l'annonce : ", 
    "Direct Mail - body footer - I want to have more information on element." : "[entrer ici votre texte complémentaire] ", 
 
    // contact form 
    "contact_form_firstname" : "Prénom ", 
    "contact_form_lastname" : "Nom ", 
    "contact_form_phone" : "Téléphone ", 

    // new label forpassword change title 
    "desc_passwordchange" : "Mot de passe", 
    "modify my password" : "modifier", 

    // now notification status 
    "You have services that will expire soon please consider buying new services " : "Attention, votre pack découverte va bientôt expirer, ",

    // bouton create primiéres annonce dans services
    "Create first ad" : "Déposer une annonce", 

    //le à des dates 
    " by " :" à ",
    "help_disp_prosiret" : "Numero de SIRET",

    // filters 
    "-- all protype --" : "-- type --", 
    "Sort by priceid asc" : "Tier par nom du Plan (prix)",

    // traduction dédiée pour les "no results"
    "No items found - No ad - admin_all" : "Aucune annonce",
    "No items found - No ad - draft" : "Aucune annonce en brouillon",
    "No items found - No ad - published" : "Aucune annonce publiée",
    "No items found - No ad - pending" : "Aucune annonce en attente",
    "No items found - No ad - willexpire" : "Aucune annonce à expiration prochaine",
    "No items found - No ad - draft pending payment" : "Aucune annonce en attente de paiement", 
    "No items found - No ad - deleted_expired" : "Aucune annonce expirée",
    "No items found - No ad - deleted" : "Aucune annonce expirée",
    "No items found - No ad - admin_pending" : "Aucune annonce à valider",
    "No items found - No ad - admin_underreview" : "Aucune annonce à valider",
    "No items found - No ad - admin_under review" : "Aucune annonce à valider",
    "No items found - No ad - admin_willexpire" : "Aucune annonce à expiration prochaine",
    "No items found - No ad - admin_expired" : "Aucune annonce expirée",
    "No items found - No ad - admin_deleted" : "Aucune annonce expirée",
    "No items found - No ad - admin_published" : "Aucune annonce publiée",
    "No items found - No ad - admin_draft" : "Aucune annonce en brouillon",
    "No items found - No ad - admin_pending" : "Aucune annonce à valider",
    "No items found - No ad - admin_draftpendingpayment" : "Aucune annonce en attente de paiement",
    "No items found - No ad - admin_draft pending payment" : "Aucune annonce en attente de paiements", 
    "No items found - No ad - admin_willexpire" : "Aucune annonce à expiration prochaine",
    "No items found - No ad - admin_expired" : "Aucune annonce expirée",
    "No items found - No ad - admin_rejected" : "Aucune annonce rejetée",
    "No items found - No ad - admin_unpublished": "Aucune annonce retirée de la publication",

    "desc_robot_name" : "Nom ROBOT", 
    "help_robot_name" : "Nom à afficher lorsque'un action a été effecturée par un batch automatique du site", 


    // probanner url 
    "desc_probannerurl" : "Banniére (URL click)",
    "help_probannerurl" : "URL du site de destination quand on clique sur la banniére. Si 'vide', on utilise l'adresse du site web",

    "Are you sure you want to leave this form ?": "Are you sure you want to leave this form ?", 
    "warning" : "Warning", 


    // new configurable options
    "desc_site_off_line" : "Site OFF-LINE", 
    "help_site_off_line" : "Mettre le site principal off-line. le back-end d'administration reste fonctionnel et les visiteurs sont redirigés vare une page statique 'offline_{langue}.php'. ", 
    "desc_sitemap_publishing_en" : "Auto-publication SITEMAP", 
    "help_sitemap_publishing_en" : "Publication automatique (PUSH) vers les principaux CRWALERS du web", 
    
    "desc_list_viewmodes" : "Mode d'affichage des listes", 
    "desc_simple_list_view_en" : "Liste simple ", 
    "help_simple_list_view_en" : "Liste simple des annonces sans Image", 
    "desc_video_list_view_en" : "Lister 'par VIDEOS'", 
    "help_video_list_view_en" : " ", 
    "desc_audio_list_view_en" : "Lister 'par AUDIOS'", 
    "help_audio_list_view_en" : " ", 
    "desc_gmap_list_view_en" : "Lister sur CARTE GMAP", 
    "help_gmap_list_view_en" : " ", 
    "desc_gallery_list_view_en" : "Lister GALLERIE", 
    "help_gallery_list_view_en" : " ", 

    "Show Video Gallery" : "Show elements with a video",

    "list filter on videogallery is ON" : "Attention, ne sont affichées que les annonces avec une video", 


    // champs pour les locations 
    "elem calendar" : "Prix et disponibilités ", 
    "Display elem calendar" : "Afficher les prix et disponibilités",
    "calendar list header text" : "Liste des réservations : ", 
    "Last updated:" : "Mise à jour:",
    "Create bookings" : "Ajouter une réservation", 
    "No entries in bookings" : "Aucune réservation pour l'instant", 

    "a_bo_moddate" : "Date",
    "a_bo_name" : "Titre",
    "a_bo_lastname" : "Loueur",
    "a_bo_start_date" : "Début",
    "a_bo_end_date" : "Fin",
    "a_bo_title" : "Libellé",

    " bookings form header title" : "Créer une réservation", 
    "modify bookings form header title" : "Modifier une réservation", 
    "bookings delete confirmation" : "Suppression de la réservation ?", 

    "booking details" : "Détails pricipaux", 
    "desc_bo_title" : "Libellé", 
    "help_bo_title" : "Un libellé pour s'y retrouver", 
    "desc_bo_start_end_date" : "Dates de début et fin", 
    "placeholder_bo_start_date" : "Début", 
    "placeholder_bo_end_date" : "Fin", 
    "desc_bo_nbadults": "Nbr personnes", 
    "booking user details" : "Détails sur le loueur",
    "desc_bo_gender" : "Genre",
    "desc_bo_comments" : "Commentaires",
    "desc_bo_ad_id" : "Ref#de l'annonce", 
    "help_bo_ad_id" : "ID de l'annonce à laquelle cette réservation est associée", 
    "desc_bo_moddate" : "Derniére modification", 
    "booking other details"  : "Autre information", 

    // admin
    "manage_bookings" : "Réservations",
    "manage_bookings_pending" : "A valider", 
    "help_manage_bookings" : "Gestion des Réservations",
    "bookings creation ongoing": "Réservation en cours de création :",
    "allbookings" : "Réservations", 
    "all bookings": "Réservations (toutes)",
    "a_bo_ad_id" : "ID annonce", 

    // "The start date can not be greater then the end date" : "La date de début ne peut pas être plus grande que la date de fin", 
    // "The end date can not be before the start date" : "La date de fin ne peut pas être antérieure à la date de début", 


    // settings pour le mode location
    "desc_rental mode" : "Mode Location", 
    "desc_rental_mode_en" : "Activer le mode", 
    "desc_calendar_auto_load" : "(CAL) Chargement auto.", 
    "desc_calendar_disable_before" : "(CAL) Dévalider jours AVANT", 
    "desc_calendar_week_start_day" : "(CAL) Jour de démarrage",
    "desc_cookie_save_calendar_nav" : "(CAL) Cookie mois",
    "desc_admin_acl_only_admin" : "Admin pour admin", 
    "desc_calendar_rolling_months": "Nombre mois affichés", 

    "help_rental_mode_en" : "Activer le mode location = affichage d'un calendrier de réservations", 
    "help_calendar_auto_load" : "(CAL) Chargement automatique des disponinilités", 
    "help_calendar_disable_before" : "(CAL) Dans le calendrier, les jours avant le jour courant sont dévalidé", 
    "help_calendar_week_start_day" : "(CAL) Jour de démarrage du calendrier (1=Lundi) ",
    "help_cookie_save_calendar_nav" : "(CAL) Suit la navigation du visiteur avec un cookie pour sauvegarder ses préférences de calendrier",        
    "help_admin_acl_only_admin" : "Le site d'administration est accessible uniquement pour les utilisateurs au profil ADMIN", 
    "help_calendar_rolling_months": "Nombre mois affichés", 


    // "Admin site is not authorized to non admin people" : "Ce site d'administration n'est pas accessible aux personnes non autorisées comme vous !",     
    // "Not authorized" : "Non autorisé", 

    // debuf options in settings 
    "desc_debug_file" : "Fichier de LOG/DEBUG", 
    "help_debug_file" : "Gestion du Fichier de LOG/DEBUG", 
    // "clear debug file" : "Effacer le contenu", 
    // "open debug file" : "Voir le fichier", 
    // "Error writing to the debug file":"Error lors de l'accés au fichier de debug/log", 
    // "File cleaned successfully":"Fichier effacé.", 


    // options pour FEEDBACK form 
    "feedback reason" : "Raison",
    "Fraud":"Fraud",
    // "Wrong category":"Mauvaise catégorie",
    // "Expired ad":"Annonce expirée",
    // "Other":"Autre",

    // special login form 
    "Login with third party credentials" : "Login with  ", 
    "facebook login":"Login with Facebook", 
    "google login":"Login with Google", 
    "twitter login":"Login with Twitter", 
    "linkedin login":"Login with LinkedIn", 
    "login or" : " or ",

    "auth-type-go" : "Google", 
    "auth-type-fb" : "Facebook", 
    "auth-type-tw" : "Twitter", 
    "auth-type-" : "Local", 

    "login_lostpassword": "Forgot password ?",
    "login_createaccount": "Not yet an account ?",
    "login_rememberme" : "Remember me",

    " user form header oauth " : "Vous pouvez vous identifier à partir de ",
    "oauth register with facebook" : "You account FACEBOOK", 
    "oauth register with google" : "You account GOOGLE", 
    "oauth register with linkedin" : "You account LINKEDIN", 
    "oauth register with twitter" : "You account TWITTER", 

    "google account" : "GOOGLE account",
    "facebook account" : "FACEBOOK account", 
    "twitter account" : "TWITTER account", 
    "linkedin account" : "LINKEDIN account",  
 

    // "This form has been pre-filled with inputs from your " : "La formulaire a été pre-rempli avec les données de votre ", 

    "desc_social_sharing":"Réseaux sociaux",
    "desc_fb_integration":"Widget LIKE Facebook",
    "desc_fb_url":"URL FACEBOOK",
    "desc_fb_auth":"Autent. FACEBOOK",
    "This form has been pre-filled with inputs from your": "Le formulaire a été renseigné avec les données de votre ", 

    "help_social_sharing":"Indique la liste des réseaux sociaux pour le bouton 'partager sur' au niveau des annonces ou annonceurs. Mettre un + entre chaque element. Codes : TW=TWITTER, FB=FACEBOOK, GO=GOOGLE+, LK=LINKEDIN, PI=PINTEREST, EV=EVERNOTE, DE=DELICIOUS ",
    "desc_facebook_settings" : "FACEBOOK configuration", 
    "help_fb_integration":"Intégration du widget Like de FACEBOOK sur la page d'accueil. Renseigner l'URL facebook ci-dessous obligatoirement",
    "help_fb_url":"URL du compte FACEBOOK",
    "help_fb_auth":"Permettre une connection au site par une autentification FACEBOOK. ATtention, necessite de déclarer l'application auprés de facebook et renseigner l'application-id dans le champ ci-dessous.",
    "desc_fb_appid" : "Application_ID", 
    "help_fb_appid" : "Application_ID = utilisé lorsque vous activez l'autentification via facebook comme identifiant de votre application. Réserver un App-ID via la console Facebook developpers.", 

    "desc_google_settings" : "GOOGLE configuration", 
    "desc_go_client_id" : "CLIENT_ID", 
    "help_go_client_id" : "CLIENT_ID = utilisé lorsque vous activez l'autentification via Google API comme identifiant de votre application. Réserver un App-ID via la console GOOGLE API.", 
    "desc_go_auth":"Autent. GOOGLE",
    "help_go_auth":"Permettre une connection au site par une autentification GOOGLE. Attention, necessite de déclarer l'application auprés de GOOGLE et renseigner le client-id dans le champ ci-dessous.",

    "desc_twitter_settings" : "TWITTER configuration", 
    "desc_tw_appid" : "API Key", 
    "help_tw_appid" : "API Key = utilisé lorsque vous activez l'autentification via TWITTER API comme identifiant de votre application.", 
    "desc_tw_auth":"Autent. TWITTER",
    "help_tw_auth":"Permettre une connection au site par une autentification TWITTER. Attention, necessite de déclarer l'application auprés de TWITTER et renseigner le API-id dans le champ ci-dessous.",
    "desc_tw_secret":"API secret",
    "help_tw_secret":"API secret key",

    "desc_linkedin_settings" : "LINKEDIN configuration", 
    "desc_lk_appid" : "API Key", 
    "help_lk_appid" : "API Key = utilisé lorsque vous activez l'autentification via LINKEDIN API comme identifiant de votre application.", 
    "desc_lk_auth":"Autent. LINKEDIN",
    "help_lk_auth":"Permettre une connection au site par une autentification LINKEDIN. Attention, necessite de déclarer l'application auprés de LINKEDIN et renseigner le API-id dans le champ ci-dessous.",
    "desc_lk_secret":"API secret",
    "help_lk_secret":"API secret key",

    "desc_disable_localization_validation"  : "Désactiver contrôles", 
    "help_disable_localization_validation"  : "Désactiver les contrôles liés à la localisation des champs PHONE, ZIP-CODE, ...", 

    "desc_scroll_top_px" : "Scroll top", 
    "help_scroll_top_px" : "En pixels, contrôle la hauteur de remontée de la page lors d'un re-centrage vertical automatique.", 

    "desc_hascalendar" : "Calendrier de location",
    "help_hascalendar" : "Associer à toutes les annonces de cette catégorie un calendrier de réservation. Attention, l'option 'LOCATION' doit être activée! ", 

    "pics" : "Pics",
    "a_parentid":"Parent", 
    "a_adultflag" : "adult?" ,
    "a_catlvfields" : "Fields", 
    "a_hascalendar" : "Cal.", 

    "all cats" : "all cats", 
    "Create cats" : "Create cats", 

    "admin_cat_type_ad":"Annnonce uniq.", 
    "admin_cat_type_user":"Usagers uniq.",
    "admin_cat_type_":"Tous",

    "admin_ad_type_sell":"vend",
    "admin_ad_type_buy":"demande",
    "admin_ad_type_zetvu":"news/zetvu",

    "desc_desc_max_char" : "Desc. MAXCHARs", 
    "help_desc_max_char" : "Nombre maximum de caractères (max 1500) du champ description.", 

    "desc_rental_mode_all_cat" : "Sur toutes les annonces", 
    "help_rental_mode_all_cat" : "Si activé, toutes les annonces posséde un calendrier et le mode location. Si désactivé, il faut renseigner au niveau de CHAQUE catégorie le mode calendrier. ", 


    "desc_user_no_expiration_for_admin" : "ADMIN never axpire",
    "help_user_no_expiration_for_admin" : "ADMIN account will never expire",  

        //6.5.0 
    "upload audio file" : "Select an audio file", 
    "upload image file" : "Select a picture", 

    "Show Audio Gallery" : "Show elements with audio media",
    "list filter on audiogallery is ON" : "list filter on audiogallery is ON", 

    "Your browser does not support the audio element." : "Your browser does not support the audio element.", 
    "title audiourl" : "Audio message", 
    "title audiourl user" : "Audio message",
    "play/pause" : "play/pause", 
    "volume up/down/mute" : "volume up/down/mute",
    "next track" : "next track",  
    "Click to play/stop : %s" : "Click to play/stop : %s", 

    "desc_audiourl" : "Audio message(s)",
    "help_audiourl %s" : "You can ad %s message(s) in WAV or MP3 format.", 


    "desc_audio settings" :"Champs audio / vocal",
    "desc_audio_ad_en" :"Activer sur annonce",
    "desc_audio_user_en" :"Activer sur usager",
    "desc_audio_file_max_size" :"Taille max/audio",
    "desc_audio_file_max_nbr" :"Nbr max audio",
    "desc_audio_file_ext" :"Extensions",
    "desc_audio_file_download" :"Téléchargement?",
    "desc_audio_autoplay" :"Jouer automatiquement",
    "desc_audio_rec_online" :"Enregistrement",
    "desc_audio_rec_max_duration" :"Enreg. durée",
    "desc_audio_rec_ext" :"Enrge. extension",


    "help_audio_ad_en" :"Activer sur annonce : permettre l'ajout de medias audios sur une annonce.",
    "help_audio_user_en" :"Activer sur usager : permettre l'ajout de medias audios sur une annonce.",
    "help_audio_file_max_size" :"Taille max de chaque média audio chargé sur le site.",
    "help_audio_file_max_nbr" :"Nbr max de media audio par annonce ou usagers.",
    "help_audio_file_ext" :"Extensions autorisées des médias audios chargés.",
    "help_audio_file_download" :"Afficher un bouton qui permet au visiteur de téléchargement le fichier audio.",
    "help_audio_autoplay" :"Jouer automatiquement lors de l'affichage de l'annonce/annonceur.",
    "help_audio_rec_online" :"Enregistrement en ligne de messages audio. ",
    "help_audio_rec_max_duration" :"Durée max en secondes de l'enregistrement en ligne.",
    "help_audio_rec_ext" :"Format du fichier enregistré en ligne.",


    "desc_watermark" :"Filigrane sur images",
    "desc_watermark_en" :"Activer",
    "desc_watermark_file_url" :"URL du Filigrane",
    "desc_watermark_free_text" :"Text libre",
    "help_watermark_en" :"Activer l'ajout de filigrane (watermark) sur les images chargées sur le site.",
    "help_watermark_file_url" :"URL du Filigrane : url d'un fichier PNG ou autre qui sera utilisé comme filigrane. Attention, lechemin est relatif au repertoire /phpsvr. exemple d'URL valide = ../uploads/files/xxx.png",
    "help_watermark_free_text" :"Text libre qui sera utilisé en filigrane (si pas d'URL renseignée ci-dessus). ",


    // securedemail and phone numbers 
    "see the email" : "Voir l'adresse email", 
    "see the phone" : "voir le numero", 
    "desc_email_as_image_en" : "Email en image", 
    "desc_phone_as_image_en" : "Tél. en image", 
    "help_email_as_image_en" : "ANTI-SPAM : Email en image : l'email de l'annonceur est affiché comme une image et non un texte", 
    "help_phone_as_image_en" : "ANTI-SPAM : Tél. en image  : le teléphone  de l'annonceur est affiché comme une image et non un texte", 


    "footer title to add services" : "footer title to add services", 
    "footer text to add services" : "footer text to add services",

    // new menus 
    "gotoadmin" : "Administration", 
    "gotosite" : "Voir le site", 

    // free texte onsubscribtions / packs 
    "settings_free_texts" :"Textes libres", 
    "settings_free_text1" :"Texte 1", 
    "settings_free_text2" :"Texte 2", 
    "settings_free_text3" :"Texte 3", 

    "desc_social_connect_general" : "Social Login",
    "desc_oauth_sso_en" : "Activer oauth", 
    "desc_oauth_auto_create_user" :"Creation auto accés", 
    "help_oauth_sso_en" : "Activer la connection SOCIAL pour accéder au site via les réseaux sociaux ci-dessous.", 
    "help_oauth_auto_create_user" :"Creation automaique des comptes usagers sans passer par l'enregistrament. Attention, pas compatible avec les plans d'abonnements", 


    //6.5.1
    "Thanks you for your payment %s %s ! Your service is activated." : "Merci pour votre achat %s %s , votre pack de service est activé.", 
    "desc_cust_cookie_url" : "Cookies (url)", 
    "help_cust_cookie_url" : "Lien (utl) ver page Cookies", 
    // nom du lien en bas de page 
    "Cookies" :"Cookies", 

    "desc_list_default_view" : "Vue par défaut", 
    "help_list_default_view" : "vue par défaut lors de l'affichage des listes d'annonces. Les valeurs possibles sont   : list | simplelist  | gallery  | videogallery | audiogallery | maplist  ",

    "desc_cookie_display_cookies_disclamer": "Avertissement cookies", 
    "help_cookie_display_cookies_disclamer": "Affiche un message d'avertissement legal sur les cookies lors de la premiére visite", 
    "Cookies policy disclamer": "En poursuivant votre navigation sur ce site, vous acceptez l'utilisation de cookies nécessaire au bon fonctionnement du site. <a class='cookiesWarning-link' href='cookies_fr_zads.php' target='_blank'>Plus d'informations sur notre politique « cookies ».</a> <i class='close icon-fa-times-circle mr6'></i>",

    // sysem messages displayed in ADMIN
    "SYS - delete install.php":"Thank you to delete <strong>install.php</strong> file for security reason.", 
    "SYS - debug mode and level > 3 if active" : "Debug mode is active with a high level (>3) of details. Security risk.",

    //6.5.3 
    "desc_dis_ad_loc" : "Pas de Locat. AD", 
    "help_dis_ad_loc" : "Désactiv. la saisie de la localisation pour les annonces.", 
    "desc_dis_user_loc" : "Pas de Locat. USER", 
    "help_dis_user_loc" : "Désactiv. la saisie de la localisation pour les usagers.", 

    "desc_user_cat2" : "Type d'activité", 
    "desc_cat2" : "Activité", 

    "desc_advs_no_freetext" : "Pas champ recherche",
    "help_advs_no_freetext" : "Le champ de recherche libre est masqué",

    "desc_advs_forced_vfields" : "Ajouter toujours vfields ..", 
    "help_advs_forced_vfields" : "Ce mode permet d'afficher de champs VFIELDS systématiquement sur la barre de recherche. format = idA|idB|idC", 

    
    "desc_nav_no_bar" : "Pas be barre de nav.",
    "help_nav_no_bar" : "Mode expert ! pas de barre de navigation principale. Pas compatible avec un affichage de carte ou de pages spéciales !",

    "desc_maincat_user_pid" : "Nav User per PID", 
    "help_maincat_user_pid" : "Mode expert !  : la barre de navigation affichant les usagers est découpée fonction des catégories users de niveau 1.", 

    "%s room" : "%s room", 
    "%s rooms" : "%s rooms", 

    "filtered : %s" : "filtered : %s", 

    "desc_seo_forced_vfields" : "SEO champs virtuels en plus", 
    "help_seo_forced_vfields" :"Liste (ID|ID|ID) des valeurs de champs virtuels à ajouter dans le META/SEO des annonces affichées. Seront ajoutés à la fin du TITLE et à la fin de la META DESCRIPTION",
    "desc_no_mobile_css" :"No mobile CSS",
    "help_no_mobile_css" :"Désactiver le théme mobile",

    "settings_ad_audiourl" : "Max fichiers audios", 
    "settings_ad_videourl" : "Max fichiers videos", 
    "ad_audiourl" : "Fichiers audios par annonce", 
    "ad_videourl" : "Fichiers videos par annonce",

    "settings_us_audiourl" : "Max fichiers audios", 
    "settings_us_videourl" : "Max fichiers videos", 
    "us_audiourl" : "Fichiers audios / profile", 
    "us_videourl" : "Fichiers videos / profile", 

    "desc_emails_admin_hourly_send" : "Notification horaire", 
    "help_emails_admin_hourly_send" : "Notification horaire", 
    "desc_en_ad_hits" : "Hits", 
    "help_en_ad_hits" : "Hits", 
    "desc_en_ad_likes" : "Likes", 
    "help_en_ad_likes" : "Likes", 
    "desc_en_user_hits" : "Hits", 
    "help_en_user_hits" : "Hits", 
    "desc_en_user_likes" : "Likes", 
    "help_en_user_likes" : "Likes", 

    // likes management
    "click to like it!" : "click to like it!",
    "Sort by likes desc" : "Sort by likes descending",

    "cannot upload more file : exceeded quantity" : "cannot upload more file : exceeded quantity", 

    "desc_reset_all_user_likes" : "Réinitialiser likes usagers",
    "help_reset_all_user_likes" : "Réinitialiser (remet à zero) le compteur de like de tous les usagers.",
    "desc_reset_all_ad_likes" : "Réinitialiser likes annonces",
    "help_reset_all_ad_likes" : "Réinitialiser (remet à zero) le compteur de like de toutes les annonces.",
    "reset_all_user_likes" : "Réinitialiser",
    "reset_all_ad_likes" : "Réinitialiser",


    "desc_page_php" : "Page home Externe (PHP)", 
    "desc_page_home_is_php" : "Activer", 
    "help_page_home_is_php" : "Si activé, la page d'accueil est chargée à partir de la page PHP ci-dessous.", 
    "desc_page_home_php_url" : "Url de la page externe",
    "help_page_home_php_url" : "Url de la page externe contenant le contenu PHP a charger sur la page d'accueil",

    //Z6.5.6 -> multi-medias elemnts 
    "media booth h1 - audio_recording" : "Medio booth", 
    "media booth into - audio_recording" : "Record you audio message here", 
    "visu in title" : "Input : waves", 
    "visu out title" : "Output", 
    "record" : "Record now",
    "recording"  : "Recording ongoing - stop", 
    "rec play" : "listen to the recording", 
    "(rec playing) stop" : "(playing) - Stop", 
    "rec download" : "Download to my PC",
    "rec save" : "Save into ad",

    "media booth h1 - picture_snap" : "Photo Booth", 
    "media booth into - picture_snap" : "Snapshot your picture here", 
    "take screenshot" :"Take picture",
    "video in title" : "Input : video", 
    "video out title" : "Your picture",
    "snap effect" : "Apply effect", 
    "snap download" : "Download to my PC",
    "snap save" : "Save into ad",

    "effect_nornal":"nornal", 
    "effect_sepia":"sepia", 
    "effect_brightness":"brightness", 
    "effect_contrast":"contrast", 
    "effect_desaturate":"desaturate", 
    "effect_grayscale":"grayscale", 
    "effect_threshold":"threshold", 
    "effect_noise":"noise", 
    "effect_invert":"invert", 

    "audiourl record now" : "Record in live",
    "filename record now" : "Take a picture",
    "avatarimg record now" : "Take a picture",
    // "no more space left to save the recorded element" : "Vous ne pouvez pas enregistrer car vous avez depassé le numbre max d'éléments.", 

    // "If you reject access to your local media, this feature cannot be used. Bye." : "Vous avez refusé l'accés à vos médias. Cette fonction ne peut pas être utilisée. Bye",
    // "This capability (getUserMedia) is not supported in your browser" : "Cette fonctionnalité n'est pas disponible sur ce navigateur. Prendre CHROME ou FIREFOX derniére version",

    "desc_picture_rec_online" : "Capture Photos", 
    "help_picture_rec_online" : "Permetter aux annonceurs de capturer des photos directement depuis le navigateur (si il est compatible web RTC, c'est à dire CHROME et FIREFOX)", 
    "desc_general fields" : "Champs communs / image",
    "desc_authorized_languages" : "authorized languages",

    // "No entries in banners" : "Pas de publicités pour l'instant.",

    // Z6.5.6
    "payment" : "payment", 
    "all my_favs_ad" : "My favorites ads",
    "watermark_pos_topright":"En haut à droite", 
    "watermark_pos_topleft":"En haut à gauche", 
    "watermark_pos_bottomright":"En bas à droite", 
    "watermark_pos_bottomleft":"En bas à gauche", 
    "desc_watermark_pos":"Position", 
    "desc_watermark_test_it":"Testeur", 
    "watermark_test_it":"Tester le watermark", 
    "Sample image with watermark in position : " : "Image d'essai avec le filigrane en position : ", 

    // Z6.5.7
    "Call us now!" : "Call us now!",
    "desc_cust_contact_phone"  : "Phone",
    "help_cust_contact_phone"  : "Numéro de téléphone qui sera affiché avec un tel: en bas de page. Préférez un numérotcanonique internationnal de type +33 4455666 pour plus de compatibilité.",
    "a_pricetype" : "Price?", 
    "cat pricetype" : "Allow price ?", 
    "help cat pricetype" : "Indique si, pour cette catégorie, le champ prix est affiché ou pas. Permet d'interdire la saisie des prix pour toutes les annonces de cette catégorie", 
    "no price" : "no price", 
    "pricetype default" : "Yes", 
    "Cancel pack" : "Cancel pack",
    "service cancellation ongoing" : "service cancellation ongoing", 

    "filter per user id" : "Filtrer par ID usager", 
    "admin_services_type_trial" :"TRIAL", 
    "admin_services_type_base" :"BASE", 
    "admin_services_type_" :"----", 
    "admin_services_type_pack" :"PACK", 
    "settings_radio_pack" : "Service", 

    "service cancel dialog title" : "Pack cancellation", 
    "Confirm delete of service :" : "Confirm cancellation of this pack :",

    "desc_hosting_cdn" : "Hosting / CDN", 
    "desc_cdn_en" : "Activate CDN", 
    "help_cdn_en" : "Activer CDN : active le mode ou les librairies principales de ZADS sont téléchargées sur un réseau de type DCN ou un hosting", 
    "desc_cdn_url" : "CDN url", 
    "help_cdn_url" : "URL du CDN : URL du bucket principal root de stokage des librairies. L'arborescence doit êre la même que sur le site principal", 


    "desc_super_notifications" : "Notifications", 
    "desc_email_superadmin" : "super admin email",
    "help_email_superadmin" : "Adresse email utilisée pour envoyer les rapports de back-ups en plus du rapport traditionnel",
    "desc_backup_deleteall" : "Effacer tout", 
    "help_backup_deleteall" : "Effacer toutes les archives anciennes à chaque fois avant la creation de la nouvelle archive.", 

    "Pay delete" : "Pay delete", 
    "Please confirm modification to status 17 of :" : "Please confirm modification to status 17 of :",

    "log_update_DRAFT PAYMENT CANCEL" : "Payment cancelled",
    "help_on_status DRAFT PAYMENT CANCEL" : "Payment is cancelled",
    "DRAFT PAYMENT CANCEL" : "Payment is cancelled",

    //Z6.5.9 - nouvelles options administration 
    "desc_en_gzip" : "Compression GZIP",
    "help_en_gzip" : "Compression GZIP des echanges AJAX entre le navigateur et le serveur PHP.",
    "desc_hide_nb_ads" : "Masquer compteurs",
    "help_hide_nb_ads" : "Masquer les compteurs d'annonces",
    "desc_en_richeditor" : "Editeur de texte riche", 
    "desc_en_richeditor" : "Editeur de texte riche pour les champs TEXTEDITs ", 
 
    "desc_en_streetview" : "Activer STREETVIEW", 
    "help_en_streetview" : "Activer le mode Google StreetView", 


    "desc_doc settings" : "Documents",
    "desc_doc_ad_en" : "Doc. sur annonces", 
    "desc_doc_user_en" : "Doc sur usagers", 
    "desc_doc_file_max_size" : "Taille max ", 
    "desc_doc_file_max_nbr" : "Nombre Max fichiers", 
    "desc_doc_file_ext" : "Extensions", 
    "desc_doc_file_download" : "Autoris. téléchargement", 


    "help_doc_ad_en" : "Autorise l'ajout de documents sur les annonces.", 
    "help_doc_user_en" : "Autorise l'ajout de documents sur les annonceurs.", 
    "help_doc_file_max_size" : "Taille max en octets de chaque document.", 
    "help_doc_file_max_nbr" : "Nombre Max fichiers par annonce", 
    "help_doc_file_ext" : "Extensions autorisées (séparer par | chaque type) ", 
    "help_doc_file_download" : "Autoriser le téléchargement des documents", 


    "desc_price_field_second" : "Autoriser 2éme prix", 
    "help_price_field_second" : "Autorise la saisie d'un second prix qui permet de gérer les hausse/baisses de prix", 

    "desc_all_price_freeofcharge" : "Services Packs Gratuits", 
    "help_all_price_freeofcharge" : "Tous les services packs sont gratuits", 

    "desc_docurl" : "Document(s)",
    "download file : " : "Télécharger le fichier : ", 
    "title docurl" : "Fichiers", 

    "desc_metatitle" :"(SEO) META TITLE",
    "desc_metadesc" :"(SEO) META DESCRIPTION",
    "desc_metakey" :"(SEO) META KEYWORDS",

    "help_metatitle" :"(SEO) META TITLE",
    "help_metadesc" :"(SEO) META DESCRIPTION",
    "help_metakey" :"(SEO) META KEYWORDS",


    // gestion du double prix
    "ad pricearea"  : "Price",

    // date expirées sur options
    "expired datetime " : "expiré ", 


    // lost password new sequence
    "change password form introduction" : "Vous avez souhaité réinitialiser votre mot de passe. Utilisez ce formulaire pour choisir un nouveau mot de passe.", 
    "Your password activation Key is already posted to your email address, please check your Email address & Junk mail folder." : 
      "Votre clé d'activation du mot de passe est déjà posté à votre adresse e-mail , s'il vous plaît vérifier votre adresse e-mail et courrier indésirable dossier.", 

    "We sent you an email to reset your password." :  "Nous vous avons envoyé un e-mail pour réinitialiser votre mot de passe.",
    "Your email address is not correct" : "Votre adresse e-mail est incorrect", 
    "Wrong activation conditions" : "Mauvaises conditions d'activation",
    "Password updated successfully.":"Mot de passe mis à jour avec succès.",
    "Wrong activation conditions for updatepassword":"Mauvaises conditions d'activation", 

    "desc_lostpassword_link" : "Email réinitialiser mdp", 
    "help_lostpassword_link" : "Si cette option est activée, en cas de perte du mot de passe, un email avec une URL de réinitialisation et proposé eu lieu d'une génération de mot de passe automatique par le site.",     


    // visitor table
    "manage_visitors" : "Visiteurs",
    "fbot" : "Uniquement crawlers", 
    "fgoogbot" : "Uniquement Google bot",
    "fbingbot" : "Uniquement bing bot",
    "IP address or fqdn" : "Adresse IP ou URI", 
    "a_uri" : "URI", 
    "a_ua" : "USER AGENT", 
    "all visitors" : "Tous les visiteurs", 
    "delete_allbutbot" : "Effacer tout SAUF les crawlers",
    "delete_allall" : "Effacer TOUT",
    "delete_allfilter" : "Effacer tout ce qui est FILTRE actuellement",

    "desc_enable_visitors_logs" : "Log des visiteurs", 
    "help_enable_visitors_logs" : "Enregistre toutes les visites du site (IP, UA, URI, ..). Permet de faire ensuite des statiques ou detecter les crawlers ou adresses IPs frauduleuses. Attention, ce mode génére beaucoup de données qui peuvvent saturer votre stockage", 

    // about pages 
    "manage_about" : "A propos", 
    "all about" : "A propos / information", 
    "zads_version" : "Version de ZADS",
    "server_software" : "Type de serveur",
    "php_version" : "Version PHP",
    "php_ini" : "Paramétres fichier PHP.INI",
    "mysql_version" : "Version MySQL",
    "php_extensions" : "Extensions PHP", 
    "changelog" : "Derniers changements", 
    "blog" : "Le blog de ZADS", 
    "support" : "Support", 
    "mysql_size_mb" : "Espace utilisé dans la base de données",
    "mysql_stats" : "Détails espace utilisé par tables",
    "files_size" : "Taille des fichiers stockés",
    "last_backup" : "Derniere Sauvegarde",
    "debugfile" : "Debug file",
    "force_backup" : "Obtenir une archive par email",

    "%s post_vcounters_phone" : "%s",
    "%s post_vcounters_email"  : "%s",

    "help_on_post_vcounters_email" : "Nombre d'emails recus ou clicks pour voir votre email.", 
    "help_on_post_vcounters_phone" : "Nombre de clicks pour voir votre numéro de téléphone.", 
    
    // imagepour simplifier la gestion des banniéres pub basées sur une image uniquement
    "desc_banimgurl" : "Image",
    "help_banimgurl" : "Optionnel : charger directement une image dans votre environnement et le code HTML va se générer automatiquement. Attention, le code HTML est écrasé !",


    "desc_seo_googlebot_directhtml" : "SEO amélioré Google", 
    "help_seo_googlebot_directhtml" : "SEO amélioré Google : permet d'avoir un mode de gestion différentié pour Google lors du référencement.", 

    "desc_assocprojects" : "Super-administrateur", 
    "help_assocprojects" : "Super-administrateur : permet la gestion compléte du site y compris les options avancées d'administration. Attention, mettre aussi les droits d'administration !",

    "search for title or description" :"Rechercher",

    "desc_locale_gmap_zoom" : "Zoom (defaut)", 
    "desc_en_gmap_in_display" : "GMAP dynamiques", 
    "help_locale_gmap_zoom" : "Facteur de zoom par defaut pour les garte google map. Entre 0 et 19 . niveau ville = 10", 
    "help_en_gmap_in_display" : "GMAP dynamiques : affiche des cartes Google Map dynamique au lieu d'une image statique dans les annonces.", 

    "desc_seo":"Sitemap et SEO",
    "desc_xtrasitemap_xml_url":"Xtra sitemap url",
    "help_xtrasitemap_xml_url" :"Ajoute au début du sitemap généra par ZADS, le contenu XML présent à l'URL indiquée. Attention, ce doit être uniquement de entrées <url></url> sans l'entête.",
    "desc_sitemap_file" :"Sitemap" ,
    "help_sitemap_file" : "Force la génération du sitemap immédiatement", 
    "force sitemap generation": "Générer un sitemap",
    "open the sitemap": "Voir le fichier",
    "Sitemap generated successfully": "Génération du SITEMAP.XML avec succés",

    "desc_gmap_custom_marker_url" : "Marqueur GoogleMap perso.", 
    "help_gmap_custom_marker_url" : "Indiquez l'URL du fchier PNG qui marquera les emplacements de annonces sur la carte ( taille MAX 20x20 recommandé )", 

    "change price" :"Changer le prix",

    "Admin interface better work with CHROME browser." : "L'interface d'administration marche mieux avec CHROME. Merci de changer de navigateur.",
     
    // seo
    "desc_seo_add_fields" :"SEO : ajout de champs db",
    "desc_seo_add_fields_pos" :"SEO : position champs db",
    "desc_seo_add_fields_sep" :"SEO : séparateur champs db",

    "help_seo_add_fields" :"List les champs de la base de donnée de ZADS que vous souhaitea afficher dans le TITLE et META DESCRIPTION. Sépareteur ';'. utiliser les noms des champs de la base de donnée. Example loccity = Ville, locdept =  département, ...",
    "help_seo_add_fields_pos" :"Position dans le titre  : 'post' =  aprés, 'pre' = avant le texte",
    "help_seo_add_fields_sep" :"Séparateur qui sera utilisé entre les champs.",

    "desc_seo_display_fqdn": "Ajouter FQDN", 
    "help_seo_display_fqdn": "Ajouter le fdqn du site à la fin du TITLE séparés par un '|' ", 

    "facebook fan page" : "Facebook",

    "Con excecuted successfully" : "Execution du script avec succés, verifier votre boite email et le journal d'activité pour les résultats.",
    "cron tests" : "Test des scripts (CRON)",  


    "Price to be defined in catalogue section for this reference" : "Les prix sont définits pour cette Référénce Cat. dans la section catalogue.",

    "desc_paypal_forced_localecode" : "Paypal Locale Code",
    "help_paypal_forced_localecode" : "Paypal Locale Code : un code 5 caractéres pour indiquer la langue paypal par défaut. Si rien d'indiqué, on utilise le code pays.",

    "desc_locale_location_restrictfield": "Restriction (champ)", 
    "help_locale_location_restrictfield": "Restriction (champ) : permet de restreindre les annonces à une zone géographique. Indiquer ici le critére = champ de la base de donnée.", 
    "desc_locale_location_restrictvalues": "Restriction (values)", 
    "help_locale_location_restrictvalues": "Restriction (values) : lorsque la zone geo. est restreinte, permet d'indiquer ici les valeures (séparateur ';' ) ", 


    "This location is not authorized" : "Cette adresse n'est pas autorisée.",
    "Restricted location area" : "Uniquement les annonces en Suisse", 

    "desc_emails_templates_enh" : "Templates améliorée (V2)",
    "help_emails_templates_enh" : "Templates améliorée (V2 : dans ce mode, le SUJET de l'email est également inclus dans le modéle.",   
    
    "desc_emails_templates_dir" : "Répertoire templates emails", 
    "help_emails_templates_dir" : "Indiquer le répertoire ou se trouve les modéles d'emails. A partir de la racine des fichiers server php et ajouter un slash à la fin ! ",   

    "manage_emails_routings" : "Routages des emails", 
    "emailsroutes" :  "Routages des emails", 

    "save routingtable" : "Sauvegarder la table des routages", 
    "test all emails" : "Test - envoyer tous les emails !", 
    "sendallmails confirmation title" : "Test - envoyer tous les emails !", 
    "sendallmails confirmation body" : "Attention, si vous confirmez, tous les emails vont sous être envoyés pour test. Cela peut prendre plusieures minutes !", 

    "edit email" : "éditer",
    "delete email" : "supprimer",  
    "test email" : "envoi de test", 
    "* modified - don't forget to save!" : "* modifié. Ne pas oublier de sauvegarder.", 

    "desc_api/cron tokens" : "Clefs de sécurité",  
    "desc_cron_token" : "Clef de sécurité CRONJOB",
    "help_cron_token" : "Clef de sécurité CRONJOB : cette clef (KEY) permet de sécuriser les CRONJOBS. Elle doit être envoyée comme paraméte token=KEY d'une méthode GET",

    "Confirm route add": "Confirmation ajout d'une route", 
    "add route" :"Ajouter une route", 
    "Please confirm route ad" : "Merci de choisir une destination et confirmer", 
    "-- select one destination --": "-- Choisir une destination --",
    "Please confirm deletion of this route : " : "Merci de confirmer l'éffacement de cette route",

    "upload banimgurl" : "charger une image",
    "user edit" : "éditer", 


    "desc_seo_inspect_like_googlebot" : "DEBIG : Explorer like Google", 
    "help_seo_inspect_like_googlebot" : "Mettre le site principal en mode exploration comme googlebot : le site 'snapshot' est affiché.", 
    "desc_seo_display_ugly_url" : "DEBUG : Afficher ugly url", 
    "help_seo_display_ugly_url" : "DEBUG : Afficher les urls avec le ?_escaped_fragment_= ", 
    "desc_seo_full_php_site" : "DEBUG : Site mode PHP pur", 
    "help_seo_full_php_site" : "Affiche le site en pur PHP sans AJAX pour des tests de référencement natif ", 
    "desc_seo_catlist" : "Lister les catégories", 
    "help_seo_catlist" : "Lister les catégories lors du référencement. 'nonull'= affiche uniquement les catégories avec au moins une annonce.  'all' : afficher tout.  {vide} : ne pas afficher ", 

    "about_subscription" : "Abonnement", 
    "about_expire" : "Expire le",
    "about_install" : "Installation", 
    "about_sitemap" : "Sitemap", 


    "allcats" : "Catégories / Champs", 
    "allsubscribers" : "Newsletter", 
    "allservices" : "Packs d'annonces", 
    "manage_settings" : "Configuration générale",
    "manage_zetvu" : "News/Zetévu/tutos", 
    "manage_emails" :"Emails & notifications",
    "settings_submenu_emails" : "Emails adresses <i class='ml6 icon-fa-cog'></i>",
    "allsubscriptions" : "Config. Abonnements", 
    "settings_submenu_services" : "Configuration <i class='ml6 icon-fa-cog'></i>",
    "settings_submenu_pricingplan" : "Plans d'abonnement <i class='ml6 icon-fa-cog'></i>",
    "allpages" : "Pages",
    "settings_submenu_sitepages" : "Page d'accueil<i class='ml6 icon-fa-cog'></i>",

    "geolocal ip":"Géolocaliser l'ip", 


    "admin_coms_type_comment" : "commentaire",
    "a_description" : "Texte", 
    "a_abuse" : "Abus", 

    // translations for commenting system
    "comment no-posts" : "Aucun commentaires",
    "no comment" : "Aucun commentaires",
    "comment save" :"Valider", 
    "comment next" : "Commentaires suivants", 
    "comment delete" : "Supprimer",
    "comment edit" : "Editer", 
    "comment like" : "Voter pour",
    "comment dislike" : "Voter contre",
    "comment abuse" : "Signaler un abus",
    "com is abuse" : "Ceci a été signalé comme abusif", 
    "comment reply" : "Répondre",
    "ad comment loading" : "Chargement des commentaires en cours ...", 
    "ad comment" : "Commentaires ...",
    "allcoms" : "Commentaires/revues", 

    '%s comment' : '%s commentaire',
    '%s comments' : '%s commentaires', 

    "manage_coms_review": "Revues/Evaluations", 
    "manage_coms_comment": "Commentaires",
    "settings_submenu_coms": "Configuration <i class='ml6 icon-fa-cog'></i>",
    "all coms_comment" : "Tous les commentaires",
    "all coms_review" : "Toutes les évaluations", 
    "No entries in coms" : "Aucun commentaires/évaluations",

    "comment tform textarea placeholder" : "Posez vos questions sur cette annonce... Merci de ne pas ajouter de coordonnées personnelles (mail, téléphone... etc) et de faire preuve de courtoisie !",
    "review tform textarea placeholder" : "Déposez vos évaluations ... Merci de ne pas ajouter de coordonnées personnelles (mail, téléphone... etc) et de faire preuve de courtoisie !",


    "coms_comment_purgedeleted" : "Purger supprimés", 
    "coms_review_purgedeleted" : "Purger supprimés", 

    "a_likes" : "Likes", 


    "review no-posts" : "Aucune revue",
    "no review" : "Aucune revues",
    "review save" :"Valider", 
    "review next" : "Suivants", 
    "review delete" : "Supprimer",
    "review edit" : "Editer", 
    "review like" : "Voter pour",
    "review dislike" : "Voter contre",
    "review abuse" : "Signaler un abus",
    "com is abuse" : "Ceci a été signalé comme abusif", 
    "review reply" : "Répondre",
    "ad review loading" : "Chargement des revues en cours ...", 

    '%s review' : '%s évaluation',
    '%s reviews' : '%s évaluations', 

    "ad_rating1_name" : "Conformité", 
    "ad_rating2_name" : "Livraison", 
    "ad_rating3_name" : "Accueil", 

    "review summary" : "Moyenne", 
    "review post" : "Poster une évaluation", 

    "review rating please select something" : "Voter", 
    "ad_rating1_level_0" : "Voter",
    "ad_rating1_level_1" : "Trés mauvais ",
    "ad_rating1_level_2" : "Mauvais",
    "ad_rating1_level_3" : "Moyen",
    "ad_rating1_level_4" : "Bien",
    "ad_rating1_level_5" : "Trés bien",

    "ad_rating2_level_0" : "Voter",
    "ad_rating2_level_1" : "Niveau 1",
    "ad_rating2_level_2" : "Niveau 2",
    "ad_rating2_level_3" : "Niveau 3",
    "ad_rating2_level_4" : "Niveau 4",
    "ad_rating2_level_5" : "Niveau 5",

    "ad_rating3_level_0" : "Voter",
    "ad_rating3_level_1" : "Niveau 1",
    "ad_rating3_level_2" : "Niveau 2",
    "ad_rating3_level_3" : "Niveau 3",
    "ad_rating3_level_4" : "Niveau 4",
    "ad_rating3_level_5" : "Niveau 5",



    "user_rating1_name" : "Conformité", 
    "user_rating2_name" : "Livraison", 
    "user_rating3_name" : "Accueil", 

    "review rating please select something" : "Voter", 
    "user_rating1_level_0" : "Voter",
    "user_rating1_level_1" : "Niveau 1",
    "user_rating1_level_2" : "Niveau 2",
    "user_rating1_level_3" : "Niveau 3",
    "user_rating1_level_4" : "Niveau 4",
    "user_rating1_level_5" : "Niveau 5",

    "user_rating2_level_0" : "Voter",
    "user_rating2_level_1" : "Niveau 1",
    "user_rating2_level_2" : "Niveau 2",
    "user_rating2_level_3" : "Niveau 3",
    "user_rating2_level_4" : "Niveau 4",
    "user_rating2_level_5" : "Niveau 5",

    "user_rating3_level_0" : "Voter",
    "user_rating3_level_1" : "Niveau 1",
    "user_rating3_level_2" : "Niveau 2",
    "user_rating3_level_3" : "Niveau 3",
    "user_rating3_level_4" : "Niveau 4",
    "user_rating3_level_5" : "Niveau 5",

    "Your acount is under review. You can login only when approved. " : "Votre accès est en cours de d'approbation. <br> Une fois approuvé, vous pourrez vous connecter ici : ", 
    "account under review" : "Compte correct mais pas encore autorisé.", 

    "desc_indir_yes_default" : "Annuaire par défaut",
    "help_indir_yes_default" : "Annuaire par défaut coché.",

    "it_IT"  : "Italian",
    "sv_SV"  : "Swedish",



    // end 
    'dummy' : 'dummy'
    }; 
