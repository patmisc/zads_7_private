// JavaScript Document
// french language file  version 6.5.8


if  (typeof monthnb_2_string == 'undefined')  var monthnb_2_string = []; 
if  (typeof daynb_2_string == 'undefined')  var daynb_2_string=[]; 
if  (typeof my_dictionary == 'undefined')  var my_dictionary=[]; 


 monthnb_2_string['fr_FR'] ={
  1 : "Jan.",
  2 : "Fév.", 
  3 : "Mar.",
  4 : "Avr.",
  5 : "Mai",
  6 : "Jun.",
  7 : "Jul.",
  8 : "Aou.",
  9 : "Sep.",
  10 : "Oct.",
  11 : "Nov.",
  12 : "Déc."
}

daynb_2_string['fr_FR'] ={
  0 : "Dimanche",
  1 : "Lundi", 
  2 : "Mardi",
  3 : "Mercredi",
  4 : "Jeudi",
  5 : "Vendredi",
  6 : "Samedi"
}



// for calendar picker 
var DPLocal = {
        days: ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"],
        daysShort: ["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"],
        daysMin: ["DI", "LU", "MA", "ME", "JE", "VE", "SA", "DI"],
        months: ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"],
        monthsShort: ["Jan", "Fév", "Mar", "Avr", "Mai", "Jui", "Jul", "Aou", "Sep", "Oct", "Nov", "Déc"],
        today: "Aujourd'hui",
        clear: "Effacer",
        weekStart: 1,
        format: "dd/mm/yyyy"
};


my_dictionary['fr_FR'] = { 
    // genéral dates : 
    "yesterday"  : "hier",
    "today"  : "aujourd'hui",
    "tomorrow" : "demain",
    "%s day ago" :"%s jour",
    "%s days ago" :"%s jours",
    "till "  : "jusqu'au ", 
    "yes" : "oui", 
    "no" : "non", 
    
    "in %s day" :"dans %s jour",
    "in %s days" :"dans %s jours",
    "days" : "jours", 
    "day" : "jour", 
    "the" : "le", 
    "the " : "le ",
    
    "%s ads" : "%s annonces" ,
    "%s ad" : "%s annonce" ,
    "no ad" : "aucune annonce",
    
    
    "%s cats" : "%s catégories" ,
    "%s cat" : "%s catégorie" , 
    
    "%s users" : "%s usagers" ,
    "%s user" : "%s usager" ,
    
    "no user" : "aucun annonceur",
    
    // global 
    "more" : "Plus de détails",
    "Load more" : "Voir la suite", 

    // offline 
    "Site is offline" : "Le site est suspendu", 
    "Site is no more available." : "Le site n'est plus disponible pour l'instant.",

    
    // general BROWSER detection messages
    "You're using IE8 or above" : "Vous utilisez IE 8 ou sup.",
    "You're using IE7.x" :  "Vous utilisez IE 7.x ",
    "You're using IE6.x" :  "Vous utilisez IE 6.x ",
    "You're using IE5.x" :  "Vous utilisez IE 5.x ",
    ': this browser is partialy supported . See the list <a href="navsupported_fr.html">here</a>' : ' : ce navigateur est partiellement supporté. Voir la liste <a href="navsupported_fr.html">ici</a>',
    
    // general navigation 
    "Main cat sell" : "Offres",
    "Main cat buy" : "Demandes", 
    "Main cat user" : "Annonceurs", 
    "Zetvu" : "Zetévu",
    "my admin" : "( Admin )", 
 
    // boutons de creation 
    "add a cat"  : "Ajouter une catégorie",
    "add a user"  : "Créez un usager",
    "add a sell"  : "Créez votre annonce",
    "add a buy"  : "Créez votre annonce",
    
    // texte d'introduction  aux formulaires 
    " ad form header title"  : "Mon annonce: ",
    " ad form header introduction" : "A travers ce formulaire, déposez votre annonce. <br>Elle est GRATUITE et sera disponible après validation par le comité éditorial. Elle restera visible 60 jours. <br>Merci de pendre en compte les champs obligatoires marqués d'une étoile. <br> ",
    
    "preview ad form header title"  : "Valider votre  annonce: ",
    "preview ad form header introduction"  : "Vérifier le contenu de votre annonce et valider après avoir accepté les règles de diffusion et d'utilisation de l'annonce",
    
    
    "modify ad form header title"  : "Modifier mon annonce: ",
    "modify ad form header introduction" : "A travers ce formulaire, modifier votre annonce. <br>Elle est GRATUITE et sera disponible après validation par le comité éditorial. Elle restera visible 60 jours. <br>Merci de pendre en compte les champs obligatoires marqués d'une étoile. <br> ",


    " user form header title"  : "Enregistrement : ",
    " user form header introduction" : "A travers ce formulaire, enregistrez vous immédiatement.<br>Merci de pendre en compte les champs obligatoires marqués d'une étoile.  ",
    " user form header introduction facebook" : "Vous pouvez vous identifier à partir de <span class='icon-menu' id='facebook'><span class='icon'></span><a href='#' what='facebook'  name='action-on-elem' class='text'>votre compte facebook.</a></span><br> ",

    "preview user form header title"  : "Valider votre compte: ",
    "preview user form header introduction"  : "Vérifier les détails de votre compte et validez aprés avoir accepté les conditions générales du site",
    

    "modify user form header title"  : "Modifier un usager: ",
    "modify user form header introduction" : "A travers ce formulaire, modifier un usager existant du site.<br>Merci de pendre en compte les champs obligatoires marqués d'une étoile. <br> ",

    "modify curuser form header title"  : "Modifier mon profil: ",
    "modify curuser form header introduction" : "A travers ce formulaire, modifier mon profil.<br>Merci de pendre en compte les champs obligatoires marqués d'une étoile. <br> ",


    " cat form header title"  : "Nouvelle catégorie: ",
    " cat form header introduction" : "A travers ce formulaire, créer une nouvelle catégorie. <br>Elle sera disponible immédiatement.<br>Merci de pendre en compte les champs obligatoires marqués d'une étoile. <br> ",
    
    "modify cat form header title"  : "Modifier une catégorie: ",
    "modify cat form header introduction" : "A travers ce formulaire, modifier une catégorie. <br>Elle sera disponible immédiatement.<br>Merci de pendre en compte les champs obligatoires marqués d'une étoile. <br> ",

    " zetvu form header title"  : "Nouveau ZeTVu: ",
    " zetvu form header introduction" : "Créer un message simple, ludique et anonyme par ce ZeTvu (prononcer 'ze té vu').<br> ",
    
    "modify zetvu form header title"  : "Modifier un ZeTVu:",
    "modify zetvu form header introduction" : "A travers ce formulaire, modifier votre ZeTeVu. <br>Elle sera disponible immédiatement.<br>Merci de pendre en compte les champs obligatoires marqués d'une étoile. <br> ",


    // Formulaire de saisie d'un user
    "username"  : "Nom de login",
    "firstname"  : "Prénom",
    "lastname"  : "Nom",
    "password"  : "Mot de passe",
    "password from "  : "Mot de passe de ",
    "confirm password"  : "Mot de passe(2)",
    "more user details" : "Détails",
    "log-in details" : "Connexion",
    "user email" : "Adresse email",
    "user phone" : "Téléphone principal",
    "phone" : "Tél.",
    "location" : "Localisation",
    "user upload picture" : "Photo(s)",
    "change password"  : "Changer mot de passe",
    "retype the password to confirm" : "confirmer le mot de passe",
    
    "help email rules" : "format doit être de type toto@service.ext",
    "help passord rules" : "doit avoir au moins 5 caractères avec des majuscules, minuscules , chiffres, caractères spéciaux, .. ",
    
    /* améliorations ZADS4.0 pour le formulaire User*/
    "bio and skills details" :"Bio & compétences",
    "user bio" : "Votre devise",  
    "user skills" : "Compétences",
    "skills" : "Compétences",
    "contact details" : "détails", 
    "contact actions" : "actions", 
    "selected skills" : "Vos compétences",
    "select a skills" : "Sélectionnez vos compétences",
    // formulaire de saisie de compétences
    "rating_level_1" : "débutant", 
    "rating_level_2" : "amateur",
    "rating_level_3" : "amateur éclairé",
    "rating_level_4" : "semi-pro",
    "rating_level_5" : "professionnel",
    "rating please select something" : "indiquer votre niveau", 
    "add_skills" : "ajouter cette compétence",
    "remove_skill" : "supprimer",
    
    "user upload pictures" : "Images / portfolio", 
    "upload folioimg" : "ajouter une image",
    "upload filename" : "ajouter une image",    
    "user upload portofolio help %s" : "Charger des images qui serviront de portfolio a votre activité. Jusqu'a %s images.",
    
    "user upload avatar" : "Avatar", 
    "upload avatarimg" : "ajouter une photo", 
    "user upload avatar help %s" : "Charger %s photo qui servira d'avatar (format : carte d'identité 207 x 266) pour votre mini-fiche",
    
    "declare pro user" : "Professionnel",
    "type of user account" : "Type de compte", 
    "professionnal details" : "Professionnel",
    "ad company name" : "Raison Sociale", 
    //"ad siret" : "SIRET",  
    
    "ad siret" : "SIRET", 

    "ad website" : "Site web",
    "link to website" : "Site web",
    "ad banner" : "Banniére", 
    "upload probannerimg" : "Ajouter une Banniére",
    "post ad banner" : "format xxx",
    "help ad banner %s" : "Charger une bannière (%s) (format : Leaderboard 728 x 90) qui sera en haut de page de votre mini-fiche",

    "user location" : "Adresse",  
    "user loczipcode" : "code postal", 
    "user loccity" : "ville", 
    "user locdept" :"départment", 
    "user locregion" : "région",
    
    "usertype" : "droits",
    "registerdate" : "crée le", 
    "lastvisitdate" : "derniére visite le", 
    "id" : "identifiant",
    
    /* messages pour les conseils du checker de passwords */ 
    "shortPass" :" Trop court ! " ,   
    "badPass":" Pas assez robuste !", 
    "goodPass":" Bon !",   
    "strongPass":" Robuste !",   
    "samePassword":" identifque au login. pas bien !",  
    
    "gender"  : "Je suis ",
    "male" : "un homme", 
    "female" : "une femme",
    
    "locale"  : "Langue princip.",
    "fr_FR"  : "francais",
    "en_GB"  : "anglais (UK)",
    "en_US"  : "anglais (USA)",
    "de_DE"  : "allemand",
    "nl_NL"  : "hollandais",
    "ar_AR"  : "arabe",
    "tr_TR"  : "turque",

    "user auth" : "Autentification", 
    "fb" : "facebook",
    "auth type fb" : "facebook",
    "auth type " : "locale",
    "content via facebook" : "via facebook", 
    "login_facebook" : "Utiliser son compte Facebook",
    "facebook login description" : "Utiliser votre compte Facebook pour authentifier sur ce site.",
    "or" : "ou",  
    " or " : "ou", 
    "Error in FACEBOOK authentification" : "Une erreur est survenue lors de l'authentification via Facebook.",
    
    "login_google" : "Utiliser son compte Google",
    
    // formulaire pour les catégories
    "cat title"  : "Nom",
    "cat description"  : "Description de la catégorie",
    "cat upload picture" : "Photo(s)",
    "help cat title" : "nom de la catégorie", 
    "desc cat type" : "Type de catégorie", 
    
    "cattype_ad" : "pour annonces", 
    "cattype_user" : "pour usagers",
    "cattype_" : "pour tous",  
    
    "help_on_cattype cattype_" : "Cette catégorie peut servir pour des annonces ou des usagers/annonceurs.", 
    "help_on_cattype cattype_user" : "Cette catégorie peut servir pour des usagers/annonceurs", 
    "help_on_cattype cattype_ad" : "Cette catégorie peut servir pour des annonces", 
    
    // formulaire pour les zeTvu
    "<b>Je tai vu ...</b>" : "<b>Je t'ai vu ...</b>",
    "zetvu title"  : "Intro",
    "zetvu desc"  : "Message",
    "zetvu location"  : "Où ?",
    
    // input de recherche : 
    "-- search through ads --" : "-- Quoi, Où ? --", 
    "search" : "recherche", 
    
    // Formulaire de saisie de l'annonce
    "ad title"  : "Titre de l'annonce",
    "help title limited to 60 chars. Do not indicate buy of sell" : "60 caractères max. Ne pas indiquer ACHETE ou VEND",
    "ad description"  : "Description",
    "ad categorie"  : "Catégorie",
    "ad email"  : "Adresse Email",
    "ad sell or buy"  : "Type",
    "ad video embed" : "Video HTML code", 
    "ad video embed help" : "Entrer le code HTML de votre fournisseur de video. Par exemple, sous YOUTUBE, rendez vous dans le menu PARTAGER / INTEGRER pour extraire le code à coller dans ce champ.", 
    "sell"  : "offres",
    "buy"  : "demandes",
    "ad price"  : "Prix",
    "&euro;" : "(en &#8364;) :  mettre 0 pour gratuit ou troc.",
    "$" : "(en $) :  mettre 0 pour gratuit ou troc.",
    "ad upload picture" : "Image(s)",
    "ad upload image help %s" : "Vous pouvez ajouter jusqu'a %s images. Max 500 ko par image. Extensions .jpeg, .jpg, .gif, .png",
    "cat upload image help %s" : "Vous pouvez ajouter %s image qui sera utilisée pour les annonces sans image de cette catégorie. Max 500 ko par image. Extensions .jpeg, .jpg, .gif, .png",
    "zetevu upload image help %s" : "Vous pouvez ajouter une image. Max 500 ko par image. Extensions .jpeg, .jpg, .gif, .png",
    "ad details" : "Annonce",
    "ad contact me" : "Contact",
    "how to contact you for this ad" : "comment me contacter ?",
    "enable phone"  : "Téléphone",
    "show phone"  : "Téléphone",
    "show email"  : "E-mail",
    "show name"  : "Nom",
    "ad help enusername" : "Le nom doit être compris entre 5 et 20 caractères",
    "Show my email address together with this ad" : "afficher mon email dans l'annonce.",
    "Show my name together with this ad" : "afficher mon nom dans l'annonce.",
    "display my phone number" : "afficher mon numéro de téléphone dans l'annonce.", 
    "Information on how to see it and get it" : "Ou se trouve l'article", 
    "ad location and delivery": "Localisation",
    "ad location": "Adresse",
    "help indicate for example a zip code or town" : "format : {rue,ville,pays} ou {codepostal,pays}. Exemple : Strasbourg,FR ou 67000,FR. Pour une auto-détection de l'adresse, laisser à vide et lancer la détection",
    "help indicate format phone number" : "format canonique :+CodePays/Région(IndicatifRégional)NuméroAbonné.Exemple : +33(0)390671234",
    "Not the right file extension." : "Cette extension de fichier n'est pas supportée.", 
    "file size exceed limit." : "La taille du fichier dépasse les limites autorisées.",
    "id of article owner" :"identiant du créateur de l'article", 
    "userid" : "Identifiant",  
    
    // title of Menu which are close to the input texts. 
    "post menu loc" : "Auto-détecter", 
    "check this loc" : "Vérifier cette adresse", 
    
    // informations affichées lors d'une modification
    "publishing state" : "Divers",
    "Publication status" : "Divers informations sur votre annonce", 
    "ad pub date" :"Date", 
    "ad logs":"Historique", 
    "what" : "quoi?", 
    "whatid"  : "id",
    "auth"  : "auth",
    "cron"  : "automate",
    "sec"  : "système",
    "daily"  : "daily",
    "weekl"  : "weekly",
    "severity" : "Sev.",
    "severity_0" :"-",
    "severity_1" :"Mid",
    "severity_2" :"High",
    "Only severity 0" :"Sévérité Normale",
    "Only severity 1" :"Sévérité Moyenne",
    "Only severity 2" :"Sévérité Haute",
    "-- select one severity --" : "-- filtrer par sévérité --",
    
    "-- select one action --" : "-- filtrer par type de log --",
    "Only Life-cycle" : "historique des modifications", 
    "Only Auth" : "Connections des usagers", 
    "Only CRON" : "Automates/robots", 
    "Only SEC" : "Système/sécurité", 
     
    
    "I agree with the " : "J'accepte les ", 
    "Terms and Conditions" : "termes et conditions", 
    "I accept the tandc" : "J'accepte les conditions ...", 
    "By clicking the confirm button, " : "En cliquant sur le bouton <b>je confirme</b>,  ",
    
    
    "mandatory" : " * ",
    
    "upload picture" : "sélectionner une image",
    
    "delete" : "supprimer",
    "submit" : "envoyer", 
    "cancel" : "annuler",
    "modify" : "modifier",
    "edit" : "modifier",
    "more actions" : "actions", 
    "no data found" : "Pas de donnée", 
    
    "ad delete"  : "effacer à vie",
    "ad supress"  : "supprimer",
    
    // dialog button and content 
     "dialog cancel"  : "annuler",
     "dialog ok"  : "je confirme",
     "ad delete dialog title"  : "Effacer un article",
     "cat delete dialog title"  : "Effacer une catégorie",
     "user delete dialog title"  : "Effacer un usager",
     "profil delete dialog title"  : "Effacer un usager",
     "curuser delete dialog title"  : "Effacer un usager",

     "Confirm delete of ad :" : "!! Attention, cette action est irréversible !!<br>Confirmez vous l'effacement de l'article : ",
     "Confirm delete of cat :" : "!! Attention, cette action est irréversible !!<br>Confirmez vous l'effacement de la catégorie : ",
     "Confirm delete of user :" : "!! Attention, cette action est irréversible !!<br>Confirmez vous l'effacement de l'usager : ",
     "Confirm delete of profil :" : "!! Attention, cette action est irréversible !!<br>Confirmez vous l'effacement de l'usager : ", 
     "Confirm delete of curuser :" : "!! Attention, cette action est irréversible !!<br>Confirmez vous l'effacement de l'usager : ",
     
     // confirmation pour les logs 
     "Confirm deletion" : "Confirmer effacement", 
     "Please confirm deletion of all logs entries with status :" : "En cliquant, <i>je confirme</i>, les enregistrements (logs) ci-dessous seront tous supprimés de façon irréversible.",
     
     "Action in progress ..." : "Mise à jour en cours, merci de patienter ...",
    // categories 
    'select one categorie' : 'sélectionner une catégorie',
    
    "-- select one reason --" : '-- sélectionner une raison --',
    "article sold though this site" : "L'article a été vendu grâce à ce site",
    "article sold through another mean" : "L'article a été vendu d'une autre manière",
    "article no more available" : "L'article n'est plus disponible",
    "auto" : "Supression automatique",
    "1_soldthru" : "Vendu via ce site", 
    "2_soldother" : "Vendu via une autre moyen", 
    "3_notavail" : "Plus disponible", 
    
    "ad creation ongoing": "Création de l'article :",
    "zetvu creation ongoing": "Création du zetevu :",
    "user creation ongoing": "Création de l'utilisateur :",
    "cat creation ongoing": "Création de la catégorie :",
    
    "(where?)" : "Localisation ?", 
    
    "ad modification ongoing": "Modification de l'article :",
    "user modification ongoing": "Modification de l'utilisateur :",
    "curuser modification ongoing": "Modification du profil :",
    "cat modification ongoing": "Modification de la catégorie :",
    
    // erreurs sur les formulaires
    "You must select something." : "merci de sélectionner quelque chose.",
    "You must fill in something." : "merci de saisir un texte.",
    "Incorrect format." : "format de saisie incorrect.", 
    "Incorrect rule." : "format de saisie incorrect.",
    "You must accept the Terms and conditions" : "vous devez accepter les T&C ",
    "Field does not match password" : "les deux mots de passe doivent être identiques",
    "Text length exceeding limits." : "la longueur du texte dépasse la limite",
    "%s char remaining" : "reste %s caractère",
    "%s chars remaining" : "reste %s caractères", 
    "%s chars max" : "%s caractères maximum",
    "your must precise skills AND ratings." : "choisir au moins une compétence et son niveau.",
    
    // error in email formular
    "Incorrect email format" :  "format de l'email incorrect.", 
    //"Incorrect SIRET number." :  "Format SIRET incorrect (14 chiffres).", 
    "Incorrect SIRET number." :  "Format SIRET incorrect (14 chiffres)", 

    // options payantes : 
    
    "ad payoptions" : "Mise en avant :", 
    "post payoptions" : "Options de mise en avant pour vous démarquer !", 
    "help payoptions" : "Options de mise en avant pour vous démarquer !", 

    // "desc putontopgallery" : "Mise à la une", 
    // "help putontopgallery" : "Mettre mon annonce à la une pendant 7 jours", 
    
    // "desc pushtotop7days" :  "Remonter mon annonce", 
    // "post pushtotop7days" :  "Mettre mon annonce en avant chaque jour pendant 7 jours", 
    //  "help pushtotop7days" :  "Mettre mon annonce en avant chaque jour pendant 7 jours", 
    
    // "desc pushtotop30days" :  "Remonter mon annonce", 
    // "post pushtotop30days" :  "Mettre mon annonce en avant chaque jour pendant 30 jours", 
    // "help pushtotop30days" :  "Mettre mon annonce en avant chaque jour pendant 30 jours", 
    

    // "desc specialcolor"  :  "Encadrer mon annonce", 
    // "post specialcolor"  :  "Encadrer de couleur mon annonce pour être plus visible", 
    //  "help specialcolor"  :  "Encadrer de couleur mon annonce pour être plus visible", 
    
    "desc_addpics"  :  "Photos en plus" , 
    "post addpics"  :  "Ajouter des photos en plus" , 
    "help addpics"  :  "Ajouter des photos en plus" , 

    "desc_paidvideo"  :  "Ajouter une video", 
    "post paidvideo" : "Ajouter une video via son code embedd", 
    "help paidvideo" : "Ajouter une video via son code embedd", 

    "pushtop" : "remontée",
    "pushtop30" : "remontée 30j",
    "pushgal" : "mise à la une",  


    // texte des boutons du formulaire
    "BTN ad NOT CREATED": "envoyer",
    "BTN ad DRAFT": "sauvegarder brouillon",
    "BTN ad DRAFT PENDING PAYMENT" : "Payer et valider", 
    "BTN ad PREVIEW": "valider",
    "BTN ad UNDER REVIEW": "soumettre pour publication",
    "BTN ad PUBLISHED": "publier",
    "BTN ad UNPUBLISHED": "retirer de la publication",
    "BTN ad DELETED": "Supprimer",
    "BTN ad REJECTED": "Rejeter",
    "BTN ad WILLEXPIRE": "Marquer expirée",
    "BTN ad REACTIVATE": "Réactiver l'annonce",
    
    "BTN cat NOT CREATED": "envoyer",
    "BTN cat DRAFT": "sauvegarder brouillon",
    "BTN cat UNDER REVIEW": "soumettre pour publication",
    "BTN cat PUBLISHED": "publier",
    "BTN cat UNPUBLISHED": "retirer de la publication",
    "BTN cat DELETED": "Supprimer",
    "BTN cat REJECTED": "Rejeter",
    "BTN cat WILLEXPIRE": "Marquer expirée",
    
    "BTN user NOT CREATED": "envoyer",
    "BTN user DRAFT": "sauvegarder brouillon",
    "BTN user DRAFT PENDING PAYMENT" : "Payer et valider", 
    "BTN user PREVIEW": "valider",
    "BTN user UNDER REVIEW": "soumettre",
    "BTN user PUBLISHED": "enregistrer",
    "BTN user UNPUBLISHED": "suspendre",
    "BTN user DELETED": "Supprimer",
    "BTN user REJECTED": "Rejeter",
    "BTN user WILLEXPIRE": "Forcer expiration",
    
    "BTN curuser NOT CREATED": "Envoyer",
    "BTN curuser DRAFT": "Sauvegarder brouillon",
    "BTN curuser UNDER REVIEW": "soumettre",
    "BTN curuser PUBLISHED": "Enregistrer",
    "BTN curuser UNPUBLISHED": "Suspendre",
    "BTN curuser DELETED": "Supprimer",
    "BTN curuser REJECTED": "Rejeter",
    "BTN curuser WILLEXPIRE": "Forcer expiration",
    
    
    "BTN zetvu NOT CREATED": "envoyer",
    "BTN zetvu DRAFT": "sauvegarder brouillon",
    "BTN zetvu UNDER REVIEW": "soumettre pour publication",
    "BTN zetvu PUBLISHED": "publier",
    "BTN zetvu UNPUBLISHED": "retirer de la publication",
    "BTN zetvu DELETED": "Supprimer",
    "BTN zetvu REJECTED": "Rejeter",
    "BTN zetvu WILLEXPIRE": "Forcer expiration",


    "BTN banner NOT CREATED": "envoyer",
    "BTN banner DRAFT": "sauvegarder brouillon",
    "BTN banner DRAFT PENDING PAYMENT" : "Payer et valider", 
    "BTN banner PREVIEW": "valider",
    "BTN banner UNDER REVIEW": "soumettre pour publication",
    "BTN banner PUBLISHED": "publier",
    "BTN banner UNPUBLISHED": "retirer de la publication",
    "BTN banner DELETED": "Supprimer",
    "BTN banner REJECTED": "Rejeter",
    "BTN banner WILLEXPIRE": "Marquer expirée",


    "BTN bookings NOT CREATED": "envoyer",
    "BTN bookings DRAFT": "sauvegarder brouillon",
    "BTN bookings DRAFT PENDING PAYMENT" : "Payer et valider", 
    "BTN bookings UNDER REVIEW": "soumettre pour publication",
    "BTN bookings PUBLISHED": "publier",
    "BTN bookings UNPUBLISHED": "retirer de la publication",
    "BTN bookings DELETED": "Supprimer",
    "BTN bookings REJECTED": "Rejeter",
    "BTN bookings WILLEXPIRE": "Marquer expirée",
    

    "REGISTERED": "Enregistré",
    "EDITOR": "Editeur",
    "ADMIN": "Administrateur",
    "SUPER-ADMIN" : "Super administrateur",
    
    "formular already exists" : "Le formulaire est déjà ouvert. Cliquez sur le bouton annuler.",
    
    // sidebar 
    "Browse all": "tout voir",
    "latest ZeTvu" : "Derniers ZeTvu", 
    "latest News" : "Derniers News", 
    "latest Tutos" : "Derniers Tutos", 
    "latest Tweet" : "News", 
 
    // sidebar buttons 
    "Subscribe" : "S'abonner",
    "subscribe feed by email": "les offres par email", 
    "subscribe feed": "abonnez vous au flux RSS",
    "follow us on twitter": "suivre sur Twitter",
    "follow us on facebook": "suivre sur Facebook",
  
    // texte des Status possibles d'un article
    "NOT CREATED": "brouillon",
    "DRAFT": "brouillon",
    "DRAFT PENDING PAYMENT": "Paiement en attente",
    "DRAFT PAYMENT OK": "Paiement effectué",
    "UNDER REVIEW": "en cours de revue",
    "under review" : "en cours de revue",
    "PUBLISHED": "publié(e)",
    "UNPUBLISHED": "re-travail",
    "DELETED": "supprimé(e)",
    "REJECTED": "rejeté(e)",
    "WILLEXPIRE": "va expirer",



    // short version for admin pages 
    "SHORT NOT CREATED": "00",
    "SHORT DRAFT": "draf",
    "SHORT DRAFT PENDING PAYMENT": "pay pend",
    "SHORT DRAFT PAYMENT CANCEL": "pay annul",
    "SHORT DRAFT PAYMENT OK": "payok",
    "SHORT UNDER REVIEW": "review",
    "SHORT under review" : "review",
    "SHORT PUBLISHED": "pub",
    "SHORT UNPUBLISHED": "un-pub",
    "SHORT DELETED": "supp",
    "SHORT REJECTED": "rejec",
    "SHORT WILLEXPIRE": "willexp",

    
    // test descriptifs des LOGS 
    "create": "création",
    "update": "modification",
    "delete": "suppression",
    "updatehit": "modification",
    "updatestatus": "modification",
    "resethits" : "modification", 
    
    "desc": "description",
    "state": "état",
    "No entries in logs" : "Aucune entrée dans l'historique.",
    "No entries in payments" : "Aucune entrée dans l'historique des paiements",
    
    "log_resethits" : "mise à zero des hits", 
    "log_create_DRAFT": "Création comme brouillon",
    "log_payment_DRAFT PAYMENT OK": "Paiement réalisé avec succès", 
    "log_create_UNDER REVIEW": "Création et soumission",
    "log_create_PUBLISHED": "Création et publication",
    "log_update_DRAFT" : "Modification et sauvegarde comme brouillon",
    "log_update_DRAFT PENDING PAYMENT" : "Mise en attente de paiement",
    "log_update_UNDER REVIEW": "Modification et re-soumission pour revue",
    "log_update_PUBLISHED": "Modification et publication",
    "log_updatestatus_PUBLISHED": "Modification et publication",
    "log_update_DELETED": "Supression de la publication",
    "log_updatestatus_UNDER REVIEW" : "Soumission pour publication",
    "log_updatestatus_DELETED": "Supression de la publication",
    "log_update_UNPUBLISHED": "Retiré de la publication temporairement",
    "log_update_REJECTED": "Rejet par l'administrateur",
    "log_update_WILLEXPIRE": "Notification de l'expiration prochaine",
    "log_delete" : "Effacement définitif",
    "log_auth_Access granted , welcome !" : "acces authorisé", 
    "log_auth_incorrect LOCAL  password  - please check" : "access denied - bad password",
    "log_auth_incorrect Login name" : "access denied - bad user name",
    
    //valeur des priorités 
    "pty_normal" : "Normale",
    "pty_top" : "En tête de gondole",
    "pty_permanent" : "Permanente",
    "pty_news" : "Article/news",  
    "top" : "A la une",
    "most viewed" : "Les plus vues",


    // paypal 
    "You have paid options for <b>%s %s %s </b>" : "Vous avez des options payantes pour un montant de <b>%s %s</b> %s.", 
    "Payment successful": "Paiement bien reçu !", 
    "Thanks you for your payment ! Your ad will now be submitted for approval." : "Merci pour votre paiement ! Votre annonce va être maintenant validée par notre commité éditorial avant publication.", 
    "Thanks you for your payment ! Your ad is now published." : " Merci pour votre paiement ! Votre annonce est publiée.", 
    "Payment cancelled" : "Paiement Annulé !", 
    "Your payment is cancelled. You can retrieve your ad into your dashboard." : "Votre paiement est annulé. Vous pouvez retrouver votre annonce/ service dans votre tableau de bord.",
    "Paypal redirection ongoing" : "Nous contactons PAYPAL ...", 
    "You will be redirected to paypal for finalizing payment." : "Vous allez être redirigé vers PAYPAL pour régler la transaction.", 
    "Payment finalization"  : "Finalisation du paiement ...", 
    "Thanks you for your payment ! We are updating your order, please wait." : "Merci pour votre paiement!. Nous mettons à jour votre annonce. Merci de patienter!", 
    "paypal - This transaction does not exist or has already been processed" : "Désolé, cette transaction n'existe pas ou a déjà été reglée.",
    "paypal payment sucessfull" : "La paiement PAYPAL  a été correctement effectué", 
    "Payment finalization ongoing" : "Patientez, finalisation du paiement ...",     

    // champs du log des paiements
    "paymentdate" : "date", 
    "amt" : "montant", 
    "paymentstatus" : "état",
    "transactionid" : "ID de la transaction",  

    // type comptes utilisateurs
     "protype_pri" : "Privé",
     "protype_pub" : "Public",
     "protype_pro" : "Professionnel",
     "protype_par" : "Particulier", 
     "protype" : "Compte",
     "private" : "Privé",
     "public" : "Public", 
     "pro" : "Professionnel",
     "par" : "Particulier", 
     "help_protype" : "Précisez si vous étes un particulier ou un professionnel",
     "desc_indir" : "Visible annuaire", 
     "help_indir" : "Permet de vous rendre visble dans l'annuaire/boutique du site", 
     "desc_account_type" :"Type de compte", 

     // annonces relatives :
     "related ads " :  "annonces ", 


    // actions
    "delete all auth logs" : "Effacer tous les logs d'AUTHentification", 
    "delete all cron logs": "Effacer tous les logs ROBOTS", 
    "delete all sec logs" : "Effacer tous les logs SYSTEMS", 
    "batch actions" : "actions en masse >>",
    "help_logs_batch_actions_menu" :"Affiche le menu pour lancer des actions en masse sur ces enregistrements.",
    "help_delete_logs_auth" : "Cette action efface toutes les entrés de type authentification dans les logs",
    "help_delete_logs_auth" : "Cette action efface toutes les entrés de type authentification dans les logs", 
    "help_delete_logs_cron" : "Cette action efface toutes les entrés de type CRON/Automates dans les logs",
    "help_delete_logs_sec" : "Cette action efface toutes les entrés de type System/Securité dans les logs",    
    
    // ecran de detail d'un article 
    "ad id" : "Num article ",
    "ad status" : "Publication ",
    "ad priority" : "Priorité ",
    "ad moddate" : "Modifié le ",
    "ad publiched the" : "le",
    "ad hits" : "vue(s) ",
    "ad vendor info" : "Auteur",
    "ad info" : "Détails",
    "ad actions" : "Actions",
    "ad admin" : "gestion de l'article",
    "ad qr code" : "Retrouver cet article",
    "ad edit" : "éditer",
    "ad reset hits" : "reset le nr de vues", 
    "ad savefav" : "ajouter à favoris",
    "ad twitter" : "partager sur Twitter",
    "Share" : "partager ... ",
    "more ..." : "plus ...",
    "less ..." : "moins ...",
    "share on twitter" : "partager sur Twitter",
    "share on facebook" : "partager Facebook",
    "share on Linkedin" : "partager Linkedin",
    "share on Google+" : "partager Google+",
    "clip to Evernote" : "capturer Evernote",
    "bookmark this on Delicious" : "Lier dans Delicious",
    "ad facebook" : "partager sur Facebook",
    "One article of interest" : "Une annonce sympa",
    "ad del savefav" : "retirer des favoris",
    "ad email it" : "envoyer par email",
    "ad print" : "imprimer",
    "ad flag it abuse" : "notifier d'un abus",
    /*
    "previous ad" : "précédent",
    "next ad" : "suivant",
    "next" : "suivant",
    "previous" : "précédent",
    */
    "previous ad" : "<",
    "next ad" : ">",
    "next" : ">",
    "previous" : "<",
    
    "elem logs": "Historique", 
    "Display elem logs": "Affichage de l'historique", 
    

    "free" : "gratuit",
    "more if registered" : "identifiez vous pour +",
    "Send a messge to the seller" : "Envoyez un message au vendeur",
    "Contact the user through the website" : "Contacter via le site web", 
    "send email" : "Lui envoyer un email",
    "call number" : "Appeler ce numéro",
      
    // help on buttons : 
    "title clip to Evernote" : "Capturer et se rappeler l'annonce dans Evernote",
      
    // login form title
    "You must be registered" : "Vous devez être identifié / enregistré pour cette action.",
    "Login form title" : "Identification",
    "login form introduction": "Identifiez vous pour accéder, créer ou gérer des petites annonces.",
    "register introduction": "Si vous n'êtes pas encore enregistré, ",
    "login_register": "enregistrez vous ici !",
    "login_lostpassword": "Perdu votre mot de passe ? ",
    "email address not known" : "cette adresse email est inconnue", 
    "login": "S'identifier",
    "login name" : "Nom utilisateur",
    "login email" : "E-mail",
    "login_rememberme" : "se rappeler de moi",
    "submit login" : "se connecter",
    "logout": "se déconnecter",
    "welcome %s": "Bonjour <strong>%s</strong> ",
    "profil": "Mon profil",
    "Access granted , welcome !" : "L'accès est autorisé, Bienvenue !", 
    "Correctly logout and cookies deleted" : "Vous êtes maintenant déconnecté.",
    "incorrect LOCAL  password  - please check" : "L'authentification a échoué : mot de passe incorrect.",
    "incorrect Login name" : "L'authentification a échoué : nom d'utilisateur non reconnu.",
    "Register": "s'enregistrer",
    "Login in progress ..." : "Identification en cours ...",
    "Loading in progress ..." : "Chargement en cours ...",
    
    // leaflet special texts
    "leaflet footer text"  : "Cette Annonce a été crée, imprimée et disponible du site de petites annonces", 
    "Select the main picture, click <a id='print' href='#'>here</a> to print and clip along the line": "Sélectionnez les images à afficher, <a id='print' href='#' nottip='yes' >imprimez</a> et découpez suivant les pointillés. ",
    "ad leaflet print" :"Imprimer affichette", // important sans espace pour IE 
    
    // email form title
    "email lost form title" : "Réinitialiser le mot de passe", 
    "email support form title" : "Nous contacter", 
    "email feedback form title" : "Signaler un problème", 
    "email remind form title" : "Me rappeler ce message", 
    "email contact form title" : "Contacter le vendeur", 
    "email abuse form title" : "Notifier un abus", 
    "email contactuser form title" :  "Envoyer un message à cet usager",
    
    "email lost form introduction" : "Entrer votre l'adresse email utilisée pour l'inscription. Un nouveau mot de passer sera envoyé à cette adresse.", 
    "email support form introduction" : "Utiliser ce formulaire pour nous contacter pour toutes demandes. ",
    "email feedback form introduction" : "Utiliser ce formulaire pour signaler tout soucis, amélioration ou demande de fonctionnalité.",
    "email abuse form introduction" : "Utiliser ce formulaire pour soumettre un abus identifié sur un contenu .",
    "email contact form introduction" : "Utiliser ce formulaire pour contacter un vendeur ou répondre à une annonce.", 
    "email remind form introduction" : "Utiliser ce formulaire pour m'envoyer les détails de cette annonce.", 
    "email contactuser form introduction" : "Utiliser ce formulaire pour envoyer un message à cet utilisateur.",
    
    "your email" : "Votre email", 
    "email title" : "Objet", 
    "email description" : "Détails", 
    
    "submit lost email" : "Réinitialiser", 
    "submit support email" : "envoyer le message",
    "submit feedback email" : "envoyer la demande",  
    "submit abuse email" : "envoyer le message",
    "submit contact email" : "envoyer le message",  
    "submit remind email" : "envoyer le message", 
    "submit contactuser email" : "lui envoyer ce message",  
    
    "Confirm modification" : "Confirmer votre modification ? ", 
    "Please confirm modification to status 40 of :" : "En cliquant, <i>je confirme</i>, l'élément ci-dessous sera publiée. Vous pouvez également envoyer un message à l'éditeur.",
    "Please confirm modification to status 90 of :" : "En cliquant, <i>je confirme</i>, la publication de l'élément ci-dessous sera rejetée. Indiquez la raison du rejet qui sera notifiée par email à l'auteur.",
    "Please confirm modification to status 80 of :" : "En cliquant, <i>je confirme</i>, l'élément ci-dessous sera supprimé de la publication.",
    "your message": "Votre message", 
    "Why ?": "Raison ?",


    "Message sending in progress" : "message en cours d'envoi ...", 
    "Message sucessufully sent !" : "Message envoyé sans problème!",
    
    "This operation is not authorized !" :  "Vous n'étes pas autorisé à faire cette opération.", 
    "You have exceeded the commercial limits : MAX AD" :  "Vous avez dépassé les limites commerciales (Nombre Max d'annonces), veuillez contacter votre administrateur.",
    "You are not authorised to access this section. You have been redirected to home page." : "Vous n'avez pas accés à cette partie du site. Vous avez été re-dirigés vers la page d'accueil.", 

    "Login in progress" : "identification en cours ...", 
    "Error in Login form" : "erreur dans la saisie",
    "incorrect Login/password" : "Erreur lors de l'autentification , identifiant ou mot de passe incorrect.",
    "Your acount is created, please login to connect : ": "Votre compte est correctement crée.",
    "Congratulation !" : "Félicitations !", 
    "refresh your page to automaticaly login" : "Rafraichir votre page pour accéder.", 
    
    "ZADS, I want to have more information on element :" : "Votre annonce, je souhaite plus d'info sur : ",  
    "ZADS, I want to have more information" : "Je souhaiterais plus d'information sur ...",
    "ZADS, I want to have more information" : "Plus d'informations sur votre annonce ?",
    
    "user vendor info" : "Informations principales",
    "user actions" : "Outils",
    "user info" : "Divers",
    "user id" : "IDentifiant",
    "user status" : "Etat",
    "user type" : "Droits",
    "user register date" : "Créé/modifié le",
    "user last visit date" : "Dernière visite",
    "ad registration date" : "Créé le",
    "ad modification date" : "Modifié le",
    
    "contact him" : "répondre",
    "Send him a message" : "Envoyer un email",
    
    "user savefav" : "+ mes favoris",
    "user email it" : "envoyer par email",
    "user print" : "imprimer",
    "user flag it abuse" : "notifier d'un abus",
    
    "hits : %s times" : "vu %s fois", 
      
    // modal box
    "modbox close" : "fermer",
    "info" : "Information",
    "error" : "Erreur",
    "success" : "Opérations exécutée avec succès",
    "Server request timeout" : "désolé, le serveur ne repond pas ou n'est pas accessible.",
    
    // messages 
    "Action not yet available": "Cette action n'est pas encore disponible. Désolé !",
    "Yay! Everything went well!" : "Votre action/modification s'est passée avec succès !",
    "ok ad under review" : "Votre annonce est bien prise en compte. Elle sera publiée aprés revue par le comité éditorial.",
    "ok ad deleted" : "Votre annonce est effacée. Elle reste neanmoins disponible 30 jours si vous changez d'avis.",
    "ok ad published" : "Félicitations ! Votre annonce est maintenant publiée. Elle restera visible 30 jours maximum.",
    "ok user registered" : "Votre accés est maintenant crée. Vous pouvez vous identifier maintenant pour accéder au site.",
    "error in form checking" : "Le formulaire n'est pas complété correctement, merci de vérifier les champs marqués d'une erreur.",
    "Doh! Something happened : A user with this email already exist." : "Cette adresse email est deja utilisée. Merci d'en choisir une autre.",
    "Doh! Something happened : This username is not available.": "Cette nom de login est déja utilisé. Merci d'en choisir un autre.",
    // main menu
    "containing <b>%s</b> word" : "contenant le mot <span class='highlight'>%s</span>",
 
    //user menu 
    "create ad" : "Créer une annonce", 
    "create user" : "Créer un usager", 
    "create zetvu" : "Créer un ZeTvu", 
    "admin (dashboard)" : "administration", 
    
    // geolocatization 
    "Geo-localization successful" : "Votre localisation a été touvée : ", 
    "Selected Geo-localization successful" :  "Votre localisation choisie a été identifée : ", 
    "Geo-localization failed" : "Erreur lors de la geo-localisation : ",
    "Geoloc not available in your navigator" : "Cette fonction n'est pas disponible sur votre navigateur.",
    "Geo-localization time-out" :"Geo-localisation : pas de réponse du serveur",
    "Geo-localization permission denied":"Geo-localisation : autorisation refusée",
    "Geo-localization position unavailable":"Geo-localisation : votre position n'est pas disponible",
    "Goecoding error : "  : "Erreur lors de la geo-localisation : ", 
    "your location" : "Votre localisation",
    "Geo-localization in progress":"Geo-localisation en cours ...",
    "Geo-localization error"  : "Erreur lors de la geo-localisation",
    "Geo-localization can move marker to select other":"Vous pouvez déplacer le marqueur à l'adresse qui vous convient.",
    "Release the Marker to the desired address" : "... déposer le marqueur à l'adresse souhaitée.", 
    "getting address...":"adresse complète en cours de détermination",
    "Error in Google Map loading. Check your internet connection." : "Chargement de GOOGLE MAP impossible. Vérifiez votre connexion internet.",
    //list view
    "Sort by:" : "Trier par:",
    "Most recent" : "Plus récent",
    "Lowest price" : "Prix plus bas",
    "Highest price" : "Prix plus haut",
    "Highest hits": "Plus vus",
    "Sort by price desc" : "Trier par prix le plus haut",
    "Sort by price asc" : "Trier par prix le plus bas",
    "Sort by date desc" : "Trier par date",
    "Sort by hits desc" : "Trier par popularité",
    "Sort by name asc" : "Trier de A à Z",
    "Sort by ad nb desc" : "Trier par nombre d'annonces",
    "Sort by whatid desc" : "Trier par IDs décroissants",
    "Sort by what desc" : "Trier par type",
    
    "By " : "Par ",
    "previous page" : "pages préc.",
    "next page" : "pages suivante",
    "help prev" : "pages préc.",
    "help next" : "pages suivante",
    
    "Ads <b>%s</b> to <b>%s</b> of <b>%s</b> ads" : "( <b>%s</b> à <b>%s</b> / <b>%s</b>)",
    "<b>%s</b>-<b>%s</b> of <b>%s</b>" : "<b>%s</b>-<b>%s</b> sur <b>%s</b>",
    
    "Back" : "retour", 

    // sub-menu 
    "myads" : "Mes annonces",
    "my_ad" : "mes annonces",
    "myadmin" : "Mon compte",
    "my_admin" : "Mon compte",
    "admin" : "Administration",
    
    "allads" : "Annonces",
    "all ad" : "Toutes les annonces",
    "all ads" : "Toutes les annonces",
    "admin_ad" : "Toutes les annonces",
    "admin_user" : "Tous les usagers",
    "allusers" : "Usagers",
    "admin_all" :"",
    "all users" : "Tous les usagers",
    "all services" : "Tous les services",


    "all logs" : "Toutes les entrées du journal",
    "all payments" : "Toutes les paiements",
    "all status" : "Tous les états",
    "manageother" : "Autre gestion",
    "all cat" : "Toutes les catégories",
    "all user" : "Tous les usagers",
    "all admin_user" : "Tous les usagers",
    "all admin_cat" : "Toutes les catégories",
    
    "dashboard" : "Tableau de bord",
    "dash no data" : "Aucune donnée à afficher",
    "mydashboard" : "Mon tableau de bord",

    "user" : "usagers",
    "cat" : "catégories",
    "files": "fichiers",
    "bytes" : "octets",  
    "ad" : "annonce", 
    "ads" : "annonces", 
    "all myads" : "Mes annonces",
    "all my_ad" : "Toutes mes annonces",
    "all admin_ad" : "Toutes les annonces",
    "myads_published" : "Publiée(s)",
    "myads_all" : "Toutes",
    "myads_pending" : "En attente(s)",
    "myads_draft" : "En brouillons",
    "myads_draftpendingpayment" : "Paiements en attente",
    "myads_deleted" : "Expirée(s)",
    "published" : "publiées",
    "pending" : "en attentes",
    "willexpire" : "vont expirer",
    "draft" : "brouillons",
    "draft pending payment" : "Paiements en attente", 
    "deleted_expired" : "expirées",
    "deleted" : "expirées",
    "ads_published" : "Annonces",
    "ads_draft" : "Brouillons",
    "admin_pending" : "A valider",
    "admin_underreview" : "A valider",
    "admin_willexpire" : "Vont expirer",
    "admin_expired" : "Expirées",
    "admin_deleted" : "Expirées",
    "admin_published" : "Annonces",
    "admin_published" : "Publiées",
    "admin_draft" : "Brouillons",
    "admin_draftpendingpayment" : "Attente paiements",
    "admin_draft pending payment" : "Attente paiements", 
    "admin_willexpire" : "Vont expirer",
    "admin_expired" : "Expirées",
    "admin_rejected" : "Rejetées",
    "admin_under review" : "En cours de revue",
    "admin_user_draftpendingpayment" : "Attente paiements",
    "admin_user_pending" : "A valider",
    "admin_user_published" : "Validés",
    "admin_user_draft" : "Non Confirmés",
    "admin_user_rejected" : "Rejetés",
    "myprofile" : "Mon profil",
    "myfav" : "Mes favoris",
    "manage_settings" : "Configuration",
    "manage_ads" : "Annonces (toutes)",
    "manage_users" : "Usagers (tous)",
    "manage_cats" : "Catégories",
    "manage_zetvu" : "Zetvu/News/Videos",
    "manage_twitter" : "Tweeter",
    "manage_logs" : "Journal/logs",
    "manage_payments" : "Journal des Paiements",
    
    "category":"Catégories",
    
    // tooltips 
    "Show List" : "Afficher sous forme de liste avec photo",
    "Show Gallery" : "Afficher sous forme de Galerie photo",
    "Show simple List" : "Afficher sous forme de liste simple",
    "Show map List" : "Afficher une carte googlemap avec les annonces localisées",
    "help_on_status DRAFT" : "Cet élément est en état brouillon et pas publié",
    "help_on_status DRAFT PENDING PAYMENT" : "Cet élément est en attente de paiement avant soumission",
    "help_on_status PUBLISHED" : "Cet élément est publié",
    "help_on_status UNDER REVIEW" : "Cet élément est en cours de revue et d'acceptation par l'éditeur",
    "help_on_status UNPUBLISHED" : "Cet élément est retiré de la publication",
    "help_on_status REJECTED" : "Cet élément a été rejeté par l'éditeur, merci de le modifier",
    "help_on_status DELETED" : "Cet élément est en archive. Il sera  effacé ",
    "help_on_status WILLEXPIRE" : "Cet élément va expirer ",
    "help_on_status pty_top" : "Cet élément est en tête de gondole",
    
    "help_on_status protype_pub" : "Ce compte est public et visible par tous",
    "help_on_status protype_pub" : "Ce compte est privé et pas visible pour des visiteurs",
    "help_on_status protype_pro" : "Ce compte est professionnel et visible pour tous",
    "help_on_status protype_pri" : "Ce compte est un Particulier",
    "help_on_status protype_par" : "Ce compte est un Particulier",
    
    
    "view all" : "Voir tout",
    "help link Main List" : "Retour à la liste initiale",

    "help password rules" : "Un bon mot de passe est différent du login et contient des chiffres et des lettres. Suivez les indications !",
    
    "help_myads_published" : "Mes articles publiés",
    "help_myads_all" : "Toutes mes annonces quelque soit l'état",
    "help_myads_pending" : "Mes articles en attente de validation",
    "help_myads_draft" : "Mes articles brouillons ou rejetés",
    "help_myads_draftpendingpayment" : "Mes articles en attente de paiement",
    "help_myads_deleted" : "Mes articles expirés ou supprimés",
    "help_myprofile" : "Voir mon profil",
    "help_myfav" : "Voir mes articles favoris",
    "help_admin_pending" : "Articles à approuver",
    "help_admin_underreview" : "Articles à approuver",
    "help_admin_willexpire" : "Articles qui vont expirer prochainement",
    "help_admin_expired" : "Articles expirés ou supprimés",
    "help_admin_deleted" : "Articles expirés ou supprimés",
    "help_admin_draftpendingpayment" : "Articles en attente de paiement",
    "help_admin_user_draftpendingpayment" : "Comptes en attente de paiement",
    "help_manage_settings" : "Paramètres du site",
    "help_manage_services" : "Gérer les packs de services",
    "help_manage_ads" : "Tous les articles dans tous les états",
    "help_manage_cats" : "Gérer les catégories",
    "help_manage_users" : "Gérer les usagers",
    "help_manage_twitter" : "Envoyer des tweets directement",
    "help_dashboard" : "Accéder au tableau de bord",
    "help_mydashboard" : "Accéder à mon tableau de bord",
    "help_manage_logs" : "Afficher les journaux/logs des modifications et connections",
    "help_manage_payments" : "Afficher les paiements reçus",
    "help_manage_zetvu" : "Gestion des annonces de type Zetvu/News/Videos",

    "Sorry !":"Désolé !", 
    "No items found" : "Aucun élément trouvé correspondant à votre demande. Certaines demandes nécessite de s'identifier.",
    "No items found - No ad" : "Vous n'avez pas encore d'annonces", 
    
    //tweeter
    "What are you doing?" : "Quoi de neuf ?",
    "twitter header" : ": tweeter directement",
    "Loading your tweets..." : "chargement de vos derniers messages en cours ...",
    "Timeline" : "Fil",
    
    // global home page messages 
    "You have %s article(s) waiting for your approval" : "Vous avez %s annonce(s) qui attendent votre approbation : ", 
    "access here" : "cliquez ici pour accéder",   
    
    // templates
    "some text"  : "une traduction de patrice  from patrice",
    "some more text"  : "another translation",
    "some text in french":"avec des é et des è",
    '%s text in french %s' : '%s exemple avec printf %s', 
    '%s text in french' : '%s exemple avec printf simple', 
    'text in french' : 'texte en francais',
    
    // dashboard 
    'adsnb' : 'nombre',
    '%adsnb' : '%',
    'val' : 'nombre',
    '%val' : '%',
    'metrics' : 'nombre',
    '%metrics' : '%',
    'nb' : 'nombre',
    'nbusers' : 'nombre',
    '%nbusers' : '%',
    'cattitle' : 'catégorie',
    'status' : 'état',
    'others' : 'autres',
    
    "dash manage ads" : "(voir/gérer)", 
    "dash manage users" : "(voir/gérer)",
    "dash manage cats" : "(voir/gérer)",
    "cumul users"  : "# usagers (cumul)",
    
    "a10": "brouillon",
    "a20": "en cours de revue",
    "a40": "publié(e)",
    "a60": "re-travail",
    "a80": "supprimé(e)",
    "a90": "rejeté(e)",
    "a45": "va expirer",
    
    'fb' : 'Facebook',
    
    'stat dashboard title' : 'Tableau de bord (Admin)', 
    'stat mydashboard title' : 'Mon Tableau de bord', 
    
    'top_dashboard' : 'Vue générale', 
    'ad_vol_per_cat' : 'Annonces par catégories', 
    'ad_vol_per_type' : 'Annonces par type', 
    'ad_vol_per_time' : 'Annonces dans le temps', 
    'ad_vol_per_delete' : 'Raisons de suppression annonces',
    
    'ad_vol_per_status' : 'Annonces par état de publication', 
    'user_vol_per_time' : 'Utilisateurs dans le temps', 
    'user_vol_per_age' : 'Utilisateurs par ancienneté', 
    'ad_vol_per_age' : 'Annonces par ancienneté', 
    'user_vol_per_type' : "Utilisateurs par type d'authentification",
    'user_vol_per_protype' : "Utilisateurs par profils",  
    'ad_vol_per_user' : 'Annonces par utilisateurs', 
    
    'Observation period : ' : 'Période : ', 
    'all' : 'toutes', 
    'thisyear' : 'cette année', 
    'thismonth' : 'ce mois',
    'thisquarter' : 'ce trimestre',
    '-- all time --' : '-- Tout --', 


    // footer translation 

    // "A propos de ZADS" : "About", 
    // "ZADS est une plateforme d'échange d'annonces entre particuliers dans un domaine privé comme une entrepsie ou une collectivité." :
    //     "ZADS is a classidied ads platform available in hosted or in script mode to enable community to exchange product and services", 

    // "En savoir plus" : "Find our more", 
    // "S'abonner": "Subsribe", 
    // "Annonces par email":"Ads by email",    
    // "Offres et Demandes" : "Sell and Buy", 
    // "Aide et Support" : "Help and support", 


    // "Aide et Support" : "Help and Support", 
    // "Questions Frequentes (FAQ)" :"F.A.Q", 
    // "Tutoriels et démos" :"Demo and Tutorials", 
    // "Signaler un probléme":"Notify us on an issue", 
    // "Suivre / Contact" : "Follow / Contact",
    // "suivre ZADS.FR sur Twitter"  : "Follow us on Twitter", 
    // "suivre ZADS.FR sur Facebook"  : "Follow us on Facebook", 


    // "Me contacter" : "Contact us", 
    // "A propos" : "About this", 
    // "Infos légales et CGU"  : "Terms and Conditions", 
    // "Publicité" : "Advertising",
    // "Nous contacter" : "Contact us",
    // "Aide" :  "Help", 
    // "F.A.Q" :  "F.A.Q",  

    // new ZADS 4.6
    "around me :": "proche de:", 
    ":unknown":": ou?", 
    "(change)" : "(changer)",
    "(locate me)" :"(me trouver)", 


    "display failed" : "Erreur", 
    "Doh! Something happened : no authorized - private profile" : "Vous n'êtes pas autorisé à accéder à ces informations", 

    "post paidaccount" : "compte payants (prix par an)  : ", 
    "help_protype_paid" : "compte d'accés au site our un nombre illimité d'annonces. Prix par an. Voir conditions générales.",

    "Process ongoing ..." : "Travail en cours, veuillez patienter ...", 


    // banners management 
    "title" :"Titre",
    "htmlcode": "Code Html",
    "clicktrackingurl": "URL clicktracking", 
    "startdate": "Date de début", 
    "enddate": "Date de fin", 
    "position": "Emplacement", 
    "clicks": "Clicks", 
    "impressions": "Imp.", 
    "CTR": "CTR", 
    "resetclicks" : "Remise à zéro des compteurs clicks et impressions",


    "add banner" :"ajouter une bannière publicitaire",  
    "Create banners" : "ajouter une bannière publicitaire",  
    "all banners" : "Toutes les banniéres", 
    "manage_banners" : "Gestion de publicités",
    "help_manage_banners" : "Gestion de publicités",

    "Banner reset clicks confirmation" :"Confirmation remise à zéro",
    "Banner reset clicks content" : "Confirmation de la remise à zéro des compteurs clicks et impressions", 
    "Banner delete confirmation" : "Confirmation effacement définitif",  

    " banner form header title" : "Création d'une bannière publicitaire",
    " banner form header introduction" :"Ci-dessous, créer une bannière publicitaire",
    "modify banner form header title" : "Modification d'une bannière publicitaire",
    "modify banner form header introduction" :"Ci-dessous, modifier la bannière publicitaire existante",


    // extended contact form
    "contact reason" : "Demande", 
    "procpny": "Société", 
    "to email" :"Destinataire",

    '-- select one --' : '-- indiquez le type de demande --',
    "Subscription" : "Inscription", 
    "Advertising" : "Publicité", 
    "Information" :"Information", 
    "Support" :"Aide technique", 
    "Other" : "Autres demandes", 

    "Account fee is <b>%s %s %s</b> per period" : "L'accès au service est facturée <b>%s %s %s</b> par mois", 

    "Please validate the location" : "Merci de valider cet emplacement",

    "top register user" : "S'inscrire", 

    // new zads 4.8 : 
    "Thanks you for your payment ! Your account is create, please login to connect" : "Merci pour votre réglement ! Votre compte est disponible.<br> Identifiez vous avec votre login et mot de passe choisi. ",
    "show all" : "Voir toutes les annonces", 
    "Sort by hierarchy" : "Trier par hiérarchie",
    "cat order plus" : "Augmenter la rang d'affichage (0=affiché en premier)",
    "cat order minus" : "Diminuer le rang d'affichage (0=affiché en premier)",

    "pub users" : "Autres annonceurs", 
    "Main list" : "retour à la liste principale", 

    // place to translate catégories 
    "Categorie initial" : "NOM DE LA CAT TRADUITE", 
    "patmisc à é é ç" : "je suis traduite",


     // ----------  new zads 4.9 : 

    "plan_step1" : "Choisir son abonnement", 
    "plan selection header title" : "plan selection header title",
    "plan selection header line1" : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent accumsan elit ligula. Nam in molestie orci. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nullam in magna tortor. Donec nisl mauris, vulputate id urna in, pharetra suscipit purus. Nam commodo mauris vel bibendum dapibus. Phasellus euismod metus ut felis adipiscing, commodo lobortis mi imperdiet. Quisque sit amet est eu arcu bibendum tincidunt. Praesent id sapien sed massa accumsan luctus. Sed non adipiscing sapien. In nisl nulla, aliquam a placerat quis, convallis eget quam. In hac habitasse platea dictumst. Aenean tempor arcu eu dui pharetra, eu hendrerit massa feugiat. Proin ipsum mauris, sagittis tempus turpis a, interdum facilisis turpis. Curabitur augue odio, faucibus et tristique quis, porta at ante. Vestibulum augue lorem, pellentesque non ante nec, auctor tristique est.",
    "plan selection footer line1" : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent accumsan elit ligula. Nam in molestie orci. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nullam in magna tortor. Donec nisl mauris, vulputate id urna in, pharetra suscipit purus. Nam commodo mauris vel bibendum dapibus. Phasellus euismod metus ut felis adipiscing, commodo lobortis mi imperdiet. Quisque sit amet est eu arcu bibendum tincidunt. Praesent id sapien sed massa accumsan luctus. Sed non adipiscing sapien. In nisl nulla, aliquam a placerat quis, convallis eget quam. In hac habitasse platea dictumst. Aenean tempor arcu eu dui pharetra, eu hendrerit massa feugiat. Proin ipsum mauris, sagittis tempus turpis a, interdum facilisis turpis. Curabitur augue odio, faucibus et tristique quis, porta at ante. Vestibulum augue lorem, pellentesque non ante nec, auctor tristique est.",


    "email" : "E-mail",

    "us_protype" : "Type usager",
    "us_skills"  : "Catégorie (s)",
    "us_avatarimg"  : "Logo",
    "us_bio"  : "Courte présentation",
    "us_longdesc"  : "Longue présentation",
    "us_folioimg"  : "Galerie photos",
    "us_videoembed"  : "Lien Video",
    "us_phone" : "Téléphone",
    "us_dispemail" : "E-mail",
    "us_subscription" : "jours accès",
    "us_prowebsite" : "URL site",
    "us_links" : "Liens usager",
    "ad_nb" : "annonces",
    "ad_nbpics" : "images",
    "ad_duration" : "",
    "ad_featured" : "",
    "ad_perm" : "",
    "ca_restricted" : "",
    "ad_videoembed" : "Lien Video", 
    "ad_links": "Liens An.", 
    "ad_enemail":"Contact E-mail", 
    "ad_enphone":"contact Tél.", 
    
    "sign up" : "Signer pour ce plan",
    
    "plans_faq_1_question" : "Lorem ipsum dolor sit amet, consectetur",
    "plans_faq_1_response" : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras commodo nec elit nec sollicitudin. Aenean rutrum, magna a venenatis lobortis, lacus nisi tristique est, id euismod ante dolor vel orci. Quisque porttitor augue at fermentum ultricies.",

    "plans_faq_2_question" : "Lorem ipsum dolor sit amet, consectetur",
    "plans_faq_2_response" : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras commodo nec elit nec sollicitudin. Aenean rutrum, magna a venenatis lobortis, lacus nisi tristique est, id euismod ante dolor vel orci. Quisque porttitor augue at fermentum ultricies.",


    // nouvelles entrése du formulaire 
    "desc_label_plan" : "Type d'abonnement", 
    "desc_plan" : "Abonnement" ,
    "you selected the  plan  : " : "Vous avez choisi l'abonnement : ", 
    "help_plan" : "Ceci indique le type d'abonnement que vous avez choisi.", 
    "desc_longdesc" :"Présentation étendue",
    "help_longdesc" :"Présentation étendue de votre socièté",

    "longdesc" : "Présentation étendue",
    "videoembed" : "Présentation Video",

    // enhancements of zads 4.9
    "See details of this user" : "Voir la fiche détaillée de cet annonceur", 
    "See all ads from this seller" : "Voir toutes les annonces de cet annonceur", 
    "See all ads" : "Toutes ses annonces",

    // pricing type 
    "desc_pricetype" : "Prix (autres)", 
    "help_pricetype" : "Indiquez ici si vous souhaitez ou proposez un prix spécial autre que celui indiqué.", 
    "price" : "prix indiqué",
    "to be discussed" : "à discuter",
    "make an offer" : "faire offre",
    "on quote" : "sur cotation",
    "model dependant" : "dépend du modèle",

    "pricetype_tbdi" : "à discuter",
    "pricetype_mano" : "faire offre",
    "pricetype_onqo" : "sur cotation",
    "pricetype_mode" : "dépend du modèle",
    "pricetype_sala" : "salaire",

    "ad videoembed" : "Video", 
    "(read more)" : "(lire la suite)",

    "Ad creation forbidden from your current profile.": "La création d'annonces n'est pas autorisée avec cet abonnement. ", 
    "pro you have exceeded quota of ad." : "La création d'annonce n'est pas possible car vous avez dépassé les limites de votre abonnement. ",
    "par you have exceeded quota of ad." : "La création d'annonce n'est pas possible car vous avez dépassé les limites de votre abonnement. ",

    // location based 
    "loccity" : "Ville", 
    "locdept" :"Département", 
    "locregion" : "Région",

    // traductions pour plan princing (customer specific)
    // SELECT INPUT 
    "-- no plan --" : "-- pas d'abonnement spécifique --", 
    "options_Basic" : "Abonnement Basic", 
    "options_Premium" : "Abonnement Premium", 
    "options_Pro" : "Abonnement Pro", 

    "more cat" : "Voir la liste complète ...", 
    "less cat" : "... Réduire ...",



    // zads @4.9.2
    "edit my profile" : "Editer mon profil", 


    // zads@4.9.5
    "a45": "va expirer",
    "a15" : "paiement en attente", 
    // -- payment logs
    "<b>%s</b> payment(s) - total amount = <b>%s</b> %s" : "<b>%s</b> paiement(s) pour un montant de = <b>%s</b> %s", 
  
    "-- select what --" : "-- Tous les types de paiement --",
    "Only Ads" :  "Les Options payantes", 
    "Only Users" : "Les Abonnements payants",
    "Only Services" : "Les Services payants",

    // zads@4.9.7
    "Map home page  - first paragraph" : " ",
    "Map home page  - last paragraph" :  " " ,

    "user links" : "Liens Web(s)", 
    " add_links" : " ajouter un lien", 
    "url title placeholder" : "Titre du lien",
    "url placeholder" : "http:// ou www.monsite.com",
    "save this link" : "sauvegarder ce lien", 
    "link title" : "titre", 
    "link url" :"url", 
    "Incorrect URL format." : "format de l'url incorrect",
    "remove this link" : "retirer ce lien", 
    "help_links (%s max)" :  "ajouter des liens web externes, jusqu'à %s liens", 
    "settings" : "Configuration",

    " settings form header title" : "Gestion de la configuration du site",
    " settings form header introduction" : "A travers ces formulaires, gérer l'apparence et la configuration générale du site. Attention, certaines actions pourraient endommager le site. Veuillez consulter la documentation technique avant toute manipulation.",
    "BTN settings PUBLISHED" : "Sauvegarder les modifications",
    "Settings updated successfully" : "Sauvegarde des paramètres faite !", 
    "settings creation ongoing" : "Sauvegarde de la configuration en cours", 
    
    "settings_menu_site_details" : "Details",
    "settings_menu_general" : "Details",
    "settings_menu_site_pages" : "Pages",
    "settings_menu_sitepages" : "Pages",
    "settings_menu_site_metas" : "Metas/SEO",
    "settings_menu_general2" : "Metas/SEO",
    "settings_menu_site_layout" : "Thème/Disposition",
    "settings_menu_layout" : "Thème/Disposition",
    "settings_menu_life_cycle" : "Cycle de vie",
    "settings_menu_lifecycle" : "Cycle de vie",
    "settings_menu_emails" : "Emails",
    "settings_menu_social" : "Social",
    "settings_menu_security" : "Securité",
    "settings_menu_site_locale" : "Locale",
    "settings_menu_locale" : "Locale",
    "settings_menu_others" : "Autre (SEO, HEADER)",
    "settings_menu_site_links" : "Liens",
    "settings_menu_links" : "Liens",
    "settings_menu_superadmin" : "Options Avancées",
    "settings_menu_site_badwords" : "Mots interdits",
    "settings_menu_badwords" : "Mots interdits",
    "settings_menu_site_theme" : "Theme",
    "settings_menu_theme" : "Theme",
    "settings_menu_fields" : "Champs",
    "settings_menu_multitenant" : "Multitenants",
    "settings_menu_site_nav" : "Nav/Recherche",
    "settings_menu_mainnav" : "Nav/Recherche",

    "desc_settings" : "Configuration", 
    "desc_settings_path" : "Variante (path)", 
    "help_settings_path" : "Variante (path) : chemin indiquant ou les paramétres de tenant sont stockés.Si vide, utilise le chemin par défaut = 'settings/' ", 

    "desc_domain_fqdn" : "Nom de Domaine FQDN",
    "desc_domain_fqdn_short" : "FQDN court (pour SEO)",
    "desc_logo_fqdn" : "Emails logo (url)",
    "desc_logo_paypal_fqdn" : "PAYPAL Logo (url) ",
    "desc_site_name" : "Nom du site",
    "desc_site_motto" : "Devise du site",
    "desc_site_customer" : "Nom du client",


    "help_domain_fqdn" : "Nom de Domaine FQDN : exemple http://www.monsite.com/ - Attention ne pas oublier le / à la fin ! ",
    "help_domain_fqdn_short" : "nom de domaine court utilisé pour le référencement",
    "help_logo_fqdn" : "Url du logo utilisé puor les notifications par emails",
    "help_logo_paypal_fqdn" : "Url (ABSOLUE !!!) du logo affiché dans PAYPAL lors du paiement. Taille max: largeur=90 px/ hauteur=60 px en .gif, .jpg, or .png.",
    "help_site_name" : "Nom du site (pour les emails)",
    "help_site_motto" : "Devise du site (pour les emails)",
    "help_site_customer" : "Nom du client (pour les emails)",

    "desc_cust_site_name" : "Nom du site",
    "desc_cust_site_motto" : "Devise du site",
    "desc_cust_site_owner_accronym" : "Propriétaire",
    "desc_cust_site_owner_long" : "Nom Long proprio.",
    "desc_cust_loading_msg" : "Message chargement",
    "desc_cust_title" : "Titre (meta) ",
    "desc_cust_description" : "Description (meta)",
    "desc_cust_about_footer_desc" : "A propos", 
    "desc_cust_keywords" : "mots clefs (meta)",
    "desc_enable_auto_sitemap" : "Sitemap automatique",
    "desc_seo_include_zetvu" : "Référencement des ZETEVU",
    "desc_cust_logo_uri" : "Logo URL",
    "desc_cust_favicon_uri" : "Favicon URL",
    "desc_enable_img_autoswipe" : "Image Auto-swipe",


    "help_cust_site_owner_accronym" : "Accronym / nom de la société propriétaire du site pour être utlilisé dans les termes et conditions.",
    "help_cust_site_owner_long" : "Nom  LONG du propriétaire du site pour être utlilisé dans les termes et conditions",
    "help_cust_site_name" : "Nom du site tel qu'il apparaitra sur la page web",
    "help_cust_site_motto" : "Devise du site tel qu'il apparaitra sur la page web",
    "help_cust_loading_msg" : "Message de bienvenue qui s'affichera lors du chargement de la page",
    "help_cust_title" : "Titre su site  ",
    "help_cust_about_footer_desc" : "Texte affiché dans le A PROPOS en bas de page . Laisser vide pour ne pas l'afficher", 
    "help_cust_description" : "Description courte du site qui sert au référencement",
    "help_cust_keywords" : "mots clefs servant au référencement",
    "help_enable_auto_sitemap" : "Génération automatique d'un sitemap.xml et dépot sur la racine su site",
    "help_seo_include_zetvu" : "Référencement des ZETEVUs/ NEWS dans la sitemap",
    "help_cust_logo_uri" : "Logo URL",
    "help_cust_favicon_uri" : "Favicon URL",
    "help_enable_img_autoswipe" : "Image Auto-swipe : active le défilement autatique des images quand on passe la souris dessus en mode affichage de détails.",


    "desc_page_map" : "Page Avec Carte",
    "desc_page_map_first_p" : "Texte HTML entête",
    "desc_page_map_center_p"  :"Texte HTML centre",
    "desc_page_map_last_p" : "Texte HTML pied",

    "help_page_map" : "Page Avec Carte",
    "help_page_map_first_p" : "Paragraphe d'entête de la page principale d'accueil (code HTML avec ZADS KEYWORDS)",
    "help_page_map_center_p" : "Paragraphe au centre la page principale d'accueil (code HTML avec ZADS KEYWORDS)",
    "help_page_map_last_p" : "Paragraphe de pied de page de la page principale d'accueil (code HTML avec ZADS KEYWORDS)",

    "desc_social_links":"Liens SOCIAL",
    "desc_cust_facebook_url":"FACEBOOK (url)",
    "desc_cust_twitter_url":"TWITTER (url)",
    "desc_cust_gplus_url":"GOOGLE+ (url)",
    "desc_cust_youtube_url":"YOUTUBE (url)",
    "desc_footer_links":"Liens bas de page",
    "desc_cust_tandc_url":"Termes et conditions (url)",
    "desc_cust_rgda_url":"Régles de Diffusion (url)",
    "desc_cust_pub_url":"Publicité (url)",
    "desc_cust_contactus_url":"Nous contacter (url)",
    "desc_cust_aboutus_url":"A propos .. (url)",
    "desc_cust_whoweare_url":"Qui sommes-nous .. (url)",
    "desc_cust_faq_url":"F.A.Q (url)",
    "desc_cust_demo_url":"Demo (url)",
    "desc_cust_help_url":"Aide (url)",
    "desc_cust_pricing_url":"Tarifs (url)",
    "desc_cust_blog_url":"Blog (url)",
    "desc_cust_forum_url":"Forum (url)",

    "help_social_links":"Liens SOCIAL",
    "help_cust_facebook_url":"FACEBOOK url affichée en bas de page ou dans le widget social",
    "help_cust_twitter_url":"TWITTER url affichée en bas de page ou dans le widget social",
    "help_cust_gplus_url":"GOOGLE+ url affichée en bas de page ou dans le widget social",
    "help_footer_links":"Liens bas de page",
    "help_cust_tandc_url":"Lien (url) vers la page des Termes et conditions du site",
    "help_cust_rgda_url":"Lien (url) vers la page des Régles de Diffusion du site",
    "help_cust_pub_url":"Lien (url) vers une page indiquant les conditions de publicité",
    "help_cust_contactus_url":"Lien vers la formulaire de contact. Indiquer 'contact' pour utiliser le formulaire intégré au site.",
    "help_cust_aboutus_url":"A propos de ..url",
    "help_cust_whoweare_url":"Qui sommes-nous .. (url)",
    "help_cust_faq_url":"Lien (url) vers lune page de Questions/Reponses",
    "help_cust_demo_url":"Lien (url) vers une page Demo",
    "help_cust_help_url":"Lien (url) vers une page d'aide sur ce site",
    "help_cust_youtube_url":"YOUTUBE url",
    "help_cust_pricing_url":"Lien (url) vers la page des tarifs.",
    "help_cust_blog_url":"Lien (url) vers votre  site de blogging",
    "help_cust_forum_url":"Lien (url) vers votre FORUM",

    "desc_general" :"Général",

    "desc_theme_style":"Théme (expert)",
    "desc_layout_bg_pattern":"Image de fond",
    "desc_theme_css_url" : "URL theme CSS (delta)", 
    "desc_theme_master_css_url" :"URL theme CSS (master)",
    "desc_theme_cust_lang_url" :"URL correctifs langues",
    "desc_layout_header_widgets_en" :"Header widget",
    "desc_layout_gallerie_widgets_forced_fullwidth" :"Gallerie 100% large",

    "desc_enable_infinite_nav" : "Navigation infinie",
    "desc_enable_infinite_scroll" : "Déroulement infini",
    "help_enable_infinite_nav" : "Navigation infinie : à la fin de chaque page, un bouton à cliquer vous propose de charger la suite.",
    "help_enable_infinite_scroll" : "Déroulement infini : chargemement automatique des pages suivantes quand vous arrivez en bas de page",

    
    "help_layout_bg_pattern":"Nom de l'image de fond par défaut. Ne rien indiquer pour avoir un fond vide. L'image doit être dans préalablement stockée dans le répertoire /bg/ du site.",
    "help_theme_css_url" : "Ce champ, si renseigné, permet d'ajouter au site en place des CSS personnels qui peuvent être chargés sur le site via l'interface de gestion de fichier ou simple des CSS venant d'une URL publique", 
    "help_theme_cust_lang_url" :"URL du fichier de langue qui viendra completer le master language . Attention, le format ne doit pas terminer ne nom du fichier (exemple pour un fchier custo_fr_FR.js, indoquez uniquement le chemin + custo_, le reste sera ajouté par le site fonction de la langue choisie.",

    "help_theme_master_css_url" :"URL theme MASTER : permet de remplacer la feuille de style maitre par une autre feuille de style . Laisser vide si vous souhaitez utiliser la feuille maitre de base.",
    "help_layout_header_widgets_en" :"Permet d'afficher une zone de 200px en haut du site (entre la barre et le début de l'affichage) et positionner le logo et une publicité",
    "help_layout_gallerie_widgets_forced_fullwidth" :"Force le module/widget Gallerie A la une a avoir 100% la taille du site. Par défaut, elle est limitée à la zone d'affichage des annonces, sans la barre latérale",

    "desc_enable_country_map":"Carte premiére page",
    "desc_max_pages_to_show":"Max page",
    "desc_max_items_per_page":"Nombre item/page",
    "desc_layout_bg_pattern":"Image de fond",
    "desc_header_show_nb_ads" : "Affic. nbr annonces en haut",
    "desc_widgets":"Widgets",
    "desc_max_items_per_mod":"MAX article/widget",
    "desc_nb_items_per_vmod":"Nbr articles/widget",
    "desc_enable_mostviewed_mod":"Les plus vus",
    "desc_enable_top_mod":"A la une",
    "desc_enable_topgallery_mod":"Galerie",
    "desc_enable_browsebyloc_mod":"Localisation",
    "desc_browsebyloc_fields_order":"Location order",
    "desc_categories":"Catégories",
    "desc_max_cat_per_column":"Catégories/col",
    "desc_show_empty_cat":"Affichage Ad Vides",
    
    "desc_hide_empty_cat_users":"Masquer Cat. vides",
    "desc_hide_empty_buy_ad":"Catégorie 'buy' vides",
    "desc_display_more_cat_link":"Afficher 'plus'",
    "desc_max_skills_nb":"Max compétences",
    "desc_zetvu":"Zetevu/NEWS",
    "desc_disable_zetvu":"Désactiver",
    "desc_zetvu_as_news":"Mode News",
    "desc_zetvu_create_by_admin_only":"Création par Admin",

    "desc_enable_latest_mod":"Derniers Ajouts",
    "desc_enable_urgent_mod":"Annonces urgentes",
    "desc_enable_social_widget":"Social toolbar",
    "desc_enable_newsletter_widget":"Newsletter",


    "help_enable_country_map":"Afficher en premiére page la carte des annonces. Mettre sur OFF pour arriver directement à la liste des annonces.",
    "help_max_pages_to_show":"Nombre maximum de pages à afficher",
    "help_max_items_per_page":"Nombre d'articles par page.",
    "help_header_show_nb_ads" : "Afficiche dans le barre du haut le nombre de d'annonces.",

    "help_widgets":"Widgets = Modules affichés",
    "help_max_items_per_mod":"Nombre d'articles maximum affichés par widget.",
    "help_nb_items_per_vmod":"Nombre d'articles visibles par widgets.",
    "help_enable_mostviewed_mod":"Module 'les plus vues'",
    "help_enable_top_mod":"Module 'a la une'",
    "help_enable_topgallery_mod":"Module Galerie tournante en haut de page des articles 'A la une' ",
    "help_enable_browsebyloc_mod":"Module 'localisation'",
    "help_browsebyloc_fields_order":"Ordre de navigation dans les champs de localisation . Mots acceptés : locregion;locdept;loccity. Séparation par | .",
    "help_categories":"Catégories",
    "help_max_cat_per_column":"Sous-menu de navigation :  Nombre max de catégories a afficher avant de changer de colonne d'affichage.",
    "help_show_empty_cat":"Sous-menu de navigation : Afficher les catégories sans annonces",
    "help_hide_empty_cat_users":"Sous-menu de navigation : Masquer les catégories sans annonceurs.",
    "help_hide_empty_buy_ad":"Sous-menu de navigation : Masquer les catégories sans annonces de type 'demandes'.",
    "help_display_more_cat_link":"Afficher le bouton 'plus' lorsque le nombre de sous-catégories dépasse 3.",
    "help_max_skills_nb":"Nombre maximum de conpétances qu'un annonceur peut choisir dans son profile",
    "help_zetvu":"Zetevu/NEWS",
    "help_disable_zetvu":"Désactiver la fonction zetevu/news.",
    "help_zetvu_as_news":"Mode News activé pour la fonction zetevu/news. Attention, le mode ZETEVu ci-dessus doit être activé",
    "help_zetvu_create_by_admin_only":"Création des ZETEVU/NEWS autorisée par administrateur uniquement. Sinon, tout le monde peut en créer un",

    "help_enable_latest_mod":"Module derniéres annononces ajoutées- Module sur la barre latérale",
    "help_enable_urgent_mod":"Module derniéres annonces urgentes - Module sur la barre latérale",
    "help_enable_social_widget":"Social toolbar qui s'affiche en statique sur le coin de la page",
    "help_enable_newsletter_widget":"Newsletter - champ de saisie disponible en bas de page pour s'enregistrer à la newsletter",


    "desc_ad_preview_before":"Mode pre-vue (annonces)",
    "desc_user_preview_before":"Mode pre-vue (usagers)",
    "desc_draft_purge_duration":"Purge Bouillons aprés ",
    "desc_publishing_duration":"Publication Ann. pendant",
    "desc_user_auto_approval":"Auto-approbation (usagers)",
    "desc_ad_auto_approval":"Auto-approbation (annonces)",
    "desc_desc_new_sincelastvisit_en" : "New (depuis edrniére visite)",
    "desc_dayskeepasnew":"Nb jours en 'new'",
    "desc_archive_duration":"Archive de tout pendant",
    "desc_notificationbefore_duration":"Notification expiration avant",
    "desc_user_maxinactive_duration":"Expirer Usagers inactifs aprés",
    "desc_ad_paid_nomods_aftercreation" : "NO-Mods options payantes", 


    "help_ad_preview_before":"Affichage de l'annnonce telle qu'elle apparaitra sur le site avant soumission ou publication",
    "help_user_preview_before":"Affichage de l'annonceur  telle qu'il apparaitra sur le site avant soumission ou publication",
    "help_draft_purge_duration":"Delai de retention des annonces brouillons",
    "help_publishing_duration":"Durée de publication des annonces",
    "help_user_auto_approval":"Auto-approbation des annonceurs",
    "help_ad_auto_approval":"Auto-approbation des annonces",
    "help_dayskeepasnew":"Nb jours ou afficher une annonce en 'new'",
    "help_desc_new_sincelastvisit_en" : "Afficheun indicateur NEW sur les annonces nouvelles depuis la derniére visite",
    "help_archive_duration":"Archive des annonces expirées pendant xx jours",
    "help_notificationbefore_duration":"Nombre de jours avant la fin de l'annonce ou une notification par email va être envoyée à l'annonceur",
    "help_user_maxinactive_duration":"Expiration automatique des comptes annonceurs aprés un délai de xx jours d'inactivité. Les comptes sont mis en archive.",
    "help_ad_paid_nomods_aftercreation" : "Desactive la capacité pour les annonceurs de changer les options payantes aprés publication", 

    "desc_email_fromadmin":"DE (email)",
    "desc_email_admin":"Admin email (TO)",
    "desc_email_admin_reports":"Rapports (TO)",
    "desc_email_support":"Support (TO)",
    "desc_email_sales":"Sales (TO)",
    "desc_emails_admin_essential_mode" : "Notification réduite", 

    "help_email_fromadmin":"Adresse email utilisée pour le champ FROM des emails envoyés. Format de type  : {prenom nom <adresse email>} ou {adresse email} autorisés",
    "help_email_admin":"Adresse email de l'administrateur pour recevoir les notifications. Format de type  : {prenom nom <adresse email>} ou {adresse email} autorisés",
    "help_email_admin_reports":"Adresse email(s) des personnes qui souhaitent recevoir les rapports journaliers d'activité.Format de type  : {prenom nom <adresse email>} ou {adresse email} autorisés",
    "help_email_support":"Adresse email de l'équipe support vers qui diriger les demandes. Format de type  : {prenom nom <adresse email>} ou {adresse email} autorisés",
    "help_email_sales":"Adresse email de l'équipe vente vers qui diriger les demandes. Format de type  : {prenom nom <adresse email>} ou {adresse email} autorisés",
    "help_emails_admin_essential_mode" : "Par défaut, chaque changement d'état d'une annonce ou d'un annonceur envoie une notification à l'administrateur. Activez cette option pour supprimer cette notification", 


    "desc_locale_default_currency":"Devise",
    "desc_locale_default_unit":"Unité mesure",
    "desc_locale_default_country_code":"Code pays",
    "desc_locale_default_sub_code":"Sous code pays",
    "desc_locale_default_lat":"Latitude",
    "desc_locale_default_lng":"Longitude",

    "help_locale_default_currency":"Devise d'affichage des prix (EUR, USD,, ) et paiement PAYPAL. Code ISO-4217. Mettre NO pour ne pas afficher la devise mais alors pas de PAYPAL !",
    "help_locale_default_unit":"Unité mesure : km (pour Kilomètres), m (pour miles)",
    "help_locale_default_country_code":"Code pays (ISO 3166-1) permettant d'afficher la bonne carte en première page et adapter les contrôles de code postaux, numéro de téléphones, ...",
    "help_locale_default_sub_code":"Sous code pays - ** reserved **",
    "help_locale_default_lat":"Latitude du point central permettant de positionner la cartes par défaut",
    "help_locale_default_lng":"Longitude du point central permettant de positionner la cartes par défaut",

    "desc_enable_badwords_filter":"Filtrage Mots Interdits",
    "desc_enable_ipblacklist_filter":"Filtrage IPs",
    "desc_enable_emailblaklist_filter":"Filtrage eMAILS",
    "desc_enable_contactthru_when_phone" : "Contract anonyme/phone", 

    "help_enable_badwords_filter":"Active le filtrage des mots interdits sur les annonces. La liste des mots se configure par langue.",
    "help_enable_ipblacklist_filter":"Active le filtrage des visiteurs sur l'adresse IP (IP BLACK LIST)",
    "help_enable_emailblaklist_filter":"Active le filtrage des connections sur adresse email",
    "help_enable_contactthru_when_phone" : "Contract anonyme/phone : permet, même quand l'annonceur indique une numero de telephone d'utiliser le formulaire de contract du site.", 


    "desc_google_analytics_account":"Google ANALYTICS",
    "desc_google_site_verification":"Google SITE CODE",
    "desc_extra_header_info" : "Code en + dans HEADER", 
    "desc_enable_debug_mode":"Mode Debug",
    "desc_auto_pics_resize" : "re-taille des images",

    "help_google_analytics_account":"Code Google Analytics pour le suivi de performance du site. Si vide, GoogleAnalytics n'est pas activé sur les pages.",
    "help_google_site_verification":"Code de vérification pour GOOGLE SITE VERIFIER",
    "help_enable_debug_mode":"Mode de debug - Administrateur uniquement - pour l'aide à la résolution de panne du site",
    "help_auto_pics_resize" : "correction automatique de la taille des images en 600x500px max.",
    "help_extra_header_info" : "Permet d'ajouter du code HTML en plus dans la section HEADE du site.", 


    "desc_sales_package": "Packaging", 
    "desc_max_tot_ads":"MAX annonces",
    "desc_max_tot_ads_per_users":"Max Annonces/user",
    "desc_max_pic_size":"Taille Image",
    "desc_max_pic_nb":"Max images/ad",
    "desc_auto_pics_resize":"Auto-resize",
    "desc_tbyb_end_date":"Fin Essai le",
    "desc_directory_mode":"Mode Annuaire",
    "desc_homepage_display_what":"Page principale",
    "desc_widgets_based_on_what":"Widget basé sur",
    "desc_security_logs":"Sécurité/logs", 
    "desc_backup_sqltable":"Backup", 
    "desc_enable_elem_logs":"Logs sur annonces",
    "desc_enable_user_logs":"Logs sur usagers",
    "desc_logs_duration":"Durée rétention",
    "desc_payment_logs_duration":"Durée PAYPAL logs",
    "desc_advanced_layout":"Mise en page avancée", 
    "desc_split_desc_ad_details":"Séparer texte ", 
    "desc_desc_ad_details_all_bottom":"Texte en bas", 

    "desc_files_manager":"Gestionnaire fichiers",
    "desc_enable_files_manager":"Activer",
    "desc_files_manager_dir":"repertoire destination",
    "desc_files_manager_max_size":"taille maxi",
    "desc_files_manager_max_nbr":"max fichiers",

    "desc_emails_manager" : "Gestion Emails",
    "desc_enable_emails_templates" : "Basé sur modèles ?",

    "desc_advanced_search":"Rech. avancée",
    "desc_adv_search_startup":"Rech. avancée",
    "desc_adv_search_autosuggest":"Auto-suggession",
    "desc_vfields":"Champs supplém.",
    "desc_enable_vfields":"Activer champs virtuels",
    "desc_vfields_search":"Rech. avec champs v.",

    "desc_access_profiles" : "Types de comptes", 
    "desc_user_profile_private_en" : "Type PRIVE", 
    "desc_user_profile_public_en" : "Type PUBLIC", 
    "desc_user_profile_pro_en" : "Auto. type PRO", 
    "desc_user_profile_par_en" : "Auto. type PARTICULIER",

    "desc_advanced theme" : "Theme (expert)", 
    "desc_theme_extra_js_url" : "URL extra JS", 
    "help_theme_extra_js_url" : "URL du fichier .JS qui devra être charger en plus du site pour ajouter du scripting personnel", 



    "desc_dpe_img_vfield_id" :"CE champ ID",
    "desc_ges_img_vfield_id" : "GES champ ID", 
    "help_dpe_img_vfield_id" :"Classe Enerie : identifiant du champ spécial contenant l'information. Permet d'afficher la carte dynamiquement. Laisser a vide pour ne pas afficher",
    "help_ges_img_vfield_id" : "Gaz a affet de serre : identifiant du champ spécial contenant l'information. Permet d'afficher la carte dynamiquement. Laisser a vide pour ne pas afficher", 


    "help_adv_search_startup":"Bloc de recherche avancée affiché par défaut au demarrage du site",
    "help_adv_search_autosuggest":"Auto-suggession activée",
    "help_enable_vfields":"Activer la gestion et usage de champs virtuals sur le site",
    "help_vfields_search":"Ajouter les champs virtuels comme critéres de recherche",

    "help_user_profile_private_en" : "Type PRIVE : permet de s'enregistrer avec unevisibilité privée (=publication uniquement d'annonces mais pas visible dans l'annuaire)", 
    "help_user_profile_public_en" : "Type PUBLIC : vompte visible dans l'annuaire mais simplifié", 
    "help_user_profile_pro_en" : "Type Professionnel : autoriser la creation de compte de type PROFESSIONNELS (plus de champs)", 
    "help_user_profile_par_en" : "Type PARticulier : autoriser la création de compte simple de type particulier.", 



 

    "help_sales_package": "Packaging", 
    "help_max_tot_ads":"Limiter au nombre total d'annonces indiqué.",
    "help_max_tot_ads_per_users":"Nombre d'annonces max par users",
    "help_max_pic_size":"Taille maximale des images téléchargées (en Octets).",
    "help_max_pic_nb":"Nombre max d'images par annonces",
    "help_auto_pics_resize":"Re-taille automatique des images téléchargées au format 672px max en largeur ou longueur en respectant les proportions.",
    "help_tbyb_end_date":"Date de fin de l'essai",
    "help_directory_mode":"Mode annuaire",
    "help_homepage_display_what":"Type d'affichage en page principale (user ou ad)",
    "help_widgets_based_on_what":"Widgets basés sur ... (ad ou user)",
    "help_security_logs":"Sécurité/logs", 
    "help_backup_sqltable":"Backup", 
    "help_enable_elem_logs":"Logs sur annonces",
    "help_enable_user_logs":"Logs sur usagers",
    "help_logs_duration":"Durée rétention des logs ",
    "help_payment_logs_duration":"Durée PAYPAL logs",
    "help_advanced_layout":"Mise en page avancée", 
    "help_split_help_ad_details":"Séparer le texte descriptif d'une annonce en 2 morceaux", 
    "help_help_ad_details_all_bottom":"Mettre tout le texte descriptif de l'annonce en dessous de la photo", 

    "help_enable_emails_templates" : "Gestion Emails sur la base de modéles HTML directment configurables via l'administration wbe. Si OFF, utilisation des modéles internes au site",

    "help_split_desc_ad_details":"Sépare texte de description des annnonces avec le debut sur le coté et la fin en dessous des photos", 
    "help_desc_ad_details_all_bottom":"Positionne 100% de la descritption d'une annonce en dessous des photos et plus sur le côté comme le mode par défaut.", 



    "desc_badwords":"Mots interdits",
    "desc_cust_badwords":"Mots interdits",
    "help_cust_badwords":"Liste des mots interdits. Attention : séparation par '|' uniquement. A la détection, l'annonce sera mise en quarantaine et nécessitera l'approbation de l'éditeur. Ne pas oublier d'activer l'option générale de filtrage des mots interdits.",
    "Bad words error notice text" : "Votre annnonce contient des mots interdits qui ne respectent pas les termes et conditions du site.",


    "desc_location_restricted_disp":"Cacher adresse (partiel)", 
    "help_location_restricted_disp":"Cette option permet de cacher aux visiteurs l'adresse exacte des annonces et annonceurs et aficher uniquement departement/ville", 


    "latest added" :"Derniers ajouts", 
    
    // file manager @Z5.1
    "manage_files" : "Gestion fichiers", 
    "help_manage_files" : "Gestion fichiers", 
    "filesmanager" : "Gestionnaire de fichiers",
    "upload file" : "Ajouter un fichier",
    "%s file":"%s fichier",
    "%s files":"%s fichiers",
    "%s Byte":"%s Byte",
    "%s Bytes":"%s Bytes",
    "No files in directory." : "Aucuns fichiers dans ce répertoire",

    // emails maagement //
    "manage_emails" :"Gestion emails",
    "help_manage_emails" :"Gestion emails",

    "emailsmanager" : "Gestionnaire des modéles de notifications email",
    "save" : "Sauvegarder", 
    "view it" : "prévisualiser",
    "send you a test email" : "Vous envoyer un email de test",

    "%s emails" : "%s modèles de notification" ,
    "%s email" : "%s modèle de notification" ,

    "help_admin_abuse_00.html":"Signaler un abus sur une annonce (Administrateur)", 
    "help_admin_ad_20.html":"Annonce à valider (Administrateur)",
    "help_admin_ad_15.html":"Annonce en attente de paiement (Administrateur)",  
    "help_admin_ad_40.html":"Annonce publiée (Administrateur)", 
    "help_admin_support_00.html":"Demande de support(Administrateur)", 
    "help_cron.html":"Tableau de bord journalier (Administrateur)", 

    "help_lost_password.html":"Changement de mot de passe (Propriétaire)", 
    "help_user_lost_00.html":"Changement de mot de passe (Propriétaire)", 

    "help_owner_ad_15.html":"Annonce ayant un paiment en attente (Annonceur)", 
    "help_owner_ad_20.html":"Annonce en attente de validation (Annonceur)", 
    "help_owner_ad_40.html":"Annonce publiée (Annonceur)", 
    "help_owner_ad_45.html":"Annonce qui va prochainement expirer (Annonceur)", 
    "help_owner_ad_80.html":"Annonce expirée (Annonceur)", 
    "help_owner_ad_90.html":"Annonce refusée par l'editeur (Annonceur)", 
    "help_owner_contactuser_00.html":"Demande de contact vers  Annonceur", 
    "help_owner_contact_00.html":"Demande de contact sur une annonce (Annonceur)", 
    
    "help_owner_support_00.html":"Demande de support (Visiteur)", 

    "help_owner_reminder_00.html":"Email de rappel d'une annonce (Visiteur) ", 
    "help_user_remind_00.html":"Email de rappel d'une annonce (Visiteur) ", 

    "help_admin_user_15.html":"Abonnement en attente de réglement (Administrateur)", 
    "help_admin_user_20.html":"Abonnement à valider (Administrateur)", 
    "help_admin_user_40.html":"Abonnement actif (Administrateur)", 
    "help_admin_user_45.html":"Abonnement va prochainement expirer (Administrateur)", 
    "help_admin_user_60.html":"Abonnement est bloqué (Administrateur)", 
    "help_admin_user_80.html":"Abonnement expiré (Administrateur)", 


    "help_owner_user_15.html":"Abonnement en attente de réglement (Annonceur)", 
    "help_owner_user_20.html":"Abonnement en cours de validation (Annonceur)",
    "help_owner_user_40.html":"Abonnement actif (Annonceur)", 
    "help_owner_user_45.html":"Abonnement va prochainement expirer (Annonceur)", 
    "help_owner_user_60.html":"Abonnement est bloqué (Annonceur)", 
    "help_owner_user_80.html":"Abonnement expiré (Annonceur)", 


    "help_user_contactuser_00.html":"Confirmation demande de contact (demandeur)", 
    "help_user_contact_00.html":"Demande de contact sur une annonce (Visiteur)", 
    "help_user_reminder_00.html":"Reppel d'une annonce interessante (Visiteur)", 
    "help_user_support_00.html":"Demande de support (Visiteur)", 

    "help_lost_password_link.html" : "Changement de mot de passe par lien",
    "help_user_lost-link_00.html": "Changement de mot de passe par lien (demandeur)",

    "help_notif.html" : "Email général de notification", 
    "help_user_abuse_00.html" : "Email de signalement d'un abus",
    "help_reactivate_account" : "Réactivation d'un compte", 
    "help_user_reactivateaccount_00.html" : "Réactivation d'un compte", 

    "help_admin_reports_cron_daily.html" : "Automate journalier (Administrateur)",
    "help_admin_reports_cron_hourly.html" : "Automate horaire (Administrateur)",
    "help_admin_reports_cron_weekly.html" : "Automate hebdomadaire (Administrateur)",

    "help_superadmin_notif_orange.html" : "Alarme Orange (Administrateur)",
    "help_superadmin_notif_red.html" : "Alarme Rouge (Administrateur)",  

    // fiels maagement //
    "manage_fields" :"Gestion des champs",
    "help_manage_fields" :"Gestion des champs",
    "fieldssmanager" : "Gestionnaire de champs personnalisés",

    "banner_pos_background_all":"Fond d'écran - arriére plan (taille infinite)", 
    "banner_pos_background_right_top":"Font d'écran - coin sup droit (taille 300x100)", 
    "banner_pos_sidebar_right_top":"Barre Latérale - droite - haut (taille 180x150) ", 
    "banner_pos_page_center_top":"Haut du listing (taille LEADERBOARD 728x90) ", 
    "banner_pos_mob_page_center_top":"Centre page - en haut du listing (Mobile) (taille 720x50)", 
    "banner_pos_ad_detail_sidebar":"Fiche d'une annonce (largeur max 260px - reco : 234x60)", 
    "banner_pos_user_detail_sidebar":"Fiche d'un annonceur (largeur max 340px - reco : 336x100)", 
    "banner_pos_news_main_center_top":"News centrale - en haut du listing", 
    "banner_pos_headerwidget_right_top":"Entête - en haut à droite (taille 480x80)", 
    "banner_pos_ad_list_center_top" : "Haut du listing - ANNONCES uniquement (taille 728x90) ", 
    "banner_pos_user_list_center_top" : "Haut du listing - VENDEURS uniquement (taille 728x90) ", 
    "-- all positions --" : "-- tous les emplacements --",
    "search for title" : "Rehercher dans le titre", 

    // zads 5.5
    // search 
    "Advanced search :" : "Recherche avancée : ", 
    "Search" : "Rechercher", 
    "No results" : "Aucun résultat trouvé", 
 
    // VFIELDS management 
    "%s vfields" : "%s champs spéciaux" ,
    "%s vfield" : "%s champ spécial" ,
    "add vfield" : "Ajouter un champ spécial" ,
    "int_label" : "Nom",
    "disp_label" : "Label",
    "preview" : "Affiché comme ...",
    "moddatestamp" : "Date",
    "domtype" : "Type",
    "scope" : "Scope",
    "forwhat" : "Cible", 
    "id" : "Ident.", 

    "fieldsmanager" : "Gestionnaire de champs spéciaux",
    "all vfields" : "tous les champs",
    "id" : "id",

    "vfield creation ongoing" : "Création du champ spécial en cours", 

    " vfield form header title" : "Création d'un champ spécial",
    " vfield form header introduction" : "Les champs spéciaux permettent d'ajouter de caractéristiques particuliéres à certaines annonces dans certaines catégories. Définissez le champ spécial ici et ajoutez le aux catégories via l'interface admin", 

    "modify vfield form header title" : "Modification d'un champ spécial",
    "modify vfield form header introduction" : " ", 


    "desc_int_label" : "Nom interne",
    "desc_disp_label" : "Nom affiché",
    "desc_scope" : "Type de champ",
    "desc_forwhat" : "Pour...",
    "desc_domtype" : "Type HTML",
    "desc_domsubtype" : "Sous-type",
    "desc_values" : "Valeurs",
    "desc_unit" : "Unité",
    "desc_stype" : "Type (recherche)", 
    "desc_linkedvfield" : "Champ lié (recherche)",
    " add_values" : "ajouter une valeur",
    "add this value" : "ajouter cette valeur",
    "vfield value placeholder" : "entrer le valeur désirée",
    "No fields defined yet" : "Aucun champ défini pour l'instant",

    "help_scope" : "Indique si ce champ sera utilisé pour des informations supplémentaires dans les annonces ou un champ de recherche",
    "help_forwhat" : "Précise si ce champ peut etre ajouté à des usagers, annonces ou tout",
    "help_int_label" : "Nom interne du champ utilisé pour l'administration",
    "help_disp_label" : "Nom affiché du champ qui sera visible par les visiteurs et annonceurs",
    "help_domtype" : "Type HTML du champ (entrée simple, liste de choix, ...",
    "help_values" : "Liste des différentes veleurs que peut prendre un champ. Ne sart a rien sur les champs input",
    "help_unit" : "Unité, optionelle pour indiquer l'unité du champ saisi",
    "help_domsubtype" : "!! uniquement pour les champs INPUTs : sous type permettant de filtrer les données",
    "help_linkedvfield" : "!! Uniquement pour les champs de recherche :  indique le champ lié à cette recherche",
    "help_stype" : "!! champ de recherche uniquement !! <br> permet de spécifier si le champ est de type MIN, MAX ou simplement generique",
    "help_values" : "Permet de lister les valeures pour les champs CHECKBOX ou RADIO ou SELECT",  
    "help_values (%s max)" : "Permet de lister les valeures pour les champs CHECKBOX ou RADIO ou SELECT (%s max). Attention, les 10 premiers caractéres doivent être différents entre chaque valeur.",  
    
    "BTN vfield DRAFT" : "Brouillon",
    "BTN vfield PUBLISHED" : "Publier",
    "BTN vfield UNPUBLISHED" : "Suspendre",
    "BTN vfield DELETED" : "Supprimer",
    "BTN vfield WILLEXPIRE" : "va expirer",

    "desc_catlvfields" : "Champs spéciaux", 
    "help_catlvfields" : "Les Champs spéciaux permettent de collecter plus d'informations lors de la création d'un annonce", 
    " add_catlvfields" : "ajouter un champ spécial",
     "add this field" : "ajouter ce champ",
     "ad vfields" : "Caractéristiques", 
     "Select something" : "--Choisissez--", 

     "set/un-set in your favorites" : "Ajouter/Supprimer de votre liste de favorites", 

     // newsletter 
     "manage_subscribers" : "Gestion des abonnés", 
     "help_manage_subscribers" : "Gestion des abonnés à la newsletter", 
     "all subscribers" : "tous les abonnés", 
     "-- all status --" : "Tous les états d'abonnement", 
     "-- all status ad --" : "-- états --", 
     "-- all status user --" : "-- états --", 
     "registration pending" : "Enregistrements en attente de validation", 
     "registered" : "Enregistrés et actifs", 
     "-- unlimited --" : "Tous les résultats", 

     "publish" : "Publier/valider", 
     "un publish" : "Retirer de la publication / suspendre", 
     "subscribers unpublish confirmation" : "Confirmation de l'arret de l'abonnement", 
     "subscribers publish confirmation" : "Confirmation de l'activation de l'abonnement", 
     "subscribers delete confirmation" : "Confirmation de l'effacement de l'abonnement",
     "No entries in subscribers" : "Aucun abonné pour l'instant", 
     "Export this table to xls" : "Exporter XLS", 
   
     "Subscribe" : "S'abonner",
     "Delete this" : "Effacer",
     "Un-Subsrcibe"  : "de-enregistrer",
     "Your email address": "Votre email",
     "Subscribe to the newsletter": "S'abonner",
     "Your subscription is already pending your approval on : %s": "Votre abonnement est déja en attente avec cette adresse email : %s",
     "You are already subscribed under %s": "Vous étes déjà abonné sous l'adresse email : %s",
     "un-subsribe to the newsletter": "Supprimer son abonnement",
     "delete this pending approval": "Annuler cette demande",
     "Newsletter": "Newsletter",
     "Your subscription is correctly registered, check your inbox email for validation.": "Votre abonnement sera définitivement valide une fois votre confirmation. Véfrifiez votre boîte email.",
     "Newsletter registration pending": "Enregistrement en attente de validation",
     "A registration already exist for this email address : %s.": "Vous étes déjà abonné sous cette adresse email : %s",

     "un-subsribe to the newsletter": "Supprimer son abonnement",
     "Your subscripton is cancelled" : "Votre abonnement est annulé",
     "Your are un-subscribed to our newsletter"  :  "Vous n'ètes plus abonné à notre newsletter.",
     "You are correctly unsubscribed." : "Vous n'ètes plus abonné à notre newsletter.", 
     "This email or hash is not known by us yet  : %s." : "Cet adresse email ou ce code d'activation n'est pas reconnu.", 
     "Your subscription is validated" : "Votre abonnement est actif.", 
     "Thank you for your registration to our newsletter" : "Merci de votre abonnement à notre newsletter.", 
     "Your are registered to our newsletter":  "Votre abonnement est actif.", 

     "details dpe" : "CLASSE ENERGIE",


     // gestion fichiers 
     "tn" : "Vignette", 
     "name" : "Nom", 
     "size" : "Taille", 
     "modified" : "Modifié le",
     "actions" : "Actions", 

     // nouveaux liens 
     "General Rules of Diffusion" : "Régles Générales de Diffusion de Annonces (RGDA)", 
     "Régles de Diffusion" : "Régles de Diffusion",
     " and the " : " et les ", 
     "Qui nous sommes ?" : "Qui nous sommes ?", 
     "Tarifs" :"Tarifs", 

     "user details vfields" : "Autres informations", 
     "desc_extra_user_fields" : "Autres informations",

     "subscribed options" : "Vos options", 
     "Test Mail sent successfully" : "L'email a bien été envoyé à votre adresse", 


     // post correction ZADS  5.5.1 - BUGs discovered //
     "definitively delete" : "Effacer définitivement", 


     // zads 5.5.2
     "mydashboard" : "Mon tableau de bord",
     "my dashboard" : "Mon tableau de bord",

    "desc_new_sincelastvisit_en" : "New depuis derniére visite",
    "help_new_sincelastvisit_en" : "Active l'option d'affichage du bandeau NEW sur les annonces nouvelles depuis la derniére visite",

    "desc_social_widget_list" : "Elements barre social (site)", 
    "desc_sidebar_widgets_order_list":"Liste order des widgets", 
    "desc_siret_control_url":"Siret control (url)", 
    "desc_urgent_ads_en":"Annonces urgentes", 

    "help_social_widget_list" : "Liste par ordre d'affichage des réseaux sociaux à afficher dans la barre latérale et le bas de page du site. Codes : FB=FACEBOOK, GO=GOOGLE, YO=YOUTUBE, LK=LINKEDIN, TW=TWITTER,  CT=CONTACT, PT=IMPRIMER", 
    "help_sidebar_widgets_order_list":"Liste par ordre d'affichage des widgets en barre latérale", 
    "help_siret_control_url":"URL du site qui controle le champ SIRET. ajouter [NUMBER] le remplacer dynamiquement par le siret du client exemple :http://www.societe.com/cgi-bin/recherche?rncs=[NUMBER]. Si renseigné, le champ SIRET devient obligatoire à la saisie", 
    "help_urgent_ads_en":"Active l'option 'annonces urgentes' lors de la saisie des annonces et la recherche", 

    "help_siret_format_FR" : "Le numéro SIRET (Système d'identification du répertoire des établissements) est un numéro d'identification unique attribué à chaque établissement selon une codification INSEE. C'est une suite numérique de 14 chiffres : les neufs premiers représentent le numéro SIREN de l'entreprise à la quelle l'établissement est rattaché, les cinq derniers chiffres sont un numéro interne de classement (NIC) qui permet d'identifier l'établissement.",
    "check prosiret" : "vérifier", 

    /* zads 5.5.3 */ 
    "urgent"  :"Urgent", 
    "ad urgent" :"Urgent",
    "Search in ads" :" Annonces", 
    "urgents" : "urgentes", 
    "only" : "uniquement",
    "desc_urgent_ads_en" : "Annonces urgentes", 
    "help_urgent_ads_en" : "Active l'option annonces urgentes pour l'administrateur et comme critére de recherche.", 
    "desc_ads fields" : "Options annonces",
    "desc_user fields" : "Options users", 
    "desc_others" : "Autres",

    "ad createdate" : "Crée", 
    "ad firstpublisheddate" :"Publiée", 

    "desc_otherpaidoptions" : "General", 
    "post otherpaidoptions" :" ",
    "addpics" : "Photos", 
    "paidvideo" : "Video code",

    "desc_putontopgallery" : "Mise à la une",
    "help_putontopgallery" : "Mise à la une",
    "putontopgallery" : "Mise à la une",  
    "post putontopgallery" : "Mettre mon annonce à la une et béneficier de optimisez ma visibilité",
    "desc_putontopgallery7days" : "Mise à la une", 
    "desc_putontopgallery15days" : "Mise à la une", 
    "desc_putontopgallery30days" : "Mise à la une", 
    "post putontopgallery7days" : "Mise 'A la Une' chaque jour pendant 7 jours", 
    "post putontopgallery15days" : "Mise 'A la Une' chaque jour pendant 15 jours", 
    "post putontopgallery30days" : "Mise 'A la Une' chaque jour pendant 30 jours", 



    "desc_pushtotop" : "Tête de liste", 
    "help_pushtotop" : "Tête de liste", 
    "pushtotop" : "Tête de liste", 
    "post pushtotop" :"Remonter mon annonce en tête de liste et multiplier mes contacts",
    "desc_pushtotoponceaweek"  : "Tête de liste une fois/sem.",
    "desc_pushtotop7days" : "Tête de liste", 
    "desc_pushtotop15days" : "Tête de liste", 
    "desc_pushtotop30days" : "Tête de liste", 
    "post pushtotoponceaweek" : "Mettre en 'tête de liste' une fois par semaine", 
    "post desc_pushtotop7days" : "Mettre en 'tête de liste' chaque jour pendant 7 jours", 
    "post desc_pushtotop15days" : "Mettre en 'tête de liste' chaque jour pendant 15 jours", 
    "post desc_pushtotop30days" : "Mettre en 'tête de liste' chaque jour pendant 30 jours", 


    
    "post pushtotop7days" :  "Mettre mon annonce en avant chaque jour pendant 7 jours", 
    "post pushtotop15days" :  "Mettre mon annonce en avant chaque jour pendant 15 jours", 
    "post pushtotop30days" :  "Mettre mon annonce en avant chaque jour pendant 30 jours", 

    

    "desc_urgentad" : "Urgent", 
    "help_urgentad" : "Urgent", 
    "urgentad" : "urgent", 
    "post urgentad":"Ajouter un Logo Urgent et vendre plus vite ",
    "desc_urgentad15days" : "Urgent", 
    "desc_urgentad7days" : "Urgent",
    "desc_urgentad30days" : "Urgent",
    "post urgentad7days" : "Mise en 'urgent' chaque jour pendant 7 jours",
    "post urgentad15days" : "Mise en 'urgent' chaque jour pendant 15 jours",
    "post urgentad30days" : "Mise en 'urgent' chaque jour pendant 30 jours",


    "desc_specialcolor" : "Encadrée",
    "help_specialcolor" : "Encadrée",
    "specialcolor " : "encadré",
    "post specialcolor" : "Encadré pour plus de visibilité lors des recherches",
    "desc_specialcoloronceaweek" : "Encadré", 
    "desc_specialcolor7days" : "Encadré",
    "desc_specialcolor15days" : "Encadré",
    "desc_specialcolor30days":"Encadré",
    "post specialcoloronceaweek":"Encadré de couleur une fois par semaine",
    "post specialcolor7days":"Encadré de couleur chaque jour pendant 7 jours",
    "post specialcolor15days":"Encadré de couleur chaque jour pendant 15 jours ",
    "post specialcolor30days":"Encadré de couleur chaque jour pendant 30 jours ",

    "help_specialcoloronceaweek":"Encadré de couleur une fois par semaine",
    "help_specialcolor7days":"Encadré de couleur chaque jour pendant 7 jours",


    "banner_pos_userpro_register_sidebar":"Banniére Latérale lors de enregistrement des pros",


    // traductions pour gestion des abonnements
    "service status PUBLISHED": "Active", 
    "service status DELETED": "Vide", 
    "service status UNPUBLISHED": "inactive",
    "service status WILLEXPIRE": "va expirer",  

    // nouvelles dates de gestion ajoutées 
    "ad life-cycle dates" : "Dates clefs",
    "desc_moddate" : "Modification le",
    "desc_createdate" : "Crée le",
    "desc_firstpublisheddate" : "1ére publication le",
    "desc_crondate" : "Dernier CRON le", 
    "desc_urgent" : "Urgente", 
    

    // text for pre-image label 
    "ad upload photo post label" : "Une annonce avec photo est 7 fois plus consultée qu'une annonce sans photo.",


    "list_locations" : "Localisation", 
    "Categories" : "Catégories", 

    "desc_location_retricted_disp" : "Cacher localis. exacte", 
    "help_location_retricted_disp" : "Si cette option est affichée, la localisation exacte saisie au niveau de l'annonce et dans la boutique sera cachée et remplacée par Ville/departement sans afficher les détails", 

    "Location displayed is restricted" : "Confidentialité : uniquement la Ville/Département seront affichés sur le site", 
    
    "desc_login_form_inpage" : "Login à plat",
    "help_login_form_inpage" : "Login à plat : l'écran de login est affiché en direct sur la page et plus via une pop-up",

    "settings_menu_paypal" : "Paypal/Paiement",


    "desc_paypal_section" : "Paypal", 
    "desc_paypal_sandbox" : "Mode bac-a-sable", 
    "desc_paypal_user" : "PAYPAL compte",
    "desc_paypal_password" : "PAYPAL mot de passe",
    "desc_paypal_signature" : "PAYPAL signature",

    "help_paypal_sandbox" : "Mode bac-a-sable : permet de tester / suspendre le paiement en redirigeant sur un site paypal de test", 
    "help_paypal_user" : "PAYPAL nom de l'utilisateur ",
    "help_paypal_password" : "PAYPAL mot de passe du compte",
    "help_paypal_signature" : "PAYPAL signature du compte",

    // my services section 
    "My Subscribed services" : "Mes services", 
    "My current services":"Mes services courants",
    "Your trial will expire in %s days": "Votre pack d'essai va expirer dans %s jours",
    "Your trial is expired as of %s days , please consider buying a pack below": "Votre pack d'essai est expiré depuis %s jours, merci de choisir un pack pour publier des annonces",  
    "Till :":"Jusqu'au :", 
    "Expired :" : "Expiré ", 
    "You have used %s of your %s ads included onto the pack": "Vous avez utilisé %s des vos %s annonces incluses dans le pack",

    "Add new services" : "Ajouter des services", 
    "Services package selection" : "Choisir le type de pack", 
    "Select this service":"Choisir ce pack", 
    "Main introduction text to add services":"Lorel ipsum main introduction text to ADD SERVICE section", 
    "Services plan selection":"Choisir le plan", 
    "Your pack :" :"Votre pack :", 
    "Modify this":"modifier", 
    "Select plan :" : "Votre plan : ",
    "Your plan :" :"Votre plan :", 
    "Select this plan":"Choisir ce plan",
    "Press the buy button to finalize your transaction": "Cliquez sur le bouton ACHETER pour finaliser la transaction", 
    "Buy this pack":"Acheter", 
    "Service order confirmation":"Confirmation de votre choix", 
    "No services activated" : "Aucun service activé",

    "myservices" : "Mes Services", 
    "help_myservices" : "La liste de mes abonnements, packs ou services activés.", 

    "You have %s article(s) waiting for your paiement" : "Vous avez %s annonce(s) qui est en attente de votre réglement. ",
    "You have no active services any more, please consider buying new services" : "Vous n'avez plus de services de publication actifs, merci d'acheter de nouveaux services pour publier des annonces. ", 
    "You have %s service(s) waiting for your paiement" : "Vous avez %s service(s) qui est en attente de votre réglement. ", 

    // new modification after 10th of feb
    "Pay now" : "Payer maintenant",
    "buy services here" : "Acheter des services",
    "pro buy services here" : "PRO : Acheter des services", 
    "par buy services here" : "PARTICULIER : Acheter des services", 
    "pri buy services here" : "Acheter des services",     
    "Thanks you for your payment ! Your service is activated." : "Merci pour votre achat, votre pack de service est activé.", 
    "service status DRAFT PENDING PAYMENT" : "Paiement en attente",
    "service creation ongoing" : "Création du service en cours", 
    "myinvoices":"Mes factures", 
    "help_myinvoices": "afficher mes factures", 
    "See your invoice %s": "afficher mes factures %s", 
    "displayinvoiceaction" : "+", 
    "display invoice details" : "Afficher la facture", 

    "CURRENCY :" : "Devise : ",
    "Designation" : "désignation",
    "qty" : "quantité",
    "qty" : "quantité",
    "unit price" : "pix unitaire",
    "total price" : "pix total",
    "invalid TRANSACTION request" : "Demande invalide", 


    // update on invoice
    "INVOICE :" : "Facture n° : ", 
    "INVOICE PRINT BUTTON" : "IMPRIMER", 

    "INVOICE DATE :" : "Date : ", 
    "BUYER INVOICING TOP LABEL" : "Facturation",
    "BUYER FIRSTNAME :":"Nom : ",
    "BUYER LASTNAME :":"Prénom : ",
    "BUYER USERNAME :":"Nom utilisateur : ",
    "BUYER PROCPNY :":"Société : ",
    "BUYER ADDRESS :":"Adresse : ",
    "BUYER PHONE :":"Téléphone : ",
    "BUYER PROWEBSITE :":"Web : ",
    "BUYER EMAIL :":"E-mail : ",


    "INVOICE DATE :":"Date : ",
    "INVOICE WHAT ID :":"Référence : ",
    "INVOICE CURRENCY :":"Devise : ",
    "INVOICE PAYMENT METHOD :":"Méthode de paiement : ",
    "INVOICE TRANSACTION ID :":"N°  de transaction Paypal : ",
    "INVOICE TOTAL AMOUNT :":"Montant total : ",


    "INVOICE DESC":"Description",
    "INVOICE UP":"Prix unitaire",
    "INVOICE QTY":" Qté",
    "INVOICE TOT PRICE":"Total",

    "INVOICE DESC TRANSACTION :":"ID  de la transaction : ",
    "INVOICE total without tax":"Total HT : ",
    "INVOICE tax":"TVA : ",
    "INVOICE total with tax":"Total TTC : ",


    "-- services all status --":"-- tous les états --", 
    "services pending payments" : "en attente de paiement" ,
    "services active" : "actifs",
    "services expired" : "expirés",  
    "Sort by sid asc" : "Trier par Nom du pack", 

    // CONFIG PAGE  : for the menu 
    "allservices" : "Services", 
    "manage_services" : "Services", 
    "No entries in services" : "Aucun résultats pour cette recherche", 
    "services unpublish confirmation" : "Suspendre ce service ? ", 



    // CONFIG PAGE  :  the the service settings parameters 
    "settings_menu_services" : "Services", 
    "desc_services_version":"Version abonnement",
    "desc_services_force_default_at_start":"Forcer default",
    "desc_services_multi_en":"Multi services",
    "desc_services_notif_before_days":"Notif expiration",
    "desc_services_deleteall_after_days_expiration":"Effacer aprés",
    "desc_services_notify_en":"Changements notif",
    "desc_services_price_free_during_trial":"Options Gratuit/trial",


    "help_services_version":"Version abonnement : laisser V2 pour la version ZADS 6.0 qui accepteune gestion de services multiples sur un abonnement",
    "help_services_force_default_at_start":"Forcer default : Lors de l'inscription d'un usager, force a prendre un service du catalogue marqué 'defaut'",
    "help_services_multi_en":"Multi services : accepter le mode 'services multiple' au lieu de abonnement simple",
    "help_services_notif_before_days":"Notif expiration : nombre de jours avant l'expiration d'un service ou un email de rappel sera envoyé.",
    "help_services_deleteall_after_days_expiration":"Effacer aprés : nombre de jours aprés lequels, un service en archive sera effacé",
    "help_services_notify_en":"Changements notif : envoyer un email de notification sur chaque changement d'état d'un service",
    "help_services_price_free_during_trial":"Options Gratuit/trial : Si cette option est activée, les services 'sur annonces' sont gratuits pendant la phase de trial",
  

 
    "desc_invoice_section":"Paramétres de facture",
    "desc_invoice_companyname" : "Nom de la société",
    "desc_invoice_vat": "Numéro de SIRET/TVA",
    "desc_invoice_company_address": "Adresse compléte",
    "desc_invoice_footertext": "Texte bas de page",

    "help_invoice_companyname" : "Nom de la société telle qu'elle apparaitra en haut de la facture",
    "help_invoice_vat": "Numéro de SIRET/TVA tel qu'il apparaitra en haut de la facture",
    "help_invoice_company_address": "Adresse compléte de la compagnie a afficher sur la facture. Indiquer les sauts de ligne avec des <br> HTML",
    "help_invoice_footertext": "Texte bas de page",

    "desc_ad_nomods_afterexpiration" : "Pas réactiv. des expirées", 
    "help_ad_nomods_afterexpiration" : "Pas de reactivation des annonces aprés expiration ou suppression", 

    "desc_ad_video_size_width" : "Largeur Videos", 
    "help_ad_video_size_width" : "Largeur des videos affichées dans le détail des annonces. la hauteur est automatiquement calculée avec le ration 0.6", 

    
    "ad video2 embed" : "Video2 HTML code", 
    "ad video2 embed help" : "Entrer le code HTML de votre fournisseur de video. Par exemple, sous YOUTUBE, rendez vous dans le menu PARTAGER / INTEGRER pour extraire le code à coller dans ce champ.", 

    "desc_banclicks" : "Clicks sur banniére", 
    "help_banclicks" : "Nombre de clicks sur votre banniére.", 
    "banclicks" : "Clicks Ban.", 

    "paypal_status_Completed" : "Payé", 
    "paypal_status_Pending" : "En attente", 
    
    // abonnements paypal
    "paypal_status_ActiveProfile"  : "Abon. Actif", 
    "paypal_status_PendingProfile"  : "Abon. En attente",

    "servi" : "service", 
    "Main List" : "retour",
    "help link retour": "retour à la liste principale", 

    "help_admin_service_15.html" : "Service/abonnement en attente de paiement (administrateur)", 
    "help_admin_service_40.html" : "Service/abonnement activé (administrateur)",

    "help_owner_service_15.html" : "Service/abonnement en attente de paiement (propriétaire)", 
    "help_owner_service_40.html" : "Service/abonnement activé (propriétaire)",  
    "help_owner_service_45.html" : "Service/abonnement va bientôt expirer (propriétaire)",  
    "help_owner_service_80.html" : "Service/abonnement est expiré (propriétaire)",  

    "help_user_newsletter_unsubscribe_80.html" : "Abonnement newsletter terminé (visiteur)", 
    "help_user_newsletter_validation_20.html" : "Abonnement newsletter en attente de validation (visiteur)", 

    "ad_nbvideos" : "Videos par annonce",

    "username already in use" : "Ce Nom de login est déja utilisé ! ",
    "email already in use" : "Cette adresse email est déja enregistrée ! ",
    "Confirm this service" : "Je confirme mon abonnement", 
    "no options" : "aucune option",
    "par" : "Particulier", 
    "pro" : "Professionnel", 
    "Click <a id='print' href='#'>here</a> to print and clip along the line": " <a id='print' nottip='yes' href='#'>imprimez</a> votre facture.",

    "desc_enable_url_noself_filter" : "Filtrage url", 
    "help_enable_url_noself_filter" : "Active le filtrage des URLs dans une annonce. Si une URL est présente, l'annonce est marquée comme non conforme et mise en validation chez l'éditeur quelque soit le mode de publication. Un message est aussi indiqué dans l'email de changement d'état à l'auteur.", 

    "desc_services_pro_free_options_list": "Options gratuites pour pros.", 
    "help_services_pro_free_options_list": "Pour les annonces, liste les options qui seront forcées et mise gratuites pour les annonceurs professionnels (specifique). Utiliser les noms tels que définit dans le catalogue et séparez les par un signe '+' . ", 

    "desc_indir_pro_only" : "Annu. pour pros. uniquement",
    "help_indir_pro_only" : "Si ON, limite la visibilité annuaire aux professionells uniquement. Les particulier ne pourront pas choisir l'option. Les pros auront le choix de figurer ou non dans l'annuaire",


    // footer links
    "Who we are ?" : "Qui sommes nous ?",  
    "COPYRIGHT" : "Copyright ZADS 2014",
    "Legal information" : "Infos légales et GCU",
    "General rules of diffusion" : "Régles de diffusion",
    "Advertising" : "Publicité",
    "Contact us" : "Nous contacter",
    "Pricing" : "Tarifs",
    "The blog" : "Le blog",
    "F.A.Q" : "Questions fréquentes",  
    "Back to main site" :"Retour au site principal",
    "Help" : "Aide",

    "sdesc_" : " ",
    "sdesc_basepack" : " ",
    "sdesc_pack5" : "(plan 5)",
    "sdesc_pack10" : "(plan 10)",
    "sdesc_pack25" : "(plan 25)",
    "sdesc_pack50" : "(plan 50)",
    "sdesc_pack75" : "(plan 75)",
    "sdesc_pack100" : "(plan 100)",



    "short-desc_of_pack5" : "plan 5 annonces",
    "short-desc_of_pack10" : "plan 10 annonces",
    "short-desc_of_pack25" : "plan 25 annonces",
    "short-desc_of_pack50" : "plan 50 annonces",
    "short-desc_of_pack75" : "plan 75 annonces",
    "short-desc_of_pack100" : "plan 100 annonces",

    "desc_extra links on nav page" : "Liens dans barre de navigation",
    "desc_extra_main_nav_link1_title" : "Lien 1 - titre ",
    "desc_extra_main_nav_link1_url" : "Lien 1 - URL ",
    "desc_extra_main_nav_link2_title" : "Lien 2 - titre ",
    "desc_extra_main_nav_link2_url" : "Lien 2 - URL ",
    "desc_extra_main_nav_link3_title" : "Lien 3 - titre ",
    "desc_extra_main_nav_link3_url" : "Lien 3 - URL ",

    "help_extra_main_nav_link1_title" : "Lien 1 - titre du lien qui s'affichera sur la barre de natigation en plus des autres.",
    "help_extra_main_nav_link1_url" : "Lien 1 - URL ",
    "help_extra_main_nav_link2_title" : "Lien 2 - titre ",
    "help_extra_main_nav_link2_url" : "Lien 2 - URL ",
    "help_extra_main_nav_link3_title" : "Lien 3 - titre ",
    "help_extra_main_nav_link3_url" : "Lien 3 - URL ",


    "desc_max_cat_on_sidebar" : "Sidebar, max ligne", 
    "help_max_cat_on_sidebar" : "Sidebar, max ligne : nombre de ligne max avant d'afficher le bouton 'plus...' pour les modules CATEGORIES et LOCALISATION de la sidebar.", 

    "social link to %s" : "Lien vers la page ou formulaire  : %s", 


    "title share on facebook" : "Partager dans Facebook",
    "title share on twitter" : "Partager sur Twitter",
    "title share on Linkedin" : "Partager dans LinkedIn",
    "title share on Google+" : "Partager dans Google+",
    "title share on Pinterest" : "Partager dans Pinterest", 
    "title ad email it" : "M'envoyer cette annonce par email",

    "you selected the  plan  : " : "Vous avez choisi le plan : ",

"you selected the  plan  : " : "Pack : ",

    "Tooltip of Export this table to xls" : "Exporter cette table vers Microsoft Excel", 

    "settings_oi" : "Reférence Article (PUK) ", 
    "settings_desc" : "Description", 
    "settings_price" : "Prix",
    "settings_priceHT" : "Prix (HT)", 
    "settings_priceTTC" : "Prix (TTC)",
    "settings_isrecurrent" : "Récurrent",
    "settings_billingperiod" : "Période",
    "settings_billingfrequency" : "Fréquence facture",
    "settings_nb_addpics" : "Nombre d'images en plus",
    "pictures" : "images", 
    "Services prices are managed into the packs" : "Les prix des packs services sont gérés dans la section Abonnements",


    "header text settings payoptions":"Catalogue des Options payantes", 
    "header text paragraph payoptions" : "Paramétrez ci-dessous les options payantes qui seront disponiblespour les annonces . Attention, les prix doivent avoir un '.' comme séparateur de décimal", 


    "desc_max_cat_on_sidebar" : "Sidebar, max ligne", 
    "help_max_cat_on_sidebar" : "Sidebar, max ligne : nombre de ligne max avant d'afficher le bouton 'plus...' pour les modules CATEGORIES et LOCALISATION de la sidebar.", 

    
    "settings_menu_payoptions" : " Catalogue", 
    "This is the LABEL element used to group below options" : "ce champ controle le libéllé", 

    // packas d'abonnements et services
    "settings_menu_pricing_plan" : "Abonnements", 
    "header text settings pricingplan":"Détails du contenu des abonnements et packs", 
    "header text paragraph pricingplan" : "Paramétrez ci-dessous les abonnements et services sui seront disponibles pour les annonceurs.", 

    "desc_page_map_type" : "Page home Externe (TEMPLATE)", 
    "desc_page_home_type_url" : "Page externe(url)", 
    "help_page_home_type_url" : "Si activé, la page d'accueil est externe et a charcher à l'url indiquée plus bas. Sinon, on utilise les champs textes", 
    "desc_page_home_url" : "Url de la page externe",
    "help_page_home_url" : "Url de la page externe contenant le contenu HTML a charger sur la page d'accueil",
    "desc_page_map_content" : "Contenu page statique", 

    "users delete confirmation" : "Confirmation suppression usager", 
    "ads delete confirmation" : "Confirmation suppression annonce", 

    // totnbads 
    // translations of the admin section zads 6.1
    "totnbads":"Qty", 
    "a_moddate" : "Date",
    "a_type" : "Type", 
    "a_id" : 'ID',
    "a_email" :"E-mail",
    "a_priceid" : "Plan", 
    "a_sid" : "Service", 
    "a_remain" : "Reste",
    "a_startdate" : "Date début",
    "a_enddate" : "Date fin",
    "a_status" : "Etat", 
    "a_userid" : "ID usager",
    "a_username" : "Nom", 
    "a_price" : "Prix" ,
    "a_pricevat" : "Taxe",
    "a_recurrent" : "Récurrent", 
    "a_firstname":"Nom",
    "a_lastname" :"Prenom",
    "a_procpny":"Société",
    "a_protype": "Type", 
    "a_totnbads": "Ann#", 
    "a_title":"Titre",
    "a_catid":"CatID", 
    "a_hits":"Vues",
    "a_severity":"Sev.",
    "a_date":"Date",
    "a_whatid" : "ID",
    "a_what":"Quoi?", 
    "a_action":"Action",
    "a_cattitle":"Titre",
    "a_adtitle":"Titre",
    "a_desc" : "Description",
    "a_state" : "Etat",
    "a_position":"Emplacement", 
    "a_clicks":"Clicks #", 
    "a_CTR":"CTR", 
    "a_impressions" : "Imp.",
    "a_registerdate" : "Enregistré",
    "a_paymentdate" :"Date", 
    "a_transactionid":"ID transac.", 
    "a_paymentstatus":"Etat paiement", 
    "a_amt":"Montant", 
    "a_displayinvoiceaction" : "Détails" ,
    "a_auth" : "Autent.", 
    "a_lastvisitdate" : "Dern. visite", 
    "a_gender" : "Genre", 
    "a_locale" : "Langue",
    "a_priority" : "Priorité",
    "a_prosiret" : "Siret",
    "a_prowebsite" : "SiteWeb",
    "a_loccity" : "Ville",
    "a_locdept" : "Dept.",
    "a_locregion" : "Region.",
    "a_loczipcode" : "Code Postal",
    "a_loclatlng" : "GPS coord.",
    "a_plan" : "Plan",
    "a_links" : "Liens",
    "a_indir" : "Annuaire?",
    "a_phone" : "Telephone",
    "a_phone2" : "Telephone2",
    "a_email2" : "E-mail 2",
    "a_expiredate" : "Expire le",
    "a_banclicks" : "Click ban.",
    "a_newsletter" : "Newletter",
    'a_ip' : 'IP@',
    'a_order' : 'Or.', 

    "a_val" : "Val",
    "a_%val" : "%",
    "a_adsnb" :"#", 
    "a_%adsnb" :"%", 
    "a_metrics" :"#",
    "a_%metrics" : "%", 
    "a_nbusers" : "#",
    "a_%nbusers" : "%",






    "select_fields" : "Choisir Champs", 
    "fields selection save & refresh" : "Sauvegarder& rafraichir", 
    "fields selection reset" : "Revenir au defaut", 


    // adult category disclamers 
    "ADULT-CATEGORY-DISCLAMER":
    "<strong>Dans cette cat</strong>é<strong>gorie, vous devez avoir plus de 18 ans et accepter les points suivants:</strong><br><br><span class='normal'><strong>1.</strong> J'ai au moins 18 ans. <br>         <br>         <strong>2.</strong> Je comprends la teneur potentiellement choquante des annonces          placées pour Adultes.<br>         <br>         <strong>3.</strong> Le contenu choquant ne m'offense pas.<br>         <br>         <strong>4.</strong> Je prends connaissance et accèpte la possibilité d'une modération de la part de l'équipe du site sur l'usage de certains mots pré-définis et laissés à l'entière discrétion des administrateurs.<br>         <br>         <strong>5.</strong> En cliquant sur le bouton <strong><span style='cursor: text; text-decoration: none'><font color='#cc0000'>'J'accepte'</font></span></strong> ci-dessous, je libère et décharge les fournisseurs d'accès, propriétaires et créateurs du site de toute responsabilité quant au contenu et à l'utilisation faite de cette section.<br> <br> N'hésitez pas à consulter nos </span><a href=''>conditions d'utilisation</a>",  

    "desc_adultflag"  : "Cat. Adulte", 
    "help_adultflag" : "Si coché, cette catégorie est reservée aux adultes et les annonces ne seront visibles qu'aprés acceptation des conditions.", 

    "title_ADULT-CATEGORY-DISCLAMER": "Avis de non-responsabilité", 
    "dialog disclamer accept" : "OUI J'Accepte", 
    "dialog disclamer refuse" : "NON, je refuse", 

    "desc_legal" : "Légal", 
    "desc_cookiename":"Prefixe Cookie",
    "desc_cookie_duration_adult_disclamer":"Durée Cookie Adulte",
    "desc_filter_adult_in_list":"Filter Cat. adultes",

    "help_cookiename":"Prefixe du Cookie qui sera utilisé pour sauvegarder sur le poste client des informations",
    "help_cookie_duration_adult_disclamer":"Durée Cookie Adulte : Durée en JOURS de persistance du cookie utilisé pour accepter les catégories adultes.",
    "help_filter_adult_in_list":"Filter Cat. adultes : quand le visiteur n'a pas accepté les conditions d'accés aux catégories ADULTES, les annonces ADULTES sont sont pas visibles.",


    // liens sur annonce et annonceurs
    "ad links" : "Liens (url)", 
    "links" : "Liens (url)",
    "desc_links_on_ad": "Liens annonce",
    "desc_links_on_user": "Liens usager",
    "help_links_on_ad": "Liens annonce : autoriser la saisie de liens webs vers d'autres sites. Indiquez le nombre max. Mettre 0 (zero) pour interdire",
    "help_links_on_user": "Liens usager : autoriser la saisie de liens webs vers d'autres sites. Indiquez le nombre max. Mettre 0 (zero) pour interdire",

    "List of links" : "Liens", 
    "desc_newsletter" : "Lettre", 
    "help_newsletter" : "Lettre d'information du site", 
    "I subscribe" : "Je m'abonne", 
    "desc_user_enable_newsletter" : "Abonnement newsletter" ,
    "help_user_enable_newsletter" : "Abonnement newsletter : proposer l'abonnement à la newsletter lors de l'enregistrement" ,

    "desc_pictures" : "Gestion Images",
    "desc_img_zoom_en" : "Zoom sur Images", 
    "help_img_zoom_en" : "Zoom sur Images : permet d'activer un zoom sur les images affichées lorsque la souris passe au-dessus. La fonction de Auto-swipe doit etre DESACTIVEE.", 


    "desc_paid_options" : "Options payantes", 
    "desc_paid_options_price_free" : "Forcer TOUT gratuit", 
    "help_paid_options_price_free" : "Force toutes les options en GRATUIT tant que ce paramétre est activé", 

    "desc_other_payments" : "Moyens de paiements (BETA)",
    "desc_payment_method" : "Methode", 
    "help_payment_method" : "Ne pas utiliser pour l'instant !", 
    "desc_payment_manual_mode" : "Mode Manuel", 
    "help_payment_manual_mode" : "Mode manuel de paiement = lors de l'achat d'une option ou un abonnement, l'administrateur doit valier la publication s'être assuré manuellement que le paiement a été effectué par tout moyent (cash, chéque, ...) ",


    "desc_general field for ad" : "Champs Annonces", 
    "desc_ad vtags"  : "Etiquettes PERSO", 
    "desc_price_field_disable" : "Desactiver champ PRIX", 
    "desc_price_field_expression" : "Expression PRIX",
    "desc_vfields_display_hide_zerovalue" : "Cacher valeur NULL", 
    "help_price_field_disable" : "Desactiver le champ prix générique et utiliser l'expression ci-dessous.", 
    "help_price_field_expression" : "Expression PRIX : permet de remplacr le champ prix affiché ar une expression basée sur les champs virtuels. exemple : [VFIELD=18][ - ][VFIELD=19][ ][CURRENCY]",
    "help_vfields_display_hide_zerovalue" : "Cacher lors de l'affichage les champs viruels qui ont une valeur nulle ou zero.", 

    "desc_main_content_width_short_en" : "*FU ** Largeur reduite",
    "help_main_content_width_short_en" : "Spécifie un affichage de liste en utilisant une largeur réduite de la zone principale. ",

    "help_vtags_labels" : "Etiquettes apposées sur les annonces", 

    " Room." : " Pce.", 
    " Peop." :" Per.",
    " m2": " m2",


    // messages lors du login
    "account expired" : "Ce compte est expiré",
    "reactivate account" : "ré-activer ce compte",
    "account reactivated" : "Votre compte est reactivé. Les nouveaux codes d'accés vous ont été transmis par e-mail.",
    "log_reactivate_PUBLISHED" : "Réactivé", 
    "desc_account_reactivate_en" : "Réactivation Comptes expirés",
    "help_account_reactivate_en" : "Réactivation Comptes expirés  : l'usager lors de la connection est notifié et peut demander une réactivation de son compte. Il recoit en retour un email avec un nouveau mot de passe et son compte est de nouveau actif.",  

    // mise a jour traductions sur logs
    "log_auth_account reactivated" : "Demande de réactivation de compte", 
    "log_auth_account expired" : "Accés avec un compte expiré", 
    "access denied - bad password" : "Accés refusé - erreur de mot de passe", 

    // new ADMIN options 
    "desc_invoice_number_format" : "Format N° facture", 
    "help_invoice_number_format" : "Format N° facture : indiquez ici le format du numero automatique de facture. Les champs spéciaux autorisés sont [TIMESTAMP], [WHAT] et [ID] ",
    "desc_vtag1_en" : "Tags Virtuel 1", 
    "desc_vtag2_en" : "Tags Virtuel 2", 
    "desc_vtag3_en" : "Tags Virtuel 3", 
    "desc_vtag4_en" : "Tags Virtuel 4",
    "desc_vtag5_en" : "Tags Virtuel 5",

    "help_vtag1_en" : "Tags Virtuel 1 : permet de definir des champs en plus sur les annonces. Vous pouvez définir le nom via votre fichier personnel de traductions", 
    "help_vtag2_en" : "Tags Virtuel 2 : permet de definir des champs en plus sur les annonces. Vous pouvez définir le nom via votre fichier personnel de traductions", 
    "help_vtag3_en" : "Tags Virtuel 3 : permet de definir des champs en plus sur les annonces. Vous pouvez définir le nom via votre fichier personnel de traductions", 
    "help_vtag4_en" : "Tags Virtuel 4 : permet de definir des champs en plus sur les annonces. Vous pouvez définir le nom via votre fichier personnel de traductions",
    "help_vtag5_en" : "Tags Virtuel 5 : permet de definir des champs en plus sur les annonces. Vous pouvez définir le nom via votre fichier personnel de traductions",

    "desc_activate_text_scroll" : "Scroll texte",
    "help_activate_text_scroll" : "Scroll texte : en affichage en mode GALLERIE, permet de faire défiler le texte en overlay fonction des mouvements de la souris",
   
    "desc_dynamic_update_widgets" : "Mise à jour auto", 
    "help_dynamic_update_widgets" : "Mise à jour auto des widgets activées lors d'un changement de catégorie, région, pays, .. ", 

    "recurrent paiement" : "Paiements récurrents",
    "one-shot transaction" : "Transaction unitaire",  
    "frecurrent" : "Récurrent", 


    // elements pour facture des abonnements récurrents
    "RECURRING PAIEMENT ID :" : "N° d'identifiant du profil :",
    "PROFILEID PRINT BUTTON" : "IMPRIMER", 
    "PROFILE ID :" : "N° ID du profi : ", 
    "PROFILE STATUS :": "Etat : ", 
    "RECURRING PROFILESTARTDATE :": "Début : ", 
    "RECURRING BILLINGPERIOD :": "Période de facturation : ", 
    "RECURRING BILLINGFREQUENCY :": "Fréquence : ", 
    "RECURRING TOTAL AMOUNT :": "Montant : ", 
    "RECURRENT DESC :" : "Description : ", 
    "RECURRENT NEXTBILLINGDATE :" : "Prochaine Facture le : ",
    "BUYER RECURRENT TOP LABEL" : "Confirmation d'abonnement", 
    "RECURRENT WHAT ID :":"Référence : ",

    // catalogue des options payantes et plans d'abonnements
    "desc_payoptions_enable" : "Activation globale", 
    "post paidplan_plan_1" : "Plan d'abonnement #1", 
    "post paidplan_plan_2" : "Plan d'abonnement #2", 
    "post paidplan_plan_3" : "Plan d'abonnement #3", 
    "post paidplan_plan_0" : "Plan d'abonnement #0", 

    "post plan_1" : "Plan d'abonnement #1", 
    "post plan_2" : "Plan d'abonnement #2", 
    "post plan_3" : "Plan d'abonnement #3", 
    "post plan_0" : "Plan d'abonnement #0", 

    "Get details directly from PAYPAL" : "Intérroger PAYPAL pour les détails en direct",

    "No entries in payments" : "Aucune transaction de ce type",


    // new options for debug
    "desc_debug" : "Options de DEBUG/LOG", 
    "desc_debug_level" :  "Profondeur des logs",
    "desc_enable_trace_log" :  "Mesure temps execution",
    "desc_disable_translation" :  "Désactiver traductions",
    "desc_enable_debug_jstools" : "Outils JS de debug",
    "help_debug_level" :  "Quels types de messages ecrire dans le fichier SYSLOG ? : détermine quel types de messages doivent être écrits dans le fichier de debug/log - 7=ALL, 6=INFO, 5=NOTICE, 4=WARNINGS 3=ERRORS, 0=PANIC.",
    "help_enable_trace_log" :  "Mesaure et affiche pour chaque requéte AJAX les temps d'éxécution à travers le script",
    "help_disable_translation" :  "Désactiver les traductions permet de voir quel SPAN est utilisé en entrée du fichier de traduction.",
    "help_enable_debug_jstools" : "Outils Javascript de debug accessibles depuis le client",

    // ====== 6.1.2 ==============================================
    // welcome login text for users without ads
    "Welcome" :"Bienvenue", 
    "Welcome %s %s !" : "Bienvenue <strong>%s %s</strong> ! ", 
    "You don't have any ad yet. Do you want to create one ?" :"Vous n'avez pas encore d'annonces. Souhaitez vous en créer une toutde suite ? ",
    "Create my first ad" :"Créer ma premiére annonce", 

    // lifecycle refactoring 
    "desc_ad life-cycle" : "Spécial Annonces",
    "desc_user life-cycle" : "Spécial Usagers",
    "desc_user_maxarchive_duration" : "Archive pendant", 
    "help_user_maxarchive_duration" : "Durée d'archive des usagers expirés.", 

    //livecheck
    "username already exist" : "nom de compte pas disponible", 
    "email already exist" : "adresse e-mail déja enregistrée",

    //protection côté serveur des validations d'annonces sur un pack "vide"
    "no tokens left on your subscribed services !" : "Désolé, vous n'avez plus de crédits pour publier cette annonce.", 

    //--tutoriels videos
    // lien dans le menu
    "myvideos" : "Tutoriels",
    // nom du breadcrumb   
    "bread_zetvu_as_video" : "Tutoriels", 
    "all zetvu_as_video" : "Tous les tutoriels", 
    "all my_zetvu_as_video" : "Tous les tutoriels",
    "all admin_zetvu_as_video" : "Tous les tutoriels",
    "bread_zetvu_as_news" : "News", 
    "all zetvu_as_news" : "Toutes les News", 
    "all my_zetvu_as_news" : "Toutes les News",
    "all admin_zetvu_as_news" : "Toutes les News",
    "zetvu" : "Zetévu",
    "all zetvu" : "Tous les Zetévu",  

    // barre principale de navigation 
    "nav_zetvu_as_video" : "Tutoriels", 
    "nav_zetvu_as_news" : "News", 

    //create button 
    "create_zetvu_as_video" : "Créer un tutoriel", 
    "create_zetvu_as_news" : "Créer une news", 

    // entete de la zone de creation
    " zetvu_as_video form header title" : "Créer votre tutorial", 
    " zetvu_as_video form header introduction" : " ", 
    " zetvu_as_news form header title" : "Créer votre nouvelle", 
    " zetvu_as_news form header introduction" : " ", 
    "modify zetvu_as_video form header title" : "Modifier un tutorial", 
    "modify zetvu_as_video form header introduction" : " ", 
    "modify zetvu_as_news form header title" : "Modifier une nouvelle", 
    "modify zetvu_as_news form header introduction" : " ", 

    // configuration
    "desc_zetvu_as_video_tuto" : "Mode VIDEOS tutos", 
    "help_zetvu_as_video_tuto" : "Mode VIDEOS tutos : dans ce mode, un champ video est disponible pour ajouter de viedos youtube ou autre. Elles sont alors affichées en mode gallerie",
    "desc_zetvu_visible_acl" : "Visible pour...",
    "help_zetvu_visible_acl" : "Niveau de control d'accés de visibilité des zetevu. 0=visible par tout le monde, 1=les utilisateurs enregistrés",

    // hover sur carte
    "This location has %s ad" : "%s annonce", 
    "This location has %s ads" : "%s annonces", 

        // hover sur carte
    "This location has %s user" : "%s annonceurs", 
    "This location has %s users" : "%s annonceurs", 

    // email direct en utilisant le client natif du PC/MAC 
    "Direct Mail - title - I want to have more information" : "Je souhaiterais plus d'information sur votre annonce", 
    "Direct Mail - body header - I want to have more information on element : " : "Je souhaiterais plus d'information sur l'annonce : ", 
    "Direct Mail - body footer - I want to have more information on element." : "[entrer ici votre texte complémentaire] ", 
 
    // contact form 
    "contact_form_firstname" : "Prénom ", 
    "contact_form_lastname" : "Nom ", 
    "contact_form_phone" : "Téléphone ", 

    // new label forpassword change title 
    "desc_passwordchange" : "Mot de passe", 
    "modify my password" : "modifier", 

    // now notification status 
    "You have services that will expire soon please consider buying new services " : "Attention, votre pack découverte va bientôt expirer, ",

    // bouton create primiéres annonce dans services
    "Create first ad" : "Déposer une annonce", 

    //le à des dates 
    " by " :" à ",
    "help_disp_prosiret" : "Numero de SIRET",

    // filters 
    "-- all protype --" : "-- type --", 
    "Sort by priceid asc" : "Tier par nom du Plan (prix)",

    // traduction dédiée pour les "no results"
    "No items found - No ad - admin_all" : "Aucune annonce",
    "No items found - No ad - draft" : "Aucune annonce en brouillon",
    "No items found - No ad - published" : "Aucune annonce publiée",
    "No items found - No ad - pending" : "Aucune annonce en attente",
    "No items found - No ad - willexpire" : "Aucune annonce à expiration prochaine",
    "No items found - No ad - draft pending payment" : "Aucune annonce en attente de paiement", 
    "No items found - No ad - deleted_expired" : "Aucune annonce expirée",
    "No items found - No ad - deleted" : "Aucune annonce expirée",
    "No items found - No ad - admin_pending" : "Aucune annonce à valider",
    "No items found - No ad - admin_underreview" : "Aucune annonce à valider",
    "No items found - No ad - admin_under review" : "Aucune annonce à valider",
    "No items found - No ad - admin_willexpire" : "Aucune annonce à expiration prochaine",
    "No items found - No ad - admin_expired" : "Aucune annonce expirée",
    "No items found - No ad - admin_deleted" : "Aucune annonce expirée",
    "No items found - No ad - admin_published" : "Aucune annonce publiée",
    "No items found - No ad - admin_draft" : "Aucune annonce en brouillon",
    "No items found - No ad - admin_pending" : "Aucune annonce à valider",
    "No items found - No ad - admin_draftpendingpayment" : "Aucune annonce en attente de paiement",
    "No items found - No ad - admin_draft pending payment" : "Aucune annonce en attente de paiements", 
    "No items found - No ad - admin_willexpire" : "Aucune annonce à expiration prochaine",
    "No items found - No ad - admin_expired" : "Aucune annonce expirée",
    "No items found - No ad - admin_rejected" : "Aucune annonce rejetée",
    "No items found - No ad - admin_unpublished": "Aucune annonce retirée de la publication",

    "desc_robot_name" : "Nom ROBOT", 
    "help_robot_name" : "Nom à afficher lorsque'un action a été effecturée par un batch automatique du site", 


    // probanner url 
    "desc_probannerurl" : "Banniére (URL click)",
    "help_probannerurl" : "URL du site de destination quand on clique sur la banniére. Si 'vide', on utilise l'adresse du site web",

    "Are you sure you want to leave this form ?": "Êtes-vous sûr de vouloir quitter ce formulaire ?", 
    "warning" : "Attention", 


    // new configurable options
    "desc_site_off_line" : "Site OFF-LINE", 
    "help_site_off_line" : "Mettre le site principal off-line. le back-end d'administration reste fonctionnel et les visiteurs sont redirigés vare une page statique 'offline_{langue}.php'. ", 
    "desc_sitemap_publishing_en" : "Auto-publication SITEMAP", 
    "help_sitemap_publishing_en" : "Publication automatique (PUSH) vers les principaux CRWALERS du web", 
    
    "desc_list_viewmodes" : "Mode d'affichage des listes", 
    "desc_simple_list_view_en" : "Liste simple ", 
    "help_simple_list_view_en" : "Liste simple des annonces sans Image", 
    "desc_video_list_view_en" : "Lister 'par VIDEOS'", 
    "help_video_list_view_en" : " ", 
    "desc_audio_list_view_en" : "Lister 'par AUDIOS'", 
    "help_audio_list_view_en" : " ", 
    "desc_gmap_list_view_en" : "Lister sur CARTE GMAP", 
    "help_gmap_list_view_en" : " ", 
    "desc_gallery_list_view_en" : "Lister GALLERIE", 
    "help_gallery_list_view_en" : " ", 

    "Show Video Gallery" : "Afficher les annonces avec une video",

    "list filter on videogallery is ON" : "Attention, ne sont affichées que les annonces avec une video", 


    // champs pour les locations 
    "elem calendar" : "Prix et disponibilités ", 
    "Display elem calendar" : "Afficher les prix et disponibilités",
    "calendar list header text" : "Liste des réservations : ", 
    "Last updated:" : "Mise à jour:",
    "Create bookings" : "Ajouter une réservation", 
    "No entries in bookings" : "Aucune réservation pour l'instant", 

    "a_bo_moddate" : "Date",
    "a_bo_name" : "Titre",
    "a_bo_lastname" : "Loueur",
    "a_bo_start_date" : "Début",
    "a_bo_end_date" : "Fin",
    "a_bo_title" : "Libellé",

    " bookings form header title" : "Créer une réservation", 
    "modify bookings form header title" : "Modifier une réservation", 
    "bookings delete confirmation" : "Suppression de la réservation ?", 

    "booking details" : "Détails pricipaux", 
    "desc_bo_title" : "Libellé", 
    "help_bo_title" : "Un libellé pour s'y retrouver", 
    "desc_bo_start_end_date" : "Dates de début et fin", 
    "placeholder_bo_start_date" : "Début", 
    "placeholder_bo_end_date" : "Fin", 
    "desc_bo_nbadults": "Nbr personnes", 
    "booking user details" : "Détails sur le loueur",
    "desc_bo_gender" : "Genre",
    "desc_bo_comments" : "Commentaires",
    "desc_bo_ad_id" : "Ref#de l'annonce", 
    "help_bo_ad_id" : "ID de l'annonce à laquelle cette réservation est associée", 
    "desc_bo_moddate" : "Derniére modification", 
    "booking other details"  : "Autre information", 

    // admin
    "manage_bookings" : "Réservations",
    "manage_bookings_pending" : "A valider", 
    "help_manage_bookings" : "Gestion des Réservations",
    "bookings creation ongoing": "Réservation en cours de création :",
    "allbookings" : "Réservations", 
    "all bookings": "Réservations (toutes)",
    "a_bo_ad_id" : "ID annonce", 

    "The start date can not be greater then the end date" : "La date de début ne peut pas être plus grande que la date de fin", 
    "The end date can not be before the start date" : "La date de fin ne peut pas être antérieure à la date de début", 


    // settings pour le mode location
    "desc_rental mode" : "Mode Location", 
    "desc_rental_mode_en" : "Activer le mode", 
    "desc_calendar_auto_load" : "(CAL) Chargement auto.", 
    "desc_calendar_disable_before" : "(CAL) Dévalider jours AVANT", 
    "desc_calendar_week_start_day" : "(CAL) Jour de démarrage",
    "desc_cookie_save_calendar_nav" : "(CAL) Cookie mois",
    "desc_admin_acl_only_admin" : "Admin pour admin", 
    "desc_calendar_rolling_months": "Nombre mois affichés", 

    "help_rental_mode_en" : "Activer le mode location = affichage d'un calendrier de réservations", 
    "help_calendar_auto_load" : "(CAL) Chargement automatique des disponinilités", 
    "help_calendar_disable_before" : "(CAL) Dans le calendrier, les jours avant le jour courant sont dévalidé", 
    "help_calendar_week_start_day" : "(CAL) Jour de démarrage du calendrier (1=Lundi) ",
    "help_cookie_save_calendar_nav" : "(CAL) Suit la navigation du visiteur avec un cookie pour sauvegarder ses préférences de calendrier",        
    "help_admin_acl_only_admin" : "Le site d'administration est accessible uniquement pour les utilisateurs au profil ADMIN", 
    "help_calendar_rolling_months": "Nombre mois affichés", 


    "Admin site is not authorized to non admin people" : "Ce site d'administration n'est pas accessible aux personnes non autorisées comme vous !",     
    "Not authorized" : "Non autorisé", 

    // debuf options in settings 
    "desc_debug_file" : "Fichier de LOG/DEBUG", 
    "help_debug_file" : "Gestion du Fichier de LOG/DEBUG", 
    "clear debug file" : "Effacer le contenu", 
    "open debug file" : "Voir le fichier", 
    "Error writing to the debug file":"Error lors de l'accés au fichier de debug/log", 
    "File cleaned successfully":"Fichier effacé.", 


    // options pour FEEDBACK form 
    "feedback reason" : "Raison",
    "Fraud":"Fraude/Arnaque",
    "Wrong category":"Mauvaise catégorie",
    "Expired ad":"Annonce expirée",
    "Other":"Autre",

    // special login form 
    "Login with third party credentials" : "S'identifier avec  ", 
    "facebook login":"Me connecter avec Facebook", 
    "google login":"Me connecter avec Google", 
    "twitter login":"Me connecter avec Twitter", 
    "linkedin login":"Me connecter avec LinkedIn", 
    "login or" : " ou ",

    "auth-type-go" : "Google", 
    "auth-type-fb" : "Facebook", 
    "auth-type-tw" : "Twitter", 
    "auth-type-" : "Local", 

    "login_lostpassword": "Mot de passe oublié ?",
    "login_createaccount": "Pas encore de compte ?",
    "login_rememberme" : "Se souvenir de moi",

    " user form header oauth " : "Vous pouvez vous identifier à partir de ",
    "oauth register with facebook" : "Votre compte FACEBOOK", 
    "oauth register with google" : "Votre compte GOOGLE", 
    "oauth register with linkedin" : "Votre compte LINKEDIN", 
    "oauth register with twitter" : "Votre compte TWITTER", 

    "google account" : "compte GOOGLE",
    "facebook account" : "compte FACEBOOK", 
    "twitter account" : "compte TWITTER", 
    "linkedin account" : "compte LINKEDIN",  
 

    "This form has been pre-filled with inputs from your " : "La formulaire a été pre-rempli avec les données de votre ", 

    "desc_social_sharing":"Réseaux sociaux",
    "desc_fb_integration":"Widget LIKE Facebook",
    "desc_fb_url":"URL FACEBOOK",
    "desc_fb_auth":"Autent. FACEBOOK",
    "This form has been pre-filled with inputs from your": "Le formulaire a été renseigné avec les données de votre ", 

    "help_social_sharing":"Indique la liste des réseaux sociaux pour le bouton 'partager sur' au niveau des annonces ou annonceurs. Mettre un + entre chaque element. Codes : TW=TWITTER, FB=FACEBOOK, GO=GOOGLE+, LK=LINKEDIN, PI=PINTEREST, EV=EVERNOTE, DE=DELICIOUS ",
    "desc_facebook_settings" : "FACEBOOK configuration", 
    "help_fb_integration":"Intégration du widget Like de FACEBOOK sur la page d'accueil. Renseigner l'URL facebook ci-dessous obligatoirement",
    "help_fb_url":"URL du compte FACEBOOK",
    "help_fb_auth":"Permettre une connection au site par une autentification FACEBOOK. ATtention, necessite de déclarer l'application auprés de facebook et renseigner l'application-id dans le champ ci-dessous.",
    "desc_fb_appid" : "Application_ID", 
    "help_fb_appid" : "Application_ID = utilisé lorsque vous activez l'autentification via facebook comme identifiant de votre application. Réserver un App-ID via la console Facebook developpers.", 

    "desc_google_settings" : "GOOGLE configuration", 
    "desc_go_client_id" : "CLIENT_ID", 
    "help_go_client_id" : "CLIENT_ID = utilisé lorsque vous activez l'autentification via Google API comme identifiant de votre application. Réserver un App-ID via la console GOOGLE API.", 
    "desc_go_auth":"Autent. GOOGLE",
    "help_go_auth":"Permettre une connection au site par une autentification GOOGLE. Attention, necessite de déclarer l'application auprés de GOOGLE et renseigner le client-id dans le champ ci-dessous.",

    "desc_twitter_settings" : "TWITTER configuration", 
    "desc_tw_appid" : "API Key", 
    "help_tw_appid" : "API Key = utilisé lorsque vous activez l'autentification via TWITTER API comme identifiant de votre application.", 
    "desc_tw_auth":"Autent. TWITTER",
    "help_tw_auth":"Permettre une connection au site par une autentification TWITTER. Attention, necessite de déclarer l'application auprés de TWITTER et renseigner le API-id dans le champ ci-dessous.",
    "desc_tw_secret":"API secret",
    "help_tw_secret":"API secret key",

    "desc_linkedin_settings" : "LINKEDIN configuration", 
    "desc_lk_appid" : "API Key", 
    "help_lk_appid" : "API Key = utilisé lorsque vous activez l'autentification via LINKEDIN API comme identifiant de votre application.", 
    "desc_lk_auth":"Autent. LINKEDIN",
    "help_lk_auth":"Permettre une connection au site par une autentification LINKEDIN. Attention, necessite de déclarer l'application auprés de LINKEDIN et renseigner le API-id dans le champ ci-dessous.",
    "desc_lk_secret":"API secret",
    "help_lk_secret":"API secret key",

    "desc_disable_localization_validation"  : "Désactiver contrôles", 
    "help_disable_localization_validation"  : "Désactiver les contrôles liés à la localisation des champs PHONE, ZIP-CODE, ...", 

    "desc_scroll_top_px" : "Scroll top", 
    "help_scroll_top_px" : "En pixels, contrôle la hauteur de remontée de la page lors d'un re-centrage vertical automatique.", 

    "desc_hascalendar" : "Calendrier de location",
    "help_hascalendar" : "Associer à toutes les annonces de cette catégorie un calendrier de réservation. Attention, l'option 'LOCATION' doit être activée! ", 

    "pics" : "images",
    "a_parentid":"Parent", 
    "a_adultflag" : "adult?" ,
    "a_catlvfields" : "Champs", 
    "a_hascalendar" : "Cal.", 

    "all cats" : "Toutes les catégories", 
    "Create cats" : "Créer une catégorie", 

    "admin_cat_type_ad":"Annnonce uniq.", 
    "admin_cat_type_user":"Usagers uniq.",
    "admin_cat_type_":"Tous",

    "admin_ad_type_sell":"vend",
    "admin_ad_type_buy":"demande",
    "admin_ad_type_zetvu":"news/zetvu",

    "desc_desc_max_char" : "Desc. MAXCHARs", 
    "help_desc_max_char" : "Nombre maximum de caractères (max 1500) du champ description.", 

    "desc_rental_mode_all_cat" : "Sur toutes les annonces", 
    "help_rental_mode_all_cat" : "Si activé, toutes les annonces posséde un calendrier et le mode location. Si désactivé, il faut renseigner au niveau de CHAQUE catégorie le mode calendrier. ", 


    "desc_user_no_expiration_for_admin" : "ADMIN expire jamais",
    "help_user_no_expiration_for_admin" : "Les comptes de type administrateurs n'expireront pas",  

        //6.5.0 
    "upload audio file" : "Sélectionner un fichier audio", 
    "upload image file" : "Sélectionner une image", 

    "Show Audio Gallery" : "Afficher les annonces avec un media audio",
    "list filter on audiogallery is ON" : "Attention, ne sont affichées que les annonces avec un media audio", 

    "Your browser does not support the audio element." : "Votre navigateur ne supporte pas la fonction audio.", 
    "title audiourl" : "Message Audio", 
    "title audiourl user" : "Message Audio",
    "play/pause" : "Jouer/pause", 
    "volume up/down/mute" : "Volume (+/-/mute)",
    "next track" : "Prochain message audio",  
    "Click to play/stop : %s" : "Cliquez pour jouer/stopper le fichier : %s", 

    "desc_audiourl" : "Message(s) Audio",
    "help_audiourl %s" : "Vous pouvez ajouter %s message(s) audio au format WAV ou MP3.", 



    "desc_audio settings" :"Champs audio / vocal",
    "desc_audio_ad_en" :"Activer sur annonce",
    "desc_audio_user_en" :"Activer sur usager",
    "desc_audio_file_max_size" :"Taille max/audio",
    "desc_audio_file_max_nbr" :"Nbr max audio",
    "desc_audio_file_ext" :"Extensions",
    "desc_audio_file_download" :"Téléchargement?",
    "desc_audio_autoplay" :"Jouer automatiquement",
    "desc_audio_rec_online" :"Enregistrement",
    "desc_audio_rec_max_duration" :"Enreg. durée",
    "desc_audio_rec_ext" :"Enrge. extension",


    "help_audio_ad_en" :"Activer sur annonce : permettre l'ajout de medias audios sur une annonce.",
    "help_audio_user_en" :"Activer sur usager : permettre l'ajout de medias audios sur une annonce.",
    "help_audio_file_max_size" :"Taille max de chaque média audio chargé sur le site.",
    "help_audio_file_max_nbr" :"Nbr max de media audio par annonce ou usagers.",
    "help_audio_file_ext" :"Extensions autorisées des médias audios chargés.",
    "help_audio_file_download" :"Afficher un bouton qui permet au visiteur de téléchargement le fichier audio.",
    "help_audio_autoplay" :"Jouer automatiquement lors de l'affichage de l'annonce/annonceur.",
    "help_audio_rec_online" :"Enregistrement en ligne de messages audio. ",
    "help_audio_rec_max_duration" :"Durée max en secondes de l'enregistrement en ligne.",
    "help_audio_rec_ext" :"Format du fichier enregistré en ligne.",


    "desc_watermark" :"Filigrane sur images",
    "desc_watermark_en" :"Activer",
    "desc_watermark_file_url" :"URL du Filigrane",
    "desc_watermark_free_text" :"Text libre",
    "help_watermark_en" :"Activer l'ajout de filigrane (watermark) sur les images chargées sur le site.",
    "help_watermark_file_url" :"URL du Filigrane : url d'un fichier PNG ou autre qui sera utilisé comme filigrane. Attention, lechemin est relatif au repertoire /phpsvr. exemple d'URL valide = ../uploads/files/xxx.png",
    "help_watermark_free_text" :"Text libre qui sera utilisé en filigrane (si pas d'URL renseignée ci-dessus). ",


    // securedemail and phone numbers 
    "see the email" : "Voir l'adresse email", 
    "see the phone" : "voir le numero", 
    "desc_email_as_image_en" : "Email en image", 
    "desc_phone_as_image_en" : "Tél. en image", 
    "help_email_as_image_en" : "ANTI-SPAM : Email en image : l'email de l'annonceur est affiché comme une image et non un texte", 
    "help_phone_as_image_en" : "ANTI-SPAM : Tél. en image  : le teléphone  de l'annonceur est affiché comme une image et non un texte", 


    "footer title to add services" : "footer title to add services", 
    "footer text to add services" : "footer text to add services",

    // new menus 
    "gotoadmin" : "Administration", 
    "gotosite" : "Voir le site", 

    // free texte onsubscribtions / packs 
    "settings_free_texts" :"Textes libres", 
    "settings_free_text1" :"Texte 1", 
    "settings_free_text2" :"Texte 2", 
    "settings_free_text3" :"Texte 3", 

    "desc_social_connect_general" : "Social Login",
    "desc_oauth_sso_en" : "Activer oauth", 
    "desc_oauth_auto_create_user" :"Creation auto accés", 
    "help_oauth_sso_en" : "Activer la connection SOCIAL pour accéder au site via les réseaux sociaux ci-dessous.", 
    "help_oauth_auto_create_user" :"Creation automaique des comptes usagers sans passer par l'enregistrament. Attention, pas compatible avec les plans d'abonnements", 


    //6.5.1
    "Thanks you for your payment %s %s ! Your service is activated." : "Merci pour votre achat %s %s , votre pack de service est activé.", 
    "desc_cust_cookie_url" : "Cookies (url)", 
    "help_cust_cookie_url" : "Lien (utl) ver page Cookies", 
    // nom du lien en bas de page 
    "Cookies" :"Cookies", 

    "desc_list_default_view" : "Vue par défaut", 
    "help_list_default_view" : "vue par défaut lors de l'affichage des listes d'annonces. Les valeurs possibles sont   : list | simplelist  | gallery  | videogallery | audiogallery | maplist  ",

    "desc_cookie_display_cookies_disclamer": "Avertissement cookies", 
    "help_cookie_display_cookies_disclamer": "Affiche un message d'avertissement legal sur les cookies lors de la premiére visite", 
    "Cookies policy disclamer": "En poursuivant votre navigation sur ce site, vous acceptez l'utilisation de cookies nécessaire au bon fonctionnement du site. <a class='cookiesWarning-link' href='cookies_fr_zads.php' target='_blank'>Plus d'informations sur notre politique « cookies ».</a> <i class='close icon-fa-times-circle mr6'></i>",

    // sysem messages displayed in ADMIN
    "SYS - delete install.php":"Merci de supprimer le fichier <strong>install.php</strong> pour des raisons de sécurité.", 
    "SYS - debug mode and level > 3 if active" : "Le mode debug est actif avec un niveau elevé (>3) d'informations. Risque de sécurité.",

    //6.5.3 
    "desc_dis_ad_loc" : "Pas de Locat. AD", 
    "help_dis_ad_loc" : "Désactiv. la saisie de la localisation pour les annonces.", 
    "desc_dis_user_loc" : "Pas de Locat. USER", 
    "help_dis_user_loc" : "Désactiv. la saisie de la localisation pour les usagers.", 

    "desc_user_cat2" : "Type d'activité", 
    "desc_cat2" : "Activité", 

    "desc_advs_no_freetext" : "Pas champ recherche",
    "help_advs_no_freetext" : "Le champ de recherche libre est masqué",

    "desc_advs_forced_vfields" : "Ajouter toujours vfields ..", 
    "help_advs_forced_vfields" : "Ce mode permet d'afficher de champs VFIELDS systématiquement sur la barre de recherche. format = idA|idB|idC", 

    
    "desc_nav_no_bar" : "Pas be barre de nav.",
    "help_nav_no_bar" : "Mode expert ! pas de barre de navigation principale. Pas compatible avec un affichage de carte ou de pages spéciales !",

    "desc_maincat_user_pid" : "Nav User per PID", 
    "help_maincat_user_pid" : "Mode expert !  : la barre de navigation affichant les usagers est découpée fonction des catégories users de niveau 1.", 

    "%s room" : "%s piéce", 
    "%s rooms" : "%s piéces", 

    "filtered : %s" : " filtré : %s", 

    "desc_seo_forced_vfields" : "SEO champs virtuels en plus", 
    "help_seo_forced_vfields" :"Liste (ID|ID|ID) des valeurs de champs virtuels à ajouter dans le META/SEO des annonces affichées. Seront ajoutés à la fin du TITLE et à la fin de la META DESCRIPTION",
    "desc_no_mobile_css" :"No mobile CSS",
    "help_no_mobile_css" :"Désactiver le théme mobile",

    "settings_ad_audiourl" : "Max fichiers audios", 
    "settings_ad_videourl" : "Max fichiers videos", 
    "ad_audiourl" : "Fichiers audios par annonce", 
    "ad_videourl" : "Fichiers videos par annonce",

    "settings_us_audiourl" : "Max fichiers audios", 
    "settings_us_videourl" : "Max fichiers videos", 
    "us_audiourl" : "Fichiers audios / profile", 
    "us_videourl" : "Fichiers videos / profile", 

    "desc_emails_admin_hourly_send" : "Notification horaire", 
    "help_emails_admin_hourly_send" : "Notification horaire", 
    "desc_en_ad_hits" : "Hits", 
    "help_en_ad_hits" : "Hits", 
    "desc_en_ad_likes" : "Likes", 
    "help_en_ad_likes" : "Likes", 
    "desc_en_user_hits" : "Hits", 
    "help_en_user_hits" : "Hits", 
    "desc_en_user_likes" : "Likes", 
    "help_en_user_likes" : "Likes", 

    // likes management
    "click to like it!" : "Cliquer pour dire que vous aimez!",
    "Sort by likes desc" : "Tier par les plus aimés",

    "cannot upload more file : exceeded quantity" : "Impossible de charger un fichier de plus - quantité autorisée dépassée !", 

    "desc_reset_all_user_likes" : "Réinitialiser likes usagers",
    "help_reset_all_user_likes" : "Réinitialiser (remet à zero) le compteur de like de tous les usagers.",
    "desc_reset_all_ad_likes" : "Réinitialiser likes annonces",
    "help_reset_all_ad_likes" : "Réinitialiser (remet à zero) le compteur de like de toutes les annonces.",
    "reset_all_user_likes" : "Réinitialiser",
    "reset_all_ad_likes" : "Réinitialiser",


    "desc_page_php" : "Page home Externe (PHP)", 
    "desc_page_home_is_php" : "Activer", 
    "help_page_home_is_php" : "Si activé, la page d'accueil est chargée à partir de la page PHP ci-dessous.", 
    "desc_page_home_php_url" : "Url de la page externe",
    "help_page_home_php_url" : "Url de la page externe contenant le contenu PHP a charger sur la page d'accueil",

    //Z6.5.6 -> multi-medias elemnts 
    "media booth h1 - audio_recording" : "Cabine d'enregistrement", 
    "media booth into - audio_recording" : "Enregistrez votre message audio ici", 
    "visu in title" : "Entrée : fréquencemétre", 
    "visu out title" : "Sortie", 
    "record" : "Enregistrer maintenant",
    "recording"  : "Enregistrement en cours - Arreter", 
    "rec play" : "Ecouter l'enregistrement", 
    "(rec playing) stop" : "(écoute en cours) - Arreter", 
    "rec download" : "Télécharger sur mon pc",
    "rec save" : "Sauvegarder dans l'annonce",

    "media booth h1 - picture_snap" : "Cabine photo", 
    "media booth into - picture_snap" : "Capturez vos images ici.", 
    "take screenshot" :"Prendre la photo",
    "video in title" : "Entrée : video", 
    "video out title" : "Votre photo",
    "snap effect" : "Appliquer un effet", 
    "snap download" : "Télécharger sur mon pc",
    "snap save" : "Sauvegarder dans l'annonce",

    "effect_nornal":"nornal", 
    "effect_sepia":"sepia", 
    "effect_brightness":"luminosité", 
    "effect_contrast":"contrasté", 
    "effect_desaturate":"saturation", 
    "effect_grayscale":"niveau de gris", 
    "effect_threshold":"seuil", 
    "effect_noise":"bruit", 
    "effect_invert":"inversé", 

    "audiourl record now" : "Enregistrer en live",
    "filename record now" : "Prendre une photo",
    "avatarimg record now" : "Prendre une photo",
    "no more space left to save the recorded element" : "Vous ne pouvez pas enregistrer car vous avez depassé le numbre max d'éléments.", 

    "If you reject access to your local media, this feature cannot be used. Bye." : "Vous avez refusé l'accés à vos médias. Cette fonction ne peut pas être utilisée. Bye",
    "This capability (getUserMedia) is not supported in your browser" : "Cette fonctionnalité n'est pas disponible sur ce navigateur. Prendre CHROME ou FIREFOX derniére version",

    "desc_picture_rec_online" : "Capture Photos", 
    "help_picture_rec_online" : "Permetter aux annonceurs de capturer des photos directement depuis le navigateur (si il est compatible web RTC, c'est à dire CHROME et FIREFOX)", 
    "desc_general fields" : "Champs communs / image",
    "desc_authorized_languages" : "Langues autorisées",

    "No entries in banners" : "Pas de publicités pour l'instant.",

    // Z6.5.6
    "payment" : "paiement", 
    "all my_favs_ad" : "Mes annonces favorites",
    "watermark_pos_topright":"En haut à droite", 
    "watermark_pos_topleft":"En haut à gauche", 
    "watermark_pos_bottomright":"En bas à droite", 
    "watermark_pos_bottomleft":"En bas à gauche", 
    "desc_watermark_pos":"Position", 
    "desc_watermark_test_it":"Testeur", 
    "watermark_test_it":"Tester le watermark", 
    "Sample image with watermark in position : " : "Image d'essai avec le filigrane en position : ", 

    // Z6.5.7
    "Call us now!" : "Appelez nous !",
    "desc_cust_contact_phone"  : "Téléphone",
    "help_cust_contact_phone"  : "Numéro de téléphone qui sera affiché avec un tel: en bas de page. Préférez un numérotcanonique internationnal de type +33 4455666 pour plus de compatibilité.",
    "a_pricetype" : "Prix?", 
    "cat pricetype" : "Permettre prix ?", 
    "help cat pricetype" : "Indique si, pour cette catégorie, le champ prix est affiché ou pas. Permet d'interdire la saisie des prix pour toutes les annonces de cette catégorie", 
    "no price" : "Pas de prix", 
    "pricetype default" : "Oui", 
    "Cancel pack" : "Annuler ce pack",
    "service cancellation ongoing" : "Annulation du pack en cours", 

    "filter per user id" : "Filtrer par ID usager", 
    "admin_services_type_trial" :"TRIAL", 
    "admin_services_type_base" :"BASE", 
    "admin_services_type_" :"----", 
    "admin_services_type_pack" :"PACK", 
    "settings_radio_pack" : "Service", 

    "service cancel dialog title" : "Annulation d'un pack", 
    "Confirm delete of service :" : "Confirmez l'annulation du pack :",

    "desc_hosting_cdn" : "Hosting / CDN", 
    "desc_cdn_en" : "Activer CDN", 
    "help_cdn_en" : "Activer CDN : active le mode ou les librairies principales de ZADS sont téléchargées sur un réseau de type DCN ou un hosting", 
    "desc_cdn_url" : "URL du CDN", 
    "help_cdn_url" : "URL du CDN : URL du bucket principal root de stokage des librairies. L'arborescence doit êre la même que sur le site principal", 


    "desc_super_notifications" : "Notifications", 
    "desc_email_superadmin" : "super admin email",
    "help_email_superadmin" : "Adresse email utilisée pour envoyer les rapports de back-ups en plus du rapport traditionnel",
    "desc_backup_deleteall" : "Effacer tout", 
    "help_backup_deleteall" : "Effacer toutes les archives anciennes à chaque fois avant la creation de la nouvelle archive.", 

    "Pay delete" : "Supprimer", 
    "Please confirm modification to status 17 of :" : "En cliquant, <i>je confirme</i>, l'élément ci-dessous sera supprimé.",

    "log_update_DRAFT PAYMENT CANCEL" : "Paiement annulé",
    "help_on_status DRAFT PAYMENT CANCEL" : "La paiement est annulé",
    "DRAFT PAYMENT CANCEL" : "Paiement annulé",

    //Z6.5.9 - nouvelles options administration 
    "desc_en_gzip" : "Compression GZIP",
    "help_en_gzip" : "Compression GZIP des echanges AJAX entre le navigateur et le serveur PHP.",
    "desc_hide_nb_ads" : "Masquer compteurs",
    "help_hide_nb_ads" : "Masquer les compteurs d'annonces",
    "desc_en_richeditor" : "Editeur de texte riche", 
    "desc_en_richeditor" : "Editeur de texte riche pour les champs TEXTEDITs ", 
 
    "desc_en_streetview" : "Activer STREETVIEW", 
    "help_en_streetview" : "Activer le mode Google StreetView", 


    "desc_doc settings" : "Documents",
    "desc_doc_ad_en" : "Doc. sur annonces", 
    "desc_doc_user_en" : "Doc sur usagers", 
    "desc_doc_file_max_size" : "Taille max ", 
    "desc_doc_file_max_nbr" : "Nombre Max fichiers", 
    "desc_doc_file_ext" : "Extensions", 
    "desc_doc_file_download" : "Autoris. téléchargement", 


    "help_doc_ad_en" : "Autorise l'ajout de documents sur les annonces.", 
    "help_doc_user_en" : "Autorise l'ajout de documents sur les annonceurs.", 
    "help_doc_file_max_size" : "Taille max en octets de chaque document.", 
    "help_doc_file_max_nbr" : "Nombre Max fichiers par annonce", 
    "help_doc_file_ext" : "Extensions autorisées (séparer par | chaque type) ", 
    "help_doc_file_download" : "Autoriser le téléchargement des documents", 


    "desc_price_field_second" : "Autoriser 2éme prix", 
    "help_price_field_second" : "Autorise la saisie d'un second prix qui permet de gérer les hausse/baisses de prix", 

    "desc_all_price_freeofcharge" : "Services Packs Gratuits", 
    "help_all_price_freeofcharge" : "Tous les services packs sont gratuits", 

    "desc_docurl" : "Document(s)",
    "download file : " : "Télécharger le fichier : ", 
    "title docurl" : "Fichiers", 

    "desc_metatitle" :"(SEO) META TITLE",
    "desc_metadesc" :"(SEO) META DESCRIPTION",
    "desc_metakey" :"(SEO) META KEYWORDS",

    "help_metatitle" :"(SEO) META TITLE",
    "help_metadesc" :"(SEO) META DESCRIPTION",
    "help_metakey" :"(SEO) META KEYWORDS",


    // gestion du double prix
    "ad pricearea"  : "Prix",

    // date expirées sur options
    "expired datetime " : "expiré ", 


    // lost password new sequence
    "change password form introduction" : "Vous avez souhaité réinitialiser votre mot de passe. Utilisez ce formulaire pour choisir un nouveau mot de passe.", 
    "Your password activation Key is already posted to your email address, please check your Email address & Junk mail folder." : 
      "Votre clé d'activation du mot de passe est déjà posté à votre adresse e-mail , s'il vous plaît vérifier votre adresse e-mail et courrier indésirable dossier.", 

    "We sent you an email to reset your password." :  "Nous vous avons envoyé un e-mail pour réinitialiser votre mot de passe.",
    "Your email address is not correct" : "Votre adresse e-mail est incorrect", 
    "Wrong activation conditions" : "Mauvaises conditions d'activation",
    "Password updated successfully.":"Mot de passe mis à jour avec succès.",
    "Wrong activation conditions for updatepassword":"Mauvaises conditions d'activation", 

    "desc_lostpassword_link" : "Email réinitialiser mdp", 
    "help_lostpassword_link" : "Si cette option est activée, en cas de perte du mot de passe, un email avec une URL de réinitialisation et proposé eu lieu d'une génération de mot de passe automatique par le site.",     


    // visitor table
    "manage_visitors" : "Visiteurs",
    "fbot" : "Uniquement crawlers", 
    "fgoogbot" : "Uniquement Google bot",
    "fbingbot" : "Uniquement bing bot",
    "IP address or fqdn" : "Adresse IP ou URI", 
    "a_uri" : "URI", 
    "a_ua" : "USER AGENT", 
    "all visitors" : "Tous les visiteurs", 
    "delete_allbutbot" : "Effacer tout SAUF les crawlers",
    "delete_allall" : "Effacer TOUT",
    "delete_allfilter" : "Effacer tout ce qui est FILTRE actuellement",

    "desc_enable_visitors_logs" : "Log des visiteurs", 
    "help_enable_visitors_logs" : "Enregistre toutes les visites du site (IP, UA, URI, ..). Permet de faire ensuite des statiques ou detecter les crawlers ou adresses IPs frauduleuses. Attention, ce mode génére beaucoup de données qui peuvvent saturer votre stockage", 

    // about pages 
    "manage_about" : "A propos", 
    "all about" : "A propos / information", 
    "zads_version" : "Version de ZADS",
    "server_software" : "Type de serveur",
    "php_version" : "Version PHP",
    "php_ini" : "Paramétres fichier PHP.INI",
    "mysql_version" : "Version MySQL",
    "php_extensions" : "Extensions PHP", 
    "changelog" : "Derniers changements", 
    "blog" : "Le blog de ZADS", 
    "support" : "Support", 
    "mysql_size_mb" : "Espace utilisé dans la base de données",
    "mysql_stats" : "Détails espace utilisé par tables",
    "files_size" : "Taille des fichiers stockés",
    "last_backup" : "Derniere Sauvegarde",
    "debugfile" : "Debug file",
    "force_backup" : "Obtenir une archive par email",

    "%s post_vcounters_phone" : "%s",
    "%s post_vcounters_email"  : "%s",

    "help_on_post_vcounters_email" : "Nombre d'emails recus ou clicks pour voir votre email.", 
    "help_on_post_vcounters_phone" : "Nombre de clicks pour voir votre numéro de téléphone.", 
    
    // imagepour simplifier la gestion des banniéres pub basées sur une image uniquement
    "desc_banimgurl" : "Image",
    "help_banimgurl" : "Optionnel : charger directement une image dans votre environnement et le code HTML va se générer automatiquement. Attention, le code HTML est écrasé !",


    "desc_seo_googlebot_directhtml" : "SEO amélioré Google", 
    "help_seo_googlebot_directhtml" : "SEO amélioré Google : permet d'avoir un mode de gestion différentié pour Google lors du référencement.", 

    "desc_assocprojects" : "Super-administrateur", 
    "help_assocprojects" : "Super-administrateur : permet la gestion compléte du site y compris les options avancées d'administration. Attention, mettre aussi les droits d'administration !",

    "search for title or description" :"Rechercher",

    "desc_locale_gmap_zoom" : "Zoom (defaut)", 
    "desc_en_gmap_in_display" : "GMAP dynamiques", 
    "help_locale_gmap_zoom" : "Facteur de zoom par defaut pour les garte google map. Entre 0 et 19 . niveau ville = 10", 
    "help_en_gmap_in_display" : "GMAP dynamiques : affiche des cartes Google Map dynamique au lieu d'une image statique dans les annonces.", 

    "desc_seo":"Sitemap et SEO",
    "desc_xtrasitemap_xml_url":"Xtra sitemap url",
    "help_xtrasitemap_xml_url" :"Ajoute au début du sitemap généra par ZADS, le contenu XML présent à l'URL indiquée. Attention, ce doit être uniquement de entrées <url></url> sans l'entête.",
    "desc_sitemap_file" :"Sitemap" ,
    "help_sitemap_file" : "Force la génération du sitemap immédiatement", 
    "force sitemap generation": "Générer un sitemap",
    "open the sitemap": "Voir le fichier",
    "Sitemap generated successfully": "Génération du SITEMAP.XML avec succés",

    "desc_gmap_custom_marker_url" : "Marqueur GoogleMap perso.", 
    "help_gmap_custom_marker_url" : "Indiquez l'URL du fchier PNG qui marquera les emplacements de annonces sur la carte ( taille MAX 20x20 recommandé )", 

    "change price" :"Changer le prix",

    "Admin interface better work with CHROME browser." : "L'interface d'administration marche mieux avec CHROME. Merci de changer de navigateur.",
     
    // seo
    "desc_seo_add_fields" :"SEO : ajout de champs db",
    "desc_seo_add_fields_pos" :"SEO : position champs db",
    "desc_seo_add_fields_sep" :"SEO : séparateur champs db",

    "help_seo_add_fields" :"List les champs de la base de donnée de ZADS que vous souhaitea afficher dans le TITLE et META DESCRIPTION. Sépareteur ';'. utiliser les noms des champs de la base de donnée. Example loccity = Ville, locdept =  département, ...",
    "help_seo_add_fields_pos" :"Position dans le titre  : 'post' =  aprés, 'pre' = avant le texte",
    "help_seo_add_fields_sep" :"Séparateur qui sera utilisé entre les champs.",

    "desc_seo_display_fqdn": "Ajouter FQDN", 
    "help_seo_display_fqdn": "Ajouter le fdqn du site à la fin du TITLE séparés par un '|' ", 

    "facebook fan page" : "Facebook",

    "Con excecuted successfully" : "Execution du script avec succés, verifier votre boite email et le journal d'activité pour les résultats.",
    "cron tests" : "Test des scripts (CRON)",  


    "Price to be defined in catalogue section for this reference" : "Les prix sont définits pour cette Référénce Cat. dans la section catalogue.",

    "desc_paypal_forced_localecode" : "Paypal Locale Code",
    "help_paypal_forced_localecode" : "Paypal Locale Code : un code 5 caractéres pour indiquer la langue paypal par défaut. Si rien d'indiqué, on utilise le code pays.",

    "desc_locale_location_restrictfield": "Restriction (champ)", 
    "help_locale_location_restrictfield": "Restriction (champ) : permet de restreindre les annonces à une zone géographique. Indiquer ici le critére = champ de la base de donnée.", 
    "desc_locale_location_restrictvalues": "Restriction (values)", 
    "help_locale_location_restrictvalues": "Restriction (values) : lorsque la zone geo. est restreinte, permet d'indiquer ici les valeures (séparateur ';' ) ", 


    "This location is not authorized" : "Cette adresse n'est pas autorisée.",
    "Restricted location area" : "Uniquement les annonces en Suisse", 

    "desc_emails_templates_enh" : "Templates améliorée (V2)",
    "help_emails_templates_enh" : "Templates améliorée (V2 : dans ce mode, le SUJET de l'email est également inclus dans le modéle.",   
    
    "desc_emails_templates_dir" : "Répertoire templates emails", 
    "help_emails_templates_dir" : "Indiquer le répertoire ou se trouve les modéles d'emails. A partir de la racine des fichiers server php et ajouter un slash à la fin ! ",   

    "manage_emails_routings" : "Routages des emails", 
    "emailsroutes" :  "Routages des emails", 

    "save routingtable" : "Sauvegarder la table des routages", 
    "test all emails" : "Test - envoyer tous les emails !", 
    "sendallmails confirmation title" : "Test - envoyer tous les emails !", 
    "sendallmails confirmation body" : "Attention, si vous confirmez, tous les emails vont sous être envoyés pour test. Cela peut prendre plusieures minutes !", 

    "edit email" : "éditer",
    "delete email" : "supprimer",  
    "test email" : "envoi de test", 
    "* modified - don't forget to save!" : "* modifié. Ne pas oublier de sauvegarder.", 

    "desc_api/cron tokens" : "Clefs de sécurité",  
    "desc_cron_token" : "Clef de sécurité CRONJOB",
    "help_cron_token" : "Clef de sécurité CRONJOB : cette clef (KEY) permet de sécuriser les CRONJOBS. Elle doit être envoyée comme paraméte token=KEY d'une méthode GET",

    "Confirm route add": "Confirmation ajout d'une route", 
    "add route" :"Ajouter une route", 
    "Please confirm route ad" : "Merci de choisir une destination et confirmer", 
    "-- select one destination --": "-- Choisir une destination --",
    "Please confirm deletion of this route : " : "Merci de confirmer l'éffacement de cette route",

    "upload banimgurl" : "charger une image",
    "user edit" : "éditer", 


    "desc_seo_inspect_like_googlebot" : "DEBIG : Explorer like Google", 
    "help_seo_inspect_like_googlebot" : "Mettre le site principal en mode exploration comme googlebot : le site 'snapshot' est affiché.", 
    "desc_seo_display_ugly_url" : "DEBUG : Afficher ugly url", 
    "help_seo_display_ugly_url" : "DEBUG : Afficher les urls avec le ?_escaped_fragment_= ", 
    "desc_seo_full_php_site" : "DEBUG : Site mode PHP pur", 
    "help_seo_full_php_site" : "Affiche le site en pur PHP sans AJAX pour des tests de référencement natif ", 
    "desc_seo_catlist" : "Lister les catégories", 
    "help_seo_catlist" : "Lister les catégories lors du référencement. 'nonull'= affiche uniquement les catégories avec au moins une annonce.  'all' : afficher tout.  {vide} : ne pas afficher ", 

    "about_subscription" : "Abonnement", 
    "about_expire" : "Expire le",
    "about_install" : "Installation", 
    "about_sitemap" : "Sitemap", 


    "allcats" : "Catégories / Champs", 
    "allsubscribers" : "Newsletter", 
    "allservices" : "Packs d'annonces", 
    "manage_settings" : "Configuration générale",
    "manage_zetvu" : "News/Zetévu/tutos", 
    "manage_emails" :"Emails & notifications",
    "settings_submenu_emails" : "Emails adresses <i class='ml6 icon-fa-cog'></i>",
    "allsubscriptions" : "Config. Abonnements", 
    "settings_submenu_services" : "Configuration <i class='ml6 icon-fa-cog'></i>",
    "settings_submenu_pricingplan" : "Plans d'abonnement <i class='ml6 icon-fa-cog'></i>",
    "allpages" : "Pages",
    "settings_submenu_sitepages" : "Page d'accueil<i class='ml6 icon-fa-cog'></i>",

    "geolocal ip":"Géolocaliser l'ip", 


    "admin_coms_type_comment" : "commentaire",
    "a_description" : "Texte", 
    "a_abuse" : "Abus", 

    // translations for commenting system
    "comment no-posts" : "Aucun commentaires",
    "no comment" : "Aucun commentaires",
    "comment save" :"Valider", 
    "comment next" : "Commentaires suivants", 
    "comment delete" : "Supprimer",
    "comment edit" : "Editer", 
    "comment like" : "Voter pour",
    "comment dislike" : "Voter contre",
    "comment abuse" : "Signaler un abus",
    "com is abuse" : "Ceci a été signalé comme abusif", 
    "comment reply" : "Répondre",
    "ad comment loading" : "Chargement des commentaires en cours ...", 
    "ad comment" : "Commentaires ...",
    "allcoms" : "Commentaires/revues", 

    '%s comment' : '%s commentaire',
    '%s comments' : '%s commentaires', 

    "manage_coms_review": "Revues/Evaluations", 
    "manage_coms_comment": "Commentaires",
    "settings_submenu_coms": "Configuration <i class='ml6 icon-fa-cog'></i>",
    "all coms_comment" : "Tous les commentaires",
    "all coms_review" : "Toutes les évaluations", 
    "No entries in coms" : "Aucun commentaires/évaluations",

    "comment tform textarea placeholder" : "Posez vos questions sur cette annonce... Merci de ne pas ajouter de coordonnées personnelles (mail, téléphone... etc) et de faire preuve de courtoisie !",
    "review tform textarea placeholder" : "Déposez vos évaluations ... Merci de ne pas ajouter de coordonnées personnelles (mail, téléphone... etc) et de faire preuve de courtoisie !",


    "coms_comment_purgedeleted" : "Purger supprimés", 
    "coms_review_purgedeleted" : "Purger supprimés", 

    "a_likes" : "Likes", 


    "review no-posts" : "Aucune revue",
    "no review" : "Aucune revues",
    "review save" :"Valider", 
    "review next" : "Suivants", 
    "review delete" : "Supprimer",
    "review edit" : "Editer", 
    "review like" : "Voter pour",
    "review dislike" : "Voter contre",
    "review abuse" : "Signaler un abus",
    "com is abuse" : "Ceci a été signalé comme abusif", 
    "review reply" : "Répondre",
    "ad review loading" : "Chargement des revues en cours ...", 

    '%s review' : '%s évaluation',
    '%s reviews' : '%s évaluations', 

    "ad_rating1_name" : "Conformité", 
    "ad_rating2_name" : "Livraison", 
    "ad_rating3_name" : "Accueil", 

    "review summary" : "Moyenne", 
    "review post" : "Poster une évaluation", 

    "review rating please select something" : "Voter", 
    "ad_rating1_level_0" : "Voter",
    "ad_rating1_level_1" : "Trés mauvais ",
    "ad_rating1_level_2" : "Mauvais",
    "ad_rating1_level_3" : "Moyen",
    "ad_rating1_level_4" : "Bien",
    "ad_rating1_level_5" : "Trés bien",

    "ad_rating2_level_0" : "Voter",
    "ad_rating2_level_1" : "Niveau 1",
    "ad_rating2_level_2" : "Niveau 2",
    "ad_rating2_level_3" : "Niveau 3",
    "ad_rating2_level_4" : "Niveau 4",
    "ad_rating2_level_5" : "Niveau 5",

    "ad_rating3_level_0" : "Voter",
    "ad_rating3_level_1" : "Niveau 1",
    "ad_rating3_level_2" : "Niveau 2",
    "ad_rating3_level_3" : "Niveau 3",
    "ad_rating3_level_4" : "Niveau 4",
    "ad_rating3_level_5" : "Niveau 5",



    "user_rating1_name" : "Conformité", 
    "user_rating2_name" : "Livraison", 
    "user_rating3_name" : "Accueil", 

    "review rating please select something" : "Voter", 
    "user_rating1_level_0" : "Voter",
    "user_rating1_level_1" : "Niveau 1",
    "user_rating1_level_2" : "Niveau 2",
    "user_rating1_level_3" : "Niveau 3",
    "user_rating1_level_4" : "Niveau 4",
    "user_rating1_level_5" : "Niveau 5",

    "user_rating2_level_0" : "Voter",
    "user_rating2_level_1" : "Niveau 1",
    "user_rating2_level_2" : "Niveau 2",
    "user_rating2_level_3" : "Niveau 3",
    "user_rating2_level_4" : "Niveau 4",
    "user_rating2_level_5" : "Niveau 5",

    "user_rating3_level_0" : "Voter",
    "user_rating3_level_1" : "Niveau 1",
    "user_rating3_level_2" : "Niveau 2",
    "user_rating3_level_3" : "Niveau 3",
    "user_rating3_level_4" : "Niveau 4",
    "user_rating3_level_5" : "Niveau 5",

    "Your acount is under review. You can login only when approved. " : "Votre accès est en cours de d'approbation. <br> Une fois approuvé, vous pourrez vous connecter ici : ", 
    "account under review" : "Compte correct mais pas encore autorisé.", 

    "desc_indir_yes_default" : "Annuaire par défaut",
    "help_indir_yes_default" : "Annuaire par défaut coché.",

    "it_IT"  : "italien",
    "se_SE"  : "swedois",


    // end 
    'dummy' : 'idiot'
    }; 

