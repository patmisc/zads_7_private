
// JavaScript Document

if  (typeof monthnb_2_string == 'undefined')  var monthnb_2_string = []; 
if  (typeof daynb_2_string == 'undefined')  var daynb_2_string=[]; 
if  (typeof my_dictionary == 'undefined')  var my_dictionary=[]; 


 monthnb_2_string['ar_AR'] ={
  1 : "Jan.",
  2 : "Fév.", 
  3 : "Mar.",
  4 : "Avr.",
  5 : "Mai",
  6 : "Jun.",
  7 : "Jui.",
  8 : "Aou.",
  9 : "Sep.",
  10 : "Oct.",
  11 : "Nov.",
  12 : "Déc."
}

daynb_2_string['ar_AR'] ={
  0 : "Dimanche",
  1 : "Lundi", 
  2 : "Mardi",
  3 : "Mercredi",
  4 : "Jeudi",
  5 : "Vendredi",
  6 : "Samedi"
}

my_dictionary['ar_AR'] = { 
    // genéral dates : 
    "yesterday"  : "hier",
    "today"  : "aujourd'hui",
    "tomorrow" : "demain",
    "%s day ago" :"%s jour",
    "%s days ago" :"%s jours",
    "till "  : "jusqu'au ", 
    "yes" : "oui", 
    "no" : "non", 
    
    "in %s day" :"dans %s jour",
    "in %s days" :"dans %s jours",
    "days" : "jours", 
    "day" : "jour", 
    "the" : "le", 
    "the " : "le ",
    
    "%s ads" : "%s annonces" ,
    "%s ad" : "%s annonce" ,
    "no ad" : "aucune annonce",
    
    
    "%s cats" : "%s catégories" ,
    "%s cat" : "%s catégorie" , 
    
    "%s users" : "%s usagers" ,
    "%s user" : "%s usager" ,
    
    "no user" : "aucun annonceur",
    
    // global 
    "more" : "Plus de détails",
    "Load more" : "Voir la suite", 

    // offline 
    "Site is offline" : "Le site est suspendu", 
    "Site is no more available." : "Le site n'est plus disponible pour l'instant.",

    
    // general BROWSER detection messages
    "You're using IE8 or above" : "Vous utilisez IE 8 ou sup.",
    "You're using IE7.x" :  "Vous utilisez IE 7.x ",
    "You're using IE6.x" :  "Vous utilisez IE 6.x ",
    "You're using IE5.x" :  "Vous utilisez IE 5.x ",
    ': this browser is partialy supported . See the list <a href="navsupported_fr.html">here</a>' : ' : ce navigateur est partiellement supporté. Voir la liste <a href="navsupported_fr.html">ici</a>',
    
    // general navigation 
    "Main cat sell" : "اعلانات",
    "Main cat buy" : "طلبات", 
    "Main cat user" : "متاجر", 
    "Zetvu" : "Zetévu",
    "my admin" : "[ ادارة ]", 
 
    // boutons de creation 
    "add a cat"  : "أضف قسم",
    "add a user"  : "أضف مستخدم",
    "add a sell"  : "أضف اعلانك",
    "add a buy"  : "أضف اعلانك",
    
    // texte d'introduction  aux formulaires 
    " ad form header title"  : "Mon annonce: ",
    " ad form header introduction" : "A travers ce formulaire, déposez votre annonce. <br>Elle est GRATUITE et sera disponible après validation par le comité éditorial. Elle restera visible 60 jours. <br>Merci de pendre en compte les champs obligatoires marqués d'une étoile. <br> ",
    
    "preview ad form header title"  : "Valider votre  annonce: ",
    "preview ad form header introduction"  : "Vérifier le contenu de votre annonce et valider aprés avoir accepté les régles de diffusion et d'utilisation de l'annonce",
    
    
    "modify ad form header title"  : "Modifier mon annonce: ",
    "modify ad form header introduction" : "A travers ce formulaire, modifier votre annonce. <br>Elle est GRATUITE et sera disponible après validation par le comité éditorial. Elle restera visible 60 jours. <br>Merci de pendre en compte les champs obligatoires marqués d'une étoile. <br> ",


    " user form header title"  : "Enregistrement : ",
    " user form header introduction" : "A travers ce formulaire, enregistrez vous immédiatement.<br>Merci de pendre en compte les champs obligatoires marqués d'une étoile.  ",
    " user form header introduction facebook" : "Vous pouvez vous identifier à partir de <span class='icon-menu' id='facebook'><span class='icon'></span><a href='#' what='facebook'  name='action-on-elem' class='text'>votre compte facebook.</a></span><br> ",

    "preview user form header title"  : "Valider votre compte: ",
    "preview user form header introduction"  : "Vérifier les détails de votre compte et validez aprés avoir accepté les conditions générales du site",
    

    "modify user form header title"  : "Modifier un usager: ",
    "modify user form header introduction" : "A travers ce formulaire, modifier un usager existant du site.<br>Merci de pendre en compte les champs obligatoires marqués d'une étoile. <br> ",

    "modify curuser form header title"  : "Modifier mon profil: ",
    "modify curuser form header introduction" : "A travers ce formulaire, modifier mon profil.<br>Merci de pendre en compte les champs obligatoires marqués d'une étoile. <br> ",


    " cat form header title"  : "Nouvelle catégorie: ",
    " cat form header introduction" : "A travers ce formulaire, créer une nouvelle catégorie. <br>Elle sera disponible immédiatement.<br>Merci de pendre en compte les champs obligatoires marqués d'une étoile. <br> ",
    
    "modify cat form header title"  : "Modifer une catégorie: ",
    "modify cat form header introduction" : "A travers ce formulaire, modifier une catégorie. <br>Elle sera disponible immédiatement.<br>Merci de pendre en compte les champs obligatoires marqués d'une étoile. <br> ",

    " zetvu form header title"  : "Nouveau ZeTVu: ",
    " zetvu form header introduction" : "Créer un message simple, ludique et anonyme par ce ZeTvu (prononcer 'ze té vu').<br> ",
    
    "modify zetvu form header title"  : "Modifier un ZeTVu:",
    "modify zetvu form header introduction" : "A travers ce formulaire, modifier votre ZeTeVu. <br>Elle sera disponible immédiatement.<br>Merci de pendre en compte les champs obligatoires marqués d'une étoile. <br> ",


    // Formulaire de saisie d'un user
    "username"  : "Nom de login",
    "firstname"  : "Prénom",
    "lastname"  : "Nom",
    "password"  : "Mot de passe",
    "password from "  : "Mot de passe de ",
    "confirm password"  : "Mot de passe(2)",
    "more user details" : "Détails",
    "log-in details" : "Connexion",
    "user email" : "Adresse email",
    "user phone" : "Téléphone principal",
    "phone" : "Tél.",
    "location" : "Localisation",
    "user upload picture" : "Photo(s)",
    "change password"  : "Changer mot de passe",
    "retype the password to confirm" : "confirmer le mot de passe",
    
    "help email rules" : "format doit etre de type toto@service.ext",
    "help passord rules" : "doit avoir au moins 5 caractéres avec des majuscules, minuscules , chiffres, caractéres spéciaux, .. ",
    
    /* améliorations ZADS4.0 pour le formulaire User*/
    "bio and skills details" :"Bio & compétences",
    "user bio" : "Votre devise",  
    "user skills" : "Compétences",
    "skills" : "Compétences",
    "contact details" : "détails", 
    "contact actions" : "actions", 
    "selected skills" : "Vos compétences",
    "select a skills" : "Selectionnez vos compétences",
    // formulaire de saisie de compétences
    "rating_level_1" : "débutant", 
    "rating_level_2" : "amateur",
    "rating_level_3" : "amateur éclairé",
    "rating_level_4" : "semi-pro",
    "rating_level_5" : "professionnel",
    "rating please select something" : "indiquer votre niveau", 
    "add_skills" : "ajouter cette compétence",
    "remove_skill" : "supprimer",
    
    "user upload pictures" : "Images / portfolio", 
    "upload folioimg" : "ajouter une image",
    "upload filename" : "ajouter une image",    
    "user upload portofolio help %s" : "Charger des images qui serviront de portfolio a votre activité. Jusqu'a %s images.",
    
    "user upload avatar" : "Avatar", 
    "upload avatarimg" : "ajouter une photo", 
    "user upload avatar help %s" : "Charger une photo qui serviera d'avatar (format : carte d'identité 207 x 266) pour votre mini-fiche",
    
    "declare pro user" : "Professionnel",
    "type of user account" : "Type de compte", 
    "professionnal details" : "Professionnel",
    "ad company name" : "Raison Sociale", 
    //"ad siret" : "SIRET",  
    
    "ad siret" : "TVA", 

    "ad website" : "Site web",
    "link to website" : "Site web",
    "ad banner" : "Banniére", 
    "upload probannerimg" : "Ajouter une Banniére",
    "post ad banner" : "format xxx",
    "help ad banner %s" : "Charger une banniére (format : Leaderboard 728 x 90)qui sera en haut de page de votre mini-fiche",

    "user location" : "Adresse",  
    "user loczipcode" : "code postal", 
    "user loccity" : "ville", 
    "user locdept" :"department", 
    "user locregion" : "region",
    
    "usertype" : "droits",
    "registerdate" : "crée le", 
    "lastvisitdate" : "derniére visite le", 
    "id" : "identifiant",
    
    /* messages pour les conseils du checker de passwords */ 
    "shortPass" :" Trop court ! " ,   
    "badPass":" Pas assez robuste !", 
    "goodPass":" Bon !",   
    "strongPass":" Robuste !",   
    "samePassword":" identifque au login. pas bien !",  
    
    "gender"  : "Je suis ",
    "male" : "un homme", 
    "female" : "une femme",
    
    "locale"  : "Langue princip.",
    "fr_FR"  : "francais",
    "en_GB"  : "anglais (UK)",
    "en_US"  : "anglais (USA)",
    "de_DE"  : "allemand",
    "nl_NL"  : "hollandais",
    "ar_AR"  : "arabe",

    "user auth" : "Autentification", 
    "fb" : "facebook",
    "auth type fb" : "facebook",
    "auth type " : "locale",
    "content via facebook" : "via facebook", 
    "login_facebook" : "Utiliser son compte Facebook",
    "facebook login description" : "Utiliser votre compte Facebook pour autentifier sur ce site.",
    "or" : "ou",  
    "Error in FACEBOOK authentification" : "Une erreur est survenue lors de l'autentification via Facebook.",
    
    "login_google" : "Utiliser son compte Google",
    
    // formulaire pour les catégories
    "cat title"  : "Nom",
    "cat description"  : "Description de la catégorie",
    "cat upload picture" : "Photo(s)",
    "help cat title" : "nom de la catégorie", 
    "desc cat type" : "Type de catégorie", 
    
    "cattype_ad" : "pour annonces", 
    "cattype_user" : "pour usagers",
    "cattype_" : "pour tous",  
    
    "help_on_cattype cattype_" : "Cette catégorie peut servir pour des annonces ou des usagers/annonceurs.", 
    "help_on_cattype cattype_user" : "Cette catégorie peut servir pour des usagers/annonceurs", 
    "help_on_cattype cattype_ad" : "Cette catégorie peut servir pour des annonces", 
    
    // formulaire pour les zeTvu
    "<b>Je tai vu ...</b>" : "<b>Je t'ai vu ...</b>",
    "zetvu title"  : "Intro",
    "zetvu desc"  : "Message",
    "zetvu location"  : "Où ?",
    
    // input de recherche : 
    "-- search through ads --" : "-- بحث --", 
    "search" : "بحث", 
    
    // Formulaire de saisie de l'annonce
    "ad title"  : "Titre de l'annonce",
    "help title limited to 60 chars. Do not indicate buy of sell" : "60 caractères max. Ne pas indiquer ACHETE ou VEND",
    "ad description"  : "Description",
    "ad categorie"  : "Catégorie",
    "ad email"  : "Adresse Email",
    "ad sell or buy"  : "Type",
    "ad video embed" : "Video HTML code", 
    "ad video embed help" : "Entrer le code HTML de votre fournisseur de video", 
    "sell"  : "offres",
    "buy"  : "demandes",
    "ad price"  : "السعر",
    "&euro;" : "(en &#8364;) :  mettre 0 pour gratuit ou troc.",
    "$" : "(en $) :  mettre 0 pour gratuit ou troc.",
    "ad upload picture" : "Image(s)",
    "ad upload image help %s" : "Vous pouvez ajouter jusqu'a %s images. Max 500 ko par image. Extensions .jpeg, .jpg, .gif, .png",
    "cat upload image help %s" : "Vous pouvez ajouter une image qui sera utilisée pour les annonces sans image de cette catégorie. Max 500 ko par image. Extensions .jpeg, .jpg, .gif, .png",
    "zetevu upload image help %s" : "Vous pouvez ajouter une image. Max 500 ko par image. Extensions .jpeg, .jpg, .gif, .png",
    "ad details" : "Annonce",
    "ad contact me" : "Contact",
    "how to contact you for this ad" : "comment me contacter ?",
    "enable phone"  : "Téléphone",
    "show phone"  : "Téléphone",
    "show email"  : "Email",
    "show name"  : "Nom",
    "ad help enusername" : "Le nom doit être compris entre 5 et 20 caractères",
    "Show my email address together with this ad" : "afficher mon email dans l'annonce.",
    "Show my name together with this ad" : "afficher mon nom dans l'annonce.",
    "display my phone number" : "afficher mon numéro de téléphone dans l'annonce.", 
    "Information on how to see it and get it" : "Ou se trouve l'article", 
    "ad location and delivery": "Localisation",
    "ad location": "Adresse",
    "help indicate for example a zip code or town" : "format : {rue,ville,pays} ou {codepostal,pays}. Exemple : Strasbourg,FR ou 67000,FR. Pour une auto-detection de l'adresse, laisser à vide et lancer la détection",
    "help indicate format phone number" : "format canonique :+CodePays/Région(IndicatifRégional)NuméroAbonné.Exemple : +33(0)390671234",
    "Not the right file extension." : "Cette extension de fichier n'est pas supportée.", 
    "file size exceed limit." : "La taille du fichier dépasse les limites autorisées.",
    "id of article owner" :"identiant du créateur de l'article", 
    "userid" : "identifiant de l'auteur",  
    
    // title of Menu which are close to the input texts. 
    "post menu loc" : "Auto-détecter votre localisation", 
    "check this loc" : "Vérifier cette adresse", 
    
    // informations affichées lors d'une modification
    "publishing state" : "Divers",
    "Publication status" : "Divers informations sur votre annonce", 
    "ad pub date" :"Date", 
    "ad logs":"Historique", 
    "what" : "quoi?", 
    "whatid"  : "id",
    "auth"  : "auth",
    "cron"  : "automate",
    "sec"  : "systéme",
    "daily"  : "daily",
    "weekl"  : "weekly",
    "severity" : "Sev.",
    "severity_0" :"-",
    "severity_1" :"Mid",
    "severity_2" :"High",
    "Only severity 0" :"Sévérity Normale",
    "Only severity 1" :"Sévérité Moyenne",
    "Only severity 2" :"Sévérité Haute",
    "-- select one severity --" : "-- filtrer par sévérité --",
    
    "-- select one action --" : "-- filtrer par type de log --",
    "Only Life-cycle" : "historique des modifications", 
    "Only Auth" : "Connections des usagers", 
    "Only CRON" : "Automates/robots", 
    "Only SEC" : "Systéme/sécurité", 
     
    
    "I agree with the " : "J'accepte les ", 
    "Terms and Conditions" : "termes et conditions", 
    
    "mandatory" : " * ",
    
    "upload picture" : "sélectionner une image",
    
    "delete" : "supprimer",
    "submit" : "envoyer", 
    "cancel" : "annuler",
    "modify" : "modifier",
    "edit" : "modifier",
    "more actions" : "actions", 
    "no data found" : "Pas de donnée", 
    
    "ad delete"  : "effacer à vie",
    "ad supress"  : "suprimer",
    
    // dialog button and content 
     "dialog cancel"  : "annuler",
     "dialog ok"  : "je confirme",
     "ad delete dialog title"  : "Effacer un article",
     "cat delete dialog title"  : "Effacer une catégorie",
     "user delete dialog title"  : "Effacer un usager",
     "profil delete dialog title"  : "Effacer un usager",
     "curuser delete dialog title"  : "Effacer un usager",

     "Confirm delete of ad :" : "!! Attention, cette action est irréverssible !!<br>Confirmez vous l'effacement de l'article : ",
     "Confirm delete of cat :" : "!! Attention, cette action est irréverssible !!<br>Confirmez vous l'effacement de la catégorie : ",
     "Confirm delete of user :" : "!! Attention, cette action est irréverssible !!<br>Confirmez vous l'effacement de l'usager : ",
     "Confirm delete of profil :" : "!! Attention, cette action est irréverssible !!<br>Confirmez vous l'effacement de l'usager : ", 
     "Confirm delete of curuser :" : "!! Attention, cette action est irréverssible !!<br>Confirmez vous l'effacement de l'usager : ",
     
     // confirmation pour les logs 
     "Confirm deletion" : "Confirmer effacement", 
     "Please confirm deletion of all logs entries with status :" : "En cliquant, <i>je confirme</i>, les engeristrements (logs) ci-dessous seront tous supprimés de facon irreversible.",
     
     "Action in progress ..." : "Mise à jour en cours, merci de patienter ...",
    // categories 
    'select one categorie' : 'sélectionner une catégorie',
    
    "-- select one reason --" : '-- sélectionner une raison --',
    "article sold though this site" : "L'article a été vendu grace à ce site",
    "article sold through another mean" : "L'article a été vendu d'une autre maniére",
    "article no more available" : "L'article n'est plus disponible",
    "auto" : "Supression automatique",
    "1_soldthru" : "Vendu via ce site", 
    "2_soldother" : "Vendu via une autre moyen", 
    "3_notavail" : "Plus disponible", 
    
    "ad creation ongoing": "Création de l'article :",
    "zetvu creation ongoing": "Création du zetevu :",
    "user creation ongoing": "Création de l'utilisateur :",
    "cat creation ongoing": "Création de la catégorie :",
    
    "(where?)" : "Localisation ?", 
    
    "ad modification ongoing": "Modification de l'article :",
    "user modification ongoing": "Modification de l'utilisateur :",
    "curuser modification ongoing": "Modification du profil :",
    "cat modification ongoing": "Modification de la catégorie :",
    
    // erreurs sur les formulaires
    "You must select something." : "merci de sélectionner quelque chose.",
    "You must fill in something." : "merci de saisir un texte.",
    "Incorrect format." : "format de saisie incorrect.", 
    "Incorrect rule." : "format de saisie incorrect.",
    "You must accept the Terms and conditions" : "vous devez accepter les T&C ",
    "Field does not match password" : "les deux mots de passe doivent être identiques",
    "Text length exceeding limits." : "la longueur du texte dépasse la limite",
    "%s char remaining" : "reste %s caractère",
    "%s chars remaining" : "reste %s caractères", 
    "%s chars max" : "%s caractères maximum",
    "your must precise skills AND ratings." : "choisir au moins une compétence et son niveau.",
    
    // error in email formular
    "Incorrect email format" :  "format de l'email incorrect.", 
    //"Incorrect SIRET number." :  "Format SIRET incorect (14 chiffres).", 
    "Incorrect SIRET number." :  "Format TVA incorrect (BE+0+9chiffres).", 


    // options payantes : 
    
    "ad payoptions" : "Mise en avant :", 
    "post payoptions" : "Options de mise en avant pour vous démarquer !", 
    "help payoptions" : "Options de mise en avant pour vous démarquer !", 

    "desc putontopgallery" : "Mise à la une", 
    "post putontopgallery" : "Mettre mon annonce à la une pendant 7 jours", 
    "help putontopgallery" : "Mettre mon annonce à la une pendant 7 jours", 
    
    "desc pushtotop7days" :  "Remonter mon annonce", 
    "post pushtotop7days" :  "Mettre mon annonce en avant chaque jour pendant 7 jours", 
     "help pushtotop7days" :  "Mettre mon annonce en avant chaque jour pendant 7 jours", 
    
    "desc specialcolor"  :  "Encadrer mon annonce", 
    "post specialcolor"  :  "Encadrer de couleur mon annonce pour être plus visible", 
     "help specialcolor"  :  "Encadrer de couleur mon annonce pour être plus visible", 
    
    "desc addpics"  :  "Photos en plus" , 
    "post addpics"  :  "Ajouter des photos en plus" , 
    "help addpics"  :  "Ajouter des photos en plus" , 

    "desc paidvideo"  :  "Ajouter une video", 
    "post paidvideo" : "Ajouter une video via son code embedd", 
    "help paidvideo" : "Ajouter une video via son code embedd", 

    "pushtop" : "remontée",
    "pushgal" : "mise à la une",  



    // texte des boutons du formulaire
    "BTN ad NOT CREATED": "envoyer",
    "BTN ad DRAFT": "sauvegarder brouillon",
    "BTN ad DRAFT PENDING PAYMENT" : "Payer et valider", 
    "BTN ad PREVIEW": "valider",
    "BTN ad UNDER REVIEW": "soumettre pour publication",
    "BTN ad PUBLISHED": "publier",
    "BTN ad UNPUBLISHED": "retirer de la publication",
    "BTN ad DELETED": "Supprimer",
    "BTN ad REJECTED": "Rejeter",
    "BTN ad WILLEXPIRE": "Marquer expirée",
    
    "BTN cat NOT CREATED": "envoyer",
    "BTN cat DRAFT": "sauvegarder brouillon",
    "BTN cat UNDER REVIEW": "soumettre pour publication",
    "BTN cat PUBLISHED": "publier",
    "BTN cat UNPUBLISHED": "retirer de la publication",
    "BTN cat DELETED": "Supprimer",
    "BTN cat REJECTED": "Rejeter",
    "BTN cat WILLEXPIRE": "Marquer expirée",
    
    "BTN user NOT CREATED": "envoyer",
    "BTN user DRAFT": "sauvegarder brouillon",
    "BTN user DRAFT PENDING PAYMENT" : "Payer et valider", 
    "BTN user PREVIEW": "valider",
    "BTN user UNDER REVIEW": "soumettre",
    "BTN user PUBLISHED": "enregistrer",
    "BTN user UNPUBLISHED": "désenregistrer",
    "BTN user DELETED": "Supprimer",
    "BTN user REJECTED": "Rejeter",
    "BTN user WILLEXPIRE": "Forcer expiration",
    
    "BTN curuser NOT CREATED": "Envoyer",
    "BTN curuser DRAFT": "Sauvegarder brouillon",
    "BTN curuser UNDER REVIEW": "soumettre",
    "BTN curuser PUBLISHED": "Enregistrer",
    "BTN curuser UNPUBLISHED": "Suspendre",
    "BTN curuser DELETED": "Supprimer",
    "BTN curuser REJECTED": "Rejeter",
    "BTN curuser WILLEXPIRE": "Forcer expiration",
    
    
    "BTN zetvu NOT CREATED": "envoyer",
    "BTN zetvu DRAFT": "sauvegarder brouillon",
    "BTN zetvu UNDER REVIEW": "soumettre pour publication",
    "BTN zetvu PUBLISHED": "publier",
    "BTN zetvu UNPUBLISHED": "retirer de la publication",
    "BTN zetvu DELETED": "Supprimer",
    "BTN zetvu REJECTED": "Rejeter",


    "BTN banner NOT CREATED": "envoyer",
    "BTN banner DRAFT": "sauvegarder brouillon",
    "BTN banner DRAFT PENDING PAYMENT" : "Payer et valider", 
    "BTN banner PREVIEW": "valider",
    "BTN banner UNDER REVIEW": "soumettre pour publication",
    "BTN banner PUBLISHED": "publier",
    "BTN banner UNPUBLISHED": "retirer de la publication",
    "BTN banner DELETED": "Supprimer",
    "BTN banner REJECTED": "Rejeter",
    "BTN banner WILLEXPIRE": "Marquer expirée",
    
    
    
    
    "REGISTERED": "Enregistré",
    "EDITOR": "Editeur",
    "SUPER-ADMIN": "Super administrateur",
    
    "formular already exists" : "Le formulaire est déjà ouvert. Cliquez sur le bouton annuler.",
    
    // sidebar 
    "Browse all": "tout voir",
    "latest ZeTvu" : "Derniers ZeTvu", 
    "latest Tweet" : "News", 
 
    // sidebar buttons 
    "Subscribe" : "الاشتراك",
    "subscribe feed by email": "الاعلانات و الطلبات", 
    "subscribe feed": "اشترك في خدمة RSS",
    "follow us on twitter": "تابعناعلى تويتر",
    "follow us on facebook": "تابعناعلى الفيسبوك",
  
    // texte des Status possibles d'un article
    "NOT CREATED": "brouillon",
    "DRAFT": "brouillon",
    "DRAFT PENDING PAYMENT": "Paiment en attente",
    "DRAFT PAYMENT OK": "Paiment effectué",
    "UNDER REVIEW": "en cours de revue",
    "under review" : "en cours de revue",
    "PUBLISHED": "publié(e)",
    "UNPUBLISHED": "re-travail",
    "DELETED": "supprimé(e)",
    "REJECTED": "rejeté(e)",
    "WILLEXPIRE": "va expirer",
    
    // test descriptifs des LOGS 
    "create": "création",
    "update": "modification",
    "delete": "suppression",
    "updatehit": "modification",
    "updatestatus": "modification",
    "resethits" : "modification", 
    
    "desc": "description",
    "state": "état",
    "No entries in logs." : "Aucune entrée dans l'historique.",
    "No entries in payments." : "Aucune entrée dans l'historique des paiements",
    
    "log_resethits" : "mise à zero des hits", 
    "log_create_DRAFT": "Création comme brouillon",
    "log_payment_DRAFT PAYMENT OK": "Paiement réalisé avec succés", 
    "log_create_UNDER REVIEW": "Création et soumission",
    "log_create_PUBLISHED": "Création et publication",
    "log_update_DRAFT" : "Modification et sauvegarde comme brouillon",
    "log_update_DRAFT PENDING PAYMENT" : "Mise en attente de paiement",
    "log_update_UNDER REVIEW": "Modification et re-soumission pour revue",
    "log_update_PUBLISHED": "Modification et publication",
    "log_updatestatus_PUBLISHED": "Modification et publication",
    "log_update_DELETED": "Supression de la publication",
    "log_updatestatus_UNDER REVIEW" : "Soumission pour publication",
    "log_updatestatus_DELETED": "Supression de la publication",
    "log_update_UNPUBLISHED": "Retiré de la publication temporairement",
    "log_update_REJECTED": "Rejet par l'administrateur",
    "log_update_WILLEXPIRE": "Notification de l'expiration prochaine",
    "log_delete" : "Effacement définitif",
    "log_auth_Access granted , welcome !" : "acces authorisé", 
    "log_auth_incorrect LOCAL  password  - please check" : "access denied - bad password",
    "log_auth_incorrect Login name" : "access denied - bad user name",
    
    //valeur des priorités 
    "pty_normal" : "Normale",
    "pty_top" : "En tête de gondole",
    "pty_permanent" : "Permanente",
    "pty_news" : "مقال / أخبار",  
    "top" : "الأفضل",
    "most viewed" : "الأكثر مشاهدة",


    // paypal 
    "You have paid options for <b>%s %s </b>" : "Vous avez des options payantes pour un montant de <b>%s %s</b>.", 
    "Payment successful": "Paiement bien reçu !", 
    "Thanks you for your payment ! Your ad will now be submitted for approval." : "Merci pour votre paiement!. Votre annonce va être maintenant validée par notre commité éditorial avant publication.", 
    "Payment cancelled" : "Paiemement Annulé !", 
    "Your payment is cancelled. You can retrieve your ad into your dashboard." : "Votre paiement est annulé. Vous pouvez retrouver votre annonce dans votre tableau de bord pour modification.",
    "Paypal redirection ongoing" : "Nous contactons PAYPAL ...", 
    "You will be redirected to paypal for finalizing payment." : "Vous allez être redirigé vers PAYPAL pour régler la transaction.", 
    "Payment finalization"  : "Finalisation du paiement ...", 
    "Thanks you for your payment ! We are updating your order, please wait." : "Merci pour votre paiement!. Nous mettons à jour votre annonce. Merci de patienter!", 
    "paypal - This transaction does not exist or has already been processed" : "Desolé, cette transaction n'existe pas ou a déjà été reglée.",
    "paypal payment sucessfull" : "La paiement paypal a été correctement effectué",     

    // champs du log des paiements
    "paymentdate" : "date", 
    "amt" : "montant", 
    "paymentstatus" : "état",
    "transactionid" : "ID de la transaction",  

    // type comptes utilisateurs
     "protype_pri" : "Privé",
     "protype_pub" : "Public",
     "protype_pro" : "Pro",
     "protype" : "Compte",
     "private" : "Privé",
     "public" : "Public", 
     "pro" : "Professionnel",
     "help_protype" : "Un compte PRIVE est uniquement visible par vous. Les comptes PUBLIC et PRO sont visible par tout le monde.",
     

     // annonces relatives :
     "related ads " :  "annonces ", 


    // actions
    "delete all auth logs" : "Effacer tous les logs d'AUTHentification", 
    "delete all cron logs": "Effacer tous les logs ROBOTS", 
    "delete all sec logs" : "Effacer tous les logs SYSTEMS", 
    "batch actions" : "actions en masse >>",
    "help_logs_batch_actions_menu" :"Affiche le menu pour lancer des actions en masse sur ces enregistrements.",
    "help_delete_logs_auth" : "Cette action efface toutes les entrés de type authentification dans les logs",
    "help_delete_logs_auth" : "Cette action efface toutes les entrés de type authentification dans les logs", 
    "help_delete_logs_cron" : "Cette action efface toutes les entrés de type CRON/Automates dans les logs",
    "help_delete_logs_sec" : "Cette action efface toutes les entrés de type System/Securité dans les logs",    
    
    // ecran de detail d'un article 
    "ad id" : "Num article ",
    "ad status" : "Publication ",
    "ad priority" : "Priorité ",
    "ad moddate" : "تم التعديل يوم ",
    "ad publiched the" : "يوم",
    "ad hits" : "مشاهدة",
    "ad vendor info" : "البائع",
    "ad info" : "تفاصيل",
    "ad actions" : "خيارات",
    "ad admin" : "gestion de l'article",
    "ad qr code" : "Retrouver cet article",
    "ad edit" : "تحرير",
    "ad reset hits" : "reset le nr de vues", 
    "ad savefav" : "أضف الى المفضلة",
    "ad twitter" : "نشر على تويتر",
    "Share" : "نشر ... ",
    "more ... »" : "أكثر ... »",
    "share on twitter" : "نشر على تويتر",
    "share on facebook" : "نشر على الفيسبوك",
    "share on Linkedin" : "نشر على لينكدين",
    "share on Google+" : "نشر على جوجل+",
    "clip to Evernote" : "نشر على ايفرنوت",
    "bookmark this on Delicious" : "نشر على ديليسيوس",
    "ad facebook" : "نشر على الفيسبوك",
    "One article of interest" : "Une annonce sympa",
    "ad del savefav" : "حذف من المفضلة",
    "ad email it" : "ارسال الى بريد الكتروني",
    "ad print" : "طباعة",
    "ad flag it abuse" : "تبليغ عن اساءة",
    /*
    "previous ad" : "précédent",
    "next ad" : "suivant",
    "next" : "suivant",
    "previous" : "précédent",
    */
    "previous ad" : "<",
    "next ad" : ">",
    "next" : ">",
    "previous" : "<",
    
    "elem logs": "آخر ما قمت بتصفحه", 
    "Display elem logs": "فتح", 
    

    "free" : "مجانا",
    "more if registered" : "identifiez vous pour +",
    "Send a messge to the seller" : "أرسل رسالة الى البائع",
    "Contact the user through the website" : "الاتصال عن طريق الموقع", 
    "send email" : "أرسل بريد الكتروني",
    "call number" : "اتصل بالرقم",
      
    // help on buttons : 
      "title clip to Evernote" : "Capturer et se rappeler l'annonce dans Evernote",
      
    // login form title
    "You must be registered" : "يجب عليك التسجيل",
    "Login form title" : "تسجيل الدخول",
    "login form introduction": "قم بتسجيل الدخول لاضافة و ادارة اعلاناتك.",
    "register introduction": "اذا لم تكن مسجل بعد, ",
    "login_register": "قم بالتسجيل من هنا !",
    "login_lostpassword": "نسيت كلمة السر؟ ",
    "email address not known" : "البريد الالكتروني خاطئ", 
    "login": "دخول",
    "login name" : "اسم المستخدم",
    "login email" : "البريد الالكتروني",
    "login_rememberme" : "تذكرني",
    "submit login" : "دخول",
    "logout": "خروج",
    "welcome %s": "أهلا بك <strong>%s</strong> ",
    "profil": "حسابي",
    "Access granted , welcome !" : "تم تسجيل الدخول, مرحبا بك !", 
    "Correctly logout and cookies deleted" : "أنت الان غير متصل.",
    "incorrect LOCAL  password  - please check" : "فشل الدخول : كلمة مرور غير صحيحة.",
    "incorrect Login name" : "فشل الدخول : اسم المستخدم غير صحيح.",
    "Register": "تسجيل",
    "Login in progress ..." : "يتم الان تسجيل الدخول ...",
    "Loading in progress ..." : "الرجاء الانتظار قليلاً ...",
    
    // leaflet special texts
    "leaflet footer text"  : "Cette Annonce a été crée, imprimée et disponible du site de petites annonces", 
    "Select the main picture, click <a id='print' href='#'>here</a> to print and clip along the line": "Sélectionnez les images à afficher, <a id='print' href='#'>imprimez</a> et découpez suivant les pointillés. ",
    "ad leaflet print" :"Imprimer affichette", // important sans espace pour IE 
    
    // email form title
    "email lost form title" : "Réinitialiser le mot de passe", 
    "email support form title" : "Nous contacter", 
    "email feedback form title" : "Signaler un probléme", 
    "email remind form title" : "Me rappeler ce message", 
    "email contact form title" : "Contacter le vendeur", 
    "email abuse form title" : "Notifier un abus", 
    "email contactuser form title" :  "Envoyer un message à cet usager",
    
    "email lost form introduction" : "Entrer votre l'adresse email utilisée pour l'inscription. Un nouveau mot de passer sera envoyé à cette adresse.", 
    "email support form introduction" : "Utiliser ce formulaire pour nous contacter pour toutes demandes. ",
    "email feedback form introduction" : "Utiliser ce formulaire pour signaler tout soucis, amélioration ou demande de fonctionnalité.",
    "email abuse form introduction" : "Utiliser ce formulaire pour soumettre un abus identifié sur un contenu de ZADS.",
    "email contact form introduction" : "Utiliser ce formulaire pour contacter un vendeur ou répondre à une annonce.", 
    "email remind form introduction" : "Utiliser ce formulaire pour m'envoyer les détails de cette annonce.", 
    "email contactuser form introduction" : "Utiliser ce formulaire pour envoyer un message à cet utilisateur.",
    
    "your email" : "Votre email", 
    "email title" : "Objet", 
    "email description" : "Détails", 
    
    "submit lost email" : "Réinitialiser", 
    "submit support email" : "envoyer le message",
    "submit feedback email" : "envoyer la demande",  
    "submit abuse email" : "envoyer le message",
    "submit contact email" : "envoyer le message",  
    "submit remind email" : "envoyer le message", 
    "submit contactuser email" : "lui envoyer ce message",  
    
    "Confirm modification" : "Confirmer votre modification ? ", 
    "Please confirm modification to status 40 of :" : "En cliquant, <i>je confirme</i>, l'element ci-dessous sera publiée. Vous pouvez également envoyer un message à l'éditeur.",
    "Please confirm modification to status 90 of :" : "En cliquant, <i>je confirme</i>, la publication de l'element ci-dessous sera rejetée. Indiquez la raison du rejet qui sera notifiée par email à l'auteur.",
    "Please confirm modification to status 80 of :" : "En cliquant, <i>je confirme</i>, l'element ci-dessous sera supprimé de la publication.",
    "your message": "Votre message", 
    "Why ?": "Raison ?",


    "Message sending in progress" : "message en cours d'envoi ...", 
    "Message sucessufully sent !" : "Message envoyé sans problème!",
    
    "This operation is not authorized !" :  "Vous n'étes pas autorisé à faire cette opération.", 
    "You have exceeded the commercial limits : MAX AD" :  "Vous avez dépassé les limites commerciales (Nombre Max d'annonces), veuillez contacter votre administrateur.",
    "You are not authorised to access this section. You have been redirected to home page." : "Vous n'avez pas accés à cette partie du site. Vous avez été re-dirigés vers la page d'accueil.", 

    "Login in progress" : "identification en cours ...", 
    "Error in Login form" : "erreur dans la saisie",
    "incorrect Login/password" : "Erreur lors de l'autentification , identifiant ou mot de passe incorrect.",
    "Your acount is created, please login to connect : ": "Votre compte est correctement crée.",
    "Congratulation !" : "Félicitations !", 
    
    "ZADS, I want to have more information on element :" : "Votre annonce ZADS, je souhaite plus d'info sur : ",  
    "ZADS, I want to have more information" : "Je souhaiterais plus d'information sur ...",
    "ZADS, I want to have more information" : "Plus d'informations sur votre annonce ZADS ?",
    
    "user vendor info" : "Informations principales",
    "user actions" : "Outils",
    "user info" : "Divers",
    "user id" : "IDentifiant",
    "user status" : "Etat",
    "user type" : "Droits",
    "user register date" : "Créé/modifié le",
    "user last visit date" : "Dernière visite",
    "ad registration date" : "Créé le",
    "ad modification date" : "Modifié le",
    
    "contact him" : "répondre",
    "Send him a message" : "Envoyer un email",
    
    "user savefav" : "+ mes favoris",
    "user email it" : "envoyer par email",
    "user print" : "imprimer",
    "user flag it abuse" : "notifier d'un abus",
    
    "hits : %s times" : "vu %s fois", 
      
    // modal box
    "modbox close" : "fermer",
    "info" : "Information",
    "error" : "Erreur",
    "success" : "Opérations exécutée avec succès",
    "Server request timeout" : "désolé, le serveur ne repond pas ou n'est pas accessible.",
    
    // messages 
    "Action not yet available": "Cette action n'est pas encore disponible. Désolé !",
    "Yay! Everything went well!" : "Votre action/modification s'est passée avec succès !",
    "ok ad under review" : "Votre annonce est bien prise en compte. Elle sera publiée aprés revue par le comité éditorial.",
    "ok ad deleted" : "Votre annonce est effacée. Elle reste neanmoins disponible 30 jours si vous changez d'avis.",
    "ok ad published" : "Félicitations ! Votre annonce est maintenant publiée. Elle restera visible 30 jours maximum.",
    "ok user registered" : "Votre accés est maintenant crée. Vous pouvez vous identifier maintenant pour accéder au site.",
    "error in form checking" : "Le formulaire n'est pas complété correctement, merci de vérifier les champs marqués d'une erreur.",
    "Doh! Something happened : A user with this email already exist." : "Cette adresse email est deja utilisée. Merci d'en choisir une autre.",
    "Doh! Something happened : This username is not available.": "Cette nom de login est déja utilisé. Merci d'en choisir un autre.",
    // main menu
    "containing <b>%s</b> word" : "contenant le mot <span class='highlight'>%s</span>",
 
    //user menu 
    "create ad" : "أضف إعلانك", 
    "create zetvu" : "créer un ZeTvu", 
    "admin (dashboard)" : "لوحة الادارة", 
    
    // geolocatization 
    "Geo-localization successful" : "Votre localisation a été touvée : ", 
    "Selected Geo-localization successful" :  "Votre localisation choisie a été identifée : ", 
    "Geo-localization failed" : "Erreur lors de la geo-localisation : ",
    "Geoloc not available in your navigator" : "Cette fonction n'est pas disponible sur votre navigateur.",
    "Geo-localization time-out" :"Geo-localisation : pas de réponse du serveur",
    "Geo-localization permission denied":"Geo-localisation : autorisation refusée",
    "Geo-localization position unavailable":"Geo-localisation : votre position n'est pas disponible",
    "Goecoding error : "  : "Erreur lors de la geo-localisation : ", 
    "your location" : "Votre localisation",
    "Geo-localization in progress":"Geo-localisation en cours ...",
    "Geo-localization error"  : "Erreur lors de la geo-localisation",
    "Geo-localization can move marker to select other":"Vous pouvez déplacer le marqueur à l'adresse qui vous convient.",
    "Release the Marker to the desired address" : "... déposer le marqueur à l'adresse souhaitée.", 
    "getting address...":"adresse compléte en cours de détermination",
    "Error in Google Map loading. Check your internet connection." : "Chargement de GOOGLE MAP impossible. Vérifiez votre connection internet.",
    //list view
    "Sort by:" : "رتب حسب:",
    "Most recent" : "الجديد",
    "Lowest price" : "الأدنى سعرا",
    "Highest price" : "الأعلى سعرا",
    "Highest hits": "الأكثر مشاهدة",
    "Sort by price desc" : "رتب حسب أعلى سعر",
    "Sort by price asc" : "رتب حسب أدنى سعر",
    "Sort by date desc" : "رتب حسب التاريخ",
    "Sort by hits desc" : "رتب حسب الإقبال",
    "Sort by name asc" : "رتب حسب الحروف",
    "Sort by ad nb desc" : "رتب حسب رقم الاعلان",
    "Sort by whatid desc" : "رتب حسب الاسم",
    "Sort by what desc" : "رتب حسب النوع",
    
    "By " : "بواسطة ",
    "previous page" : "الصفحة السابقة",
    "next page" : "الصفحة التالية",
    "help prev" : "الصفحة السابقة",
    "help next" : "الصفحة التالية",
    
    "Ads <b>%s</b> to <b>%s</b> of <b>%s</b> ads" : "( <b>%s</b> à <b>%s</b> / <b>%s</b>)",
    "<b>%s</b>-<b>%s</b> of <b>%s</b>" : "<b>%s</b>-<b>%s</b> sur <b>%s</b>",
    
    "Back" : "الرجوع", 

    // sub-menu 
    "myads" : "اعلاناتي",
    "my_ad" : "اعلاناتي",
    "myadmin" : "حسابي",
    "my_admin" : "حسابي",
    "admin" : "الادارة",
    
    "allads" : "جميع الاعلانات",
    "all ad" : "جميع الاعلانات",
    "admin_ad" : "جميع الاعلانات",
    "admin_user" : "جميع المستخدمين",
    "allusers" : "جميع المستخدمين",
    "admin_all" :"جميع المستخدمين",
    
    "all logs" : "جميع إدخالات السجل",
    "all payments" : "جميع المدفوعات",
    "all status" : "جميع الحالات",
    "manageother" : "إدارة أخرى",
    "all cat" : "جميع الأقسام",
    "all user" : "جميع المستخدمين",
    "all admin_user" : "جميع المستخدمين",
    "all admin_cat" : "جميع الأقسام",
    
    "dashboard" : "لوحة التحكم",
    "dash no data" : "لا توجد بيانات",
    "mydashboard" : "حسابي",
    "user" : "مستخدم",
    "cat" : "أقسام", 
    "ad" : "اعلان", 
    "all myads" : "اعلاناتي",
    "all my_ad" : "جميع اعلاناتي",
    "all admin_ad" : "كل الاعلانات",
    "myads_published" : "منشورة",
    "myads_all" : "كل",
    "myads_pending" : "في الإنتظار",
    "myads_draft" : "في المسودات",
    "myads_draftpendingpayment" : "Paiements en attente",
    "myads_deleted" : "Expirée(s)",
    "published" : "publiées",
    "pending" : "en attentes",
    "willexpire" : "vont expirer",
    "draft" : "brouillons",
    "draft pending payment" : "Paiements en attente", 
    "deleted_expired" : "expirées",
    "deleted" : "expirées",
    "ads_published" : "Annonces",
    "ads_draft" : "Brouillons",
    "admin_pending" : "A valider",
    "admin_willexpire" : "Vont expirer",
    "admin_expired" : "Expirées",
    "admin_deleted" : "Expirées",
    "admin_published" : "Annonces",
    "admin_draft" : "Brouillons",
    "admin_pending" : "A valider",
    "admin_draftpendingpayment" : "Attente paiements",
    "admin_draft pending payment" : "Attente paiements", 
    "admin_willexpire" : "Vont expirer",
    "admin_expired" : "Expirées",
    "admin_rejected" : "Rejetées",
    "admin_under review" : "En cours de revue",
    "admin_user_draftpendingpayment" : "Attente paiements",
    "myprofile" : "Mon profile",
    "myfav" : "mes favoris",
    "manage_settings" : "Options",
    "manage_ads" : "Annonces (toutes)",
    "manage_users" : "Usagers",
    "manage_cats" : "Catégories",
    "manage_twitter" : "Tweeter",
    "manage_logs" : "Journal/logs",
    "manage_payments" : "Journal des Payments",
    
    "category":"Catégories",
    
    // tooltips 
    "Show List" : "Afficher sous forme de liste avec photo",
    "Show Gallery" : "Afficher sous forme de Galerie photo",
    "Show simple List" : "Afficher sous forme de liste simple",
    "Show map List" : "Afficher une carte googlemap avec les annonces localisées",
    "help_on_status DRAFT" : "Cet élément est en état brouillon et pas publié",
    "help_on_status DRAFT PENDING PAYMENT" : "Cet élément est en attente de paiement avant soumission",
    "help_on_status PUBLISHED" : "Cet élément est publié",
    "help_on_status UNDER REVIEW" : "Cet élément est en cours de revue et d'acceptation par l'éditeur",
    "help_on_status UNPUBLISHED" : "Cet élément est retiré de la publication",
    "help_on_status REJECTED" : "Cet élément a été rejeté par l'éditeur, merci de le modifier",
    "help_on_status DELETED" : "Cet élément est en archive. Il sera  effacé ",
    "help_on_status WILLEXPIRE" : "Cet élément va expirer ",
    "help_on_status pty_top" : "Cet élément est en tête de gondole",
    
    "help_on_status protype_pub" : "Ce compte est public et visible par tous",
    "help_on_status protype_pub" : "Ce compte est privé et pas visible pour des visiteurs",
    "help_on_status protype_pro" : "Ce compte est professionnel et visible pour tous",
    
    "view all" : "Voir tout",
    "help link Main List" : "Retour à la liste initiale",

    "help password rules" : "Un bon mot de passe est différent du login et contient des chiffres et des lettres. Suivez les indications !",
    
    "help_myads_published" : "Mes articles publiés",
    "help_myads_all" : "Toutes mes annonces quelque soit l'état",
    "help_myads_pending" : "Mes articles en attente de validation",
    "help_myads_draft" : "Mes articles brouillons ou rejetés",
    "help_myads_draftpendingpayment" : "Mes articles en attente de paiement",
    "help_myads_deleted" : "Mes articles expirés ou supprimés",
    "help_myprofile" : "Voir mon profil",
    "help_myfav" : "Voir mes articles favoris",
    "help_admin_pending" : "Articles à approuver",
    "help_admin_willexpire" : "Articles qui vont expirer prochainement",
    "help_admin_expired" : "Articles expirés ou supprimés",
    "help_admin_deleted" : "Articles expirés ou supprimés",
    "help_admin_draftpendingpayment" : "Articles en attente de paiement",
    "help_admin_user_draftpendingpayment" : "Comptes en attente de paiement",
    "help_manage_settings" : "Paramétres du site",
    "help_manage_ads" : "Tous les articles dans tous les états",
    "help_manage_cats" : "Gérér les catégories",
    "help_manage_users" : "Gérér les usagers",
    "help_manage_twitter" : "Envoyer des tweets directement",
    "help_dashboard" : "Accéder au tableau de bord",
    "help_mydashboard" : "Accéder à mon tableau de bord",
    "help_manage_logs" : "Afficher les journaux/logs des modifications et connections",
    "help_manage_payments" : "Afficher les paiements recus",


    "Sorry !":"Désolé !", 
    "No items found" : "Aucun élément trouvé correspondant à votre demande. Certaines demandes nécessite de s'identifier.",
    "No items found - No ad" : "Vous n'avez pas encore d'annonces", 
    
    //tweeter
    "What are you doing?" : "Quoi de neuf ?",
    "twitter header" : ": tweeter directement depuis Zads",
    "Loading your tweets..." : "chargement de vos derniers messages en cours ...",
    "Timeline" : "Fil",
    
    // global home page messages 
    "You have %s article(s) waiting for your approval" : "Vous avez %s annonce(s) qui attendent votre approbation : ", 
    "access here" : "cliquez ici pour accéder",   
    
    // templates
    "some text"  : "une traduction de patrice  from patrice",
    "some more text"  : "another translation",
    "some text in french":"avec des é et des è",
    '%s text in french %s' : '%s exemple avec printf %s', 
    '%s text in french' : '%s exemple avec printf simple', 
    '%s comment' : '%s commentaire',
    '%s comments' : '%s commentaires', 
    'text in french' : 'texte en francais',
    
    // dashboard 
    'adsnb' : 'nombre',
    '%adsnb' : '%',
    'val' : 'nombre',
    '%val' : '%',
    'metrics' : 'nombre',
    '%metrics' : '%',
    'nb' : 'nombre',
    'nbusers' : 'nombre',
    '%nbusers' : '%',
    'cattitle' : 'catégorie',
    'status' : 'état',
    'others' : 'autres',
    
    "dash manage ads" : "(voir/gérer)", 
    "dash manage users" : "(voir/gérer)",
    "dash manage cats" : "(voir/gérer)",
    "cumul users"  : "# usagers (cumul)",
    
    "a10": "brouillon",
    "a20": "en cours de revue",
    "a40": "publié(e)",
    "a60": "re-travail",
    "a80": "supprimé(e)",
    "a90": "rejeté(e)",
    "a45": "va expirer",
    
    'fb' : 'Facebook',
    
    'stat dashboard title' : 'Tableau de bord (Admin)', 
    'stat mydashboard title' : 'Mon Tableau de bord', 
    
    'top_dashboard' : 'Vue générale', 
    'ad_vol_per_cat' : 'Annonces par catégories', 
    'ad_vol_per_type' : 'Annonces par type', 
    'ad_vol_per_time' : 'Annonces dans le temps', 
    'ad_vol_per_delete' : 'Raisons de suppression annonces',
    
    'ad_vol_per_status' : 'Annonces par état de publication', 
    'user_vol_per_time' : 'Utilisateurs dans le temps', 
    'user_vol_per_age' : 'Utilisateurs par ancienneté', 
    'ad_vol_per_age' : 'Annonces par ancienneté', 
    'user_vol_per_type' : "Utilisateurs par type d'autentification",
    'user_vol_per_protype' : "Utilisateurs par profils",  
    'ad_vol_per_user' : 'Annonces par utilisateurs', 
    
    'Observation period : ' : 'Période : ', 
    'all' : 'toutes', 
    'thisyear' : 'cette année', 
    'thismonth' : 'ce mois',
    'thisquarter' : 'ce trimestre',


    // footer translation 

    // "A propos de ZADS" : "About", 
    // "ZADS est une plateforme d'échange d'annonces entre particuliers dans un domaine privé comme une entrepsie ou une collectivité." :
    //     "ZADS is a classidied ads platform available in hosted or in script mode to enable community to exchange product and services", 

    // "En savoir plus" : "Find our more", 
    // "S'abonner": "Subsribe", 
    // "Annonces par email":"Ads by email",    
    // "Offres et Demandes" : "Sell and Buy", 
    // "Aide et Support" : "Help and support", 


    // "Aide et Support" : "Help and Support", 
    // "Questions Frequentes (FAQ)" :"F.A.Q", 
    // "Tutoriels et démos" :"Demo and Tutorials", 
    // "Signaler un probléme":"Notify us on an issue", 
    // "Suivre / Contact" : "Follow / Contact",
    // "suivre ZADS.FR sur Twitter"  : "Follow us on Twitter", 
    // "suivre ZADS.FR sur Facebook"  : "Follow us on Facebook", 


    // "Me contacter" : "Contact us", 
    // "A propos" : "About this", 
    // "Infos légales et CGU"  : "Terms and Conditions", 
    // "Publicité" : "Advertising",
    // "Nous contacter" : "Contact us",
    // "Aide" :  "Help", 
    // "F.A.Q" :  "F.A.Q",  

    // new ZADS 4.6
    "around me :": "بالقرب من:", 
    ":unknown":": أين؟", 
    "(change)" : "(تغيير)",
    "(locate me)" :"(جدني)", 


    "display failed" : "خطأ", 
    "Doh! Something happened : no authorized - private profile" : "Vous n'etes pas autorisé à accéder à ces informations", 

    "post paidaccount" : "compte payants (prix par an)  : ", 
    "help_protype_paid" : "compte d'accés au site our un nombre illimité d'annonces. Prix par an. Voir conditions générales.",

    "Process ongoing ..." : "Travail en cours, veuillez patienter ...", 


    // banners management 
    "title" :"Titre",
    "htmlcode": "Code Html",
    "clicktrackingurl": "URL clicktracking", 
    "startdate": "Date de début", 
    "enddate": "Date de fin", 
    "position": "Emplacement", 
    "clicks": "Clicks", 
    "impressions": "Imp.", 
    "CTR": "CTR", 
    "resetclicks" : "Remise à zéro des compteurs clicks et impressions",

    "desc_banner_title" :"Titre",
    "desc_banner_htmlcode": "Code Html",
    "desc_banner_clicktrackingurl": "URL clicktracking", 
    "desc_banner_startdate": "Date de début", 
    "desc_banner_enddate": "Date de fin", 
    "desc_banner_position": "Emplacement", 
    "desc_banner_clicks": "Clicks", 
    "desc_banner_impressions": "Impressions", 
    "desc_banner_CTR": "CTR", 

    "help_banner_title" :"Titre de la banniére pour vous aider à l'identifier",
    "help_banner_htmlcode": "Code Html de la banniére. Dans le cas d'une banniére 'background_all', indiquez uniquement l'url de la publicité. Javascript non supporté",
    "help_banner_clicktrackingurl": "URL qui redirigera les utilisateurs lors d'un click sur la publicité", 
    "help_banner_startdate": "Date de début de publication", 
    "help_banner_enddate": "Date de fin de publication", 
    "help_banner_position": "Emplacement de la publicité sur le site", 
    "help_banner_clicks": "Nombre de clicks sur la publicité", 
    "help_banner_impressions": "Nombre d'impressions sur le site", 
    "help_banner_CTR": "CTR =  Click Trhough Ratio  =  nbr de clicks / nbr d'impressions",

    "add banner" :"ajouter une banniére publicitaire",  
    "all banners" : "Toutes les banniéres", 
    "manage_banners" : "Gestion de publicités",
    "help_manage_banners" : "Gestion de publicités",

    "Banner reset clicks confirmation" :"Confirmation remise à zéro",
    "Banner reset clicks content" : "Confirmation de la remise à zéro des compteurs clicks et impressions", 
    "Banner delete confirmation" : "Confirmation effacement définitif",  

    " banner form header title" : "Création d'une banniére publicitaire",
    " banner form header introduction" :"Ci-dessous, créer une banniére publicitaire",
    "modify banner form header title" : "Modification d'une banniére publicitaire",
    "modify banner form header introduction" :"Ci-dessous, modifier la banniére publicitaire existante",


    // extended contact form
    "contact reason" : "Demande", 
    "procpny": "Société", 
    "to email" :"Destinataire",

    '-- select one --' : '-- indiquez le type de demande --',
    "Subscription" : "Inscription", 
    "Advertising" : "Publicité", 
    "Information" :"Information", 
    "Support" :"Aide technique", 
    "Other" : "Autres demandes", 

    "Account fee is <b>%s %s </b> per year" : "L'accés au service est facturée <b>%s %s</b> par an", 

    "Please validate the location" : "Merci de valider cet emplacement",

    "top register user" : "S'inscrire", 

    // new zads 4.8 : 
    "Thanks you for your payment ! Your account is create, please login to connect" : "Merci pour votre réglement ! Votre compte est disponible.<br> Identifiez vous avec votre login et mot de passe choisi. ",
    "show all" : "Voir toutes les annonces", 
    "Sort by hierarchy" : "Trier par hiérarchie",
    "desc_parentid" : "Cat. parente", 
    "help_parentid" : "Si vous souhaitez des catégories à 2 niveaux, selectionner ici une catégorie parente. Sinon, laisser à SELECTIONNER. Uniquement 2 niveaux possibles. ", 
    "cat order plus" : "Augmenter la rang d'affichage (0=affiché en premier)",
    "cat order minus" : "Diminuer le rang d'affichage (0=affiché en premier)",

    "pub users" : "Autres annonceurs", 
    "Main list" : "retour à la liste principale", 

    // place to translate catégories 
    "Categorie initial" : "NOM DE LA CAT TRADUITE", 
    "patmisc à é é ç" : "je suis traduite",


     // ----------  new zads 4.9 : 

    "plan_step1" : "Choisir son abonnement", 

    "plan selection header title" : 
     "Vous êtes un professionnel dans le domaine de la santé ? ",
    "plan selection header line1" : 
     "Découvrez dès maintenant comment vous inscrire sur le 1er site d'annonce de la santé et optimisez au maximum votre visibilité auprès d'un grand nombre de prospect !",


    "us_protype" : "Annuaire pro",
    "us_skills"  : "Catégorie (s)",
    "us_avatarimg"  : "Logo",
    "us_bio"  : "Courte présentation",
    "us_longdesc"  : "Longue présentation",
    "us_folioimg"  : "Galerie photos",
    "us_videoembed"  : "Lien Video",
    "us_phone" : "Téléphone",
    "us_dispemail" : "Email",
    "us_subscription" : "jours acces",
    "ad_nb" : "annonces",
    "ad_nbpics" : "images",
    "ad_duration" : "",
    "ad_featured" : "",
    "ad_perm" : "",
    "ca_restricted" : "",
    "sign up" : "Signer pour ce plan",
    
    "plans_faq_1_question" : "Lorem ipsum dolor sit amet, consectetur",
    "plans_faq_1_response" : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras commodo nec elit nec sollicitudin. Aenean rutrum, magna a venenatis lobortis, lacus nisi tristique est, id euismod ante dolor vel orci. Quisque porttitor augue at fermentum ultricies.",

    "plans_faq_2_question" : "Lorem ipsum dolor sit amet, consectetur",
    "plans_faq_2_response" : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras commodo nec elit nec sollicitudin. Aenean rutrum, magna a venenatis lobortis, lacus nisi tristique est, id euismod ante dolor vel orci. Quisque porttitor augue at fermentum ultricies.",


    // nouvelles entrése du formulaire 
    "desc_label_plan" : "Type d'abonnement", 
    "desc_plan" : "Abonnement" ,
    "you selected the  plan  : " : "Vous avez choisi l'abonnement : ", 
    "help_plan" : "Ceci indique le type d'abonnement que vous avez choisi.", 
    "desc_longdesc" :"Présentation étendue",

    "longdesc" : "Présentation étendue",
    "videoembed" : "Présentation Video",

    // enhancements of zads 4.9
    "See details of this user" : "Voir la fiche détaillée de cet annonceur", 
    "See all ads from this seller" : "Voir toutes les annonces de cet annonceur", 
    "See all ads" : "Toutes ses annonces",

    // pricing type 
    "desc_pricetype" : "Prix (autres)", 
    "help_pricetype" : "Indiquez ici si vous souhaitez ou proposez un prix spécial autre que celui indiqué.", 
    "price" : "prix indiqué",
    "to be discussed" : "à discuter",
    "make an offer" : "faire offre",
    "on quote" : "sur cotation",
    "model dependant" : "dépend du modéle",

    "pricetype_tbdi" : "à discuter",
    "pricetype_mano" : "faire offre",
    "pricetype_onqo" : "sur cotation",
    "pricetype_mode" : "dépend du modéle",

    "ad videoembed" : "Video", 
    "(read more)" : "(lire la suite)",

    "Ad creation forbidden from your current profile.": "La création d'annonces n'est pas autorisée avec cet abonnement.", 
    "You have exceeded quota of ad." : "La création d'annonce n'est pas possible car vous avez dépassé les limites de votre abonnement.",

    // location based 
    "loccity" : "Ville", 
    "locdept" :"Départment", 
    "locregion" : "Région",

    // traductions pour plan princing (customer specific)
    // SELECT INPUT 
    "-- no plan -- " : "-- pas d'abonnement spécifique --", 
    "options_Basic" : "Abonnement Basic", 
    "options_Premium" : "Abonnement Premium", 
    "options_Pro" : "Abonnement Pro", 

    "more cat" : "Voir la liste compléte ...", 
    "less cat" : "... Réduire ...",


    // zads @4.9.1
    "COPYRIGHT" : "&copy; 2013-2014 ZADS",

    //Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras commodo nec elit nec sollicitudin. Aenean rutrum, magna a venenatis lobortis, lacus nisi tristique est, id euismod ante dolor vel orci. Quisque porttitor augue at fermentum ultricies. Praesent lacinia lacinia nibh semper pharetra. Maecenas justo massa, cursus nec luctus sed, varius vitae quam. Nulla odio lorem, tempus dignissim hendrerit sit amet, tincidunt eu purus. Morbi a tincidunt lorem. Nam consectetur lorem eu mi tincidunt pharetra ac non augue. Interdum et malesuada fames ac ante ipsum primis in faucibus. Morbi auctor vestibulum lacus eu rhoncus. In sagittis arcu id tortor pharetra dignissim. Nullam elementum tristique lorem in semper. Duis id risus id magna ornare rutrum. Nam non nisl rhoncus, malesuada massa ac, suscipit mi. Aenean vel tincidunt tortor. Fusce feugiat, elit quis tempor faucibus, erat erat lobortis tortor, nec vulputate tellus odio eu neque.
    // end 
    'dummy' : 'idiot'
    }; 
