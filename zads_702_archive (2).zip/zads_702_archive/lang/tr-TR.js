﻿// JavaScript Document
// french language file  version 6.2.1


if  (typeof monthnb_2_string == 'undefined')  var monthnb_2_string = []; 
if  (typeof daynb_2_string == 'undefined')  var daynb_2_string=[]; 
if  (typeof my_dictionary == 'undefined')  var my_dictionary=[]; 


 monthnb_2_string['tr_TR'] ={
  1 : "Oca.",
  2 : "Şub.", 
  3 : "Mar.",
  4 : "Nis.",
  5 : "May",
  6 : "Haz.",
  7 : "Tem.",
  8 : "Ağu.",
  9 : "Eyl.",
  10 : "Eki.",
  11 : "Kas.",
  12 : "Ara."
}

daynb_2_string['tr_TR'] ={
  0 : "Pazar",
  1 : "Pazartesi", 
  2 : "Salı",
  3 : "Çarşamba",
  4 : "Perşembe",
  5 : "Cuma",
  6 : "Cumartesi"
}



// for calendar picker 
var DPLocal = {
        days: ["Pazar", "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"],
        daysShort: ["Paz", "Pts", "Sal", "Çar", "Per", "Cum", "Cts", "Paz"],
        daysMin: ["PZ", "PT", "SL", "ÇŞ", "PŞ", "CM", "CT", "PZ"],
        months: ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasim", "Aralik"],
        monthsShort: ["Oca", "Şub", "Mar", "Nis", "May", "Haz", "Tem", "Ağu", "Sep", "Eyl", "Eki", "Kas"],
        today: "Bugün",
        clear: "Sil",
        weekStart: 1,
        format: "dd/mm/yyyy"
};


my_dictionary['tr_TR'] = { 
    // genéral dates : 
    "yesterday"  : "dün",
    "today"  : "bugün",
    "tomorrow" : "yarın",
    "%s day ago" :"%s gün önce",
    "%s days ago" :"%s gün önce",
    "till "  : "%s 'ine kadar", 
    "yes" : "Evet", 
    "no" : "Hayır", 
    
    "in %s day" :"%s günde",
    "in %s days" :"%s günde",
    "days" : "günler", 
    "day" : "gün", 
    "the" : "", 
    "the " : "",
    
    "%s ads" : "%s ilan" ,
    "%s ad" : "%s ilan" ,
    "no ad" : "ilan yok",
    
    
    "%s cats" : "%s kategori" ,
    "%s cat" : "%s kategori" , 
    
    "%s users" : "%s kullanıcı" ,
    "%s user" : "%s kullanıcı" ,
    
    "no user" : "Reklamveren  yok",
    
    // global 
    "more" : "Ayrıntılar",
    "Load more" : "Devamını yükle", 

    // offline 
    "Site is offline" : "Site Devrimdışı", 
    "Site is no more available." : "Site mevcut değil.",

    
    // general BROWSER detection messages
    "You're using IE8 or above" : "IE 8 veya üst versiyonu kullanıyorsunuz.",
    "You're using IE7.x" :  "IE 7.x'i kullanıyorsunuz",
    "You're using IE6.x" :  "IE 6.x'i kullanıyorsunuz",
    "You're using IE5.x" :  "IE 5.x'i kullanıyorsunuz",
    ': this browser is partialy supported . See the list <a href="navsupported_fr.html">here</a>' : ' : Bu tarayıcı kısmen desteklenmektedir. Listeye bakın <a href="navsupported_fr.html">ici</a>',
    
    // general navigation 
    "Main cat sell" : "İlanlar",
    "Main cat buy" : "İstekler", 
    "Main cat user" : "Reklamverenler", 
    "Zetvu" : "Zetevu",
    "my admin" : "( Hesabım )", 
 
    // boutons de creation 
    "add a cat"  : "Kategori ekle",
    "add a user"  : "Kullanıcı olustur",
    "add a sell"  : "ilanızı oluşturun",
    "add a buy"  : "ilan oluşturun",
    
    // texte d'introduction  aux formulaires 
    " ad form header title"  : "İlanım: ",
    " ad form header introduction" : "Bu formu aracılığıyla ilanızı verin. <br>ÜCRETSIZ ve yayın kurulu tarafından onaylandıktan sonra kullanılabilir. 60 gün görüntülenecektir. <br>Lütfen, bir yıldız ile işaretlenmiş zorunlu alanları dikkate alın. <br> ",
    
    "preview ad form header title"  : "İlanızı onaylayın: ",
    "preview ad form header introduction"  : "İlanızın içeriğini kontrol etikten sonra, kullanma ve yayım koşullarını kabul edin ilanızı onaylayın",
    
    
    "modify ad form header title"  : "İlanı duzenle: ",
    "modify ad form header introduction" : "Bu formu aracılığıyla ilanızı degiştirrin. <br>ÜCRETSIZ ve yayın kurulu tarafından onaylandıktan sonra kullanılabilir. 60 gün görüntülenecektir. <br>Lütfen, bir yıldız ile işaretlenmiş zorunlu alanları dikkate alın. <br>  ",


    " user form header title"  : "Kayıt olun : ",
    " user form header introduction" : "Bu formu aracılığıyla hemen kayıt olun.<br>Lütfen, bir yıldız ile işaretlenmiş zorunlu alanları dikkate alın.  ",
    " user form header introduction facebook" : "Facebook aracılığıyla'da kayıt olabilirsiniz <span class='icon-menu' id='facebook'><span class='icon'></span><a href='#' what='facebook'  name='action-on-elem' class='text'>facebook hesabınız.</a></span><br> ",

    "preview user form header title"  : "Hesabınızı onaylayın: ",
    "preview user form header introduction"  : "Hesap bilgilerinizi kontrol edin ve sitenin koşullarını kabul ettikten sonra onaylayın",
    

    "modify user form header title"  : "Kullanıcı düzenleme: ",
    "modify user form header introduction" : "Bu formu aracılığıyla varolan kullanıcıyı değiştir.<br>Lütfen, bir yıldız ile işaretlenmiş zorunlu alanları dikkate alın. <br> ",

    "modify curuser form header title"  : "Profilimi düzenle: ",
    "modify curuser form header introduction" : "Bu formu aracılığıyla profilinimi düzenle.<br>Lütfen, bir yıldız ile işaretlenmiş zorunlu alanları dikkate alın. <br> ",


    " cat form header title"  : "Yeni kategori: ",
    " cat form header introduction" : "Bu formu aracılığıyla yeni bir kategori oluşturun. <br>Hemen kullanılır durumda olacaktır.<br>Lütfen, bir yıldız ile işaretlenmiş zorunlu alanları dikkate alın. <br> ",
    
    "modify cat form header title"  : "Kategori düzenle: ",
    "modify cat form header introduction" : "Bu formu aracılığıyla bir kategoriyi düzenle. <br>Hemen kullanılır durumda olacaktır.<br>Lütfen, bir yıldız ile işaretlenmiş zorunlu alanları dikkate alın. <br> ",

    " zetvu form header title"  : "Yeni ZeTEVu: ",
    " zetvu form header introduction" : "ZETEVU tarafindan, Basit, eğlenceli ve anonim bir mesaj oluşturun.<br> ",
    
    "modify zetvu form header title"  : "Bir ZeTeVu'yü Düzenle:",
    "modify zetvu form header introduction" : "Bu formu aracılığıyla ZeTeVu'yü Düzenle. <br>Hemen kullanılır durumda olacaktır.<br>Lütfen, bir yıldız ile işaretlenmiş zorunlu alanları dikkate alın. <br> ",


    // Formulaire de saisie d'un user
    "username"  : "kullanıcı giriş adı",
    "firstname"  : "Adı",
    "lastname"  : "Soyadı",
    "password"  : "Parola",
    "password from "  : "Parola",
    "confirm password"  : "Parola(2)",
    "more user details" : "Kullanıcı ayrıntıları",
    "log-in details" : "Oturum Aç",
    "user email" : "E-posta adresiniz",
    "user phone" : "Ana telefonunuz",
    "phone" : "Tel.",
    "location" : "Konum",
    "user upload picture" : "Resim,resimler",
    "change password"  : "Parolayı değiştir",
    "retype the password to confirm" : "Parolayı onayla",
    
    "help email rules" : " Form türü, toto@service.ext biçiminde olmalı",
    "help passord rules" : "Büyük harfler, küçük harfler, sayılar, özel karakterler ile en az 5 karakter uzunluğunda olmalıdır .. ",
    
    /* améliorations ZADS4.0 pour le formulaire User*/
    "bio and skills details" :"Biyografi ve becerileri",
    "user bio" : "Sizin sloganız",  
    "user skills" : "Kullanıcı becerileri",
    "skills" : "Beceriler",
    "contact details" : "Ayrıntılar", 
    "contact actions" : "Eylemler", 
    "selected skills" : "Becerileriniz",
    "select a skills" : "Becerilerinizi seçin",
    // formulaire de saisie de compétences
    "rating_level_1" : "Acemi", 
    "rating_level_2" : "Amatör",
    "rating_level_3" : "Usta",
    "rating_level_4" : "Yari profesyonel",
    "rating_level_5" : "Profesyonel",
    "rating please select something" : "seviyenizi belirtin", 
    "add_skills" : "Bu becerinizi ekleyin",
    "remove_skill" : "Sil",
    
    "user upload pictures" : "Görüntüler / portföy", 
    "upload folioimg" : "Görüntü ekleyin",
    "upload filename" : "Görüntü ekleyin" ,    
    "user upload portofolio help %s" : "Mesleğinizi açıklamaya yardım edecek foto(görüntü) yükleyin. En fazla %s görüntü.",
    
    "user upload avatar" : "Avatar", 
    "upload avatarimg" : "Bir fotoğraf ekleyin", 
    "user upload avatar help %s" : " Mini fişinize avatar görevi yapacak %s resim yükle ",
    
    "declare pro user" : "Profesyonel",
    "type of user account" : "Hesabın türü", 
    "professionnal details" : "Ayrıntılar",
    "ad company name" : "Şirketin adı", 
    //"ad siret" : "SIRET",  
    
    "ad siret" : "SIRET", 

    "ad website" : "Web sitesi",
    "link to website" : "Web sitenin adresi",
    "ad banner" : "Afiş", 
    "upload probannerimg" : "Afiş Ekle",
    "post ad banner" : "Formu xxx",
    "help ad banner %s" : "Mini fiş üst olacak bir afiş (%s) (format : Leaderboard 728 x 90) yükleyin ",

    "user location" : "Adres",  
    "user loczipcode" : "Şehir kodu", 
    "user loccity" : "Şehir", 
    "user locdept" :"İlçe", 
    "user locregion" : "Bölge",
    
    "usertype" : "Haklar",
    "registerdate" : "Oluştulma tarihi ta rihi", 
    "lastvisitdate" : "En son ziyarettarihi", 
    "id" : "Oturum ",
    
    /* messages pour les conseils du checker de passwords */ 
    "shortPass" :"Çok kısa !" ,   
    "badPass":" Yeteri kadar emniyetli değil!", 
    "goodPass":" İyi !",   
    "strongPass":" emniyetli !",   
    "samePassword":" Giriş adı, iyi değil !",  
    
    "gender"  : "Ben ",
    "male" : "Erkek", 
    "female" : "Kadın",
    
    "locale"  : "Kullanılan Ana dili.",
    "fr_FR"  : "Fransızca",
    "en_GB"  : "İngilizce (UK)",
    "en_US"  : "İngilizce (USA)",
    "de_DE"  : "Almanca",
    "nl_NL"  : "Hollandaca",
    "ar_AR"  : "Arapça",
    "tr_TR"  : "Türkçe",

    "user auth" : "Kimlik doğrulama", 
    "fb" : "Facebook",
    "auth type fb" : "Facebook",
    "auth type " : "yerel",
    "content via facebook" : "Facebook üzerinden", 
    "login_facebook" : "Facebook hesabınızı kullanın",
    "facebook login description" : "Bu siteye kimlik doğrulaması için Facebook hesabınızı kullanın.",
    "or" : "veya",  
    " or " : "veya", 
    "Error in FACEBOOK authentification" : "Facebook üzerinden kimlik doğrulama sırasında bir hata oluştu.",
    
    "login_google" : "Google hesabınızı kullanın",
    
    // formulaire pour les catégories
    "cat title"  : "Adı",
    "cat description"  : "Kategori Açiklaması",
    "cat upload picture" : "Fotoğraf,fotoğraflar",
    "help cat title" : "Kategorinin adı", 
    "desc cat type" : "Kategori türü", 
    
    "cattype_ad" : "ilanlar için", 
    "cattype_user" : "kullanıcılar için",
    "cattype_" : "tüm'ü için",  
    
    "help_on_cattype cattype_" : "Bu kategori duyurular veya kullanıcılar / reklamverenler için kullanılabilir.", 
    "help_on_cattype cattype_user" : "Bu kategori , kullanıcılar / reklamverenler için kullanılabilir", 
    "help_on_cattype cattype_ad" : "Bu kategori, ilanlar için kullanılabilir", 
    
    // formulaire pour les zeTvu
    "<b>Je tai vu ...</b>" : "<b>Je t'ai vu ...</b>",
    "zetvu title"  : "Intro",
    "zetvu desc"  : "Mesaj",
    "zetvu location"  : "Nerede ?",
    
    // input de recherche : 
    "-- search through ads --" : "-- Ne , Nerede ? --", 
    "search" : "Arama", 
    
    // Formulaire de saisie de l'annonce
    "ad title"  : ",İlanın başlığı",
    "help title limited to 60 chars. Do not indicate buy of sell" : "60 karakter maksimum . Satın veya satılık anlamına gelen kelimeler yazmayın",
    "ad description"  : "Açıklama",
    "ad categorie"  : "Kategori",
    "ad email"  : "E-posta adresi",
    "ad sell or buy"  : "Tip",
    "ad video embed" : "Video HTML kodu", 
    "ad video embed help" : "Video sağlayıcınız HTML kodunu girin . Örnek, YOUTUBE girin , PAYLAS menünün altındaki kodu bu alana kopyala.", 
    "sell"  : "Satılanlar",
    "buy"  : "İstekler",
    "ad price"  : "Fiyat",
    "&euro;" : "(en &#8364;) :  mettre 0 pour gratuit ou troc.",
    "$" : "(en $) :  Ücretsiz  veya takas için 0 yaz.",
    "ad upload picture" : "Resim",
    "ad upload image help %s" : " %s görüntüye kadar ekleyebilirsiniz. Maksimum 500kb foto başına. Kabul olan uzantılar .jpeg, .jpg, .gif, .png",
    "cat upload image help %s" : "Bu kategorideki resimsiz ilanlar için %s resim ekleyebilirsiniz. Resim başına max 500 KB. Kabul olan uzantılar .jpeg, .jpg, .gif, .png. g",
    "zetevu upload image help %s" : "Bir resim ekleyebilirsiniz . Resim başına Max 500 kb. Kabul olan uzantılar .jpeg, .jpg, .gif, .png",
    "ad details" : "İlan",
    "ad contact me" : "İletişim",
    "how to contact you for this ad" : "Benimle nasıl iletişim kurarsın?",
    "enable phone"  : "Telefon",
    "show phone"  : "Telefon",
    "show email"  : "E-posta",
    "show name"  : "Adı",
    "ad help enusername" : "İsim 5 ile 20 karakter arasında olmalıdır",
    "Show my email address together with this ad" : " İlanda e-posta'mı görüntüle.",
    "Show my name together with this ad" : "İlanda Adımı görüntüle.",
    "display my phone number" : "İlanda telefon numaramı görüntüle.", 
    "Information on how to see it and get it" : "Ürün nerede bulunuyor", 
    "ad location and delivery": "Konum",
    "ad location": "Adres",
    "help indicate for example a zip code or town" : "biçim: {cadde, şehir, ülke} veya {PostaKodu, ülke}. Örnek: Strazburg, FR veya 67000, FR. Adresi Otomatik algılama için boş bırakın ve algılamayı başlatın",
    "help indicate format phone number" : "kurallı biçim: + ülke (AlanKodu)/bölge adı Abonenin numarası.örnek: + 33(0)390671234",
    "Not the right file extension." : "Bu dosya uzantısı desteklenmiyor.", 
    "file size exceed limit." : "Dosyanın boyutu geçerli limiti aşıyor.",
    "id of article owner" :"İlanın sahibinin kimliği", 
    "userid" : "/'yazarın kimliği",  
    
    // title of Menu which are close to the input texts. 
    "post menu loc" : "Otomatik algılama", 
    "check this loc" : "Bu adresi kontrol edin", 
    
    // informations affichées lors d'une modification
    "publishing state" : "Diger çeşitler",
    "Publication status" : "İlan hakkında çeşitli bilgiler", 
    "ad pub date" :"Tarih", 
    "ad logs":"Geçmişi", 
    "what" : "Ne?", 
    "whatid"  : "kimlik",
    "auth"  : "Kimlik Doğrulama",
    "cron"  : "otomat",
    "sec"  : "Sistem",
    "daily"  : "günlük",
    "weekl"  : "Haftalık",
    "severity" : "Önem.",
    "severity_0" :"-",
    "severity_1" :"Orta",
    "severity_2" :"Yüksek",
    "Only severity 0" :"Normal önem",
    "Only severity 1" :"Orta Önem",
    "Only severity 2" :"Yüksek önem",
    "-- select one severity --" : "-- Önem derecesine göre filtrele --",
    
    "-- select one action --" : "-- günlük türüne göre filtre --",
    "Only Life-cycle" : "Değişikliklerin geçmişi", 
    "Only Auth" : "Kullanıcıların bağlantıları, siteye girişleri", 
    "Only CRON" : "Otomatizm/robotlar", 
    "Only SEC" : "Sistem/Güvenlik", 
     
    
    "I agree with the " : "Kabul ediyorum ", 
    "Terms and Conditions" : "şartlar ve koşullar", 
    "I accept the tandc" : "Şartları kabul ediyorum ...", 
    "By clicking the confirm button, " : "<b> düğmesine tıkladığımda,</b> onaylıyorum,  ",
    
    
    "mandatory" : " * ",
    
    "upload picture" : "Bir Resim(görüntü) seç",
    
    "delete" : "Sil",
    "submit" : "Gönder", 
    "cancel" : "İptal et",
    "modify" : "Düzenle",
    "edit" : "Düzenle",
    "more actions" : "¨Daha fazla aksiyon", 
    "no data found" : "Veri bulunamadı", 
    
    "ad delete"  : "Ömür boyu sil",
    "ad supress"  : "Sil",
    
    // dialog button and content 
     "dialog cancel"  : "iptal et",
     "dialog ok"  : "Onaylıyorum",
     "ad delete dialog title"  : " Bir ilanı sil",
     "cat delete dialog title"  : "Bir kategoriyi sil",
     "user delete dialog title"  : "Kullanıcıyı sil",
     "profil delete dialog title"  : "Kullanıcıyı sil",
     "curuser delete dialog title"  : "Kullanıcıyı sil",

     "Confirm delete of ad :" : "!! Dikkat Bu seçenekten geri dönülemez !!<br> Ürünün silinmesini onaylıyormusun ? ",
     "Confirm delete of cat :" : "!! Dikkat Bu seçenekten geri dönülemez !!<br> Kategorinin silinmesini onaylıyormusun ? : ",
     "Confirm delete of user :" : "!! Dikkat Bu seçenekten geri dönülemez !!<br> Kullanıcının silinmesini onaylıyormusun ? ",
     "Confirm delete of profil :" : "!! Dikkat Bu seçenekten geri dönülemez !!<br> Kullanıcının silinmesini onaylıyormusun ? ", 
     "Confirm delete of curuser :" : "!! Dikkat Bu seçenekten geri dönülemez !!<br> Kullanıcının silinmesini onaylıyormusun ? ",
     
     // confirmation pour les logs 
     "Confirm deletion" : "Silmeyi onayla", 
     "Please confirm deletion of all logs entries with status :" : "<i>onaylıyorum<i>Üzerine tıklayarak aşağıdaki kayıtlar tümü silinecektir  . Dikkat geri dönülemez !!",
     
     "Action in progress ..." : "Güncelleniyor..., lütfen bekleyin ",
    // categories 
    'select one categorie' : 'Bir kategori seçin',
    
    "-- select one reason --" : '-- Bir sebep seçin --',
    "article sold though this site" : "Ürün  bu web sitesi aracılığıyla satılmıştır",
    "article sold through another mean" : "Ürün farklı bir şekilde satıldı",
    "article no more available" : "Ürün artık mevcut değil",
    "auto" : "Ürün artık mevcut değil",
    "1_soldthru" : "Bu web sitesi aracılığıyla satıldı", 
    "2_soldother" : "Diğer yollarla satıldı", 
    "3_notavail" : "Mevcut değil", 
    
    "ad creation ongoing": "Ürün oluşturma :",
    "zetvu creation ongoing": "Zetevu oluşturma :",
    "user creation ongoing": "Kullanıcı oluşturma :",
    "cat creation ongoing": "Kategori oluşturma :",
    
    "(where?)" : "Konum ?", 
    
    "ad modification ongoing": "Eşyanın değiştirilmesi :",
    "user modification ongoing": "Kullanıcının değiştirilmesi :",
    "curuser modification ongoing": "Profilin değiştirilmesi :",
    "cat modification ongoing": "kategorinin değiştirilmesi :",
    
    // erreurs sur les formulaires
    "You must select something." : "Lütfen bir şey seçin.",
    "You must fill in something." : "Lütfen metni girin.",
    "Incorrect format." : "Hatalı giriş.", 
    "Incorrect rule." : "Hatalı giriş.",
    "You must accept the Terms and conditions" : "Şartları ve koşulları kabul etmelisiniz  ",
    "Field does not match password" : "iki parola aynı olmalıdır",
    "Text length exceeding limits." : "Metin uzunluğu sınırı aşıyor",
    "%s char remaining" : "%s karakter kaldı",
    "%s chars remaining" : "%s karakter kaldı", 
    "%s chars max" : "%s  karakter maksimum",
    "your must precise skills AND ratings." : "En az bir beceri ve düzeyini seçin.",
    
    // error in email formular
    "Incorrect email format" :  "e-posta biçimi yanlış.", 
    //"Incorrect SIRET number." :  "SIRET biçimi yanlış (14 basamaklı).", 
    "Incorrect SIRET number." :  "SIRET biçimi yanlış (14 basamaklı)", 

    // options payantes : 
    
    "ad payoptions" : "ön plana çıkarma :", 
    "post payoptions" : "Sizi daha iyi görmek için,öne çıkarma seçenekleri !", 
    "help payoptions" : "Sizi daha iyi görmek için,öne çıkarma seçenekleri !", 

    // "desc putontopgallery" : "İlk sıralara koyma", 
    // "help putontopgallery" : "reklamımı 7 gün süreyle başa (ilk saralara) koyma", 
    
    // "desc pushtotop7days" :  "Reklamımı günceleyerek öne çıkar", 
    // "post pushtotop7days" :  "Reklamımı 7 gün süreyle günceleyerek öne çıkar", 
    //  "help pushtotop7days" :  "Reklamımı 7 gün süreyle günceleyerek öne çıkar", 
    
    // "desc pushtotop30days" :  "Reklamımı günceleyerek öne çıkar", 
    // "post pushtotop30days" :  "Reklamımı 30 gün süreyle günceleyerek öne çıkar", 
    // "help pushtotop30days" :  "Reklamımı 30 gün süreyle günceleyerek öne çıkar", 
    

    // "desc specialcolor"  :  "İlanı çerçevelemek", 
    // "post specialcolor"  :  "Daha iyi görünür olması için ilanı çerçevelemek", 
    //  "help specialcolor"  :  "Daha iyi görünür olması için ilanı çerçevelemek", 
    
    "desc_addpics"  :  "Ek Fotoğraflar" , 
    "post addpics"  :  "Ek Fotoğraflar indir" , 
    "help addpics"  :  "Ek Fotoğraflar indir" , 

    "desc_paidvideo"  :  "Video ekle", 
    "post paidvideo" : "Embedd Kod yoluyla bir video ekle", 
    "help paidvideo" : "Embedd Kod yoluyla bir video ekle", 

    "pushtop" : "İleri çıkarma",
    "pushtop30" : "30 gün ileri çıkarma",
    "pushgal" : "İlk sıralara koyma",  


    // texte des boutons du formulaire
    "BTN ad NOT CREATED": "Gönder",
    "BTN ad DRAFT": "Taslağı kaydet",
    "BTN ad DRAFT PENDING PAYMENT" : "Ödemek ve onaylamak", 
    "BTN ad PREVIEW": "onaylamak",
    "BTN ad UNDER REVIEW": "yayınlanması için teslim etmek",
    "BTN ad PUBLISHED": "/Yayınlamak",
    "BTN ad UNPUBLISHED": "Yayından çekmek",
    "BTN ad DELETED": "Sil",
    "BTN ad REJECTED": "Red edildi",
    "BTN ad WILLEXPIRE": "İlanın zamanı doldu",
    "BTN ad REACTIVATE": "ilanı yeniden aktif hale getirmek",
    
    "BTN cat NOT CREATED": "Gönder",
    "BTN cat DRAFT": "Taslağı kaydet",
    "BTN cat UNDER REVIEW": "yayınlanması için teslim etmek",
    "BTN cat PUBLISHED": "Yayınlamak",
    "BTN cat UNPUBLISHED": "Yayından çekmek",
    "BTN cat DELETED": "Sil",
    "BTN cat REJECTED": "Red edildi",
    "BTN cat WILLEXPIRE": "İlanın zamanı doldu",
    
    "BTN user NOT CREATED": "Gönder",
    "BTN user DRAFT": "Taslağı kaydet",
    "BTN user DRAFT PENDING PAYMENT" : "Ödemek ve onaylamak", 
    "BTN user PREVIEW": "onaylamak",
    "BTN user UNDER REVIEW": "yayınlanması için teslim etmek",
    "BTN user PUBLISHED": "Yayınlamak",
    "BTN user UNPUBLISHED": "Yayından çekmek",
    "BTN user DELETED": "Sil",
    "BTN user REJECTED": "Red edildi",
    "BTN user WILLEXPIRE": "İlanın zamanı doldu",
    
    "BTN curuser NOT CREATED": "Gönder",
    "BTN curuser DRAFT": "Taslağı kaydet",
    "BTN curuser UNDER REVIEW": "yayınlanması için teslim etmek",
    "BTN curuser PUBLISHED": "Yayınlamak",
    "BTN curuser UNPUBLISHED": "Yayından çekmek",
    "BTN curuser DELETED": "Sil",
    "BTN curuser REJECTED": "Red edildi",
    "BTN curuser WILLEXPIRE": "İlanın zamanı doldu",
    
    
    "BTN zetvu NOT CREATED": "Gönder",
    "BTN zetvu DRAFT": "Taslağı kaydet",
    "BTN zetvu UNDER REVIEW": "yayınlanması için teslim etmek",
    "BTN zetvu PUBLISHED": "Yayınlamak",
    "BTN zetvu UNPUBLISHED": "Yayından çekmek",
    "BTN zetvu DELETED": "Sil",
    "BTN zetvu REJECTED": "Red edildi",
    "BTN zetvu WILLEXPIRE": "İlanın zamanı doldu",


    "BTN banner NOT CREATED": "Gönder",
    "BTN banner DRAFT": "Taslağı kaydet",
    "BTN banner DRAFT PENDING PAYMENT" : "Ödemek ve onaylamak", 
    "BTN banner PREVIEW": "onaylamak",
    "BTN banner UNDER REVIEW": "yayınlanması için teslim etmek",
    "BTN banner PUBLISHED": "Yayınlamak",
    "BTN banner UNPUBLISHED": "Yayından çekmek",
    "BTN banner DELETED": "Sil",
    "BTN banner REJECTED": "Red edildi",
    "BTN banner WILLEXPIRE": "İlanın zamanı doldu",


    "BTN bookings NOT CREATED": "Gönder",
    "BTN bookings DRAFT": "Taslağı kaydet",
    "BTN bookings DRAFT PENDING PAYMENT" : "Ödemek ve onaylamak", 
    "BTN bookings UNDER REVIEW": "yayınlanması için teslim etmek",
    "BTN bookings PUBLISHED": "Yayınlamak",
    "BTN bookings UNPUBLISHED": "Yayından çekmek",
    "BTN bookings DELETED": "Sil",
    "BTN bookings REJECTED": "Red edildi",
    "BTN bookings WILLEXPIRE": "İlanın zamanı doldu",
    

    "REGISTERED": "Kaydedildi",
    "EDITOR": "Editör",
    "SUPER-ADMIN": "Super administratör",
    
    "formular already exists" : "Form zaten açık,İptal düğmeye basın.",
    
    // sidebar 
    "Browse all": "Hepsini görmek",
    "latest ZeTvu" : "Son ZETEVU", 
    "latest Tweet" : "Yeni", 
 
    // sidebar buttons 
    "Subscribe" : "Abone olmak",
    "subscribe feed by email": "E-posta ile teklifler", 
    "subscribe feed": "RSS akışına abone ol",
    "follow us on twitter": "Twitter'den takip et",
    "follow us on facebook": "Facebook'dan takip et",
  
    // texte des Status possibles d'un article
    "NOT CREATED": "Taslak",
    "DRAFT": "Taslak",
    "DRAFT PENDING PAYMENT": "Ödeme bekleniyor",
    "DRAFT PAYMENT OK": "Ödeme yapıldı",
    "UNDER REVIEW": "Gözden geçirilmede",
    "under review" : "Gözden geçirilmede",
    "PUBLISHED": "Yayınlanan",
    "UNPUBLISHED": "yeniden çalışılan ilan",
    "DELETED": "Silinen",
    "REJECTED": "reddedilen ",
    "WILLEXPIRE": "sona erecek",



    // short version for admin pages 
    "SHORT NOT CREATED": "00",
    "SHORT DRAFT": "draf",
    "SHORT DRAFT PENDING PAYMENT": "payp",
    "SHORT DRAFT PAYMENT OK": "payok",
    "SHORT UNDER REVIEW": "review",
    "SHORT under review" : "review",
    "SHORT PUBLISHED": "pub",
    "SHORT UNPUBLISHED": "un-pub",
    "SHORT DELETED": "supp",
    "SHORT REJECTED": "rejec",
    "SHORT WILLEXPIRE": "willexp",

    
    // test descriptifs des LOGS 
    "create": "Oluşturma",
    "update": "Düzenleme",
    "delete": "silmek",
    "updatehit": "Düzenleme",
    "updatestatus": "Düzenleme",
    "resethits" : "Düzenleme", 
    
    "desc": "Tanımlamak",
    "state": "Durum",
    "No entries in logs." : "Geriye dönük hiç bir giriş yok.",
    "No entries in payments." : "Geriye dönük ödemelerde hiç giriş  yok",
    
    "log_resethits" : "Hits'leri sıfırla", 
    "log_create_DRAFT": "Taslak biçimde oluşturmak",
    "log_payment_DRAFT PAYMENT OK": "Ödeme başarı ile gerçekleşti", 
    "log_create_UNDER REVIEW": "Oluşturmak ve ilgili bölüme sunmakn",
    "log_create_PUBLISHED": "Oluşturmak ve yayınlamak",
    "log_update_DRAFT" : "Taslak biçiminde saklamak için düzenlemek ve kayıt etmek",
    "log_update_DRAFT PENDING PAYMENT" : "Ödeme için beklemeye alındı",
    "log_update_UNDER REVIEW": "Düzenleme ve yeniden gözden geçirilmesi için göndermek",
    "log_update_PUBLISHED": "Düzenleme ve yayınlama",
    "log_updatestatus_PUBLISHED": "Düzenleme ve yayınlama",
    "log_update_DELETED": "Yayından kaldırmak",
    "log_updatestatus_UNDER REVIEW" : "Yayınlanmak için teslim etmek",
    "log_updatestatus_DELETED": "Yayından kaldırmak",
    "log_update_UNPUBLISHED": "Geçici olarak yayından kaldırıldı",
    "log_update_REJECTED": "Yönetici tarafından reddedildi",
    "log_update_WILLEXPIRE": "Bitiş tarihi bildirimi",
    "log_delete" : "Süresiz silmek",
    "log_auth_Access granted , welcome !" : "Erişim kabul", 
    "log_auth_incorrect LOCAL  password  - please check" : "Yanlış parola",
    "log_auth_incorrect Login name" : "Yanlış kullanıcı",
    
    //valeur des priorités 
    "pty_normal" : "Normal",
    "pty_top" : "Gondolun başında",
    "pty_permanent" : "devamlı",
    "pty_news" : "Ürün/Yeni",  
    "top" : "önde",
    "most viewed" : "En çok ziyaret edilenler",


    // paypal 
    "You have paid options for <b>%s %s %s </b>" : "<b>%s %s</b> %s miktarda ücretli opsyon çeşiliriniz var.", 
    "Payment successful": "Ödeme yapıldı!", 
    "Thanks you for your payment ! Your ad will now be submitted for approval." : "Ödemeniz için teşekkürler, ilanız yayınlamadan önce editör ekibimiz tarafından onaylanacaktır", 
    "Thanks you for your payment ! Your ad is now published." : " Ödemeniz için teşekkürler,ilanız yayınlandı.", 
    "Payment cancelled" : "Ödeme iptal edildi !", 
    "Your payment is cancelled. You can retrieve your ad into your dashboard." : "Ödemeniz iptal edildi,ilanızı dashboard'a bulabilirsiniz.",
    "Paypal redirection ongoing" : "PAYPAL'a bağlanıyoruz....", 
    "You will be redirected to paypal for finalizing payment." : "Ödemeyi yapmanız için PAYPAL'a yönlendirileceksiniz", 
    "Payment finalization"  : "Ödemenin son aşamasına geliniyor....", 
    "Thanks you for your payment ! We are updating your order, please wait." : "Ödemeniz için teşekkürler,ilanız güncelleniyor,sabrınız için teşekkürler!", 
    "paypal - This transaction does not exist or has already been processed" : "Üzgünüz böyle bir ödeme yok veya ödeme daha önce yapılmıştır.",
    "paypal payment sucessfull" : "PAYPAL ödemeniz başarıyla gerçekleştirildi", 
    "Payment finalization ongoing" : "Lütfen bekleyin, ödemeniz yapılıyor ...",     

    // champs du log des paiements
    "paymentdate" : "Tarih", 
    "amt" : "Ücret", 
    "paymentstatus" : "Durum",
    "transactionid" : "ödemenin kodu",  

    // type comptes utilisateurs
     "protype_pri" : "Özel",
     "protype_pub" : "Kamu",
     "protype_pro" : "Profesyonel",
     "protype_par" : "Özel kişi", 
     "protype" : "Hesap",
     "private" : "Özel",
     "public" : "Kamu", 
     "pro" : "Profesyonel",
     "par" : "Özel kişi", 
     "help_protype" : "Profesyonel mi özel kişimi olduğunuzu belirtin",
     "desc_indir" : "Görünür rehber", 
     "help_indir" : "Sitenin rehberinde görünmenize izin verir", 
     "desc_account_type" :"Hesap türü", 

     // annonces relatives :
     "related ads " :  "ilan ", 


    // actions
    "delete all auth logs" : "Effacer tous les logs d'AUTHentification", 
    "delete all cron logs": "Effacer tous les logs ROBOTS", 
    "delete all sec logs" : "Effacer tous les logs SYSTEMS", 
    "batch actions" : "actions en masse >>",
    "help_logs_batch_actions_menu" :"Affiche le menu pour lancer des actions en masse sur ces enregistrements.",
    "help_delete_logs_auth" : "Cette action efface toutes les entrés de type authentification dans les logs",
    "help_delete_logs_auth" : "Cette action efface toutes les entrés de type authentification dans les logs", 
    "help_delete_logs_cron" : "Cette action efface toutes les entrés de type CRON/Automates dans les logs",
    "help_delete_logs_sec" : "Cette action efface toutes les entrés de type System/Securité dans les logs",    
    
    // ecran de detail d'un article 
    "ad id" : "Ürün Num",
    "ad status" : "Yayınlama ",
    "ad priority" : "Öncelik ",
    "ad moddate" : "Değiştirilme tarihi ",
    "ad publiched the" : "le",
    "ad hits" : "Görünüm ",
    "ad vendor info" : "Yazan",
    "ad info" : "Ayrıntılar",
    "ad actions" : "Eylemler",
    "ad admin" : "Ürün yönetimi",
    "ad qr code" : "Bu Ürün'ü bul",
    "ad edit" : "Düzenle",
    "ad reset hits" : "Görüntü sayısını Sıfırla", 
    "ad savefav" : "Favorilere ekle",
    "ad twitter" : "Twitter üzerinden paylaş",
    "Share" : "Paylaşmak ... ",
    "more ..." : "çok ...",
    "less ..." : "az ...",
    "share on twitter" : "Twitter ile paylaş",
    "share on facebook" : "Facebook ile paylaş",
    "share on Linkedin" : "Linkedin ile paylaş",
    "share on Google+" : "/Google+ ile paylaş",
    "clip to Evernote" : "Evernote ile klips",
    "bookmark this on Delicious" : "Delicious ile bağlayın",
    "ad facebook" : "Facebook'da paylaş",
    "One article of interest" : "ilgi çeken ürün",
    "ad del savefav" : "favorilerden çıkar",
    "ad email it" : "E-posta ile gönder",
    "ad print" : "Yazdır",
    "ad flag it abuse" : "kötüye kullanımı bildir",
    /*
    "previous ad" : "önceki",
    "next ad" : "sonraki",
    "next" : "sonraki",
    "previous" : "önceki",
    */
    "previous ad" : "<",
    "next ad" : ">",
    "next" : ">",
    "previous" : "<",
    
    "elem logs": "Geçmiş", 
    "Display elem logs": "Geçmişi görüntüleme", 
    

    "free" : "Bedava",
    "more if registered" : "Fazla için kendinizi tanıtın",
    "Send a messge to the seller" : "Satıcıya mesaj gönder",
    "Contact the user through the website" : "Web sitesi üzerinden ulaşın", 
    "send email" : "Ona Email gönder",
    "call number" : "Bu numarayı ara",
      
    // help on buttons : 
    "title clip to Evernote" : "Evernote içindeki duyuruyu yakalamak ve hatırlamak",
      
    // login form title
    "You must be registered" : "Bu eylem için kimliğinizi tanımlamanız ve kaydetmeniz lazım.",
    "Login form title" : "Tanımlama",
    "login form introduction": "İlanlara girmek,ilan oluşturmak veya ilanları yönetmek için kendinizi tanımlayın",
    "register introduction": "Henüz kaydolmadıysanız, ",
    "login_register": "burada kaydolun !",
    "login_lostpassword": "Parolanızı kaybettiysen tıkla? ",
    "email address not known" : "Bu E-posta adresi tanınmıyor", 
    "login": "Giriş yap",
    "login name" : "Kullanıcı adı",
    "login email" : "E-posta",
    "login_rememberme" : "Beni hatırla",
    "submit login" : "Bağlanmak",
    "logout": "Çıkış",
    "welcome %s": "Merhaba <strong>%s</strong> ",
    "profil": "Profilim",
    "Access granted , welcome !" : "Erişime izin verildi, hoş geldiniz !", 
    "Correctly logout and cookies deleted" : "Artık bağlı değilsiniz.",
    "incorrect LOCAL  password  - please check" : "Kimlik doğrulaması başarısız oldu: yanlış şifre.",
    "incorrect Login name" : "Kimlik doğrulaması başarısız oldu: kullanıcı adı tanınmadı.",
    "Register": "Kayıt ol",
    "Login in progress ..." : "Kimlik doğrulama devam ediyor ...",
    "Loading in progress ..." : "Yükleniyor ...",
    
    // leaflet special texts
    "leaflet footer text"  : "Bu ilan oluşturuldu, yazdırıldı ve seri ilan sitesinde  kullanılabilir halde.", 
    "Select the main picture, click <a id='print' href='#'>here</a> to print and clip along the line": "Gösterilecek fotoğrafları seçiniz, <a id='print' href='#' nottip='yes' >yazdır</a> ve noktalı çizgileri takip ederek kesin. ",
    "ad leaflet print" :"Flyer'i Yazdır", // important sans espace pour IE 
    
    // email form title
    "email lost form title" : "Parolayı yeniden yenile", 
    "email support form title" : "Bize ulaşın", 
    "email feedback form title" : "Sorun bildir", 
    "email remind form title" : "Bu mesajı bana hatırlat", 
    "email contact form title" : "Satıcıyla iletişim kurun", 
    "email abuse form title" : "Kötüye kullanımı bildir", 
    "email contactuser form title" :  "Bu kullanıcıya bir mesaj gönderin",
    
    "email lost form introduction" : "Kayıt için kullanılan e-posta adresinizi girin. Yeni parola bu adrese gönderilecektir.", 
    "email support form introduction" : "Tüm istekleri bize ulaştırmak için bu formu kullanın. ",
    "email feedback form introduction" : "Herhangi bir sorun, geliştirme veya özellik isteği bildirmek için bu formu kullanın.",
    "email abuse form introduction" : "Bir içerikte saptanan kötü kullanımı bildirmek için bu formu kullanın .",
    "email contact form introduction" : "Bir satıcıya baş vurmak veya bir reklam için yanıt vermek için bu formu kullanın..", 
    "email remind form introduction" : "Bu kullanıcıya Reklamın  ayrıntılarını göndermek için bu formu kullanın.", 
    "email contactuser form introduction" : "Bu kullanıcıya bir ileti veya mesaj göndermek için bu formu kullanın.",
    
    "your email" : "E-postanız", 
    "email title" : "Konu", 
    "email description" : "Ayrıntılar", 
    
    "submit lost email" : "Sıfırla,yeniden adlandır", 
    "submit support email" : "Mesaj'i gönderin",
    "submit feedback email" : "İsteği gönderin",  
    "submit abuse email" : "Mesaj'i gönderin",
    "submit contact email" : "Mesaj'i gönderin",  
    "submit remind email" : "Mesaj'i gönderin", 
    "submit contactuser email" : "Ona bu mesajı gönderin",  
    
    "Confirm modification" : "Değişikliklerinizi doğrulayın ? ", 
    "Please confirm modification to status 40 of :" : "<i>Onayla</i> tıklayarak, aşağıda ilan yayınlanacaktır. Editöre bir mesaj gönderebilirsiniz.",
    "Please confirm modification to status 90 of :" : "<i>Onayla</i> tıklayarak, aşağıda ilan reddedilecektir. Ret nedeni belirtin ver e-posta ile bildirin.",
    "Please confirm modification to status 80 of :" : "<i>Onayla</i> tıklayarak, aşağıda ilan yayından kaldırılacaktır.",
    "your message": "Mesajınız", 
    "Why ?": "Neden?",


    "Message sending in progress" : "Mesaj gönderiliyor...", 
    "Message sucessufully sent !" : "Mesaj hatasız gönderildi!",
    
    "This operation is not authorized !" :  "Bu işlemi yapmak için izniniz yok", 
    "You have exceeded the commercial limits : MAX AD" :  "Ticari limitler (reklamları Max sayı) aştınız, yöneticinize/Admnistratöre başvurun..",
    "You are not authorised to access this section. You have been redirected to home page." : "Sitenin bu bölümüne erişiminiz yok. Giriş sayfasına yönlendirileceksiniz.", 

    "Login in progress" : "Kimlik doğrulama yapılıyor ...", 
    "Error in Login form" : "Giriş formunda hata",
    "incorrect Login/password" : "Kimlik doğrulaması sırasında hata oluştu, kullanıcı adı veya yanlış parola.",
    "Your acount is created, please login to connect : ": "Hesabınız başarıyla oluşturuldu.",
    "Congratulation !" : "Bravo !", 
    
    "ZADS, I want to have more information on element :" : "İlannınız hakkında daha fazla bilgi istiyorum : ",  
    "ZADS, I want to have more information" : "...hakkında daha fazla bilgi istiyorum",
    "ZADS, I want to have more information" : "İlannınız hakkında daha fazla bilgiler  ?",
    
    "user vendor info" : "Önemli bilgiler",
    "user actions" : "Araçlar",
    "user info" : "Diğer",
    "user id" : "Kimlik",
    "user status" : "Durum",
    "user type" : "Haklar",
    "user register date" : "Tarihinde oluşturuldu/değiştirildi",
    "user last visit date" : "son ziyaret",
    "ad registration date" : "Oluşturuluş tarihi",
    "ad modification date" : "Değiştiriliş tarihi",
    
    "contact him" : "Cevapla",
    "Send him a message" : "Mail gönder",
    
    "user savefav" : "+ Favorilerim",
    "user email it" : "E-posta ile göndermek",
    "user print" : "Yazdır",
    "user flag it abuse" : "kötüye kullanımı bildir",
    
    "hits : %s times" : "%s defa görüldü", 
      
    // modal box
    "modbox close" : "Kapat",
    "info" : "Bilgi",
    "error" : "Hata",
    "success" : "Başarı ile gerçekleştirilen işlemler",
    "Server request timeout" : "Üzgünüz, sunucu cevap vermiyor veya erişilebilir değil.",
    
    // messages 
    "Action not yet available": "Bu eylem henüz kullanılabilir değil. Özür dileriz!",
    "Yay! Everything went well!" : "Eyleminiz/değişikliğiniz başarıyla geçmiştir!",
    "ok ad under review" : "İlannınız dikkate alındı. Düzenleme Komitesi tarafından gözden geçirildikten sonra yayınlanacaktır.",
    "ok ad deleted" : "İlannınız silindi. Ancak,fikrinizi değiştirirseniz.  30 gün kullanılabilir kalacaktır",
    "ok ad published" : "Tebrikler! İlannınız şimdi yayınlandı.  Maksimum 30 gün  Görünür kalacaktır..",
    "ok user registered" : "Şimdi siteye erişim oluşturuldu. Siteye giriş için kimliğinizi kullanın.",
    "error in form checking" : "Forum düzgün doldurulmamıştır. İşaretlenmiş alanları  kontrol edin, Lütfen !",
    "Doh! Something happened : A user with this email already exist." : "Bu e-posta adresi zaten kullanılıyor. Lütfen başka bir adresi seçin..",
    "Doh! Something happened : This username is not available.": "Bu oturum adı zaten kullanılıyor. Lütfen başka bir ad seçin..",
    // main menu
    "containing <b>%s</b> word" : "<span class='highlight'>%s</span> sözü içeren",
 
    //user menu 
    "create ad" : "Anons (ilan) oluşturun", 
    "create user" : "bir kullanıcı oluşturun", 
    "create zetvu" : "bir ZeTvu oluşturun", 
    "admin (dashboard)" : "Yönetim", 
    
    // geolocatization 
    "Geo-localization successful" : "Bulunduğunuz yer belirlendi : ", 
    "Selected Geo-localization successful" :  "Seçtiğiniz yer belirlendi : ", 
    "Geo-localization failed" : " Coğrafi konumu ayarlamada hata : ",
    "Geoloc not available in your navigator" : "Bu fonksiyon tarayıcınızda kullanılamaz.",
    "Geo-localization time-out" :"Coğrafi konum: sunucu yanıt vermiyor",
    "Geo-localization permission denied":"Coğrafi konum : izin reddedildi",
    "Geo-localization position unavailable":"Coğrafi konum : pozisyonuz mevcut değildir",
    "Goecoding error : "  : "Coğrafi konumu ayarlamada hata : ", 
    "your location" : "Bulunduğunuz yer",
    "Geo-localization in progress":"Coğrafi konum ayarlama devam ediyor ...",
    "Geo-localization error"  : "Coğrafi konumu ayarlamada hata",
    "Geo-localization can move marker to select other":"İşaretleyiciyi uygun adrese taşıyabilirsiniz.",
    "Release the Marker to the desired address" : "... İşaretleyiciyi istenilen adrese yerleştirin.", 
    "getting address...":"Tam adres belirleme devam ediyor",
    "Error in Google Map loading. Check your internet connection." : "GOOGLE MAP Haritası yüklenemedi. İnternet bağlantınızı kontrol edin..",
    //list view
    "Sort by:" : "Sıralama yapın:",
    "Most recent" : "En yeni",
    "Lowest price" : "En düşük fiyat",
    "Highest price" : "En yüksek fiyat",
    "Highest hits": "En çok ziyaret edilen",
    "Sort by price desc" : "En yüksek fiyata göre sırala",
    "Sort by price asc" : "En düşük fiyata göre sırala",
    "Sort by date desc" : "Tarihe göre sırala",
    "Sort by hits desc" : "En çok ziyaret edilene göre sırala ",
    "Sort by name asc" : "Alfebeye göre (A dan Z ye) sırala",
    "Sort by ad nb desc" : "İlan sayısına göre sırala",
    "Sort by whatid desc" : "Kimlik (ID) azalana göre sırala",
    "Sort by what desc" : "kategoriye  göre sırala",
    
    "By " : "Tarafından ",
    "previous page" : "Önceki Sayfalar",
    "next page" : "Sonraki Sayfalar",
    "help prev" : "Önceki Sayfalar",
    "help next" : "Sonraki Sayfalar",
    
    "Ads <b>%s</b> to <b>%s</b> of <b>%s</b> ads" : "( <b>%s</b> à <b>%s</b> / <b>%s</b>)",
    "<b>%s</b>-<b>%s</b> of <b>%s</b>" : "<b>%s</b>-<b>%s</b> / <b>%s</b>",
    
    "Back" : "Geriye", 

    // sub-menu 
    "myads" : "Anonslarım",
    "my_ad" : "Anonslarım",
    "myadmin" : "Hesabım",
    "my_admin" : "Hesabım",
    "admin" : "Yönetim",
    
    "allads" : "Tüm anonslar",
    "all ad" : "Tüm anonslar",
    "all ads" : "Tüm anonslar",
    "admin_ad" : "Tüm anonslar",
    "admin_user" : "Tous les usagers",
    "allusers" : "Tüm kullanıcılar",
    "admin_all" :"",
    "all users" : "Tüm kullanıcılar",
    "all services" : "Tüm hizmetler",


    "all logs" : "Tüm girişleri",
    "all payments" : "Tüm ödemeler",
    "all status" : "Tüm durumlar",
    "manageother" : "Autre gestion",
    "all cat" : "Tüm kategoriler",
    "all user" : "Tüm kullanıcılar",
    "all admin_user" : "Tüm kullanıcılar",
    "all admin_cat" : "Tüm kategoriler",
    
    "dashboard" : "Yol haritası",
    "dash no data" : "Görüntülenecek hiçbir veri yok",
    "mydashboard" : "Yol haritam",

    "user" : "Kullanıcılar",
    "cat" : "Kategoriler",
    "files": "Dosyalar",
    "bytes" : "bayt",  
    "ad" : "Anons", 
    "ads" : "Anons", 
    "all myads" : "Anonslarım",
    "all my_ad" : "Tüm anonslarım",
    "all admin_ad" : "Tüm anonslar",
    "myads_published" : "Yayınlananlar",
    "myads_all" : "Tümü",
    "myads_pending" : "Beklemedekiler",
    "myads_draft" : "Taslaktakiler",
    "myads_draftpendingpayment" : " Bekleyen ödemeler",
    "myads_deleted" : "Süresi bitenler",
    "published" : "Yayınlananlar",
    "pending" : "Bekleyenler",
    "willexpire" : " süresi bitecekler",
    "draft" : "Taslaktakiler",
    "draft pending payment" : " Bekleyen ödemeler", 
    "deleted_expired" : "Süresi bitenler",
    "deleted" : "Süresi bitenler",
    "ads_published" : "Annonces",
    "ads_draft" : "Taslaktakiler",
    "admin_pending" : "Onaylanacak",
    "admin_underreview" : "Onaylanacak",
    "admin_willexpire" : "Süresi bitecekler",
    "admin_expired" : "Süresi bitenler",
    "admin_deleted" : "Süresi bitenler",
    "admin_published" : "Anonslar",
    "admin_draft" : "Taslaktakiler",
    "admin_draftpendingpayment" : "Ödemeleri beklenilenler",
    "admin_draft pending payment" : "Ödemeleri beklenilenler", 
    "admin_willexpire" : "Süresi bitecekler",
    "admin_expired" : "Süresi bitenler",
    "admin_rejected" : "Reddedilenler",
    "admin_under review" : "İncelemede",
    "admin_user_draftpendingpayment" : "Ödemeleri beklenilenler",
    "admin_user_pending" : "Onaylanacak",
    "myprofile" : "Profilim",
    "myfav" : "Favorilerim",
    "manage_settings" : "Yapılandırma",
    "manage_ads" : "Anonslar (tümü)",
    "manage_users" : "Kullanıcılar (tümü)",
    "manage_cats" : "Kategoriler",
    "manage_zetvu" : "Zetvu/haber/Video",
    "manage_twitter" : "Tweeter",
    "manage_logs" : "Günlük raporları",
    "manage_payments" : "Ödeme raporu",
    
    "category":"Kategoriler",
    
    // tooltips 
    "Show List" : "Fotoğraf içeren bir liste halinde göster",
    "Show Gallery" : "Fotoğraf Galerisi biçiminde göster",
    "Show simple List" : "Basit liste olarak görüntüleme",
    "Show map List" : "Googlemap harita üzerinde anonsları göster",
    "help_on_status DRAFT" : "Bu ilan taslak durumundadır ve yayımlanmadı ",
    "help_on_status DRAFT PENDING PAYMENT" : "Bu ilan gönderilmeden önce ödeme bekliyor",
    "help_on_status PUBLISHED" : "Bu ilan yayınlandı",
    "help_on_status UNDER REVIEW" : "Bu ilan, yayımcı tarafından kabul edilmesi için inceleme altındadır",
    "help_on_status UNPUBLISHED" : "Bu ilan yayından kaldırıldı",
    "help_on_status REJECTED" : "Bu ilan editör tarafından reddedildi, lütfen değiştirin",
    "help_on_status DELETED" : "Bu ilan arşivdedir. Yakında silinecek",
    "help_on_status WILLEXPIRE" : "İlanın Süresi bitecek",
    "help_on_status pty_top" : "Bu ilan gondolun başındadır",
    
    "help_on_status protype_pub" : "Bu hesap kamu hesabıdır ve herkes tarafından görünür",
    "help_on_status protype_pub" : "Bu hesap özeldir ve ziyaretçiler için görünür değil.",
    "help_on_status protype_pro" : "Bu hesap profesyonel hesabıdır ve herkes tarafından görünür",
    "help_on_status protype_pri" : "Bu hesap belirli hesaptır",
    "help_on_status protype_par" : "Bu hesap belirli hesaptır",
    
    
    "view all" : "Tümünü görmek",
    "help link Main List" : "Ana listeye dönmek",

    "help password rules" : "İyi bir şifre ve giriş parolası LOGİN den farklı olur rakam ve harfler içerir. Tavsiyeler'i takip edin !",
    
    "help_myads_published" : "Yayınlanan ilanlarım",
    "help_myads_all" : "Bütün ilanlarım durumu ne olursa olsun",
    "help_myads_pending" : "Onaylama bekleyen ilanlarım",
    "help_myads_draft" : "Reddedilen/taslak ilanlarım ",
    "help_myads_draftpendingpayment" : "Ödeme bekleyen ilanlarım",
    "help_myads_deleted" : "/Süresi dolan veya silinen ilanlarım",
    "help_myprofile" : "Profilimi göster",
    "help_myfav" : "Favori ilanlarımı görmek",
    "help_admin_pending" : "Articles à approuver",
    "help_admin_underreview" : "Articles à approuver",
    "help_admin_willexpire" : "Articles qui vont expirer prochainement",
    "help_admin_expired" : "Articles expirés ou supprimés",
    "help_admin_deleted" : "Articles expirés ou supprimés",
    "help_admin_draftpendingpayment" : "Articles en attente de paiement",
    "help_admin_user_draftpendingpayment" : "Comptes en attente de paiement",
    "help_manage_settings" : "Paramètres du site",
    "help_manage_services" : "Gérer les packs de services",
    "help_manage_ads" : "Tous les articles dans tous les états",
    "help_manage_cats" : "Gérer les catégories",
    "help_manage_users" : "Gérer les usagers",
    "help_manage_twitter" : "Envoyer des tweets directement",
    "help_dashboard" : "Accéder au tableau de bord",
    "help_mydashboard" : "Accéder à mon tableau de bord",
    "help_manage_logs" : "Afficher les journaux/logs des modifications et connections",
    "help_manage_payments" : "Afficher les paiements reçus",
    "help_manage_zetvu" : "Gestion des annonces de type Zetvu/News/Videos",

    "Sorry !":"Üzgünüm !", 
    "No items found" : "İsteğinizle ilgilihiçbir öğe bulunamadı. Bazı uygulamalar, giriş yapılması gerektirir..",
    "No items found - No ad" : "Henüz ilanız yok", 
    
    //tweeter
    "What are you doing?" : "Ne yapıyorsun ?",
    "twitter header" : ": Doğrudan tweet",
    "Loading your tweets..." : "Son mesajlarınız yükleniyor ...",
    "Timeline" : "Fil",
    
    // global home page messages 
    "You have %s article(s) waiting for your approval" : "Onayınızı bekleyen %s duyuru var: ", 
    "access here" : "Onaylamak için tıklayınız",   
    
    // templates
    "some text"  : "Admin'den adminé tercüme",
    "some more text"  : "başka tercüme",
    "some text in french":"é ve è harfleriyle",
    '%s text in french %s' : '%s printf örneği %s', 
    '%s text in french' : '%s basit printf örneği', 
    '%s comment' : '%s yorumlar',
    '%s comments' : '%s yorumlar', 
    'text in french' : 'Fransızca metin',
    
    // dashboard 
    'adsnb' : 'Sayı',
    '%adsnb' : '%',
    'val' : 'Sayı',
    '%val' : '%',
    'metrics' : 'Sayı',
    '%metrics' : '%',
    'nb' : 'Sayı',
    'nbusers' : 'Sayı',
    '%nbusers' : '%',
    'cattitle' : 'Kategori',
    'status' : 'Durum',
    'others' : 'Diğerleri',
    
    "dash manage ads" : "(Görmek/yönetmek)", 
    "dash manage users" : "(Görmek/yönetmek)",
    "dash manage cats" : "(Görmek/yönetmek)",
    "cumul users"  : "# kullanıcılar (toplam)",
    
    "a10": "Taslak",
    "a20": "Şu anda inceleme altında",
    "a40": "yayımlanan",
    "a60": "re-travail",
    "a80": "Silindi",
    "a90": "reddedildi",
    "a45": "suresi bitecek",
    
    'fb' : 'Facebook',
    
    'stat dashboard title' : 'Yönetici Panosu (Admin)', 
    'stat mydashboard title' : 'Benim Panom', 
    
    'top_dashboard' : 'Genel Görünüm ', 
    'ad_vol_per_cat' : 'Kategorilere göre ilanlar', 
    'ad_vol_per_type' : 'Tipe göre ilanlar', 
    'ad_vol_per_time' : 'Zaman içinde ilanlar', 
    'ad_vol_per_delete' : 'İlan silmek için nedenler',
    
    'ad_vol_per_status' : 'Yayın durumuna göre ilanlar', 
    'user_vol_per_time' : 'Zaman içinde kullanıcılar ', 
    'user_vol_per_age' : 'Eskiliğe göre kullanıcılar', 
    'ad_vol_per_age' : 'Eskiliğe göre ilanlar', 
    'user_vol_per_type' : "Kimlik doğrulama göre kullanıcılar",
    'user_vol_per_protype' : "Profile göre kullanıcılar",  
    'ad_vol_per_user' : ' kullanıcılar tarafından verilen ilnalar', 
    
    'Observation period : ' : 'Dönem : ', 
    'all' : 'Hepsi', 
    'thisyear' : 'Bu sene', 
    'thismonth' : 'bu ay',
    'thisquarter' : 'Bu çeyrek',
    '-- all time --' : '-- Her zaman --', 


    // footer translation 

    // "A propos de ZADS" : "About", "ZADS hakkında"
    // "ZADS est une plateforme d'échange d'annonces entre particuliers dans un domaine privé comme une entrepsie ou une collectivité." :
    //     "ZADS is a classidied ads platform available in hosted or in script mode to enable community to exchange product and services", 
	//          "ZADS ,  bir şirket veya bir topluluk ile  özel bir kişi arasındaki alış veriş reklamları için bir platformdur."

    // "En savoir plus" : "Find our more", "Daha fazla bilgi edinin"
    // "S'abonner": "Subsribe", "Abone olmak"
    // "Annonces par email":"Ads by email", ""E-posta ile ilan"  
    // "Offres et Demandes" : "Sell and Buy", "Teklifler ve istekler"
    // "Aide et Support" : "Help and support", "Yardım ve destek"


    // "Aide et Support" : "Help and Support", "Yardım ve destek"
    // "Questions Frequentes (FAQ)" :"F.A.Q", "Sıkça Sorulan Sorular (SSS)"
    // "Tutoriels et démos" :"Demo and Tutorials", "Öğreticiler ve demolar"
    // "Signaler un probléme":"Notify us on an issue", "Bir sorunu rapor bildirin"
    // "Suivre / Contact" : "Follow / Contact","iletişim"
    // "suivre ZADS.FR sur Twitter"  : "Follow us on Twitter", "ZADS.FR Twitterden takip edin"
    // "suivre ZADS.FR sur Facebook"  : "Follow us on Facebook", "ZADS.FR Facebook'tan takip edin"


    // "Me contacter" : "Contact us", "bana ulaşın"
    // "A propos" : "About this", "Hakkında"
    // "Infos légales et CGU"  : "Terms and Conditions", "Künye ve şartları"
    // "Publicité" : "Advertising","Reklam"
    // "Nous contacter" : "Contact us", "Bize ulaşın"
    // "Aide" :  "Help", "Yardım"
    // "F.A.Q" :  "F.A.Q",  "SSS"

    // new ZADS 4.6
    "around me :" : "Yakınımda:", 
    ":unknown" :" Nerede?", 
    "(change)" : "(değiştir)",
    "(locate me)" :"(beni bul)", 


    "display failed" : "Hata", 
    "Doh! Something happened : no authorized - private profile" : "Bu bilgilere erişmek için yetkiniz yok", 

    "post paidaccount" : " Ücretli hesap (Yıllık fiyat,tarife)  : ", 
    "help_protype_paid" : "Sitede sınırsız sayıda reklamlar için erişim sağlar. Yıllık tarife için. Genel koşullara bakınız.",

    "Process ongoing ..." : "Devam ediyor, lütfen bekleyin ...", 


    // banners management 
    "title" :"Başlık",
    "htmlcode": "Html kodu",
    "clicktrackingurl": "URL clicktracking", 
    "startdate": "Başlangıç tarihi", 
    "enddate": "Bitiş tarihi", 
    "position": "Konum", 
    "clicks": "Tıklama", 
    "impressions": "Yazdırmak.", 
    "CTR": "CTR", 
    "resetclicks" : "Tıklanma ve (Yazdırma) gösterimler kontörünü sıfırlamak",

    "desc_banner_title" :"Titre",
    "desc_banner_htmlcode": "Code Html",
    "desc_banner_clicktrackingurl": "URL clicktracking", 
    "desc_banner_startdate": "Date de début", 
    "desc_banner_enddate": "Date de fin", 
    "desc_banner_position": "Emplacement", 
    "desc_banner_clicks": "Clicks", 
    "desc_banner_impressions": "Impressions", 
    "desc_banner_CTR": "CTR", 

    "help_banner_title" :"Titre de la bannière pour vous aider à l'identifier",
    "help_banner_htmlcode": "Code Html de la banniére. Dans le cas d'une bannière'background_all', indiquez uniquement l'url de la publicité. Javascript non supporté",
    "help_banner_clicktrackingurl": "URL qui redirigera les utilisateurs lors d'un click sur la publicité", 
    "help_banner_startdate": "Date de début de publication", 
    "help_banner_enddate": "Date de fin de publication", 
    "help_banner_position": "Emplacement de la publicité sur le site", 
    "help_banner_clicks": "Nombre de clicks sur la publicité", 
    "help_banner_impressions": "Nombre d'impressions sur le site", 
    "help_banner_CTR": "CTR =  Click Trhough Ratio  =  nbr de clicks / nbr d'impressions",

    "add banner" :"ajouter une bannièrepublicitaire",  
    "all banners" : "Toutes les banniéres", 
    "manage_banners" : "Gestion de publicités",
    "help_manage_banners" : "Gestion de publicités",

    "Banner reset clicks confirmation" :"Confirmation remise à zéro",
    "Banner reset clicks content" : "Confirmation de la remise à zéro des compteurs clicks et impressions", 
    "Banner delete confirmation" : "Confirmation effacement définitif",  

    " banner form header title" : "Création d'une bannière publicitaire",
    " banner form header introduction" :"Ci-dessous, créer une bannière publicitaire",
    "modify banner form header title" : "Modification d'une bannière publicitaire",
    "modify banner form header introduction" :"Ci-dessous, modifier la bannière publicitaire existante",


    // extended contact form
    "contact reason" : "istek", 
    "procpny": "Şirket", 
    "to email" :"Alıcı",

    '-- select one --' : '-- istek - türünü gösterin --',
    "Subscription" : "Kayıt olmak", 
    "Advertising" : "Reklam vermek", 
    "Information" :"Bilgilendirme", 
    "Support" :"Teknik yardım", 
    "Other" : "Diğer istekler", 

    "Account fee is <b>%s %s %s</b> per period" : "Servise erişim ücreti ayda <b>%s %s %s</b> euros", 

    "Please validate the location" : "Lütfen bu yeri onaylayın",

    "top register user" : "Kayıt olmak", 

    // new zads 4.8 : 
    "Thanks you for your payment ! Your account is create, please login to connect" : "Ödeme için teşekkür ederiz! Hesabınızda kullanılabilir durumda.<br> Parolanızla ve seçilen şifre ile giriş yapın ",
    "show all" : "Tüm anonsları göster", 
    "Sort by hierarchy" : "Hiyerarşiye göre sırala",
    "desc_parentid" : "Ana kategori", 
    "help_parentid" : "2 düzey kategori istiyorsanız,  buradan bir ana kategoriyi seçin. Aksi halde SEÇ olarak bırakın. Yalnızca 2 düzey mümkün. . ", 
    "cat order plus" : "Görüntü sırası artırın (0 = ilk görüntü)",
    "cat order minus" : "Görüntü sırası azaltmak (0 = ilk görüntü)",

    "pub users" : "Diğer reklam verenler", 
    "Main list" : "Ana listeye geri dön", 

    // place to translate catégories 
    "Categorie initial" : "ÇEVRİLEN KATEGORİNİN ADI", 
    "patmisc à é é ç" : "Tercüme edildim",


     // ----------  new zads 4.9 : 

    "plan_step1" : "Abonelik seçin", 
    "plan selection header title" : "plan selection header title",
    "plan selection header line1" : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent accumsan elit ligula. Nam in molestie orci. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nullam in magna tortor. Donec nisl mauris, vulputate id urna in, pharetra suscipit purus. Nam commodo mauris vel bibendum dapibus. Phasellus euismod metus ut felis adipiscing, commodo lobortis mi imperdiet. Quisque sit amet est eu arcu bibendum tincidunt. Praesent id sapien sed massa accumsan luctus. Sed non adipiscing sapien. In nisl nulla, aliquam a placerat quis, convallis eget quam. In hac habitasse platea dictumst. Aenean tempor arcu eu dui pharetra, eu hendrerit massa feugiat. Proin ipsum mauris, sagittis tempus turpis a, interdum facilisis turpis. Curabitur augue odio, faucibus et tristique quis, porta at ante. Vestibulum augue lorem, pellentesque non ante nec, auctor tristique est.",
    "plan selection footer line1" : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent accumsan elit ligula. Nam in molestie orci. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nullam in magna tortor. Donec nisl mauris, vulputate id urna in, pharetra suscipit purus. Nam commodo mauris vel bibendum dapibus. Phasellus euismod metus ut felis adipiscing, commodo lobortis mi imperdiet. Quisque sit amet est eu arcu bibendum tincidunt. Praesent id sapien sed massa accumsan luctus. Sed non adipiscing sapien. In nisl nulla, aliquam a placerat quis, convallis eget quam. In hac habitasse platea dictumst. Aenean tempor arcu eu dui pharetra, eu hendrerit massa feugiat. Proin ipsum mauris, sagittis tempus turpis a, interdum facilisis turpis. Curabitur augue odio, faucibus et tristique quis, porta at ante. Vestibulum augue lorem, pellentesque non ante nec, auctor tristique est.",


    "email" : "E-posta",

    "us_protype" : "Profesyonel Rehber ",
    "us_skills"  : "Kategoriler",
    "us_avatarimg"  : "Logo",
    "us_bio"  : "Kısa sunum",
    "us_longdesc"  : "Uzun sunum",
    "us_folioimg"  : "Fotoğraf galerisi",
    "us_videoembed"  : "Video bağlantısı",
    "us_phone" : "Telefon",
    "us_dispemail" : "E-posta",
    "us_subscription" : "Giriş günleri",
    "ad_nb" : "Anonslar",
    "ad_nbpics" : "Resimler",
    "ad_duration" : "",
    "ad_featured" : "",
    "ad_perm" : "",
    "ca_restricted" : "",
    "ad_videoembed" : "Video bağlantısı", 
    "ad_links": "Bağlantılar", 
    "ad_enemail":"İletişim E-posta", 
    "ad_enphone":"İletişim Tél.", 


    "settings_v" : "Görünür", 
    "settings_us_protype" : "Profesyonel Rehber",
    "settings_us_skills"  : "Kategoriler",
    "settings_us_avatarimg"  : "Logo",
    "settings_us_bio"  : "Kısa sunum",
    "settings_us_longdesc"  : "Uzun sunum",
    "settings_us_folioimg"  : "Fotoğraf galerisi",
    "settings_us_videoembed"  : "Video bağlantısı",
    "settings_us_phone" : "Telefon",
    "settings_us_dispemail" : "E-posta",
    "settings_us_subscription" : "Giriş günleri",
    "settings_ad_nb" : "Maksimum anons",
    "settings_ad_nbpics" : "Anons başı maks. fotoğraf",
    "settings_ad_duration" : "",
    "settings_ad_featured" : "",
    "settings_ad_perm" : "",
    "settings_ca_restricted" : "",
    "settings_ad_videoembed" : "Video bağlantısı", 
    "settings_ad_links": "Maks bağlantı", 
    "settings_ad_enemail":"İletişim E-posta", 
    "settings_ad_enphone":"İletişim Tél.", 
    "settings_ad_duration":"Anonsun süresi(Gün olarak)", 
    "settings_ad_duration":"*** Kullanmayın ***", 
    "settings_ad_nbvideos" : "Maks video (embed)", 
    "settings_ad_urgent" : "ACIL zorla", 
    "settings_ad_featured":"ÜSTE zorla",
    "settings_ad_perm":"KALICI Zorla",

    // Z6.1.2 - temporary removed as no actions yet 
    "settings_ad_urgent" : "*** ne pas utiliser ***", 
    "settings_ad_featured":"*** ne pas utiliser ***",
    "settings_ad_perm":"*** ne pas utiliser ***",


    "settings_us_social":"** do not use **",
    "settings_us_links":"Max liens",
    "settings_us_prowebsite" : "Site web pro", 
    "settings_ca_restriction" : "Uniquement Cat. ID",

    "settings_duration" : "Durée (jours)",
    "settings_bgcolor" : "CSS color",
    "settings_type" : "Type",
    "settings_xtype" : "XType",

    "settings_radio_base" : "Base", 
    "settings_radio_trial" : "Trial", 
    "settings_radio_" : "Service", 

    "settings_default" : "Par défaut",
    "settings_pricedesc" : "Description (prix)", 
    "settings_name" : "Nom", 
    "settings_payoption" : "Reference Cat.",
    "settings_price_type" : "Structure", 
    "settings_radio_flat" : "Unique", 
    "settings_radio_volume" : "Volume",
    "settings_ad_details" : "Contenu du pack (annonces)", 
    "settings_us_details" : "Contenu du pack (compte)",
    "settings_prices_details" : "Structure de prix",  
    "settings_n" : "Prix ID",
    "settings_ttc" : "Prix (TTC)",
    "settings_ht" : "Prix (HT)",
    "sign up" : "Signer pour ce plan",
    
    "plans_faq_1_question" : "Lorem ipsum dolor sit amet, consectetur",
    "plans_faq_1_response" : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras commodo nec elit nec sollicitudin. Aenean rutrum, magna a venenatis lobortis, lacus nisi tristique est, id euismod ante dolor vel orci. Quisque porttitor augue at fermentum ultricies.",

    "plans_faq_2_question" : "Lorem ipsum dolor sit amet, consectetur",
    "plans_faq_2_response" : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras commodo nec elit nec sollicitudin. Aenean rutrum, magna a venenatis lobortis, lacus nisi tristique est, id euismod ante dolor vel orci. Quisque porttitor augue at fermentum ultricies.",


    // nouvelles entrése du formulaire 
    "desc_label_plan" : "Abonelik türü", 
    "desc_plan" : "Abonelik" ,
    "you selected the  plan  : " : "Seçtiniz abonelik : ", 
    "help_plan" : "Bu seçtiğiniz Abonelik türünü belirtir.", 
    "desc_longdesc" :"Genişletilmiş tanıtım",
    "help_longdesc" :"Şirketinizin genişletilmiş tanıtımı",

    "longdesc" : "Genişletilmiş tanıtım",
    "videoembed" : "Video tanıtımı",

    // enhancements of zads 4.9
    "See details of this user" : "Bu reklam verenin detaylarına bakın", 
    "See all ads from this seller" : "Bu reklam verenin tüm ilanlarına bakınız", 
    "See all ads" : "Tüm ilanları",

    // pricing type 
    "desc_pricetype" : "Fiyatlar (diğer)", 
    "help_pricetype" : "Belirtilen dışında özel bir fiyat teklif etmek istiyorsanız burada belirtin.", 
    "price" : "Önerilen fiyat",
    "to be discussed" : "pazarlık yapmak",
    "make an offer" : "teklif yapmak",
    "on quote" : "ticaret üzerinde",
    "model dependant" : "modele bağlı",

    "pricetype_tbdi" : "pazarlık yapmak",
    "pricetype_mano" : "teklif yapmak",
    "pricetype_onqo" : "ticaret üzerinde",
    "pricetype_mode" : "modele bağlı",
    "pricetype_sala" : "maaş",

    "ad videoembed" : "Video", 
    "(read more)" : "(devamını oku)",

    "Ad creation forbidden from your current profile.": "Aboneliğinizin sınırlarını aştınızı reklam oluşturulması mümkün değildir.  ", 
    "pro you have exceeded quota of ad." : "Reklam oluşturulmanız mümkün değildir çünkü aboneliğinizin sınırlarını aştınız.",
    "par you have exceeded quota of ad." : "Reklam oluşturulmanız mümkün değildir çünkü aboneliğinizin sınırlarını aştınız.",

    // location based 
    "loccity" : "Şehir", 
    "locdept" :"il", 
    "locregion" : "Bölge",

    // traductions pour plan princing (customer specific)
    // SELECT INPUT 
    "-- no plan --" : "-- Özellikli abonelik yok --", 
    "options_Basic" : "Basic abonelik", 
    "options_Premium" : "Premium Abonelik", 
    "options_Pro" : "Profesyonel Abonelik", 

    "more cat" : "tam listeyi göster ...", 
    "less cat" : "... Küçült ...",



    // zads @4.9.2
    "edit my profile" : "Profilimi Düzenle", 


    // zads@4.9.5
    "a45": "suresi bitecek",
    "a15" : "ödeme beklemede", 
    // -- payment logs
    "<b>%s</b> payment(s) - total amount = <b>%s</b> %s" : "<b>%s</b>  ödeme - toplam tutarı  = <b>%s</b> %s", 
  
    "-- select what --" : "-- Her çeşit ödeme türleri --",
    "Only Ads" :  "Ücretli seçenekler", 
    "Only Users" : "Ücretli Aboneler",
    "Only Services" : "Ücretli servisler",

    // zads@4.9.7
    "Map home page  - first paragraph" : " ",
    "Map home page  - last paragraph" :  " " ,

    "user links" : "Web bağlantılar", 
    " add_links" : " Bağlantı ekle", 
    "url title placeholder" : "Bağlantının başlığı",
    "url placeholder" : "http:// ou www.monsite.com",
    "save this link" : "Bu bağlantıyı kaydet", 
    "link title" : "Başlık", 
    "link url" :"url", 
    "Incorrect URL format." : "URL biçimi yanlış",
    "remove this link" : "Bu bağlantıyı Kaldır", 
    "help_links (%s max)" :  "Dış bağlantılar ekleyebilirsiniz, %s bağlantıya kadar", 
    "settings" : "Yapılandırma",

    " settings form header title" : "Gestion de la configuration du site",
    " settings form header introduction" : "A travers ces formulaires, gérer l'apparence et la configuration générale du site. Attention, certaines actions pourraient endommager le site. Veuillez consulter la documentation technique avant toute manipulation.",
    "BTN settings PUBLISHED" : "Sauvegarder les modifications",
    "Settings updated successfully" : "Sauvegarde des paramètres faite !", 
    "settings creation ongoing" : "Sauvegarde de la configuration en cours", 
    
    "settings_menu_site_details" : "Details",
    "settings_menu_general" : "Details",
    "settings_menu_site_pages" : "Pages",
    "settings_menu_sitepages" : "Pages",
    "settings_menu_site_metas" : "Metas/SEO",
    "settings_menu_general2" : "Metas/SEO",
    "settings_menu_site_layout" : "Thème/Disposition",
    "settings_menu_layout" : "Thème/Disposition",
    "settings_menu_life_cycle" : "Cycle de vie",
    "settings_menu_lifecycle" : "Cycle de vie",
    "settings_menu_emails" : "Emails",
    "settings_menu_social" : "Social",
    "settings_menu_security" : "Securité",
    "settings_menu_site_locale" : "Locale",
    "settings_menu_locale" : "Locale",
    "settings_menu_others" : "Autre",
    "settings_menu_site_links" : "Liens",
    "settings_menu_links" : "Liens",
    "settings_menu_superadmin" : "Options Avancées",
    "settings_menu_site_badwords" : "Mots interdits",
    "settings_menu_badwords" : "Mots interdits",
    "settings_menu_site_theme" : "Theme",
    "settings_menu_theme" : "Theme",
    "settings_menu_fields" : "Champs",
    "settings_menu_multitenant" : "Multitenants",
    "settings_menu_site_nav" : "Nav/Recherche",
    "settings_menu_mainnav" : "Nav/Recherche",

    "desc_settings" : "Configuration", 
    "desc_settings_path" : "Variante (path)", 
    "help_settings_path" : "Variante (path) : chemin indiquant ou les paramétres de tenant sont stockés.Si vide, utilise le chemin par défaut = 'settings/' ", 

    "desc_domain_fqdn" : "Nom de Domaine FQDN",
    "desc_domain_fqdn_short" : "FQDN court (pour SEO)",
    "desc_logo_fqdn" : "Emails logo (url)",
    "desc_logo_paypal_fqdn" : "PAYPAL Logo (url) ",
    "desc_site_name" : "Nom du site",
    "desc_site_motto" : "Devise du site",
    "desc_site_customer" : "Nom du client",


    "help_domain_fqdn" : "Nom de Domaine FQDN : exemple http://www.monsite.com/ - Attention ne pas oublier le / à la fin ! ",
    "help_domain_fqdn_short" : "nom de domaine court utilisé pour le référencement",
    "help_logo_fqdn" : "Url du logo utilisé puor les notifications par emails",
    "help_logo_paypal_fqdn" : "Url (ABSOLUE !!!) du logo affiché dans PAYPAL lors du paiement. Taille max: largeur=90 px/ hauteur=60 px en .gif, .jpg, or .png.",
    "help_site_name" : "Nom du site (pour les emails)",
    "help_site_motto" : "Devise du site (pour les emails)",
    "help_site_customer" : "Nom du client (pour les emails)",

    "desc_cust_site_name" : "Nom du site",
    "desc_cust_site_motto" : "Devise du site",
    "desc_cust_site_owner_accronym" : "Propriétaire",
    "desc_cust_site_owner_long" : "Nom Long proprio.",
    "desc_cust_loading_msg" : "Message chargement",
    "desc_cust_title" : "Titre (meta) ",
    "desc_cust_description" : "Description (meta)",
    "desc_cust_about_footer_desc" : "A propos", 
    "desc_cust_keywords" : "mots clefs (meta)",
    "desc_enable_auto_sitemap" : "Sitemap automatique",
    "desc_seo_include_zetvu" : "Référencement des ZETEVU",
    "desc_cust_logo_uri" : "Logo URL",
    "desc_cust_favicon_uri" : "Favicon URL",
    "desc_enable_img_autoswipe" : "Image Auto-swipe",


    "help_cust_site_owner_accronym" : "Accronym / nom de la société propriétaire du site pour être utlilisé dans les termes et conditions.",
    "help_cust_site_owner_long" : "Nom  LONG du propriétaire du site pour être utlilisé dans les termes et conditions",
    "help_cust_site_name" : "Nom du site tel qu'il apparaitra sur la page web",
    "help_cust_site_motto" : "Devise du site tel qu'il apparaitra sur la page web",
    "help_cust_loading_msg" : "Message de bienvenue qui s'affichera lors du chargement de la page",
    "help_cust_title" : "Titre su site  ",
    "help_cust_about_footer_desc" : "Texte affiché dans le A PROPOS en bas de page . Laisser vide pour ne pas l'afficher", 
    "help_cust_description" : "Description courte du site qui sert au référencement",
    "help_cust_keywords" : "mots clefs servant au référencement",
    "help_enable_auto_sitemap" : "Génération automatique d'un sitemap.xml et dépot sur la racine su site",
    "help_seo_include_zetvu" : "Référencement des ZETEVUs/ NEWS dans la sitemap",
    "help_cust_logo_uri" : "Logo URL",
    "help_cust_favicon_uri" : "Favicon URL",
    "help_enable_img_autoswipe" : "Image Auto-swipe : active le défilement autatique des images quand on passe la souris dessus en mode affichage de détails.",


    "desc_page_map" : "Page Avec Carte",
    "desc_page_map_first_p" : "Texte HTML entête",
    "desc_page_map_center_p"  :"Texte HTML centre",
    "desc_page_map_last_p" : "Texte HTML pied",

    "help_page_map" : "Page Avec Carte",
    "help_page_map_first_p" : "Paragraphe d'entête de la page principale d'accueil (code HTML avec ZADS KEYWORDS)",
    "help_page_map_center_p" : "Paragraphe au centre la page principale d'accueil (code HTML avec ZADS KEYWORDS)",
    "help_page_map_last_p" : "Paragraphe de pied de page de la page principale d'accueil (code HTML avec ZADS KEYWORDS)",

    "desc_social_links":"Liens SOCIAL",
    "desc_cust_facebook_url":"FACEBOOK (url)",
    "desc_cust_twitter_url":"TWITTER (url)",
    "desc_cust_gplus_url":"GOOGLE+ (url)",
    "desc_cust_youtube_url":"YOUTUBE (url)",
    "desc_footer_links":"Liens bas de page",
    "desc_cust_tandc_url":"Termes et conditions (url)",
    "desc_cust_rgda_url":"Régles de Diffusion (url)",
    "desc_cust_pub_url":"Publicité (url)",
    "desc_cust_contactus_url":"Nous contacter (url)",
    "desc_cust_aboutus_url":"A propos .. (url)",
    "desc_cust_whoweare_url":"Qui sommes-nous .. (url)",
    "desc_cust_faq_url":"F.A.Q (url)",
    "desc_cust_demo_url":"Demo (url)",
    "desc_cust_help_url":"Aide (url)",
    "desc_cust_pricing_url":"Tarifs (url)",
    "desc_cust_blog_url":"Blog (url)",
    "desc_cust_forum_url":"Forum (url)",

    "help_social_links":"Liens SOCIAL",
    "help_cust_facebook_url":"FACEBOOK url affichée en bas de page ou dans le widget social",
    "help_cust_twitter_url":"TWITTER url affichée en bas de page ou dans le widget social",
    "help_cust_gplus_url":"GOOGLE+ url affichée en bas de page ou dans le widget social",
    "help_footer_links":"Liens bas de page",
    "help_cust_tandc_url":"Lien (url) vers la page des Termes et conditions du site",
    "help_cust_rgda_url":"Lien (url) vers la page des Régles de Diffusion du site",
    "help_cust_pub_url":"Lien (url) vers une page indiquant les conditions de publicité",
    "help_cust_contactus_url":"Lien vers la formulaire de contact. Indiquer 'contact' pour utiliser le formulaire intégré au site.",
    "help_cust_aboutus_url":"A propos de ..url",
    "help_cust_whoweare_url":"Qui sommes-nous .. (url)",
    "help_cust_faq_url":"Lien (url) vers lune page de Questions/Reponses",
    "help_cust_demo_url":"Lien (url) vers une page Demo",
    "help_cust_help_url":"Lien (url) vers une page d'aide sur ce site",
    "help_cust_youtube_url":"YOUTUBE url",
    "help_cust_pricing_url":"Lien (url) vers la page des tarifs.",
    "help_cust_blog_url":"Lien (url) vers votre  site de blogging",
    "help_cust_forum_url":"Lien (url) vers votre FORUM",

    "desc_general" :"Général",

    "desc_theme_style":"Théme (expert)",
    "desc_layout_bg_pattern":"Image de fond",
    "desc_theme_css_url" : "URL theme CSS (delta)", 
    "desc_theme_master_css_url" :"URL theme CSS (master)",
    "desc_theme_cust_lang_url" :"URL correctifs langues",
    "desc_layout_header_widgets_en" :"Header widget",
    "desc_layout_gallerie_widgets_forced_fullwidth" :"Gallerie 100% large",

    "desc_enable_infinite_nav" : "Navigation infinie",
    "desc_enable_infinite_scroll" : "Déroulement infini",
    "help_enable_infinite_nav" : "Navigation infinie : à la fin de chaque page, un bouton à cliquer vous propose de charger la suite.",
    "help_enable_infinite_scroll" : "Déroulement infini : chargemement automatique des pages suivantes quand vous arrivez en bas de page",

    
    "help_layout_bg_pattern":"Nom de l'image de fond par défaut. Ne rien indiquer pour avoir un fond vide. L'image doit être dans préalablement stockée dans le répertoire /bg/ du site.",
    "help_theme_css_url" : "Ce champ, si renseigné, permet d'ajouter au site en place des CSS personnels qui peuvent être chargés sur le site via l'interface de gestion de fichier ou simple des CSS venant d'une URL publique", 
    "help_theme_cust_lang_url" :"URL du fichier de langue qui viendra completer le master language . Attention, le format ne doit pas terminer ne nom du fichier (exemple pour un fchier custo_fr_FR.js, indoquez uniquement le chemin + custo_, le reste sera ajouté par le site fonction de la langue choisie.",

    "help_theme_master_css_url" :"URL theme MASTER : permet de remplacer la feuille de style maitre par une autre feuille de style . Laisser vide si vous souhaitez utiliser la feuille maitre de base.",
    "help_layout_header_widgets_en" :"Permet d'afficher une zone de 200px en haut du site (entre la barre et le début de l'affichage) et positionner le logo et une publicité",
    "help_layout_gallerie_widgets_forced_fullwidth" :"Force le module/widget Gallerie A la une a avoir 100% la taille du site. Par défaut, elle est limitée à la zone d'affichage des annonces, sans la barre latérale",

    "desc_enable_country_map":"Carte premiére page",
    "desc_max_pages_to_show":"Max page",
    "desc_max_items_per_page":"Nombre item/page",
    "desc_layout_bg_pattern":"Image de fond",
    "desc_header_show_nb_ads" : "Affic. nbr annonces en haut",
    "desc_widgets":"Widgets",
    "desc_max_items_per_mod":"MAX article/widget",
    "desc_nb_items_per_vmod":"Nbr articles/widget",
    "desc_enable_mostviewed_mod":"Les plus vus",
    "desc_enable_top_mod":"A la une",
    "desc_enable_topgallery_mod":"Galerie",
    "desc_enable_browsebyloc_mod":"Localisation",
    "desc_browsebyloc_fields_order":"Location order",
    "desc_categories":"Catégories",
    "desc_max_cat_per_column":"Catégories/col",
    "desc_show_empty_cat":"Affichage Ad Vides",
    
    "desc_hide_empty_cat_users":"Masquer Cat. vides",
    "desc_hide_empty_buy_ad":"Catégorie 'buy' vides",
    "desc_display_more_cat_link":"Afficher 'plus'",
    "desc_max_skills_nb":"Max compétences",
    "desc_zetvu":"Zetevu/NEWS",
    "desc_disable_zetvu":"Désactiver",
    "desc_zetvu_as_news":"Mode News",
    "desc_zetvu_create_by_admin_only":"Création par Admin",

    "desc_enable_latest_mod":"Derniers Ajouts",
    "desc_enable_urgent_mod":"Annonces urgentes",
    "desc_enable_social_widget":"Social toolbar",
    "desc_enable_newsletter_widget":"Newsletter",


    "help_enable_country_map":"Afficher en premiére page la carte des annonces. Mettre sur OFF pour arriver directement à la liste des annonces.",
    "help_max_pages_to_show":"Nombre maximum de pages à afficher",
    "help_max_items_per_page":"Nombre d'articles par page.",
    "help_header_show_nb_ads" : "Afficiche dans le barre du haut le nombre de d'annonces.",

    "help_widgets":"Widgets = Modules affichés",
    "help_max_items_per_mod":"Nombre d'articles maximum affichés par widget.",
    "help_nb_items_per_vmod":"Nombre d'articles visibles par widgets.",
    "help_enable_mostviewed_mod":"Module 'les plus vues'",
    "help_enable_top_mod":"Module 'a la une'",
    "help_enable_topgallery_mod":"Module Galerie tournante en haut de page des articles 'A la une' ",
    "help_enable_browsebyloc_mod":"Module 'localisation'",
    "help_browsebyloc_fields_order":"Ordre de navigation dans les champs de localisation . Mots acceptés : locregion;locdept;loccity. Séparation par | .",
    "help_categories":"Catégories",
    "help_max_cat_per_column":"Sous-menu de navigation :  Nombre max de catégories a afficher avant de changer de colonne d'affichage.",
    "help_show_empty_cat":"Sous-menu de navigation : Afficher les catégories sans annonces",
    "help_hide_empty_cat_users":"Sous-menu de navigation : Masquer les catégories sans annonceurs.",
    "help_hide_empty_buy_ad":"Sous-menu de navigation : Masquer les catégories sans annonces de type 'demandes'.",
    "help_display_more_cat_link":"Afficher le bouton 'plus' lorsque le nombre de sous-catégories dépasse 3.",
    "help_max_skills_nb":"Nombre maximum de conpétances qu'un annonceur peut choisir dans son profile",
    "help_zetvu":"Zetevu/NEWS",
    "help_disable_zetvu":"Désactiver la fonction zetevu/news.",
    "help_zetvu_as_news":"Mode News activé pour la fonction zetevu/news. Attention, le mode ZETEVu ci-dessus doit être activé",
    "help_zetvu_create_by_admin_only":"Création des ZETEVU/NEWS autorisée par administrateur uniquement. Sinon, tout le monde peut en créer un",

    "help_enable_latest_mod":"Module derniéres annononces ajoutées- Module sur la bare latérale",
    "help_enable_urgent_mod":"Module derniéres annonces urgentes - Module sur la bare latérale",
    "help_enable_social_widget":"Social toolbar qui s'affiche en statique sur le coin de la page",
    "help_enable_newsletter_widget":"Newsletter - champ de saisie disponible en bas de page pour s'enregistrer à la newsletter",


    "desc_ad_preview_before":"Mode pre-vue (annonces)",
    "desc_user_preview_before":"Mode pre-vue (usagers)",
    "desc_draft_purge_duration":"Purge Bouillons aprés ",
    "desc_publishing_duration":"Publication Ann. pendant",
    "desc_user_auto_approval":"Auto-approbation (usagers)",
    "desc_ad_auto_approval":"Auto-approbation (annonces)",
    "desc_desc_new_sincelastvisit_en" : "New (depuis edrniére visite)",
    "desc_dayskeepasnew":"Nb jours en 'new'",
    "desc_archive_duration":"Archive de tout pendant",
    "desc_notificationbefore_duration":"Notification expiration avant",
    "desc_user_maxinactive_duration":"Expirer Usagers inactifs aprés",
    "desc_ad_paid_nomods_aftercreation" : "NO-Mods options payantes", 


    "help_ad_preview_before":"Anons'un Sitede görüleceği son şekli",
    "help_user_preview_before":"Reklam verenin Sitede görüleceği son şekli ,görünümü",
    "help_draft_purge_duration":"Anons taslaklarını saklama dönemi",
    "help_publishing_duration":"Anons yayın süresi",
    "help_user_auto_approval":"Anons verenin otomatik onaylanması",
    "help_ad_auto_approval":"Anonsların otomatik onaylanması",
    "help_dayskeepasnew":"Bir anons'un YENİ  işaretli olarak gösterilme gün sayısı",
    "help_desc_new_sincelastvisit_en" : "En son ziyaretten sonra Yeni reklamların üzerine YENİ bir gösterge (işaret) görüntüler.",
    "help_archive_duration":"Anonsların arşivi xx gün sonra doldu",
    "help_notificationbefore_duration":"Anons'un bitimine xx gün kala,anons verene E-mail vasıtasıyla bildirim gönderilecek",
    "help_user_maxinactive_duration":"xx gün hareketsizlikten sonra reklam verenin hesabı kaldırılır ve arşive konur.",
    "help_ad_paid_nomods_aftercreation" : "Anons'un verildiğnden sonra,anons verenin ödeme şeklini değiştirme seçeneğini kaldırır", 

    "desc_email_fromadmin":"DE (email)",
    "desc_email_admin":"Admin email (TO)",
    "desc_email_admin_reports":"Rapports (TO)",
    "desc_email_support":"Support (TO)",
    "desc_email_sales":"Sales (TO)",
    "desc_emails_admin_essential_mode" : "Notification réduite", 

    "help_email_fromadmin":"Adresse email utilisée pour le champ FROM des emails envoyés",
    "help_email_admin":"Adresse email de l'administrateur pour recevoir les notifications",
    "help_email_admin_reports":"Adresse email(s) des personnes qui souhaitent recevoir les rapports journaliers d'activité",
    "help_email_support":"Adresse email de l'équipe support vers qui diriger les demandes",
    "help_email_sales":"Adresse email de l'équipe vente vers qui diriger les demandes",
    "help_emails_admin_essential_mode" : "Par défaut, chaque changement d'état d'une annonce ou d'un annonceur envoie une notification à l'administrateur. Activez cette option pour supprimer cette notification", 


    "desc_locale_default_currency":"Devise",
    "desc_locale_default_unit":"Unité mesure",
    "desc_locale_default_country_code":"Code pays",
    "desc_locale_default_sub_code":"Sous code pays",
    "desc_locale_default_lat":"Latitude",
    "desc_locale_default_lng":"Longitude",

    "help_locale_default_currency":"Devise d'affichage des prix (EUR, USD). Mettre NO pour ne pas afficher la devise.",
    "help_locale_default_unit":"Unité mesure : km (pour Kilomètres), m (pour miles)",
    "help_locale_default_country_code":"Code pays (ISO 3166-1) permettant d'afficher la bonne carte en première page et adapter les contrôles de code postaux, numéro de téléphones, ...",
    "help_locale_default_sub_code":"Sous code pays - ** reserved **",
    "help_locale_default_lat":"Latitude du point central permettant de positionner la cartes par défaut",
    "help_locale_default_lng":"Longitude du point central permettant de positionner la cartes par défaut",

    "desc_enable_badwords_filter":"Filtrage Mots Interdits",
    "desc_enable_ipblacklist_filter":"Filtrage IPs",
    "desc_enable_emailblaklist_filter":"Filtrage eMAILS",
    "desc_enable_contactthru_when_phone" : "Contract anonyme/phone", 

    "help_enable_badwords_filter":"Active le filtrage des mots interdits sur les annonces. La liste des mots se configure par langue.",
    "help_enable_ipblacklist_filter":"Active le filtrage des visiteurs sur l'adresse IP (IP BLACK LIST)",
    "help_enable_emailblaklist_filter":"Active le filtrage des connections sur adresse email",
    "help_enable_contactthru_when_phone" : "Contract anonyme/phone : permet, même quand l'annonceur indique une numero de telephone d'utiliser le formulaire de contract du site.", 


    "desc_google_analytics_account":"Google ANALYTICS",
    "desc_google_site_verification":"Google SITE CODE",
    "desc_enable_debug_mode":"Mode Debug",
    "desc_auto_pics_resize" : "re-taille des images",

    "help_google_analytics_account":"Code Google Analytics pour le suivi de performance du site",
    "help_google_site_verification":"Code de vérification pour GOOGLE SITE VERIFIER",
    "help_enable_debug_mode":"Mode de debug - Administrateur uniquement - pour l'aide à la résolution de panne du site",
    "help_auto_pics_resize" : "correction automatique de la taille des images en 600x500px max.",


    "desc_sales_package": "Packaging", 
    "desc_max_tot_ads":"MAX annonces",
    "desc_max_tot_ads_per_users":"Max Annonces/user",
    "desc_max_pic_size":"Taille Image",
    "desc_max_pic_nb":"Max images/ad",
    "desc_auto_pics_resize":"Auto-resize",
    "desc_tbyb_end_date":"Fin Essai le",
    "desc_directory_mode":"Mode Annuaire",
    "desc_homepage_display_what":"Page principale",
    "desc_widgets_based_on_what":"Widget basé sur",
    "desc_security_logs":"Sécurité/logs", 
    "desc_backup_sqltable":"Backup", 
    "desc_enable_elem_logs":"Logs sur annonces",
    "desc_enable_user_logs":"Logs sur usagers",
    "desc_logs_duration":"Durée rétention",
    "desc_payment_logs_duration":"Durée PAYPAL logs",
    "desc_advanced_layout":"Mise en page avancée", 
    "desc_split_desc_ad_details":"Séparer texte ", 
    "desc_desc_ad_details_all_bottom":"Texte en bas", 

    "desc_files_manager":"Gestionnaire fichiers",
    "desc_enable_files_manager":"Activer",
    "desc_files_manager_dir":"repertoire destination",
    "desc_files_manager_max_size":"taille maxi",
    "desc_files_manager_max_nbr":"max fichiers",

    "desc_emails_manager" : "Gestion Emails",
    "desc_enable_emails_templates" : "Basé sur modèles ?",

    "desc_advanced_search":"Rech. avancée",
    "desc_adv_search_startup":"Rech. avancée",
    "desc_adv_search_autosuggest":"Auto-suggession",
    "desc_vfields":"Champs supplém.",
    "desc_enable_vfields":"Activer champs virtuels",
    "desc_vfields_search":"Rech. avec champs v.",

    "desc_access_profiles" : "Types de comptes", 
    "desc_user_profile_private_en" : "Type PRIVE", 
    "desc_user_profile_public_en" : "Type PUBLIC", 
    "desc_user_profile_pro_en" : "Auto. type PRO", 
    "desc_user_profile_par_en" : "Auto. type PARTICULIER",

    "desc_advanced theme" : "Theme (expert)", 
    "desc_theme_extra_js_url" : "URL extra JS", 
    "help_theme_extra_js_url" : "URL du fichier .JS qui devra être charger en plus du site pour ajouter du scripting personnel", 



    "desc_dpe_img_vfield_id" :"CE champ ID",
    "desc_ges_img_vfield_id" : "GES champ ID", 
    "help_dpe_img_vfield_id" :"Classe Enerie : identifiant du champ spécial contenant l'information. Permet d'afficher la carte dynamiquement. Laisser a vide pour ne pas afficher",
    "help_ges_img_vfield_id" : "Gaz a affet de serre : identifiant du champ spécial contenant l'information. Permet d'afficher la carte dynamiquement. Laisser a vide pour ne pas afficher", 


    "help_adv_search_startup":"Bloc de recherche avancée affiché par défaut au demarrage du site",
    "help_adv_search_autosuggest":"Auto-suggession activée",
    "help_enable_vfields":"Activer la gestion et usage de champs virtuals sur le site",
    "help_vfields_search":"Ajouter les champs virtuels comme critéres de recherche",

    "help_user_profile_private_en" : "PRIVE tip'i : anons yayınla ama rehberde hesabınız görünmez", 
    "help_user_profile_public_en" : "PUBLIC tip'i : anons yayınla ama rehberde hesabınız görüntüsü kısıtlı", 
    "help_user_profile_pro_en" : "PROFESIONNEL tip'i: profesyonel hesap kaydetmek için (çok opsyon)", 
    "help_user_profile_par_en" : "PARTICULIER tip'i : basit hesap oluşturmaya izin verme.", 



 

    "help_sales_package": "Packaging", 
    "help_max_tot_ads":"Limiter au nombre total d'annonces indiqué.",
    "help_max_tot_ads_per_users":"Nombre d'annonces max par users",
    "help_max_pic_size":"Taille maximale des images téléchargées (en Octets).",
    "help_max_pic_nb":"Nombre max d'images par annonces",
    "help_auto_pics_resize":"Re-taille automatique des images téléchargées",
    "help_tbyb_end_date":"Date de fin de l'essai",
    "help_directory_mode":"Mode annuaire",
    "help_homepage_display_what":"Type d'affichage en page principale (user ou ad)",
    "help_widgets_based_on_what":"Widgets basés sur ... (ad ou user)",
    "help_security_logs":"Sécurité/logs", 
    "help_backup_sqltable":"Backup", 
    "help_enable_elem_logs":"Logs sur annonces",
    "help_enable_user_logs":"Logs sur usagers",
    "help_logs_duration":"Durée rétention des logs ",
    "help_payment_logs_duration":"Durée PAYPAL logs",
    "help_advanced_layout":"Mise en page avancée", 
    "help_split_help_ad_details":"Séparer le texte descriptif d'une annonce en 2 morceaux", 
    "help_help_ad_details_all_bottom":"Mettre tout le texte descriptif de l'annonce en dessous de la photo", 

    "help_enable_emails_templates" : "Gestion Emails sur la base de modéles HTML directment configurables via l'administration wbe. Si OFF, utilisation des modéles internes au site",

    "help_split_desc_ad_details":"Sépare texte de description des annnonces avec le debut sur le coté et la fin en dessous des photos", 
    "help_desc_ad_details_all_bottom":"Positionne 100% de la descritption d'une annonce en dessous des photos et plus sur le côté comme le mode par défaut.", 



    "desc_badwords":"Mots interdits",
    "desc_cust_badwords":"Mots interdits",
    "help_cust_badwords":"Liste des mots interdits. Attention : séparation par '|' uniquement. A la détection, l'annonce sera mise en quarantaine et nécessitera l'approbation de l'éditeur. Ne pas oublier d'activer l'option générale de filtrage des mots interdits.",
    "Bad words error notice text" : "Votre annnonce contient des mots interdits qui ne respectent pas les termes et conditions du site.",


    "desc_location_restricted_disp":"Cacher adresse (partiel)", 
    "help_location_restricted_disp":"Cette option permet de cacher aux visiteurs l'adresse exacte des annonces et annonceurs et aficher uniquement departement/ville", 


    "latest added" :"Derniers ajouts", 
    
    // file manager @Z5.1
    "manage_files" : "Gestion fichiers", 
    "help_manage_files" : "Gestion fichiers", 
    "filesmanager" : "Gestionnaire de fichiers",
    "upload file" : "Ajouter un fichier",
    "%s file":"%s fichier",
    "%s files":"%s fichiers",
    "%s Byte":"%s Byte",
    "%s Bytes":"%s Bytes",
    "No files in directory." : "Aucuns fichiers dans ce répertoire",

    // emails maagement //
    "manage_emails" :"Gestion notifications emails",
    "help_manage_emails" :"Gestion notifications emails",

    "emailsmanager" : "Gestionnaire des modèles de notifications email",
    "save" : "Sauvegarder", 
    "view it" : "Prévisualiser",
    "send you a test email" : "Vous envoyez un email de test",

    "%s emails" : "%s modèles de notification" ,
    "%s email" : "%s modèle de notification" ,

    "help_admin_abuse_00.html":"Bir anons üzerindeki tacizleri,hataları bildirin  (Yönetici)", 
    "help_admin_ad_20.html":"Onay bekleyen anons (Yönetici)", 
    "help_admin_ad_40.html":"Yayımlanan anons (Yönetici)", 
    "help_admin_support_00.html":"Destek talebi (Yönetici)", 
    "help_cron.html":"Günlük tablosu (Yönetici)", 
    "help_lost_password.html":"Parola değişikliği (sahibi)", 
    "help_owner_ad_15.html":"Ödemesi bekleyen anons (anons veren)", 
    "help_owner_ad_20.html":"Doğrulama bekleyen anons (anons veren)", 
    "help_owner_ad_40.html":"Yayımlanan anons (reklamverenin)", 
    "help_owner_ad_45.html":"Anonsun süresi yakında sona rerecek ( anons veren)", 
    "help_owner_ad_80.html":"Anonsun süresi doldu (reklamverenin)", 
    "help_owner_ad_90.html":"Yönetici tarafından anons rededildi (anons veren)", 
    "help_owner_contactuser_00.html":"Anons veren ile iletişim isteği", 
    "help_owner_contact_00.html":"Anons'u veren ile iletişim isteği (anons veren)", 
    "help_owner_reminder_00.html":"Anons'u hatırlatan E-posta(Ziyaretçi) ", 
    "help_owner_support_00.html":"Destek talebi (Ziyaretçi)", 
    "help_owner_user_15.html":"Abonelik için ödeme bekleniyor (anons veren)", 
    "help_owner_user_40.html":"Abonelik aktif durumda (Anons veren)", 
    "help_owner_user_45.html":"Abonelik yakında sona erecek (Anons veren)", 
    "help_owner_user_60.html":"Abonelik bloke (Anons veren)", 
    "help_owner_user_80.html":"Süresi dolan abonelik (Anons veren)", 
    "help_user_contactuser_00.html":"iletişim isteği (başvurucu)", 
    "help_user_contact_00.html":"Anons'u veren ile iletişim isteği (Ziyaretçi)", 
    "help_user_reminder_00.html":"Enetresan anons için hatırlama(Ziyaretçi)", 
    "help_user_support_00.html":" Destek talebi (Ziyaretçi)", 


    // fiels maagement //
    "manage_fields" :"Gestion des champs",
    "help_manage_fields" :"Gestion des champs",
    "fieldssmanager" : "Gestionnaire de champs personnalisés",

    "banner_pos_background_all":"Fond d'écran - arriére plan ", 
    "banner_pos_background_right_top":"Font d'écran - coin sup droit", 
    "banner_pos_sidebar_right_top":"Bare Latérale - droite - haut ", 
    "banner_pos_page_center_top":"Centre page - en haut du listing ", 
    "banner_pos_mob_page_center_top":"Centre page - en haut du listing (Mobile)", 
    "banner_pos_ad_detail_sidebar":"Bare latérale sur consultation fiche d'une annonce", 
    "banner_pos_news_main_center_top":"News centrale - en haut du listing", 
    "banner_pos_headerwidget_right_top":"Entête - en haut à droite", 


    // zads 5.5
    // search 
    "Advanced search :" : "Gelişmiş arama : ", 
    "Search" : "Arama", 
    "No results" : "Sonuç bulunamadı", 
 
    // VFIELDS management 
    "%s vfields" : "%s champs spéciaux" ,
    "%s vfield" : "%s champ spécial" ,
    "add vfield" : "Ajouter un champ spécial" ,
    "int_label" : "Nom",
    "disp_label" : "Label",
    "preview" : "Affiché comme ...",
    "moddatestamp" : "Date",
    "domtype" : "Type",
    "scope" : "Scope",
    "forwhat" : "Cible", 
    "id" : "Ident.", 

    "fieldsmanager" : "Gestionnaire de champs spéciaux",
    "all vfields" : "tous les champs",
    "id" : "id",

    "vfield creation ongoing" : "Création du champ spécial en cours", 

    " vfield form header title" : "Création d'un champ spécial",
    " vfield form header introduction" : "Les champs spéciaux permettent d'ajouter de caractéristiques particuliéres à certaines annonces dans certaines catégories. Définissez le champ spécial ici et ajoutez le aux catégories via l'interface admin", 

    "modify vfield form header title" : "Modification d'un champ spécial",
    "modify vfield form header introduction" : " ", 


    "desc_int_label" : "Nom interne",
    "desc_disp_label" : "Nom affiché",
    "desc_scope" : "Type de champ",
    "desc_forwhat" : "Pour...",
    "desc_domtype" : "Type HTML",
    "desc_domsubtype" : "Sous-type",
    "desc_values" : "Valeurs",
    "desc_unit" : "Unité",
    "desc_stype" : "Type (recherche)", 
    "desc_linkedvfield" : "Champ lié (recherche)",
    " add_values" : "ajouter une valeur",
    "add this value" : "ajouter cette valeur",
    "vfield value placeholder" : "entrer le valeur désirée",
    "No fields defined yet" : "Aucun champ défini pour l'instant",

    "help_scope" : "Indique si ce champ sera utilisé pour des informations supplémentaires dans les annonces ou un champ de recherche",
    "help_forwhat" : "Précise si ce champ peut etre ajouté à des usagers, annonces ou tout",
    "help_int_label" : "Nom interne du champ utilisé pour l'administration",
    "help_disp_label" : "Nom affiché du champ qui sera visible par les visiteurs et annonceurs",
    "help_domtype" : "Type HTML du champ (entrée simple, liste de choix, ...",
    "help_values" : "Liste des différentes veleurs que peut prendre un champ. Ne sart a rien sur les champs input",
    "help_unit" : "Unité, optionelle pour indiquer l'unité du champ saisi",
    "help_domsubtype" : "!! uniquement pour les champs INPUTs : sous type permettant de filtrer les données",
    "help_linkedvfield" : "!! Uniquement pour les champs de recherche :  indique le champ lié à cette recherche",
    "help_stype" : "!! champ de recherche uniquement !! <br> permet de spécifier si le champ est de type MIN, MAX ou simplement generique",
    "help_values" : "Permet de lister les valeures pour les champs CHECKBOX ou RADIO ou SELECT",  
    "help_values (%s max)" : "Permet de lister les valeures pour les champs CHECKBOX ou RADIO ou SELECT (%s max). Attention, les 10 premiers caractéres doivent être différents entre chaque valeur.",  
    
    "BTN vfield DRAFT" : "Brouillon",
    "BTN vfield PUBLISHED" : "Publier",
    "BTN vfield UNPUBLISHED" : "Suspendre",
    "BTN vfield DELETED" : "Supprimer",
    "BTN vfield WILLEXPIRE" : "va expirer",

    "desc_catlvfields" : "Champs spéciaux", 
    "help_catlvfields" : "Les Champs spéciaux permettent de collecter plus d'informations lors de la création d'une annonce", 
    " add_catlvfields" : "ajouter un champ spécial",
     "add this field" : "ajouter ce champ",
     "ad vfields" : "Caractéristiques", 
     "Select something" : "--Choisissez--", 

     "set/un-set in your favorites" : "Ajouter/Supprimer de votre liste de favorites", 

     // newsletter 
     "manage_subscribers" : "Gestion des abonnés", 
     "help_manage_subscribers" : "Gestion des abonnés à la newsletter", 
     "all subscribers" : "tous les abonnés", 
     "-- all status --" : "Tous les états d'abonnement", 
     "-- all status ad --" : "-- états --", 
     "-- all status user --" : "-- états --", 
     "registration pending" : "Enregistrements en attente de validation", 
     "registered" : "Enregistrés et actifs", 
     "-- unlimited --" : "Tous les résultats", 

     "publish" : "Valider l'abonnement", 
     "un publish" : "Retirer l'abonnement", 
     "subscribers unpublish confirmation" : "Confirmation de l'arrêt de l'abonnement", 
     "subscribers publish confirmation" : "Confirmation de l'activation de l'abonnement", 
     "subscribers delete confirmation" : "Confirmation de l'effacement de l'abonnement",
     "No entries in subscribers" : "Aucun abonné pour l'instant", 
     "Export this table to xls" : "Exporter XLS", 
   
     "Subscribe" : "Abone ol",
     "Delete this" : "Sil",
     "Un-Subsrcibe"  : "Kaydet",
     "Your email address": "Mail adresiniz",
     "Subscribe to the newsletter": "Abone ol",
     "Your subscription is already pending your approval on : %s": "Abonelik zaten bu e-posta adresi ile bekliyor : %s",
     "You are already subscribed under %s": "Zaten bu e-posta adresi altında abonesiniz : %s",
     "un-subsribe to the newsletter": "Onun aboneliğini sil",
     "delete this pending approval": "Bu isteği iptal edin",
     "Newsletter": "Newsletter",
     "Your subscription is correctly registered, check your inbox email for validation.": "Aboneniz E-posta adresinizdeki mesaj'ı onayladıktan sonra geçerli olacak.",
     "Newsletter registration pending": "Onay bekleyen kayıt",
     "A registration already exist for this email address : %s.": "Zaten bu e-posta adresi altında abonesiniz : %s",

     "un-subsribe to the newsletter": "Aboneliğini sil",
     "Your subscripton is cancelled" : "Aboneliğiniz iptal edilmiştir",
     "Your are un-subscribed to our newsletter"  :  "Bizim bültene abone değilsiniz.",
     "You are correctly unsubscribed." : "Bizim bültene abone değilsiniz.", 
     "This email or hash is not known by us yet  : %s." : "Bu e-posta adresi veya bu aktivasyon kodu tanınmıyor.", 
     "Your subscription is validated" : "Aboneliğiniz etkindir.", 
     "Thank you for your registration to our newsletter" : "Bültenimize aboneliğiniz için teşekkür ederiz.", 
     "Your are registered to our newsletter":  "Aboneliğiniz etkindir.", 

     "details dpe" : "CLASSE ENERGIE",


     // gestion fichiers 
     "tn" : "Küçük resimler", 
     "name" : "Adı", 
     "size" : "Boyutu", 
     "modified" : "Düzenleme tarihi",
     "actions" : "Eylemler", 

     // nouveaux liens 
     "General Rules of Diffusion" : "Anonsların yayımlanması için genel kurallar(RGDA)", 
     "Régles de Diffusion" : "Yayımlama kuralları",
     " and the " : " ve ", 
     "Qui nous sommes ?" : "Biz kimiz ?", 
     "Tarifs" :"Fiyatlar", 

     "user details vfields" : "Diğer bilgiler", 
     "desc_extra_user_fields" : "Diğer bilgiler",

     "subscribed options" : "Seçenekleriniz", 
     "Test Mail sent successfully" : "Mail E-posta adresinize gönderildi", 


     // post correction ZADS  5.5.1 - BUGs discovered //
     "definitively delete" : "Kalıcı olarak sil", 


     // zads 5.5.2
     "mydashboard" : "Benim Panom",
     "my dashboard" : "Benim Panom",

    "desc_new_sincelastvisit_en" : "Son ziyaretten bu yana yenilikler",
    "help_new_sincelastvisit_en" : "Son ziyaretten bu yana yeni reklamları görüntülemek için seçeneği sağlar",

    "desc_social_widget_list" : "Elements barre social (site)", 
    "desc_sidebar_widgets_order_list":"Liste order des widgets", 
    "desc_siret_control_url":"Siret control (url)", 
    "desc_urgent_ads_en":"Acil reklamlar", 

    "help_social_widget_list" : "Liste par ordre d'affichage des réseaux sociaux afficher dans la barre latérale social et le bas de page", 
    "help_sidebar_widgets_order_list":"Liste par ordre d'affichage des widgets en barre latérale", 
    "help_siret_control_url":"URL du site qui controle le champ SIRET. ajouter [NUMBER] le remplacer dynamiquement par le siret du client exemple :http://www.societe.com/cgi-bin/recherche?rncs=[NUMBER]. Si renseigné, le champ SIRET devient obligatoire à la saisie", 
    "help_urgent_ads_en":"Active l'option 'annonces urgentes' lors de la saisie des annonces et la recherche", 

    "help_siret_format_FR" : "Le numéro SIRET (Système d'identification du répertoire des établissements) est un numéro d'identification unique attribué à chaque établissement selon une codification INSEE. C'est une suite numérique de 14 chiffres : les neufs premiers représentent le numéro SIREN de l'entreprise à la quelle l'établissement est rattaché, les cinq derniers chiffres sont un numéro interne de classement (NIC) qui permet d'identifier l'établissement.",
    "check prosiret" : "vérifier", 




    /* zads 5.5.3 */ 
    "urgent"  :"Acil", 
    "ad urgent" :"Acil",
    "Search in ads" :" Anons", 
    "urgents" : "Acil", 
    "only" : "Yalnızca",
    "desc_urgent_ads_en" : "Acil anonslar", 
    "help_urgent_ads_en" : "Active l'option annonces urgentes pour l'administrateur et comme critére de recherche.", 
    "desc_ads fields" : "Options annonces",
    "desc_user fields" : "Options users", 
    "desc_others" : "Autres",

    "ad createdate" : "Oluşturuyor", 
    "ad firstpublisheddate" :"Yayınlandı", 

    "desc_otherpaidoptions" : "Genel", 
    "post otherpaidoptions" :" ",
    "addpics" : "Fotolar", 
    "paidvideo" : "Videolar",

    "desc_putontopgallery" : "Güncelleştirmek",
    "help_putontopgallery" : "Güncelleştirmek",
    "putontopgallery" : "Güncelleştirmek",  
    "post putontopgallery" : "Anonsumu güncelleştir ve görünülürlüğümü artır",
    "desc_putontopgallery7days" : "Güncelleştirmek", 
    "desc_putontopgallery15days" : "Güncelleştirmek", 
    "desc_putontopgallery30days" : "Güncelleştirmek", 
    "post putontopgallery7days" : "7 gün süresince her gün güncelleştir", 
    "post putontopgallery15days" : "15 gün süresince her gün güncelleştir", 
    "post putontopgallery30days" : "30 gün süresince her gün güncelleştir", 



    "desc_pushtotop" : "Liste başı ", 
    "help_pushtotop" : "Liste başı ", 
    "pushtotop" : "Liste başı ", 
    "post pushtotop" :"Anonsumu liste başına çıkar ve müşterileri artır",
    "desc_pushtotoponceaweek"  : "Haftada bir, liste başı.",
    "desc_pushtotop7days" : "Liste başı", 
    "desc_pushtotop15days" : "Liste başı", 
    "desc_pushtotop30days" : "Liste başı", 
    "post pushtotoponceaweek" : "Haftada bir anonsumu liste başına çıkar", 
    "post desc_pushtotop7days" : "7 gün boyunca her gün anonsumu liste başına koy", 
    "post desc_pushtotop15days" : "15 gün boyunca her gün anonsumu liste başına koy", 
    "post desc_pushtotop30days" : "30 gün boyunca her gün anonsumu liste başına koy", 


    
    "post pushtotop7days" :  "Anonsumu 7 gün boyunca her gün öne koy", 
    "post pushtotop15days" :  "Anonsumu 15 gün boyunca her gün öne koy", 
    "post pushtotop30days" :  "Anonsumu 30 gün boyunca her gün öne koy", 

    

    "desc_urgentad" : "Acil", 
    "help_urgentad" : "Acil", 
    "urgentad" : "Acil", 
    "post urgentad":"Daha hızlı satmak için 'Acil' Logo'yu eklemek",
    "desc_urgentad15days" : "Acil", 
    "desc_urgentad7days" : "Acil",
    "desc_urgentad30days" : "Acil",
    "post urgentad7days" : "7 gün boyunca hergün 'Acil' durumuna koy",
    "post urgentad15days" : "15 gün boyunca hergün 'Acil' durumuna koy",
    "post urgentad30days" : "30 gün boyunca hergün 'Acil' durumuna koy",


    "desc_specialcolor" : "Çerçeveli",
    "help_specialcolor" : "Çerçeveli",
    "specialcolor " : "Çerçeveli",
    "post specialcolor" : "Aramalarda daha fazla görünmek için 'Çerçeveli' opsyon",
    "desc_specialcoloronceaweek" : "Çerçeveli", 
    "desc_specialcolor7days" : "Çerçeveli",
    "desc_specialcolor15days" : "Çerçeveli",
    "desc_specialcolor30days":"Çerçeveli",
    "post specialcoloronceaweek":"Haftada bir kere renkle çevrele",
    "post specialcolor7days":"7 gün boyunca hergün renkle çevrele",
    "post specialcolor15days":"15 gün boyunca hergün renkle çevrele ",
    "post specialcolor30days":"30 gün boyunca hergün renkle çevrele ",

    "help_specialcoloronceaweek":"Haftada bir kere renkle çevrele",
    "help_specialcolor7days":"7 gün boyunca her gün renkle çevrele",


    "banner_pos_userpro_register_sidebar":"Profesyonel kayıt sırasında yan çubuk",


    // traductions pour gestion des abonnements
    "service status PUBLISHED": "Etkin", 
    "service status DELETED": "Boş", 
    "service status UNPUBLISHED": "Etkin olmayan ",
    "service status WILLEXPIRE": "Süresi bitecek",  

    // nouvelles dates de gestion ajoutées 
    "ad life-cycle dates" : "Anahtar tarihler",
    "desc_moddate" : "Düzenleme tarihi",
    "desc_createdate" : "Oluşturma tarihi",
    "desc_firstpublisheddate" : "İlk Yayın tarihi",
    "desc_crondate" : "Son CRON tarihi", 
    "desc_urgent" : "Acil", 
    

    // text for pre-image label 
    "ad upload photo post label" : "Fotoğraflı bir reklam fotoğrafsız bir reklamdan 7 kat daha fazla tıklanır.",


    "list_locations" : "Konumu", 
    "Categories" : "Kategoriler", 

    "desc_location_retricted_disp" : "Tam adresi gizle", 
    "help_location_retricted_disp" : "Bu seçenek görünüyorsa,   anonsun ve dükkanın detaylı adresi gizli tutulacak sadece şehir ve devlet görünecek", 

    "Location displayed is restricted" : "Gizlilik: sadece şehir ve eyalet sitede gösterilir", 
    
    "desc_login_form_inpage" : "Login à plat",
    "help_login_form_inpage" : "Login à plat : l'écran de login est affiché en direct sur la page et plus via une pop-up",

    "settings_menu_paypal" : "Paypal/Paiement",


    "desc_paypal_section" : "Paypal", 
    "desc_paypal_sandbox" : "Mode bac-a-sable", 
    "desc_paypal_user" : "PAYPAL compte",
    "desc_paypal_password" : "PAYPAL mot de passe",
    "desc_paypal_signature" : "PAYPAL signature",

    "help_paypal_sandbox" : "Mode bac-a-sable : permet de tester / suspendre le paiement en redirigeant sur un site paypal de test", 
    "help_paypal_user" : "PAYPAL nom de l'utilisateur ",
    "help_paypal_password" : "PAYPAL mot de passe du compte",
    "help_paypal_signature" : "PAYPAL signature du compte",

    // my services section 
    "My Subscribed services" : "Hizmetlerim", 
    "My current services":"Sık kullandığım serisler",
    "Your trial will expire in %s days": "Deneme paketiniz %s gün içinde bitecek",
    "Your trial is expired as of %s days , please consider buying a pack below": " %s günden beri deneme paketiniz bitti,anons kaydetemek için yeni bir paket seçin",  
    "Till :":"Kadar :", 
    "Expired :" : "Süresi bitti  ", 
    "You have used %s of your %s ads included onto the pack": "Paketinizdeki %s anonslardan %s 'ini kullandınız",

    "Add new services" : "Hizmetler ekleyin", 
    "Services package selection" : "Paket türünü seç", 
    "Select this service":"Bu paketi seç", 
    "Main introduction text to add services":"Lorel ipsum main introduction text to ADD SERVICE section", 
    "Services plan selection":"Plan seçmek", 
    "Your pack :" :"Paketiniz :", 
    "Modify this":"Düzenle", 
    "Select plan :" : "Paketiniz : ",
    "Your plan :" :"Paketiniz :", 
    "Select this plan":"Bu planı seç",
    "Press the buy button to finalize your transaction": "Hareketi tamamlamak için Al düğmesini tıklaytın", 
    "Buy this pack":"Al", 
    "Service order confirmation":"Seçiminizi onaylama", 
    "No services activated" : "Hiçbir hizmeti etkinleştirilmedi",

    "myservices" : "Hizmetlerim ", 
    "help_myservices" : "Etkin halde olan aboneliklerim, paketlerim veya hizmetlerim listesi.", 

    "You have %s article(s) waiting for your paiement" : "Ödeme bekleyen %s anonsunuz var. ",
    "You have no active services any more, please consider buying new services" : "Yayınlamak için hizmet ervisiniz kalmadı,reklamınızı yayınlamak için hizmet servisi alın. ", 
    "You have %s service(s) waiting for your paiement" : "Ödeme bekleyen %s hizmetiniz var. ", 

    // new modification after 10th of feb
    "Pay now" : "Şimdi öde",
    "buy services here" : "Hizmetler satın alın",
    "pro buy services here" : "PRO : Hizmetler satın alın", 
    "par buy services here" : "PARTICULIER : Hizmetler satın alın", 
    "pri buy services here" : "Hizmetler satın alın",     
    "Thanks you for your payment ! Your service is activated." : "Satın alma için teşekkürler, hizmet paketini etkin halde.", 
    "service status DRAFT PENDING PAYMENT" : "Ödeme beklemede",
    "service creation ongoing" : "Hizmet oluşturma durumda", 
    "myinvoices":"Faturalarım", 
    "help_myinvoices": "Faturalarımı göster", 
    "See your invoice %s": "Faturalarımı göster %s", 
    "displayinvoiceaction" : "+", 
    "display invoice details" : "Faturayı göster", 

    "CURRENCY :" : "Para cinsi : ",
    "Designation" : "Atama",
    "qty" : "Miktar",
    "qty" : "Miktar",
    "unit price" : " Fiyatı",
    "total price" : "tomplam fiyati",
    "invalid TRANSACTION request" : "Geçersiz uygulama", 


    // update on invoice
    "INVOICE :" : "Fatura n° : ", 
    "INVOICE PRINT BUTTON" : "Yazdır", 

    "INVOICE DATE :" : "Tarih : ", 
    "BUYER INVOICING TOP LABEL" : "Faturalama",
    "BUYER FIRSTNAME :":"Soyadı : ",
    "BUYER LASTNAME :":"Adı : ",
    "BUYER USERNAME :":"Kullanıcı adı : ",
    "BUYER PROCPNY :":"Şirket : ",
    "BUYER ADDRESS :":"Adres : ",
    "BUYER PHONE :":"Telefon : ",
    "BUYER PROWEBSITE :":"Web : ",
    "BUYER EMAIL :":"Mail adresi : ",


    "INVOICE DATE :":"Tarih : ",
    "INVOICE WHAT ID :":"Referans : ",
    "INVOICE CURRENCY :":"Deviz : ",
    "INVOICE PAYMENT METHOD :":"Ödeme şekli : ",
    "INVOICE TRANSACTION ID :":"Paypal işlemin numarası : ",
    "INVOICE TOTAL AMOUNT :":"Toplam tutar  : ",


    "INVOICE DESC":"Açıklama",
    "INVOICE UP":"Parça fiyatı",
    "INVOICE QTY":" Miktar",
    "INVOICE TOT PRICE":"Toplam",

    "INVOICE DESC TRANSACTION :":",İşlem kimliği : ",
    "INVOICE total without tax":"KDV hariç toplam : ",
    "INVOICE tax":"KDV : ",
    "INVOICE total with tax":"KDV dahil toplam : ",


    "-- services all status --":"-- tüm durumlar --", 
    "services pending payments" : "ödeme beklemesinde" ,
    "services active" : "Aktifler",
    "services expired" : " süresi dolmuşr",  
    "Sort by sid asc" : " Paketi adına göre sıralanmış", 

    // CONFIG PAGE  : for the menu 
    "allservices" : "Hizmet yönetimi", 
    "manage_services" : "Hizmetler", 
    "No entries in services" : " Bu arama için sonuç yok", 
    "services unpublish confirmation" : "Bu hizmet askıya alınsınmı ? ", 



    // CONFIG PAGE  :  the the service settings parameters 
    "settings_menu_services" : "Services", 
    "desc_services_version":"Version abonnement",
    "desc_services_force_default_at_start":"Forcer default",
    "desc_services_multi_en":"Multi services",
    "desc_services_notif_before_days":"Notif expiration",
    "desc_services_deleteall_after_days_expiration":"Effacer aprés",
    "desc_services_notify_en":"Changements notif",
    "desc_services_price_free_during_trial":"Options Gratuit/trial",


    "help_services_version":"Version abonnement : laisser V2 pour la version ZADS 6.0 qui accepteune gestion de services multiples sur un abonnement",
    "help_services_force_default_at_start":"Forcer default : Lors de l'inscription d'un usager, force a prendre un service du catalogue marqué 'defaut'",
    "help_services_multi_en":"Multi services : accepter le mode 'services multiple' au lieu de abonnement simple",
    "help_services_notif_before_days":"Notif expiration : nombre de jours avant l'expiration d'un service ou un email de rappel sera envoyé.",
    "help_services_deleteall_after_days_expiration":"Effacer aprés : nombre de jours aprés lequels, un service en archive sera effacé",
    "help_services_notify_en":"Changements notif : envoyer un email de notification sur chaque changement d'état d'un service",
    "help_services_price_free_during_trial":"Options Gratuit/trial : Si cette option est activée, les services 'sur annonces' sont gratuits pendant la phase de trial",
  

 
    "desc_invoice_section":"Fatura ayarları",
    "desc_invoice_companyname" : "Şirket adı",
    "desc_invoice_vat": "SIRET/KDV no'su",
    "desc_invoice_company_address": "Tam adres",
    "desc_invoice_footertext": "Sayfanın alt kısmında metin",

    "help_invoice_companyname" : "Nom de la société telle qu'elle apparaitra en haut de la facture",
    "help_invoice_vat": "Numéro de SIRET/TVA tel qu'il apparaitra en haut de la facture",
    "help_invoice_company_address": "Adresse compléte de la compagnie a afficher sur la facture. Indiquer les sauts de ligne avec des <br> HTML",
    "help_invoice_footertext": "Texte bas de page",

    "desc_ad_nomods_afterexpiration" : "Pas réactiv. des expirées", 
    "help_ad_nomods_afterexpiration" : "Pas de reactivation des annonces aprés expiration ou suppression", 

    "desc_ad_video_size_width" : "Largeur Videos", 
    "help_ad_video_size_width" : "Largeur des videos affichées dans le détail des annonces. la hauteur est automatiquement calculée avec le ration 0.6", 

    
    "ad video2 embed" : "Video2 HTML code", 
    "ad video2 embed help" : "Video sağlayıcınız HTML kodunu girin. Örneğin, YOUTUBE altında menü paylaşımınaki kodu yapıştırın.", 

    "desc_banclicks" : "Başlık sayfasına tıklamalar", 
    "help_banclicks" : "Başlık sayfasına tıklama sayısı.", 
    "banclicks" : "Başlık sayfasına tıklama.", 

    "paypal_status_Completed" : "Ödendi", 
    "paypal_status_Pending" : "Beklemede", 
    
    // abonnements paypal
    "paypal_status_ActiveProfile"  : "Abonelik Etkin", 
    "paypal_status_PendingProfile"  : "Abonelik Beklemede",

    "servi" : "hizmet", 
    "Main List" : "geri dön",
    "help link retour": "Ana listeye geri dön", 

    "help_admin_service_15.html" : "Hizmet/abonelik ödeme beklemesinde (Yönetici)", 
    "help_admin_service_40.html" : "Hizmet/abonelik etkin (Yönetici)",

    "help_owner_service_15.html" : "Hizmet/abonelik ödeme beklemesinde (sahibi)", 
    "help_owner_service_40.html" : "Hizmet/abonelik etkin (sahibi)",  
    "help_owner_service_45.html" : "Hizmet/abonelik yakında sona erecek (sahibi)",  
    "help_owner_service_80.html" : "Hizmet/abonelik süresi doldu (sahibi)",  

    "help_user_newsletter_unsubscribe_80.html" : "Abonelik bülten sona erdi (ziyaretçi)", 
    "help_user_newsletter_validation_20.html" : "Haber bülteni abonelik bekleyen doğrulama (ziyaretçi)", 

    "ad_nbvideos" : "Videoyla anons",

    "username already in use" : "Bu oturum açma adı zaten kullanılıyor ! ",
    "email already in use" : "Bu e-posta adresi kayıtlıdır ! ",
    "Confirm this service" : "Aboneliğimi onaylayıroum", 
    "no options" : "opsyon yok",
    "par" : "Profesyonel olmayanlar", 
    "pro" : "Profesyonel", 
    "Click <a id='print' href='#'>here</a> to print and clip along the line": " <a id='print' nottip='yes' href='#'>yazdır</a> faturanı.",

    "desc_enable_url_noself_filter" : "Filtrage url", 
    "help_enable_url_noself_filter" : "Active le filtrage des URLs dans une annonce. Si une URL est présente, l'annonce est marquée comme non conforme et mise en validation chez l'éditeur quelque soit le mode de publication. Un message est aussi indiqué dans l'email de changement d'état à l'auteur.", 

    "desc_services_pro_free_options_list": "Options gratuites pour pros.", 
    "help_services_pro_free_options_list": "Pour les annonces, liste les options qui seront forcées et mise gratuites pour les annonceurs professionnels (specifique). Utiliser les noms tels que définit dans le catalogue et séparez les par un signe '+' . ", 

    "desc_indir_pro_only" : "Annu. pour pros. uniquement",
    "help_indir_pro_only" : "Si ON, limite la visibilité annuaire aux professionells uniquement. Les particulier ne pourront pas choisir l'option. Les pros auront le choix de figurer ou non dans l'annuaire",


    // footer links
    "Who we are ?" : "Biz kimiz ?",  
    "COPYRIGHT" : "Copyright ZADS 2014",
    "Legal information" : "Yasal bilgi ve kullanma şartları",
    "General rules of diffusion" : "yayın kuralları",
    "Advertising" : "Reklam",
    "Contact us" : "Bize ulaşın",
    "Pricing" : "Fiyatlar",
    "The blog" : "Blog",
    "F.A.Q" : "S.S.S",  
    "Back to main site" :"Ana siteye dönüş",
    "Help" : "Yardım",

    "sdesc_" : " ",
    "sdesc_basepack" : " ",
    "sdesc_pack5" : "(plan 5)",
    "sdesc_pack10" : "(plan 10)",
    "sdesc_pack25" : "(plan 25)",
    "sdesc_pack50" : "(plan 50)",
    "sdesc_pack75" : "(plan 75)",
    "sdesc_pack100" : "(plan 100)",



    "short-desc_of_pack5" : "plan 5 ilan",
    "short-desc_of_pack10" : "plan 10 ilan",
    "short-desc_of_pack25" : "plan 25 ilan",
    "short-desc_of_pack50" : "plan 50 ilan",
    "short-desc_of_pack75" : "plan 75 ilan",
    "short-desc_of_pack100" : "plan 100 ilan",

    "desc_extra links on nav page" : "Liens dans bare de navigation",
    "desc_extra_main_nav_link1_title" : "Lien 1 - titre ",
    "desc_extra_main_nav_link1_url" : "Lien 1 - URL ",
    "desc_extra_main_nav_link2_title" : "Lien 2 - titre ",
    "desc_extra_main_nav_link2_url" : "Lien 2 - URL ",
    "desc_extra_main_nav_link3_title" : "Lien 3 - titre ",
    "desc_extra_main_nav_link3_url" : "Lien 3 - URL ",

    "help_extra_main_nav_link1_title" : "Lien 1 - titre du lien qui s'affichera sur la barre de natigation en plus des autres.",
    "help_extra_main_nav_link1_url" : "Lien 1 - URL ",
    "help_extra_main_nav_link2_title" : "Lien 2 - titre ",
    "help_extra_main_nav_link2_url" : "Lien 2 - URL ",
    "help_extra_main_nav_link3_title" : "Lien 3 - titre ",
    "help_extra_main_nav_link3_url" : "Lien 3 - URL ",


    "desc_max_cat_on_sidebar" : "Sidebar, max ligne", 
    "help_max_cat_on_sidebar" : "Sidebar, max ligne : nombre de ligne max avant d'afficher le bouton 'plus...' pour les modules CATEGORIES et LOCALISATION de la sidebar.", 

    "social link to %s" : "Lien vers la page ou formulaire  : %s", 


    "title share on facebook" : "Facebook'ta paylaş",
    "title share on twitter" : "Twitter'de paylaş",
    "title share on Linkedin" : "Linkedin'de paylaş",
    "title share on Google+" : "Google+ te paylaş",
    "title share on Pinterest" : "Pinterest'te paylaş", 
    "title ad email it" : "Bu ilanı bana email ile gönderin",

    "you selected the  plan  : " : "Plan seçtiniz : ",

"you selected the  plan  : " : "Paket : ",

    "Tooltip of Export this table to xls" : "Bu tabloyu Microsoft Excel'e götür", 

    "settings_oi" : "Madde referans", 
    "settings_desc" : "Tanım", 
    "settings_price" : "Fiyat",
    "settings_priceHT" : "Fiyat (KKVsiz)", 
    "settings_priceTTC" : "Fiyat (KDVli)",
    "settings_isrecurrent" : "Düzenli",
    "settings_billingperiod" : "Dönem",
    "settings_billingfrequency" : "Fatura Frekansı",
    "settings_nb_addpics" : "fazla resim sayısı",
    "pictures" : "resimler", 
    "Services prices are managed into the packs" : "Hizmet paketleri fiyatları abonelik bölümünde yönetilir",


    "header text settings payoptions":"Ücretli opsyonların katalogu", 
    "header text paragraph payoptions" : "Paramétrez ci-dessous les options payantes qui seront disponibles pour les annonces . Attention, les prix doivent avoir un '.' comme séparateur de décimal", 


    "desc_max_cat_on_sidebar" : "Sidebar, max ligne", 
    "help_max_cat_on_sidebar" : "Sidebar, max ligne : nombre de ligne max avant d'afficher le bouton 'plus...' pour les modules CATEGORIES et LOCALISATION de la sidebar.", 

    
    "settings_menu_payoptions" : " Catalogue", 
    "This is the LABEL element used to group below options" : "ce champ controle le libéllé", 

    // packas d'abonnements et services
    "settings_menu_pricing_plan" : "Abonnements", 
    "header text settings pricingplan":"Détails du contenu des abonnements et packs", 
    "header text paragraph pricingplan" : "Paramétrez ci-dessous les abonnements et services sui seront disponibles pour les annonceurs.", 

    "desc_page_map_type" : "Page home Externe (TEMPLATE)", 
    "desc_page_home_type_url" : "Page externe(url)", 
    "help_page_home_type_url" : "Si activé, la page d'accueil est externe et à chercher à l'url indiquée plus bas. Sinon, on utilise les champs textes", 
    "desc_page_home_url" : "Url de la page externe",
    "help_page_home_url" : "Url de la page externe contenant le contenu HTML à charger sur la page d'accueil",
    "desc_page_map_content" : "Contenu page statique", 

    "users delete confirmation" : "Kullanıcı silme onayla", 
    "ads delete confirmation" : "ilan silme onayla", 

    // totnbads 
    // translations of the admin section zads 6.1
    "totnbads":"Miktar ", 
    "a_moddate" : "Tarih",
    "a_type" : "Tip", 
    "a_id" : 'Kimlik',
    "a_email" :"E-posta",
    "a_priceid" : "Plan", 
    "a_sid" : "Servis", 
    "a_remain" : "Kalan",
    "a_startdate" : "başlangıç tarihi",
    "a_enddate" : "Bitiş tarihi",
    "a_status" : "Durum", 
    "a_userid" : "Kullanıcı kimlik",
    "a_username" : "Ad", 
    "a_price" : "Fiyat" ,
    "a_pricevat" : "Vergi",
    "a_recurrent" : "Düzenli", 
    "a_firstname":"Soyadı",
    "a_lastname" :"Adı",
    "a_procpny":"Şirket",
    "a_protype": "Tip", 
    "a_totnbads": "Ann#", 
    "a_title":"Başlık",
    "a_catid":"Kategori kimlik", 
    "a_hits":"Ziyaretler",
    "a_severity":"Şiddeti .",
    "a_date":"Tarih",
    "a_whatid" : "kimlik",
    "a_what":"Ne?", 
    "a_action":"Eylem",
    "a_cattitle":"Başlık",
    "a_adtitle":"Başlık",
    "a_desc" : "tanım",
    "a_state" : "Durumu",
    "a_position":"Yer Konumu", 
    "a_clicks":"Tıklama #", 
    "a_CTR":"CTR", 
    "a_impressions" : "Yazdırma",
    "a_registerdate" : "Kayıt yapma",
    "a_paymentdate" :"Tarih", 
    "a_transactionid":"İşlem kimliği.", 
    "a_paymentstatus":"Ödeme durumu", 
    "a_amt":"Tutar", 
    "a_displayinvoiceaction" : "Ayrıntılar" ,
    "a_auth" : "Kimlik doğrulama.", 
    "a_lastvisitdate" : "Son ziyaret", 
    "a_gender" : "Cins", 
    "a_locale" : "Dil",
    "a_priority" : "Öncelik",
    "a_prosiret" : "Siret",
    "a_prowebsite" : "Web sitesi",
    "a_loccity" : "Şehir",
    "a_locdept" : "il",
    "a_locregion" : "Bölge.",
    "a_loczipcode" : "Posta kodu",
    "a_loclatlng" : "GPS koordinatlar.",
    "a_plan" : "Plan",
    "a_links" : "Bağlar",
    "a_indir" : ",Rehber?",
    "a_phone" : "Telefon",
    "a_phone2" : "Telefon2",
    "a_email2" : "E-posta 2",
    "a_expiredate" : "Son kullanma tarihi",
    "a_banclicks" : "Banner tıklayın",
    "a_newsletter" : "Bülten",
    'a_ip' : 'IP@',
    'a_order' : 'Or.', 

    "select_fields" : "Alanlar seçin", 
    "fields selection save & refresh" : "Yenileme & Kaydetmek", 
    "fields selection reset" : "Başa dönmek", 


    // adult category disclamers 
    "ADULT-CATEGORY-DISCLAMER":
    "<strong>Bu kategoride, üzerinde 18 yaşında olmalı ve aşağıdaki  şartları kabul etmeniz gerekir:</strong><br><br><span class='normal'><strong>1.</strong>En az 18 yaşındayım. <br>         <br>         <strong>2.</strong> Ben ilanların potansyelik şok edici içerik olabileceğini anlıyorum.<br>         <br>         <strong>3.</strong> Şok edici içerik beni rahatsız etmez.<br>         <br>         <strong>4.</strong> Sitenin yönetim tarafından bazi berlili kelimelerin kısıtlamasını kabul ediyorum  ve Yönetim takdirine bırakıyorum .<br>         <br>         <strong>5.</strong> .  <strong><span style='cursor: text; text-decoration: none'><font color='#cc0000'>'Kabul ediyorum'</font></span></strong> Butona tıklayarak, sitenin sağlayıcıları , sahipleri ve yaratıcıları tüm sorumluluk ve bu bölümde yapılan kullanımından deşarj ediyorum.<br> <br> Kullanım şartlarımızı </span><a href=''>danışmak için tereddüt etmeyin</a>",  

    "desc_adultflag"  : "Yetişkin Kategori", 
    "help_adultflag" : "Bu onay kutusu işaretliyse, sadece koşulları kabul eden yetişkin kullanıcılar ilanları görebilecek.", 

    "title_ADULT-CATEGORY-DISCLAMER": "Sorumluluk Reddi", 
    "dialog disclamer accept" : "Evet kabul ediyorum", 
    "dialog disclamer refuse" : "Hayır, reddediyorum", 

    "desc_legal" : "Légal", 
    "desc_cookiename":"Prefixe Cookie",
    "desc_cookie_duration_adult_disclamer":"Durée Cookie Adulte",
    "desc_filter_adult_in_list":"Filter Cat. adultes",

    "help_cookiename":"Prefixe du Cookie qui sera utilisé pour sauvegarder sur le poste client des informations",
    "help_cookie_duration_adult_disclamer":"Durée Cookie Adulte : Durée en JOURS de persistance du cookie utilisé pour accepter les catégories adultes.",
    "help_filter_adult_in_list":"Filter Cat. adultes : quand le visiteur n'a pas accepté les conditions d'accés aux catégories ADULTES, les annonces ADULTES sont sont pas visibles.",


    // liens sur annonce et annonceurs
    "ad links" : "Liens (url)", 
    "links" : "Liens (url)",
    "desc_links_on_ad": "Liens annonce",
    "desc_links_on_user": "Liens usager",
    "help_links_on_ad": "Liens annonce : autoriser la saisie de liens webs vers d'autres sites. Indiquez le nombre max. Mettre 0 (zero) pour interdire",
    "help_links_on_user": "Liens usager : autoriser la saisie de liens webs vers d'autres sites. Indiquez le nombre max. Mettre 0 (zero) pour interdire",

    "List of links" : "Liens", 
    "desc_newsletter" : "Mektup ", 
    "help_newsletter" : "Sitenin Bülteni", 
    "I subscribe" : "abone oluyorum", 
    "desc_user_enable_newsletter" : "Abonnement newsletter" ,
    "help_user_enable_newsletter" : "Abonnement newsletter : proposer l'abonnement à la newsletter lors de l'enregistrement" ,

    "desc_pictures" : "Gestion Images",
    "desc_img_zoom_en" : "Zoom sur Images", 
    "help_img_zoom_en" : "Zoom sur Images : permet d'activer un zoom sur les images affichées lorsque la souris passe au-dessus. La fonction de Auto-swipe doit etre DESACTIVEE.", 


    "desc_paid_options" : "Options payantes", 
    "desc_paid_options_price_free" : "Forcer TOUT gratuit", 
    "help_paid_options_price_free" : "Force toutes les options en GRATUIT tant que ce paramétre est activé", 

    "desc_other_payments" : "Moyens de paiements (BETA)",
    "desc_payment_method" : "Methode", 
    "help_payment_method" : "Ne pas utiliser pour l'instant !", 
    "desc_payment_manual_mode" : "Mode Manuel", 
    "help_payment_manual_mode" : "Mode manuel de paiement = lors de l'achat d'une option ou un abonnement, l'administrateur doit valier la publication s'être assuré manuellement que le paiement a été effectué par tout moyent (cash, chéque, ...) ",


    "desc_general field for ad" : "Champs Annonces", 
    "desc_ad vtags"  : "Etiquettes PERSO", 
    "desc_price_field_disable" : "Desactiver champ PRIX", 
    "desc_price_field_expression" : "Expression PRIX",
    "desc_vfields_display_hide_zerovalue" : "Cacher valeur NULL", 
    "help_price_field_disable" : "Desactiver le champ prix générique et utiliser l'expression ci-dessous.", 
    "help_price_field_expression" : "Expression PRIX : permet de remplacr le champ prix affiché ar une expression basée sur les champs virtuels. exemple : [VFIELD=18][ - ][VFIELD=19][ ][CURRENCY]",
    "help_vfields_display_hide_zerovalue" : "Cacher lors de l'affichage les champs viruels qui ont une valeur nulle ou zero.", 

    "desc_main_content_width_short_en" : "*FU ** Largeur reduite",
    "help_main_content_width_short_en" : "Spécifie un affichage de liste en utilisant une largeur réduite de la zone principale. ",

    "help_vtags_labels" : "Etiquettes apposées sur les annonces", 

    " Room." : " Pce.", 
    " Peop." :" Per.",
    " m2": " m2",


    // messages lors du login
    "account expired" : "Bu hesabın süresi doldu",
    "reactivate account" : "Bu hesap yeniden etkinleştir",
    "account reactivated" : "Hesabınız reaktif hala getirilmiştir. Yeni erişim kodları size e-postayla gönderilmiş.",
    "log_reactivate_PUBLISHED" : "Etkinleştirildi", 
    "desc_account_reactivate_en" : "Süresi dolan hesabı yeniden etkinleştirme",
    "help_account_reactivate_en" : "Réactivation Comptes expirés  : l'usager lors de la connection est notifié et peut demander une réactivation de son compte. Il recoit en retour un email avec un nouveau mot de passe et son compte est de nouveau actif.",  

    // mise a jour traductions sur logs
    "log_auth_account reactivated" : " Hesabı yeniden etkinleştirme için istek", 
    "log_auth_account expired" : " süresi dolmuş bir hesapla erişim,giriş", 
    "access denied - bad password" : "Erişim engellendi - parola hatası", 

    // new ADMIN options 
    "desc_invoice_number_format" : "Format N° facture", 
    "help_invoice_number_format" : "Format N° facture : indiquez ici le format du numero automatique de facture. Les champs spéciaux autorisés sont [TIMESTAMP], [WHAT] et [ID] ",
    "desc_vtag1_en" : "Tags Virtuel 1", 
    "desc_vtag2_en" : "Tags Virtuel 2", 
    "desc_vtag3_en" : "Tags Virtuel 3", 
    "desc_vtag4_en" : "Tags Virtuel 4",
    "desc_vtag5_en" : "Tags Virtuel 5",

    "help_vtag1_en" : "Tags Virtuel 1 : permet de definir des champs en plus sur les annonces. Vous pouvez définir le nom via votre fichier personnel de traductions", 
    "help_vtag2_en" : "Tags Virtuel 2 : permet de definir des champs en plus sur les annonces. Vous pouvez définir le nom via votre fichier personnel de traductions", 
    "help_vtag3_en" : "Tags Virtuel 3 : permet de definir des champs en plus sur les annonces. Vous pouvez définir le nom via votre fichier personnel de traductions", 
    "help_vtag4_en" : "Tags Virtuel 4 : permet de definir des champs en plus sur les annonces. Vous pouvez définir le nom via votre fichier personnel de traductions",
    "help_vtag5_en" : "Tags Virtuel 5 : permet de definir des champs en plus sur les annonces. Vous pouvez définir le nom via votre fichier personnel de traductions",

    "desc_activate_text_scroll" : "Scroll texte",
    "help_activate_text_scroll" : "Scroll texte : en affichage en mode GALLERIE, permet de faire défiler le texte en overlay fonction des mouvements de la souris",
   
    "desc_dynamic_update_widgets" : "Mise à jour auto", 
    "help_dynamic_update_widgets" : "Mise à jour auto des widgets activées lors d'un changement de catégorie, région, pays, .. ", 

    "recurrent paiement" : "Paiements récurrents",
    "one-shot transaction" : "Transaction unitaire",  
    "frecurrent" : "Récurrent", 


    // elements pour facture des abonnements récurrents
    "RECURRING PAIEMENT ID :" : "N° d'identifiant du profil :",
    "PROFILEID PRINT BUTTON" : "IMPRIMER", 
    "PROFILE ID :" : "N° ID du profil : ", 
    "PROFILE STATUS :": "Etat : ", 
    "RECURRING PROFILESTARTDATE :": "Début : ", 
    "RECURRING BILLINGPERIOD :": "Période de facturation : ", 
    "RECURRING BILLINGFREQUENCY :": "Fréquence : ", 
    "RECURRING TOTAL AMOUNT :": "Montant : ", 
    "RECURRENT DESC :" : "Description : ", 
    "RECURRENT NEXTBILLINGDATE :" : "Prochaine Facture le : ",
    "BUYER RECURRENT TOP LABEL" : "Confirmation d'abonnement", 
    "RECURRENT WHAT ID :":"Référence : ",

    // catalogue des options payantes et plans d'abonnements
    "desc_payoptions_enable" : "Activation globale", 
    "post paidplan_plan_1" : "Abonelik planı #1", 
    "post paidplan_plan_2" : "Abonelik planı #2", 
    "post paidplan_plan_3" : "Abonelik planı #3", 
    "post paidplan_plan_0" : "Abonelik planı #0", 

    "post plan_1" : "Abonelik planı #1", 
    "post plan_2" : "Abonelik planı #2", 
    "post plan_3" : "Abonelik planı #3", 
    "post plan_0" : "Abonelik planı #0", 

    "Get details directly from PAYPAL" : "Canlı bilgi için sorgulama",

    "No entries in payments" : "Herhangi bir işlem yok",


    // new options for debug
    "desc_debug" : "Options de DEBUG/LOG", 
    "desc_debug_level" :  "Profondeur des logs",
    "desc_enable_trace_log" :  "Mesure temps execution",
    "desc_disable_translation" :  "Désactiver traductions",
    "desc_enable_debug_jstools" : "Outils JS de debug",
    "help_debug_level" :  "Quels types de messages ecrire dans le fichier SYSLOG ? : détermine quel types de messages doivent être écrits dans le fichier de debug/log - 7=ALL, 6=INFO, 5=NOTICE, 4=WARNINGS 3=ERRORS, 0=PANIC.",
    "help_enable_trace_log" :  "Mesaure et affiche pour chaque requéte AJAX les temps d'éxécution à travers le script",
    "help_disable_translation" :  "Désactiver les traductions permet de voir quel SPAN est utilisé en entrée du fichier de traduction.",
    "help_enable_debug_jstools" : "Outils Javascript de debug accessibles depuis le client",

    // ====== 6.1.2 ==============================================
    // welcome login text for users without ads
    "Welcome" :"Hoş geldiniz", 
    "Welcome %s %s !" : "Hoş geldiniz <strong>%s %s</strong> ! ", 
    "You don't have any ad yet. Do you want to create one ?" :"Henüz ilanınız yok,hemen bir reklam oluşturmak istiyormusunuz? ? ",
    "Create my first ad" :"İlk reklam oluşturma", 

    // lifecycle refactoring 
    "desc_ad life-cycle" : "Özel ilanlar",
    "desc_user life-cycle" : "Özel kullanıcılar",
    "desc_user_maxarchive_duration" : "Arşiv süresi", 
    "help_user_maxarchive_duration" : "Süresi dolan kullanıcıların Arşiv süresi.", 

    //livecheck
    "username already exist" : "Mevcut olmayan hesap adı", 
    "email already exist" : "Önceden kayıtlı e-posta",

    //protection côté serveur des validations d'annonces sur un pack "vide"
    "no tokens left on your subscribed services !" : "Üzgünüz,  bu ilan yayınlamak için  krediniz kalmadı.", 

    //--tutoriels videos
    // lien dans le menu
    "myvideos" : "Öğreticiler",
    // nom du breadcrumb   
    "bread_zetvu_as_video" : "Öğreticiler", 
    "all zetvu_as_video" : "Tüm öğreticiler", 
    "all my_zetvu_as_video" : "Tüm öğreticiler",
    "all admin_zetvu_as_video" : "Tüm öğreticiler",
    "bread_zetvu_as_news" : "Haberler", 
    "all zetvu_as_news" : "Tüm haberler", 
    "all my_zetvu_as_news" : "Tüm haberler",
    "all admin_zetvu_as_news" : "Tüm haberler",
    "zetvu" : "Zetévu",
    "all zetvu" : "Tous les Zetévu",  

    // barre principale de navigation 
    "nav_zetvu_as_video" : "Öğreticiler", 
    "nav_zetvu_as_news" : "Haberler", 

    //create button 
    "create_zetvu_as_video" : "Bir öğretici oluşturmak", 
    "create_zetvu_as_news" : "Bir haber oluşturmak", 

    // entete de la zone de creation
    " zetvu_as_video form header title" : "Öğreticinizi oluşturun", 
    " zetvu_as_video form header introduction" : " ", 
    " zetvu_as_news form header title" : "Bülteninizi oluşturun", 
    " zetvu_as_news form header introduction" : " ", 
    "modify zetvu_as_video form header title" : "Bir öğretici değiştirme", 
    "modify zetvu_as_video form header introduction" : " ", 
    "modify zetvu_as_news form header title" : "Bir bülteni değiştirme", 
    "modify zetvu_as_news form header introduction" : " ", 

    // configuration
    "desc_zetvu_as_video_tuto" : "Mode VIDEOS tutos", 
    "help_zetvu_as_video_tuto" : "Mode VIDEOS tutos : dans ce mode, un champ video est disponible pour ajouter des videos youtube ou autre. Elles sont alors affichées en mode gallerie",
    "desc_zetvu_visible_acl" : "Visible pour...",
    "help_zetvu_visible_acl" : "Niveau de control d'accés de visibilité des zetevu. 0=visible par tout le monde, 1=les utilisateurs enregistrés",

    // hover sur carte
    "This location has %s ad" : "%s ilan", 
    "This location has %s ads" : "%s ilan", 

    // email direct en utilisant le client natif du PC/MAC 
    "Direct Mail - title - I want to have more information" : "İlanınız hakkında daha fazla bilgi istiyorum", 
    "Direct Mail - body header - I want to have more information on element : " : "İlan hakkında daha fazla bilgi istiyorum : ", 
    "Direct Mail - body footer - I want to have more information on element." : "[Buraya ek metininizi girin .] ", 
 
    // contact form 
    "contact_form_firstname" : "Ad ", 
    "contact_form_lastname" : "Soyad ", 
    "contact_form_phone" : "Telefon ", 

    // new label forpassword change title 
    "desc_passwordchange" : "Şifre", 
    "modify my password" : "Şifre değiştir", 

    // now notification status 
    "You have services that will expire soon please consider buying new services " : "Dikkat , keşif paketi yakında sona erecek, ",

    // bouton create primiéres annonce dans services
    "Create first ad" : "Bir ilan yerleştirin", 

    //le à des dates 
    " by " :" ---> ",
    "help_disp_prosiret" : "SIRET numarası",

    // filters 
    "-- all protype --" : "-- Türü --", 
    "Sort by priceid asc" : "Isim Plan göre sıralayın (fiyat)",

    // traduction dédiée pour les "no results"
    "No items found - No ad - admin_all" : "Aucune annonce",
    "No items found - No ad - draft" : "Aucune annonce en brouillon",
    "No items found - No ad - published" : "Aucune annonce publiée",
    "No items found - No ad - pending" : "Aucune annonce en attente",
    "No items found - No ad - willexpire" : "Aucune annonce à expiration prochaine",
    "No items found - No ad - draft pending payment" : "Aucune annonce en attente de paiement", 
    "No items found - No ad - deleted_expired" : "Aucune annonce expirée",
    "No items found - No ad - deleted" : "Aucune annonce expirée",
    "No items found - No ad - admin_pending" : "Aucune annonce à valider",
    "No items found - No ad - admin_underreview" : "Aucune annonce à valider",
    "No items found - No ad - admin_willexpire" : "Aucune annonce à expiration prochaine",
    "No items found - No ad - admin_expired" : "Aucune annonce expirée",
    "No items found - No ad - admin_deleted" : "Aucune annonce expirée",
    "No items found - No ad - admin_published" : "Aucune annonce publiée",
    "No items found - No ad - admin_draft" : "Aucune annonce en brouillon",
    "No items found - No ad - admin_pending" : "Aucune annonce à valider",
    "No items found - No ad - admin_draftpendingpayment" : "Aucune annonce en attente de paiement",
    "No items found - No ad - admin_draft pending payment" : "Aucune annonce en attente de paiements", 
    "No items found - No ad - admin_willexpire" : "Aucune annonce à expiration prochaine",
    "No items found - No ad - admin_expired" : "Aucune annonce expirée",
    "No items found - No ad - admin_rejected" : "Aucune annonce rejetée",
    "No items found - No ad - admin_unpublished": "Aucune annonce retirée de la publication",

    "desc_robot_name" : "Nom ROBOT", 
    "help_robot_name" : "Nom à afficher lorsque'un action a été effecturée par un batch automatique du site", 


    // probanner url 
    "desc_probannerurl" : "Banniére (URL click)",
    "help_probannerurl" : "URL du site de destination quand on clique sur la banniére. Si 'vide', on utilise l'adresse du site web",

    "Are you sure you want to leave this form ?": "Bu formu ayrılmak istediğinizden emin misiniz ?", 
    "warning" : "Dikkat", 


    // new configurable options
    "desc_site_off_line" : "Site OFF-LINE", 
    "help_site_off_line" : "Mettre le site principal off-line. le back-end d'administration reste fonctionnel et les visiteurs sont redirigés vare une page statique 'offline_{langue}.php'. ", 
    "desc_sitemap_publishing_en" : "Auto-publication SITEMAP", 
    "help_sitemap_publishing_en" : "Publication automatique (PUSH) vers les principaux CRWALERS du web", 
    
    "desc_list_viewmodes" : "Listelerin  görüntüleme modu", 
    "desc_simple_list_view_en" : "Basit liste ", 
    "help_simple_list_view_en" : "Resim olmayan basit ilan listesi", 
    "desc_video_list_view_en" : "Videolu ilanları listele'", 
    "help_video_list_view_en" : " ", 
    "desc_audio_list_view_en" : "Sesli ilanları listele'", 
    "help_audio_list_view_en" : " ", 
    "desc_gmap_list_view_en" : "GMAP üzerinde listele", 
    "help_gmap_list_view_en" : " ", 
    "desc_gallery_list_view_en" : "Galeri listele", 
    "help_gallery_list_view_en" : " ", 

    "Show Video Gallery" : "Videolu ilanları görüntüle",

    "list filter on videogallery is ON" : "Dikkat, sadece videolu ilanlar görüntülü", 


    // champs pour les locations 
    "elem calendar" : "Fiyat ve mevcut durumu ", 
    "Display elem calendar" : "Fiyat ve mevcut durumular göster",
    "calendar list header text" : "Rezervasyonların listesi : ", 
    "Last updated:" : "Güncelleşme:",
    "Create bookings" : "Rezervasyon ekle", 
    "No entries in bookings" : "Şimdilik hiçbir rezervasyon", 

    "a_bo_moddate" : "Tarih",
    "a_bo_name" : "Başlık",
    "a_bo_lastname" : "Kiralayıcı",
    "a_bo_start_date" : "Başlangıç",
    "a_bo_end_date" : "Son",
    "a_bo_title" : "Etiket",

    " bookings form header title" : "Rezervasyon oluşturmak", 
    "modify bookings form header title" : "Rezervasyon değiştirme", 
    "bookings delete confirmation" : "Rezervasyon kaldır, sil ?", 

    "booking details" : "Ana Detayları", 
    "desc_bo_title" : "Etiket", 
    "help_bo_title" : "Gezinmek için bir etiket", 
    "desc_bo_start_end_date" : "Başlama ve bitiş tarihi ", 
    "placeholder_bo_start_date" : "Başlama", 
    "placeholder_bo_end_date" : "bitiş", 
    "desc_bo_nbadults": "Kişi sayısı", 
    "booking user details" : "Kiralayanın detay bilgileri",
    "desc_bo_gender" : "Cins",
    "desc_bo_comments" : "Yorumlar",
    "desc_bo_ad_id" : "ilanın referansı", 
    "help_bo_ad_id" : "Bu rezervasyon ile ilişkili ilan Kimliği", 
    "desc_bo_moddate" : "Son güncelleme", 
    "booking other details"  : "Diğer bilgiler", 

    // admin
    "manage_bookings" : "Rezervasyonlar",
    "manage_bookings_pending" : "Onaylanacak", 
    "help_manage_bookings" : "Rezervasyon yönetimi",
    "bookings creation ongoing": "Oluşturulan rezervasyon :",
    "allbookings" : "Rezervasyonlar", 
    "all bookings": "Rezervasyonlar (tümü)",
    "a_bo_ad_id" : "İlan kimliği", 

    "The start date can not be greater then the end date" : "Başlangıç tarihi bitiş tarihinden daha büyük olamaz", 
    "The end date can not be before the start date" : "Bitiş tarihi başlangıç tarihinden önce olamaz", 


    // settings pour le mode location
    "desc_rental mode" : "Mode Location", 
    "desc_rental_mode_en" : "Activer le mode", 
    "desc_calendar_auto_load" : "(CAL) Chargement auto.", 
    "desc_calendar_disable_before" : "(CAL) Dévalider jours AVANT", 
    "desc_calendar_week_start_day" : "(CAL) Jour de démarrage",
    "desc_cookie_save_calendar_nav" : "(CAL) Cookie mois",
    "desc_admin_acl_only_admin" : "Admin pour admin", 
    "desc_calendar_rolling_months": "Nombre mois affichés", 

    "help_rental_mode_en" : "Activer le mode location = affichage d'un calendrier de réservations", 
    "help_calendar_auto_load" : "(CAL) Chargement automatique des disponinilités", 
    "help_calendar_disable_before" : "(CAL) Dans le calendrier, les jours avant le jour courant sont dévalidé", 
    "help_calendar_week_start_day" : "(CAL) Jour de démarrage du calendrier (1=Lundi) ",
    "help_cookie_save_calendar_nav" : "(CAL) Suit la navigation du visiteur avec un cookie pour sauvegarder ses préférences de calendrier",        
    "help_admin_acl_only_admin" : "Le site d'administration est accessible uniquement pour les utilisateurs au profil ADMIN", 
    "help_calendar_rolling_months": "Nombre mois affichés", 


    "Admin site is not authorized to non admin people" : "Bu site yönetiminin yetkisiz kişilerin erişimine açık değildir !",     
    "Not authorized" : "Yetkisiz", 

    // debuf options in settings 
    "desc_debug_file" : "Fichier de LOG/DEBUG", 
    "help_debug_file" : "Gestion du Fichier de LOG/DEBUG", 
    "clear debug file" : "Effacer le contenu", 
    "open debug file" : "Voir le fichier", 
    "Error writing to the debug file":"Error lors de l'accés au fichier de debug/log", 
    "File cleaned successfully":"Fichier effacé.", 


    // options pour FEEDBACK form 
    "feedback reason" : "Nedeni",
    "Fraud":"Dolandırıcılık",
    "Wrong category":"Yanlış kategori",
    "Expired ad":"İlan süresi doldu",
    "Other":"Diğer",

    // special login form 
    "Login with third party credentials" : "ile kendini tanımlamak  ", 
    "facebook login":"Facebook ile bağlan", 
    "google login":"Google ile bağlan", 
    "twitter login":"Twitter ile bağlan", 
    "linkedin login":"Linkedin ile bağlan", 
    "login or" : " veya ",

    "auth-type-go" : "Google", 
    "auth-type-fb" : "Facebook", 
    "auth-type-tw" : "Twitter", 
    "auth-type-" : "Local", 

    "login_lostpassword": "Şifremi unuttum ?",
    "login_createaccount": "Henüz hesabın yokmu ?",
    "login_rememberme" : "Beni hatırla",

    " user form header oauth " : "... üzerinden giriş yapabilirsiniz",
    "oauth register with facebook" : "FACEBOOK hesabınız", 
    "oauth register with google" : "GOOGLE hesabınız", 
    "oauth register with linkedin" : "LİNKEDİN hesabınız", 
    "oauth register with twitter" : "Twitter hesabınız", 

    "google account" : "GOOGLE  hesabı",
    "facebook account" : "FACEBOOK hesabı", 
    "twitter account" : "TWITTER hesabı", 
    "linkedin account" : "LINKEDIN hesabı",  
 

    "This form has been pre-filled with inputs from your " : "La formulaire a été pre-rempli avec les données de votre ", 

    "desc_social_sharing":"Réseaux sociaux",
    "desc_fb_integration":"Widget LIKE Facebook",
    "desc_fb_url":"URL FACEBOOK",
    "desc_fb_auth":"Autent. FACEBOOK",
    "This form has been pre-filled with inputs from your": "Le formulaire a été renseigné avec les données de votre ", 

    "help_social_sharing":"Indique la liste des réseaux sociaux pour le bouton 'partager sur' : TW=TWITTER, FB=FACEBOOK, GO=GOOGLE+,, LK =LINKEDIN",
    "desc_facebook_settings" : "FACEBOOK configuration", 
    "help_fb_integration":"Intégration du widget Like de FACEBOOK sur la page d'accueil. Renseigner l'URL facebook ci-dessous obligatoirement",
    "help_fb_url":"URL du compte FACEBOOK",
    "help_fb_auth":"Permettre une connection au site par une autentification FACEBOOK. ATtention, necessite de déclarer l'application auprés de facebook et renseigner l'application-id dans le champ ci-dessous.",
    "desc_fb_appid" : "Application_ID", 
    "help_fb_appid" : "Application_ID = utilisé lorsque vous activez l'autentification via facebook comme identifiant de votre application. Réserver un App-ID via la console Facebook developpers.", 

    "desc_google_settings" : "GOOGLE configuration", 
    "desc_go_client_id" : "CLIENT_ID", 
    "help_go_client_id" : "CLIENT_ID = utilisé lorsque vous activez l'autentification via Google API comme identifiant de votre application. Réserver un App-ID via la console GOOGLE API.", 
    "desc_go_auth":"Autent. GOOGLE",
    "help_go_auth":"Permettre une connection au site par une autentification GOOGLE. Attention, necessite de déclarer l'application auprés de GOOGLE et renseigner le client-id dans le champ ci-dessous.",

    "desc_twitter_settings" : "TWITTER configuration", 
    "desc_tw_appid" : "API Key", 
    "help_tw_appid" : "API Key = utilisé lorsque vous activez l'autentification via TWITTER API comme identifiant de votre application.", 
    "desc_tw_auth":"Autent. TWITTER",
    "help_tw_auth":"Permettre une connection au site par une autentification TWITTER. Attention, necessite de déclarer l'application auprés de TWITTER et renseigner le API-id dans le champ ci-dessous.",
    "desc_tw_secret":"API secret",
    "help_tw_secret":"API secret key",

    "desc_linkedin_settings" : "LINKEDIN configuration", 
    "desc_lk_appid" : "API Key", 
    "help_lk_appid" : "API Key = utilisé lorsque vous activez l'autentification via LINKEDIN API comme identifiant de votre application.", 
    "desc_lk_auth":"Autent. LINKEDIN",
    "help_lk_auth":"Permettre une connection au site par une autentification LINKEDIN. Attention, necessite de déclarer l'application auprés de LINKEDIN et renseigner le API-id dans le champ ci-dessous.",
    "desc_lk_secret":"API secret",
    "help_lk_secret":"API secret key",

    "desc_disable_localization_validation"  : "Désactiver contrôles", 
    "help_disable_localization_validation"  : "Désactiver les contrôles liés à la localisation des champs PHONE, ZIP-CODE, ...", 

    "desc_scroll_top_px" : "Scroll top", 
    "help_scroll_top_px" : "En pixels, contrôle la hauteur de remontée de la page lors d'un re-centrage vertical automatique.", 

    "desc_hascalendar" : "Calendrier de location",
    "help_hascalendar" : "Associer à toutes les annonces de cette catégorie un calendrier de réservation. Attention, l'option 'LOCATION' doit être activée! ", 

    "pics" : "images",
    "a_parentid":"Parent", 
    "a_adultflag" : "adult?" ,
    "a_catlvfields" : "Champs", 
    "a_hascalendar" : "Cal.", 

    "all cats" : "Toutes les catégories", 
    "Create cats" : "Créer une catégorie", 

    "admin_cat_type_ad":"Annnonce uniq.", 
    "admin_cat_type_user":"Usagers uniq.",
    "admin_cat_type_":"Tous",

    "admin_ad_type_sell":"vend",
    "admin_ad_type_buy":"demande",
    "admin_ad_type_zetvu":"news/zetvu",

    "desc_desc_max_char" : "Desc. MAXCHARs", 
    "help_desc_max_char" : "Nombre maximum de caractères (max 1500) du champ description.", 

    "desc_rental_mode_all_cat" : "Sur toutes les annonces", 
    "help_rental_mode_all_cat" : "Si activé, toutes les annonces posséde un calendrier et le mode location. Si désactivé, il faut renseigner au niveau de CHAQUE catégorie le mode calendrier. ", 


    "desc_user_no_expiration_for_admin" : "ADMIN expire jamais",
    "help_user_no_expiration_for_admin" : "Les comptes de type administrateurs n'expireront pas",  

        //6.5.0 
    "upload audio file" : "Bir ses dosyası seçin", 
    "upload image file" : "Bir görüntü seçin", 

    "Show Audio Gallery" : "Ses medyali ilanları göster",
    "list filter on audiogallery is ON" : "Dikkat sadece Ses medyali ilanları görüntülenir", 

    "Your browser does not support the audio element." : "Tarayıcınız ses işlevini desteklemiyor.", 
    "title audiourl" : "sesli mesage", 
    "title audiourl user" : "sesli mesage",
    "play/pause" : "Oynat/Duraklat", 
    "volume up/down/mute" : "Volume (+/-/mute)",
    "next track" : " Bir sonraki sesli mesaj",  
    "Click to play/stop : %s" : "Oynatmak/durdumak için tıkla : %s", 

    "desc_audiourl" : "sesli mesajlar",
    "help_audiourl %s" : "WAV veya MP3 formatında %s sesli mesaj (lar) ekleyebilirsiniz", 



    "desc_audio settings" :"Champs audio / vocal",
    "desc_audio_ad_en" :"Activer sur annonce",
    "desc_audio_user_en" :"Activer sur usager",
    "desc_audio_file_max_size" :"Taille max/audio",
    "desc_audio_file_max_nbr" :"Nbr max audio",
    "desc_audio_file_ext" :"Extensions",
    "desc_audio_file_download" :"Téléchargement?",
    "desc_audio_autoplay" :"Jouer automatiquement",
    "desc_audio_rec_online" :"Enregistrement",
    "desc_audio_rec_max_duration" :"Enreg. durée",
    "desc_audio_rec_ext" :"Enrge. extension",


    "help_audio_ad_en" :"Activer sur annonce : permettre l'ajout de medias audios sur une annonce.",
    "help_audio_user_en" :"Activer sur usager : permettre l'ajout de medias audios sur une annonce.",
    "help_audio_file_max_size" :"Taille max de chaque média audio chargé sur le site.",
    "help_audio_file_max_nbr" :"Nbr max de media audio par annonce ou usagers.",
    "help_audio_file_ext" :"Extensions autorisées des médias audios chargés.",
    "help_audio_file_download" :"Afficher un bouton qui permet au visiteur de téléchargement le fichier audio.",
    "help_audio_autoplay" :"Jouer automatiquement lors de l'affichage de l'annonce/annonceur.",
    "help_audio_rec_online" :"Enregistrement en ligne de messages audio. ",
    "help_audio_rec_max_duration" :"Durée max en secondes de l'enregistrement en ligne.",
    "help_audio_rec_ext" :"Format du fichier enregistré en ligne.",


    "desc_watermark" :"Filigrane sur images",
    "desc_watermark_en" :"Activer",
    "desc_watermark_file_url" :"URL du Filigrane",
    "desc_watermark_free_text" :"Text libre",
    "help_watermark_en" :"Activer l'ajout de filigrane (watermark) sur les images chargées sur le site.",
    "help_watermark_file_url" :"URL du Filigrane : url d'un fichier PNG ou autre qui sera utilisé comme filigrane. Attention, lechemin est relatif au repertoire /phpsvr. exemple d'URL valide = ../uploads/files/xxx.png",
    "help_watermark_free_text" :"Text libre qui sera utilisé en filigrane (si pas d'URL renseignée ci-dessus). ",


    // securedemail and phone numbers 
    "see the email" : "Voir l'adresse email", 
    "see the phone" : "voir le numero", 
    "desc_email_as_image_en" : "Email en image", 
    "desc_phone_as_image_en" : "Tél. en image", 
    "help_email_as_image_en" : "ANTI-SPAM : Email en image : l'email de l'annonceur est affiché comme une image et non un texte", 
    "help_phone_as_image_en" : "ANTI-SPAM : Tél. en image  : le teléphone  de l'annonceur est affiché comme une image et non un texte", 


    "footer title to add services" : "footer title to add services", 
    "footer text to add services" : "footer text to add services",

    // new menus 
    "gotoadmin" : "Administration", 
    "gotosite" : "Voir le site", 

    // free texte onsubscribtions / packs 
    "settings_free_texts" :"Textes libres", 
    "settings_free_text1" :"Texte 1", 
    "settings_free_text2" :"Texte 2", 
    "settings_free_text3" :"Texte 3", 

    "desc_social_connect_general" : "Social Login",
    "desc_oauth_sso_en" : "Activer oauth", 
    "desc_oauth_auto_create_user" :"Creation auto accés", 
    "help_oauth_sso_en" : "Activer la connection SOCIAL pour accéder au site via les réseaux sociaux ci-dessous.", 
    "help_oauth_auto_create_user" :"Creation automaique des comptes usagers sans passer par l'enregistrament. Attention, pas compatible avec les plans d'abonnements", 


    //6.5.1
    "Thanks you for your payment %s %s ! Your service is activated." : "Alış verişiniz için teşekkürler %s %s, hizmet paketiniz aktiftir.", 
    "desc_cust_cookie_url" : "Cookies (url)", 
    "help_cust_cookie_url" : "Lien (utl) ver page Cookies", 
    // nom du lien en bas de page 
    "Cookies" :"Cookies", 

    "desc_list_default_view" : "Vue par défaut", 
    "help_list_default_view" : "vue par défaut lors de l'affichage des listes d'annonces. Les valeurs possibles sont   : list | simplelist  | gallery  | videogallery | audiogallery | maplist  ",

    "desc_cookie_display_cookies_disclamer": "Avertissement cookies", 
    "help_cookie_display_cookies_disclamer": "Affiche un message d'avertissement legal sur les cookies lors de la premiére visite", 
    "Cookies policy disclamer": "bu sitede gezinirken,sitenin doğru çalışması için lazım olan tanımlama bilgilerini kullanmayı kabul ediyorsunuz.    <a class='cookiesWarning-link' href='cookies_fr_zads.php' target='_blank'>politikamız hakkında daha fazla bilgi « cookies ».</a>",

    // sysem messages displayed in ADMIN
    "SYS - delete install.php":"Merci de supprimer le fichier <strong>install.php</strong> pour des raisons de sécurité.", 
    "SYS - debug mode and level > 3 if active" : "Le mode debug est actif avec un niveau elevé (>3) d'informations. Risque de sécurité.",

    //6.5.3 
    "desc_dis_ad_loc" : "Pas de Locat. AD", 
    "help_dis_ad_loc" : "Désactiv. la saisie de la localisation pour les annonces.", 
    "desc_dis_user_loc" : "Pas de Locat. USER", 
    "help_dis_user_loc" : "Désactiv. la saisie de la localisation pour les usagers.", 

    "desc_user_cat2" : "Type d'activité", 
    "desc_cat2" : "Activité", 

    "desc_advs_no_freetext" : "Pas champ recherche",
    "help_advs_no_freetext" : "Le champ de recherche libre est masqué",

    "desc_advs_forced_vfields" : "Ajouter toujours vfields ..", 
    "help_advs_forced_vfields" : "Ce mode permet d'afficher de champs VFIELDS systématiquement sur la barre de recherche. format = idA|idB|idC", 

    
    "desc_nav_no_bar" : "Pas be barre de nav.",
    "help_nav_no_bar" : "Mode expert ! pas de barre de navigation principale. Pas compatible avec un affichage de carte ou de pages spéciales !",

    "desc_maincat_user_pid" : "Nav User per PID", 
    "help_maincat_user_pid" : "Mode expert !  : la barre de navigation affichant les usagers est découpée fonction des catégories users de niveau 1.", 

    "%s room" : "%s oda", 
    "%s rooms" : "%s oda", 

    "filtered : %s" : " filtré : %s", 

    "desc_seo_forced_vfields" : "SEO champs en plus", 
    "help_seo_forced_vfields" :"Liste (ID|ID|ID) des valeures de champs vistuels à ajouter dans le meta/SEO des annonces affichées.",
    "desc_no_mobile_css" :"No mobile CSS",
    "help_no_mobile_css" :"Désactiver le théme mobile",

    "settings_ad_audiourl" : "Max fichiers audios", 
    "settings_ad_videourl" : "Max fichiers videos", 
    "ad_audiourl" : "Fichiers audios par annonce", 
    "ad_videourl" : "Fichiers videos par annonce",

    "settings_us_audiourl" : "Max fichiers audios", 
    "settings_us_videourl" : "Max fichiers videos", 
    "us_audiourl" : "Fichiers audios / profile", 
    "us_videourl" : "Fichiers videos / profile", 

    "desc_emails_admin_hourly_send" : "Notification horaire", 
    "help_emails_admin_hourly_send" : "Notification horaire", 
    "desc_en_ad_hits" : "Hits", 
    "help_en_ad_hits" : "Hits", 
    "desc_en_ad_likes" : "Likes", 
    "help_en_ad_likes" : "Likes", 
    "desc_en_user_hits" : "Hits", 
    "help_en_user_hits" : "Hits", 
    "desc_en_user_likes" : "Likes", 
    "help_en_user_likes" : "Likes", 

    // likes management
    "click to like it!" : "Beğendiniz demek için tıklayınız.!",
    "Sort by likes desc" : "En sevilene göre sırala",

    "cannot upload more file : exceeded quantity" : "kota geçildi,fazla dosya yüklemek imkansız !", 

    "desc_reset_all_user_likes" : "Réinitialiser likes usagers",
    "help_reset_all_user_likes" : "Réinitialiser (remet à zero) le compteur de like de tous les usagers.",
    "desc_reset_all_ad_likes" : "Réinitialiser likes annonces",
    "help_reset_all_ad_likes" : "Réinitialiser (remet à zero) le compteur de like de toutes les annonces.",
    "reset_all_user_likes" : "Réinitialiser",
    "reset_all_ad_likes" : "Réinitialiser",


    "desc_page_php" : "Page home Externe (PHP)", 
    "desc_page_home_is_php" : "Activer", 
    "help_page_home_is_php" : "Si activé, la page d'accueil est chargée à partir de la page PHP ci-dessous.", 
    "desc_page_home_php_url" : "Url de la page externe",
    "help_page_home_php_url" : "Url de la page externe contenant le contenu PHP a charger sur la page d'accueil",

    //Z6.5.6 -> multi-medias elemnts 
    "media booth h1 - audio_recording" : "Kayıt kabini", 
    "media booth into - audio_recording" : "Sesli mesajınızı kayıt yeri", 
    "visu in title" : "giriş : giriş frekansı ", 
    "visu out title" : "Çıkış", 
    "record" : "Şimdi kayıt",
    "recording"  : "Kayıt devam ediyor - Durdurun", 
    "rec play" : "Kaydı dinle", 
    "(rec playing) stop" : "(Dinlemede) - Durdurun", 
    "rec download" : "Bilgisayarıma indir",
    "rec save" : "Anonsa kopyala",

    "media booth h1 - picture_snap" : "Foto kabini", 
    "media booth into - picture_snap" : "Burada fotoğraflarızı çekin..", 
    "take screenshot" :"Fotoğraf çek",
    "video in title" : "Giriş : video", 
    "video out title" : "Fotoğrafınız",
    "snap effect" : "Efekt uygulayın.", 
    "snap download" : "Bilgisayarıma indir",
    "snap save" : "Anonsu kopyala",





    // end 
    'dummy' : 'idiot'
    }; 
