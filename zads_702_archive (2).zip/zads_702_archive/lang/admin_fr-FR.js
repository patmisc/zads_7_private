// JavaScript Document
// french language file  version 6.5.8


admin_my_dictionary['fr_FR'] = { 

    "desc_banner_title" :"Titre",
    "desc_banner_htmlcode": "Code Html",
    "desc_banner_clicktrackingurl": "URL clicktracking", 
    "desc_banner_startdate": "Date de début", 
    "desc_banner_enddate": "Date de fin", 
    "desc_banner_position": "Emplacement", 
    "desc_banner_clicks": "Clicks", 
    "desc_banner_impressions": "Impressions", 
    "desc_banner_CTR": "CTR", 

    "help_banner_title" :"Titre de la bannièrepour vous aider à l'identifier",
    "help_banner_htmlcode": "Code HTML de la banniére. Dans le cas d'une bannière'background_all (fond ecran)', indiquez uniquement l'url de la publicité. Le javascript est supporté (adsense). ",
    "help_banner_clicktrackingurl": "URL qui redirigera les utilisateurs lors d'un click sur la publicité", 
    "help_banner_startdate": "Date de début de publication", 
    "help_banner_enddate": "Date de fin de publication", 
    "help_banner_position": "Emplacement de la publicité sur le site", 
    "help_banner_clicks": "Nombre de clicks sur la publicité", 
    "help_banner_impressions": "Nombre d'impressions sur le site", 
    "help_banner_CTR": "CTR =  Click Trhough Ratio  =  nbr de clicks / nbr d'impressions",

    "desc_parentid" : "Cat. parente", 
    "help_parentid" : "Si vous souhaitez des catégories à 2 niveaux, sélectionner ici une catégorie parente. Sinon, laisser à SELECTIONNER. Uniquement 2 niveaux possibles. ", 
  

    "settings_v" : "visible", 
    "settings_us_protype" : "Annuaire pro",
    "settings_us_skills"  : "Catégorie (s)",
    "settings_us_avatarimg"  : "Logo",
    "settings_us_bio"  : "Courte présentation",
    "settings_us_longdesc"  : "Longue présentation",
    "settings_us_folioimg"  : "Galerie photos",
    "settings_us_videoembed"  : "Lien Video",
    "settings_us_phone" : "Téléphone",
    "settings_us_dispemail" : "E-mail",
    "settings_us_subscription" : "Jours accès",
    "settings_ad_nb" : "Max annonces",
    "settings_ad_nbpics" : "Max images par annonce",
    "settings_ad_duration" : "",
    "settings_ad_featured" : "",
    "settings_ad_perm" : "",
    "settings_ca_restricted" : "",
    "settings_ad_videoembed" : "Lien Video", 
    "settings_ad_links": "Max liens", 
    "settings_ad_enemail":"Contact E-mail", 
    "settings_ad_enphone":"contact Tél.", 
    "settings_ad_duration":"Durée (jours) de l'annonce", 
    "settings_ad_duration":"*** ne pas utiliser ***", 
    "settings_ad_nbvideos" : "Max videos (embed)", 
    "settings_ad_urgent" : "Forcée URGENTE", 
    "settings_ad_featured":"Forcée A LA UNE",
    "settings_ad_perm":"Forcée PERMANENTE",

    // Z6.1.2 - temporary removed as no actions yet seesettings
    "settings_ad_urgent" : "*** ne pas utiliser ***", 
    "settings_ad_featured":"*** ne pas utiliser ***",
    "settings_ad_perm":"*** ne pas utiliser ***",


    "settings_us_social":"** do not use **",
    "settings_us_links":"Max liens",
    "settings_us_prowebsite" : "Site web pro", 
    "settings_ca_restriction" : "Uniquement Cat. ID",

    "settings_duration" : "Durée (jours)",
    "settings_bgcolor" : "CSS color",
    "settings_type" : "Type",
    "settings_xtype" : "XType",

    "settings_radio_base" : "Base", 
    "settings_radio_trial" : "Trial", 
    "settings_radio_" : "Service", 

    "settings_default" : "Par défaut",
    "settings_pricedesc" : "Description (prix)", 
    "settings_name" : "Nom", 
    "settings_payoption" : "Reference Cat.",
    "settings_price_type" : "Structure", 
    "settings_radio_flat" : "Unique", 
    "settings_radio_volume" : "Volume",
    "settings_ad_details" : "Contenu du pack (annonces)", 
    "settings_us_details" : "Contenu du pack (compte)",
    "settings_prices_details" : "Structure de prix",  
    "settings_n" : "Prix ID",
    "settings_ttc" : "Prix (TTC)",
    "settings_ht" : "Prix (HT)",

    "desc_label_plan" : "Type d'abonnement", 
    "desc_plan" : "Abonnement" ,


    // end 
    'dummy' : 'idiot'
    }; 

