// JavaScript Document
// western europe 1252

if  (typeof monthnb_2_string == 'undefined')  var monthnb_2_string = []; 
if  (typeof daynb_2_string == 'undefined')  var daynb_2_string=[]; 
if  (typeof my_dictionary == 'undefined')  var my_dictionary=[]; 


 monthnb_2_string['ar_AR'] ={
  1 : "ÌÇäÝí",
  2 : "ÝíÝÑí", 
  3 : "ãÇÑÓ",
  4 : "ÃÝÑíá",
  5 : "ãÇí",
  6 : "ÌæÇä",
  7 : "ÌæíáíÉ",
  8 : "ÃæÊ",
  9 : "ÓÈÊãÈÑ",
  10 : "ÃßÊæÈÑ",
  11 : "äæÝãÈÑ",
  12 : "ÏíÓãÈÑ"
}

daynb_2_string['ar_AR'] ={
  0 : "ÇáÃÍÏ",
  1 : "ÇáÅËäíä", 
  2 : "ÇáËáÇËÇÁ",
  3 : "ÇáÃÑÈÚÇÁ",
  4 : "ÇáÎãíÓ",
  5 : "ÇáÌãÚÉ",
  6 : "ÇáÓÈÊ"
}

my_dictionary['ar_AR'] = { 
    // genéral dates : 
    "yesterday"  : "ÃãÓ",
    "today"  : "Çáíæã",
    "tomorrow" : "ÛÏÇ",
    "%s day ago" :"%s ÃíÇã",
    "%s days ago" :"%s íæã",
    "till "  : "Çáì ÛÇíÉ ", 
    "yes" : "äÚã", 
    "no" : "áÇ", 
    
    "in %s day" :"ÎáÇá %s ÃíÇã",
    "in %s days" :"ÎáÇá %s íæã",
    "days" : "íæã", 
    "day" : "ÃíÇã", 
    "the" : "", 
    "the " : " ",
    
    "%s ads" : "%s ÇÚáÇä" ,
    "%s ad" : "%s ÇÚáÇäÇÊ" ,
    "no ad" : "áÇ íæÌÏ ÇÚáÇäÇÊ",
    
    
    "%s cats" : "%s ÃÞÓÇã" ,
    "%s cat" : "%s ÞÓã" , 
    
    "%s users" : "%s ãÓÊÎÏãíä" ,
    "%s user" : "%s ãÓÊÎÏã" ,
    
    "no user" : "áÇ íæÌÏ ãÚáäíä",
    
    // global 
    "more" : "ÊÝÇÕíá ÃßËÑ",
    "Load more" : "ÇáãÒíÏ", 

    // offline 
    "Site is offline" : "ÇáãæÞÚ ãÛáÞ", 
    "Site is no more available." : "ÇáãæÞÚ ÛíÑ ãÊÇÍ ÍÇáíÇ",

    
    // general BROWSER detection messages
    "You're using IE8 or above" : "Vous utilisez IE 8 ou sup.",
    "You're using IE7.x" :  "Vous utilisez IE 7.x ",
    "You're using IE6.x" :  "Vous utilisez IE 6.x ",
    "You're using IE5.x" :  "Vous utilisez IE 5.x ",
    ': this browser is partialy supported . See the list <a href="navsupported_fr.html">here</a>' : ' : ce navigateur est partiellement supporté. Voir la liste <a href="navsupported_fr.html">ici</a>',
    
    // general navigation 
    "Main cat sell" : "ÇÚáÇäÇÊ",
    "Main cat buy" : "ØáÈÇÊ", 
    "Main cat user" : "ãÊÇÌÑ", 
    "Zetvu" : "Zetévu",
    "my admin" : "[ ÇÏÇÑÉ ]", 
 
    // boutons de creation 
    "add a cat"  : "ÃÖÝ ÞÓã",
    "add a user"  : "ÃÖÝ ãÓÊÎÏã",
    "add a sell"  : "ÃÖÝ ÇÚáÇäß",
    "add a buy"  : "ÃÖÝ ÇÚáÇäß",
    
    // texte d'introduction  aux formulaires 
    " ad form header title"  : "ÅÚáÇäß: ",
    " ad form header introduction" : "ÃÖÝ ÇÚáÇäß ãÌÇäÇ ÚÈÑ ãáÆ åÐÇ ÇáäãæÐÌ<br>ÓíÊã äÔÑå ÈÚÏ ÇáãæÇÝÞÉ Úáíå ãä ÞÈá ÇáÇÏÇÑÉ. ãÏÉ ÙåæÑ ÇÚáÇäß åí ÓÊæä íæãÇ<br>íÌÈ Úáíß ãáÆ ÇáÍÞæá ÇáÇÌÈÇÑíÉ ÇáãÚáãÉ ÈÜ (*)<br> ",
    
    "preview ad form header title"  : "ãÚÇíäÉ ÇÚáÇäß: ",
    "preview ad form header introduction"  : "ÊÍÞÞ ãä ãÍÊæì ÅÚáÇäß ÞÈá äÔÑå. Úáíß ÞÈæá ÔÑæØ ÇáäÔÑ æÇáÇÓÊÎÏÇã",
    
    
    "modify ad form header title"  : "ÊÚÏíá ÇÚáÇäß: ",
    "modify ad form header introduction" : "ÚÏá ÇÚáÇäß ãÌÇäÇ ÚÈÑ ãáÆ åÐÇ ÇáäãæÐÌ<br>ÓíÊã äÔÑå ÈÚÏ ÇáãæÇÝÞÉ Úáíå ãä ÞÈá ÇáÇÏÇÑÉ. ãÏÉ ÙåæÑ ÇÚáÇäß åí ÓÊæä íæãÇ<br>íÌÈ Úáíß ãáÆ ÇáÍÞæá ÇáÇÌÈÇÑíÉ ÇáãÚáãÉ ÈÜ (*). <br> ",


    " user form header title"  : "ÇáÊÓÌíá : ",
    " user form header introduction" : "Þã ÈÇáÊÓÌíá ãÚäÇ ÚÈÑ ãáÆ åÐÇ ÇáäãæÐÌ.<br>íÌÈ Úáíß ãáÆ ÇáÍÞæá ÇáÇÌÈÇÑíÉ ÇáãÚáãÉ ÈÜ (*). ",
    " user form header introduction facebook" : "íãßäß ÊÓÌíá ÇáÏÎæá Úä ØÑÞ <span class='icon-menu' id='facebook'><span class='icon'></span><a href='#' what='facebook'  name='action-on-elem' class='text'>ÍÓÇÈß Ýí ÇáÝíÓÈæß.</a></span><br> ",

    "preview user form header title"  : "ÇáÊÍÞÞ ãä ãÚáæãÇÊß: ",
    "preview user form header introduction"  : "ÊÍÞÞ ãä ÊÝÇÕíá ÍÓÇÈß æ Þã ÈÊÃßíÏåÇ. ÑÌÇÁÇ Þã ÈÇáãæÇÝÞÉ Úáì ÔÑæØ ÇáãæÞÚ.",
    

    "modify user form header title"  : "ÊÚÏíá ãÓÊÎÏã: ",
    "modify user form header introduction" : "A travers ce formulaire, modifier un usager existant du site.<br>Merci de pendre en compte les champs obligatoires marqués d'une étoile. <br> ",

    "modify curuser form header title"  : "ÊÚÏíá ÍÓÇÈí: ",
    "modify curuser form header introduction" : "A travers ce formulaire, modifier mon profil.<br>Merci de pendre en compte les champs obligatoires marqués d'une étoile. <br> ",


    " cat form header title"  : "ÞÓã ÌÏíÏ: ",
    " cat form header introduction" : "A travers ce formulaire, créer une nouvelle catégorie. <br>Elle sera disponible immédiatement.<br>Merci de pendre en compte les champs obligatoires marqués d'une étoile. <br> ",
    
    "modify cat form header title"  : "ÊÚÏíá ÞÓã: ",
    "modify cat form header introduction" : "A travers ce formulaire, modifier une catégorie. <br>Elle sera disponible immédiatement.<br>Merci de pendre en compte les champs obligatoires marqués d'une étoile. <br> ",

    " zetvu form header title"  : "ÊÏæíäÉ ÌÏíÏÉ: ",
    " zetvu form header introduction" : "Créer un message simple, ludique et anonyme par ce ZeTvu (prononcer 'ze té vu').<br> ",
    
    "modify zetvu form header title"  : "ÊÚÏíá ÇáÊÏæíäÉ:",
    "modify zetvu form header introduction" : "A travers ce formulaire, modifier votre ZeTeVu. <br>Elle sera disponible immédiatement.<br>Merci de pendre en compte les champs obligatoires marqués d'une étoile. <br> ",


    // Formulaire de saisie d'un user
    "username"  : "ÇÓã ÇáãÓÊÎÏã",
    "firstname"  : "ÇáÇÓã",
    "lastname"  : "ÇááÞÈ",
    "password"  : "ßáãÉ ÇáãÑæÑ",
    "password from "  : "ßáãÉ ÇáãÑæÑ ãä ",
    "confirm password"  : "ßáãÉ ÇáãÑæÑ(2)",
    "more user details" : "ÊÝÇÕíá",
    "log-in details" : "Connexion",
    "user email" : "ÇáÈÑíÏ ÇáÇáßÊÑæäí",
    "user phone" : "ÑÞã ÇáåÇÊÝ",
    "phone" : "ÇáåÇÊÝ",
    "location" : "ÇáÎÇÑØÉ",
    "user upload picture" : "ÕæÑÉ",
    "change password"  : "ÊÛííÑ ßáãÉ ÇáãÑæÑ",
    "retype the password to confirm" : "ÊÃßíÏ ßáãÉ ÇáãÑæÑ",
    
    "help email rules" : "format doit etre de type toto@service.ext",
    "help passord rules" : "doit avoir au moins 5 caractéres avec des majuscules, minuscules , chiffres, caractéres spéciaux, .. ",
    
    /* améliorations ZADS4.0 pour le formulaire User*/
    "bio and skills details" :"Bio & compétences",
    "user bio" : "Votre devise",  
    "user skills" : "Compétences",
    "skills" : "Compétences",
    "contact details" : "détails", 
    "contact actions" : "actions", 
    "selected skills" : "Vos compétences",
    "select a skills" : "Selectionnez vos compétences",
    // formulaire de saisie de compétences
    "rating_level_1" : "débutant", 
    "rating_level_2" : "amateur",
    "rating_level_3" : "amateur éclairé",
    "rating_level_4" : "semi-pro",
    "rating_level_5" : "professionnel",
    "rating please select something" : "indiquer votre niveau", 
    "add_skills" : "ajouter cette compétence",
    "remove_skill" : "supprimer",
    
    "user upload pictures" : "Images / portfolio", 
    "upload folioimg" : "ajouter une image",
    "upload filename" : "ajouter une image",    
    "user upload portofolio help %s" : "Charger des images qui serviront de portfolio a votre activité. Jusqu'a %s images.",
    
    "user upload avatar" : "Avatar", 
    "upload avatarimg" : "ajouter une photo", 
    "user upload avatar help %s" : "Charger une photo qui serviera d'avatar (format : carte d'identité 207 x 266) pour votre mini-fiche",
    
    "declare pro user" : "Professionnel",
    "type of user account" : "Type de compte", 
    "professionnal details" : "Professionnel",
    "ad company name" : "Raison Sociale", 
    //"ad siret" : "SIRET",  
    
    "ad siret" : "TVA", 

    "ad website" : "Site web",
    "link to website" : "Site web",
    "ad banner" : "Banniére", 
    "upload probannerimg" : "Ajouter une Banniére",
    "post ad banner" : "format xxx",
    "help ad banner %s" : "Charger une banniére (format : Leaderboard 728 x 90)qui sera en haut de page de votre mini-fiche",

    "user location" : "Adresse",  
    "user loczipcode" : "code postal", 
    "user loccity" : "ville", 
    "user locdept" :"department", 
    "user locregion" : "region",
    
    "usertype" : "droits",
    "registerdate" : "crée le", 
    "lastvisitdate" : "derniére visite le", 
    "id" : "identifiant",
    
    /* messages pour les conseils du checker de passwords */ 
    "shortPass" :" Trop court ! " ,   
    "badPass":" Pas assez robuste !", 
    "goodPass":" Bon !",   
    "strongPass":" Robuste !",   
    "samePassword":" identifque au login. pas bien !",  
    
    "gender"  : "Je suis ",
    "male" : "un homme", 
    "female" : "une femme",
    
    "locale"  : "Langue princip.",
    "fr_FR"  : "francais",
    "en_GB"  : "anglais (UK)",
    "en_US"  : "anglais (USA)",
    "de_DE"  : "allemand",
    "nl_NL"  : "hollandais",
    "ar_AR"  : "arabe",

    "user auth" : "Autentification", 
    "fb" : "facebook",
    "auth type fb" : "facebook",
    "auth type " : "locale",
    "content via facebook" : "via facebook", 
    "login_facebook" : "Utiliser son compte Facebook",
    "facebook login description" : "Utiliser votre compte Facebook pour autentifier sur ce site.",
    "or" : "ou",  
    "Error in FACEBOOK authentification" : "Une erreur est survenue lors de l'autentification via Facebook.",
    
    "login_google" : "Utiliser son compte Google",
    
    // formulaire pour les catégories
    "cat title"  : "Nom",
    "cat description"  : "Description de la catégorie",
    "cat upload picture" : "Photo(s)",
    "help cat title" : "nom de la catégorie", 
    "desc cat type" : "Type de catégorie", 
    
    "cattype_ad" : "pour annonces", 
    "cattype_user" : "pour usagers",
    "cattype_" : "pour tous",  
    
    "help_on_cattype cattype_" : "Cette catégorie peut servir pour des annonces ou des usagers/annonceurs.", 
    "help_on_cattype cattype_user" : "Cette catégorie peut servir pour des usagers/annonceurs", 
    "help_on_cattype cattype_ad" : "Cette catégorie peut servir pour des annonces", 
    
    // formulaire pour les zeTvu
    "<b>Je tai vu ...</b>" : "<b>Je t'ai vu ...</b>",
    "zetvu title"  : "Intro",
    "zetvu desc"  : "Message",
    "zetvu location"  : "Où ?",
    
    // input de recherche : 
    "-- search through ads --" : "-- ÈÍË --", 
    "search" : "ÈÍË", 
    
    // Formulaire de saisie de l'annonce
    "ad title"  : "Titre de l'annonce",
    "help title limited to 60 chars. Do not indicate buy of sell" : "60 caractères max. Ne pas indiquer ACHETE ou VEND",
    "ad description"  : "Description",
    "ad categorie"  : "Catégorie",
    "ad email"  : "Adresse Email",
    "ad sell or buy"  : "Type",
    "ad video embed" : "Video HTML code", 
    "ad video embed help" : "Entrer le code HTML de votre fournisseur de video", 
    "sell"  : "offres",
    "buy"  : "demandes",
    "ad price"  : "ÇáÓÚÑ",
    "&euro;" : "(en &#8364;) :  mettre 0 pour gratuit ou troc.",
    "$" : "(en $) :  mettre 0 pour gratuit ou troc.",
    "ad upload picture" : "Image(s)",
    "ad upload image help %s" : "Vous pouvez ajouter jusqu'a %s images. Max 500 ko par image. Extensions .jpeg, .jpg, .gif, .png",
    "cat upload image help %s" : "Vous pouvez ajouter une image qui sera utilisée pour les annonces sans image de cette catégorie. Max 500 ko par image. Extensions .jpeg, .jpg, .gif, .png",
    "zetevu upload image help %s" : "Vous pouvez ajouter une image. Max 500 ko par image. Extensions .jpeg, .jpg, .gif, .png",
    "ad details" : "Annonce",
    "ad contact me" : "Contact",
    "how to contact you for this ad" : "comment me contacter ?",
    "enable phone"  : "Téléphone",
    "show phone"  : "Téléphone",
    "show email"  : "Email",
    "show name"  : "Nom",
    "ad help enusername" : "Le nom doit être compris entre 5 et 20 caractères",
    "Show my email address together with this ad" : "afficher mon email dans l'annonce.",
    "Show my name together with this ad" : "afficher mon nom dans l'annonce.",
    "display my phone number" : "afficher mon numéro de téléphone dans l'annonce.", 
    "Information on how to see it and get it" : "Ou se trouve l'article", 
    "ad location and delivery": "Localisation",
    "ad location": "Adresse",
    "help indicate for example a zip code or town" : "format : {rue,ville,pays} ou {codepostal,pays}. Exemple : Strasbourg,FR ou 67000,FR. Pour une auto-detection de l'adresse, laisser à vide et lancer la détection",
    "help indicate format phone number" : "format canonique :+CodePays/Région(IndicatifRégional)NuméroAbonné.Exemple : +33(0)390671234",
    "Not the right file extension." : "Cette extension de fichier n'est pas supportée.", 
    "file size exceed limit." : "La taille du fichier dépasse les limites autorisées.",
    "id of article owner" :"identiant du créateur de l'article", 
    "userid" : "identifiant de l'auteur",  
    
    // title of Menu which are close to the input texts. 
    "post menu loc" : "Auto-détecter votre localisation", 
    "check this loc" : "Vérifier cette adresse", 
    
    // informations affichées lors d'une modification
    "publishing state" : "Divers",
    "Publication status" : "Divers informations sur votre annonce", 
    "ad pub date" :"Date", 
    "ad logs":"Historique", 
    "what" : "quoi?", 
    "whatid"  : "id",
    "auth"  : "auth",
    "cron"  : "automate",
    "sec"  : "systéme",
    "daily"  : "daily",
    "weekl"  : "weekly",
    "severity" : "Sev.",
    "severity_0" :"-",
    "severity_1" :"Mid",
    "severity_2" :"High",
    "Only severity 0" :"Sévérity Normale",
    "Only severity 1" :"Sévérité Moyenne",
    "Only severity 2" :"Sévérité Haute",
    "-- select one severity --" : "-- filtrer par sévérité --",
    
    "-- select one action --" : "-- filtrer par type de log --",
    "Only Life-cycle" : "historique des modifications", 
    "Only Auth" : "Connections des usagers", 
    "Only CRON" : "Automates/robots", 
    "Only SEC" : "Systéme/sécurité", 
     
    
    "I agree with the " : "J'accepte les ", 
    "Terms and Conditions" : "termes et conditions", 
    
    "mandatory" : " * ",
    
    "upload picture" : "sélectionner une image",
    
    "delete" : "supprimer",
    "submit" : "envoyer", 
    "cancel" : "annuler",
    "modify" : "modifier",
    "edit" : "modifier",
    "more actions" : "actions", 
    "no data found" : "Pas de donnée", 
    
    "ad delete"  : "effacer à vie",
    "ad supress"  : "suprimer",
    
    // dialog button and content 
     "dialog cancel"  : "annuler",
     "dialog ok"  : "je confirme",
     "ad delete dialog title"  : "Effacer un article",
     "cat delete dialog title"  : "Effacer une catégorie",
     "user delete dialog title"  : "Effacer un usager",
     "profil delete dialog title"  : "Effacer un usager",
     "curuser delete dialog title"  : "Effacer un usager",

     "Confirm delete of ad :" : "!! Attention, cette action est irréverssible !!<br>Confirmez vous l'effacement de l'article : ",
     "Confirm delete of cat :" : "!! Attention, cette action est irréverssible !!<br>Confirmez vous l'effacement de la catégorie : ",
     "Confirm delete of user :" : "!! Attention, cette action est irréverssible !!<br>Confirmez vous l'effacement de l'usager : ",
     "Confirm delete of profil :" : "!! Attention, cette action est irréverssible !!<br>Confirmez vous l'effacement de l'usager : ", 
     "Confirm delete of curuser :" : "!! Attention, cette action est irréverssible !!<br>Confirmez vous l'effacement de l'usager : ",
     
     // confirmation pour les logs 
     "Confirm deletion" : "Confirmer effacement", 
     "Please confirm deletion of all logs entries with status :" : "En cliquant, <i>je confirme</i>, les engeristrements (logs) ci-dessous seront tous supprimés de facon irreversible.",
     
     "Action in progress ..." : "Mise à jour en cours, merci de patienter ...",
    // categories 
    'select one categorie' : 'sélectionner une catégorie',
    
    "-- select one reason --" : '-- sélectionner une raison --',
    "article sold though this site" : "L'article a été vendu grace à ce site",
    "article sold through another mean" : "L'article a été vendu d'une autre maniére",
    "article no more available" : "L'article n'est plus disponible",
    "auto" : "Supression automatique",
    "1_soldthru" : "Vendu via ce site", 
    "2_soldother" : "Vendu via une autre moyen", 
    "3_notavail" : "Plus disponible", 
    
    "ad creation ongoing": "Création de l'article :",
    "zetvu creation ongoing": "Création du zetevu :",
    "user creation ongoing": "Création de l'utilisateur :",
    "cat creation ongoing": "Création de la catégorie :",
    
    "(where?)" : "Localisation ?", 
    
    "ad modification ongoing": "Modification de l'article :",
    "user modification ongoing": "Modification de l'utilisateur :",
    "curuser modification ongoing": "Modification du profil :",
    "cat modification ongoing": "Modification de la catégorie :",
    
    // erreurs sur les formulaires
    "You must select something." : "merci de sélectionner quelque chose.",
    "You must fill in something." : "merci de saisir un texte.",
    "Incorrect format." : "format de saisie incorrect.", 
    "Incorrect rule." : "format de saisie incorrect.",
    "You must accept the Terms and conditions" : "vous devez accepter les T&C ",
    "Field does not match password" : "les deux mots de passe doivent être identiques",
    "Text length exceeding limits." : "la longueur du texte dépasse la limite",
    "%s char remaining" : "reste %s caractère",
    "%s chars remaining" : "reste %s caractères", 
    "%s chars max" : "%s caractères maximum",
    "your must precise skills AND ratings." : "choisir au moins une compétence et son niveau.",
    
    // error in email formular
    "Incorrect email format" :  "format de l'email incorrect.", 
    //"Incorrect SIRET number." :  "Format SIRET incorect (14 chiffres).", 
    "Incorrect SIRET number." :  "Format TVA incorrect (BE+0+9chiffres).", 


    // options payantes : 
    
    "ad payoptions" : "Mise en avant :", 
    "post payoptions" : "Options de mise en avant pour vous démarquer !", 
    "help payoptions" : "Options de mise en avant pour vous démarquer !", 

    "desc putontopgallery" : "Mise à la une", 
    "post putontopgallery" : "Mettre mon annonce à la une pendant 7 jours", 
    "help putontopgallery" : "Mettre mon annonce à la une pendant 7 jours", 
    
    "desc pushtotop7days" :  "Remonter mon annonce", 
    "post pushtotop7days" :  "Mettre mon annonce en avant chaque jour pendant 7 jours", 
     "help pushtotop7days" :  "Mettre mon annonce en avant chaque jour pendant 7 jours", 
    
    "desc specialcolor"  :  "Encadrer mon annonce", 
    "post specialcolor"  :  "Encadrer de couleur mon annonce pour être plus visible", 
     "help specialcolor"  :  "Encadrer de couleur mon annonce pour être plus visible", 
    
    "desc addpics"  :  "Photos en plus" , 
    "post addpics"  :  "Ajouter des photos en plus" , 
    "help addpics"  :  "Ajouter des photos en plus" , 

    "desc paidvideo"  :  "Ajouter une video", 
    "post paidvideo" : "Ajouter une video via son code embedd", 
    "help paidvideo" : "Ajouter une video via son code embedd", 

    "pushtop" : "remontée",
    "pushgal" : "mise à la une",  



    // texte des boutons du formulaire
    "BTN ad NOT CREATED": "ÅÑÓÇá",
    "BTN ad DRAFT": "ÍÝÙ ÇáãÓæÏÉ",
    "BTN ad DRAFT PENDING PAYMENT" : "ÏÝÚ æ ÊÝÚíá", 
    "BTN ad PREVIEW": "ÊÝÚíá",
    "BTN ad UNDER REVIEW": "ÊÞÏíã ááäÔÑ",
    "BTN ad PUBLISHED": "äÔÑ",
    "BTN ad UNPUBLISHED": "ÊÚáíÞ",
    "BTN ad DELETED": "ÍÐÝ",
    "BTN ad REJECTED": "ÑÝÖ",
    "BTN ad WILLEXPIRE": "ÅäåÇÁ ÇáÕáÇÍíÉ",
    
    "BTN cat NOT CREATED": "ÅÑÓÇá",
    "BTN cat DRAFT": "ÍÝÙ ÇáãÓæÏÉ",
    "BTN cat UNDER REVIEW": "ÊÞÏíã ááäÔÑ",
    "BTN cat PUBLISHED": "äÔÑ",
    "BTN cat UNPUBLISHED": "ÊÚáíÞ",
    "BTN cat DELETED": "ÍÐÝ",
    "BTN cat REJECTED": "ÑÝÖ",
    "BTN cat WILLEXPIRE": "ÅäåÇÁ ÇáÕáÇÍíÉ",
    
    "BTN user NOT CREATED": "ÅÑÓÇá",
    "BTN user DRAFT": "ÍÝÙ ÇáãÓæÏÉ",
    "BTN user DRAFT PENDING PAYMENT" : "ÏÝÚ æ ÊÝÚíá", 
    "BTN user PREVIEW": "ÊÝÚíá",
    "BTN user UNDER REVIEW": "ÊÞÏíã ááäÔÑ",
    "BTN user PUBLISHED": "äÔÑ",
    "BTN user UNPUBLISHED": "ÊÚáíÞ",
    "BTN user DELETED": "ÍÐÝ",
    "BTN user REJECTED": "ÑÝÖ",
    "BTN user WILLEXPIRE": "äåÇíÉ ÇáÕáÇÍíÉ",
    
    "BTN curuser NOT CREATED": "ÅÑÓÇá",
    "BTN curuser DRAFT": "ÍÝÙ ÇáãÓæÏÉ",
    "BTN curuser UNDER REVIEW": "ÊÞÏíã ááäÔÑ",
    "BTN curuser PUBLISHED": "äÔÑ",
    "BTN curuser UNPUBLISHED": "ÊÚáíÞ",
    "BTN curuser DELETED": "ÍÐÝ",
    "BTN curuser REJECTED": "ÑÝÖ",
    "BTN curuser WILLEXPIRE": "ÅäåÇÁ ÇáÕáÇÍíÉ",
    
    
    "BTN zetvu NOT CREATED": "ÅÑÓÇá",
    "BTN zetvu DRAFT": "ÍÝÙ ÇáãÓæÏÉ",
    "BTN zetvu UNDER REVIEW": "ÊÞÏíã ááäÔÑ",
    "BTN zetvu PUBLISHED": "äÔÑ",
    "BTN zetvu UNPUBLISHED": "ÊÚáíÞ",
    "BTN zetvu DELETED": "ÍÐÝ",
    "BTN zetvu REJECTED": "ÑÝÖ",


    "BTN banner NOT CREATED": "ÅÑÓÇá",
    "BTN banner DRAFT": "ÍÝÙ ÇáãÓæÏÉ",
    "BTN banner DRAFT PENDING PAYMENT" : "ÏÝÚ æ ÊÝÚíá", 
    "BTN banner PREVIEW": "ÊÝÚíá",
    "BTN banner UNDER REVIEW": "ÊÞÏíã ááäÔÑ",
    "BTN banner PUBLISHED": "äÔÑ",
    "BTN banner UNPUBLISHED": "ÊÚáíÞ",
    "BTN banner DELETED": "ÍÐÝ",
    "BTN banner REJECTED": "ÑÝÖ",
    "BTN banner WILLEXPIRE": "ÅäåÇÁ ÇáÕáÇÍíÉ",
    
    
    
    
    "REGISTERED": "ãÓÌá",
    "EDITOR": "ãÍÑÑ",
    "SUPER-ADMIN": "ãÏíÑ ÚÇã",
    
    "formular already exists" : "Le formulaire est déjà ouvert. Cliquez sur le bouton annuler.",
    
    // sidebar 
    "Browse all": "ÊÕÝÍ Çáßá",
    "latest ZeTvu" : "Derniers ZeTvu", 
    "latest Tweet" : "ÂÎÑ ÇáÊÛÑíÏÇÊ", 
 
    // sidebar buttons 
    "Subscribe" : "ÇáÇÔÊÑÇß",
    "subscribe feed by email": "ÇáÇÚáÇäÇÊ æ ÇáØáÈÇÊ", 
    "subscribe feed": "ÇÔÊÑß Ýí ÎÏãÉ RSS",
    "follow us on twitter": "ÊÇÈÚäÇÚáì ÊæíÊÑ",
    "follow us on facebook": "ÊÇÈÚäÇÚáì ÇáÝíÓÈæß",
  
    // texte des Status possibles d'un article
    "NOT CREATED": "ãÓæÏÉ",
    "DRAFT": "ãÓæÏÉ",
    "DRAFT PENDING PAYMENT": "ÚãáíÇÊ ÏÝÚ ÞíÏ ÇáÇäÊÙÇÑ",
    "DRAFT PAYMENT OK": "ÚãáíÇÊ ÇáÏÝÚ ÇáãäÝÐÉ",
    "UNDER REVIEW": "ÞíÏ ÇáãÑÇÌÚÉ",
    "under review" : "ÞíÏ ÇáãÑÇÌÚÉ",
    "PUBLISHED": "ãäÔæÑ",
    "UNPUBLISHED": "ÛíÑ ãäÔæÑ",
    "DELETED": "ãÍÐæÝ",
    "REJECTED": "ãÑÝæÖ",
    "WILLEXPIRE": "ÓÊäÊåí ÕáÇÍíÊå",
    
    // test descriptifs des LOGS 
    "create": "ÇäÔÇÁ",
    "update": "ÊÚÏíá",
    "delete": "ÍÐÝ",
    "updatehit": "ÊÚÏíá",
    "updatestatus": "ÊÚÏíá",
    "resethits" : "ÊÚÏíá", 
    
    "desc": "ÇáæÕÝ",
    "state": "ÇáÍÇáÉ",
    "No entries in logs." : "áÇ ÊæÌÏ ÚãáíÇÊ ÈÇáÓÌá.",
    "No entries in payments." : "áÇ ÊæÌÏ ÚãáíÇÊ ÈÓÌá ÇáãÏÝæÚÇÊ",
    
    "log_resethits" : "ãÓÍ ÇáÊÕæíÊÇÊ", 
    "log_create_DRAFT": "ÅäÔÇÁ ãÓæÏÉ",
    "log_payment_DRAFT PAYMENT OK": "ÊãÊ ÚãáíÉ ÇáÏÝÚ ÈäÌÇÍ", 
    "log_create_UNDER REVIEW": "ÅäÔÇÁ æ ÊÞÏíã",
    "log_create_PUBLISHED": "ÅäÔÇÁ æ äÔÑ",
    "log_update_DRAFT" : "ÊÚÏíá æ ÍÝÙ ßãÓæÏÉ",
    "log_update_DRAFT PENDING PAYMENT" : "ÚãáíÉ ÇáÏÝÚ ÞíÏ ÇáãÑÇÌÚÉ",
    "log_update_UNDER REVIEW": "ÊÚÏíá æ ÚÑÖ ááãÑÇÌÚÉ",
    "log_update_PUBLISHED": "ÊÚÏíá æ äÔÑ",
    "log_updatestatus_PUBLISHED": "ÊÚÏíá æ äÔÑ",
    "log_update_DELETED": "ÍÐÝ",
    "log_updatestatus_UNDER REVIEW" : "ÚÑÖ ááäÔÑ",
    "log_updatestatus_DELETED": "ÍÐÝ",
    "log_update_UNPUBLISHED": "ÍÏÝ ãÄÞÊ",
    "log_update_REJECTED": "áã íÊã ÇáãæÇÝÞÉ Úáíå",
    "log_update_WILLEXPIRE": "ÅÔÚÇÑ ÇäÊåÇÁ ÇáÕáÇÍíÉ",
    "log_delete" : "ÍÐÝ äåÇÆí",
    "log_auth_Access granted , welcome !" : "ãÑÍÈÇ Èß", 
    "log_auth_incorrect LOCAL  password  - please check" : "ßáãÉ ÇáãÑæÑ ÎÇØÆÉ",
    "log_auth_incorrect Login name" : "ÇÓã ÇáãÓÊÎÏã ÎÇØÆ",
    
    //valeur des priorités 
    "pty_normal" : "ÚÇÏí",
    "pty_top" : "Ýí ÇáÃÚáì",
    "pty_permanent" : "ÏÇÆã",
    "pty_news" : "ãÞÇá / ÃÎÈÇÑ",  
    "top" : "ÇáÃÝÖá",
    "most viewed" : "ÇáÃßËÑ ãÔÇåÏÉ",


    // paypal 
    "You have paid options for <b>%s %s </b>" : "Vous avez des options payantes pour un montant de <b>%s %s</b>.", 
    "Payment successful": "Paiement bien reçu !", 
    "Thanks you for your payment ! Your ad will now be submitted for approval." : "Merci pour votre paiement!. Votre annonce va être maintenant validée par notre commité éditorial avant publication.", 
    "Payment cancelled" : "Paiemement Annulé !", 
    "Your payment is cancelled. You can retrieve your ad into your dashboard." : "Votre paiement est annulé. Vous pouvez retrouver votre annonce dans votre tableau de bord pour modification.",
    "Paypal redirection ongoing" : "Nous contactons PAYPAL ...", 
    "You will be redirected to paypal for finalizing payment." : "Vous allez être redirigé vers PAYPAL pour régler la transaction.", 
    "Payment finalization"  : "Finalisation du paiement ...", 
    "Thanks you for your payment ! We are updating your order, please wait." : "Merci pour votre paiement!. Nous mettons à jour votre annonce. Merci de patienter!", 
    "paypal - This transaction does not exist or has already been processed" : "Desolé, cette transaction n'existe pas ou a déjà été reglée.",
    "paypal payment sucessfull" : "La paiement paypal a été correctement effectué",     

    // champs du log des paiements
    "paymentdate" : "ÇáÊÇÑíÎ", 
    "amt" : "ÇáãÈáÛ", 
    "paymentstatus" : "ÇáÍÇáÉ",
    "transactionid" : "ÑÞã ÇáÕÝÞÉ",  

    // type comptes utilisateurs
     "protype_pri" : "ÎÇÕ",
     "protype_pub" : "ÚÇã",
     "protype_pro" : "ÅÍÊÑÇÝí",
     "protype" : "ÍÓÇÈ",
     "private" : "ÎÇÕ",
     "public" : "ÚÇã", 
     "pro" : "ÅÍÊÑÇÝí",
     "help_protype" : "ÇáÍÓÇÈ ÇáÎÇÕ íßæä ãÑÆíÇ áß ÝÞØ¡ ÇáÍÓÇÈÇÊ ÇáÚÇãÉ æ ÇáÇÍÊÑÇÝíÉ Êßæä ãÑÆíÉ ááÌãíÚ.",
     

     // annonces relatives :
     "related ads " :  "ÇÚáÇäÇÊ ", 


    // actions
    "delete all auth logs" : "ãÓÍ ÓÌá ÇáÏÎæá", 
    "delete all cron logs": "ãÓÍ ÓÌá ÇáÑæÈæÊ", 
    "delete all sec logs" : "ãÓÍ ÓÌá ÇáäÙÇã", 
    "batch actions" : "ÎíÇÑÇÊ >>",
    "help_logs_batch_actions_menu" :"Affiche le menu pour lancer des actions en masse sur ces enregistrements.",
    "help_delete_logs_auth" : "Cette action efface toutes les entrés de type authentification dans les logs",
    "help_delete_logs_auth" : "Cette action efface toutes les entrés de type authentification dans les logs", 
    "help_delete_logs_cron" : "Cette action efface toutes les entrés de type CRON/Automates dans les logs",
    "help_delete_logs_sec" : "Cette action efface toutes les entrés de type System/Securité dans les logs",    
    
    // ecran de detail d'un article 
    "ad id" : "ÑÞã ÇáÇÚáÇä ",
    "ad status" : "ãäÔæÑ ",
    "ad priority" : "ÇáÃÝÖáíÉ ",
    "ad moddate" : "Êã ÇáÊÚÏíá íæã ",
    "ad publiched the" : "íæã",
    "ad hits" : "ãÔÇåÏÉ",
    "ad vendor info" : "ÇáÈÇÆÚ",
    "ad info" : "ÊÝÇÕíá",
    "ad actions" : "ÎíÇÑÇÊ",
    "ad admin" : "ÇÏÇÑÉ ÇáÇÚáÇä",
    "ad qr code" : "ÃæÌÏ åÐÇ ÇáÇÚáÇä",
    "ad edit" : "ÊÚÏíá",
    "ad reset hits" : "ãÓÍ ÚÏÏ ÇáãÔÇåÏÇÊ", 
    "ad savefav" : "ÃÖÝ Çáì ÇáãÝÖáÉ",
    "ad twitter" : "äÔÑ Úáì ÊæíÊÑ",
    "Share" : "äÔÑ ... ",
    "more ... »" : "ÃßËÑ ... »",
    "share on twitter" : "äÔÑ Úáì ÊæíÊÑ",
    "share on facebook" : "äÔÑ Úáì ÇáÝíÓÈæß",
    "share on Linkedin" : "äÔÑ Úáì áíäßÏíä",
    "share on Google+" : "äÔÑ Úáì ÌæÌá+",
    "clip to Evernote" : "äÔÑ Úáì ÇíÝÑäæÊ",
    "bookmark this on Delicious" : "äÔÑ Úáì ÏíáíÓíæÓ",
    "ad facebook" : "äÔÑ Úáì ÇáÝíÓÈæß",
    "One article of interest" : "ÅÚáÇä ãåã",
    "ad del savefav" : "ÍÐÝ ãä ÇáãÝÖáÉ",
    "ad email it" : "ÇÑÓÇá Çáì ÈÑíÏ ÇáßÊÑæäí",
    "ad print" : "ØÈÇÚÉ",
    "ad flag it abuse" : "ÊÈáíÛ Úä ÇÓÇÁÉ",
    /*
    "previous ad" : "précédent",
    "next ad" : "suivant",
    "next" : "suivant",
    "previous" : "précédent",
    */
    "previous ad" : "<",
    "next ad" : ">",
    "next" : ">",
    "previous" : "<",
    
    "elem logs": "ÂÎÑ ãÇ ÞãÊ ÈÊÕÝÍå", 
    "Display elem logs": "ÝÊÍ", 
    

    "free" : "ãÌÇäÇ",
    "more if registered" : "ÇáãÒíÏ +",
    "Send a messge to the seller" : "ÃÑÓá ÑÓÇáÉ Çáì ÇáÈÇÆÚ",
    "Contact the user through the website" : "ÇáÇÊÕÇá Úä ØÑíÞ ÇáãæÞÚ", 
    "send email" : "ÃÑÓá ÈÑíÏ ÇáßÊÑæäí",
    "call number" : "ÇÊÕá ÈÇáÑÞã",
      
    // help on buttons : 
      "title clip to Evernote" : "ÍÝÙ ÇáÇÚáÇä Ýí ãÝßÑÉ ÇíÝÑ äæÊ",
      
    // login form title
    "You must be registered" : "íÌÈ Úáíß ÇáÊÓÌíá",
    "Login form title" : "ÊÓÌíá ÇáÏÎæá",
    "login form introduction": "Þã ÈÊÓÌíá ÇáÏÎæá áÇÖÇÝÉ æ ÇÏÇÑÉ ÇÚáÇäÇÊß.",
    "register introduction": "ÇÐÇ áã Êßä ãÓÌá ÈÚÏ, ",
    "login_register": "Þã ÈÇáÊÓÌíá ãä åäÇ !",
    "login_lostpassword": "äÓíÊ ßáãÉ ÇáÓÑ¿ ",
    "email address not known" : "ÇáÈÑíÏ ÇáÇáßÊÑæäí ÎÇØÆ", 
    "login": "ÏÎæá",
    "login name" : "ÇÓã ÇáãÓÊÎÏã",
    "login email" : "ÇáÈÑíÏ ÇáÇáßÊÑæäí",
    "login_rememberme" : "ÊÐßÑäí",
    "submit login" : "ÏÎæá",
    "logout": "ÎÑæÌ",
    "welcome %s": "ÃåáÇ Èß <strong>%s</strong> ",
    "profil": "ÍÓÇÈí",
    "Access granted , welcome !" : "Êã ÊÓÌíá ÇáÏÎæá, ãÑÍÈÇ Èß !", 
    "Correctly logout and cookies deleted" : "ÃäÊ ÇáÇä ÛíÑ ãÊÕá.",
    "incorrect LOCAL  password  - please check" : "ÝÔá ÇáÏÎæá : ßáãÉ ãÑæÑ ÛíÑ ÕÍíÍÉ.",
    "incorrect Login name" : "ÝÔá ÇáÏÎæá : ÇÓã ÇáãÓÊÎÏã ÛíÑ ÕÍíÍ.",
    "Register": "ÊÓÌíá",
    "Login in progress ..." : "íÊã ÇáÇä ÊÓÌíá ÇáÏÎæá ...",
    "Loading in progress ..." : "ÇáÑÌÇÁ ÇáÇäÊÙÇÑ ÞáíáÇð ...",
    
    // leaflet special texts
    "leaflet footer text"  : "áÞÏ Êã ÅäÔÇÁ æ ØÈÇÚÉ åÐÇ ÇáÅÚáÇä ãä ãæÞÚ ÇáÅÚáÇäÇÊ ÇáãÈæÈÉ", 
    "Select the main picture, click <a id='print' href='#'>here</a> to print and clip along the line": "ÍÏÏ ÕæÑÉ ÑÆíÓíÉ, <a id='print' href='#'>ØÈÇÚÉ </a> æÊÞØíÚ ÈÇÊÈÇÚ ÇáÎØ ÇáãäÞØ. ",
    "ad leaflet print" :"ØÈÇÚÉ ÇáÕÝÍÉ", // important sans espace pour IE 
    
    // email form title
    "email lost form title" : "ÅÚÇÏÉ ÊÚííä ßáãÉ ÇáãÑæÑ", 
    "email support form title" : "ÅÊÕá ÇáÂä", 
    "email feedback form title" : "ÊÈáíÛ Úä ãÔßáÉ", 
    "email remind form title" : "ÐßÑäí ÈåÐå ÇáÑÓÇáÉ", 
    "email contact form title" : "ÅÊÕá ÈÇáÈÇÆÚ", 
    "email abuse form title" : "ÊÈáíÛ Úä ÅÓÇÁÉ", 
    "email contactuser form title" :  "ÅÑÓÇá ÑÓÇáÉ áåÐÇ ÇáãÓÊÎÏã",
    
    "email lost form introduction" : "ÃÏÎá ÇáÈÑíÏ ÇáÇáßÊÑæäí ÇáÐí ÞãÊ ÈÇáÊÓÌíá Èå", 
    "email support form introduction" : "ÅÓÊÚãá åÐÇ ÇáäãæÐÌ áãÑÇÓáÊäÇ.",
    "email feedback form introduction" : "ÅÓÊÚãá åÐÇ ÇáäãæÐÌ áãÑÇÓáÊäÇ.",
    "email abuse form introduction" : "ÅÓÊÚãá åÐÇ ÇáäãæÐÌ ááÊÈáíÛ Úä ÅÓÇÁÉ.",
    "email contact form introduction" : "ÅÓÊÚãá åÐÇ ÇáäãæÐÌ áãÑÇÓáÉ ÇáÈÇÆÚ.", 
    "email remind form introduction" : "ÅÓÊÚãá åÐÇ ÇáäãæÐÌ áÅÝÇÏÊí ÈÊÝÇÕíá åÐÇ ÇáÇÚáÇä", 
    "email contactuser form introduction" : "ÅÓÊÚãá åÐÇ ÇáäãæÐÌ áãÑÇÓáÉ åÐÇ ÇáãÓÊÎÐã.",
    
    "your email" : "ÇáÈÑíÏ ÇáÇáßÊÑæäí", 
    "email title" : "ÇáãæÖæÚ", 
    "email description" : "ÊÝÇÕíá", 
    
    "submit lost email" : "ÅÚÇÏÉ ÇÑÓÇá ßáãÉ ÇáãÑæÑ", 
    "submit support email" : "ÅÑÓÇá ÇáÑÓÇáÉ",
    "submit feedback email" : "ÅÑÓÇá ÇáÑÓÇáÉ",  
    "submit abuse email" : "ÅÑÓÇá ÇáÑÓÇáÉ",
    "submit contact email" : "ÅÑÓÇá ÇáÑÓÇáÉ",  
    "submit remind email" : "ÅÑÓÇá ÇáÑÓÇáÉ", 
    "submit contactuser email" : "ÅÑÓÇá ÇáÑÓÇáÉ",  
    
    "Confirm modification" : "ÍÝÙ ÇáÊÛíÑÇÊ", 
    "Please confirm modification to status 40 of :" : "ÚäÏ ÇáÖÛØ Úáì¡ <i>ãæÇÝÞ</i>¡ ÓíÊã äÔÑ ÇáÇÚáÇä. ßãÇ íãßäß ãÑÇÓáÉ ÇáÈÇÆÚ.",
    "Please confirm modification to status 90 of :" : "ÚäÏ ÇáÖÛØ Úáì¡ <i>ãæÇÝÞ</i> ¡ ÓíÊã ÑÝÖ ÇáãæÖæÚ ¡ ÍÏÏ ÓÈÈ ÇáÑÝÖ.",
    "Please confirm modification to status 80 of :" : "ÚäÏ ÇáÖÛØ Úáì ¡ <i>ãæÇÝÞ</i> ¡ ÓíÊã ÍÐÝ ÇáãæÖæÚ.",
    "your message": "äÕ ÑÓÇáÊß", 
    "Why ?": "áãÇÐÇ¿",


    "Message sending in progress" : "ÌÇÑí ÇÑÓÇá ÇáÑÓÇáÉ ...", 
    "Message sucessufully sent !" : "Êã ÇÑÓÇá ÑÓÇáÊß ÈäÌÇÍ!",
    
    "This operation is not authorized !" :  "áÇ íãßäß ÊäÝíÐ åÐå ÇáÚãáíÉ.", 
    "You have exceeded the commercial limits : MAX AD" :  "áÞÏ ÞãÊ ÈÊÌÇæÒ ÚÏÏ ÇáÇÚáÇäÇÊ ÇáãÓãæÍ Èå¡ íÑÌì ÇáÇÊÕÇá ÈÇáÇÏÇÑÉ.",
    "You are not authorised to access this section. You have been redirected to home page." : "áÇ íãßäß ÇáÏÎæá Çáì åÐÇ ÇáÞÓã¡ ÓíÊã ÊÍæíáß Çáì ÇáÕÝÍÉ ÇáÑÆíÓíÉ.", 

    "Login in progress" : "ÌÇÑí ÊÓÌíá ÇáÏÎæá...", 
    "Error in Login form" : "ÎØÃ ÚäÏ ãáÆ ÇáäãæÐÌ.",
    "incorrect Login/password" : "ÎØÃ¡ ÇÓã ÇáãÓÊÎÏã Ãæ ßáãÉ ÇáãÑæÑ ÇáÊí ÃÏÎáÊåÇ ÛíÑ ÕÍíÍÉ.",
    "Your acount is created, please login to connect : ": "Êã ÇäÔÇÁ ÍÓÇÈß ÈäÌÇÍ.",
    "Congratulation !" : "ÊåÇäíäÇ !", 
    
    "ZADS, I want to have more information on element :" : "ÃÈÍË Úä ãÚáæãÇÊ ÃßËÑ ÈÎÕæÕ ÇÚáÇäß: ",  
    "ZADS, I want to have more information" : "ÃÈÍË Úä ãÚáæãÇÊ ÃßËÑ ÈÎÕæÕ ...",
    "ZADS, I want to have more information" : "åá ãä ãÚáæãÇÊ ÃßËÑ ÈÎÕæÕ ÇÚáÇäß¿",
    
    "user vendor info" : "ãÚáæãÇÊ ÇáÈÇÆÚ",
    "user actions" : "ÎíÇÑÇÊ",
    "user info" : "ãÚáæãÇÊ",
    "user id" : "ÇáãÚÑÝ",
    "user status" : "ÇáÍÇáÉ",
    "user type" : "ÇáÍÞæÞ",
    "user register date" : "ÊÇÑíÎ ÇáÊÓÌíá",
    "user last visit date" : "ÂÎÑ ÇáÒíÇÑÇÊ",
    "ad registration date" : "ÊÇÑíÎ ÇáÊÓÌíá",
    "ad modification date" : "ÚÏá íæã",
    
    "contact him" : "ÇÊÕá ÈÇáÈÇÆÚ",
    "Send him a message" : "ÑÇÓá ÇáÈÇÆÚ",
    
    "user savefav" : "+ ÇÚáÇäÇÊí ÇáãÝÖáÉ",
    "user email it" : "ÇÑÓÇá Çáì ÈÑíÏ ÇáßÊÑæäí",
    "user print" : "ØÈÇÚÉ",
    "user flag it abuse" : "ÊÈáíÛ Úä ÇÓÇÁÉ",
    
    "hits : %s times" : "ÊãÊ ãÔÇåÏÊå %s ãÑÉ", 
      
    // modal box
    "modbox close" : "ÅÛáÇÞ",
    "info" : "ãÚáæãÇÊ",
    "error" : "ÎØÃ",
    "success" : "ÊãÊ ÇáÚãáíÉ ÈäÌÇÍ !",
    "Server request timeout" : "ÚÐÑÇ¡ áÇ íãßä ÇáÇÊÕÇá ÈÇáÓíÑÝÑ.",
    
    // messages 
    "Action not yet available": "åÐå ÇáÚãáíÉ ÛíÑ ãÊÇÍÉ ÍÇáíÇ !",
    "Yay! Everything went well!" : "ÊãÊ ÇáÚãáíÉ ÈäÌÇÍ !",
    "ok ad under review" : "ÓíÊã äÔÑ ÇÚáÇäß ÈÚÏ ãÑÇÌÚÊå ãä ØÑÝ ÇáÇÏÇÑÉ.",
    "ok ad deleted" : "Êã ÍÐÝ ÇÚáÇäß.",
    "ok ad published" : "Êã äÔÑ ÇÚáÇäß ÈäÌÇÍ. Óíßæä ãÊÇÍÇ áãÏÉ 30 íæãÇ.",
    "ok user registered" : "Êã ÇäÔÇÁ ÍÓÇÈß. íãßäß ÇáÂä ÊÓÌíá ÏÎæáß ááãæÞÚ.",
    "error in form checking" : "áã ÊÞã ÈãáÆ ÇáäãæÐÌ ÈÔßá ÕÍíÍ¡ Úáíß ÇáÊÍÞÞ ãä ÇáÍÞæá ÇáÊí ÊÍãá ÚáÇãÉ ÎØÃ.",
    "Doh! Something happened : A user with this email already exist." : "åÐÇ ÇáÈÑíÏ ãÓÊÚãá ãä ØÑÝ ãÓÊÎÏã ÂÎÑ¡ ÑÌÇÁÇ Þã ÈÇÎÊíÇÑ ÈÑíÏ ÂÎÑ.",
    "Doh! Something happened : This username is not available.": "åÐÇ ÇáÇÓã ÛíÑ ãÊÇÍ¡ ÑÌÇÁÇ Þã ÈÇÎÊíÇÑ ÇÓã ÂÎÑ.",
    // main menu
    "containing <b>%s</b> word" : "ÊÍÊæí Úáì ßáãÉ <span class='highlight'>%s</span>",
 
    //user menu 
    "create ad" : "ÃÖÝ ÅÚáÇäß", 
    "create zetvu" : "créer un ZeTvu", 
    "admin (dashboard)" : "áæÍÉ ÇáÇÏÇÑÉ", 
    
    // geolocatization 
    "Geo-localization successful" : "Êã ÊÍÏíÏ ãäØÞÊß : ", 
    "Selected Geo-localization successful" :  "Êã ÊÍÏíÏ ãäØÞÊß : ", 
    "Geo-localization failed" : "ÎØÃ - áã íÊã ÊÍÏíÏ ãäØÞÊß : ",
    "Geoloc not available in your navigator" : "åÐå ÇáÎÇÕíÉ ÛíÑ ãÊæÝÑÉ Ýí ãÊÕÝÍß.",
    "Geo-localization time-out" :"ÊÍÏíÏ ÇáãäØÞÉ: ÝÔá ÇáÇÊÕÇá ÈÇáÓíÑÝÑ.",
    "Geo-localization permission denied":"ÊÍÏíÏ ÇáãäØÞÉ: ÊÕÑíÍ ãÑÝæÖ.",
    "Geo-localization position unavailable":"ÊÍÏíÏ ÇáãäØÞÉ: ãäØÞÊß ÛíÑ ãÊÇÍÉ ÍÇáíÇ.",
    "Goecoding error : "  : "ÎØÃ - áã íÊã ÊÍÏíÏ ãäØÞÊß : ", 
    "your location" : "ãäØÞÊß",
    "Geo-localization in progress":"ÌÇÑí ÊÍÏíÏ ÇáãäØÞÉ ...",
    "Geo-localization error"  : "ÎØÃ ÃËäÇÁ ÊÍÏíÏ ÇáãäØÞÉ",
    "Geo-localization can move marker to select other":"íãßäß æÖÚ ÇáãÄÔÑ Ýí ÇáãßÇä ÇáãäÇÓÈ áß.",
    "Release the Marker to the desired address" : "... æÖÚ ÇáãÄÔÑ Ýí ÇáãßÇä ÇáãäÇÓÈ", 
    "getting address...":"ÌÇÑí ÊÍÏíÏ ÇáÚäæÇä...",
    "Error in Google Map loading. Check your internet connection." : "ÝÔá ÇáÇÊÕÇá ÈÎÑÇÆØ ÌææÌá.",
    //list view
    "Sort by:" : "ÑÊÈ ÍÓÈ:",
    "Most recent" : "ÇáÌÏíÏ",
    "Lowest price" : "ÇáÃÏäì ÓÚÑÇ",
    "Highest price" : "ÇáÃÚáì ÓÚÑÇ",
    "Highest hits": "ÇáÃßËÑ ãÔÇåÏÉ",
    "Sort by price desc" : "ÑÊÈ ÍÓÈ ÃÚáì ÓÚÑ",
    "Sort by price asc" : "ÑÊÈ ÍÓÈ ÃÏäì ÓÚÑ",
    "Sort by date desc" : "ÑÊÈ ÍÓÈ ÇáÊÇÑíÎ",
    "Sort by hits desc" : "ÑÊÈ ÍÓÈ ÇáÅÞÈÇá",
    "Sort by name asc" : "ÑÊÈ ÍÓÈ ÇáÍÑæÝ",
    "Sort by ad nb desc" : "ÑÊÈ ÍÓÈ ÑÞã ÇáÇÚáÇä",
    "Sort by whatid desc" : "ÑÊÈ ÍÓÈ ÇáÇÓã",
    "Sort by what desc" : "ÑÊÈ ÍÓÈ ÇáäæÚ",
    
    "By " : "ÈæÇÓØÉ ",
    "previous page" : "ÇáÕÝÍÉ ÇáÓÇÈÞÉ",
    "next page" : "ÇáÕÝÍÉ ÇáÊÇáíÉ",
    "help prev" : "ÇáÕÝÍÉ ÇáÓÇÈÞÉ",
    "help next" : "ÇáÕÝÍÉ ÇáÊÇáíÉ",
    
    "ãä <b>%s</b> Çáì <b>%s</b> ãä ÃÕá <b>%s</b> ÅÚáÇä" : "( <b>%s</b> à <b>%s</b> / <b>%s</b>)",
    "<b>%s</b>-<b>%s</b> ãä ÃÕá <b>%s</b>" : "<b>%s</b>-<b>%s</b> ãä <b>%s</b>",
    
    "Back" : "ÇáÑÌæÚ", 

    // sub-menu 
    "myads" : "ÇÚáÇäÇÊí",
    "my_ad" : "ÇÚáÇäÇÊí",
    "myadmin" : "áæÍÉ ÇáÊÍßã",
    "my_admin" : "áæÍÉ ÇáÊÍßã",
    "admin" : "ÇáÇÏÇÑÉ",
    
    "allads" : "ÌãíÚ ÇáÇÚáÇäÇÊ",
    "all ad" : "ÌãíÚ ÇáÇÚáÇäÇÊ",
    "admin_ad" : "ÌãíÚ ÇáÇÚáÇäÇÊ",
    "admin_user" : "ÌãíÚ ÇáãÓÊÎÏãíä",
    "allusers" : "ÌãíÚ ÇáãÓÊÎÏãíä",
    "admin_all" :"ÌãíÚ ÇáãÓÊÎÏãíä",
    
    "all logs" : "ÌãíÚ ÅÏÎÇáÇÊ ÇáÓÌá",
    "all payments" : "ÌãíÚ ÇáãÏÝæÚÇÊ",
    "all status" : "ÌãíÚ ÇáÍÇáÇÊ",
    "manageother" : "ÅÏÇÑÉ ÃÎÑì",
    "all cat" : "ÌãíÚ ÇáÃÞÓÇã",
    "all user" : "ÌãíÚ ÇáãÓÊÎÏãíä",
    "all admin_user" : "ÌãíÚ ÇáãÓÊÎÏãíä",
    "all admin_cat" : "ÌãíÚ ÇáÃÞÓÇã",
    
    "dashboard" : "áæÍÉ ÇáÊÍßã",
    "dash no data" : "áÇ ÊæÌÏ ÈíÇäÇÊ",
    "mydashboard" : "áæÍÉ ÇáÊÍßã",
    "user" : "ãÓÊÎÏã",
    "cat" : "ÃÞÓÇã", 
    "ad" : "ÇÚáÇä", 
    "all myads" : "ÇÚáÇäÇÊí",
    "all my_ad" : "ÌãíÚ ÇÚáÇäÇÊí",
    "all admin_ad" : "ßá ÇáÇÚáÇäÇÊ",
    "myads_published" : "ÅÚáÇäÇÊ ãäÔæÑÉ",
    "myads_all" : "ÌãíÚ ÇÚáÇäÇÊí",
    "myads_pending" : "ÞíÏ ÇáÇäÊÙÇÑ",
    "myads_draft" : "Ýí ÇáãÓæÏÇÊ",
    "myads_draftpendingpayment" : "ÚãáíÇÊ ÏÝÚ ÞíÏ ÇáÇäÊÙÇÑ",
    "myads_deleted" : "ÅÚáÇäÇÊ ãÍÐæÝÉ",
    "published" : "ÅÚáÇäÇÊ ãäÔæÑÉ",
    "pending" : "Ýí ÇáÅäÊÙÇÑ",
    "willexpire" : "ÅÚáÇäÇÊ ÓÊäÊåí ÕáÇÍíÊåÇ",
    "draft" : "ãÓæÏÇÊ",
    "draft pending payment" : "ÚãáíÇÊ ÏÝÚ ÞíÏ ÇáÇäÊÙÇÑ", 
    "deleted_expired" : "ãäÊåí ÇáÕáÇÍíÉ",
    "deleted" : "ãäÊåí ÇáÕáÇÍíÉ",
    "ads_published" : "ÇÚáÇäÇÊ",
    "ads_draft" : "ÇáãÓæÏÇÊ",
    "admin_pending" : "Ýí ÇäÊÙÇÑ ÇáÊÝÚíá",
    "admin_willexpire" : "ÅÚáÇäÇÊ ÓÊäÊåí ÕáÇÍíÊåÇ",
    "admin_expired" : "ãäÊåí ÇáÕáÇÍíÉ",
    "admin_deleted" : "ãäÊåí ÇáÕáÇÍíÉ",
    "admin_published" : "ÇÚáÇäÇÊ",
    "admin_draft" : "ÇáãÓæÏÇÊ",
    "admin_pending" : "Ýí ÇäÊÙÇÑ ÇáÊÝÚíá",
    "admin_draftpendingpayment" : "ÚãáíÇÊ ÏÝÚ ÞíÏ ÇáÇäÊÙÇÑ",
    "admin_draft pending payment" : "ÚãáíÇÊ ÏÝÚ ÞíÏ ÇáÇäÊÙÇÑ", 
    "admin_willexpire" : "ÓÊäÊåí ÕáÇÍíÊå",
    "admin_expired" : "ãäÊåí ÇáÕáÇÍíÉ",
    "admin_rejected" : "ãÑÝæÖ",
    "admin_under review" : "ÞíÏ ÇáäÙÑ",
    "admin_user_draftpendingpayment" : "ÚãáíÇÊ ÏÝÚ ÞíÏ ÇáÇäÊÙÇÑ",
    "myprofile" : "ÍÓÇÈí",
    "myfav" : "ÇáãÝÖáÉ",
    "manage_settings" : "ÎíÇÑÇÊ",
    "manage_ads" : "ÌãíÚ ÇáÇÚáÇäÇÊ",
    "manage_users" : "ÇáãÓÊÎÏãíä",
    "manage_cats" : "ÇáÃÞÓÇã",
    "manage_twitter" : "ÊæíÊÑ",
    "manage_logs" : "ÚãáíÇÊ ÇáÏÎæá",
    "manage_payments" : "ÇáÏÎæá ÇáÏÝÚ",
    
    "category":"ÇáÃÞÓÇã",
    
    // tooltips 
    "Show List" : "ÚÑÖ Úáì Ôßá ÞÇÆãÉ ãÚ ÇáÕæÑ",
    "Show Gallery" : "ÚÑÖ Úáì Ôßá ãÚÑÖ ÕæÑ",
    "Show simple List" : "ÚÑÖ Úáì Ôßá ÞÇÆãÉ ÈÓíØÉ",
    "Show map List" : "ÚÑÖ ÎÇÑØÉ ÌææÌá ãÚ ÇáÇÚáÇäÇÊ ÇáãÍáíÉ",
    "help_on_status DRAFT" : "åÐÇ ÇáÇÚáÇä Ýí ÇáãÓæÏÉ æ áã íÊã äÔÑå",
    "help_on_status DRAFT PENDING PAYMENT" : "åÐÇ ÇáÇÚáÇä Ýí ÇäÊÙÇÑ ÏÝÚ ÇáãÓÊÍÞÇÊ",
    "help_on_status PUBLISHED" : "åÐÇ ÇáÇÚáÇä ãäÔæÑ",
    "help_on_status UNDER REVIEW" : "åÐÇ ÇáÇÚáÇä ÞíÏ ÇáãÑÇÌÚÉ",
    "help_on_status UNPUBLISHED" : "åÐÇ ÇáÇÚáÇä Êã ÓÍÈå ãä ÇáäÔÑ",
    "help_on_status REJECTED" : "åÐÇ ÇáÇÚáÇä Êã ÑÝÖå. ÇáÑÌÇÁ ÊÛííÑå ",
    "help_on_status DELETED" : "åÐÇ ÇáÇÚáÇä Ýí ÇáÃÑÔíÝ. ÓíÍÐÝ ",
    "help_on_status WILLEXPIRE" : "åÐÇ ÇáÇÚáÇä ÓÊäÊåí ÕáÇÍíÊå ",
    "help_on_status pty_top" : "åÐÇ ÇáÇÚáÇä íÙåÑ ÈÇáÃÚáì ",
    
    "help_on_status protype_pub" : "åÐÇ ÍÓÇÈ ÚÇã ãÑÆí ááÌãíÚ",
    "help_on_status protype_pub" : "åÐÇ ÍÓÇÈ ÎÇÕ ãÑÆí ááÌãíÚ",
    "help_on_status protype_pro" : "åÐÇ ÍÓÇÈ ÇÍÊÑÇÝí ãÑÆí ááÌãíÚ",
    
    "view all" : "ÚÑÖ Çáßá",
    "help link Main List" : "ÇáÚæÏÉ Çáì ÇáÞÇÆãÉ ÇáÑÆíÓíÉ",

    "help password rules" : "íÒíÏ ÇÓÊÎÏÇã ÇáÃÑÞÇã æÇáÑãæÒ æãÒíÌ ãä ÇáÃÍÑÝ ÇáßÈíÑÉ æÇáÕÛíÑÉ Ýí ßáãÉ ÇáãÑæÑ ãä ÕÚæÈÉ ÊÎãíä ßáãÉ ÇáãÑæÑ Ãæ ÇáÇÓÊíáÇÁ ÚáíåÇ !",
    
    "help_myads_published" : "ÇÚáÇäÇÊí ÇáãäÔæÑÉ",
    "help_myads_all" : "ÌãíÚ ÇÚáÇäÇÊí",
    "help_myads_pending" : "ÇÚáÇäÇÊ ÊäÊÙÑ ÇáãÑÇÌÚÉ",
    "help_myads_draft" : "ÇÚáÇäÇÊ Ýí ÇáãÓæÏÉ",
    "help_myads_draftpendingpayment" : "ÇÚáÇäÇÊ ÊäÊÙÑ ÇáÏÝÚ",
    "help_myads_deleted" : "ÇÚáÇäÇÊ ãäÊåíÉ Ãæ ãÍÐæÝÉ",
    "help_myprofile" : "ÚÑÖ ÍÓÇÈí",
    "help_myfav" : "ÚÑÖ ÇÚáÇäÇÊí ÇáãÝÖáÉ",
    "help_admin_pending" : "ÇÚáÇäÇÊ ÊäÊÙÑ ÇáãÑÇÌÚÉ",
    "help_admin_willexpire" : "ÇÚáÇäÇÊ Úáì æÔß ÇáÇäÊåÇÁ",
    "help_admin_expired" : "ÇÚáÇäÇÊ ãäÊåíÉ Ãæ ãÍÐæÝÉ",
    "help_admin_deleted" : "ÇÚáÇäÇÊ ãäÊåíÉ Ãæ ãÍÐæÝÉ",
    "help_admin_draftpendingpayment" : "ÇÚáÇäÇÊ ÊäÊÙÑ ÇáÏÝÚ",
    "help_admin_user_draftpendingpayment" : "ÍÓÇÈÇÊ ÊäÊÙÑ ÇáÏÝÚ",
    "help_manage_settings" : "ÎíÇÑÇÊ ÇáãæÞÚ",
    "help_manage_ads" : "ÇÏÇÑÉ ÌãíÚ ÇáÇÚáÇäÇÊ",
    "help_manage_cats" : "ÇÏÇÑÉ ÇáÃÞÓÇã",
    "help_manage_users" : "ÇÏÇÑÉ ÇáãÓÊÎÏãíä",
    "help_manage_twitter" : "ÃÑÓá ÊÛÑíÏÇÊ",
    "help_dashboard" : "ÇáÏÎæá Çáì áæÍÉ ÇáÊÍßã",
    "help_mydashboard" : "ÇáÏÎæá Çáì áæÍÉ ÇáÊÍßã",
    "help_manage_logs" : "ÚÑÖ ÓÌá ÇáÇÊÕÇáÇÊ",
    "help_manage_payments" : "ÚÑÖ ÓÌá ÇáãÏÝæÚÇÊ",


    "Sorry !":"ÚÝæÇ !", 
    "No items found" : "áÇ íæÌÏ ãÇ ÊÈÍË Úäå. ÈÚÖ ÇáãÚáæãÇÊ ÊÊØáÈ ÊÓÌíá ÇáÏÎæá ááæÕæá ÇáíåÇ.",
    "No items found - No ad" : "áíÓ áÏíß ÇÚáÇäÇÊ ÈÚÏ", 
    
    //tweeter
    "What are you doing?" : "ãÇ ÇáÌÏíÏ¿",
    "twitter header" : ": ÇáÊÛÑíÏ ãä ãæÞÚäÇ ãÈÇÔÑÉ",
    "Loading your tweets..." : "ÌÇÑí ÊÍãíá ÂÎÑ ÇáÊÛÑíÏÇÊ",
    "Timeline" : "ÂÎÑ ÇáÃÎÈÇÑ",
    
    // global home page messages 
    "You have %s article(s) waiting for your approval" : "áÏíß %s ÇÚáÇä íäÊÙÑ ãÑÇÌÚÊß : ", 
    "access here" : "ÇÖÛØ åäÇ ááÏÎæá",   
    
    // templates
    "some text"  : "une traduction de patrice  from patrice",
    "some more text"  : "another translation",
    "some text in french":"avec des é et des è",
    '%s text in french %s' : '%s exemple avec printf %s', 
    '%s text in french' : '%s exemple avec printf simple', 
    '%s comment' : '%s ÊÚáíÞÇÊ',
    '%s comments' : '%s ÊÚáíÞ', 
    'text in french' : 'äÕ ÈÇáÚÑÈíÉ',
    
    // dashboard 
    'adsnb' : 'nombre',
    '%adsnb' : '%',
    'val' : 'nombre',
    '%val' : '%',
    'metrics' : 'nombre',
    '%metrics' : '%',
    'nb' : 'nombre',
    'nbusers' : 'nombre',
    '%nbusers' : '%',
    'cattitle' : 'catégorie',
    'status' : 'état',
    'others' : 'autres',
    
    "dash manage ads" : "(ÅÏÇÑÉ)", 
    "dash manage users" : "(ÅÏÇÑÉ)",
    "dash manage cats" : "(ÅÏÇÑÉ)",
    "cumul users"  : "# ãÓÊÎÏãíä",
    
    "a10": "ãÓæÏÉ",
    "a20": "ÇÚáÇäÇÊ ÞíÏ ÇáãÑÇÌÚÉ",
    "a40": "ÇÚáÇäÇÊ ãäÔæÑÉ",
    "a60": "ÇÚáÇäÇÊ ÛíÑ ãäÔæÑÉ",
    "a80": "ÇÚáÇäÇÊ ãÍÐæÝÉ",
    "a90": "ÇÚáÇäÇÊ ãÑÝæÖÉ",
    "a45": "ÇÚáÇäÇÊ ÓÊäÊåí ÕáÇÍíÊåÇ",
    
    'fb' : 'ÇáÝíÓÈæß',
    
    'stat dashboard title' : 'áæÍÉ ÇáÊÍßã (ÇáÇÏÇÑÉ)', 
    'stat mydashboard title' : 'áæÍÉ ÊÍßãí', 
    
    'top_dashboard' : 'äÙÑÉ ÚÇãÉ', 
    'ad_vol_per_cat' : 'ÇÚáÇäÇÊ ÍÓÈ ÇáÞÓã', 
    'ad_vol_per_type' : 'ÇÚáÇäÇÊ ÍÓÈ ÇáäæÚ', 
    'ad_vol_per_time' : 'ÇÚáÇäÇÊ ÍÓÈ ÇáæÞÊ', 
    'ad_vol_per_delete' : 'ÃÓÈÇÈ ÍÐÝ ÇáÇÚáÇäÇÊ',
    
    'ad_vol_per_status' : 'ÇÚáÇäÇÊ ÍÓÈ ÍÇáÉ ÇáäÔÑ', 
    'user_vol_per_time' : 'ãÓÊÎÏãíä ÍÓÈ ÇáæÞÊ', 
    'user_vol_per_age' : 'ãÓÊÎÏãíä ÍÓÈ ÇáÃÞÏãíÉ', 
    'ad_vol_per_age' : 'ÇÚáÇäÇÊ ÍÓÈ ÇáÃÞÏãíÉ', 
    'user_vol_per_type' : "ÇáãÓÊÎÏãíä ÍÓÈ äæÚ ÇáÊØÇÈÞ",
    'user_vol_per_protype' : "ÇáãÓÊÎÏãíä ÍÓÈ ÇáãáÝ",  
    'ad_vol_per_user' : 'ÅÚáÇäÇÊ ÍÓÈ ÇáãÓÊÎÏãíä', 
    
    'Observation period : ' : 'ÇáÝÊÑÉ : ', 
    'all' : 'ÇáÌãíÚ', 
    'thisyear' : 'åÐå ÇáÓäÉ', 
    'thismonth' : 'åÐÇ ÇáÔåÑ',
    'thisquarter' : 'åÐÇ ÇáËáÇËí',


    // footer translation 

    // "A propos de ZADS" : "About", 
    // "ZADS est une plateforme d'échange d'annonces entre particuliers dans un domaine privé comme une entrepsie ou une collectivité." :
    //     "ZADS is a classidied ads platform available in hosted or in script mode to enable community to exchange product and services", 

    // "En savoir plus" : "Find our more", 
    // "S'abonner": "Subsribe", 
    // "Annonces par email":"Ads by email",    
    // "Offres et Demandes" : "Sell and Buy", 
    // "Aide et Support" : "Help and support", 


    // "Aide et Support" : "Help and Support", 
    // "Questions Frequentes (FAQ)" :"F.A.Q", 
    // "Tutoriels et démos" :"Demo and Tutorials", 
    // "Signaler un probléme":"Notify us on an issue", 
    // "Suivre / Contact" : "Follow / Contact",
    // "suivre ZADS.FR sur Twitter"  : "Follow us on Twitter", 
    // "suivre ZADS.FR sur Facebook"  : "Follow us on Facebook", 


    // "Me contacter" : "Contact us", 
    // "A propos" : "About this", 
    // "Infos légales et CGU"  : "Terms and Conditions", 
    // "Publicité" : "Advertising",
    // "Nous contacter" : "Contact us",
    // "Aide" :  "Help", 
    // "F.A.Q" :  "F.A.Q",  

    // new ZADS 4.6
    "around me :": "ÈÇáÞÑÈ ãä:", 
    ":unknown":": Ãíä¿", 
    "(change)" : "(ÊÛííÑ)",
    "(locate me)" :"(ÌÏäí)", 


    "display failed" : "ÎØÃ", 
    "Doh! Something happened : no authorized - private profile" : "ÚÐÑÇ ÃäÊ áÇ Êãáß ÇáÕáÇÍíÉ ááæÕæá Çáì åÐå ÇáãÚáæãÇÊ", 

    "post paidaccount" : "ÅÔÊÑÇß ãÏÝæÚ - ÇáÓÚÑ ÇáÓäæí", 
    "help_protype_paid" : "ÍÓÇÈ áäÔÑ ÚÏÏ ÛíÑ ãÍÏæÏ ãä ÇáÅÚáÇäÇÊ. ÇáÓÚÑ ÓäæíÇ. ÑÇÌÚ ÇáÔÑæØ ÇáÚÇãÉ",

    "Process ongoing ..." : "ÌÇÑí ÇáÊÍãíá¡ ÇáÑÌÇÁ ÇáÇäÊÙÇÑ ...", 


    // banners management 
    "title" :"ÇáÚäæÇä",
    "htmlcode": "ßæÏ Html",
    "clicktrackingurl": "ÑÇÈØ ÇÚÇÏÉ ÇáÊæÌíå", 
    "startdate": "ÊÇÑíÎ ÇáÈÏÇíÉ", 
    "enddate": "ÊÇÑíÎ ÇáäåÇíÉ", 
    "position": "ÇáãßÇä", 
    "clicks": "ÚÏÏ ÇáÖÛØÇÊ", 
    "impressions": "ÚÏÏ ãÑÇÊ ÇáÙåæÑ", 
    "CTR": "äÓÈå ÖÛØ ÇáÒæÇÑ Úáì ÑÇÈØ ÇáÇÚáÇä", 
    "resetclicks" : "ãÓÍ ÚÏÇÏ ÇáÖÛØÇÊ æ ÇáÙåæÑ",

    "desc_banner_title" :"ÇáÚäæÇä",
    "desc_banner_htmlcode": "ßæÏ Html",
    "desc_banner_clicktrackingurl": "ÑÇÈØ ÇÚÇÏÉ ÇáÊæÌíå", 
    "desc_banner_startdate": "ÊÇÑíÎ ÇáÈÏÇíÉ", 
    "desc_banner_enddate": "ÊÇÑíÎ ÇáäåÇíÉ", 
    "desc_banner_position": "ÇáãßÇä", 
    "desc_banner_clicks": "ÚÏÏ ÇáÖÛØÇÊ", 
    "desc_banner_impressions": "ÚÏÏ ãÑÇÊ ÇáÙåæÑ", 
    "desc_banner_CTR": "äÓÈå ÖÛØ ÇáÒæÇÑ Úáì ÑÇÈØ ÇáÇÚáÇä", 

    "help_banner_title" :"ÚäæÇä ÇáÈÇäÑ",
    "help_banner_htmlcode": "ßæÏ html - ÚäÏ ÇÓÊÎÏÇã ÈäÑ ÇáÎáÝíÉ ÊßÝí ÇáÇÔÇÑÉ Çáì ÑÇÈØ ÇáÇÚáÇä - ÇáÌÇÝÇ ÛíÑ ãÊÇÍ",
    "help_banner_clicktrackingurl": "ÇáÑÇÈØ ÇáÐí íÚíÏ ÊæÌíå ÇáãÓÊÎÏãíä ÚäÏ ÇáäÞÑ Úáì ÇáÅÚáÇä", 
    "help_banner_startdate": "ÊÇÑíÎ ÈÏÇíÉ äÔÑ ÇáÈäÑ", 
    "help_banner_enddate": "ÊÇÑíÎ äåÇíÉ äÔÑ ÇáÈäÑ", 
    "help_banner_position": "ãßÇä ÇáÈäÑ", 
    "help_banner_clicks": "ÚÏÏ ÇáÖÛØÇÊ Úáì ÇáÈäÑ", 
    "help_banner_impressions": "ÚÏÏ ãÑÇÊ ÙåæÑ ÇáÈäÑ", 
    "help_banner_CTR": "äÓÈå ÖÛØ ÇáÒæÇÑ Úáì ÑÇÈØ ÇáÇÚáÇä = ÚÏÏ ÇáÖÛØÇÊ / ÚÏÏ ãÑÇÊ ÇáÙåæÑ",

    "add banner" :"ÇÖÇÝÉ ÈäÑ ÇÚáÇäí",  
    "all banners" : "ÌãíÚ ÇáÈäÑÇÊ", 
    "manage_banners" : "ÇÏÇÑÉ ÇáÈäÑÇÊ",
    "help_manage_banners" : "ÇÏÇÑÉ ÇáÈäÑÇÊ",

    "Banner reset clicks confirmation" :"ÊÃßíÏ ÇáãÓÍ",
    "Banner reset clicks content" : "ÊÃßíÏ ãÓÍ ÚÏÇÏ ÇáÖÛØÇÊ æ ÇáØÈÇÚÉ", 
    "Banner delete confirmation" : "ÊÃßíÏ ÇáãÓÍ ÇáäåÇÆí",  

    " banner form header title" : "ÇäÔÇÁ ÈäÑ ÇÚáÇäí",
    " banner form header introduction" :"ÇäÔÇÁ ÈäÑ ÇÚáÇäí",
    "modify banner form header title" : "ÊÚÏíá  ÈäÑ ÇÚáÇäí",
    "modify banner form header introduction" :"ÊÚÏíá  ÈäÑ ÇÚáÇäí",


    // extended contact form
    "contact reason" : "ØáÈ", 
    "procpny": "ãÌÊãÚ", 
    "to email" :"ÇáÈÑíÏ ÇáÇáßÊÑæäí",

    '-- select one --' : '-- ÍÏÏ äæÚ ÇáØáÈ --',
    "Subscription" : "ÇáÊÓÌíá", 
    "Advertising" : "ÅÚáÇä", 
    "Information" :"ãÚáæãÇÊ", 
    "Support" :"ãÓÇÚÏÉ ÊÞäíÉ", 
    "Other" : "ØáÈÇÊ ÃÎÑì", 

    "Account fee is <b>%s %s </b> per year" : "åÐå ÇáÎÏãÉ ãÊæÝÑÉ ÈÜ <b>%s %s</b> ááÓäÉ", 

    "Please validate the location" : "ÑÌÇÁÇ Þã ÈÊÃßíÏ ÇáãäØÞÉ",

    "top register user" : "ÊÓÌíá ÇáÏÎæá", 

    // new zads 4.8 : 
    "Thanks you for your payment ! Your account is create, please login to connect" : "ÔßÑÇ áß Úáì ÊÓÏíÏ ãÓÊÍÞÇÊß ! ÍÓÇÈß ãÊÇÍ ÇáÂä. <br> Þã ÈÊÓÌíá ÇáÏÎæá ÈÇÓã ÇáãÓÊÎÏã æßáãÉ ÇáãÑæÑ ÇáÊí ÇÎÊÑÊåÇ. ",
    "show all" : "ÔÇåÏ ÌãíÚ ÇáÇÚáÇäÇÊ", 
    "Sort by hierarchy" : "ÊÑÊíÈ ÍÓÈ ÇáÓáã",
    "desc_parentid" : "ÞÓã ÑÆíÓí", 
    "help_parentid" : "ÅÐÇ ßäÊ ÊÑíÏ ãÓÊæííä ãä ÇáÃÞÓÇã¡ Þã ÈÊÍÏíÏ ÇáÞÓã ÇáÑÆíÓí. ", 
    "cat order plus" : "ÒíÇÏÉ ÇáÚÑÖ (0 = ÚÑÖ ÃæáÇ)",
    "cat order minus" : "ÊÞáíÕ ÇáÚÑÖ (0 = ÚÑÖ ÃæáÇ)",

    "pub users" : "ãÚáäíä ÇÎÑíä", 
    "Main list" : "ÇáÚæÏÉ Çáì ÇáÞÇÆãÉ ÇáÑÆíÓíÉ", 

    // place to translate catégories 
    "Categorie initial" : "ÇÓã ÇáÞÓã ÇáãÊÑÌã", 
    "patmisc à é é ç" : "ãÊÑÌã",


     // ----------  new zads 4.9 : 

    "plan_step1" : "ÇÎÊÑ äæÚ ÇáÇÔÊÑÇß", 

    "plan selection header title" : 
     "ÊÈÍË Úä ãÊÌÑ ÇÍÊÑÇÝí¿",
    "plan selection header line1" : 
     "ÇÎÊÑ ÃÍÏ ÇáÚÑæÖ ÇáÊÇáíÉ",


    "us_protype" : "ãÊÌÑ",
    "us_skills"  : "ÃÞÓÇã",
    "us_avatarimg"  : "ÔÚÇÑ",
    "us_bio"  : "ãÞÏãÉ ÞÕíÑÉ",
    "us_longdesc"  : "ãÞÏãÉ ØæíáÉ",
    "us_folioimg"  : "ãÚÑÖ ÇáÕæÑ",
    "us_videoembed"  : "ÑÇÈØ ÝíÏíæ",
    "us_phone" : "ÇáåÇÊÝ",
    "us_dispemail" : "ÇáÈÑíÏ ÇáÇáßÊÑæäí",
    "us_subscription" : "ÃíÇã",
    "ad_nb" : "ÇÚáÇäÇÊ",
    "ad_nbpics" : "ÕæÑ",
    "ad_duration" : "",
    "ad_featured" : "",
    "ad_perm" : "",
    "ca_restricted" : "",
    "sign up" : "ÇÔÊÑß",
    
    "plans_faq_1_question" : "Lorem ipsum dolor sit amet, consectetur",
    "plans_faq_1_response" : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras commodo nec elit nec sollicitudin. Aenean rutrum, magna a venenatis lobortis, lacus nisi tristique est, id euismod ante dolor vel orci. Quisque porttitor augue at fermentum ultricies.",

    "plans_faq_2_question" : "Lorem ipsum dolor sit amet, consectetur",
    "plans_faq_2_response" : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras commodo nec elit nec sollicitudin. Aenean rutrum, magna a venenatis lobortis, lacus nisi tristique est, id euismod ante dolor vel orci. Quisque porttitor augue at fermentum ultricies.",


    // nouvelles entrése du formulaire 
    "desc_label_plan" : "äæÚ ÇáÇÔÊÑÇß", 
    "desc_plan" : "ÅÔÊÑÇß" ,
    "you selected the  plan  : " : "áÞÏ ÞãÊ ÈÇÎÊíÇÑ ÇáÇÔÊÑÇß : ", 
    "help_plan" : "åÐÇ íÔíÑ Çáì äæÚ ÇáÇÔÊÑÇß ÇáÐí ÞãÊ ÈÇÎÊíÇÑå", 
    "desc_longdesc" :"ãÞÏãÉ ÔÇãáÉ",

    "longdesc" : "ãÞÏãÉ ÔÇãáÉ",
    "videoembed" : "ÑÇÈØ ÇáÝíÏíæ",

    // enhancements of zads 4.9
    "See details of this user" : "ÔÇåÏ ÈØÇÞÉ ÇáãÚáä", 
    "See all ads from this seller" : "ÔÇåÏ ÌãíÚ ÇÚáÇäÇÊ åÐÇ ÇáãÚáä", 
    "See all ads" : "ÌãíÚ ÇÚáÇäÇÊå",

    // pricing type 
    "desc_pricetype" : "ÇáÓÚÑ", 
    "help_pricetype" : "ÇÞÊÑÍ ÓÚÑÇ ÂÎÑ.", 
    "price" : "ÓÚÑ ËÇÈÊ",
    "to be discussed" : "ÞÇÈá ááãäÇÞÔÉ",
    "make an offer" : "ÛíÑ ÞÇÈá ááãäÇÞÔÉ",
    "on quote" : "ÍÓÈ ÇáÇÞÊÈÇÓ",
    "model dependant" : "ÍÓÈ ÇáäæÚ",

    "pricetype_tbdi" : "ÞÇÈá ááãäÇÞÔÉ",
    "pricetype_mano" : "ÛíÑ ÞÇÈá ááãäÇÞÔÉ",
    "pricetype_onqo" : "ÍÓÈ ÇáÇÞÊÈÇÓ",
    "pricetype_mode" : "ÍÓÈ ÇáäæÚ",

    "ad videoembed" : "ÑÇÈØ ÇáÝíÏíæ", 
    "(read more)" : "(ÇÞÑÃ ÇáãÒíÏ)",

    "Ad creation forbidden from your current profile.": "äæÚ ÇÔÊÑÇßß áÇ íÊíÍ áß äÔÑ ÇÚáÇäÇÊ.", 
    "You have exceeded quota of ad." : "áÇ íãßäß ÇäÔÇÁ ÇÚáÇäÇÊ áÃäß ÊÌÇæÒÊ ÍÏæÏ ÇÔÊÑÇßß.",

    // location based 
    "loccity" : "ÇáãÏíäÉ", 
    "locdept" :"ÇáÏÇÆÑÉ", 
    "locregion" : "ÇáãäØÞÉ",

    // traductions pour plan princing (customer specific)
    // SELECT INPUT 
    "-- no plan -- " : "-- áÇ íæÌÏ ÇÔÊÑÇß ãÍÏÏ --", 
    "options_Basic" : "ÇÔÊÑÇß ãÌÇäí", 
    "options_Premium" : "ÇÔÊÑÇß ãÏÝæÚ", 
    "options_Pro" : "ÇÔÊÑÇß ÇÍÊÑÇÝí", 

    "more cat" : "ÇáãÒíÏ ...", 
    "less cat" : "... ÊÞáíÕ ...",


    // zads @4.9.1
    "COPYRIGHT" : "&copy; 2013-2014 ZADS",

    //Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras commodo nec elit nec sollicitudin. Aenean rutrum, magna a venenatis lobortis, lacus nisi tristique est, id euismod ante dolor vel orci. Quisque porttitor augue at fermentum ultricies. Praesent lacinia lacinia nibh semper pharetra. Maecenas justo massa, cursus nec luctus sed, varius vitae quam. Nulla odio lorem, tempus dignissim hendrerit sit amet, tincidunt eu purus. Morbi a tincidunt lorem. Nam consectetur lorem eu mi tincidunt pharetra ac non augue. Interdum et malesuada fames ac ante ipsum primis in faucibus. Morbi auctor vestibulum lacus eu rhoncus. In sagittis arcu id tortor pharetra dignissim. Nullam elementum tristique lorem in semper. Duis id risus id magna ornare rutrum. Nam non nisl rhoncus, malesuada massa ac, suscipit mi. Aenean vel tincidunt tortor. Fusce feugiat, elit quis tempor faucibus, erat erat lobortis tortor, nec vulputate tellus odio eu neque.
    // end 
    'dummy' : 'ÛÈí'
    }; 
