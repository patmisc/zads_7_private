<?php 



  // ----- SET Tag for Admin pages   ----// 
  $isPageAdmin = false; $preload_facebook_js=false; $noscript=0;
  if ($isPageAdmin) $bodyextraclass = "admin-page"; else $bodyextraclass="main-site-page";

  // ini_set( 'default_charset', 'ISO-8859-1' );
  ini_set( 'default_charset', 'UTF-8' );

  // ----- INIT ESSENTIAL SETTINGS =  LANGUAGE  ----// 
  include_once "./phpsvr/init_settings.php";

  // --- global redirection to 404page when site of OFF-LINE 
  if ($SITE_OFF_LINE) {
    header("Location: offline_".$cust_lang_long.".php");
    die();
  }

  // global variable 
  if ($FORCE_FILE_VERSION) define('VERSION','?v='.ZADS_VERSION); 
  else define('VERSION',''); 

  // ----- BANNERS ----// 
  include_once "./phpsvr/banners.php"; 

  // ----- HTML SNAPSHOT FOR SEO   ----// 
  include_once "./phpsvr/html_snapshot_lib.php"; 
  $r= detect_escaped_fragment();

  // ----- for GOOGLEBOT, generates a special clean HTML page from PHP to avoid issues with JAVASCRIPT decoding----// 
  if (($SEO_GOOGLEBOT_DIRECTHTML &&  detect_googlebot()) || $SEO_INSPECT_LIKE_GOOGLEBOT){
    display_html_version($r);
    die; // end up here  
  }

  // ----- CDN management --/
  if ($CDN_EN && $CDN_URL) $ROOT_LIBS_URL = $CDN_URL; else $ROOT_LIBS_URL = "";
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML+RDFa 1.0//EN" "http://www.w3.org/MarkUp/DTD/xhtml-rdfa-1.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" dir="<?php echo $cust_dir;?>" lang="<?php echo $cust_lang;?>" xml:lang="<?php echo $cust_lang;?>" >
<head>

  <!-- CHARSET definition  -->
  <?php if ($cust_lang_short=="ar") { ?>
    <meta http-equiv="content-type" content="text/html;charset=windows-1252" /> 
    <!-- <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />    -->
    <?php } else if ($cust_lang_short=="tr") { ?>
    <meta http-equiv="content-type" content="text/html;charset=windows-1254" /> -->
  <?php } else { ?>
     <!-- <meta http-equiv="content-type" content="text/html; charset=iso-8859-15"/> -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />        
  <?php } ?>


  <?php 

    // display comments to track SEO activity 
    display_header_comments(); 

    if ( ($r==false) && !(isset($_GET['gplus'])) ) { 
       // DEFAULT HOME 
       $metasAr = Array('title'=> $cust_title, 'desc'=>$cust_description, 'image'=>$cust_logo_fb_uri, 'url'=>$DOMAIN_FQDN, 'gplus'=>$cust_gplus_url); 
    } else { 
      if (isset($_GET['gplus'])){
        // generate dynamically title & description depending on nav // 
        $metasAr = Array('title'=> trim($_GET['title']), 'desc'=>trim($_GET['desc']), 'image'=>trim($_GET['image']), 'url'=>trim($_GET['realurl'])); 
      } else {
        // HTML snapshot
        $metasAr = get_metas($r);
      }
    }
    // display METAS in all cases 
    echo display_metas($metasAr);  
   ?>

  <!-- not really used by SEO -->
	<meta name="keywords"  content="<?php echo $cust_keywords;?>" />

  <!-- SRC image for FACEBOOK sharing  -->
  <?php if ($cust_favicon_uri) {?>
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo $cust_favicon_uri;?>" /> 
    <link rel="icon" type="image/x-icon" href="<?php echo $cust_favicon_uri;?>" />
    <link rel="image_src" href="<?php echo $cust_favicon_uri;?>" />
  <?php } ?> 

  <?php if (isset($NO_MOBILE_CSS) && $NO_MOBILE_CSS===true) $tdummy=1; else { ?> 
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, shrink-to-fit=no,  minimal-ui" /> 
	<?php } ?> 

	<!-- LIB stylesheets -->
   
 <!--  <link rel="stylesheet" media="all" type="text/css" href="css/skeleton.css"  />
  <link rel="stylesheet" media="all" type="text/css" href="css/chosen.css"  />
 -->

  <link rel="stylesheet" media="all" type="text/css" href="<?php echo $ROOT_LIBS_URL;?>css/patmisc.lib.css"  />
  <link rel="stylesheet" media="all" type="text/css" href="<?php echo $ROOT_LIBS_URL;?>css/datepicker.css"  />

  <!-- awesome font  -->
  <!-- <link rel="stylesheet" media="all" type="text/css" href="css/font-awesome.min.css"> -->
  <link rel="stylesheet" media="all" type="text/css" href="css/font-awesome.css" />

  <!-- https://materialdesignicons.com/-->
  <link rel="stylesheet" media="all" type="text/css" href="css/materialdesignicons.min.css" />

  <!--[if IE 7]>
  <link rel="stylesheet" href="/css/font-awesome-ie7.css">
  <![endif]-->


  <link rel="stylesheet" media="all" type="text/css" href="css/bootstrap.css" />
  <link rel="stylesheet" media="all" type="text/css" href="css/patchonbootstrap.css" />

  <!-- THEME and CUSTOM  stylesheets -->
  <?php if (isset($THEME_MASTER_CSS_URL) && $THEME_MASTER_CSS_URL!="") { ?> 
  <link rel="stylesheet" media="all" type="text/css" href="<?php echo $THEME_MASTER_CSS_URL;?><?php echo VERSION;?> "  />
  <?php } else { ?>
    <link rel="stylesheet" media="all" type="text/css" href="<?php echo $ROOT_LIBS_URL;?>css/theme_style.css<?php echo VERSION;?>"  />
  <?php } ?> 
  
  <?php if (isset($THEME_CSS_URL) && $THEME_CSS_URL!="") { ?> 
    <link rel="stylesheet" media="all" type="text/css" href="<?php echo $THEME_CSS_URL;?><?php echo VERSION;?> "  />
  <?php } else { ?>
    <link rel="stylesheet" media="all" type="text/css" href="css/custom_style.css<?php echo VERSION;?>"  />
  <?php } ?> 

  <!--[if IE 6]> 
  <link rel="stylesheet" href="theme_style_IE6.css" type="text/css" media="screen" /> 
  <![endif]-->
  <?php if (isset($NO_MOBILE_CSS) && $NO_MOBILE_CSS===true) $tdummy=1; else { ?> 
  <link rel="stylesheet" media="screen and (min-device-width: 320px) and (max-width:480px)" href="css/mobile.css<?php echo VERSION;?>" type="text/css" />
  <link rel="stylesheet" media="screen and (min-device-width: 481px) and (max-device-width: 799px)" type="text/css" href="css/tablet.css<?php echo VERSION;?>"/>
  <link rel="stylesheet" media="screen and (min-width: 481px) and (max-width: 799px)" type="text/css" href="css/tablet.css<?php echo VERSION;?>"/>

  <!-- extra theme for mobile -->
  <?php if (isset($THEME_MOBILE_CSS_URL) && $THEME_MOBILE_CSS_URL!="") { ?> 
    <link rel="stylesheet"  media="screen and (min-device-width: 320px) and (max-width:480px)" type="text/css" href="<?php echo $THEME_MOBILE_CSS_URL;?><?php echo VERSION;?> "  />
  <?php } ?>

  <?php } ?>
  
  <!-- theme for PRINT  -->
  <link rel="stylesheet" href="css/theme_print.css<?php echo VERSION;?>" type="text/css" media="print"/>

  <!-- STYLE SWITCHER  -->
  <?php if (isset($STYLE_SWITCHER_EN) && $STYLE_SWITCHER_EN) { ?> 
  <link rel="stylesheet" href="css/zads-style-switcher.css" type="text/css" media="screen"/>
  <link href="" data-style="styles" rel="stylesheet" />
  <?php } ?>


  <!--  special meta for tablets and smartphones -->

  <link rel="apple-touch-icon" href="zadsmobicon.png" /> 
  <meta name="apple-mobile-web-app-capable" content="yes" />
  <meta name="apple-mobile-web-app-status-bar-style" content="black" />
  <link rel="apple-touch-startup-image" href="bg/iphonestartup2.png"/>
  <!-- <link rel="apple-touch-icon-precomposed" href="/images/icon.png"/> -->
	
  <!-- RSS feeds --> 
	<link rel="alternate" type="application/rss+xml" href="phpsvr/tmp1.php?rss=sell"  title="<?php echo $cust_motto;?> 10 dernieres offres et demandes" />
  <?php if ($ZETVU_AS_NEWS) { ?> 
  <link rel="alternate" type="application/rss+xml" href="phpsvr/tmp1.php?rss=zetvu"  title="<?php echo $cust_motto;?> 10 derniers ZeTvu" />
  <?php } ?> 

  <!-- meta for crawling AJAX elements  ** USE THIS ON HOME PAGE  *** -->
  <!-- <meta name="fragment" content="!"> -->

	
	<!-- native javascript functions (no jquery) to make some tests before starting HTML -->
  <script type="text/javascript" src="<?php echo $ROOT_LIBS_URL;?>lib/patmisc.preload.toolkit.min.js"></script> 
  
  <!-- adblocker detection  -->
  <script type="text/javascript" src="lib/ads.js"></script>
 
  <!-- google site verification --> 
  <?php if ($GOOGLE_SITE_VERIFICATION){?>
  <meta name="google-site-verification" content="<?php echo $GOOGLE_SITE_VERIFICATION;?>" />
  <?php } ?>



  <!-- EXTRA HEADER inserted by ZADS - configured in WEBADMIN  --> 
  <?php if ($EXTRA_HEADER_INFO){
      echo base64_decode($EXTRA_HEADER_INFO);
  } ?>


  <!-- SCRIPT for Google Analytics  JUST BEFORE HEAD END !!!!! --> 
  <?php if ($GOOGLE_ANALYTICS_ACCOUNT ){?>
  <script type="text/javascript">
    var _gaq = _gaq || [];
    _gaq.push(['_setAccount', '<?php echo $GOOGLE_ANALYTICS_ACCOUNT;?>']);
    _gaq.push(['_trackPageview']);
  
    (function() {
      var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
      ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
      var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
    })();
  </script>
  <?php } ?>

    <!-- set variable for admin  --> 
    <script type="text/javascript">
      var preload_facebook_js=false;  // default value
      <?php if ($isPageAdmin){?>
        var isPageAdmin=true; 
        
      <?php } else { ?>
        var isPageAdmin=false; 
    <?php } ?>
    </script>

</head>
    
<!-- Calculate the body style -->
  <?php
  if ($r==false){ 
    if ($thebanners['background_all']){
      $url = base64_decode($thebanners['background_all']['htmlcode']);
      $bodyextrastyle  =  "background : url('$url') fixed center 48px;";
      $bodyextraclass .= " hasbanner"; 
    }
  }
  ?>
<body id="top" itemscope="itemscope" itemtype="http://schema.org/WebPage" style=" <?php echo $bodyextrastyle ?> " class=" <?php echo $bodyextraclass ?> " lang="<?php echo $cust_lang; ?>" xml:lang="<?php echo $cust_lang;?>" xzads-lang="<?php echo $cust_lang_long; ?>" xzads-lang-support="<?php echo $cust_lang_support; ?>">
  
  <!-- MAIN TITLE for CRAWLERS -->
  <?php if (!detect_googlebot()){?>
  <noscript> <?php 
      if ( ($r==false) && !(isset($_GET['gplus'])) )  echo html_snapshot_display('maintitle',$r);  
     ?>
  </noscript>
  <?php } ?>

  <?php if ($thebanners['background_all']['clicktrackingurl']){ ?>
  <div id="body-clickeable-background" style="" rel="<?php echo $thebanners['background_all']['id'] ?>" turl="<?php echo $thebanners['background_all']['clicktrackingurl'] ?>">
  </div> <!--  END OF BODY BACKGROUND -->
  <?php }?>


  <!-- in this section is loaded the Banner that will be used leter on the javascript code  -->
  <?php   
    if ($r==false){
      foreach (['ad_detail_sidebar', 'user_detail_sidebar', 'ad_list_center_top', 'user_list_center_top', 'userpro_register_sidebar', 'ad_list_inner_static', 'mob_ad_list_inner_static'] as $bannerid) {
        echo '<div id="banner_pos_'.$bannerid.'" class="banner" style="display:none;">'; 
        display_banner($thebanners[$bannerid]);
        echo '</div>'; 
      }
    }
  ?>
  <!-- end Banner section -->




    <!-- START Z6.5.5 placeholder for VIDEO/AUDIO-->
    <?php if ($r==false) { ?>
    <div id="my_booth" class="modal_box mbox-window" style="display:none;">
    <!--     <select id="audioSource"></select>
      <select id="videoSource"></select> -->
      <div><i class=" close icon-fa-times-circle fs12 "></i></div>
      <h1 class="orange_text"></h1>
      <p class="intro_p"></p>
      
      <div class="booth_error error" style="display:none"></div>

      <div class="audio_recording all wrapper" style="display:none;">
        <div class="visu_wrapper">
          <canvas id="in-visu" class="visualizer"></canvas>
          <div class="visu_title hastext" z-label="visu in title"></div>
          <div><i class="mute_btn icon-fa-microphone-slash"></i></div>
        </div>
        <div><a class="record_btn dm_button2 fullwidth" z-label="record" z-label-alt="recording"><i class="icon-fa-microphone"></i><label></label></a></div>
        
        <!-- <canvas id="out-visu" class="visualizer"></canvas> -->

        <div class="wav_out_wrapper">
          <div>
            <span class="record_duration">0.000</span>
            <span class="record_duration_max"></span>
          </div>
          <div class="visu_wrapper">
            <canvas id="wavedisplay" class="visualizer" ></canvas>
            <div class="visu_title hastext" z-label="visu out title"></div>
            <div class="visu_timeline"></div>
          </div>
          <audio id="wav_audio_player" class="" ></audio>
          <div><a class="wav_playstop_btn dm_button2 fullwidth" z-label="rec play" z-label-alt="(rec playing) stop"><i class="icon-fa-play"></i><label></label></a></div>
          <div><a class="wav_download_btn dm_button2 fullwidth" z-label="rec download"><i class="icon-fa-download"></i><label></label></a></div>
          <div><a class="wav_save_btn dm_button2 fullwidth" z-label="rec save" z-label-alt="... saving"><i class="icon-fa-cloud-upload"></i><label></label></a></div>
          <div class="wav_save_progress booth_progress " style="display: none;" ><div class="bar" style="width: 0%;"></div><div class="percent">0%</div></div> 
        </div>
      </div>


      <div class="picture_snap all video_recording wrapper" style="display:none;">
        <div class="video_wrapper">
          <video autoplay id="my_main_video"></video>
          <div id="video-countdown" class="video-countdown" style="display: none;"><p>1</p></div>
          <div id="video-flash" class="video-flash" style="display: none;"></div>
          <div class="video_title hastext" z-label="video in title"></div>
        </div>
        
        <div><a class="video_snap_btn dm_button2 fullwidth" z-label="take screenshot" z-label-alt=""><i class="icon-fa-camera"></i><label></label></a></div>
        <div class="video_wrapper">
          <canvas id="snap_canvas" class="snap_canvas" ></canvas>
          <div class="video_title hastext" z-label="video out title"></div>
          <div class="video_effect " z-label=""></div>
          
          <div class="video_effect_range_wrapper" style="display: none;" >
            <input id="video_effect_range" type="range" min="0" max="50" value="25" step="1" class="vert">
            <div class="video_effect_range_value " z-label="">25</div>
          </div>

        </div>
        <div><a class="snap_effect_btn dm_button2 fullwidth disabled" z-id="0" z-label="snap effect"><i class="icon-fa-flask"></i><label></label></a></div>
        <div>
          <a class="snap_download_btn dm_button2 fullwidth disabled" z-label="snap download"><i class="icon-fa-download"></i><label></label></a>
          <a class="snap_download_hidden" style="display:none;"></a>
        </div>
        <div><a class="snap_save_btn dm_button2 fullwidth disabled"  z-label="snap save" z-label-alt="... saving"><i class="icon-fa-cloud-upload"></i><label></label></a></div>

      </div> 


    </div>
    <div id="my_booth_mask" class="mask toplayer"></div>
    <!-- END  Z6.5.5 placeholder for VIDEO/AUDIO-->
    <?php } ?>  
  

  <!-- placeholder for Facebook javascript-->
  <div id="fb-root"></div>
 
  <!-- MODL BOX !!!! BUT BE PUT FIRST  after the body ********* --> 
      <div id="boxes" class="toplayer">
      	<div id="dialog" class="mbox-window">
          <div id="mbox-close"> <a href="#" id="close" class="close"></a></div>
      	  <!-- empty space for mbox-header-->
      	  <div class="clearer">&nbsp;</div>
        	<div id="mbox-body">
          </div>  		
      		<div id="mbox-footer"> <a href="#" class="close"></a></div>
        </div>
       	<div id="mask" class="mask toplayer"></div>
       	<div id="mask2" class="mask toplayer"></div><!-- mask for displaying "loading... banner-->
      </div>


      <div class="box midlayer">
        <div id="modal_form" class="modal_box mbox-window">
          <div class="mbox-close"> <a href="#" id="close" class="close"></a></div>
          <!-- empty space for mbox-header-->
          <div class="clearer">&nbsp;</div>
          <div id="mbox-body" class="mbox-body"></div>      
          <div id="mbox-footer" class="mbox-footer"> <a href="#" class="close"></a></div>
        </div>
            <div id="mask3" class="mask midlayer"></div>
      </div>

      <div class="box lowlayer">
        <div id="modal_display" class=" modal_box mbox-window">
          <div class="mbox-close"> <a href="#" id="close" class="close"></a></div>
          <div class="clearer">&nbsp;</div>
          <div id="mbox-body" class="mbox-body"></div>      
          <div id="mbox-footer" class="mbox-footer"> <a href="#" class="close"></a></div>
        </div>
            <div id="mask4" class="mask lowlayer"></div>
      </div>

      
      <!-- second box to go against IE ubg -->
      <div id="box2">
        <div id="mask3" class="mask"></div>

      </div>
      
    <!-- network start -->
     <?php if (!$LAYOUT_BT_HEADER) { ?>
    <div id="network">
      <div id="network-wrapper" class="center-wrapper">
      
        <div id="network-wrapper-left"  class="left">

          <!-- placeholder for mobile only navigation  -->
          <div id="nav-mobile-wrapper" class="large-hidden" >
          </div>

          <!-- logo -->
          <div id="logo_wrapper" class="left">
            <?php if (($cust_logo_uri!="") && !$LAYOUT_HEADER_WIDGETS_EN) { ?>
              <div style="float:none;">
                <a href="" title="<?php echo   (stripslashes($cust_site_motto)); ?>" id="logo" class="">
                  <img  alt="<?php echo   (stripslashes($cust_site_name)); ?>"  src="<?php echo $cust_logo_uri; ?>" height="40" /></a>
              </div>
            <?php } ?>
            <div id="site-motto-below-logo" class="" style="float:none;"><?php if ($r==false) echo   (stripslashes($cust_site_motto)); ?></div>
          </div>

          <!-- site name and motto -->
          <div id="info"> 
            <ul id="info-ul">
              <a href="./"><li id="site-name" class="quiet"><?php if ($r==false) echo   (stripslashes($cust_site_name)); ?></li></a>
              <li id="network-wrapper-ads" class="quiet"></li>
              <li class="text-separator">&nbsp;</li>
              <li id="cnx-label" class="allwhitespan inline"></li>
            </ul>

            <!-- motto -->
            <div id="site-motto" class=""><?php if ($r==false) echo   (stripslashes($cust_site_motto)); ?></div>
                   <div class="clear"></div>
          </div>     
        </div> 
        

        <!-- language flags -->
        <div id="network-wrapper-flags" class="right">
        	<a href="#" class="lang-menu-link">
            <span class="flags fr"></span>
            <!-- <span class="down-arrow" style="display:none"></span> -->
          </a>
          <div id="lang-drop_container" class="lang-menu"></div>
        </div>
      
        <!-- buttons  -->
        <div id="network-wrapper-right" class="right">
            <!-- placeholder for buttons and other links -->
        </div>

       <div class="clearer">&nbsp;</div>

      </div>
    </div>

    <?php } else if ($LAYOUT_BT_HEADER!="none") { ?>
    <div id="network">
      <header id="network-wrapper" class="center-wrapper hdr">

          <!-- placeholder for mobile only navigation  -->
          <div id="nav-mobile-wrapper" class="large-hidden" >
          </div>

          <?php if (($cust_logo_uri!="") && !$LAYOUT_HEADER_WIDGETS_EN) { ?>
          <div class="pull-left elem no-hover hdr-logo">
            <a class="  hdr-btn" title="<?php echo   (stripslashes($cust_site_motto)); ?>"> 
              <img  alt="<?php echo   (stripslashes($cust_site_name)); ?>"  src="<?php echo $cust_logo_uri; ?>" />
            </a>
          </div>
          <?php } ?>

          <div class="pull-left elem  no-hover hdr-tagline">
            <a href="./" class="hdr-btn"> 
              <div class="hdr-title"><?php if ($r==false) echo   (stripslashes($cust_site_name)); ?></div>
              <div class="hdr-motto"><?php if ($r==false) echo   (stripslashes($cust_site_motto)); ?></div>
            </a>
          </div>


          <!-- languages -->
          <div id="network-wrapper-flags"  class="pull-right elem">
            <a class="hdr-btn lang-menu-link" href="/inbox" data-href="/inbox" data-toggle="drop-down" rel="nofollow">
                <div class="">
                  <span class="flags fr"></span>
                </div>
                <div id="lang-drop_container" class="lang-menu"></div>
            </a>
          </div>

          <div class="pull-right elem" id="hdr-logged-user">
            <!-- contextual area to insert login informations  -->
          </div>


          <div class="pull-right " id="hdr-notifs-section">
            <!-- contextual area to insert notifications -->
          </div>

          <div class="pull-right" id="hdr-buttons-section">
          <!-- contextual buttons will be inserted here -->
          </div>


      </header>
    </div>





    <?php } ?>
    <!-- end network -->


      
  <div id="site">
	<div class="center-wrapper">

    <!-- HEADER WIDGETS  section  -->
    <?php
    if ($LAYOUT_HEADER_WIDGETS_EN){ ?>
     <div id="header-widgets-section" class="">
      <div class="logo">
         <?php if  ($ABOUT_IN_HEADER) { ?>

          <div class="about-in-header"><?php echo   (stripslashes($cust_about_footer_desc));?> </div>

         <?php } else { ?>
            <h1> <a href="">
                <img src="<?php echo $cust_logo_uri; ?>" alt="<?php echo   (stripslashes($cust_site_name)); ?>" style="opacity: 1;" />
                </a> 
            </h1>
          <?php } ?>
      </div>

      <div class="headerwidget">
        <div class="logowidget">
          <?php 
          if ($r==false){ 

            //if (has_banner($thebanners['headerwidget_right_top'])){ 
              if (1==1){
            ?>
            
            <div id="banner_pos_headerwidget_right_top" class="w480h80" style="">
 
              <?php display_banner($thebanners['headerwidget_right_top']); ?>
              <!-- <img src="adsense_ban/ad_480x80.gif" /> -->

            </div>
          <?php } } ?>
          <div class="clear"></div>
        </div>
      </div>
      <div class="clear"></div>

     </div> 
    <?php } ?>
    <!-- END HEADER WIDGETS section  -->



	<div class="center-wrapper-inner">


    <div id="logo-overlay"></div>
	  
		<div id="header" >   

      <?php if ($r && !$SEO_NO_SPECIAL) { ?>
        <!-- Section for Google CRAWLERS supporting JS/AJAX -->
        <ul class="tabbed">
        <?php  echo html_snapshot_display('nav',$r);  ?>
        </ul>
        <!-- END Section for Google CRAWLERS supporting JS/AJAX -->
      <?php }  ?>

			<div id="navigation">
				<div id="main-nav">
          <div id="main-nav-links">
  					<ul class="tabbed">
  					<li></li> <!-- to be HTML W3C compliant -->
            </ul>
  					<!-- place holder for main menu (JAVASCRIPT MODE) -->
            
            <?php if (!detect_googlebot()){?>
            <noscript> 
                <!-- START NAVIGATION version for Crawlers and browsers without Javascript  -->
                <?php  echo html_snapshot_display('nav',$r);  ?>
            </noscript>
            <?php } ?>
            <!--  END version no-JS -->
  					
            

  				</div>
  			 
  				<div id="main-nav-search" style="display:none;">
  				 <form id="search-bar" action="#">
            <div class="input-group">
                <input type="text" tabindex="0" size="40" class="text" id="search" name="search" placeholder="" value="" />  
                <span id="adv-search-open-bton" class=""><i class="icon-fa-search-plus"></i></span>
            </div>
          </form>
  				</div>
          <div class="clearer">&nbsp;</div>

          <div id="main-nav-adv-search" > 
             <!-- placeholder for advanced search area  -->
          </div>  					
				</div>
				
				
        <div id="overall-sub-nav">
				</div>
				
				
				<div class="clearer">&nbsp;</div>
			
      </div>
          <?php if ($r==false) { ?>
					<!-- Global message Area  --> 
          <div id="global_message" class="msg_banner" style="display:none;">
            <a href="" class="msg-close" nottip="yes"></a> <span id="inner"></span> 
          </div><div class="clearer">&nbsp;</div>   

          <!-- Notification AREA  --> 
          <div id="global_notif_wrapper" class="notif_banner" style="display:none;">
          </div><div class="clearer">&nbsp;</div>   
         
          <?php } ?> 
          <!-- Paypal test  -->
		</div>
		
		
    <div class="clearer">&nbsp;</div>

		<div class="main" id="main-two-columns">

        <!-- Top gallery when positionned into FULL WIDTH --> 
        <?php 
        if ($LAYOUT_GALLERIE_WIDGETS_FORCED_FULLWIDTH){ ?>
        <div id="topgallery" class="skgrid fullwidth" style="display:none;">
          <div class="section-content"></div>
        </div>
        <?php } ?>


        <?php if ($r && !$SEO_NO_SPECIAL) { ?>
          <!-- Section for Google CRAWLERS supporting JS/AJAX -->
          <?php  echo html_snapshot_display('content',$r);  ?>
          <!-- END Section for Google CRAWLERS supporting JS/AJAX -->
        <?php }  ?>

			<div class="left" id="main-left"> 

        <div class="jsloading"></div>

        <!-- placeholder to add the banners recommended =  LEADRERBOARD 728x90  (Disabled on mobile) -->
        <div id="banner_pos_page_center_top" class="<?php echo has_banner($thebanners['page_center_top']) ?>">
          <!-- DYNAMIC banner will be inserted here -->
          <div class="genuinebanner"><?php if ($r==false){  display_banner($thebanners['page_center_top']);} ?></div>
          <div class="altbanner"></div>
        </div>

        <!-- placeholder to add the banners recommended =  MOBILE ONLY ->  720x50 -->
        <div id="banner_pos_mob_page_center_top" class="<?php echo has_banner($thebanners['mob_page_center_top']) ?>">
          <!-- DYNAMIC banner will be inserted here -->
          <?php if ($r==false){  display_banner($thebanners['mob_page_center_top']);} ?>
        </div>


        <!-- Top gallery when positionned into CONTENT SECTION --> 
        <?php 
        if (!$LAYOUT_GALLERIE_WIDGETS_FORCED_FULLWIDTH){ ?>
        <div id="topgallery" class="skgrid" style="display:none;">
          <div id="bannertitle"><div class="ribbon-front2">R</div></div>
          <div class="section-content"></div>
        </div>
        <?php } ?>

        <!-- Overlay message area --> 
        <div id="oe_wrap" class="oe_wrap" style="display:none;">
          <div class="icon"></div><div class="content"></div><div id="oe_close"></div>
        </div>    
        
          <!-- general loading box & Javascript control  --> 
          <div class="loadarea" id="mainloading">

          <!-- START FULL CONTENT version for Crawlers and browsers without Javascript  -->
          <?php if (!detect_googlebot()){?>
          <noscript> 
            <?php 
             if (!isset($_GET['gplus'])){
                echo html_snapshot_display('content', $r);  
              }
            ?>
          </noscript>
          <?php } ?>
          <!--  END version no-JS -->

          <!-- LOADING Section  --> 
          <?php 
            if ($LOADING_IMG){ 
              // ideal size is 970px width x 600 px height (2/3 of page height)
              ?>
              <!-- loading images -->
              <div class="loading-imgs">
                <img width="100%" src="<?php echo $LOADING_IMG;?>" />
              </div>
              <!-- loading text -->
              <div class="loading-content">
                <div class="loading-text">
                  <?php  if (!$noscript) echo $cust_loading_msg;?>
                </div>
              </div>

              <!-- end loading section -->
              </div>
              <?php

            }
            else {
              if (($r==false)) { ?>
              <div class="loadbox" id="b1"></div>
              <div class="loadbox" id="b2"></div>
              <div class="loadbox" id="b3"></div>
              <div class="loadbox" id="b4"></div>
              <div class="loadbox" id="b5"></div>
              
              <div class="loadspan" id="loadspan"><?php if ($noscript!=1) echo $cust_loading_msg;?></div>
          </div>
        
          <?php } else echo "</div>";  }?>

         <!-- AREA to display Breadcrumb  --> 
          <div id="breadcrumbs" class="clear  dyn_content" style="display:none;">
        	</div> 
        	
        	<div id="output"></div>

          <!-- just for testing calendar function / DEBUG -->
          <div id="test_calendar"></div>
        
          <!-- AREA to display FORM to create/modify an Ad  --> 
          <div id="forminput" class="hideit  dyn_content" >
        	</div><div class="clearer">&nbsp;</div>   
        	
        	
          <!-- AREA to display Ad details  --> 
          <div id="addetails" class="addetails dyn_content" > 
          </div> <div class="clearer">&nbsp;</div>           

          <!-- AREA to display the List of Articles  -->
          <div id="adlist" class="dyn_content">
          </div> <div class="clearer">&nbsp;</div>

          <!-- AREA to display static pages -->
          <div id="pages">
            <?php if ($page_home_is_php) { require_once($page_home_php_url);}?>
          </div> <div class="clearer">&nbsp;</div>

			</div>


      <!-- sidebar RIGHT  -->
			<div class="right sidebar" id="sidebar">

        <!-- placeholder to add the banners recommended =  180x150 -->
        <div id="banner_pos_sidebar_right_top" class="<?php echo has_banner($thebanners['sidebar_right_top']) ?>" >
          <?php if ($r==false){  display_banner($thebanners['sidebar_right_top']); } ?>
          <!-- <img src="./adsense_ban/small_rectangle_180x150.png"/>-->
        </div>

         <div id="banner_pos_sidebar_right_top2" class="<?php echo has_banner($thebanners['sidebar_right_top2']) ?>" >
          <?php if ($r==false){  display_banner($thebanners['sidebar_right_top2']); } ?>
          <!-- <img src="./adsense_ban/small_rectangle_180x150.png"/>-->
        </div>
			
			
			 <!-- <div class="section" id="sidebar-subnav" style="width:100%;">	 -->
			   <div id="sub-nav" class="section" style="display:none;">
			   <!-- area for JS SUB-NAV menu -->
			   </div>
			 <!-- </div> -->

       <!-- <div class="section" id="sidebar-locnav" style="width:100%;">   -->
         <div id="loc-nav" class="section" style="display:none;">
         <!-- area for JS LOC-NAV menu -->
         </div>
       <!-- </div> -->
  		<!-- AREA where other section will be displayed --> 
            				
			</div> <!-- end sidebar -->

			<div class="clearer">&nbsp;</div>

		</div>

	</div>

	</div>


 <?php
    if ($r==false){ 
    ?>

    <div id="dashboard">
      <div id="dashboard-content">

        <?php if (has_banner($thebanners['dashboard_bottom'])){ ?>
        <div id="banner_pos_sidebar_right_top2" style="display:inline-block;"  class="<?php echo has_banner($thebanners['dashboard_bottom']) ?>" >
            <?php  display_banner($thebanners['dashboard_bottom']);  ?>
            <!-- <img src="./adsense_ban/small_rectangle_180x150.png"/>-->
        </div>
        <?php } else { ?> 

          <?php  if ($cust_about_footer_desc && !$ABOUT_IN_HEADER) { ?>
          <div class="column " id="column-1">
            <div class="column-content">
              <div class="column-title totranslate">A propos </div>
              <div class="about-desc"><?php echo   (stripslashes($cust_about_footer_desc));?> </div>
              <a class="learnmore totranslate" href="<?php echo $cust_aboutus_url;?>">En savoir plus</a>
            </div>
          </div>
          <?php } ?>

          <div class="column  help" id="column-3">
            <div class="column-content">
              <div class="column-title totranslate">Aide et Support</div>
              <ul class="plain-list">

              <?php  if ($cust_help_url) { ?>
                <li class="help_url"><a class=" " href="<?php echo $cust_help_url;?> "><i class="icon-fa-info mr6"></i><span class="totranslate">Aide et Support</span></a></li>
              <?php } ?>
              
              <?php  if ($cust_faq_url) { ?>
                <li class="faq_url"><a class=" " href="<?php echo $cust_faq_url;?> "><i class="icon-fa-info mr6"></i><span class="totranslate">Questions Fréquentes (FAQ)</span></a></li>
              <?php } ?>

              <?php  if ($cust_demo_url) { ?>
                <li><a class="demo_url" href="<?php echo $cust_demo_url;?> "><i class="icon-fa-lightbulb-o mr6"></i><span class="totranslate">Tutoriels et démos</span></a></li>
              <?php } ?>

              <?php  if ($cust_forum_url) { ?>
                <li><a class="forum_url" href="<?php echo $cust_forum_url;?> "><i class="icon-fa-comments mr6"></i><span class="totranslate">FORUM</span></a></li>
              <?php } ?>
               
               <li><a class="feedback_me" id="feedbackme" href="#"><i class="icon-fa-comment mr6"></i><span class="totranslate">Signaler un problème</span></a></li> 
              </ul>
            </div>

          </div>
        <?php }  ?>

        <div class="column " id="column-4">

          <div class="column-content">
            <div class="column-title totranslate ">Suivre / Contact</div>
            <ul class="social-footer">
              <?php  echo display_social_footer_bar(); ?>
            </ul>
            <div class="clear"></div> <!-- reset -->
            
            <!-- Newsletter section  -->
            <div class="newsletter-wrapper">
              <!-- placeholder for Newletters  -->
            </div>
            <!-- END newsletter section  -->


          </div> 
        </div> <!--  end COLUMN -->

        <div class="clearer">&nbsp;</div>
      </div> <!--  end DASHBOARD CONTENT  -->
    </div> <!--  end DASHBOARD  -->
    


    <?php } ?>


</div>

     <!-- add FOOTER -->
    <?php include_once("footer.php"); ?>    
    <!-- END FOOTER -->




<!-- VERY IMPORTANT -> Special zone for storing MEYWORDS for URL Rewritte to be used by JS  -->
<?php echo display_keywords_seo(); ?>

<!-- VERY IMPORTANT -> Special zone for storing SOCIAL URLs  -->
<?php echo display_social_urls(); ?>


  <!-- Jquery LIB -->                                                                       
  <script type="text/javascript" src="<?php echo $ROOT_LIBS_URL;?>lib/jquery-1.7.min.js"></script> 
 
  <script type="text/javascript">
    function loadbarAnimStart(){
      i=0;
      $('.loadbox').each(function (){
        var e=$(this), delayedstart=i*200, duration=300, opacity_start=(i%2) ? 1 : 0.5;
        setTimeout(function() { e.animate({opacity:opacity_start}, duration, function() {
            e.animate({opacity: 0.2}, duration, function() {});
        }) }, delayedstart);
        i++; 
      });
    };
    loadbarAnimStart();
    loadanim = setInterval(loadbarAnimStart, 1400);
  </script>

  <!-- Jquery plug-in -->
  
  <script type="text/javascript"  src="<?php echo $ROOT_LIBS_URL;?>lib/patmisc.postload.lib.min.js"></script> 
  
  <!-- HELLO- SSO plugin -->
  <?php if ($OAUTH_SSO_EN) { ?> 
    <script type="text/javascript" charset="utf-8" src="<?php echo $ROOT_LIBS_URL;?>lib/hello.min.js"></script>    
  <?php }?>

  <!-- LANGUAGE File (MASTER) -->
  <?php if (!$DISABLE_TRANSLATION) { ?> 
    <script type="text/javascript" charset="utf-8" src="lang/<?php echo str_replace('_','-',$cust_lang_long); ?>.js<?php echo VERSION;?>"></script>
  <?php }?>

  <!-- DATE PICKER --> 
  <script type="text/javascript" src="<?php echo $ROOT_LIBS_URL;?>lib/bootstrap-datepicker.min.js"></script>    

  <!-- moment language script -->
  <script type="text/javascript" charset="utf-8" src="<?php echo $ROOT_LIBS_URL;?>lib/moment-with-locales.min.js"></script> 


  <!-- LANGUAGE File (CUSTOM) - COMING ON TOP OF EXISTING ONE -->
  <?php if (isset($THEME_CUST_LANG_URL) && $THEME_CUST_LANG_URL!="" && !$DISABLE_TRANSLATION) { ?> 
  <?php if ($cust_lang_short=="ar") { ?>
      <script type="text/javascript"  charset="windows-1252" src="<?php echo $THEME_CUST_LANG_URL.str_replace('_','-',$cust_lang_long); ?>.js<?php echo VERSION;?>"></script>
    <?php } else { ?>
      <script type="text/javascript" charset="utf-8" src="<?php echo $THEME_CUST_LANG_URL.str_replace('_','-',$cust_lang_long); ?>.js<?php echo VERSION;?>"></script>
    <?php }?>
  <?php }?>





  <!-- Load graphical library and associated country map  -->
  <?php if ($ENABLE_COUNTRY_MAP) { ?>  
    <script type="text/javascript" src="<?php echo $ROOT_LIBS_URL;?>lib/raphael-min.js"></script> 
    <script type="text/javascript" src="<?php echo $ROOT_LIBS_URL;?>map/map_<?php if (!$LOCALE_DEFAULT_SUB_CODE) echo $LOCALE_DEFAULT_COUNTRY_CODE; else echo $LOCALE_DEFAULT_SUB_CODE
      ?>.js<?php echo VERSION;?>"  charset="utf-8" ></script> 
  <?php } ?>


  
  <!-- location Array (Javascript) --><!-- 
  <script type="text/javascript" src="lib/ArrayDept.js"></script>
   -->

  <!-- Core feature of ZADS--> 
  
 
  <script type="text/javascript" charset="utf-8" src="<?php echo $ROOT_LIBS_URL;?>js/zads.js<?php echo VERSION;?>"></script> 
  <script type="text/javascript" charset="utf-8" src="<?php echo $ROOT_LIBS_URL;?>js/zads_post.js<?php echo VERSION;?>"></script> 

  <!-- CUSTOM STAGE  feature of ZADS -->
  <?php if (isset($THEME_EXTRA_JS_URL) && $THEME_EXTRA_JS_URL!="") { ?> 
   <script type="text/javascript" charset="utf-8" src="<?php echo $THEME_EXTRA_JS_URL;?><?php echo VERSION;?>"></script> 
  <?php } ?>

  <!-- ELEVATED ZOOM LIB if function is activated -->
  <?php if (isset($IMG_ZOOM_EN) && $IMG_ZOOM_EN) { ?> 
  <script  type="text/javascript" charset="utf-8" src='lib/jquery.elevateZoom.min.js'></script>
  <?php } ?>

  <!-- STYLE SWITCHER  -->
  <?php if (isset($STYLE_SWITCHER_EN) && $STYLE_SWITCHER_EN) { ?> 
  <script  type="text/javascript" charset="utf-8" src="lib/zads-style-switcher.min.js"></script>
  <?php } ?>


  <!-- google map API *** asynchronously loaded *** --> 
  
  <!-- evernote script *** asynchronously loaded *** --> 


</body>
</html>
