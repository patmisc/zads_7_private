<?php 
  // ----- add generic header for STATIC pages  version 1-------------//
  include_once "header-static.php";
?> 

  <div id="site">
	<div class="center-wrapper">


    <div id="header">

      <!-- Main menu -->
      <?php  include_once "site-title-static.php"; ?>
      <!-- end main menu -->


      <div class="clearer"> </div>

      <!-- sub menu navigation  -->
      <div id="navigation">
        <div id="main-nav">
          <div id="main-nav-links">
            <ul class="tabbed">
            </ul>
          </div>
          <div class="clearer"> </div>
        </div>
        <div class="clearer"> </div>
      </div>
      <!-- end sub menu navigation -->

    </div>

		<div class="main" id="main-two-columns">
		
      <div class="tc-maintext">

       
            <h1>Comment gérer les cookies ?</h1>
      
      <h2>Définition des cookies</h2>
        <p> </p>
      <p align="justify">Les cookies sont des petits fichiers placés sur le disque dur de votre terminal (ordinateur, smartphone ou tablette). <strong><?php echo $SITE_NAME;?></strong> utilise des cookies pour vous proposer ses services et assurer la gestion de votre compte. Il s'agit essentiellement de cookies dits <strong>« cookies de session »</strong>, à savoir des cookies automatiquement supprimés de votre disque dur dès que votre session est terminée (c'est-à-dire quand vous cliquez sur le lien "Déconnexion" ou lorsque vous fermez votre navigateur Internet préféré).</p>
        <p> </p>
        
      <h2>Comment activer les cookies ?</h2>
        <p> </p>
      <p align="justify">L'utilisateur doit savoir que <strong><?php echo $SITE_NAME;?></strong> se réserve la possibilité d'implanter un "cookie" sur son terminal (ordinateur, smartphone ou tablette). Le "cookie" n'a pas pour visée d'identifier l'utilisateur mais de sauvegarder des informations relatives à sa navigation à partir de son terminal sur le site <strong><?php echo $SITE_NAME;?></strong> à savoir  - sans que cette liste soit exhaustive - : toute information relative aux pages consultées ainsi que les dates et heures de consultation, l'acceptation ou la non acceptation des conditions particulières d'accès du site ou de certaines sections du site...</p>
      
            <p> </p>
        
            <h2>Comment désactiver les cookies ?</h2>
        <p> </p>
        
      <p align="justify">Il est précisé que tout utilisateur conserve la possibilité de s'opposer à l'implémentation de "cookies" sur son terminal en configurant son navigateur Internet.</p>
      
      <p> </p>


    <p align="justify">Il est également précisé qu'en choisissant la désactivation des "cookies", l'utilisateur peut ne plus avoir accès à certaines sections du site <strong><?php echo $SITE_NAME;?></strong> voire d'utiliser certains services.</p>
              
      <div styme="clear:both;"></div>

      <p> </p>
          
      <strong>Date de dernière mise à jour : </strong>1er janvier 2015 - rev 1.0</strong>
          
      <div class="clearer"> </div>


      </div>

			<div class="clearer"> </div>

		</div>

 <!-- add FOOTER -->
    <?php include_once("footer.php"); ?>    
    <!-- END FOOTER -->

    

	</div>
</div>

   <!-- Jquery  & plug-in -->
  <script type="text/javascript" src="lib/jquery-1.4.4.min.js"></script> 
  <script type="text/javascript" src="lib/jquery-ui.min.js"></script> 
  <script type="text/javascript" src="lib/patmisc.postload.lib.min.js"></script> 

  <!-- LANGUAGE File (MASTER) -->
  <?php if (!$DISABLE_TRANSLATION) { ?> 
    <script type="text/javascript" src="lang/<?php echo str_replace('_','-',$cust_lang_long); ?>.js"></script>
  <?php }?>


  <!-- LANGUAGE File (CUSTOM) - COMING ON TOP OF EXISTING ONE -->
  <?php if (isset($THEME_CUST_LANG_URL) && $THEME_CUST_LANG_URL!="" && !$DISABLE_TRANSLATION) { ?> 
    <script type="text/javascript" src="<?php echo $THEME_CUST_LANG_URL.str_replace('_','-',$cust_lang_long); ?>.js"></script>
  <?php }?>

  <!-- Core feature of ZADS ESSENTIAL STATIC PAGES  --> 
  <script type="text/javascript" src="js/zads-static-page.js"></script> 


</body>
</html>
