<?php 
  // ----- add generic header for STATIC pages  -------------//
  include_once "header-static.php";
  $r=false; 
?> 

  <div id="site">
	<div class="center-wrapper">


    <div id="header">

      <!-- Main menu -->      
      <?php  include_once "site-title-static.php"; ?>
      <!-- end main menu -->


      <div class="clearer">&nbsp;</div>

      <!-- sub menu navigation  -->
      <div id="navigation">
        <div id="main-nav">
          <div id="main-nav-links">
            <ul class="tabbed">
            </ul>
          </div>
          <div class="clearer">&nbsp;</div>
        </div>
        <div class="clearer">&nbsp;</div>
      </div>
      <!-- end sub menu navigation -->

    </div>

		<div class="main" id="main-two-columns">
		
            <div class="tc-maintext">
            
<h1>Qui sommes-nous ?</h1>
			
			
			<p align="justify"><strong><?php echo $cust_site_name;?></strong> a pour vocation de mettre en relation acheteurs, vendeurs, loueurs ou donateurs (particuliers ou professionnels) qui cherchent à acheter, vendre, louer voire échanger des biens ou des services sur le territoire Français.</p>
			
			<p>&nbsp;</p>

			<p align="justify">Pour l'essentiel gratuit, <strong><?php echo $cust_site_name;?></strong> offre non seulement une visibilité sur l'ensemble des catégories de petites annonces : immobilières, auto, moto, emploi...produits neufs ou d'occasions mais également une recherche avancée et une gamme complète d'options afin de faciliter la mise en avant et la consultation d'une petite annonce.</p>

			<p>&nbsp;</p>
			
			<p align="justify">Créé en 2013, le site de petites annonces gratuites <strong><?php echo $cust_site_name;?></strong> est édité par la société  <strong><?php echo $cust_site_owner_accronym;?></strong> dont les coordonnées sont les suivantes :</p>
			
			<p>&nbsp;</p>

      <table>
        <tr><td>
			
  			<strong>PAYS</strong> :
     
  			<p>&nbsp;</p>
     
  			adresse 1<br />
  			adresse 1<br />
  			E-mail : <a href="mailto:">nous contacter</a>

  			<p>&nbsp;</p>

     
  			<strong>France</strong> :

  			<p>&nbsp;</p>
  			
  			<strong>Besoin d'aide ?</strong> : <a href="mailto:">contacter le support technique</a><br />
  			<strong>Vous souhaitez communiquer sur Nous ?</strong> : <a href="mailto:">contacter le service commercial</a><br />
  			<strong>Vous êtes client ?</strong> : <a href="mailto:">contacter le service client</a>                                  
  					
  			<p>&nbsp;</p>
      </td>
      <td>

      
        <!-- google map view -->
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d83998.91163207516!2d2.3470599!3d48.85885894999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e66e1f06e2b70f%3A0x40b82c3688c9460!2sParis!5e0!3m2!1sfr!2sfr!4v1439747214755" width="400" height="300" frameborder="0" style="border:0" ></iframe>
</td></tr></table>
      

      <div styme="clear:both;"></div>


					
			<p align="justify">Et quoniam mirari posse quosdam peregrinos existimo haec lecturos forsitan, si contigerit, quamobrem cum oratio ad ea monstranda deflexerit quae Romae gererentur, nihil praeter seditiones narratur et tabernas et vilitates harum similis alias, summatim causas perstringam nusquam a veritate sponte propria digressurus.

Etenim si attendere diligenter, existimare vere de omni hac causa volueritis, sic constituetis, iudices, nec descensurum quemquam ad hanc accusationem fuisse, cui, utrum vellet, liceret, nec, cum descendisset, quicquam habiturum spei fuisse, nisi alicuius intolerabili libidine et nimis acerbo odio niteretur. Sed ego Atratino, humanissimo atque optimo adulescenti meo necessario, ignosco, qui habet excusationem vel pietatis vel necessitatis vel aetatis. Si voluit accusare, pietati tribuo, si iussus est, necessitati, si speravit aliquid, pueritiae. Ceteris non modo nihil ignoscendum, sed etiam acriter est resistendum.

Ob haec et huius modi multa, quae cernebantur in paucis, omnibus timeri sunt coepta. et ne tot malis dissimulatis paulatimque serpentibus acervi crescerent aerumnarum, nobilitatis decreto legati mittuntur: Praetextatus ex urbi praefecto et ex vicario Venustus et ex consulari Minervius oraturi, ne delictis supplicia sint grandiora, neve senator quisquam inusitato et inlicito more tormentis exponeretur.

Ob haec et huius modi multa, quae cernebantur in paucis, omnibus timeri sunt coepta. et ne tot malis dissimulatis paulatimque serpentibus acervi crescerent aerumnarum, nobilitatis decreto legati mittuntur: Praetextatus ex urbi praefecto et ex vicario Venustus et ex consulari Minervius oraturi, ne delictis supplicia sint grandiora, neve senator quisquam inusitato et inlicito more tormentis exponeretur.</p>		
			
			<p>&nbsp;</p>
					
			<strong>Date de derni&egrave;re mise à jour : </strong>07 D&eacute;cembre 2013 - rev 1.0</strong>
					
			<div class="clearer">&nbsp;</div>

		</div>
            <p>
            <p> </p>


 <!-- add FOOTER -->
    <?php include_once("footer.php"); ?>    
    <!-- END FOOTER -->

    

	</div>
</div>

   <!-- Jquery  & plug-in -->
  <script type="text/javascript" src="lib/jquery-1.4.4.min.js"></script> 
  <script type="text/javascript" src="lib/jquery-ui.min.js"></script> 
  <script type="text/javascript" src="lib/patmisc.postload.lib.min.js"></script> 

    <!-- LANGUAGE File (MASTER) -->
  <script type="text/javascript" src="lang/<?php echo str_replace('_','-',$cust_lang_long); ?>.js"></script>

  <!-- LANGUAGE File (CUSTOM) - COMING ON TOP OF EXISTING ONE -->
  <?php if (isset($THEME_CUST_LANG_URL) && $THEME_CUST_LANG_URL!="") { ?> 
    <script type="text/javascript" src="<?php echo $THEME_CUST_LANG_URL.str_replace('_','-',$cust_lang_long); ?>.js"></script>
  <?php }?>

  <!-- Core feature of ZADS ESSENTIAL STATIC PAGES  --> 
  <script type="text/javascript" src="js/zads-static-page.js"></script> 


</body>
</html>
