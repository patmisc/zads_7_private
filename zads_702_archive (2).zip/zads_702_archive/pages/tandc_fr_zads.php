<?php 
  // ----- add generic header for STATIC pages  -------------//
  include_once "header-static.php";
?> 

  <div id="site">
	<div class="center-wrapper">


    <div id="header">

      <!-- Main menu -->      
      <?php  include_once "site-title-static.php"; ?>
      <!-- end main menu -->


      <div class="clearer">&nbsp;</div>

      <!-- sub menu navigation  -->
      <div id="navigation">
        <div id="main-nav">
          <div id="main-nav-links">
            <ul class="tabbed">
            </ul>
          </div>
          <div class="clearer">&nbsp;</div>
        </div>
        <div class="clearer">&nbsp;</div>
      </div>
      <!-- end sub menu navigation -->

    </div>

		<div class="main" id="main-two-columns">
		
            <div class="tc-maintext">
            

            <p>
            <p> </p>
			<h1>Informations l&eacute;gales </h1>
			<p>&nbsp;</p>
			<p>Le site Internet,  ci-apr&egrave;s d&eacute;nomm&eacute; &laquo; <?php echo (stripslashes($cust_site_name));?>&raquo; est un site communautaire de petites annonces entre particuliers.</p>
			<p>&nbsp;</p>
			<p>Le site est &eacute;dit&eacute; et est la propri&eacute;t&eacute; de <?php echo (stripslashes($cust_site_owner_long));?> , ci-apr&egrave;s <?php echo (stripslashes($cust_site_owner_accronym));?>.</p>
			<p>Pour toute question sur l'entreprise, vous pouvez nous contacter en utilisation le formulaire de support en ligne.</p>
			<p><?php echo $cust_site_name;?> est h&eacute;berg&eacute; par 1&amp;1.</p>
			<p><br />
			  

 Les pr&eacute;sentes Conditions G&eacute;n&eacute;rales d'Utilisation ont pour objet de d&eacute;finir les termes et conditions dans lesquelles <?php echo $cust_site_name;?> fournit les Services aux Utilisateurs. Toute utilisation de l'un des Services offerts par <?php echo $cust_site_name;?>, l'acc&eacute;s au site, sa consultation et son utilisation sont subordonn&eacute;s &agrave; l'acceptation sans r&eacute;serve des pr&eacute;sentes Conditions G&eacute;n&eacute;rales d'Utilisation. 


 La derni&egrave;re modification de ces Conditions d'utilisation a eu lieu le 07 D&eacute;cembre 2010. </p>
			<p>&nbsp;</p>
			<h1>Conditions G&eacute;n&eacute;rales d'Utilisation</h1>
            <p><br />
    <strong>1. Propri&eacute;t&eacute; intellectuelle</strong><br />
  1.1. Droits d'auteur et droits voisins <br />
  L'ensemble des &eacute;l&eacute;ments constituant le site <?php echo $cust_site_name;?> (textes, graphismes, logiciels, photographies, images, vid&eacute;os, sons, plans, noms, logos, marques, cr&eacute;ations et &oelig;uvres prot&eacute;geables diverses, bases de donn&eacute;es, etc...) ainsi que le site lui-m&ecirc;me, rel&egrave;vent des l&eacute;gislations françaises et internationales sur le droit d'auteur et sur les droits voisins du droit d'auteur (notamment les articles L122-4 et L122-5. du Code de la Propri&eacute;t&eacute; Intellectuelle). </p>
<p><br />
    En cons&eacute;quence, l'utilisateur du site <?php echo $cust_site_name;?> s'engage à ne pas : </p>
<ul>
<li class="list">utiliser ou interroger le site<?php echo $cust_site_name;?> pour le compte ou au profit d'autrui ;</li>
<li class="list">reproduire en nombre, &agrave; des fins commerciales ou non, des informations ou des petites annonces pr&eacute;sentes sur le site <?php echo $cust_site_name;?> ;</li>
<li class="list">int&eacute;grer tout ou partie du contenu du site <?php echo $cust_site_name;?> dans un site tiers, &agrave; des fins commerciales ou non ;</li>
<li class="list">utiliser un robot, notamment d'exploration (spider), une application de recherche ou r&eacute;cup&eacute;ration de sites Internet ou tout autre moyen permettant de r&eacute;cup&eacute;rer ou d'indexer tout ou partie du contenu du site <?php echo $cust_site_name;?>, except&eacute; en cas d'autorisation expresse et pr&eacute;alable de <?php echo (stripslashes($cust_site_owner_accronym));?> ;</li>

<li class="list">copier les informations sur des supports de toute nature permettant de reconstituer tout ou partie des fichiers d'origine.</li>
</ul> 
<p>Toute utilisation non express&eacute;ment autoris&eacute;e d'&eacute;l&eacute;ments du site <?php echo $cust_site_name;?> entra&icirc;ne une violation des droits d'auteur et constitue une contrefa?on.  Elle peut aussi entra&icirc;ner une violation des droits à l'image, droits des personnes ou de tous autres droits et r&eacute;glementations en vigueur. Elle peut donc engager la responsabilit&eacute; civile et/ou p&eacute;nale de son auteur. <?php echo (stripslashes($cust_site_owner_accronym));?> se r&eacute;serve la possibilit&eacute; de saisir toutes voies de droit à l'encontre des personnes qui n'auraient pas respect&eacute; les interdictions contenues dans le pr&eacute;sent article.<br />
  
  <br />
    1.2. Droits du producteur de base de donn&eacute;es<br />
    <?php echo (stripslashes($cust_site_owner_accronym));?> est le producteur de la base de donn&eacute;es constitu&eacute;e par le site <?php echo $cust_site_name;?>, au sens de l'article<br />
    L 341-1 et suivants du Code de la Propri&eacute;t&eacute; Intellectuelle. Toute extraction ou utilisation du contenu de la base non express&eacute;ment autoris&eacute;e peut engager la responsabilit&eacute; civile et/ou p&eacute;nale de son auteur. <?php echo (stripslashes($cust_site_owner_accronym));?> se r&eacute;serve la possibilit&eacute; de saisir toutes voies de droit &agrave; l'encontre des personnes qui n'auraient pas respect&eacute; cette interdiction.</p>
<p><br />
    1.3. Droit de marque<br />
    Les d&eacute;nomination et logotype <?php echo $cust_site_name;?> sont des marques d&eacute;pos&eacute;es, propri&eacute;t&eacute; de <?php echo (stripslashes($cust_site_owner_accronym));?>. Toute utilisation non express&eacute;ment autoris&eacute;e peut engager la responsabilit&eacute; civile et/ou p&eacute;nale de son auteur. <?php echo (stripslashes($cust_site_owner_accronym));?> se r&eacute;serve la possibilit&eacute; d'exercer toutes voies de droit &agrave; l'encontre des personnes qui porteraient atteinte &agrave; ses droits.</p>
<p>&nbsp;</p>
<p><strong>2. Conditions d'acc&eacute;s aux services </strong></p>
<p>2.1. Conditions d'acc&eacute;s aux services libres </p>
<p>L'acc&egrave;s au Contenu Editorial du Site <?php echo $cust_site_name;?>, est totalement libre et gratuit. </p>
<p>&nbsp;</p>
<p>2.2. Conditions d'acc&eacute;s aux Services Ssp&eacute;cifiques gratuits </p>
<p>L'utilisation des Services Sp&eacute;cifiques suppose le respect par l'Utilisateur d'une proc&eacute;dure d'inscription par laquelle ce dernier doit founir ses coordonn&eacute;es. L'Utilisateur s'engage &agrave; ce que les informations communiqu&eacute;es, notamment les informations personnelles, soient exactes, compl&egrave;tes et &agrave; jour et &agrave; effectuer les modifications n&eacute;cessaires &agrave; cette fin. <br />
    <br />
  Dans le cadre de cette proc&eacute;dure, l'Utilisateur d&eacute;clare avoir pris connaissance et avoir accept&eacute; express&eacute;ment les pr&eacute;sentes Conditions G&eacute;n&eacute;rales d'Utilisation en vigueur au jour de la souscription aux Services Sp&eacute;cifiques par un clic sur l'ic&ocirc;ne intitul&eacute;e "j'accepte les Conditions G&eacute;n&eacute;rales d'Utilisation : envoi des donn&eacute;es". Toute acceptation exprim&eacute;e par l'Utilisateur par un clic vaut signature au m&ecirc;me titre que sa signature manuscrite. Par la r&eacute;alisation de ce clic l'Utilisateur est r&eacute;put&eacute; avoir donn&eacute; son accord irr&eacute;vocablement. </p>
<p><br />
        <strong>3. Protection des donn&eacute;es personnelles</strong><br />
        Conform&eacute;ment &agrave; la loi n?78-17 du 6 janvier 1978, dite &laquo; Informatique et libert&eacute;s &raquo;, <?php echo $cust_site_name;?> a fait l'objet d'une d&eacute;claration aupr&egrave;s de la Commission Nationale de l'Informatique et des Libert&eacute;s (C.N.I.L) sous le num&eacute;ro: .Conform&eacute;ment &agrave; l'article 27 de la loi n?78-17 du 6 janvier 1978, vous disposez &agrave; tout moment d'un droit d'acc&egrave;s et de rectification des donn&eacute;es vous concernant. Ce droit peut &ecirc;tre exerc&eacute; par courrier &eacute;lectronique (m&eacute;l) aupr&egrave;s de <?php echo (stripslashes($cust_site_owner_accronym));?>.  Il est demand&eacute; un d&eacute;lai de 15 jours maximum avant la prise en compte de la demande de l'Utilisateur. </p>
<p>&nbsp;</p>
<p><?php echo $cust_site_name;?> s'engage &agrave; faire ses meilleurs efforts pour prot&eacute;ger les Donn&eacute;es Personnelles, afin d'emp&ecirc;cher qu'elles ne soient d&eacute;form&eacute;es, endommag&eacute;es ou communiqu&eacute;es &agrave; des tiers non autoris&eacute;s conform&eacute;ment &agrave; l'article 29 de la loi du 6 janvier 1978.</p>
<p><br />
          <strong>4. Responsabilit&eacute;s </strong><br />
          <?php echo (stripslashes($cust_site_owner_accronym));?> d&eacute;cline toute responsabilit&eacute;:</p>
<ul>
<li class="list">
en cas d'interruption de <?php echo $cust_site_name;?> pour des op&eacute;rations de maintenance techniques ou d'actualisation des informations publi&eacute;es,

</li>
<li class="list">
en cas d'impossibilit&eacute; momentan&eacute;e d'acc&egrave;s &agrave; <?php echo $cust_site_name;?> (et/ou aux sites lui &eacute;tant li&eacute;s) en raison de probl&egrave;mes techniques et ce quelles qu'en soient l'origine et la provenance,
</li>
<li class="list">
en cas de dommages directs ou indirects caus&eacute;s &agrave; l'utilisateur, quelle qu'en soit la nature, r&eacute;sultant du contenu, de l'acc&egrave;s, ou de l'utilisation de <?php echo $cust_site_name;?> (et/ou des sites qui lui sont li&eacute;s),

</li>
<li class="list">
en cas d'utilisation anormale ou d'une exploitation illicite de <?php echo $cust_site_name;?>. L'utilisateur de <?php echo $cust_site_name;?>  est alors seul responsable des dommages caus&eacute;s aux tiers et des cons&eacute;quences des r&eacute;clamations ou actions qui pourraient en d&eacute;couler. L'utilisateur renonce &eacute;galement &agrave; exercer tout recours contre <?php echo (stripslashes($cust_site_owner_accronym));?> dans le cas de poursuites diligent&eacute;es par un tiers &agrave; son encontre du fait de l'utilisation et/ou de l'exploitation illicite du site,
</li>
<li class="list">
en cas de perte par le membre de <?php echo $cust_site_name;?> de son identifiant et/ou de son mot de passe ou en cas d'usurpation de son identit&eacute;.

</li>
</ul>
<p><br />
    <strong>5. Liens hypertexte</strong><br />
    5.1. Liens &agrave; partir du site <?php echo $cust_site_name;?><br />
    Le site <?php echo $cust_site_name;?> peut contenir des liens hypertextes vers des sites exploit&eacute;s par des tiers. Ces liens sont fournis &agrave; simple titre d'information. <?php echo (stripslashes($cust_site_owner_accronym));?> n'exerce aucun contr&ocirc;le sur ces sites et d&eacute;cline toute responsabilit&eacute; quant &agrave; l'acc&egrave;s, au contenu ou &agrave; l'utilisation de ces sites, ainsi qu'aux dommages pouvant r&eacute;sulter de la consultation des informations pr&eacute;sentes sur ces sites. La d&eacute;cision d'activer ces liens rel&egrave;ve de la pleine et enti&egrave;re responsabilit&eacute; de l'internaute.<br />
  
  <br />
  5.2. Liens vers le site <?php echo $cust_site_name;?><br />
  Aucun lien hypertexte ne peut &ecirc;tre cr&eacute;&eacute; vers le site <?php echo $cust_site_name;?> sans l'accord pr&eacute;alable expr&egrave;s de <?php echo (stripslashes($cust_site_owner_accronym));?>.<br />
  Si un internaute ou une personne morale d&eacute;sire cr&eacute;er, &agrave; partir de son site, un lien hypertexte vers le site <?php echo $cust_site_name;?>, ils doivent pr&eacute;alablement prendre contact avec <?php echo (stripslashes($cust_site_owner_accronym));?> &agrave; l'adresse mentionn&eacute;e au point 3. L'admissibilit&eacute; ou non d'une telle demande sera transmise &agrave; l'int&eacute;ress&eacute;.<br />
  
<br />
  <strong>6. Cookies</strong><br />
  Afin de faciliter la navigation sur le site <?php echo $cust_site_name;?>, des cookies peuvent &ecirc;tre implant&eacute;s dans votre ordinateur afin par exemple de conserver les crit&egrave;res de recherche.<br />
  Si vous ne souhaitez pas accepter l'implantation de cookies vous pouvez r&eacute;gler votre navigateur afin de les refuser. Cependant, l'utilisation de <?php echo $cust_site_name;?> peut en &ecirc;tre perturb&eacute;e.</p>
<p>&nbsp;</p>
<p><strong>7. Acceptation des risques de l'internet </strong></p>
<p>L'Utilisateur d&eacute;clare bien conna&icirc;tre Internet, ses caract&eacute;ristiques et ses limites et en particulier reconna&icirc;t : </p>
<p>- " Que l'Internet est un r&eacute;seau ouvert non ma&icirc;trisable par <?php echo $cust_site_name;?> et que les &eacute;changes de donn&eacute;es circulant sur Internet ne b&eacute;n&eacute;ficient que d'une fiabilit&eacute; relative, et ne sont prot&eacute;g&eacute;es notamment contre les risques de d&eacute;tournements ou de piratages &eacute;ventuels ; <br />
  - " Que la communication par l'Utilisateur d'informations &agrave; caract&egrave;re sensible est donc effectu&eacute;e &agrave; ses risques et p&eacute;rils ; <br />
  - "Avoir connaissance de la nature du r&eacute;seau Internet et en particulier de ses performances techniques et des temps de r&eacute;ponse, pour consulter, interroger ou transf&eacute;rer les donn&eacute;es d'informations. </p>
<p><?php echo $cust_site_name;?> ne peut garantir que les informations &eacute;chang&eacute;es ne seront pas intercept&eacute;es par des tiers, et que la confidentialit&eacute; des &eacute;changes sera garantie. <br />
  <?php echo $cust_site_name;?> informe l'Utilisateur de l'existence de r&egrave;gles et d'usage en vigueur sur Internet connus sous le nom de Netiquette ainsi que de diff&eacute;rents codes de d&eacute;ontologie et notamment la Charte Internet accessibles sur Internet. </p>
<p><br />
        <br />
        <strong>8. Modifications des Conditions G&eacute;n&eacute;rales d'Utilisation</strong><br />
        <?php echo (stripslashes($cust_site_owner_accronym));?> se r&eacute;serve le droit de modifier, librement et &agrave; tout moment, les Conditions G&eacute;n&eacute;rales d'Utilisation du site <?php echo $cust_site_name;?>. Chaque internaute se connectant au site <?php echo $cust_site_name;?> est invit&eacute; &agrave; consulter r&eacute;guli&egrave;rement les pr&eacute;sentes conditions d'utilisation afin de prendre connaissance de changements &eacute;ventuels. L'utilisation renouvel&eacute;e du site au fur et &agrave; mesure de la modification de ces conditions d'utilisation constitue l'acceptation, par chaque utilisateur, des Conditions G&eacute;n&eacute;rales d'Utilisation en vigueur.<br /> 
        
      <br />
        <strong>9. Attribution de juridiction &ndash; Loi applicable</strong><br />
        Toutes contestations qui pourraient survenir au sujet de la validit&eacute;, de l'interpr&eacute;tation, de l'acceptation et de l'ex&eacute;cution des pr&eacute;sentes quel que soit le lieu de souscription, ou de r&egrave;glement, feront l'objet d'une tentative de r&egrave;glement amiable que les parties s'engagent &agrave; rechercher. A d&eacute;faut d'y parvenir dans un d&eacute;lai de trois (3) mois, les tribunaux de Strasbourg seront seuls comp&eacute;tents m&ecirc;me en cas d'appel en garantie ou de pluralit&eacute; de d&eacute;fendeurs, pour les proc&eacute;dures d'urgence ou conservatoires, en r&eacute;f&eacute;r&eacute; ou par requ&ecirc;te.<br /> 
        
      <br />
        Les pr&eacute;sentes conditions g&eacute;n&eacute;rales sont soumises au droit fran&ccedil;ais, qui d&eacute;termine, au cas par cas, la loi applicable. En l'absence de toute disposition imp&eacute;rative contraire ou en pr&eacute;sence d'un choix dans la d&eacute;termination de la loi applicable, la loi fran&ccedil;aise sera appliqu&eacute;e.<br />
        <br />
</p>
<h1>Conditions g&eacute;n&eacute;rales de diffusion</h1>

<p><br />
    <strong>1. Acceptation des conditions g&eacute;n&eacute;rales de diffusion</strong><br />
    1.1 La diffusion d'une petite annonce (ci-apr&egrave;s &laquo; Annonce &raquo;) diffus&eacute;e sur le site internet <?php echo $cust_site_name;?> &eacute;dit&eacute; par  <?php echo (stripslashes($cust_site_owner_accronym));?>, implique pour l'annonceur, l'acceptation sans r&eacute;serve des pr&eacute;sentes conditions g&eacute;n&eacute;rales de diffusion &agrave; l'exclusion expresse de toutes conditions autres ou contraires des co-contractants de <?php echo (stripslashes($cust_site_owner_accronym));?>, ins&eacute;r&eacute;es dans leurs documents d'information, lettres, contrats, etc., re&ccedil;us ou &agrave; recevoir et de tous usages professionnels contraires aux pr&eacute;sentes, lesquels conditions et usages seront consid&eacute;r&eacute;s comme inopposables &agrave; <?php echo (stripslashes($cust_site_owner_accronym));?>.</p>
<p>&nbsp;</p>
<p>1.2 <?php echo $cust_site_name;?> apporte un service communautaire visant &agrave; prot&eacute;ger au maximum les &eacute;changes equitables et hon&eacute;tes entre particuliers / professionels. La diffusion d'un Annonce et sous le control de l'Annonceur qui peut restreindreou non la visibilit&eacute; &agrave; une communaut&eacute;. Cette Communaut&eacute; est auto-constitu&eacute;e sans que <?php echo (stripslashes($cust_site_owner_accronym));?> puisse &ecirc;tre tenu responsable de la qualit&eacute; et des acts des membres de cette communaut&eacute;. Tout utilisateur,  annonceur ou titulaire de droits peut  signaler les annonces qui portent atteinte &agrave; leurs droits de propri&eacute;t&eacute; intellectuelle par le biais de la fonction &quot;notifier un abus&quot;. </p>
<p><br />
    1.3 Toute adjonction, rature, modification ou suppression qui serait port&eacute;e sur les pr&eacute;sentes devra, pour &ecirc;tre opposable &agrave; <?php echo (stripslashes($cust_site_owner_accronym));?> &ecirc;tre contresign&eacute;es par celle-ci.<br />
      <br />
      1.4 Le fait que <?php echo (stripslashes($cust_site_owner_accronym));?> ne se pr&eacute;vale pas &agrave; un moment donn&eacute; de l'une quelconque des dispositions des pr&eacute;sentes conditions g&eacute;n&eacute;rales de diffusion ne peut &ecirc;tre interpr&eacute;t&eacute; comme valant renonciation &agrave; s'en pr&eacute;valoir ult&eacute;rieurement.</p>
<p><br />
        <strong>2. Diffusion</strong><br />
        2.1 L'annonceur reconna&icirc;t &ecirc;tre l'auteur unique et exclusif du texte de l'Annonce. A d&eacute;faut, il d&eacute;clare disposer de tous les droits et autorisations n&eacute;cessaires &agrave; la parution de l' Annonce.<br /> 
        <br />
        2.2 L'Annonce est diffus&eacute;e sous la responsabilit&eacute; exclusive de l'annonceur.<br />
      
        <br />
        2.3 L'annonceur certifie que l'Annonce est conforme &agrave; l'ensemble des dispositions l&eacute;gales et r&eacute;glementaires en vigueur et respecte les droits des tiers. En cons&eacute;quence, l'annonceur rel&egrave;ve <?php echo (stripslashes($cust_site_owner_accronym));?>, ses sous-traitants et fournisseurs, de toutes responsabilit&eacute;s, et les garantit contre toutes condamnations, frais judiciaires et extrajudiciaires, qui r&eacute;sulteraient de tout recours en relation avec la diffusion de l'annonce et les indemnise pour tout dommage r&eacute;sultant de la violation de la pr&eacute;sente disposition.<br />
        <br />
        2.4 Sans pr&eacute;judice de l'application de la pr&eacute;c&eacute;dente clause, et sans que cela cr&eacute;e &agrave; sa charge une obligation de v&eacute;rifier le contenu, l'exactitude ou la coh&eacute;rence de l'Annonce, <?php echo (stripslashes($cust_site_owner_accronym));?> se r&eacute;serve le droit de refuser &agrave; tout moment une Annonce pour tout motif l&eacute;gitime, et notamment des &eacute;l&eacute;ments de texte (mots, expressions, phrases&hellip;etc.), qui lui semblerait contraire aux dispositions l&eacute;gales ou r&eacute;glementaires, aux bonnes m&oelig;urs, &agrave; l'esprit de la publication, ou susceptible de troubler ou choquer les lecteurs. Un tel refus ne fait na&icirc;tre au profit de l'annonceur aucun droit &agrave; indemnit&eacute;.<br />
        
        <br />
          <strong>3. Limitation de responsabilit&eacute;</strong><br />
          3.1 Sauf dol ou faute lourde, <?php echo (stripslashes($cust_site_owner_accronym));?>, ses sous-traitants et fournisseurs ne seront tenus en aucun cas &agrave; reparation, p&eacute;cuniaire ou en nature, du fait d'erreurs ou d'omissions dans la composition ou la traduction d'une Annonce, ou de d&eacute;faut de parution de quelque nature que ce soit. En particulier, de tels &eacute;v&eacute;nements ne pourront en aucun cas ouvrir droit &agrave; une indemnisation sous quelque forme que ce soit.<br />
          <br />
          3.2 Ni l'annonceur, d'une part, ni <?php echo (stripslashes($cust_site_owner_accronym));?>, ses sous-traitants ou fournisseurs, d'autre part, ne pourra &ecirc;tre tenu pour responsable de tout retard, inex&eacute;cution ou autre manquement &agrave; ses obligations au titre des pr&eacute;sentes qui (1) r&eacute;sulterait, directement ou indirectement, d'un &eacute;v&eacute;nement &eacute;chappant &agrave; son contr&ocirc;le raisonnable, et (2) n'aurait pas pu &ecirc;tre &eacute;vit&eacute; &agrave; l'aide de mesures de pr&eacute;caution, solutions de remplacement ou autres moyens commercialement raisonnables.<br /> 
        
          <br />
          3.3 Ni l'annonceur, d'une part, ni <?php echo (stripslashes($cust_site_owner_accronym));?>, ses sous-traitants ou fournisseurs, d'autre part, ne pourra &ecirc;tre tenu pour responsable des retards ou des impossibilit&eacute;s de remplir ses obligations contractuelles, li&eacute;s &agrave; des destructions de mat&eacute;riels, aux attaques ou au piratage informatiques, &agrave; la privation, &agrave; la suppression ou &agrave; l'interdiction, temporaire ou d&eacute;finitive, et pour quelque cause que ce soit - dont les pannes ou indisponibilit&eacute;s inh&eacute;rentes aux serveurs d'h&eacute;bergement -, de l'acc&egrave;s au r&eacute;seau Internet.<br />
        
          <br />
          3.4 <?php echo (stripslashes($cust_site_owner_accronym));?> se r&eacute;serve le droit de suspendre ou d'arr&ecirc;ter la diffusion du site <?php echo $cust_site_name;?> sans &ecirc;tre tenue de verser &agrave; l'annonceur une indemnit&eacute; de quelque nature que ce soit.<br />  
          <br />
          3.5 Toute r&eacute;clamation, pour &ecirc;tre recevable, doit &ecirc;tre transmise par lettre simple, t&eacute;l&eacute;copie ou e-mail, dans un d&eacute;lai de quarante huit (48) heures &agrave; compter de la date de diffusion sur <?php echo $cust_site_name;?>.<br /> 
        
          <br />
          <br />
          <strong>4. Attribution de juridiction &ndash; Loi applicable</strong><br />
          4.1 Toutes contestations qui pourraient survenir &agrave; l'occasion de l'interpr&eacute;tation, de l'acceptation et de l'ex&eacute;cution des pr&eacute;sentes quel que soit le lieu de souscription, ou de r&egrave;glement, feront l'objet d'une tentative de r&egrave;glement amiable que les parties s'engagent &agrave; rechercher. A d&eacute;faut d'y parvenir dans un d&eacute;lai de trois (3) mois, les tribunaux de Strasbourg seront seuls comp&eacute;tents m&ecirc;me en cas d'appel en garantie ou de pluralit&eacute; de d&eacute;fendeurs, pour les proc&eacute;dures d'urgence ou conservatoires, en r&eacute;f&eacute;r&eacute; ou par requ&ecirc;te.<br />
        
          <br />
          4.2 Les pr&eacute;sentes conditions g&eacute;n&eacute;rales sont soumises &agrave; la loi fran&ccedil;aise.<br />
          <br />
          <strong>5. Divers</strong><br />
          5.1 Les marques et logotypes <?php echo $cust_site_name;?> et <?php echo (stripslashes($cust_site_owner_accronym));?> sont d&eacute;pos&eacute;s par <?php echo (stripslashes($cust_site_owner_accronym));?>. Sans l'accord de cette derni&egrave;re, toute reproduction ou utilisation est strictement interdite.<br />
</p>
</div>

			<div class="clearer">&nbsp;</div>

		</div>

 <!-- add FOOTER -->
    <?php include_once("footer.php"); ?>    
    <!-- END FOOTER -->

    

	</div>
</div>

   <!-- Jquery  & plug-in -->
  <script type="text/javascript" src="lib/jquery-1.4.4.min.js"></script> 
  <script type="text/javascript" src="lib/jquery-ui.min.js"></script> 
  <script type="text/javascript" src="lib/patmisc.postload.lib.min.js"></script> 

  <!-- LANGUAGE File (MASTER) -->
  <?php if (!$DISABLE_TRANSLATION) { ?> 
    <script type="text/javascript" src="lang/<?php echo str_replace('_','-',$cust_lang_long); ?>.js"></script>
  <?php }?>


  <!-- LANGUAGE File (CUSTOM) - COMING ON TOP OF EXISTING ONE -->
  <?php if (isset($THEME_CUST_LANG_URL) && $THEME_CUST_LANG_URL!="" && !$DISABLE_TRANSLATION) { ?> 
    <script type="text/javascript" src="<?php echo $THEME_CUST_LANG_URL.str_replace('_','-',$cust_lang_long); ?>.js"></script>
  <?php }?>

  <!-- Core feature of ZADS ESSENTIAL STATIC PAGES  --> 
  <script type="text/javascript" src="js/zads-static-page.js"></script> 


</body>
</html>
