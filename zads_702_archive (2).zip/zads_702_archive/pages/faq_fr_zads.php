<?php 
  // ----- add generic header for STATIC pages  -------------//
  include_once "header-static.php";
?> 

<!-- special stye for FAQ -->
   <style>
        :focus, :active { outline:0 }
        .accordion { 
          color:#555 ;
        }
        
        .accordion h3 {
          padding:5px; 
          box-shadow:0 1px 4px #CCC; 
          margin:6px 0; cursor:pointer 

        }
        .accordion div {
          margin:0 0 0 10px; 
          padding:10px; 
          border:solid 1px #F6F6F6; 
          height:auto 
        }
    </style>



  <div id="site" class="">
	<div class="center-wrapper">

    <div id="header">

      <!-- Main menu -->
      <?php  include_once "site-title-static.php"; ?>
      <!-- end main menu -->

      <div class="clearer">&nbsp;</div>

      <!-- sub menu navigation  -->
      <div id="navigation">
        <div id="main-nav">
          <div id="main-nav-links">
            <ul class="tabbed">
            </ul>
          </div>
          <div class="clearer">&nbsp;</div>
        </div>
        <div class="clearer">&nbsp;</div>
      </div>
      <!-- end sub menu navigation -->

    </div>

		<div class="main" id="main-two-columns">
		
      <div class="tc-maintext">
            

            
            <p>
            <p> </p>
			   <h1 id="motto">Questions Fréquentes</h1>

        

<h2>Section title</h2>     
<div class="accordion">
          <!-- TITLE -->
          <!-- DESCRIPTION -->
          <h3>Lorem ipsum dolor sit amet,</h3>
          <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis blandit dictum. Aenean id tristique ipsum. Ut felis lorem, cursus et lacinia quis, interdum eu lectus. Nullam lacinia varius velit in vulputate. Nunc vulputate arcu ac velit tempus, sit amet vehicula justo bibendum. Cras dignissim urna nisi, quis elementum dui interdum eget. Nulla enim enim, viverra et turpis at, posuere rhoncus orci. Nunc dictum vitae diam nec congue. Nam at orci sed libero ullamcorper congue non id velit. Curabitur feugiat rhoncus rutrum. Etiam egestas euismod libero, at mollis nisl sollicitudin a.</div>
          

          <!-- TITLE -->
          <!-- DESCRIPTION -->
          <h3>Lorem ipsum dolor sit amet,</h3>
          <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis blandit dictum. Aenean id tristique ipsum. Ut felis lorem, cursus et lacinia quis, interdum eu lectus. Nullam lacinia varius velit in vulputate. Nunc vulputate arcu ac velit tempus, sit amet vehicula justo bibendum. Cras dignissim urna nisi, quis elementum dui interdum eget. Nulla enim enim, viverra et turpis at, posuere rhoncus orci. Nunc dictum vitae diam nec congue. Nam at orci sed libero ullamcorper congue non id velit. Curabitur feugiat rhoncus rutrum. Etiam egestas euismod libero, at mollis nisl sollicitudin a.</div>
          
          <!-- TITLE -->
          <!-- DESCRIPTION -->
          <h3>Lorem ipsum dolor sit amet,</h3>
          <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis blandit dictum. Aenean id tristique ipsum. Ut felis lorem, cursus et lacinia quis, interdum eu lectus. Nullam lacinia varius velit in vulputate. Nunc vulputate arcu ac velit tempus, sit amet vehicula justo bibendum. Cras dignissim urna nisi, quis elementum dui interdum eget. Nulla enim enim, viverra et turpis at, posuere rhoncus orci. Nunc dictum vitae diam nec congue. Nam at orci sed libero ullamcorper congue non id velit. Curabitur feugiat rhoncus rutrum. Etiam egestas euismod libero, at mollis nisl sollicitudin a.</div>
</div> 




<h2>Section title</h2>
<div class="accordion">
          <!-- TITLE -->
          <!-- DESCRIPTION -->
          <h3>Lorem ipsum dolor sit amet,</h3>
          <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis blandit dictum. Aenean id tristique ipsum. Ut felis lorem, cursus et lacinia quis, interdum eu lectus. Nullam lacinia varius velit in vulputate. Nunc vulputate arcu ac velit tempus, sit amet vehicula justo bibendum. Cras dignissim urna nisi, quis elementum dui interdum eget. Nulla enim enim, viverra et turpis at, posuere rhoncus orci. Nunc dictum vitae diam nec congue. Nam at orci sed libero ullamcorper congue non id velit. Curabitur feugiat rhoncus rutrum. Etiam egestas euismod libero, at mollis nisl sollicitudin a.</div>
          

          <!-- TITLE -->
          <!-- DESCRIPTION -->
          <h3>Lorem ipsum dolor sit amet,</h3>
          <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis blandit dictum. Aenean id tristique ipsum. Ut felis lorem, cursus et lacinia quis, interdum eu lectus. Nullam lacinia varius velit in vulputate. Nunc vulputate arcu ac velit tempus, sit amet vehicula justo bibendum. Cras dignissim urna nisi, quis elementum dui interdum eget. Nulla enim enim, viverra et turpis at, posuere rhoncus orci. Nunc dictum vitae diam nec congue. Nam at orci sed libero ullamcorper congue non id velit. Curabitur feugiat rhoncus rutrum. Etiam egestas euismod libero, at mollis nisl sollicitudin a.</div>
          
          <!-- TITLE -->
          <!-- DESCRIPTION -->
          <h3>Lorem ipsum dolor sit amet,</h3>
          <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam iaculis blandit dictum. Aenean id tristique ipsum. Ut felis lorem, cursus et lacinia quis, interdum eu lectus. Nullam lacinia varius velit in vulputate. Nunc vulputate arcu ac velit tempus, sit amet vehicula justo bibendum. Cras dignissim urna nisi, quis elementum dui interdum eget. Nulla enim enim, viverra et turpis at, posuere rhoncus orci. Nunc dictum vitae diam nec congue. Nam at orci sed libero ullamcorper congue non id velit. Curabitur feugiat rhoncus rutrum. Etiam egestas euismod libero, at mollis nisl sollicitudin a.</div>
 </div>                  
                
 
                 



      </div>

			<div class="clearer">&nbsp;</div>

		</div>

     <!-- add FOOTER -->
    <?php include_once("footer.php"); ?>    
    <!-- END FOOTER -->

	</div>
</div>


   <!-- Jquery  & plug-in -->
  <script type="text/javascript" src="lib/jquery-1.4.4.min.js"></script> 
  <script type="text/javascript" src="lib/jquery-ui.min.js"></script> 
  <script type="text/javascript" src="lib/patmisc.postload.lib.min.js"></script> 

  <!-- LANGUAGE File (MASTER) -->
  <?php if (!$DISABLE_TRANSLATION) { ?> 
    <script type="text/javascript" src="lang/<?php echo str_replace('_','-',$cust_lang_long); ?>.js"></script>
  <?php }?>

  <!-- LANGUAGE File (CUSTOM) - COMING ON TOP OF EXISTING ONE -->
  <?php if (isset($THEME_CUST_LANG_URL) && $THEME_CUST_LANG_URL!="" && !$DISABLE_TRANSLATION) { ?> 
    <script type="text/javascript" src="<?php echo $THEME_CUST_LANG_URL.str_replace('_','-',$cust_lang_long); ?>.js"></script>
  <?php }?>

  <!-- Core feature of ZADS ESSENTIAL STATIC PAGES  --> 
  <script type="text/javascript" src="js/zads-static-page.js"></script> 


  <!-- Specific Javascript to this page  -->

  <script type="text/javascript">

    $(document).ready(function() {

        
      // JQUERY FUNCTION.
      $(".accordion").accordion({
          heightStyle: "content",
          active: false,
          collapsible: true
      });


      $(".accordion h3").each(function (elem){
        var iconspan =  '<i class="h3icon icon-fa-plus-sign mr6"></i>'; 
        $(this).prepend(iconspan); 
      });
   
      // EXPAND AND COLLAPSE MENUS ON “HEADER CLICK”
      $(".accordion h3").click(function() {
          $(".accordion h3").animate({ 'background-color': 'none', 'color' : '#444' }, 100);
          // $("#accordion h3").css({ 'color': '#000' });
          if ($(this).hasClass("ui-state-active")) {
              // reset all and change the one clicked
              $(this).parent().find('i').removeClass('icon-fa-plus-sign').removeClass('icon-fa-minus-sign').addClass('icon-fa-plus-sign');
              $(this).find('i').removeClass('icon-fa-plus-sign').addClass('icon-fa-minus-sign');

          }
          else {
            $(this).parent().find('i').removeClass('icon-fa-plus-sign').removeClass('icon-fa-minus-sign').addClass('icon-fa-plus-sign');
            $(this).find('i').removeClass('icon-fa-minus-sign').addClass('icon-fa-plus-sign');
          }

          $(this).animate({ 'background-color': '#000', 'color' : '#FFF' }, 100); // HIGHLIGHT THE SELECTED HEADER (BLOCK)
      });

    }); // end ready function

  </script>



</body>
</html>
