<?php 
  // ----- add generic header for STATIC pages  -------------//
  include_once "header-static.php";
?> 

  <div id="site">
	<div class="center-wrapper">


    <div id="header">

      <!-- Main menu -->
      <?php  include_once "site-title-static.php"; ?>
      <!-- end main menu -->


      <div class="clearer">&nbsp;</div>

      <!-- sub menu navigation  -->
      <div id="navigation">
        <div id="main-nav">
          <div id="main-nav-links">
            <ul class="tabbed">
            </ul>
          </div>
          <div class="clearer">&nbsp;</div>
        </div>
        <div class="clearer">&nbsp;</div>
      </div>
      <!-- end sub menu navigation -->

    </div>

		<div class="main" id="main-two-columns">
		
            <div class="tc-maintext">
            

            <p>
            <p> </p>
<h1>Règles Générales de Diffusion des Annonces (RGDA)</h1>

			<p>&nbsp;</p>
			
			<strong>1. Acceptation des Règles Générales de Diffusion des Annonces</strong>
	
			<p>&nbsp;</p>
			
			<p align="justify">1.1 La diffusion d'une petite Annonce (ci-après " Annonce ") diffusée sur le site internet <?php echo $cust_site_name;?> édité par  <?php echo $cust_site_owner_accronym;?>, implique pour l'annonceur, l'acceptation sans réserve des présentes <strong>Règles Générales de Diffusion des Annonces</strong> (RGDA) à l'exclusion expresse de toutes conditions autres ou contraires des co-contractants de <?php echo $cust_site_owner_accronym;?>, insérées dans leurs documents d'information, lettres, contrats, etc., reçus ou à recevoir et de tous usages professionnels contraires aux présentes, lesquels conditions et usages seront considérés comme inopposables à <?php echo $cust_site_owner_accronym;?>.</p>
			
			<p>&nbsp;</p>
			
			<p align="justify">1.2 <?php echo $cust_site_name;?> apporte un service communautaire visant à protéger au maximum les échanges équitables et honnêtes entre les utilisateurs. La diffusion d'une Annonce est sous le contr&ocirc;le de l'annonceur. La communauté <?php echo $cust_site_name;?> est auto-constituée sans que <?php echo $cust_site_owner_accronym;?> puisse être tenu responsable de la qualité et des agissement de cette communauté. Tout utilisateur, annonceur ou titulaire de droits     droits peut signaler les Annonces qui portent atteinte à leurs droits de propriété intellectuelle par le biais de la fonction &quot;signaler un problème&quot;. </p>

			<p>&nbsp;</p>
			
			<p align="justify">1.3 Toute adjonction, rature, modification ou suppression qui serait portée sur les présentes devra, pour être opposable à <?php echo $cust_site_owner_accronym;?> être contresignées par celle-ci.</p>
			
			<p>&nbsp;</p>
    
			<p align="justify">1.4 Le fait que <?php echo $cust_site_owner_accronym;?> ne se prévale pas à un moment donné de l'une quelconque des dispositions des présentes conditions générales de diffusion ne peut être interprété comme valant renonciation à s'en prévaloir ultérieurement.</p>

			<p>&nbsp;</p>
			
			<strong>2. Diffusion</strong>
				
			<p>&nbsp;</p>
		
			<p align="justify">2.1 L'annonceur reconna&icirc;t être l'auteur unique et exclusif du texte de l'Annonce. A défaut, il déclare disposer de tous les droits et autorisations nécessaires à la parution de celle-ci.</p>
			
			<p>&nbsp;</p>
		
			<p align="justify">2.2 L'Annonce est diffusée sous la responsabilité exclusive de l'annonceur.</p>
			
			<p>&nbsp;</p>
      
        	<p align="justify">2.3 L'annonceur certifie que l'Annonce est conforme à l'ensemble des dispositions légales et réglementaires en vigueur et respecte les droits des tiers. En conséquence, l'annonceur relève <?php echo $cust_site_owner_accronym;?>, ses sous-traitants et fournisseurs, de toutes responsabilités, et les garantit contre toutes condamnations, frais judiciaires et extrajudiciaires, qui résulteraient de tout recours en relation avec la diffusion de l'Annonce et les indemnise pour tout dommage résultant de la violation de la présente disposition.</p>
        
			<p>&nbsp;</p>
      
		    <p align="justify">2.4 Sans préjudice de l'application de la précédente clause, et sans que cela crée à sa charge une obligation de vérifier le contenu, l'exactitude ou la cohérence de l'Annonce, <?php echo $cust_site_owner_accronym;?> se réserve le droit de refuser à tout moment une Annonce pour tout motif légitime, et notamment des éléments de texte (mots, expressions, phrases&hellip;etc.), qui lui semblerait contraire aux dispositions légales ou réglementaires, aux bonnes m&oelig;urs, à l'esprit de la publication, ou susceptible de troubler ou choquer les lecteurs. Un tel refus ne fait na&icirc;tre au profit de l'annonceur aucun droit à indemnité.</p>
			
			<p>&nbsp;</p>
      
			<strong>3. Limitation de responsabilité</strong>
			
			<p>&nbsp;</p>
			
			<p align="justify">3.1 Sauf dol ou faute lourde, <?php echo $cust_site_owner_accronym;?>, ses sous-traitants et fournisseurs ne seront tenus en aucun cas à reparation, pécuniaire ou en nature, du fait d'erreurs ou d'omissions dans la composition ou la traduction d'une annonce, ou de défaut de parution de quelque nature que ce soit. En particulier, de tels événements ne pourront en aucun cas ouvrir droit à une indemnisation sous quelque forme que ce soit.</p>
			
		    <p>&nbsp;</p>
			
			<p align="justify">3.2 Ni l'annonceur, d'une part, ni <?php echo $cust_site_owner_accronym;?>, ses sous-traitants ou fournisseurs, d'autre part, ne pourra être tenu pour responsable de tout retard, inexécution ou autre manquement à ses obligations au titre des présentes qui (1) résulterait, directement ou indirectement, d'un événement échappant à son contr&ocirc;le raisonnable, et (2) n'aurait pas pu être évité à l'aide de mesures de précaution, solutions de remplacement ou autres moyens commercialement raisonnables.</p>
        
			<p>&nbsp;</p>
			
			<p align="justify">3.3 Ni l'annonceur, d'une part, ni <?php echo $cust_site_owner_accronym;?>, ses sous-traitants ou fournisseurs, d'autre part, ne pourra être tenu pour responsable des retards ou des impossibilités de remplir ses obligations contractuelles, liés à des destructions de matériels, aux attaques ou au piratage informatiques, à la privation, à la suppression ou à l'interdiction, temporaire ou définitive, et pour quelque cause que ce soit - dont les pannes ou indisponibilités inhérentes aux serveurs d'hébergement -, de l'accès au réseau Internet.</p>
        
            <p>&nbsp;</p>
			
            <p align="justify">3.4 <?php echo $cust_site_owner_accronym;?> se réserve le droit de suspendre ou d'arrêter la diffusion du site <?php echo $cust_site_name;?> sans être tenue de verser à l'annonceur une indemnité de quelque nature que ce soit.</p>
          
			<p>&nbsp;</p>
		  
			<p align="justify">3.5 <?php echo $cust_site_name;?> est un site communautaire de publication de petites annonces et en aucun cas un intermédiaire entre offreur et demandeur. En d'autres termes, la responsabilité de la société <?php echo $cust_site_owner_accronym;?> ne saurait être engagée directement ou indirectement dans les transactions qui obéissent aux règles générales du Code Civil (art. 1641 et suivants). <?php echo $cust_site_owner_accronym;?> se réserve la possibilité de saisir toutes voies de droit à l'encontre des personnes qui n'auraient pas respecté cette interdiction.</p>
        
			<p>&nbsp;</p>
		  
		    <p align="justify">3.6 Toute réclamation, pour être recevable, doit être transmise par lettre, ou e-mail, dans un délai de quarante huit (48) heures à compter de la date de diffusion sur <?php echo $cust_site_name;?>.</p>
        
			<p>&nbsp;</p>
			
			
			<strong>4. Sont interdits sur le site <?php echo $cust_site_name;?></strong>
			
			<p>&nbsp;</p>
		
			 <p align="justify">Toute Annonce ou message ne respectant pas ces interdictions sera supprimé sine die, sans préavis ou autre notification de <?php echo $cust_site_owner_accronym;?>. Ceci concerne aussi bien les Annonces sans contrepartie financière (échange, troc, prêt...) que les Annonces payantes.
		
		    <p>&nbsp;</p>
		
			<p align="justify">4.1 Interdictions d'ordre général</p>
		
			<p>&nbsp;</p>
			
		    <ul>
			
				<li class="list">Annonce trop courte, imprécise utilisant un vocabulaire confus ou chargé par trop d'abbréviations.</li>
				<li class="list">Usage de médias (photos ou vidéos) n'ayant pas de lien direct avec l'article proposé.</li>
				<li class="list">Annonce exprimant l'offre ou la recherche de plusieurs articles dans une même annonce.</li>
				<li class="list">La diffusion d'une même annonce dans de multiples catégories ou sous-catégories.</li>
				<li class="list">Créer et publier plusieurs annonces dont le contenu présente des similitudes.</li>
				<li class="list">Annonce faisant la promotion d'un site Web à caractère privé ou professionnel.</li>
				<li class="list">Tenir un langage raciste, diffamatoire, abusif, pornographique, obscène.</li>
				<li class="list">Annonce usurpant l'identité d'une personne ou d'une marque sans son consentement.</li>
				<li class="list">Contenu engageant la responsabilité ou prenant l'identité de <?php echo $cust_site_owner_accronym;?> ou de ses collaborateurs.</li>
			
			</ul>
				
			<p>&nbsp;</p>	
				
			<p align="justify">4.2 Achat / Vente</p>
		
			<p>&nbsp;</p>
			
		    <ul>
			
				<li class="list">Tabac, drogues et objets associés facilitant leur transport ou production et toutes substances dangereuses et illicites (tels que définis par la législation en vigueur),</li>
				<li class="list">Cosmétique neufs ou usagés, médicaments (et accessoires médicaux) et parapharmacie</li>
				<li class="list">Armes à feu et assimilés : pièges de chasse, pièces détachées d'armes à feu, couteux à cran d'arrêt, bombes à gaz lacrymogène, tout type de pistolets, revolvers ou carabines : à grenaille, à plomb ou à billes (liste non exhaustive).</li>
				<li class="list">Espèces végétales et animales protégées : plantes ou animaux protégées par les conventions internationales ou en voie d'extinction.</li>
				<li class="list">Contrefaçons de tout produit quelles que soient sa nature et destination.</li>
				<li class="list">Copies illégales de toute oeuvre de l'esprit quelque soit le support et contrevenant aux droits de propriété physique ou intellectuelle de son auteur ou d'un ayant droit.</li>
				<li class="list">Vente / revente de biens volés.</li>
				<li class="list">Produits pharmaceutiques n'ayant ne bénéficiant ni d'une autorisation de la Haute Autorité de Santé ni d'une licence commerciale de distribution sur le territoire Français.</li>
				<li class="list">Matières dangereuses ou produits dangereux (tels que définis par la législation en vigueur) : explosifs, herbicides, pesticides, pétards et fusées pour d'artifice et objets associés facilitant leur transport ou production.</li>
				<li class="list">Tout article usagé présentant un défaut de fonctionnement ne lui permettant pas d'assurer son service tel que le jour de son achat.</li>
				<li class="list">Tout produit ou substances du corps humain : produits sanguins, fluides corporels ou tout autre organe.</li>
				<li class="list">Fausses pièces d'identité, données personnelles et à caractère financier, y compris faux diplômes et insignes officiels.</li>
				<li class="list">Vente de renseignements ou de tout fichier d'adresses postales ou e-mails à caractère privé ou professionnel.</li>
				<li class="list">Faux moyens de paiement : billets, pièces, cartes bancaires...(liste non exhaustive y compris objets associés facilitant leur transport ou production.</li>
				<li class="list">Vente de valeurs mobilières : actions, obligations, stock options...(liste non exhaustive).</li>
			
			</ul>
					
			<p>&nbsp;</p>
			
			<p align="justify">4.3 Conditions particulières : catégorie <strong><em>Animaux</em></strong></p>
		
			<p>&nbsp;</p>

			<p align="justify">La loi n°99-5 du 6 janvier 1999 relative aux animaux dangereux et errants et la protection des animaux (Jo du 7 janvier 1999) précise entre autres : "Pour les animaux dangereux dits de 1ère catégorie (chiens d'attaque) la stérilisation est obligatoire et donne lieu à un certificat vétérinaire".</p><br />
		
			<p align="justify">Ainsi, la vente d'un chien d'attaque adulte est autorisé sous réserve que l'animal ait été stérilisé et que son propriétaire fournisse copie du certificat de vaccination. La vente du chiot de <strong>moins de 8 semaines</strong> est interdite.</p><br />
			
			<p align="justify">De plus, la cession de tout animal de compagnie, à titre onéreux ou gratuit, est soumise à réglementation :</p>
				
			<p align="justify">On entend par animal de compagnie tout animal détenu ou destiné à être détenu par l'homme pour son agrément (article L. 214-6 du Code rural).</p>
				
			<p>&nbsp;</p>

			<p align="justify"><strong>L'obligation d'identification (article L. 212-10 du Code rural)</strong> : préalablement à leur cession, à titre gratuit ou onéreux, les chiens et chats doivent être identifiés. L'identification est obligation pour tous les chiens nés après le 6 janvier 1999 &acirc;gés de plus de 4 mois et pour les chats de plus de 7 mois nés après le 1er janvier 2012.</p>

				<p>&nbsp;</p>

			<p align="justify"><strong>Les interdictions d'acquisition et de cession</strong> : il est interdit de céder à titre onéreux des chiens et des chats &acirc;gés de moins de huit semaines (article L. 214-8 du Code rural). Il est interdit d'acquérir ou de céder, à titre gratuit ou onéreux, des chiens appartenant à la première catégorie (article L. 211-15 du Code rural).</p>
        
				<p>&nbsp;</p>
				
			<p align="justify"><strong>L'interdiction de cession des animaux de compagnie dans le cadre de certaines manifestations</strong> : la cession, à titre gratuit ou onéreux, d'animaux de compagnie est interdite dans les foires, marchés, brocantes, salons, expositions ou toutes autres manifestations non spécifiquement consacrés aux animaux (article L. 214-7 du Code rural).</p>				
				
			  <p>&nbsp;</p>
				
			<p align="justify"><strong>Les conditions relatives à la cession par des professionnels (article L214-8 du code rural)</strong> : toute vente d'animaux domestiques doit s'accompagner, au moment de la livraison à l'acquéreur, de la délivrance :</p>
        
        <ul>

            <li class="list">d'une attestation de cession</li> 
            <li class="list">d'un document d'information sur les caractéristiques et les besoins de l'animal contenant, au besoin, des conseils d'éducation</li>
            <li class="list">pour les ventes de chiens, d'un certificat vétérinaire</li>
				
				</ul>
				
				<p>&nbsp;</p>
				
			<p align="justify"><strong>Les conditions relatives à la cession par des particuliers (article L214-8 du code rural) </strong>: toute cession à titre onéreux d'un chat est subordonnée à la délivrance d'un certificat de bonne santé établi par un vétérinaire. Toute cession à titre gratuit ou onéreux d'un chien doit s'accompagner d'un certificat de bonne santé.</p>
				
				<p>&nbsp;</p>
				
			<p align="justify"><strong>Les conditions relatives aux offres de cession (article L214-8 du code rural)</strong>: toute publication d'une offre de cession de chats ou de chiens, quel que soit le support utilisé, doit mentionner le numéro d'identification du professionnel ou mentionner soit le numéro d'identification de chaque animal, soit le numéro d'identification de la femelle ayant donné naissance aux animaux, ainsi que le nombre d'animaux de la portée (article L. 214-8 du Code rural).</p>
			
			  <p>&nbsp;</p>
			  
			<p align="justify">Le numéro d'identification d'un animal est composé de 15 chiffres de la façon suivante :</p> 
			
			<ul>

            <li class="list">3 premiers chiffres : code du pays (250 pour la France)</li> 
            <li class="list">2 suivants: espèce animale (26 pour les chats et chiens)</li>
            <li class="list">2 suivants: code du laboratoire</li>
            <li class="list">8 suivants: code animal</li>
				
				</ul>
							
				<p>&nbsp;</p>
				
			<p align="justify"><strong>La cession d'animaux sur la voie publique (article R214-31-1 du Code Rural)</strong> : il est interdit de céder un animal sur la voie publique.</p>
				
				<p>&nbsp;</p>
				
			<p align="justify">L'annonce doit également comporter l'&acirc;ge des animaux et l'existence ou l'absence d'inscription de ceux-ci à un livre généalogique reconnu par le Ministre chargé de l'agriculture.</p>
				
				<p>&nbsp;</p>
			
			<p align="justify">4.4 Conditions particulières : catégorie <strong><em>Rencontre</em></strong></p>
		
				<p>&nbsp;</p>
			
			<ul>
			
				<li class="list">La publication d'annonces dans cette catégorie est <u>strictement interdite</u> à toute personne &acirc;gée <u>de moins de</u> dix-huit(18) ans.</li>
				<li class="list">Annonce pour tout acte sexuel contre rémunération financière ou en nature.</li>
			
			</ul>
			
        <p>&nbsp;</p>
			
			<p align="justify">4.5 Conditions particulières : catégorie <strong><em>Service</em></strong></p>
			
        <p>&nbsp;</p>
			
			<ul>
			
				<li class="list">Proposition de castings photos ou vidéos à caractère érotique ou pornographique.</li>
				<li class="list">Proposition de séances photos ou réalisation de vidéos à caractère privé.</li>
				<li class="list">Annonce proposant un accompagnement tarifé : escort-girl ou escort-boy.</li>
			
			</ul>
			
        <p>&nbsp;</p>
			
			<p align="justify">4.6 Conditions particulières : catégorie <strong><em>Emploi</em></strong></p>
			
        <p>&nbsp;</p>
			
			<ul>
			
				<li class="list">Offre et demande d'un emploi de danseur(euse) ou strip-tiseuse dans une discothèque ou établissements assimilés.</li>
				<li class="list">Offre d'adhésion à une structure pyramidale, adhésion à un club ou marketing multi-niveaux.</li>
				<li class="list">Toute offre d'emploi dont le descriptif est imprécis ou l'expression de la fonction recherchée reste ambigue.</li>
				<li class="list">Toute offre d'emploi ne comportant pas au <u>minimum</u> : description détaillée de l'emploi proposée, lieu, raison sociale, salaire (liste non exhaustive).</li>
				
			</ul>
			
        <p>&nbsp;</p>
        
      <p align="justify">4.7 Conditions particulières : catégorie <strong><em>Immobilier</em></strong></p>
			
        <p>&nbsp;</p>
        
        <p align="justify">D'après la <strong>loi n°2010-788 du 12 juillet 2010</strong> portant engagement national pour l'environnement et le <strong>décret n°2010-1662 du 28 décembre 2010</strong>, depuis le 1er Janvier 2011, toutes les petites annonces de particuliers concernant la vente ou la location de biens immobiliers soumis à la réalisation d'un diagnostic de performance énergétique, doivent comporter l'étiquette et la classe de performance énergétique du logement concerné.<br /> <br />La diffusion de votre annonce sans l'indication de la performance énergétique du logement concerné n'est pas conforme à la réglementation et votre responsabilité est susceptible d'être engagée. Aussi, vous avez pleinement conscience que la parution de votre annonce en l'état, et ce, malgré les renseignements fournis, est effectuée à vos seuls risques et périls.</p>
        
        <p>&nbsp;</p>
        
       <strong>5. Pour nous contacter :</strong>
					
        <p>&nbsp;</p>
		
		    <p align="justify">5.1 Nous contacter par :</p>
		
		    <p>&nbsp;</p>
		    
		    <p align="justify">E-mail : <a href="mailto:contact@annonces-eschau.fr">nous contacter</a></p>
		
        <p>&nbsp;</p>
      
			<strong>6. Divers</strong>
		  
		    <p>&nbsp;</p>
	  
			<p align="justify">6.1 Les marques et logotypes <?php echo $cust_site_name;?> et <?php echo $cust_site_owner_accronym;?> sont déposés par <?php echo $cust_site_owner_accronym;?>. Sans l'accord de cette dernière, toute reproduction ou utilisation est strictement interdite.</p>
			
        <p>&nbsp;</p>
			
			<p align="justify">Les <strong>Règles Générales de Diffusion des Annonces</strong> (RGDA) constituent une extension des <strong>Conditions Générales d'Utilisation</strong> du site <?php echo $cust_site_name;?>.<br />Cette liste est non exhaustive et <?php echo $cust_site_owner_accronym;?> se réserve le droit de supprimer sine die sans préavis d'aucune sorte ou notification toute Annonce ou message ne respectant pas ces interdictions.</p>
			
        <p>&nbsp;</p>

			<strong>Date de dernière mise à jour : </strong>01 Mars 2014 - rev 1.0</strong>
		
</div>

			<div class="clearer">&nbsp;</div>

		</div>

 <!-- add FOOTER -->
    <?php include_once("footer.php"); ?>    
    <!-- END FOOTER -->

    

	</div>
</div>

   <!-- Jquery  & plug-in -->
  <script type="text/javascript" src="lib/jquery-1.4.4.min.js"></script> 
  <script type="text/javascript" src="lib/jquery-ui.min.js"></script> 
  <script type="text/javascript" src="lib/patmisc.postload.lib.min.js"></script> 


  <!-- LANGUAGE File (MASTER) -->
  <?php if (!$DISABLE_TRANSLATION) { ?> 
    <script type="text/javascript" src="lang/<?php echo str_replace('_','-',$cust_lang_long); ?>.js"></script>
  <?php }?>

  <!-- LANGUAGE File (CUSTOM) - COMING ON TOP OF EXISTING ONE -->
  <?php if (isset($THEME_CUST_LANG_URL) && $THEME_CUST_LANG_URL!="" && !$DISABLE_TRANSLATION) { ?> 
    <script type="text/javascript" src="<?php echo $THEME_CUST_LANG_URL.str_replace('_','-',$cust_lang_long); ?>.js"></script>
  <?php }?>

  <!-- Core feature of ZADS ESSENTIAL STATIC PAGES  --> 
  <script type="text/javascript" src="js/zads-static-page.js"></script> 


</body>
</html>
