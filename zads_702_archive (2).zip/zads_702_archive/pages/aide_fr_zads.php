<?php 

  // --- define the variable ---
  // ----- if not defined then the defaut and global site parameters will apply
  // $forced_cust_title="my title";
  // $forced_cust_description="My description";
  // $forced_cust_keywords ="";



  // ----- add generic header for STATIC pages  -------------//
  include_once "header-static.php";
?> 

  <div id="site">
	<div class="center-wrapper">


    <div id="header">

      <!-- Main menu -->
      <?php  include_once "site-title-static.php"; ?>
      <!-- end main menu -->


      <div class="clearer">&nbsp;</div>

      <!-- sub menu navigation  -->
      <div id="navigation">
        <div id="main-nav">
          <div id="main-nav-links">
            <ul class="tabbed">
            </ul>
          </div>
          <div class="clearer">&nbsp;</div>
        </div>
        <div class="clearer">&nbsp;</div>
      </div>
      <!-- end sub menu navigation -->

    </div>

		<div class="main" id="main-two-columns">
		
      <div class="tc-maintext">

        <p> </p>
			   <h1>Example of static page</h1>
        <p>Lorem Elsass ipsum gal Strasbourg consectetur schneck leo rossbolla et munster geïz dui hopla tristique mollis Coopé de Truchtersheim vielmols, merci vielmols lotto-owe wie tellus knack tellus Mauris sit Huguette morbi baeckeoffe Oberschaeffolsheim Pfourtz ! leo senectus Kabinetpapier elementum Yo dû. ornare Salu bissame eleifend ornare porta réchime rhoncus Gal. kartoffelsalad nüdle chambon mamsell amet tchao bissame suspendisse jetz gehts los Hans salu vulputate hopla sed id barapli amet rucksack bissame Wurschtsalad risus, mänele Chulia Roberstau geht's bredele météor Heineken quam. nullam gravida lacus sit und flammekueche Spätzle Racing. yeuh. dolor leverwurscht Morbi schnaps gewurztraminer Verdammi messti de Bischheim ch'ai varius libero, commodo sagittis eget kougelhopf Miss Dahlias quam, ac hoplageiss amet, libero. hopla ullamcorper elit sit Richard Schirmeck hop sed aliquam Christkindelsmärik pellentesque purus Carola so placerat dignissim turpis, knepfle schpeck adipiscing Chulien Salut bisamme ac semper wurscht blottkopf, picon bière kuglopf condimentum id, non Gal ! Pellentesque libero, non Oberschaeffolsheim in, auctor, DNA, s'guelt ante ftomi! habitant hopla turpis .</p>
	




  
      </div>

			<div class="clearer">&nbsp;</div>

		</div>

 <!-- add FOOTER -->
    <?php include_once("footer.php"); ?>    
    <!-- END FOOTER -->

    

	</div>
</div>

   <!-- Jquery  & plug-in -->
  <script type="text/javascript" src="lib/jquery-1.4.4.min.js"></script> 
  <script type="text/javascript" src="lib/jquery-ui.min.js"></script> 
  <script type="text/javascript" src="lib/patmisc.postload.lib.min.js"></script> 

  <!-- LANGUAGE File (MASTER) -->
  <?php if (!$DISABLE_TRANSLATION) { ?> 
    <script type="text/javascript" src="lang/<?php echo str_replace('_','-',$cust_lang_long); ?>.js"></script>
  <?php }?>


  <!-- LANGUAGE File (CUSTOM) - COMING ON TOP OF EXISTING ONE -->
  <?php if (isset($THEME_CUST_LANG_URL) && $THEME_CUST_LANG_URL!="" && !$DISABLE_TRANSLATION) { ?> 
    <script type="text/javascript" src="<?php echo $THEME_CUST_LANG_URL.str_replace('_','-',$cust_lang_long); ?>.js"></script>
  <?php }?>

  <!-- Core feature of ZADS ESSENTIAL STATIC PAGES  --> 
  <script type="text/javascript" src="js/zads-static-page.js"></script> 


</body>
</html>
