      
<?php 

$variant=2; // set the varian version  
if ($variant==1) { ?>
      <div id="site-title">
      <div style="float:left;">  
        <!-- image logo -->
        <?php if ($LOGO_PAYPAL_FQDN) { ?>  <img src="<?php echo $LOGO_PAYPAL_FQDN;?>" width="" height=""> <?php } ?> 

        <div id="site-motto-static" class=""><?php  echo (stripslashes($cust_site_motto)); ?></div>
       </div>
  
        <!-- Print Icon   -->
        <div class="right" id="item-print" onclick="javascript:window.print();"><span class="icon"></span><div><a href="#" title="" name="manage_ad">Imprimer</a></div></div>
       
        <div class="clearer">&nbsp;</div>
      </div>

<?php } ?>

<?php if ($variant==2) { ?>

      <div id="site-title">  
        <table><tr>
          <!-- image logo -->
          <td class="colA">
          <?php if ($LOGO_PAYPAL_FQDN) { ?>  <img src="<?php echo $LOGO_PAYPAL_FQDN;?>" width="" height=""> <?php } ?> 
          <div id="site-motto-static" class=""><?php  echo (stripslashes($cust_site_motto)); ?></div>
          </td>
          <!-- site name -->
          <td class="colB">
          <h1 id="motto"><?php echo (stripslashes($cust_site_name));?></h1>
          </td>

          <!-- Print Icon   -->
          <td class="colC">
          <div class="right" id="item-print" onclick="javascript:window.print();"><span class="icon"></span><div><a href="#" title="" name="manage_ad">imprimer</a></div></div>
          </td>
          
          <div class="clearer">&nbsp;</div>
        </tr></table>
      </div>

<?php } ?>
      <!-- end main menu -->