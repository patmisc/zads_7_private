<?php 
  // ----- add generic header for STATIC pages  -------------//
  include_once "header-static.php";
?> 




  <div id="site">
	<div class="center-wrapper">

    <div id="header">

      <!-- Main menu -->
      <?php  include_once "site-title-static.php"; ?>
      <!-- end main menu -->


      <div class="clearer"></div>

      <!-- sub menu navigation  -->
      <div id="navigation">
        <div id="main-nav">
          <div id="main-nav-links">
            <ul class="tabbed">
            </ul>
          </div>
          <div class="clearer"></div>
        </div>
        <div class="clearer"></div>
      </div>
      <!-- end sub menu navigation -->

    </div>



		<div class="main" id="main-two-columns">
		
            <div class="maintext">
                       

		   
         <div class="clearer"></div>
		 
			   <h1 id="motto">Tarifs (en  &euro; TTC)</h1>
			   
          
			
<div style="display:inline"><!-- BEGIN 1ST TAB -->
			
<!-- Services Gratuits Particuliers / Pros -->
			
<div class="pricing_table pricing_four"><!-- BEGIN TABLE CONTAINER -->


    <ul class="pricing_column_first"><!-- BEGIN DESCRIPTION COLUMN -->


        <li class="pricing_header1" style="text-align:center;"><span>Services de base (gratuits)</span></li>
        
        <li class="odd"><span>Création d'un compte</span>
          <a class="tooltipwanna" href="#">
            	<span>La création d'un compte est <em>gratuite</em> aussi bien pour les <em>Particuliers</em> que pour les <em>Professionnels</em>.</span>
            </a>
        </li>
        <li class="even"><span>Suppression d'un compte</span>
        	<a class="tooltipwanna" href="#">
            	<span>Si votre compte reste <em>inactif</em> (non utilisé) pendant <em>plus de 30 jours</em>, celui-ci sera automatiquement <em>supprimé</em> de WannAnnonces.</span>
            </a>
        </li>
		 <li class="odd"><span>Sauvegarde d'un compte</span>
        	<a class="tooltipwanna" href="#">
            	<span>En cas de <em>non confirmation</em> de votre <em>Pack Découverte</em>pendant les 15 jours correspondant à sa durée de validité, celui-ci sera <em>désactivé</em>. Toutefois, votre compte est sauvegardé pendant <em>15 jours supplémentaires</em>. Ainsi, vous pouvez le ré_activer et profiter des services de WannAnnonces.</span>
            </a>
        </li>
        <li class="even"><span>Dépôt d'une annonce</span>
        	<a class="tooltipwanna" href="#">
            	<span>Le dépôt d'une annonce est <em>gratuite</em> aussi bien pour les <em>Particuliers</em> que pour les <em>Professionnels</em>.</span>
            </a>
        </li>
        <li class="odd"><span>Annonce anonyme</span>
        	<a class="tooltipwanna" href="#">
            	<span>Vous avez la possibilité de publier une annonce de manière <em>anonyme</em> c'est-à-dire en ne diffusant ni votre pseudo, ni votre adresse e-mail et ni votre n° de téléphone. L'utilisateur intéressé par votre offre peut vous contacter via la messagerie interne WannAnnonces à l'aide d'un formulaire.</span>
            </a>
        </li>
        <li class="even"><span>Durée de parution</span>
        	<a class="tooltipwanna" href="#">
            	<span>La durée de parution (ou de publication) de votre annonce est de<em>90 jours</em> à compter de la date de validation de celle-ci par WannAnnonces. Cette durée est valable également pour les annonces du <em>Pack Découverte</em> et des <em>Packs Pros</em>.</span>
            </a>
        </li>
        <li class="odd"><span>Durée d'archivage</span>
        	<a class="tooltipwanna" href="#">
            	<span>Votre annonce est archivée dès lors que celle-ci dépasse la durée de parution (90 jours). La durée d'archivage (ou de sauvegarde) est de <em>30 jours</em>. <u>Exception</u> : les annonces incluses dans la <strong>Pack Découverte</strong> et les <strong>Packs Pros</strong> ne peuvent être archivées et ré-activables.</span>
            </a>
        </li>
        <li class="even"><span>Statut de l'annonce <em>New (Nouveau)</em></span>
        	<a class="tooltipwanna" href="#">
            	<span>Une annonce nouvellement publiée et validée par WannAnnonces acquière le statut de 'New'(Nouveau) pendant <em>2 jours</em>. Cette règle est valable également pour les annonces du <em>Pack Découverte</em> et des <em>Packs Pros</em>.</span>
            </a>
        </li>
        <li class="odd"><span>Statut de l'annonce <em>Brouillon</em></span>
        	<a class="tooltipwanna" href="#">
            	<span>Une annonce sauvegardée acquière le statut 'brouillon' au maximum pendant <em>7 jours</em>. Au-delà de ce délai, votre annonce est automatiquement supprimée de WannAnnonces. Cette règle est valable également pour les annonces du <em>Pack Découverte</em> et des <em>Packs Pros</em>.</span>
            </a>
        </li>
            <li class="even"><span>Statut de l'annonce <em>Paiement en attente</em></span>
        	<a class="tooltipwanna" href="#">
            	<span>Une annonce peut être sauvegardée avec le statut 'en attente de paiement' au maximum pendant <em>7 jours</em>. Au-delà de ce délai, votre annonce est automatiquement supprimée de WannAnnonces. Cette règle est valable également pour les annonces du <em>Pack Découverte</em> et des <em>Packs Pros</em>.</span>
            </a>
        </li>
        <li class="odd"><span>Modification</span>
        	<a class="tooltipwanna" href="#">
            	<span>Vous pouvez modifier à tout moment et de manière illimitée votre annonce durant toute sa période de parution. Ce service <em>gratuit</em> est également valable pour les annonces du <em>Pack Découverte</em> et des <em>Packs Pros</em>. <u>Cas particulier</u> : si des <em>options de mise en avant</em> (payantes) sont associées à votre annonce, vous ne pouvez <em>ni les supprimer ni les modifier</em>.</span>
            </a>
        </li>
        <li class="even"><span>Suspension</span>
        	<a class="tooltipwanna" href="#">
            	<span>Vous pouvez suspendre à tout moment et de manière illimitée la parution de votre annonce. Ce service <em>gratuit</em> et également valable pour les annonces du <em>Pack Découverte</em> et des <em>Packs Pros</em> ne suspend pas pour autant la durée de parution -limitée à 90jours- qui courts toujours.</span>
            </a>
        </li>
        <li class="odd"><span>Prolongation</span>
        	<a class="tooltipwanna" href="#">
            	<span>Vous pouvez prolonger à tout moment et de manière illimitée la parution (ou la publication) de votre annonce. Ce service est <em>gratuit</em>. <u>Cas particulier</u> : les annonces du <em>Pack Découverte</em> et des <em>Packs Pros</em> ne sont pas éligibles à ce service.</span>
            </a>
        </li>
        <li class="even"><span>Recherche multicritères</span>
        	<a class="tooltipwanna" href="#">
            	<span>WannAnnonces met à votre disposition <em>deux modes</em> de recherche : <em>recherche globale</em> (quoi ? et où ?) ou une <em>recherche avancée</em> à l'aide de plusieurs critères au niveau des catégories et sous-catégories.</span>
            </a>
        </li>
        <li class="odd"><span>Impression affichette + QR code</span>
        	<a class="tooltipwanna" href="#">
            	<span>Service exclusif de WannAnnonces ! Vos souhaitez diffuser votre annonce sur votre lieu de travail ou en milieu associatif...? Rien de plus simple : votre annonce imprimée au format A4 dispose de son propre QR code. Elle pourra ainsi être consultée sur place et lue grâce à une application QR code embarquée sur un Smartphone ou une Tablette.</span>
            </a>
        </li>
        <li class="even"><span>Partage sur les réseaux sociaux</span>
        	<a class="tooltipwanna" href="#">
            	<span>Utilisez la puissance de <em>Buzz</em> des réseaux sociaux. WannAnnonces vous propose de partager votre annonce sur Twitter, Facebook, Google+, Pinterest,...</span>
            </a>
        </li>
        <li class="odd"><span>Messagerie interne</span>
        	<a class="tooltipwanna" href="#">
            	<span>WannAnnonces dispose d'une messagerie interne. Ce système vous permet de communiquer directement avec les autres utilisateurs ou de notifier un abus d'usage à WannAnnonces.</span>
            </a>
        </li>
        <li class="even"><span>Photos</span>
         	<a class="tooltipwanna" href="#">
            	<span>Les <em>Particuliers</em> comme les <em>Professionnels</em> peuvent publier <em>gratuitement</em> jusqu'à <em>5 photos</em> par annonce avec la possibilité d'en ajouter <em>5 de plus</em> en souscrivant à cette <em>option de mise en avant</em> (payante). Dans le cas du <em>Pack Découverte</em>, le nombre de photos est limité à <em>3</em>. Dans le cas des <em>Packs Pros</em>, les Professionnels ont la possibilité de publier <em>jusqu'à 10 photos</em>.</span>
            </a>
        </li>
        <li class="odd"><span>Vidéo</span>
        	<a class="tooltipwanna" href="#">
            	<span>Les <em>Particuliers</em> comme les <em>Professionnels</em> peuvent publier <em>gratuitement</em> <em>1 vidéo</em> par annonce avec la possibilité d'en ajouter <em>1 de plus</em> en souscrivant à cette <em>option de mise en avant</em> payante. Dans le cas du <em>Pack Découverte</em>, le nombre de vidéo est limité à <em>1</em>. Dans le cas des <em>Packs Pros</em>, les Professionnels ont la possibilité de publier <em>jusqu'à 2 vidéos</em>.</span>       	
            </a>
        </li>
        <li class="even"><span>Bannière publicitaire</span>
         	<a class="tooltipwanna" href="#">
            	<span>Les professionnels peuvent mettre en ligne une bannière promotionnelle qui sera positionnée en en-tête de leur page <em>Société</em> dans la rubrique <em>Annuaire des Pros</em>. La taille de la bannière doit être de 728 pixels de large et 90 pixels de hauteur (format <em>Leaderboard</em>). Les extensions de fichiers acceptés sont : .swf, .gif, .jpg, .jpeg et .png</span>
            </a>
        </li>
        <li class="odd"><span>Annuaire des Pros</span>
        <a class="tooltipwanna" href="#">
            	<span>Les professionnels peuvent créer <em>gratuitement</em> dans la rubrique <em>Annuaire des Pros</em> leur page <em>Société</em> sur laquelle ils pourront diffuser : leurs coordonnées complètes, l'adresse de leur site Web, une présentation étendue, une présentation vidéo et portfolio. L'insertion dans l'annuaire est <em>automatique</em> et se fait à la création du compte Professionnel.</span>
            </a>
        </li>
        
                
     </ul><!-- END DESCRIPTION COLUMN -->
        
        
    <div class="pricing_hover_area"><!-- BEGIN HOVER AREA -->
    
    
        <ul class="pricing_column gradient_lightgrey"><!-- BEGIN FIRST CONTENT COLUMN -->

            <li class="pricing_header1">Particuliers</li>
           
            <li class="odd" data-table="création d'un compte"><span class="pricing_yes"></li>
            <li class="even" data-table="suppression d'un compte"><span>au-delà de  30 jours d'inactivité</li>
            <li class="odd" data-table="sauvegarde d'un compte"><span>15 jours</li>
            <li class="even" data-table="dépôt d'une annonce"><span class="pricing_yes"></li>
            <li class="odd" data-table="annonce anonyme"><span class="pricing_yes"></li>
            <li class="even" data-table="durée de parution"><span>90 jours</span></li>
            <li class="odd" data-table="artchivage"><span>30 jours</span></li>
            <li class="even" data-table="statut new"><span>2 jours</span></li>
            <li class="odd" data-table="statut brouillon"><span>Max. 7 jours</span></li>
            <li class="even" data-table="statut brouillon"><span>Max. 7 jours</span></li>
            <li class="odd" data-table="modification"><span class="pricing_yes"></li>
            <li class="even" data-table="suspension"><span class="pricing_yes"></li>
            <li class="odd" data-table="prolongation"><span class="pricing_yes"></li>
            <li class="even" data-table="recherche multicritères"><span class="pricing_yes"></li>
            <li class="odd" data-table="affichette"><span class="pricing_yes"></li>
            <li class="even" data-table="partage sur réseaux sociaux"><span class="pricing_yes"></li>
            <li class="odd" data-table="messagerie interne"><span class="pricing_yes"></li>
            <li class="even" data-table="photos"><span class="pricing_yes"></li>
            <li class="odd" data-table="vidéo"><span class="pricing_yes"></li>
            <li class="even" data-table="bannière publicitaire"><span class="pricing_no"></li>
            <li class="odd" data-table="annuaire des pros"><span class="pricing_no"></li>                
                       
        </ul><!-- END FIRST CONTENT COLUMN -->
        
    
        <ul class="pricing_column gradient_greenwanna"><!-- BEGIN SECOND CONTENT COLUMN -->

            <li class="pricing_header1">Professionnels</li>
            
            <li class="odd" data-table="création d'un compte"><span class="pricing_yes"></li>
            <li class="even" data-table="suppression d'un compte"><span>au-delà de  30 jours d'inactivité</li>
            <li class="odd" data-table="sauvegarde d'un compte"><span>15 jours</li>
            <li class="even" data-table="dépôt d'une annonce"><span class="pricing_yes"></li>
            <li class="odd" data-table="annonce anonyme"><span class="pricing_yes"></li>
            <li class="even" data-table="durée de parution"><span>90 jours</span></li>
            <li class="odd" data-table="artchivage"><span>30 jours</span></li>
            <li class="even" data-table="statut new"><span>2 jours</span></li>
            <li class="odd" data-table="statut brouillon"><span>Max. 7 jours</span></li>
            <li class="even" data-table="statut brouillon"><span>Max. 7 jours</span></li>
            <li class="odd" data-table="modification"><span class="pricing_yes"></li>
            <li class="even" data-table="suspension"><span class="pricing_yes"></li>
            <li class="odd" data-table="prolongation"><span class="pricing_yes"></li>
            <li class="even" data-table="recherche multicritères"><span class="pricing_yes"></li>
            <li class="odd" data-table="affichette"><span class="pricing_yes"></li>
            <li class="even" data-table="partage sur réseaux sociaux"><span class="pricing_yes"></li>
            <li class="odd" data-table="messagerie interne"><span class="pricing_yes"></li>
            <li class="even" data-table="photos"><span class="pricing_yes"></li>
            <li class="odd" data-table="vidéo"><span class="pricing_yes"></li>
            <li class="even" data-table="bannière publicitaire"><span class="pricing_yes"></li>
            <li class="odd" data-table="annuaire des pros"><span class="pricing_yes"></li>
            
                                
        </ul><!-- END SECOND CONTENT COLUMN -->
    
    
	</div><!-- END HOVER AREA -->

    
</div><!-- END TABLE CONTAINER -->			
			
<!-- END Services Gratuits Particuliers / Pros -->			

</div><!-- END 1ST TAB -->

<div style="display:inline"><!-- BEGIN 2ND TAB -->

<!-- Options Payantes Particuliers / Pros -->
			
<div class="pricing_table pricing_four"><!-- BEGIN TABLE CONTAINER -->


    <ul class="pricing_column_first"><!-- BEGIN DESCRIPTION COLUMN -->


        <li class="pricing_header1" style="text-align:center;"><span>Options  de mise en avant (payantes)</span></li>
        
        <li class="odd" data-table="mise à la Une"><span><strong>Mise à la Une</strong></span>
         	<a class="tooltipwanna" href="#">
            	<span>Mettez votre annonce 'à la Une' et bénéficier d'une meilleure visibilité.</span>
            </a>
        </li>
        <li class="even"><span>Pendant 7 jours</span></li>
        <li class="odd"><span>Pendant 15 jours</span></li>
        <li class="even"><span>Pendant 30 jours</span></li>
        
        <li class="odd" data-table="mise à la Une"><span><strong>En tête de liste</strong></span>
           	<a class="tooltipwanna" href="#">
            	<span>Faites remonter votre annonce en 'tête de liste' et multiplier vos contacts. Votre annonce remonte en 'tête de liste' chaque semaine le jour où votre annonce a été validée par WannAnnonces.<span>
            </a>
        </li>
        <li class="even"><span>1 jour/semaine</span></li>
        <li class="odd"><span>Pendant 7 jours</span></li>
        <li class="even"><span>Pendant 15 jours</span></li>
        <li class="odd"><span>Pendant 30 jours</span></li>
        
        <li class="even" data-table="mise en urgent"><span><strong>Mise en Urgent</strong></span>
           <a class="tooltipwanna" href="#">
            	<span>Ajouter la mention <font style="color:#F60; font-weight:bold;">'! Urgent'</font> à votre annonce et vender plus rapidement.</span>
           </a>
        </li>
        <li class="odd"><span>Pendant 7 jours</span></li>
        <li class="even"><span>Pendant 15 jours</span></li>
        <li class="odd"><span>Pendant 30 jours</span></li>        
                
        <li class="even" data-table="encadré"><span><strong>Encadré de couleur</strong></span>
         	<a class="tooltipwanna" href="#">
            	<span>Ajouter un encadré de couleur autour de votre annonce pour plus de visibilité lors des recherches.</span>
          </a>
        </li>
        <li class="odd"><span>1 jour/semaine</span></li>
        <li class="even"><span>Pendant 7 jours</span></li>
        <li class="odd"><span>Pendant 15 jours</span></li>
        <li class="even"><span>Pendant 30 jours</span></li>        
                
        <li class="odd" data-table="photos-vidéos"><span><strong>Photos / Vidéos</strong></span>
         	<a class="tooltipwanna" href="#">
            	<span>Une annonce détaillée et bien illustrée par des photos (ou vidéos) est, en moyenne, jusqu'à 20 fois plus consultée qu'une annonce insuffisamment illustrée.</span>
          </a>
        </li>
        <li class="even"><span>Photos suppl.</span></li>
        <li class="odd"><span>Vidéo suppl.</span></li>  
          
          
     </ul><!-- END DESCRIPTION COLUMN -->
        
        
    <div class="pricing_hover_area"><!-- BEGIN HOVER AREA -->
    
    
        <ul class="pricing_column gradient_lightgrey"><!-- BEGIN FIRST CONTENT COLUMN -->

            <li class="pricing_header1">Particuliers</li>
           
            <li class="odd" data-table="mise à la Une"></li>
            <li class="even" data-table="mise à la une - 7 jours">5,00 &euro;</li>
            <li class="odd" data-table="mise à la une - 15 jours">7,50 &euro;</li>
            <li class="even" data-table="mise à la une - 30 jours">16,00 &euro;</li>
            <li class="odd" data-table="tête de liste"></li>
            <li class="even" data-table="tête de liste - 1 jour/semaine">1,00 &euro;</li>            
            <li class="odd" data-table="tête de liste - 7 jours">2,00 &euro;</li>
            <li class="even" data-table="tête de liste - 15 jours">4,50 &euro;</li>
            <li class="odd" data-table="tête de liste - 30 jours">8,50 &euro;</li>          
            <li class="even" data-table="urgent"></li>
            <li class="odd" data-table="urgent - 7 jours">1,50 &euro;</li>
            <li class="even" data-table="urgent - 15 jours">2,50 &euro;</li>           
            <li class="odd" data-table="urgent - 30 jours">5,00 &euro;</li>          
            <li class="even" data-table="encadré"></li>
            <li class="odd" data-table="encadré - 1 jour/semaine">1,00 &euro;</li>
            <li class="even" data-table="encadré - 7 jours">1,50 &euro;</li>
            <li class="odd" data-table="encadré - 15 jours">2,50 &euro;</li>       
            <li class="even" data-table="encadré - 30 jours">5,00 &euro;</li>
            <li class="odd" data-table="photos-vidéos"></li>      
            <li class="even" data-table="photos supp.">1,00 &euro;</li>            
            <li class="odd" data-table="vidéo supp.">2,00 &euro;</li>            
                       
        </ul><!-- END FIRST CONTENT COLUMN -->
        
    
        <ul class="pricing_column gradient_greenwanna"><!-- BEGIN SECOND CONTENT COLUMN -->

            <li class="pricing_header1">Professionnels</li>
            
            <li class="odd" data-table="mise à la Une"></li>
            <li class="even" data-table="mise à la une - 7 jours">8,00 &euro;</li>  
            <li class="odd" data-table="mise à la une - 15 jours">12,00 &euro;</li>  
            <li class="even" data-table="mise à la une - 30 jours">25,60 &euro;</li>  
            <li class="odd" data-table="tête de liste"></li> 
            <li class="even" data-table="tête de liste - 1 jour/semaine">1,60 &euro;</li>
            <li class="odd" data-table="tête de liste - 7 jours">3,20 &euro;</li>
            <li class="even" data-table="tête de liste - 15 jours">7,20 &euro;</li>
            <li class="odd" data-table="tête de liste - 30 jours">13,60 &euro;</li>  
            <li class="even" data-table="urgent"></li>
            <li class="odd" data-table="urgent - 7 jours">2,40 &euro;</li> 
            <li class="even" data-table="urgent - 15 jours">4,00 &euro;</li>            
            <li class="odd" data-table="urgent - 30 jours">8,00 &euro;</li>   
            <li class="even" data-table="encadré"></li>
            <li class="odd" data-table="encadré - 1 jour/semaine">1,60 &euro;</li> 
            <li class="even" data-table="encadré - 7 jours">2,40 &euro;</li> 
            <li class="odd" data-table="encadré - 15 jours">4,00 &euro;</li>            
            <li class="even" data-table="encadré - 30 jours">8,00 &euro;</li> 
            <li class="odd" data-table="photos-vidéos"></li>      
            <li class="even" data-table="photos supp.">1,60 &euro;</li>   
            <li class="odd" data-table="vidéo supp.">3,20 &euro;</li>        
                                
        </ul><!-- END SECOND CONTENT COLUMN -->
    
    
	</div><!-- END HOVER AREA -->

    
</div><!-- END TABLE CONTAINER -->			
			
<!-- END - Options Payantes Particuliers / Pros -->	

</div><!-- END 2ND TAB -->

 
 
 
   
<!-- BEGIN Services Packs Pros -->   

<div class="pricing_table pricing_six"><!-- BEGIN TABLE CONTAINER -->

       <ul class="pricing_column_first"><!-- BEGIN DESCRIPTION COLUMN -->


        <li class="pricing_header1" style="text-align:center;"><span>Packs Pros</span></li>
    
        <li class="even"><span>Durée de validité</span>
        	<a class="tooltipwanna" href="#">
            	<span>La durée de validité des packs est de <em>1 an</em> à compter de la date de souscription au Pack. Si à l'issue de 1 an, aucune annonce de votre plan n'a été publiée, votre pack devient inactif.</span>
            </a>
        </li>
        
        <li class="odd"><span>Annonce anonyme</span>
        	<a class="tooltipwanna" href="#">
            	<span>Vous avez la possibilité de publier une annonce de manière <em>anonyme</em> c'est-à-dire en ne diffusant ni votre pseudo, ni votre adresse e-mail et ni votre n° de téléphone. L'utilisateur intéressé peut vous contacter via la messagerie interne à l'aide d'un formulaire.</span>
            </a>
        </li>
        
        <li class="even"><span>Durée de parution</span>
        	<a class="tooltipwanna" href="#">
            	<span>La durée de parution (ou de publication) de votre annonce est limitée à <em>90 jours</em> à compter de la date de validation de celle-ci par WannAnnonces.</span>
            </a>
        </li>
        
        <li class="odd"><span>Durée d'archivage</span>
        	<a class="tooltipwanna" href="#">
            	<span>Quel que soit le plan (5, 10,..., 100 annonces) du Pack Pros auquel vous avez souscrit, une annonce <em>ne peut être archivée</em> au-delà de sa période de publication, soit <em>90 jours maximum</em>.</span>
            </a>
        </li>
                
        <li class="even"><span>En tête de liste</span>
         	<a class="tooltipwanna" href="#">
            	<span>Faites remonter votre annonce 'en tête de liste' et multiplier vos contacts. Votre annonce remonte en 'tête de liste' chaque semaine <em>le jour</em> où votre annonce a été validée par WannAnnonces. Ainsi, votre annonce remontera en 'tête de liste' soit tous les lundis, soit tous les mardis...</span>
            </a>
        </li>
        
        <li class="odd"><span>Modification</span>
         	<a class="tooltipwanna" href="#">
            	<span>Vous pouvez modifier à tout moment et de manière illimitée votre annonce durant toute sa période de parution. <u>Cas particulier</u> : si des <em>options de mise en avant</em> (payantes) sont associées à votre annonce, vous ne pouvez <em>ni les supprimer ni les modifier</em>.</span>
            </a>
        </li>
        
        <li class="even"><span>Suspension</span>
        	<a class="tooltipwanna" href="#">
            	<span>Vous pouvez suspendre à tout moment et de manière illimitée la parution (ou la publication) de votre annonce en cours de diffusion pendant une <em>période maximale de 90 jours</em>. Ce service est <em>gratuit</em>.</span>
            </a>
        </li>
        
        <li class="odd"><span>Prolongation</span>
        	<a class="tooltipwanna" href="#">
            	<span>Quel que soit le plan (5, 10,..., 100 annonces) du Pack Pros auquel vous avez souscrit, une annonce <em>ne peut être prolongée</em> au-delà de sa période de publication, soit <em>90 jours maximum</em>.</span>
            </a>
        </li>
        
        <li class="even"><span>10 photos/annonce</span>
        	<a class="tooltipwanna" href="#">
            	<span>Possibilité de publier jusqu'à <em>10 photos</em> par annonce.</span>
            </a>
        </li>
        
         <li class="odd"><span>2 vidéos/annonce</span>
        	<a class="tooltipwanna" href="#">
            	<span>Possibilité de publier jusqu'à <em>2 vidéos</em> par annonce.</span>
            </a>
        </li>
        
        <li class="even"><span>Gesion multi-plans</span>
        	<a class="tooltipwanna" href="#">
            	<span>Possibilité de gérer <em>simultanément</em> différents plans (5, 10,..., 100 annonces) à l'intérieur d'un même Pack Pros.</span>
            </a>
        </li>
        
        <li class="odd"><span>Options de mise en avant</span>
        	<a class="tooltipwanna" href="#">
            	<span>Possibilité d'associer des options de mise en avant (payantes) à votre annonce.</span>
            </a>
        </li>
        
        <li class="even"><span>Statistiques de visite</span>
        	<a class="tooltipwanna" href="#">
            	<span>Statistique du nombre cumulé de visites. Possibilité de ré-initialiser le compteur de visites pour une observation de l'audience sur une période donnée.</span>
            </a>
        </li>
        
        <li class="odd"><span>Prix dégressifs</span>
        	<a class="tooltipwanna" href="#">
            	<span>Les prix des plans sont <em>dégressifs</em> pour tous les Packs Pros. Plus vous achetez des annonces plus vous êtes gagnant !.</span>
            </a>
        </li>
        
        <li class="even"><span>Frais d'insertion : 0 &euro; </span>
        	<a class="tooltipwanna" href="#">
            	<span>Aucun frais d'insertion n'est prélevé par WannAnnonces lors de la publication d'une annonce.</span>
            </a>
        </li>
        
        <li class="odd"><span>Commissions : 0 &euro;</span>
        	<a class="tooltipwanna" href="#">
            	<span>Aucune commission n'est prélévée par WannAnnonces à la souscription d'un plan d'un Pack Pros.</span>
            </a>
        </li>
       
        <li class="even"><span>Paiement Paypal</span>
        	<a class="tooltipwanna" href="#">
            	<span>Le paiement est réalisé à travers la plate-forme sécurisée Paypal.</span>
            </a>
        </li>
       
          
    </ul><!-- END DESCRIPTION COLUMN | Packs Pros -->

    
    <div class="pricing_hover_area"><!-- BEGIN HOVER AREA -->
    
    
        <ul class="pricing_column gradient_blue"><!-- BEGIN FIRST CONTENT COLUMN -->

            <li class="pricing_header1 ">WannImmo</li>
      
            <li class="even" data-table="durée de validité">1 an</li>
            <li class="odd" data-table="annonce anonyme"><span class="pricing_yes"></li>
            <li class="even" data-table="durée de parution"><span>90 jours</span></li>
            <li class="odd" data-table="durée d'archivage"><span class="pricing_no"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_yes"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_no"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_yes"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_yes"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_yes"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_yes"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
                           
        </ul><!-- END FIRST CONTENT COLUMN -->
        
    
        <ul class="pricing_column gradient_green"><!-- BEGIN SECOND CONTENT COLUMN -->

            <li class="pricing_header1 ">WannAuto</li>

            <li class="even" data-table="durée de validité">1 an</li>
            <li class="odd" data-table="annonce anonyme"><span class="pricing_yes"></li>
            <li class="even" data-table="durée de parution"><span>90 jours</span></li>
            <li class="odd" data-table="durée d'archivage"><span class="pricing_no"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_yes"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_no"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_yes"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_yes"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_yes"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_yes"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
           
                  
        </ul><!-- END SECOND CONTENT COLUMN -->
    

        <ul class="pricing_column gradient_yellow"><!-- BEGIN THIRD CONTENT COLUMN -->

            <li class="pricing_header1">WannMoto</li>
         
            <li class="even" data-table="durée de validité">1 an</li>
            <li class="odd" data-table="annonce anonyme"><span class="pricing_yes"></li>
            <li class="even" data-table="durée de parution"><span>90 jours</span></li>
            <li class="odd" data-table="durée d'archivage"><span class="pricing_no"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_yes"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_no"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_yes"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_yes"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_yes"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_yes"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
                  
               
        </ul><!-- END THIRD CONTENT COLUMN -->
    

        <ul class="pricing_column gradient_orange"><!-- BEGIN FOURTH CONTENT COLUMN -->

            <li class="pricing_header1">WannEmploi</li>
           
            <li class="even" data-table="durée de validité">1 an</li>
            <li class="odd" data-table="annonce anonyme"><span class="pricing_yes"></li>
            <li class="even" data-table="durée de parution"><span>90 jours</span></li>
            <li class="odd" data-table="durée d'archivage"><span class="pricing_no"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_yes"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_no"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_yes"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_yes"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_yes"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_yes"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
                  
            
        </ul><!-- END FOURTH CONTENT COLUMN -->
    

        <ul class="pricing_column gradient_red"><!-- BEGIN FIFTH CONTENT COLUMN -->

            <li class="pricing_header1">WannServices</li>
            
            <li class="even" data-table="durée de validité">1 an</li>
            <li class="odd" data-table="annonce anonyme"><span class="pricing_yes"></li>
            <li class="even" data-table="durée de parution"><span>90 jours</span></li>
            <li class="odd" data-table="durée d'archivage"><span class="pricing_no"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_yes"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_no"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_yes"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_yes"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_yes"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
            <li class="odd" data-table=""><span class="pricing_yes"></li>
            <li class="even" data-table=""><span class="pricing_yes"></li>
    
                       
        </ul><!-- END FIFTH CONTENT COLUMN -->
    
    
	</div><!-- END HOVER AREA -->

    
</div><!-- END TABLE CONTAINER -->

<!-- End Pricing Tables-->	   
   
<!-- END Services Packs Pros -->     

 
 
 

<!-- BEGIN Pricing Tables | Packs Pros -->

<div class="pricing_table pricing_six"><!-- BEGIN TABLE CONTAINER -->

       <ul class="pricing_column_first"><!-- BEGIN DESCRIPTION COLUMN -->


        <li class="pricing_header1" style="text-align:center;"><span>Tarifs Packs Pros</span></li>
    
        <li class="odd"><span>Plan 5</span>
        	<a class="tooltipwanna" href="#">
            	<span>Ce plan comprend 5 annonces.</span>
            </a>
        </li>
        
         <li class="even"><span>Plan 10</span>
        	<a class="tooltipwanna" href="#">
            	<span>Ce plan comprend 10 annonces.</span>
            </a>
        </li>
        
        <li class="odd"><span>Plan 25</span>
         	<a class="tooltipwanna" href="#">
            	<span>Ce plan comprend 25 annonces.</span>
            </a>
        </li>
        
        <li class="even"><span>Plan 50</span>
         	<a class="tooltipwanna" href="#">
            	<span>Ce plan comprend 50 annonces.</span>
            </a>
        </li>
        
        <li class="odd"><span>Plan 75</span>
        	<a class="tooltipwanna" href="#">
            	<span>Ce plan comprend 75 annonces.</span>
            </a>
        </li>
        
        <li class="even"><span>Plan 100</span>
        	<a class="tooltipwanna" href="#">
            	<span>Ce plan comprend 100 annonces.</span>
            </a>
        </li>
            
          
    </ul><!-- END DESCRIPTION COLUMN | Packs Pros -->

    
    <div class="pricing_hover_area"><!-- BEGIN HOVER AREA -->
    
    
        <ul class="pricing_column gradient_blue"><!-- BEGIN FIRST CONTENT COLUMN -->

            <li class="pricing_header1">WannImmo</li>
      
            <li class="odd" data-table="">29,00 &euro;</li>
            <li class="even" data-table="">58,00 &euro;</li>
            <li class="odd" data-table="">132,00 &euro;</li>
            <li class="even" data-table="">250,00 &euro;</li>
            <li class="odd" data-table="">354,00 &euro;</li>
            <li class="even" data-table="">447,00 &euro;</li>
                              
        </ul><!-- END FIRST CONTENT COLUMN -->
        
    
        <ul class="pricing_column gradient_green"><!-- BEGIN SECOND CONTENT COLUMN -->

            <li class="pricing_header1">WannAuto</li>

            <li class="odd" data-table="">27,00 &euro;</li>
            <li class="even" data-table="">55,00 &euro;</li>
            <li class="odd" data-table="">125,00 &euro;</li>
            <li class="even" data-table="">235,00 &euro;</li>
            <li class="odd" data-table="">333,00 &euro;</li>
            <li class="even" data-table="">421,00 &euro;</li>
           
                  
        </ul><!-- END SECOND CONTENT COLUMN -->
    

        <ul class="pricing_column gradient_yellow"><!-- BEGIN THIRD CONTENT COLUMN -->

            <li class="pricing_header1">WannMoto</li>
         
            <li class="odd" data-table="">27,00 &euro;</li>
            <li class="even" data-table="">55,00 &euro;</li>
            <li class="odd" data-table="">125,00 &euro;</li>
            <li class="even" data-table="">235,00 &euro;</li>
            <li class="odd" data-table="">333,00 &euro;</li>
            <li class="even" data-table="">421,00 &euro;</li>
                  
               
        </ul><!-- END THIRD CONTENT COLUMN -->
    

        <ul class="pricing_column gradient_orange"><!-- BEGIN FOURTH CONTENT COLUMN -->

            <li class="pricing_header1">WannEmploi</li>
           
            <li class="odd" data-table="">29,00 &euro;</li>
            <li class="even" data-table="">58,00 &euro;</li>
            <li class="odd" data-table="">132,00 &euro;</li>
            <li class="even" data-table="">250,00 &euro;</li>
            <li class="odd" data-table="">354,00 &euro;</li>
            <li class="even" data-table="">447,00 &euro;</li>
            
           
            
        </ul><!-- END FOURTH CONTENT COLUMN -->
    

        <ul class="pricing_column gradient_red"><!-- BEGIN FIFTH CONTENT COLUMN -->

            <li class="pricing_header1">WannServices</li>
            

            <li class="odd" data-table="">24,00 &euro;</li>
            <li class="even" data-table="">48,00 &euro;</li>
            <li class="odd" data-table="">109,00 &euro;</li>
            <li class="even" data-table="">205,00 &euro;</li>
            <li class="odd" data-table="">291,00 &euro;</li>
            <li class="even" data-table="">368,00 &euro;</li>
    
                       
        </ul><!-- END FIFTH CONTENT COLUMN -->
    
    
	</div><!-- END HOVER AREA -->

    
</div><!-- END TABLE CONTAINER -->

<!-- End Pricing Tables-->	   
					 
					<div class="clearer"></div>

          <div class="final-text">
					<strong>Date de derni&egrave;re mise à jour : </strong>07 D&eacute;cembre 2013 - rev 1.0</strong>
					</div>


			<div class="clearer"></div>

		</div>


    <!-- add FOOTER -->
    <?php include_once("footer.php"); ?>    
    <!-- END FOOTER -->

    


	</div>
</div>

   <!-- Jquery  & plug-in -->
  <script type="text/javascript" src="lib/jquery-1.4.4.min.js"></script> 
  <script type="text/javascript" src="lib/jquery-ui.min.js"></script> 
  <script type="text/javascript" src="lib/patmisc.postload.lib.min.js"></script> 

    <!-- LANGUAGE File (MASTER) -->
  <script type="text/javascript" src="lang/<?php echo str_replace('_','-',$cust_lang_long); ?>.js"></script>

  <!-- LANGUAGE File (CUSTOM) - COMING ON TOP OF EXISTING ONE -->
  <?php if (isset($THEME_CUST_LANG_URL) && $THEME_CUST_LANG_URL!="") { ?> 
    <script type="text/javascript" src="<?php echo $THEME_CUST_LANG_URL.str_replace('_','-',$cust_lang_long); ?>.js"></script>
  <?php }?>

  <!-- Core feature of ZADS ESSENTIAL STATIC PAGES  --> 
  <script type="text/javascript" src="js/zads-static-page.js"></script> 


</body>
</html>
