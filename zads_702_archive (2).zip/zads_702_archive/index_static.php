<?php

if (strpos($_SERVER['REQUEST_URI'],'zads60/') !== false){
	define("BASE_PATH", '/zads60/');
} else define("BASE_PATH", '/');

define("URI_MODE", 'static');  

// ----- INIT ESSENTIAL SETTINGS =  LANGUAGE  ----// 
include_once "./phpsvr/init_settings.php";

// ----- HTML SNAPSHOT FOR SEO   ----// 
include_once "./phpsvr/html_snapshot_lib.php"; 

// step 1 =  decode the URI 
// echo $_SERVER['REQUEST_URI'];
// echo '<br>';
$r= parse_request_uri();
// var_dump($r);

// step 2 = display the stupid page 
display_html_version($r);


?>