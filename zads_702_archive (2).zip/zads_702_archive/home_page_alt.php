<?php
echo "<h1>home_page_alt.php</h1>" ; 
echo "enter in this PHP page the text and php code you want here the code you want" ; 
?>