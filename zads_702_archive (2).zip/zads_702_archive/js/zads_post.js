/******************************************************************************
 * ZADS MAIN JS script
 * @category   SECONDARY PACKAGE (can be loaded asynchonously) - ADMIN functions essentialy 
 * @package    ZADS
 * @author     Patrice COHAUT <patrice.cohaut@gmail.com>
 * @copyright  2016 PATMISC
 * @version    7.1.5
 ******************************************************************************/

/**-----------------------------------------------------------------------------
* GLOBAL VARIABLES  
*-----------------------------------------------------------------------------*/  

var options_nbqty= new Array() ; 
for (var i = 1; i < 13; i++) {
    options_nbqty.push({ name : ''+i+'', value : ''+i+''});   
};

var bannerform = {
         // the  Main form as displayed when creating of modifying an article   
         form1 : [
        
            // {name: 'type', type : 'radio', mandatory :'yes', regx:'',  linkedobj : options_a , size : '' , desc :'ad sell or buy',help :'',  checked: 'no', default_val :'', dbfilter:'no', jobj:'' },
            {name: 'title', type : 'input', mandatory :'yes', regx:'', size : '60' , desc :'desc_banner_title', help :'help_banner_title',  checked: 'no', default_val :''},
            {name: 'htmlcode', type : 'textarea', mandatory :'yes', regx:'', size : '70', rowssize : '4', maxchar : '1500' , desc :'desc_banner_htmlcode', help :'help_banner_htmlcode', default_val :''},
            {name: 'banimgurl', type : 'uploadwithprogress', onlycreation:'yes' ,  maximg:1 , desc :'*', help :'*', default_val :''},
            {name: 'clicktrackingurl', type : 'input', mandatory :'', regx:URLREG, size : '60' , desc :'desc_banner_clicktrackingurl', help :'help_banner_clicktrackingurl',  checked: 'no', default_val :'' },
            {name: 'startdate', accesslevel:'9', type : 'input', subtype:'datetime', mandatory :'yes', size : '20' ,regx:DATEREG,  desc :'desc_banner_startdate', postlabel:'', help :'help_banner_startdate', checked: 'no', default_val :'today'},       
            {name: 'enddate', accesslevel:'9', type : 'input', subtype:'datetime', mandatory :'yes', size : '20' ,regx:DATEREG,  desc :'desc_banner_enddate', postlabel:'', help :'help_banner_enddate', checked: 'no', default_val :'today+30' },       
            {name: 'position', accesslevel:'9', type : 'select', linkedobj : banner_position_options , mandatory :'yes', regx:'',  desc :'desc_banner_position', postlabel:'', help :'help_banner_position', checked: 'no', default_val :'' },

            {name: 'status', type : 'span', onlymodify:'yes' , size : '' , desc :'ad status', postlabel:'', help :'' },
            //{name: 'priority', accesslevel:'9', type : 'select', linkedobj : priority_options , mandatory :'', regx:'',  desc :'ad priority', postlabel:'', help :'', checked: 'no', default_val :'', dbfilter:'no', jobj:'' },
            {name: 'moddate', accesslevel:'1', type : 'span-hidden', mandatory :'', onlymodify:'yes' , size : '20' ,regx:DATEREG,  desc :'ad pub date', postlabel:'', help :'' },
            {name: 'moddate', accesslevel:'5', type : 'span-hidden', mandatory :'', onlymodify:'yes' , size : '20' ,regx:DATEREG,  desc :'ad pub date', postlabel:'', help :''},        
            {name: 'moddate', accesslevel:'9', type : 'input', subtype:'datetime', mandatory :'', onlymodify:'yes' , size : '20' ,regx:DATEREG,  desc :'ad pub date', postlabel:'', help :'' },       
            //{name: 'logs', type : 'span', onlymodify:'yes' , accesslevel:'9', size : '' , desc :'ad logs', postlabel:'', help :'', checked: 'no', default_val :'', dbfilter:'no', jobj:'' },
            {name: 'clicks', type : 'span', onlymodify:'yes' , size : '' , desc :'desc_banner_clicks', postlabel:'clicks', help :'help_banner_clicks' },  
            {name: 'impressions', type : 'span', onlymodify:'yes' , size : '' , desc :'desc_banner_impressions', postlabel:'impressions', help :'help_banner_impressions'  }  

          ]
    };

// add the "select all" 
var banner_position_filter_options = banner_position_options;
banner_position_filter_options.unshift({ name : '-- all positions --', value : '', style:''});

var bookingform = {
         // the  Main form as displayed when creating of modifying an article   
         form1 : [
          {name: 'label2', type : 'label', desc :'booking details'},
            {name: 'bo_ad_id', type : 'input', mandatory :'yes', regx:'', size : '40' , desc :'*', help :'*',  checked: 'no', default_val :''},
            {name: 'bo_title', type : 'input', mandatory :'yes', regx:'', size : '40' , desc :'*', help :'*',  checked: 'no', default_val :''},
            {name: 'bo_start_end_date', field1:'bo_start_date', field2:'bo_end_date', type : 'date-double', subtype:'date', mandatory :'yes', size : '20' ,  desc :'*', postlabel:'', help :'', checked: 'no', default_val1 :'today'},       
            {name: 'bo_nbadults',  type : 'select', mandatory :'yes',  linkedobj : options_nbqty , desc :'*', postlabel:'', help :'', checked: 'no', default_val :'1'},       
          {name: 'label2', type : 'label', desc :'booking user details'},
             {name: 'bo_gender', type : 'radio',  regx:'',  linkedobj : options_gender , size : '' , desc :'*',help :'',  checked: 'no', default_val :''  },
             {name: 'bo_firstname', type : 'input',  regx:'', size : '30' , desc :'firstname', help :'',  checked: 'no', default_val :''  },
             {name: 'bo_lastname', type : 'input',  regx:'', size : '30' , desc :'lastname', help :'',  checked: 'no', default_val :''  },
             {name: 'bo_email', type : 'input', subtype:'email' , regx:EMAILREG , size : '40', maxsize:'60', desc :'user email',  help :'help email rules', checked: 'no', default_val :''  },
             {name: 'bo_location', type : 'input', regx:'GEOLOCATION' , size : '40', maxsize:'100' , desc :'user location', postmenu:'loc' , help :'help indicate for example a zip code or town', checked: 'no', default_val :''  },
             {name: 'bo_comments', type : 'textarea',regx:'', rowssize:'2', size : '70', maxchar : '250' , desc :'*', help :'', checked: 'no', default_val :''  },
          {name: 'label2', type : 'label', desc :'booking other details', onlymodify:'yes' ,accesslevel:'9'},
            {name: 'bo_moddate', accesslevel:'1', type : 'span-hidden', mandatory :'', onlymodify:'yes' , size : '20' ,regx:DATEREG,  desc :'*', postlabel:'', help :'' },
            {name: 'bo_moddate', accesslevel:'5', type : 'span-hidden', mandatory :'', onlymodify:'yes' , size : '20' ,regx:DATEREG,  desc :'*', postlabel:'', help :''},        
            {name: 'bo_moddate', accesslevel:'9', type : 'input', subtype:'datetime', mandatory :'', onlymodify:'yes' , size : '20' ,regx:DATEREG,  desc :'*', postlabel:'', help :'' },       
            {name: 'userid', type : 'input',  accesslevel:'9', onlymodify:'yes', mandatory :'yes', regx:'', size : '4' , desc :'userid', postlabel:'id of article owner', help :'',  checked: 'yes', default_val :''  },
            {name: 'status', type : 'span', onlymodify:'yes' , size : '' , desc :'ad status', postlabel:'', help :'' }

          ]
    };


  // 6.9.0 arrays for various usages including settings 
  var gen_select_options = {

    coms_ad_type: [
      { name : '-- disabled --', value : '', checked: 'checked'},
      { name : 'comment', value : 'comment'},
      { name : 'review', value : 'review'}
    ]

    ,coms_user_type: [
      { name : '-- disabled --', value : '', checked: 'checked'},
      { name : 'comment', value : 'comment'},
      { name : 'review', value : 'review'}
    ]
    , coms_type : [
      { name : '-- all type --', value : '', checked: 'checked'},
      { name : 'comment', value : 'comment'},
      { name : 'review', value : 'review'}
    ]
    , coms_rating_visual: [
      { name : 'stars', value : 'stars'},
      { name : 'positive/neutral/negative', value : 'pnn'}
    ]

   , userdetails_only_for: [
      { name : '-- all users --', value : ''},
      { name : 'registered', value : 'registered'}
    ]
    , adv_search_location : [
      { name : '-- none --', value : ''}
      ,{ name : 'locdept', value : 'locdept'}
      ,{ name : 'locregion', value : 'locregion'}
    ]

    , locale_location_list_mode  : [
      { name : '-- none --', value : ''}
      ,{ name : 'jsonplussql', value : 'jsonplussql'}
      ,{ name : 'json', value : 'json'}
      ,{ name : 'sql', value : 'sql'}
    ]

     , calendar_for_protype  : [
      { name : 'all ads', value : 'all'}
      ,{ name : 'protype_par', value : 'par'}
      ,{ name : 'protype_pro', value : 'pro'}
    ]

     , locale_ad_for  : [
      { name : 'all ads', value : 'all'}
      ,{ name : 'protype_par', value : 'par'}
      ,{ name : 'protype_pro', value : 'pro'}
    ]

     , ad_expiration_for  : [
      { name : 'all ads', value : 'all'}
      ,{ name : 'protype_par', value : 'par'}
      ,{ name : 'protype_pro', value : 'pro'}
      ,{ name : 'protype_nobody', value : 'none'}
    ]

     , your_subscription  : [
      { name : 'DEMO', value : 'DEMO 5 Days'}
      ,{ name : 'CLOUD-300', value : 'CLOUD-300'}
      ,{ name : 'CLOUD-500', value : 'CLOUD-500'}
      ,{ name : 'CHEZ-VOUS', value : 'CHEZ-VOUS'}
    ]
    , advs_type_mode: [
      { name : 'do not display', value : 'none'}
      ,{ name : 'all ad types', value : 'allad'}
      ,{ name : 'all ad types default sell', value : 'allad_default_sell'}
    ]

    ,list_default_view  : [
        { name : 'list', value : 'list'}
      ,{ name : 'simplelist', value : 'simplelist'}
      ,{ name : 'gallery', value : 'gallery'}
      ,{ name : 'videogallery', value : 'videogallery'}
      ,{ name : 'audiogallery', value : 'audiogallery'}
      ,{ name : 'maplist', value : 'maplist'}
    ]
    , advs_cityzip_mode : [
        { name : 'gmap', value : 'Google Map API'}
    ]

  };

  var subscribers_filter_status_obj =  new Array (
      { name : '-- all status --', value : '', checked: 'checked'},
      { name : 'registration pending', value : '20'},
      { name : 'registered', value : '40'}
  ); 

  var services_filter_status_obj =  new Array (
      { name : '-- services all status --', value : '', checked: 'checked'},
      { name : 'services pending payments', value : '15'},
      { name : 'services active', value : '40'},
      { name : 'services expired', value : '80'}
  ); 


  var list_elements_per_page_obj =  new Array (
      { name : '-- unlimited --', value : ''},
      { name : '20', value : '20', checked: 'checked'},
      { name : '50', value : '50'},
      { name : '100', value : '100'}
  ); 


  var catpricetype_opts =  new Array (
      { name : 'pricetype default', value : '',checked: 'checked'},
      { name : 'no price', value : 'nopr'}
  ); 

  //Z6.5.6 - general options for admin settings for all variables which are managed through select 

  var settings_opts = {
    watermark_pos : [
        { name : 'watermark_pos_topright', value : 'topright'}
        ,{ name : 'watermark_pos_topleft', value : 'topleft'}
        ,{ name : 'watermark_pos_bottomright', value : 'bottomright'}
        ,{ name : 'watermark_pos_bottomleft', value : 'bottomleft'}
    ]
  }
  
  // Z6.1.4
  var filter_protype = new Array (
    { name : '-- all protype --', value : ''},
    { name : 'par', value : 'par', id :'', style:'', checked: ''}, 
    { name : 'pro', value : 'pro', id :'', style:'', checked: ''}      
  ); 

  var vfield_domtype_options = new Array (
      { name : 'input', value : 'input', checked: 'checked'},
      { name : 'radio', value : 'radio'},
      { name : 'checkbox', value : 'checkbox'},
      { name : 'select', value : 'select'},
      { name : 'select autofill', value : 'selectauto'}
  ); 


  var vfield_domsubtype_options = new Array (
      { name : 'various', value : 'various', checked: 'checked'},
      { name : 'integer', value : 'integer'},
      { name : 'year', value : 'year'}
  ); 

  var vfield_forwhat_options = new Array (
      { name : 'all', value : '', checked: 'checked'},
      { name : 'ad', value : 'ad'},
      { name : 'user', value : 'user'}
  ); 
  var vfield_filter_forwhat_options = new Array (
      { name : 'all', value : '', checked: 'checked'},
      { name : 'ad', value : 'ad'},
      { name : 'user', value : 'user'}
  ); 

  var vfield_scope_options = new Array (
      { name : 'category', value : 'cat', checked: 'checked'},
      { name : 'search', value : 'search'}
  ); 

  var vfield_filter_scope_options = new Array (
      { name : 'all', value : '', checked: 'checked'},
      { name : 'category', value : 'cat'},
      { name : 'search', value : 'search'}
  ); 

  var vfield_stype_options= new Array (
      { name : 'equal', value : '', checked: 'checked'},
      { name : 'min', value : 'min', checked: 'checked'},
      { name : 'max', value : 'max', checked: 'checked'}
  ); 

  var linked_vfield_list = vfield_list;


  var vfieldform = {
       // the  Main form as displayed when creating of modifying an article   
       form1 : [
          // {name: 'type', type : 'radio', mandatory :'yes', regx:'',  linkedobj : options_a , size : '' , desc :'ad sell or buy',help :'',  checked: 'no', default_val :'', dbfilter:'no', jobj:'' },
          {name: 'scope', type : 'radio', mandatory :'', regx:'', linkedobj : vfield_scope_options , desc :'*',help :'*',  checked: 'no', default_val :'' },
          {name: 'int_label', type : 'input', mandatory :'yes', regx:'', size : '60' , desc :'*', help :'*',  checked: 'no', default_val :'' },
          {name: 'disp_label', type : 'input', mandatory :'yes', regx:'', size : '60' , desc :'*', help :'*',  checked: 'no', default_val :''},
          {name: 'linkedvfield',  type : 'select',   linkedobj : linked_vfield_list , forcedwhat:'cat', mandatory :'', regx:'', size : '' , desc :'*', help :'*',  checked: 'no', default_val :'' },
          {name: 'stype', accesslevel:'9', type : 'select', linkedobj : vfield_stype_options , mandatory :'', regx:'',  size : '' , desc :'*', postlabel:'', help :'*', checked: 'no', default_val :''},
          {name: 'forwhat', type : 'radio', mandatory :'',  regx:'', linkedobj : vfield_forwhat_options , desc :'*',help :'*',   default_val :'' },
          {name: 'domtype', accesslevel:'9', type : 'select', linkedobj : vfield_domtype_options , mandatory :'yes', regx:'', size : '' , desc :'*', postlabel:'', help :'*', checked: 'no', default_val :''},
          {name: 'domsubtype', accesslevel:'9', type : 'select', linkedobj : vfield_domsubtype_options , mandatory :'', regx:'',  size : '' , desc :'*', postlabel:'', help :'*', checked: 'no', default_val :''},
          {name: 'unit', type : 'input', mandatory :'', regx:'', size : '10' , desc :'*', help :'*', default_val :''},
          {name: 'linkedvar', type : 'input', mandatory :'', regx:'', size : '10' , desc :'*', help :'*', default_val :''},
          {name: 'slaveid', type : 'input', mandatory :'', regx:'', size : '10' , desc :'*', help :'*', default_val :''},
          // {name: 'slaveid', type : 'select',   linkedobj : linked_vfield_list , forcedwhat:'all', mandatory :'', regx:'', size : '10' , desc :'*', help :'*', default_val :''},

          {name: 'values', type : 'multi-inputs',   max:100 ,  size : '40', maxsize:'200' , desc :'*', postmenu:'' , help :'', checked: 'no', default_val :''},
          {name: 'moddate', accesslevel:'1', type : 'span-hidden', mandatory :'', onlymodify:'yes' , size : '20' ,regx:DATEREG,  desc :'ad pub date', postlabel:'', help :''  },
          {name: 'moddate', accesslevel:'5', type : 'span-hidden', mandatory :'', onlymodify:'yes' , size : '20' ,regx:DATEREG,  desc :'ad pub date', postlabel:'', help :'' },        
          {name: 'moddate', accesslevel:'9', type : 'input', subtype:'datetime', mandatory :'', onlymodify:'yes' , size : '20' ,regx:DATEREG,  desc :'ad pub date', postlabel:'', help :'' }     
        ]
  };


  //Z7.0
  var cat_protype_options=new Array (
       { name : 'all', value : '', id :'', style:'', checked: 'checked'} 
      ,{ name : 'par', value : 'par', id :'', style:'', checked: ''}
      ,{ name : 'pro', value : 'pro', id :'', style:'', checked: ''}      
  ); 

  var catform = {
       // the  Main form as displayed when rceating of modifying an article   
       form1 : [
          {name: 'title', type : 'input', mandatory :'yes', regx:'', size : '60' , desc :'cat title', help :'help cat title',  checked: 'no', default_val :''  },
          {name: 'type', type : 'radio', linkedobj : cattype_a , size : '' , desc :'desc cat type', help :'', default_val :'' },
          {name: 'protype', type : 'radio',  linkedobj : cat_protype_options  , size : '' , desc :'*', help :'help cat protype', default_val :'' },
          {name: 'adultflag', type : 'checkbox',  desc :'*', help :'*', default_val :'' },
          // Z701 - to manage special comments on categories 
          {name: 'adulttext', type : 'input', size : '20' , desc :'*', help :'*', default_val :''  },
          {name: 'hascalendar', type : 'checkbox',  desc :'*', help :'*', default_val :'' },
          {name: 'pricetype',type : 'radio',  linkedobj : catpricetype_opts ,   desc :'cat pricetype', help :'help cat pricetype', default_val :'' },
          {name: 'desc', type : 'textarea', mandatory :'yes', regx:'', size : '60' , rowssize:'3' , maxchar : '900' ,desc :'cat description', help :'', checked: 'no', default_val :''  },
          
          // new zads 4.8        
          {name: 'metatitle', type : 'input', mandatory :'', regx:'', size : '60' , desc :'*', help :'*',  checked: 'no', default_val :''  },
          {name: 'metadesc', type : 'textarea', mandatory :'', regx:'', maxchar : '160', rowssize:'2' , size : '60' , desc :'*', help :'*',  checked: 'no', default_val :''  },
          {name: 'metakey', type : 'textarea', mandatory :'', regx:'', maxchar : '160',  rowssize:'2' , size : '60' , desc :'*', help :'*',  checked: 'no', default_val :''  },

          // new zads 4.8        
          {name: 'parentid', type : 'select', mandatory :'', type2 :'1',  regx:'', linkedobj : cat_options , size : '' , desc :'*', help :'*', checked: 'no', default_val :''  },
          {name: 'filename', type : 'uploadwithprogress', maximg:1, mandatory :'', regx:'', desc :'cat upload picture', help :'cat upload image help'},
          // new zads 5.5
          {name: 'catlvfields', type : 'multi-inputs',   max:30 ,  size : '40', maxsize:'200' , desc :'*', postmenu:'' , help :'', checked: 'no', default_val :''},
          // new zads 4.8   
          {name: 'label2', type : 'label', onlymodify:'yes', mandatory :'', regx:'', desc :'publishing state', postlabel:'Publication status', help :''},
          {name: 'status', type : 'span', onlymodify:'yes' , size : '' , desc :'ad status', postlabel:'', help :'', checked: 'no', default_val :''  },
          {name: 'moddate', type : 'input', subtype:'datetime', mandatory :'', onlymodify:'yes' , size : '20' ,regx:'',  desc :'ad pub date', postlabel:'', help :'', checked: 'no', default_val :''  }
        ],
         // the form displayed when DISPLAYING the article
        form_disp : [
          {name: 'title', type : 'input', mandatory :'yes', regx:'', size : '60' , desc :'ad title', help :'do not indicate buy of sell',  checked: 'no', default_val :''  },
          {name: 'pics', type : 'upload',  maximg:1 , mandatory :'', regx:'', desc :'ad upload picture'},
          {name: 'desc', type : 'textarea', mandatory :'yes', regx:'', size : '70' , desc :'ad description', help :'', checked: 'no', default_val :''  }
        ], 
        
        form_disp_panel_misc : [    
          {name: 'moddate', displayicon:'yes', icon: 'time' , type : 'input', mandatory :'', regx:'', size : '6' , desc :'ad date', postlabel:'', help :'', checked: 'no', default_val :''  }
        ], 
        
        form_disp_panel_desc: [
          {name: 'desc', type : 'textarea', mandatory :'yes', regx:'', size : '70' , desc :'ad description', help :'', checked: 'no', default_val :''  } ,  
          {name: 'type', type : 'radio', linkedobj : cattype_a ,  desc :'desc cat type', help :'' },
          {name: 'pricetype', type : 'radio', linkedobj : catpricetype_opts ,  desc :'*', help :'' }
        ], 
        
        form_disp_panel_info : [
          {name: 'status', type : 'span', onlymodify:'yes' , size : '' , desc :'ad status', postlabel:'', help :'', checked: 'no', default_val :''  },
          {name: 'edit', action : 'yes',displayicon:'yes', icon: 'edit', desc :'ad edit', postlabel:'', help :'', checked: 'no', default_val :''  },
          {name: 'delete', action : 'yes',displayicon:'yes', icon: 'trash-o', desc :'ad delete', postlabel:'', help :'', checked: 'no', default_val :''  } 
        ]    
  };



  function gen_grab_all_filters(jqselector){
  var fql=""; 
  var filterzone =  $(jqselector); 
  // loop though each filter to get the exact AJAX PARAM 
  // SELECT 
  filterzone.find('ul > select').each(function(idx,elem){
      filtername = $(this).attr('id');
      selelem = $(this).find("option:selected"); 
      fql+="&"+filtername+"="+selelem.val();
  }); 

  // INPUT
  filterzone.find('ul > input').each(function(idx,elem){
      filtername = $(this).attr('id');
      if ($(this).attr('type')=='text') selelem= $(this).val();  // input text
      else selelem = $(this).is(':checked') ? $(this).val() : ""; // check box
      fql+="&"+filtername+"="+selelem;
  }); 

  return fql; 
}


/**-----------------------------------------------------------------------------
* This function count the number of Vfileds
* @param  {obj} data - the JSON object containing the data (data) and options from RX
* @param  {string} scope - if need to filter something cased on scope or not 
*-----------------------------------------------------------------------------*/  
function count_vfields(data, scope){
  var c=0; 
  var sa = data.split('|'); 
  for(var i = 0; i < sa.length; i++) {
    // { name : 'input', value : 'input', checked: 'checked'},
    ekey=sa[i].split(';')[0]; // object
    if (ekey) {
        if (scope){
          rs =  JSON_find_elem_byID(vfields_list,ekey).scope ; 
          if (rs==scope) c+=1; 
        } else c+=1; 
    }
  }
    return c ; 
}


/**-----------------------------------------------------------------------------
* This function convert a vfieldelemnt (json) into its HTML representation 
* @param  {obj} data - the JSON object containing the data (data) and options from RX
* @param  {string} context - specify various formating {empty}| withlabel | withlabelequaltitle
* @param  {string} value - the default value to display 
* @param  {string} scope - if need to filter something cased on scope or not 
*-----------------------------------------------------------------------------*/  
function vield_2_html(data,context,value, scope){

  var t='', noLabel=false;
  var dv=''; if (value) dv=value; // dv =defualt value or modified value 
  var isRequired =  (display_settings.vfields_mandatory) ?  true : false; 


  if (scope && data.scope!=scope) return t; // premature exit
  else {

    if (scope && scope=="search") {
      npx = "f_";
      idx = data.linkedvfield ; // take the IDof the Vfield 
      if (data.stype=="min" || data.stype=="max"){
        idx = data.stype+'-'+idx ; // add the type to the identifier to inform it's a min or max 
      }
    }
    else {
      npx = "cat_"; // precise the name to be sent 
      idx = data.id ; 
    }

    var vfield_html_name =  npx+'vfields['+idx+']'; 
  
    var xattr= (isRequired ) ? ' data-required="true" required ' : " "; 

    if (data.domtype=="input"){
      t +=  '<input name="'+vfield_html_name+'" id="'+vfield_html_name+'" data-id="'+data.id+'" localregexp="" mandatory="" size="10" type="text" class="text preview" value="'+dv+'" placeholder="'+data.disp_label+'"  '+xattr+' ></input>';
    }
    if (data.domtype=="select" || data.domtype=="selectauto"){

      
      // zads 7.4.0 - automated linked vars
      if (data.linkedvar!='' && data.domtype!="selectauto" )
        xattr +=' data-ajaxupdate="yes" data-ajaxkey="'+data.linkedvar+'" ';

      if (data.domtype=="selectauto"){
         xattr +=' disabled ';
      }

      t +=  '<select name="'+vfield_html_name+'" id="'+vfield_html_name+'" data-id="'+data.id+'" data-scope="'+data.scope+'" '+xattr+'>';
      
      var firstvalue = true ; 
      if (context=="withlabelequaltitle") {
        noLabel = true; 
        firstvalue  = data.disp_label ; 
      }

      if (data.domtype=="select" ) t +=  build_DOM_SELECT_options(string_2_json(data.values, firstvalue),dv,'ad');
      else t +=  build_DOM_SELECT_options(string_2_json('|', firstvalue),dv,'ad');
     
      t +=  '</select>';
    }
     if (data.domtype=="radio"){
      t +=  build_DOM_RADIO_options(vfield_html_name, string_2_json(data.values), dv);
    }

    if (data.domtype=="checkbox"){
      // console.log(data.values); 
      t +=  build_DOM_CHECKBOX_options(vfield_html_name, string_2_json(data.values), dv,'','','multidims');
    }

    // add units if indicated 
    if (data.unit){
       t += '<span class="unit">'+data.unit+'</span>'; 
    }
    if ((data.stype=="min") || (data.stype=="max")) {
      xcl =  data.stype ; 
    } else xcl ="";

    if (isRequired){
      t+='<span class="admandatory"> * </span>';
    } 


    // add the error screen for displaying error in entry 
    t += '<span id="error" class="error" style="display :none"></span>'; 


    if ((context=="withlabel") || (context=="withlabelequaltitle")){
      var xxcl = (noLabel) ? ' no_mob_label ' : ''  ; // we don't use this feature now 
      var xlabel= '<span class="extra-vfield disp_label '+xxcl+'">'+data.disp_label+'</span>' ; 
      t = '<div class="vfield_in_div '+xcl+'">' + xlabel + t + '</div>'; 
    } 
  }
  
  return t;
};



/**-----------------------------------------------------------------------------
* This function convert a string value FRROM  'xx|xx|xx' into s json object to be used for SELECT and radio
* str = the input string in format xx|yy|
* withfirstvalue = if true >> we add "Select something" if STRING, we add the string, if  nothing or false, we add nothing 
*-----------------------------------------------------------------------------*/  
function string_2_json (str, withfirstvalue){
  var o = new Array(), xname='';
  if (!str) return ''; // DUMB protection

  var sa = str.split('|'); 

  if (withfirstvalue) {
    if (withfirstvalue===true) xname =  'Select something'; else xname =  withfirstvalue;
    o.push({ name : xname, value : ''});   
  }
  for(var i = 0; i < sa.length; i++) {
    // { name : 'input', value : 'input', checked: 'checked'},
    e=sa[i].split(';')[0]; // object 
    ev =  e.toLowerCase().substr(0,10); 
    o.push({ name : e, value : ev});   
  }

  return o; 
}

/**-----------------------------------------------------------------------------
* This function check if a given string is present into a list like xx|yy|zz... 
*-----------------------------------------------------------------------------*/
function inStr(needle, haystack, separator){
  var o=false;
  if (haystack){
    var n = haystack.split(separator); 
    for(var i = 0; i < n.length; i++) {
      if (n[i]==needle) return true; 
    }
  } 
  return o; 
}  

/**-----------------------------------------------------------------------------
* This function convert a string value in the form xx=value|xx=value|xx=valie into s json  array [key]=value ; 
*-----------------------------------------------------------------------------*/  
function stringwithpipe_2_json(str){
  var o = new Array();
  if (str) {
    var sa = str.split('|'); 

    for(var i = 0; i < sa.length; i++) {
      // { name : 'input', value : 'input', checked: 'checked'},
      var p=sa[i].split('='); // pair 
      var ek = p[0]; // key  
      var ev = p[1]; //value  
      o[ek] = ev ; 
    }
  }
  return o; 
}



/**-----------------------------------------------------------------------------
* This function decode the Vtag settings 
*-----------------------------------------------------------------------------*/  
function decode_vtag_settings(vtagname){
  // get id and boolena, en, url (decoded)
  var o = new Array();
  var idx=vtagname.substr(-1);
  o['en']= vtags_settings['vtag'+idx+'_en']; 
  o['name']= vtagname; 
  var b = vtags_settings['vtag'+idx+'_boolean']
  o['boolean']= (typeof b !== "undefined") ? b : false; 
  o['urlfull']= vtags_settings['vtag'+idx+'_url']; 

  // decode the url
  if (o['urlfull'])
    o['urldetails'] = stringwithpipe_2_json(o['urlfull']); 

  // console.log(o);
  return o; 
}


/**-----------------------------------------------------------------------------
* This function convert a string value in the form xx|yy|zz;xx|yy|zz; info a json obect 
*-----------------------------------------------------------------------------*/  
function urlstring_2_json(str){
  var o = new Array();
  if (str) {
    var sa = str.split(';'); 
    for(var i = 0; i < sa.length; i++) {
      // { name : 'input', value : 'input', checked: 'checked'},
      var p=sa[i].split('|'); // pair 
      var pext  =p[0].substring(p[0].lastIndexOf('.')+1);
      o.push({filename : p[0], basename : p[1], filesize : p[2], ext:pext, fileurl : './uploads/img/'+p[0], lid : i} );   
      // urlobj.filename+"|"+urlobj.basename+"|"+urlobj.filesize;
    }
  }
  return o; 
}

/**-----------------------------------------------------------------------------
* This function convert a json object into a string with key=value&key=value,....
*-----------------------------------------------------------------------------*/  
function json_2_str(o){
  var s = '';
  $.each(o, function (key, value){ s+='&'+key+'='+value;});
  s = s.substring(1); // remove fisrt '&'
  return s; 
}

/**-----------------------------------------------------------------------------
* This function convert a string value in the form xx=value&xx=value&xx=valie into s json  array [key]=value ; 
*-----------------------------------------------------------------------------*/  
function serialstring_2_json(str){
  var o = {};
  if (str) {
    var sa = str.split('&'); 
    for(var i = 0; i < sa.length; i++) {
      var p=sa[i].split('='); // pair 
      var ek = p[0]; // key  
      var ev = p[1]; //value  
      o[ek] = ev ; 
    }
  }
  return o; 
}


// function serialstring2_2_json(str){
//   var obj = {}; 
//   str.replace(/([^=&]+)=([^&]*)/g, function(m, key, value) {
//       obj[decodeURIComponent(key)] = decodeURIComponent(value);
//   }); 
//   return obj; 
// }

/**-----------------------------------------------------------------------------
* This function remove a lits of keys from a Javascript array 
*-----------------------------------------------------------------------------*/  
function remove_keys_from_json(obj, keysAr){
  var o=obj; 
  // for (var key in obj) {
  //     if (in_array(key,keysAr)){
  //       delete o[key] 
  //     }
  // }
   $.each(o, function (key, value){ 
    if (in_array(key,keysAr)){
        delete o[key] 
    }
  });
return o; 
}




// *-----------------------------------------------------------------------------
// * This function remove a lits of keys from a Javascript array 
// *-----------------------------------------------------------------------------  
// function remove_keys_from_assoArray(obj, keysAr){
//   var o=obj; 
//   for (var key in obj) {
//       if (in_array(key,keysAr)){
//         delete o[key] 
//       }
//   }
// return o; 
// }

// *-----------------------------------------------------------------------------
// * This function convert a json object into a string with key=value&key=value,....
// *-----------------------------------------------------------------------------  
// function assoArray_2_str(o){
//   var s = '';
//   for (var key in o) {
//     value=o[key]; 
//     s+='&'+key+'='+value;
//   }
//   s = s.substring(1); // remove fisrt '&'
//   return s; 
// }




/**-----------------------------------------------------------------------------
* This function find a give Vfield based in it's ID
*-----------------------------------------------------------------------------*/  
function find_vfield_by_id(str, id){
  var o=false; 
  var sa = str.split('|'); 
  if (sa.length >= 1){
     for(var i = 0; i < sa.length; i++) {
      sb  = sa[i].split('=');
      if (sb[0]==id) {o=sb[1]; break;}
     }
  }
  return o;
}


/**-----------------------------------------------------------------------------
* This function display the breadcrumb 
* @param  {str} what - the location
*-----------------------------------------------------------------------------*/ 
function build_DOM_breadcrumb(what, nav, search){

  nav = typeof nav !== 'undefined' ? nav : 'admin';
  search = typeof search !== 'undefined' ? search : '';

  var t_nav='';       
  // ---------- breadcrumb -----------------
  var ax = new Array();
  ax.push({text : $.i18n._('Main List') , href : '#action=back', cl : 'home', help:'yes'});
  ax.push({text : $.i18n._(nav) , href : '#nav=admin&what=dashboard', cl :''});
  if (search) ax.push({text : $.i18n._("search") , href : '#', cl :''});
  ax.push({text : $.i18n._("all "+what) , href : '#', cl :''});
  
  // display the breadcrumb
  t_nav += '<ul id="breadcrumbsul" class="clear">'; 
  $.each(ax, function(i, elem) {
    if ((i+1)==ax.length)
      t_nav += '<li>'+elem.text+'</li>'; // final element
    else {
      if (elem.help=="yes") tt =  'title="'+$.i18n._('help link '+elem.text)+'"'; 
      else tt=""; 

      // case of home which means BACK ! 
      if (elem.cl=="home") { xtra =  '<i class="icon-fa-backward"></i>'; xtext = '';} else { xtra=''; xtext = elem.text;}
      t_nav += '<li><a nottip="yes" name="list_ads" zhref="'+elem.href+'" href="'+elem.href+'" class="'+elem.cl+'" '+tt+'>'+xtra+xtext+'</a></li>';
      t_nav += '<span>&gt</span>';
    }
  });
  t_nav += '</ul>';

  // append
  $('#breadcrumbs').html(t_nav).show();

  // event handlers
  $('#breadcrumbs a').click(function(e){
    e.preventDefault(); 
    gen_navigation_dispatcher($(this)); 
    return true;
  }); 

}

/**-----------------------------------------------------------------------------
* This function is a generic navigation dispatcher based on href element 
* @param  {jquery object} thisjqobj - the object having generated the event 
*-----------------------------------------------------------------------------*/ 
function gen_navigation_dispatcher(thisjqobj){

   window.location.hash = "";  

   ahref = thisjqobj.attr('href'); 
   var tmpx = ahref.split("#");
   ahref2 = tmpx[tmpx.length-1]; // get just the final elements after latest # to correcr IE bug.
   anchor1=[]; 
   eval_href ( ahref, "anchor1");

   if (anchor1.action=="list") {
      // call ajax to refresh the list
      cur_nav_ajax = ahref2; 
      ajax_action (cur_nav_ajax);
   }
   else if (anchor1.what=="dashboard"){
     display_DASHBOARD();
   } 
    else if (anchor1.what=="mydashboard"){
     display_DASHBOARD('my');
   }
   else if (anchor1.action=="back"){
     $('#home a').click();
   } else 
    displayMessage("Action not yet available", true, "info");


   return true; 
}


/**-----------------------------------------------------------------------------
* This function display a given JSON as an HTML TABLE 
* @param  {str} whereselector - the location selector to display the content
*-----------------------------------------------------------------------------*/  
function display_DOM_generic_Table_from_JSON(data, whereselector, context, translate){

  var t='', key; 
  context = typeof context !== 'undefined' ? context : 'about';
  translate = typeof translate !== 'undefined' ? translate : true;

  $.each(data, function(i, e) {

    var tkey1 = (translate) ? $.i18n._(i) : i ; 
    t+='<tr>'; 
    t+='<td>'+tkey1+'</td>'; // display thekey whatever happens
    
    if (typeof e === 'object'){
      // has child so create a new table 
      t+='<td><table class="table-bordered "><tbody>';
      $.each(e, function(i, e2) {
        // level 2 iteration 
        t+='<tr>'; 
        if (typeof e2 === 'object'){
          if (i==0) cl=" bold ";  else cl=''; // fisrt item
          // multiple key/value into the object (level 3 iteration)
          $.each(e2, function(k2, v2) {
            t+='<td class="'+cl+'">'+v2+'</td>'; // display the value only
          });
        }
        else {
          t+='<td>'+i+'</td>'; 
          val2=(e[i]=='true' || e[i]==true) ? '<i class="icon icon-fa-check" style="color:green"></i>' : e[i]; 
          val2=(val2=='false' || val2==false) ? '<i class="icon icon-fa-close" style="color:red"></i>' : val2; 
          t+='<td>'+val2+'</td>'; 
        }
        t+='</tr>'
      }); 
      t+='</tbody></table></td>';
    } else{
      t+='<td>'+e+'</td>'; // display thekey whatever happens
    }
    t+='</tr>'; // close the column,

  });

  //wrap into atable
  t= '<table class="table-striped table-bordered '+context+'"><tbody>' + t + '</tbody></table>'; 

  // clean and append all 
  clean_allcontent(); 
  $(whereselector).html(t).show();
  build_DOM_breadcrumb('about');


  // handlers on actions if exists 
    // main navigartion handler
  $(whereselector +' a.hasaction').click(function (e){
    e.preventDefault();
    // get the href and delete the leading # 
    var tmpx = $(this).attr('zhref').split("#"); ahref2 = tmpx[tmpx.length-1]; // get just the final elements after latest # to correcr IE bug.
    // call the generic nav dispatcher 
    nav_dispatcher(ahref2, '_admin_subnav_menu'); 
    return true;
  });


}



function export_this_xls(tableid, wsname){
        //window.open('data:application/vnd.ms-excel,' + $('#bom-content').html());
        if (tableid=='list_of_orders') $('#list_of_orders ul.action').remove();
        tableToExcel(tableid,wsname); 
}


    var tableToExcel = (function() {
      var uri = 'data:application/vnd.ms-excel;base64,'
        , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
        , base64 = function(s) { 
          // return window.btoa(unescape(encodeURIComponent(s))) cause troubles for accents in FR ! 
          return window.btoa(unescape(s)) 
        }
        , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
      return function(table, name) {
        if (!table.nodeType) table = document.getElementById(table)
        var ctx = {worksheet: name || 'Worksheet', table: table.innerHTML}
        window.location.href = uri + base64(format(template, ctx))
      }
    })()


/**-----------------------------------------------------------------------------
* This function build the navigation page 
* @param  {obj} d - the JSON object containing the data (data) and options from RX
*-----------------------------------------------------------------------------*/  
function build_gen_nav_pages(what,totaladnbr,paged,elems_per_page ){

  var t_nav=''; 

  var AD_ITEMS_PER_PAGE = (elems_per_page) ? elems_per_page : 50 ; 

  var maxpages = Math.ceil(totaladnbr/AD_ITEMS_PER_PAGE);
  var nextpage= paged+1;prevpage= paged-1;
  var articlestart = Math.max((paged-1)*AD_ITEMS_PER_PAGE+1, 1); 
  if ((paged*AD_ITEMS_PER_PAGE)>totaladnbr) articleend = totaladnbr; 
  else articleend = (paged*AD_ITEMS_PER_PAGE);

  // display Right part 
  //if (AD_ITEMS_PER_PAGE < totaladnbr){ // condition to hide display when only 1 page to show
  t_nav += ' <ul id="navpage" class="">';
    t_nav += '<li id="navtxt"> '+$.i18n._('<b>%s</b>-<b>%s</b> of <b>%s</b>',[articlestart,articleend,totaladnbr]) +'</li>';
    if (paged > 1)  
      t_nav += ' <li class="text"> <a name="filter_list" class="dm_button2" title="'+$.i18n._('help prev')+'" href="#'+what+'=list&page='+prevpage+'"><i class="icon-fa-chevron-left"></i></a></li>';      
    if ((nextpage <= maxpages) )  t_nav += '   <li class="text"> <a name="filter_list"  title="'+$.i18n._('help next')+'" class="dm_button2" href="#'+what+'=list&page='+nextpage+'"><i class="icon-fa-chevron-right"></i></a></li>';
    t_nav += ' </ul>';
  //}

  return t_nav; 
}


/**-----------------------------------------------------------------------------
* This function build the generic list of filters 
*-----------------------------------------------------------------------------*/ 
function build_DOM_generic_list_filters(what,listoffilters, curvalue){
  var t='';

  $.each(listoffilters, function(i, e) {
    if (e.type=="select"){
      t += ' <ul class="sort-options">';
      t +=  '<select name="filter_list" id="'+e.id+'" >';
      t +=  build_DOM_SELECT_options(e.linkedobj, curvalue[e.id],what);
      t +=  '</select>';
      t += ' </ul>';
    }

     if (e.type=="input"){
      t += ' <ul class="sort-options">';
      if (curvalue[e.id]) xval =  curvalue[e.id]; else xval=''; 
      t +=  '<input type="text" class="'+e.cl+'" name="filter_list" id="'+e.id+'"  value="'+xval+'" placeholder="'+$.i18n._(e.placeholder)+'"/>';
      t += ' </ul>';
    }

     if (e.type=="checkbox"){
      if (typeof curvalue[e.id] == undefined) {
        if (e.checked) elemchecked="checked"; else elemchecked="";
      } else  if (curvalue[e.id]==e.value) elemchecked="checked"; else elemchecked=""; 
      
      t += ' <ul class="sort-options">';
      t += '<input name="filter_list"  id="'+e.id+'" type="checkbox"  class="checkboxx" value="'+e.value+'" '+elemchecked+' ></input>';
      t += '<span class="">'+$.i18n._(e.id)+'</span>';             
      t += ' </ul>';
    }

    if (e.type=="link-export" && isPageAdmin && isAdmin ){
      t += ' <ul class="top-actions">';
      t+=  '<li><a href="#" name="exporttoxls" class="dm_button2"  z-table="table_gen"><i class="icon-fa-download mr6"></i>'+$.i18n._("Export this table to xls")+'</a></li>'; 
      t += ' </ul>';
    }

    if (e.type=="button-create" && (isPageAdmin || what=="bookings")){
      xtraattr='';
      if (what=='ads') {
        // console.log(curvalue['type']);   
        if (curvalue['type']=="zetvu") {
          xtraattr+= ' z-type="'+curvalue['type']+'" '; 
          var tlabel=(zetevu_as_news) ? "create_zetvu_as_news" : (zetevu_as_video) ? "create_zetvu_as_video" : "create zetvu";
          txt_button = $.i18n._(tlabel);
        } else txt_button = $.i18n._("create ad");
      }
      else if (what=='users') txt_button = $.i18n._("create user");
      else txt_button  = $.i18n._("Create "+what);

      if (what=="bookings" && curvalue['fadid']) xtraattr+= ' z-fadid="'+curvalue['fadid']+'" '; 
    
      t += ' <ul class="top-actions">';
      t+=  '<li><a href="#" name="create" class="dm_button2" zwhat="'+what+'" '+xtraattr+' z-table="table_gen"><i class="icon-fa-plus mr6"></i>'+txt_button+'</a></li>'; 
      t += ' </ul>';
    }

    if( e.type=="button"){
      var txt_button = $.i18n._(e.id);
      var xtraattr= ' zajax = "'+e.ajax+'"'; 
      t += ' <ul class="top-actions">';
      t+=  '<li><a href="#" name="ajaxbutton" class="dm_button2" zwhat="'+what+'" '+xtraattr+' z-table="table_gen"><i class="icon-fa-'+e.icon+' mr6"></i>'+txt_button+'</a></li>'; 
      t += ' </ul>';
    }

    if( e.type=="linebreak"){
      t+='<br>';
    };

    // select fieldsbutton 
    if (e.type=="select-fields-button" && isPageAdmin && isAdmin ){
      txt_button = $.i18n._(e.id);
      t += ' <ul class="top-actions" >';
      t+=  '<li style="position:relative;" ><a href="#" name="select_fields" class="dm_button2" zwhat="'+what+'" z-table="table_gen"><i class="icon-fa-gear mr6"></i>'+txt_button+'</a><div class="select_drop_down hideit"></div></li>'; 
      t += ' </ul>';
    }

  });
  return t;   
}





/**-----------------------------------------------------------------------------
* This function build and display the List of subscribers 
* @param  {obj} d - the JSON object containing the data (data) and options from RX
* @param  {str} whereselector - the location selector to display the content
* @param  {str} viewmode - {digest | empty} - condensed view when list displayed inline 
*-----------------------------------------------------------------------------*/  
function display_DOM_generic_list(what, d, whereselector, viewmode){

    var t  = ""; 
    var t2 = "";
    var t_nav="";
    var adnbr; 
    var imgsize=0;
    var act='';
    
    var isSearch=false;  if (d.search && d.search!="") isSearch=true;
    if (!d.sort) d.sort = "date_desc"; // default value
    var totaladnbr = d.totnb;  // total number of returned results .
    var paged=parseInt(d.paged); 
    if (!paged) paged=1; 
    
    var nav = d.nav; 
    // patch NAV
    if (!nav){nav="dashboard";} 


    var status = d.status; 
    var search = d.search; 
    var whattodisp=d.what;
    var type=d.type;
    var catid=d.catid;
    var view = d.view;
    var sort = d.sort;
    var userid=d.userid;
    var faction = d.faction;
    var fseverity = d.fseverity;
    var fstatus=d.fstatus; 
    var ftype=d.ftype; 
    var eppage =d.eppage; 
    var status=d.status; 
    var fadid=d.fadid;
    var fuserid=d.fuserid;
    var ftime=d.ftime; 
    var frecurrent=d.frecurrent; 
    var fwhat=d.fwhat; 
    var fsearch=d.fsearch; 
    var fbot=d.fbot; 
    var fbingbot=d.fbingbot; 
    var fgoogbot=d.fgoogbot; 
    var fposition=d.fposition; 
    
    var cur_value= new Array();
     cur_value['faction'] = faction;
     cur_value['fseverity'] = fseverity;
     cur_value['fstatus'] = fstatus;
     cur_value['ftime'] = ftime;
     cur_value['fwhat'] = fwhat;
     cur_value['ftype'] = ftype;
     cur_value['fsearch'] = fsearch;
     cur_value['fbot'] = fbot;cur_value['fbingbot'] = fbingbot;cur_value['fgoogbot'] = fgoogbot;
     cur_value['type'] = type;
     cur_value['frecurrent'] = frecurrent;
     cur_value['fposition'] = fposition;
     cur_value['eppage'] = eppage;
     cur_value['sort'] = sort;
     cur_value['view'] = view;
     cur_value['status'] = status;
     cur_value['fadid'] = fadid;
     cur_value['fuserid'] = fuserid;
     cur_value['search'] = search;
     if (cur_value['status']) cur_value['status'] = status.split('admin_')[1];

    var eppage =d.eppage; 
    var elems_per_page = d.eppage; 
    AD_ITEMS_PER_PAGE = (elems_per_page) ? elems_per_page : 50 ; 

    // patch for "ads"
    var orig_what = what ; 
    if (what=="ads" || what=="users" || what=="cats") {
      var rawdata = d.item0[0] ;
    }
    else {
      var rawdata = d.data; 
      var what=d.action;
    }

    // sinatanciate the varialbel here so that we are sure it's up to date  ! 
    var list_of_filters_for_list =  { 
      subscribers : [
          { id : 'sort',linkedobj: sortoptions_obj , type:'select'}
          ,{ id : 'fstatus',linkedobj: subscribers_filter_status_obj , type:'select'}
          ,{ id : 'eppage',linkedobj: list_elements_per_page_obj , type:'select'}
          ,{ id : 'list_elements_per_page_obj', type:'link-export'}
        ],
      ads : [
          { id : 'sort',linkedobj: sortoptions_obj , type:'select'}
          ,{ id : 'status',linkedobj: ad_filter_options , type:'select'}
          ,{ id : 'ftype',linkedobj: filter_protype , type:'select'}
          ,{ id : 'eppage',linkedobj: list_elements_per_page_obj , type:'select'}
          ,{ id : 'list_elements_per_page_obj', type:'link-export'}
          ,{ id : 'button_create', type:'button-create'}
          ,{ id : 'select_fields', type:'select-fields-button'}
          ,{ id : 'search', type:'input', placeholder:'search for title or description', cl:'admin-search-medium'}
        ],

      coms : [
          { id : 'sort',linkedobj: sortoptions_obj , type:'select'}
          ,{ id : 'status',linkedobj: ad_filter_options , type:'select'}
          ,{ id : 'ftype',linkedobj: gen_select_options.coms_type , type:'select'}
          ,{ id : 'eppage',linkedobj: list_elements_per_page_obj , type:'select'}
          ,{ id : 'list_elements_per_page_obj', type:'link-export'}
          ,{ id : 'search', type:'input', placeholder:'search for title or description', cl:'admin-search-medium'}
      ],

      coms_comment : [
          { id : 'sort',linkedobj: sortoptions_obj , type:'select'}
          ,{ id : 'status',linkedobj: ad_filter_options , type:'select'}
          ,{ id : 'ftype',linkedobj: gen_select_options.coms_type , type:'select'}
          ,{ id : 'eppage',linkedobj: list_elements_per_page_obj , type:'select'}
          ,{ id : 'list_elements_per_page_obj', type:'link-export'}
          ,{ id : 'coms_comment_purgedeleted', type:'button', icon:'trash', ajax:'coms=purgedeleted&ftype=comment&laction=com_purgedeleted'}
          ,{ id : 'search', type:'input', placeholder:'search for title or description', cl:'admin-search-medium'}
      ],

      coms_review : [
          { id : 'sort',linkedobj: sortoptions_obj , type:'select'}
          ,{ id : 'status',linkedobj: ad_filter_options , type:'select'}
          ,{ id : 'ftype',linkedobj: gen_select_options.coms_type , type:'select'}
          ,{ id : 'eppage',linkedobj: list_elements_per_page_obj , type:'select'}
          ,{ id : 'list_elements_per_page_obj', type:'link-export'}
          ,{ id : 'coms_review_purgedeleted', type:'button', icon:'trash', ajax:'coms=purgedeleted&ftype=review&laction=com_purgedeleted'}
          ,{ id : 'search', type:'input', placeholder:'search for title or description', cl:'admin-search-medium'}
      ],

       alerts : [
          { id : 'sort',linkedobj: sortoptions_obj , type:'select'}
          ,{ id : 'status',linkedobj: ad_filter_options , type:'select'}
          ,{ id : 'eppage',linkedobj: list_elements_per_page_obj , type:'select'}
          ,{ id : 'search', type:'input', placeholder:'search for title or description', cl:'admin-search-medium'}
      ],

      cats : [
          { id : 'sort',linkedobj: sortoptions_obj , type:'select'}
          ,{ id : 'type',linkedobj: cattype_a , type:'select'}
          ,{ id : 'eppage',linkedobj: list_elements_per_page_obj , type:'select'}
          ,{ id : 'list_elements_per_page_obj', type:'link-export'}
          ,{ id : 'button_create', type:'button-create'}
          ,{ id : 'search', type:'input', placeholder:'search for title or description', cl:'admin-search-medium'}

        ],

      banners : [
          { id : 'button_create', type:'button-create'}
         ,{ id : 'fposition',linkedobj: banner_position_filter_options , type:'select'}
         ,{ id : 'search', type:'input', placeholder:'search for title', cl:'admin-search-medium'}
         ,{ id : 'button_refreshcache', type:'button', icon:'recycle', ajax:'banners=refreshcache'}
        ],

      users : [
          { id : 'sort',linkedobj: sortoptions_obj , type:'select'}
          ,{ id : 'status',linkedobj: user_filter_options , type:'select'}
          ,{ id : 'ftype',linkedobj: filter_protype , type:'select'}
          ,{ id : 'eppage',linkedobj: list_elements_per_page_obj , type:'select'}
          ,{ id : 'list_elements_per_page_obj', type:'link-export'}
          ,{ id : 'button_create', type:'button-create'}
          ,{ id : 'select_fields', type:'select-fields-button'}
          ,{ id : 'search', type:'input', placeholder:'search', cl:'admin-search-medium'}

          
      ],
      services : [
          { id : 'sort',linkedobj: sortoptions_obj , type:'select'}
          // ,{ id : 'status',linkedobj: user_filter_options , type:'select'}
          ,{ id : 'eppage',linkedobj: list_elements_per_page_obj , type:'select'}
          ,{ id : 'fuserid', type:'input', placeholder:'filter per user id'}
          ,{ id : 'list_elements_per_page_obj', type:'link-export'}
          //,{ id : 'button_create', type:'button-create'}
      ],
      payments : [
          { id : 'fwhat',linkedobj: log_filter_what_obj , type:'select'}
          ,{ id : 'frecurrent',value:'yes', type:'checkbox'}
          ,{ id : 'ftime',linkedobj: filter_time_obj , type:'select'}
          // ,{ id : 'status',linkedobj: user_filter_options , type:'select'}
          ,{ id : 'eppage',linkedobj: list_elements_per_page_obj , type:'select'}
          ,{ id : 'list_elements_per_page_obj', type:'link-export'}
          //,{ id : 'button_create', type:'button-create'}
      ],
      bookings : [
          { id : 'sort',linkedobj: sortoptions_obj , type:'select'}
          ,{ id : 'eppage',linkedobj: list_elements_per_page_obj , type:'select'}
          ,{ id : 'list_elements_per_page_obj', type:'link-export'}
          ,{ id : 'button_create', type:'button-create'}
      ],
      visitors : [
          { id : 'sort',linkedobj: sortoptions_obj , type:'select'}
          ,{ id : 'eppage',linkedobj: list_elements_per_page_obj , type:'select'}
          ,{ id : 'fsearch', type:'input', placeholder:'IP address or fqdn '}
          ,{ id : 'fgoogbot', type:'checkbox', checked:false, value:'yes'}
          ,{ id : 'fbingbot', type:'checkbox', checked:false, value:'yes'}
          ,{ id : 'linebreak', type:'linebreak'}
          ,{ id : 'delete_allbutbot', type:'button', icon:'trash', ajax:'visitors=delete&laction=allbutbot'}
          ,{ id : 'delete_allall', type:'button', icon:'trash', ajax:'visitors=delete&laction=allall'}
          ,{ id : 'delete_allfilter', type:'button', icon:'trash', ajax:'visitors=delete&laction=allfilter'}
      ],
      logs : [
          { id : 'sort',linkedobj: sortoptions_obj , type:'select'}
          ,{ id : 'eppage',linkedobj: list_elements_per_page_obj , type:'select'}
          ,{ id : 'faction',linkedobj: log_filter_action_obj , type:'select'}
          ,{ id : 'fseverity',linkedobj: log_filter_severity_obj , type:'select'}
          ,{ id : 'linebreak', type:'linebreak'}
          ,{ id : 'delete all auth logs', type:'button', icon:'trash', ajax:'logs=delete&laction=auth'}
          ,{ id : 'delete all cron logs', type:'button', icon:'trash', ajax:'logs=delete&laction=cron'}
          ,{ id : 'delete all sec logs', type:'button', icon:'trash', ajax:'logs=delete&laction=sec'}

      ]

    }; 


    if (!whereselector){
      // empty content and hide 
      $('#adlist').html("").hide(); 
      ad_form_hide(); 
      $('#addetails').html("").hide(); 
      $('#breadcrumbs').html("").hide();
      whereselector ='#adlist'; // default 
    } else {
        $(whereselector).html('').show(); 
    }

    //hide the search bar
    $('#main-nav-search').hide();

    
    

      // ------------------- display the NAV banner  -----------------------  
      t_nav += '<div class="clear" id="listings-nav">  '; 
      
      // ---------- breadcrumb -----------------
      var ax = new Array();
      ax.push({text : $.i18n._('Main List') , href : '#action=back', cl : 'home', help:'yes'});
      ax.push({text : $.i18n._(nav) , href : '#nav=admin&what=dashboard', cl :''});
      if (search) 
        ax.push({text : $.i18n._("search") , href : '#', cl :''});
      ax.push({text : $.i18n._("all "+orig_what) , href : '#', cl :''});
      
      // display the breadcrumb
      t_nav += '<ul id="breadcrumbsul" class="clear">'; 
      $.each(ax, function(i, elem) {
        if ((i+1)==ax.length)
          t_nav += '<li>'+elem.text+'</li>'; // final element
        else {
          if (elem.help=="yes") tt =  'title="'+$.i18n._('help link '+elem.text)+'"'; 
          else tt=""; 

          // case of home which means BACK ! 
          if (elem.cl=="home") { xtra =  '<i class="icon-fa-backward"></i>'; xtext = '';} else { xtra=''; xtext = elem.text;}
          t_nav += '<li><a nottip="yes" name="list_ads" href="'+elem.href+'" class="'+elem.cl+'" '+tt+'>'+xtra+xtext+'</a></li>';
          t_nav += '<span>&gt</span>';
        }
      });
      t_nav += '</ul>';
    
  
      // text with nbr of items
      if (search && search!="") searchtxt = $.i18n._('containing <b>%s</b> word',[search]); else searchtxt=""; 
      t_nav += ' <div class="text-nav">'+searchtxt; 
      t_nav += '</div>';
      
      // display Right part 

      // navigation arrow 
      t_nav += build_gen_nav_pages(orig_what,totaladnbr,paged,elems_per_page ); 
      
      t_nav += ' <div class="clearer">&nbsp;</div>'; 
      t_nav += '</div>  '; 
               
      // really display the nbr of ads 
      if (whereselector =='#adlist')
          $(whereselector).append(t_nav);
      
      // ------------------- display the Second Line of Header  -----------------------  

      if (what=="alerts" && viewmode=="digest") t+=''; 
      else {
        t += '';  
        t += '<div class="clear" id="listings-header">  ';  
        t+= build_DOM_generic_list_filters(what,list_of_filters_for_list[orig_what],cur_value);
        t +='</div>'; 
      }

      // ---- finaly append all the nav headers 
      $(whereselector).append(t); 

      // ------------- get the filst of fields to be selected in display -----------
      if (what=="users") default_list=["id", "moddate",  "email", "username", "firstname", "lastname",  "procpny", "protype","plan", "totnbads",  "status"];
      if (what=="ads")  default_list=["id", "moddate", "type", "title",  "price", "catid", "hits","username", "protype", "status"];
      
      if (what=="cats")  // add protype in filter 
        if (display_settings.cat_filter_protype)   default_list=["id", "title", "parentid", "type", "totnbads", "catlvfields", "hascalendar", "adultflag", "pricetype", "protype", "status", "order"];
        else default_list=["id", "title", "parentid", "type", "totnbads", "catlvfields", "hascalendar", "adultflag", "pricetype",  "status", "order"];
      
      if (what=="subscribers") {  default_list=["id", "email", "registerdate", "status"];}
      if (what=="services")  default_list=["id", "type","sid", "priceid", "remain", "startdate", "enddate",  "status", "userid", "username", "price", "pricevat"];
      if (what=="payments") default_list=[ "paymentdate", "whatid", "what", "transactionid","paymentstatus" ,"amt", "recurrent", "displayinvoiceaction"];
      if (what=="visitors")  default_list=["date","ip", "uri", "ua"];
      if (what=="banners")  default_list=["title", "status", "startdate", "enddate", "position", "clicks", "CTR", "impressions"];
      if (orig_what=="coms_comment")  default_list=["id",  "moddate", "description", "username", "whatid", "likes", "status",   "abuse"];
      if (orig_what=="coms_review")  default_list=["id", "moddate", "ratings", "description", "username", "what", "whatid", "status", "abuse"];

      if (what=="bookings") {
        if (viewmode=="digest")  default_list=[ "bo_moddate", "bo_title","bo_lastname", "bo_start_date", "bo_end_date", "status"];
        else  default_list=[ "bo_moddate", "bo_title", "bo_start_date", "bo_end_date", "status","bo_ad_id" ,"userid"];
      }
      if (what=="logs")  default_list=["severity", "date", "what", "whatid", "action", "dyn_title", "desc", "state", "username"];

      if (what=="alerts")  {
         if (viewmode=="digest")  default_list=["title", "moddate", "expiredate"];
         else default_list=["title", "status", "moddate", "expiredate", "userid"];
       }

      var fields_list_tobedisplayed =  construct_fields_list(what, rawdata, ".select_drop_down" ,default_list); 
  
      // ---------------  start displaying the list of items  ---------------   
      t = ' <div  id="logs">';
      if (rawdata.length>0) {
            // create the table char 
            // P = Publish, M = modify  D = Delete , O=order (special for CAT)
            // G = geocoding of IP address (users) R= ? 
            if (what=="subscribers")  { act="PD"; }
            if (what=="ads")          { act="MD"; }
            if (what=="cats")         { act="OMD"; }
            if (what=="users")        { act="MDG";}
            if (what=="services")     { act="PD"; }
            if (what=="payments")     { act=""; }
            if (what=="bookings")     { act="MD";}
            if (what=="banners")      { act="MDR";}
            if (what=="coms")         { act="MDTPL"; }
            if (what=="alerts")       
              if (viewmode=="digest") { act="D";}  // just delete
              else                    { act="PDT";} 

            // call the table with right values 
            table = create_table_chart(rawdata,fields_list_tobedisplayed,'',50,'logsmode',d.userid, act, what); 

      } else { 
            table = '<div class="noresults">'+$.i18n._("No entries in "+what)+'</div>';
      }
      t +=table;
      t += '</div>  '; 

      // --- complement with some datas on second header line 
      if (what=="payments"){
        // add the total amount + number of items 
        var counti = 0, totamount = 0, tmpstrtot =''; 
        $.each(d.data, function(i, e) {
          counti++; totamount+=e.amt*1; curcode= e.currencycode; 
        });
        if (counti>0){
          totamount= format("# ##0.00", totamount); // format price
          tmpstrtot += '<div class="payment_totamount">'+$.i18n._('<b>%s</b> payment(s) - total amount = <b>%s</b> %s',[counti,totamount, curcode]) +'</div>'; 
          tmpstrtot += ' <div class="clearer">&nbsp;</div>';  
        }
        t = tmpstrtot + t;
      }

      // ---- display everything  ! 
      $('.z-upload-hidden').remove(); // remove all contents
      if (!d.inlinefor)  hide_modalbox(); 
      $(whereselector).hide().append(t).fadeIn(); 
      
      // ----- add the navigation 
      if (whereselector =='#adlist')
          $(whereselector).append(t_nav); 

      // --- activate the tooltips on new links
      //activate_tooltip('.ttip');
      activate_tooltip('a');

      // ---- update navigation element 
      //-- update the URL without reloading 
      if (whereselector =='#adlist'){
          if (what=="payments")
            addToNavigatorHistory('!!'+build_URL('myinvoices'),'localseo');  
          else  
            addToNavigatorHistory('!!'+build_URL(orig_what),'localseo');  
      }
        
       // ---------------  event handlers   ---------------                    
       // event handler for the show buttons 
       $(whereselector +' a[name=display_elem]').click (function(e) {
         e.preventDefault();
         ahref = $(this).attr('href');
         var tmpx = ahref.split("#");
         ahref = tmpx[tmpx.length-1]; // get just the final elements after latest # to correcr IE bug.
        
         ajax_action(ahref);
         return true; 
       });


       $(whereselector +' a[name=display_invoice]').click (function(e) {
         e.preventDefault();
         tid= $(this).attr('z-tid');
         // window.open('invoice.php#transactionid-'+tid,'','width=1000,toolbar=no, location=no,directories=no,status=no,menubar=yes,scrollbars=yes,copyhistory=no,resizable=yes');
         window.open('invoice.php#transactionid-'+tid);

         return true; 
       });

      // event handler for the show buttons 
       $(whereselector +' a[name=display_local_elem]').click (function(e) {
         e.preventDefault();
         zlid=  $(this).attr('z-lid');
         zwhat=$(this).attr('z-what');
         elem_display(zlid, zwhat,rawdata); 
         return true; 
       });


      // event handler for cross links between user and list of their ads 
       $(whereselector +' a[name=display_related_elem]').click (function(e) {
         e.preventDefault();
         zrelatedid=  $(this).attr('z-relatedid');
         zwhat=$(this).attr('z-what'); // case of ads
         ajax_action('action=list&what='+zwhat+'&userid='+zrelatedid+'&nav=admin&status=all');

         return true; 
       });


       $(whereselector +' .top-actions a[name=exporttoxls]').click (function(e) {
         e.preventDefault();
         tableid = $(this).attr('z-table');
         wsname = what; 
         export_this_xls(tableid, wsname);
       }); 

      $(whereselector +' .top-actions a[name=create]').click (function(e) {
         e.preventDefault();
         if ($(this).attr('z-fadid')) {
          // call the creation of something (on top of a given ad-id number)
          elem_create_modify('create', $(this).attr('zwhat'),'', '', '', $(this).attr('z-fadid'))
         } else {
          var xwhat = ($(this).attr('z-type')) ? $(this).attr('z-type') : $(this).attr('zwhat') ; // patch for zetvu
          elem_create_modify('create', xwhat);
         }

       }); 

       $(whereselector +' .top-actions a[name=ajaxbutton]').click (function(e) {
         e.preventDefault();
         var filterparams = grab_all_filters2('adlist'); // get all filters
         zajax=  $(this).attr('zajax');
         ajax_action(zajax+filterparams+'&nav=admin');
       }); 


      $(whereselector +' .top-actions a[name=select_fields]').click (function(e) {
         e.preventDefault();
         var _thedrop =  $(this).parent().find('.select_drop_down'); 
         if (parseInt($(this).offset().left) < 600) _thedrop.addClass('left0');
        _thedrop.toggleClass('hideit'); 
       });


       // event handler for the ACTIONS  button 
       $(whereselector +' .actions a').click (function(e) {
         e.preventDefault();
         id = $(this).attr('adid');
         dbid=  $(this).attr('rel');
         act = $(this).attr('action');
         hash = $(this).attr('z-hash');
         from =  $(this).attr('z-from');
         type=$(this).attr('z-type');
         dir=$(this).attr('z-dir');
         neworder=$(this).attr('z-order');
         var xtraajax="",filter_plus="";  

        if (what=="subscribers") {
          xtraajax = '&hashid='+ rawdata[id].hashid+'&email='+ rawdata[id].email+'&nav=admin' ; 
          rawdata[id].title=rawdata[id].email; 
        } 

         if ((act=="delete") || (act=="trash")|| (act=="resetclicks") || (act=="publish") || (act=="unpublish") || (act=="resetlikes")){
            
            if (type) filter_plus+="&ftype="+type; 
            afterajax =  what+"="+act+"&id="+dbid+xtraajax+filter_plus;   

            if (d.inlinefor)  afterajax+="&inlinefor="+d.inlinefor; // Z6.2.0 to identify INLINE ACTIONS
            display_DIALOG_BOX(what+" "+act+" confirmation", rawdata[id] ,"",afterajax, '','');
         } else if (act=="updateorder"){
          // ajaxtypcal call is : afterajax="#action=updateorder&dir=up&what='+whattodisp+'&id='+dbid+'&order='+orderup+'"
          afterajax='action='+act+'&dir='+dir+'&what='+what+'&id='+dbid+'&order='+neworder;
          ajax_action(afterajax); 
         }
         else{ // case of "create" & "edit" 
          var twhat=(type=="zetvu")? type : what; // case of zetevu
          var inlineparam=(d.inlinefor) ? d.inlinefor : '';  
          if (id) elem_create_modify('modify', twhat, id, '', '', inlineparam); 
          else elem_create_modify('create', twhat, '', '', '', inlineparam); 

        }
         return true; 
       });

      
      // set the actions handlers for breadcrumb
      $(whereselector +' #breadcrumbsul a[name=list_ads]').click (function(e) {
        e.preventDefault();
        gen_navigation_dispatcher($(this)); 
        return true; 
      });
       
       // event handler for navigation links / page next 
       $(whereselector +' #listings-nav a[name=filter_list]').click (function(e) {
         e.preventDefault();
         ahref = $(this).attr('href');
         var tmpx = ahref.split("#");
         var filter_plus=''; 

         ahref = tmpx[tmpx.length-1]; // get just the final elements after latest # to correcr IE bug.
          
         var filterparams = grab_all_filters2('adlist'); 
         // type and catid
         
         if(type) filter_plus+="&type="+type; 
         if (catid) filter_plus+="&catid="+catid; 
         ajax_action (ahref + filterparams +filter_plus, cur_nav_ajax); 

         // merge the actions and add to navigation history
         mhref = merge_href(ahref,cur_nav_ajax);          
         addToNavigatorHistory(mhref);     

         return true; 
       });
       
       // event handler for all the SELECT filters
       $(whereselector +' .sort-options SELECT, '+ whereselector+' .sort-options INPUT').change(function() {  
           var ahref = what+"=list";
           var filterparams = grab_all_filters2('adlist'); 
           var filter_plus=""; 
           ajax_action (ahref+filterparams+filter_plus, cur_nav_ajax);
           //add to navigation historybuild_simple_table
           //addToNavigatorHistory(ahref+filterparams+filter_plus);
           return false; 
        });
                
        function grab_all_filters2(mainid){
          var fql=""; 
          var filterzone =  $('#'+mainid); 
          // loop though each filter to get the exact AJAX PARAM 
          // SELECT 
          filterzone.find('ul > select').each(function(idx,elem){
              filtername = $(this).attr('id');
              selelem = $(this).find("option:selected"); 
              fql+="&"+filtername+"="+selelem.val();
          }); 

          // INPUTbox
          filterzone.find('ul > input').each(function(idx,elem){
              filtername = $(this).attr('id');
              if ($(this).attr('type')=='text') selelem= $(this).val();  // input text
              else selelem = $(this).is(':checked') ? $(this).val() : ""; // check box
              fql+="&"+filtername+"="+selelem;
          }); 

          return fql; 
        }
                         
       // event handler for the actions menu 
       $(whereselector +' a[name=log_actions]').click (function(e) {
         e.preventDefault();
         ahref = $(this).attr('rel');
         var tmpx = ahref.split("#");
         ahref = tmpx[tmpx.length-1]; // get just the final elements after latest # to correcr IE bug.
         eval_href ( ahref, "anchor1"); 
         
         // just toggle the menu of launch the batch action
         if (ahref=="toggle_menu"){
            menuid = $(this).attr('menuid');
            $('#'+menuid).toggle(); 
         }else if (anchor1.logs=="delete"){
          // call the confirmation popup
          display_DIALOG_BOX("Confirm deletion",{title:$.i18n._(anchor1.laction), id:''},  "Please confirm deletion of all logs entries with status : ", ahref);  
         }
         return false; 
       });       
  
    return true; 

}

function in_array(needle, haystack) {
    for(var i in haystack) {
        if(haystack[i] == needle) return true;
    }
    return false;
}

function construct_fields_list(what, data, where, default_list){

  var t='', o = new Array(), ttop='', line=0; 
  var max_per_pol=10 // max fields per columns 
  var saved_list = [];

  if (data[0]){

    // get the existing cookie value 
    var cookval = readCookie(COOKIEPREFIX+"_"+what+"_list_fields");
    if (cookval) {
      // resue it and send it for list (just the one having a true value)
      o2 = JSON.parse(cookval); 
      j=0; 
       $.each(o2, function (i,e){
         if (e.value) saved_list[j++] = e.name;
      });
    } else saved_list=default_list ; 


    fieldlist = swapJsonKeyValues(data[0]);    
    // construct the array name, desc, value
    $.each(fieldlist, function (i,e){
      var xvalue = in_array(e, saved_list) ;  
      o.push({name : e, value : xvalue , desc : 'a_'+e});  
    });

    // display it into pop-up
    t+='<div class="drop_column"><ul class="">'; 
    $.each(o, function (i,e){
      // construct
      var xchecked = (e.value)? "checked" :  "";
      var xdesc=$.i18n._(e.desc) ; 

      // display only if there is a translation 
      if (xdesc.indexOf("a_") ==-1){
        t+='<li class=""><input type="checkbox" z-name="'+e.name+'"  '+xchecked+' ><span>'+$.i18n._(e.desc)+'</span></li>'; 
        
        line++; 
        if (line > max_per_pol) {
          line=0;  t+='</ul></div><div class="drop_column"><ul class="">'; 
        }
      }

    });
    t+='</ul></div><div class="clear">&nbsp;</div>'; 

    // add the save button 
    ttop += '<div class="fields_selection_actions_btns">';
    ttop += '<a href="#" class="dm_button2 save"><i class="icon-fa-save mr6"></i>'+$.i18n._('fields selection save & refresh')+'</a>'; 
    ttop += '<a href="#" class="dm_button2 reset"><i class="icon-fa-trash-o mr6"></i>'+$.i18n._('fields selection reset')+'</a>'; 
    ttop += '</div>'; 

    $(where).html(ttop+t); 

    // event handlers 
    $(where+' li input').change(function(){
      var checked=  $(this).is(':checked'); 
      oi = JSON_find_elem_byName(o, $(this).attr('z-name')) ; 
      oi.value = checked;  
    });

    $(where+' .save').click(function(e){
      e.preventDefault();    
      // save this into a cookie 

      // with USER filds, we can exceed the max lengh of a cookie, so we keep only the true values.
      var saved_o = new Array()
      $.each(o, function (i,e){
         if (e.value==true)  saved_o.push(e);
      });

      cookiecontent = JSON.stringify(saved_o);
      createCookie(COOKIEPREFIX+"_"+what+"_list_fields",cookiecontent, COOKIE_DURATION); 
      $(where).toggleClass("hideit"); // hide the pop-up
      if (cur_nav_ajax) ajax_action(cur_nav_ajax); 
      return false; 
    });


     $(where+' .reset').click(function(e){
      e.preventDefault();    
      eraseCookie(COOKIEPREFIX+"_"+what+"_list_fields"); 
      $(where).toggleClass("hideit"); // hide the pop-up

      if (cur_nav_ajax) ajax_action(cur_nav_ajax); 

      return false; 
    });

  } // end if data

  if (saved_list.length>0) return saved_list;
  else return false; 
}

/**-----------------------------------------------------------------------------
* This function build the navigation page 
* @param  {obj} d - the JSON object containing the data (data) and options from RX
*-----------------------------------------------------------------------------*/  
function build_gen_nav_pages(what,totaladnbr,paged,elems_per_page ){

  var t_nav=''; 

  var AD_ITEMS_PER_PAGE = (elems_per_page) ? elems_per_page : 50 ; 

  var maxpages = Math.ceil(totaladnbr/AD_ITEMS_PER_PAGE);
  var nextpage= paged+1;prevpage= paged-1;
  var articlestart = Math.max((paged-1)*AD_ITEMS_PER_PAGE+1, 1); 
  if ((paged*AD_ITEMS_PER_PAGE)>totaladnbr) articleend = totaladnbr; 
  else articleend = (paged*AD_ITEMS_PER_PAGE);

  // display Right part 
  //if (AD_ITEMS_PER_PAGE < totaladnbr){ // condition to hide display when only 1 page to show
  t_nav += ' <ul id="navpage" class="">';
    t_nav += '<li id="navtxt"> '+$.i18n._('<b>%s</b>-<b>%s</b> of <b>%s</b>',[articlestart,articleend,totaladnbr]) +'</li>';
    if (paged > 1)  
      t_nav += ' <li class="text"> <a name="filter_list" class="dm_button2" title="'+$.i18n._('help prev')+'" href="#'+what+'=list&page='+prevpage+'"><i class="icon-fa-chevron-left"></i></a></li>';      
    if ((nextpage <= maxpages) )  t_nav += '   <li class="text"> <a name="filter_list"  title="'+$.i18n._('help next')+'" class="dm_button2" href="#'+what+'=list&page='+nextpage+'"><i class="icon-fa-chevron-right"></i></a></li>';
    t_nav += ' </ul>';
  //}

  return t_nav; 
}



/**-----------------------------------------------------------------------------
* This function build and display the List of Vfields 
* @param  {obj} d - the JSON object containing the data (data) and options from RX
*-----------------------------------------------------------------------------*/  
function display_DOM_vfieldsList(d) {
    
    var t  = ""; var t2 = ""; var t_nav="";
    var adnbr; 
    var imgsize=0;
    
    var isSearch=false;  if (d.search && d.search!="") isSearch=true;
    if (!d.sort) d.sort = "date_desc"; // default value
    var totaladnbr = d.totnb;  // total number of returned results .
    var paged=parseInt(d.paged); 
    if (!paged) paged=1; 
    var nav = d.nav; 
    var status = d.status; 
    var search = d.search; 
    var whattodisp=d.what;
    var type=d.type;
    var catid=d.catid;
    var view = d.view;
    var sort = d.sort;
    var userid=d.userid;
    var faction = d.faction;
    var fseverity = d.fseverity;
    var what=d.action; 
    
    var eppage =d.eppage; 
    var elems_per_page = d.eppage; 

    // empty content and hide 
    $('#adlist').html("").hide(); 
    
    // hide the form
    ad_form_hide(); 
    
    // clear and Hide the adddetails if displayed
    $('#addetails').html("").hide(); 
    
    // clear and hide breadcrumbs
    $('#breadcrumbs').html("").hide();
    

      // ------------------- display the NAV banner  -----------------------  
      t_nav += '<div class="clear" id="listings-nav">  ';       
      // ---------- breadcrumb -----------------
      var ax = new Array();
      ax.push({text : $.i18n._('Main List') , href : '#action=back', cl : 'home', help:'yes'});
      ax.push({text : $.i18n._(nav) , href : '#nav=admin&what=dashboard', cl :''});
      if (search) 
        ax.push({text : $.i18n._("search") , href : '#', cl :''});
      ax.push({text : $.i18n._("all vfields") , href : '#', cl :''});
      
      // display the breadcrumb
      t_nav += '<ul id="breadcrumbsul" class="clear">'; 
      $.each(ax, function(i, elem) {
      if ((i+1)==ax.length)
        t_nav += '<li>'+elem.text+'</li>';
      else {
        if (elem.help=="yes") tt =  'title="'+$.i18n._('help link '+elem.text)+'"'; 
        else tt=""; 
      t_nav += '<li><a name="list_ads" href="'+elem.href+'" class="'+elem.cl+'" '+tt+'>'+elem.text+'</a></li>';
      t_nav += '<span>&gt</span>';
      }});
      t_nav += '</ul>';
    
    
      // text with nbr of items
      if (search && search!="") searchtxt = $.i18n._('containing <b>%s</b> word',[search]); else searchtxt=""; 
      t_nav += ' <div class="text-nav">'+searchtxt; 
      t_nav += '</div>';

      // navigation arrow 
      t_nav += build_gen_nav_pages(what,totaladnbr,paged,elems_per_page ); 

      t_nav += ' <div class="clearer">&nbsp;</div>'; 
      t_nav += '</div>  '; 
                     
      // ---------------  start displaying the list of items  ---------------   

      var t=''; var th=''; var tlh=''; 
      var cumulqty=0, cumulsize=0;

    // ---------------  start displaying the list of items  ---------------   
    t = ' <div  id="logs">';

    if (d.data.length>0) {
          
        // display the table chart  ! ( DEFINE THE FIELDS )
        esw=["id","int_label", "disp_label", "preview", "unit", "scope", "forwhat", "status", "actions"];
        //table = create_table_chart(alldata.data,coldata,'',20,'logsmode'); 
        th+='<div id="logs"><table><thead> <tr>';
      for (var ix=0; ix<esw.length;ix++){ th+='<th class="text">'+$.i18n._(esw[ix])+ '</th>';};
      th+='</tr></thead><tbody>'; 
      var nb=0; 
      $.each(d.data, function(i, e) {
         
        th+='<tr>';cumulqty+=1; e.title=e.int_label; e.desc=e.disp_label; //do it for the dialog box ! 
        for (var ix=0; ix<esw.length;ix++){
          ekey =esw[ix];
          cl=(i=0)? 'text' : 'text'; elemval = (typeof e[ekey] !== 'undefined') ? e[ekey] : ''; 
          if (ekey=="moddatestamp") elemval = convert_delta_date_2_String(elemval, true); 
          if (ekey=="preview") elemval = vield_2_html(e); 
          if (ekey=="status")  elemval =  '<div class="adlist_status '+ad_status_name[elemval]+'">'+elemval+'</div>';
          if (ekey=="actions") {
            elemval = '<a class="files-actions" name="vfield_action" z-action="update" z-id="'+nb+'" z-dbid="'+e.id+'" z-fname="'+e.int_label+'" title="'+$.i18n._("update")+'" href="#" ><i class="icon-fa-edit mr6"/></a>';
            elemval += '<a class="files-actions" name="vfield_action" z-action="clone" z-id="'+nb+'" z-dbid="'+e.id+'" z-fname="'+e.int_label+'" title="'+$.i18n._("clone")+'" href="#" ><i class="icon-fa-code-fork mr6"/></a>';
            elemval += '<a class="files-actions" name="vfield_action" z-action="delete" z-id="'+nb+'" z-dbid="'+e.id+'" z-fname="'+e.int_label+'" title="'+$.i18n._("delete")+'" href="#" ><i class="icon-fa-trash-o"/></a>';
          
          } // display the actions

          th+='<td class="'+cl+'">'+elemval+'</td>';
        }
         nb+=1; 
        
      });th+='</tbody></table><div>';
      table=th; 
      } else { 
          table = '<div class="noresults">'+$.i18n._("No fields defined yet")+'</div>';
      }
      t +=table;
      t += '</div>  '; 


      // -------- update header with content summary 
      tlh += '';  
      tlh += '<div class="clear" id="listings-header">  '; 
      tlh += '<ul class="files-infos">'; 
      tlh += '<li>'; 
      tlh += '<i class="icon-fa-file"/><span>'+$.i18n._n('%s vfield','%s vfields' , cumulqty,[cumulqty])+'</span>'; 
      tlh +='</li><li><a name="vfield_action" id="add_vfield_admin" what="vfield" href="" rel="" class="dm_button2"><i class="icon-fa-plus mr6"></i>'+$.i18n._('add vfield')+'</a>';
      

      // ACTION filter select
      tlh += '<li>'; 
      tlh += ' <ul class="sort-options-2">';      
      tlh += ' <span class="label">'+$.i18n._("scope")+'</span>';
      tlh +=  '<select name="filter_list" id="fscope" >';
      tlh += build_DOM_SELECT_options(vfield_filter_scope_options, d.fscope,''); 
      tlh +=  '</select>';
      tlh += ' </ul>';
      tlh += '</li>'; 

      // ACTION filter select
      tlh += '<li>'; 
      tlh += ' <ul class="sort-options-2">';
      tlh += ' <span class="label">'+$.i18n._("forwhat")+'</span>';
      tlh +=  '<select name="filter_list" id="fforwhat" >';
      tlh += build_DOM_SELECT_options(vfield_filter_forwhat_options, d.fforwhat,''); 
      tlh +=  '</select>';
      tlh += ' </ul>';
      tlh += '</li>'; 

      tlh += '</li></ul>  ';
      tlh += '</div>  ';

      // update the breadcrumb
      //update_DOM_breadcrumbs(0,0, 1, 'vfields');

      
      $('#adlist').hide().append(t_nav+tlh+t +t_nav).fadeIn(); 
      $('#addetails').html(); // clean up

      // activate the tooltips on new links
      activate_tooltip('.ttip');
        
       // ---------------  event handlers   ---------------                    
        // event handler for the ADD button 
       $('#adlist a[name=vfield_action]').click (function(e) {
         e.preventDefault();
         id = $(this).attr('z-id');
         dbid=  $(this).attr('z-dbid');
         action = $(this).attr('z-action');
         if (action=="delete"){
            display_DIALOG_BOX("Vfield delete confirmation", vfield_list[id],  "", "vfields=delete&id="+dbid, '','');
         } else if (action=="clone"){
          ajax_action("vfields=clone&id="+dbid); // launch the clone action 
         }
         else{
          if (id) elem_create_modify('modify', 'vfield', id, ''); 
          else elem_create_modify('create', 'vfield', '', ''); 
        }
         return true; 
       });

        // event handler for all the SELECT filters
        $('#adlist .sort-options-2 SELECT').change(function() {  
           var ahref = "vfields=list";
           var filterparams = grab_all_filters3('listings-header'); 
           var filter_plus=""; 
           ajax_action (ahref+filterparams+filter_plus, cur_nav_ajax);
           //add to navigation history
           //addToNavigatorHistory(ahref+filterparams+filter_plus);
           return false; 
        });
                
        function grab_all_filters3(mainid){
          var fql=""; 
          var filterzone =  $('#'+mainid); 
          // loop though each filter to get the exact AJAX PARAM  
          filterzone.find('ul > select').each(function(idx,elem){
              filtername = $(this).attr('id');
              selelem = $(this).find("option:selected"); 
              fql+="&"+filtername+"="+selelem.val();
          });       
          return fql; 
        }

        // navigation and breadcrumb display 

        // set the actions handlers for breadcrumb
        $('#adlist #breadcrumbsul a[name=list_ads]').click (function(e) {
          e.preventDefault();
          gen_navigation_dispatcher($(this));  
          return true; 
        });
       
        // event handler for navigation links / page next 
        $('#adlist #listings-nav a[name=filter_list]').click (function(e) {
         e.preventDefault();
         ahref = $(this).attr('href');
         var tmpx = ahref.split("#");
         ahref = tmpx[tmpx.length-1]; // get just the final elements after latest # to correcr IE bug.
          
         var filterparams = grab_all_filters3('listings-header'); 
         // type and catid
         filter_plus=""; 
         if(type) filter_plus+="&type="+type; 
         if (catid)filter_plus+="&catid="+catid; 
         ajax_action (ahref + filterparams +filter_plus, cur_nav_ajax); 

         // merge the actions and add to navigation history
         mhref = merge_href(ahref,cur_nav_ajax);          
         addToNavigatorHistory(mhref);     

         return true; 
       });


    
    
    return true; 
}; 


function display_translation(textfilter){
  var t='', tbt='', i=0, cl=''; 
  var dico = my_dictionary[cur_lang];

  // -- build the table
  t+='<div id="transData">'; 
  t+='<table><tbody>'; 
  t+='<tr><th>idx</th><th>Base</th><th style="width:40%;">'+cur_lang+'</th><th style="width:40%;">newvalue</th></tr>'; 
  $.each(dico, function(key, value) {
    i++; cl=''; 
    // extra qualification
    var input="desc_";  if (key.substring(0, input.length) === input) cl += " desc_ "; 
    var input="help_";  if (key.substring(0, input.length) === input) cl += " help_ "; 
    t+='<tr class="word '+cl+' "><td>'+i+'</td><td>'+key+'</td><td>'+value+'</td><td><input type="text" style="width:100%;  border:1px solid #EEE;"/></td></tr>';
    // if (i>1000) return false ; 
  }); 

  t+='</tbody></table>';
  t+='</div>';  

  // -- add the export in XLS button
  tbt += '<div class="clear" id="listings-header">';
  tbt += '<ul class="sort-options"><a name="" id="" what="" type="" href="#" rel="" class="dm_button2 action" z-action="exportxls"><i class="icon-fa-plus"></i>'+$.i18n._("export to XLS")+'</a></ul>';
  tbt +=' <ul class="sort-options"><span class="words-counter">'+$.i18n._n("%s word","%s words", i, [i])+'</span></ul>';
  tbt +=' <ul class="sort-options"><input name="desc_" z-action="filter" id="" type="checkbox" class=" checkboxx" value="yes" checked ><span class="">'+$.i18n._("include desc_")+'</span> </ul>';
  tbt +=' <ul class="sort-options"><input name="help_" z-action="filter" id="" type="checkbox" class=" checkboxx" value="yes" checked ><span class="">'+$.i18n._("include help_")+'</span> </ul>';
  tbt += '</div>';

  // -- display it 
  clean_allcontent();
  $('#adlist').hide().html(tbt+t).fadeIn(); 

  // -- update breadcrumb
  update_DOM_breadcrumbs(0,0, 1, 'translation');

  // -- event management 
  $('#adlist .action').click (function(e) {
     e.preventDefault();
     var za= $(this).attr('z-action');
     if ( za== "exportxls"){
      // window.open('data:application/vnd.ms-excel, ' + $('#transData').html());
      window.open('data:application/vnd.ms-excel;base64, ' + base64_encode($('#transData').html()));      
     }
  }); 

  $('#adlist   input[type=checkbox]').change(function () {
      var ischecked= $(this).is(':checked');
      var za= $(this).attr('z-action');
      var name= $(this)[0].name;
      var obj=$('#transData table tr.'+name); 
      if (!ischecked) obj.hide();
      else obj.show();
      
      var numOfVisibleRows = $('#transData table tr:visible').length;
      $('.words-counter').html($.i18n._n("%s word","%s words", numOfVisibleRows, [numOfVisibleRows]));
  });




}




/**-----------------------------------------------------------------------------
* This function build and display the FILES / RESOURCES  LIST with special modifications pages 
* @param  {obj} alldata  - the JSON object containing the data (data) and options from RX
*-----------------------------------------------------------------------------*/ 
function display_DOM_files_list(alldata, what){
  var t=''; var th=''; var tlh=''; 
  var cumulqty=0, cumulsize=0;

  // ---------------  start displaying the list of items  ---------------   
    if (alldata.data.length>0) {
      // display the table chart  ! 
      if (what=="files") esw=["tn","name", "size", "modified", "actions"];
      if (what=="pages") esw=["tn","name", "size", "modified", "actions"];
      if (what=="emails") esw=["name", "actions"];

      th+='<div id="gen-files-list">';

      if (what=="emails") th+='<div id="" class="emails-list-left">'; 

      th+='<table class="content-list" ><thead> <tr>';
      for (var ix=0; ix<esw.length;ix++){ th+='<th class="text">'+$.i18n._(esw[ix])+ '</th>';};
      th+='</tr></thead><tbody>'; 

      $.each(alldata.data, function(i, e) {
        th+='<tr>';cumulqty+=1; cumulsize+=e['size']*1;

        for (var ix=0; ix<esw.length;ix++){
          ekey =esw[ix];
          cl=(i=0)? 'text' : 'text'; elemval = (typeof e[ekey] !== 'undefined') ? e[ekey] : ''; 
          if (ekey=="modified") { elemval = convert_delta_date_2_String(elemval*1000); cl+=" date";} 
          if (ekey=="size") {elemval = format("### ##0.#", elemval); }
          if (ekey=="tn") {
            if (in_array(e.ext, ['css', 'php', 'js', 'ico', 'htm', 'swf']) ) 
              xtn_src ='./img/fileicons/'+e.ext+'.png'; 
            else xtn_src =alldata.rooturl+'tn_'+e.name ;
            elemval = '<img class="files-img-tn" src="'+xtn_src+'" />';
          } // display the thumbnail
          if (ekey=="name") {
            if (what=="emails") // second line 
            {
             elemval ='<span style="font-size:1.1em;">'+$.i18n._("help_"+e.name)+'</span>';
             elemval += '<br><span>'+e[ekey]+'</span>';
             elemval +='<br><span class="date">('+convert_delta_date_2_String(e['modified']*1000)+')</span>';
            } else 
            elemval = '<a class="" href="'+alldata.rooturl+e.name+'" target="_blank">'+elemval+'</a>';

          } // display a link to the object
          if (ekey=="actions") {
              cl ="center"; // force a center  
              if (what!="emails") elemval = '<a class="files-actions" z-action="delete" z-fname="'+e.name+'" title="'+$.i18n._("delete")+'" href="#" ><i class="icon-fa-trash-o mr6"/></a>';
              if (in_array(e.ext, ['css', 'php', 'js', 'htm']) || what=="emails" ) 
                elemval += '<a class="files-actions" z-action="read" z-fname="'+e.name+'" title="'+$.i18n._("edit")+'" href="#" ><i class="icon-fa-edit"/></a>';
            
          } // display the actions

          th+='<td class="'+cl+'">'+elemval+'</td>';
        }
        
      });
      th+='</tbody></table>'; 
      // end the table 

      if (what=="emails") th+='</div><div id="" class="email-editor-wrapper emails-list-right"><div class="edit-empty">'+$.i18n._("Click on "+what+" to view and edit")+'</div></div>'; 

      // end the section
      th+='<div>';
      table=th;

    } else { 
        table = '<div class="noresults">'+$.i18n._("No "+what+" in directory.")+'</div>';
    }
    t +=table;
    t += '</div>  '; 

    // update header with content summary 
    tlh += '';  
    tlh += '<div class="clear" id="listings-header">  '; 
    tlh += '<ul class="files-infos">'; 
    tlh += '<li>'; 
    tlh += '<i class="icon-fa-file"/><span>'+$.i18n._n('%s file','%s files' , cumulqty,[cumulqty])+'</span> - '; 
    tlh += '<span>'+$.i18n._n('%s Bytes','%s Bytes' , cumulsize,[format("### ##0.#", cumulsize)])+'</span>';

    // display the button 
    if (what=="files"){
      if (display_settings.files_manager_max_nbr && cumulqty>display_settings.files_manager_max_nbr) {
        tlh += '</li><li><span class="error"><i class="icon-fa-warning mr6 fs12"></i>'+$.i18n._("cannot upload more file : exceeded quantity")+'</span>';
      } else  tlh += '</li><li><a name="add_item" id="add_file" what="file" type="file" href="" rel="" class="dm_button2 uploadbtn"><i class="icon-fa-plus"></i>'+$.i18n._("upload file")+'</a>';
    }
    
    tlh += '</li></ul>  ';
    tlh += '</div>  ';

    // update the breadcrumb
    update_DOM_breadcrumbs(0,0, 1, what);

    // --- DISPLAY 
    $('#addetails').html(''); // clean up
    $('#forminput').html('').hide(); // clean up
    $('#adlist').hide().html(tlh+t).fadeIn(); 

    // ACTIVATE file handlers 
    if (what=="file" || what=="files"  || what=="pages" ) { activate_FILEUPLOAD("files",$('.files-infos'), "ressources"); }

     $('#adlist .files-actions').click (function(e) {
         e.preventDefault();
         if ($(this).attr('z-action') == "delete") {
          var aparam = what+"=delete&fname="+$(this).attr('z-fname'); 
          display_DIALOG_BOX("Confirm deletion",{title:$(this).attr('z-fname'), id:''},  "Please confirm deletion of the file : ", aparam);  
        }

        if ($(this).attr('z-action') == "read") {
          var aparam = what+"=read&fname="+$(this).attr('z-fname'); 
          ajax_action(aparam);  
        }

     }); 

      // handler in case an image is broken
      $('.files-img-tn').error(function () {
              imgfullurl = "./img/img_missing.png"; 
              $(this).unbind("error").attr("src", imgfullurl);
      });

  return true; 
}


/**-----------------------------------------------------------------------------
* This function display a text editor 
* @param  {string} textareaid  the DOM ID of the text editor
* @param  {string} context  : indicate the context : "inelemform" | ""
*-----------------------------------------------------------------------------*/  
function display_zeditor(textareaid, context){
  var t='', ttool='',tedi='';

  // build the toolbar 
  ttool+='<ul class="zeditor-toolbar">'; 
  // if (context!="inelemform"){
    ttool+='<li class="plainrichswitcher"><a href="#" class="re-icon  icon-fa-code"       z-cmd="togglehtml" ></a></li>';
  // }

  ttool+='<li class="forrich" ><a href="#" class="re-icon  icon-fa-bold"       z-cmd="bold"></a></li>';
  ttool+='<li class="forrich" ><a href="#" class="re-icon  icon-fa-italic"     z-cmd="italic" ></a></li>';
  ttool+='<li class="forrich" ><a href="#" class="re-icon  icon-fa-underline"  z-cmd="underline" ></a></li>';
  
  if (context=="inelemform"){
    ttool+='<li class="forrich" ><a href="#" class="re-icon  icon-fa-strikethrough"  z-cmd="strikeThrough" ></a></li>';
    ttool+='<li class="forrich" ><a href="#" class="re-icon  icon-fa-subscript"  z-cmd="subscript" ></a></li>';
    ttool+='<li class="forrich" ><a href="#" class="re-icon  icon-fa-superscript"  z-cmd="superscript" ></a></li>';

    ttool+='<li class="forrich" ><a href="#" class="re-icon  icon-fa-undo"  z-cmd="undo" ></a></li>';
    ttool+='<li class="forrich" ><a href="#" class="re-icon  icon-fa-repeat"  z-cmd="redo" ></a></li>';

    ttool+='<li class="forrich" ><a href="#" class="re-icon  icon-fa-align-left"  z-cmd="justifyLeft" ></a></li>';
    ttool+='<li class="forrich" ><a href="#" class="re-icon  icon-fa-align-center"  z-cmd="justifyCenter" ></a></li>';
    ttool+='<li class="forrich" ><a href="#" class="re-icon  icon-fa-align-right"  z-cmd="justifyRight" ></a></li>';
    ttool+='<li class="forrich" ><a href="#" class="re-icon  icon-fa-align-justify"  z-cmd="justifyFull" ></a></li>';
  }
  else {
    ttool+='<li class="forrich" ><a href="#" class="re-icon  icon-fa-list-ul"    z-cmd="insertUnorderedList" ></a></li>';
    ttool+='<li class="forrich" ><a href="#" class="re-icon  icon-fa-list-ol"    z-cmd="insertOrderedList" ></a></li>';
    ttool+='<li class="forrich" ><a href="#" class="re-icon  icon-fa-indent"     z-cmd="indent"></a></li>';
    ttool+='<li class="forrich" ><a href="#" class="re-icon  icon-fa-outdent"    z-cmd="outdent"></a></li>';
  }
  ttool+='<li class="forrich" ><a href="#" class="re-icon  icon-fa-link"       z-cmd="link"></a></li>';
  

  ttool+='</ul>'; 

  //build the editor 
  tedi+='<div class="zeditor-editor" z-for="'+textareaid+'" contenteditable="true" dir="ltr" style="display: block;"></div>';

  // build the editor 
  t+='<div id="zeditorbox_'+textareaid+'"  class="zeditor-box '+context+'  " z-for="'+textareaid+'" >';
  t+=ttool;
  t+=tedi;
  t+='</div>'; 

  //-- display it in the right place
  var genuine_tarea=  $("#"+textareaid); 
  genuine_tarea.before(t) ; 
  genuine_tarea.hide(); 

  // update content if alraedy has something
  genuine_tarea.parent().find('.zeditor-editor').html(genuine_tarea.val()); 
  var genuine_teditor = genuine_tarea.parent().find('.zeditor-box'); 

  // event handler 
  $('#zeditorbox_'+textareaid+' .zeditor-toolbar li a ').click (function(e) {
      e.preventDefault();
      var cmd = $(this).attr('z-cmd');
      // 1 > LI > UL > TOP
      var teditor = genuine_teditor.find('.zeditor-editor'); 
      var ttarea =  $('#'+teditor.attr('z-for')); // genuine textarea

      if (cmd=="togglehtml"){
        if (teditor.is(':visible')) {
          ttarea.val(teditor.html()); 
          $('.zeditor-toolbar li.forrich').hide() ; 
        }
        else {
          teditor.html(ttarea.val()); // copy contents
          $('.zeditor-toolbar li.forrich').show() ; 
        } 
        ttarea.toggle(); teditor.toggle(); // toggle thedisplay 
      } else {
        if (cmd=="link"){
          var url = prompt("Enter the URL");
          document.execCommand("createLink", false, url);
        }
        else document.execCommand(cmd, false, null);
        // DOCUMENTATION : https://developer.mozilla.org/en-US/docs/Web/API/document/execCommand
        // in all cases, coy the content
        ttarea.val(teditor.html()); // copy contents from each content
        char_check(ttarea); // check chars if counter exists
      }


   }); 

   // even handler for editable content change
      $(".zeditor-editor, .zeditor-input ").on('change keyup paste', function() {
        $('.file-modified').show();
        var tareaObj =  $('#'+$(this).attr('z-for')); 
        tareaObj.val($(this).html()); // copy contents from each content
        char_check(tareaObj); // check chars if counter exists
   });

}

/**-----------------------------------------------------------------------------
* This function display edit section 
* @param  {obj} filedata  - the JSON object wih name /content, ... 
*-----------------------------------------------------------------------------*/  

function display_edit_file(filedata, what, wheretodisplay){

  var t='', th='',tfn=''; 
  tfn =  filedata.name; 

  t+= ' <div  id="file_editor">';

  t+='<div class="labelform_label fullwidth filenameheader "><span class="file-title">('+tfn+')</span>'; // name 
  t+='<span class="file-modified hideit">'+$.i18n._("* modified - don't forget to save!")+'</span>'; // name 

  // Actions BUTTONS
  t+='<div class="file-actions"><ul class="actions">',
  t+='<li><a name="" id="" what="file" z-action="save"  z-fname="'+tfn+'" href="" rel="" class="dm_button2 action"><i class="icon-fa-save"></i>'+$.i18n._("save")+'</a></li>';
  
  if (what=="emails") 
    t+='<li><a name="" id="" what="file" z-action="test"  z-fname="'+tfn+'" href="" rel="" class="dm_button2 action"><i class="icon-fa-envelope"></i>'+$.i18n._("send you a test email")+'</a></li>';
  
  // if (what!="emails") 
    t+='<li><a name="" id="" what="file"  z-action="cancel"  z-fname="'+tfn+'" href="" rel="" class=" action"><i class="icon-fa-cancel"></i>'+$.i18n._("cancel")+'</a></li>';
  t+='<div class="clearer">&nbsp;</div></ul></div>'; 

  t+='</div><div class="clearer">&nbsp;</div>';
  // TEXT AREA 
  
  //for emails : add the subject 
  if (what=="emails"){
    subjectvalue = base64_decode(filedata.subjectencoded);
    t+='<div><strong>'+$.i18n._("Email subject")+'</strong></div>'; 
    t+='<div><input class="text zeditor-input" type="text" name="subject" id="file_subject" value="'+subjectvalue+'"></div>';

    t+='<div><strong>'+$.i18n._("Email content")+'</strong></div>'; 
  }

  htmlvalue = base64_decode(filedata.htmlencoded);
  t+='<textarea style="width:100%;"  class="zeditor-textarea" cols="140" rows="50" name="htmlcode" id="file_raw_content">'+htmlvalue+'</textarea><div class="clearer">&nbsp;</div>';

  t += ' </div>'; 

  // --- display it in default location or where specified
  if (what=="files" || what=="pages") wheretodisplay =  '#addetails';  // bypass 
  $(wheretodisplay).html(t).show();

  // --- add the text editor if PHPor HTML
  var ext = tfn.substr(tfn.lastIndexOf('.') + 1);
  if (in_array(ext, ['htm', 'html'])){
    if (filedata.hasOwnProperty('isplaintxt')) {
      if (!filedata.isplaintxt)
        display_zeditor('file_raw_content'); 
    } else display_zeditor('file_raw_content'); 
  } 
    
    // event handler
  $('#file_editor .action').click (function(e) {
      e.preventDefault();
      var ta= $(this).attr('z-action');
      if (ta =="cancel") {
        $('#file_editor').slideUp().empty(); 
      } 
      else if (ta =="save") {
        // copy content from both sides depending on which one is active. 
        var teditor = $('.zeditor-editor'), ttarea =  $('.zeditor-textarea') ; 
        if (teditor.is(':visible')) ttarea.val(teditor.html()); else teditor.html(ttarea.val()); // copy contents 
        // var td= base64_encode($('#file_raw_content').val()); //encode because of &chars)
        // !!!! note : we don't sent in base68 encode because this causes Bugs in decoding process (PHP) if <tags> presents
        var td= $('#file_raw_content').serialize();
        if (what=="emails") td+='&'+$('#file_subject').serialize();
        ajax_action(what+"=save&fname="+$(this).attr('z-fname')+"&"+td);
         $('.file-modified').hide();
      } else if (ta =="test"){
        ajax_action(what+"="+ta+"&fname="+$(this).attr('z-fname')+'&email='+cur_user.email); 
      }
   }); 

  // even handler for editable content change
   $(".zeditor-textarea, .zeditor-input").on('change keyup paste', function() {
      $('.file-modified').show();
   });

}


/**-----------------------------------------------------------------------------
* This function build and siaplay the twitter box  
* @param {string}  title  : title to be displayed ont top of dialog box
* @return {boolean} TRUE when everything goes well
*-----------------------------------------------------------------------------*/

function display_TWITTER_BOX(title, ad_id,  innercontent, ajaxcall){
  t ="";
  
  t += '<div id="twitter-container">'; 
  
  t += '<div id="twitter-header"><div></div>';
  t += '<span>'+$.i18n._('twitter header')+'</span>';
  t += '</div>';
  
  t += '<form id="tweetForm" action="#" method="post">';
  t += '  <span class="counter">140</span>';
  t += ' <label for="inputField">'+$.i18n._('What are you doing?')+'</label>';
  
  t += ' <textarea name="twstatus" id="inputField" tabindex="1" rows="2" cols="40"></textarea>';
  t += '  <input id="tw-submit" class="submitButton inact" name="submit" type="submit" value="Tweeter" disabled="disabled" />  ';  
  t += '  <div class="clear"></div>';
  
  t += '  </form>';
  t += '  <h3 class="timeline">'+$.i18n._('Timeline')+'</h3>';
  t += '  <ul class="statuses" id="twitter-list">';
  t += ' <li><img class="tw-loading" style="padding:12px" src="img/loading2x16.gif" alt="loading" width="16" height="16" /><div class="tweetTxt">'+$.i18n._('Loading your tweets...')+'</div>';
  t += '<div class="clear"></div></li>';
  t += '</ul>';
  t += ' </div>';
  
  // display it. 
  $('#addetails').html(t).slideDown();
  update_DOM_breadcrumbs(0,0, 1, 'twitter');
  
  // attach event handlers 
  $('#tweetForm #inputField').bind("blur focus keydown keypress keyup", function(e){tw_recount(e);});
  $('#tweetForm input.submitButton').attr('disabled','disabled');
  
  tw_init("mytweet"); 

   $('#tw-submit').click (function(e) {
     e.preventDefault();
     tw_send();   
     return true; 
   });
  return true; 
}; 


// // globalization of 
function build_D_E_SPECIAL(elem, iname, domtype, iclass, section, whereisval,valuesAr, parentn){
  var t='', xtraattr='',icl='';
  var xname=iname;
  var xnamedisp=xname;
  var xval=(whereisval=="val") ? elem.val : elem[xname] ; 

  xname=(iname=="v") ? elem.n+'_v' : xname ; // patch name 
  xname=(parentn) ?  parentn+"_"+elem.n+"_"+iname : xname; // case of pricing 
  icl = domtype ; 

  // patch inputclass for L1, L2, ... 
  if (iclass.indexOf('l3') != -1){ icl+=" l3";} 
  else  if (iclass.indexOf('l2') != -1){ icl+=" l2";} else  icl+=" l1"; //defautl L1 

  t += '<div class="elem">';
  t += '<span class="'+iclass+'">'+$.i18n._("settings_"+xnamedisp)+'</span>'; 
  if (domtype.indexOf('input') != -1){
    t += '<input name="'+xname+'" id="" size="30" type="text" class="text '+icl+'" value="'+xval+'"  '+xtraattr+'>';
  }

  if (domtype.indexOf('textarea') != -1){
    t += '<textarea name="'+xname+'" id="" rows="1" maxlength="300" cols="30" class="text '+icl+'" value="'+xval+'"  '+xtraattr+'>';
  }

  if (domtype.indexOf('checkbox') != -1){
    elemchecked=((xval===false) || (xval==="false") || xval=="no") ?  "" : "checked";
    t += '<input name="'+xname+'" id="" size="30" type="checkbox" class="text '+icl+'" value="true"  '+elemchecked+' '+xtraattr+'>';
  }

  if (domtype.indexOf('radio') != -1){
   $.each(valuesAr, function(i, e) {
      var radiochecked= (xval==e) ? ' checked="checked"' : '';
      // make xname unique otherwise this does not work ! 
      radioname=elem.id+'_'+xname; 
      t += '<input name="'+radioname+'" orig_name="'+xname+'" id="" size="30" type="radio" class="text '+icl+'" value="'+e+'"  '+radiochecked+' '+xtraattr+'>'+$.i18n._("settings_radio_"+e);
    });
  }

  t += '</div>';

  return t;
};

/**-----------------------------------------------------------------------------
* This function get the email routing file in JSON format, display it and allow for changes 
* @param {scope}  : optionnal  : indicate if it's the global dashboard of the "MY" one.
* @return TRUE
*-----------------------------------------------------------------------------*/
var allroutes=[] ; 
function display_special_json_settings(subaction, alldata ){
    console.log(alldata);
    allroutes=alldata.data ;
    var t='', th=''; 

    t+='<div class="'+subaction+'">'; 

    // for edition section
    t+= '<div class="email-editor-wrapper"></div>';
    t+='<div class="clearer">&nbsp;</div>'; 

    $.each(allroutes, function(what, routesforwhat) {
      // each what
      t+='<div class=""><div class="title_level1">'+$.i18n._(what)+'</div>' ; 
      $.each(routesforwhat, function(state, routesforstatus) {
        // each what
        if (in_array(what, ['user', 'ad', 'service', 'curuser']))   t+='<div class="level2"><div class="title_level2">'+$.i18n._(ad_status_name[state])+'' ;  
        else t+='<div class="level2"><div class="title_level2">'+state+'';

        // optionto add a new route
        t+='<br><a id="" z-what="'+what+'" z-state="'+state+'" z-action="addroute"  z-fname="" href="" rel="" class=" addroute action"><i class="icon-fa-plus mr6"></i>'+$.i18n._("add route")+'</a>';

        t+='</div><div class="left">' ;  

        $.each(routesforstatus, function(i, route) {

          // cleanup of json forman
          if (!route.hasOwnProperty('en')) route.en=true; 
          if (route.hasOwnProperty('title')) delete route.title ; 
          if (route.hasOwnProperty('msgheader')) delete route.msgheader ; 
          if (route.hasOwnProperty('msginner')) delete route.msginner ; 
          if (route.hasOwnProperty('msgfooter')) delete route.msgfooter ; 

          // help
          to = route.to;
          if (in_array(what, ['user', 'ad', 'service', 'curuser']) && route.to=="USER") to="owner"; 
          var filename  = to+'_'+what+'_'+state+'.html'; 
          filename = filename.toLowerCase();
          // var filefqdn =  "./phpsvr/locale_emails/fr_FR/"+filename ; 
          var helptxt = 'help_'+filename ;  

          t+='<div class="level3">';

          // check box to activate or not 
          var tchecked =  (route.en) ? "checked" : "";
          t+='<input type="checkbox" name="en" z-state="'+state+'" z-fname="'+filename+'" z-what="'+what+'" z-i="'+i+'" '+tchecked+' ><span class="item item2">'+route.to+'</span>';

          // ACTIONS BUTTONS
          // t+='<span class="item item3"><a name="" id="" what="file" z-action="save"  z-fname="" target="blank" href="'+filefqdn+'" rel="" class="action"><i class="icon-fa-search-plus mr6 "></i>'+$.i18n._("view")+'</a></span>';  
          t+='<span class="item item5"><a name="" id=""  z-action="read"  z-what="emails" z-fname="'+filename+'" target="blank" href="#" rel="" class="action"><i class="icon-fa-edit mr6 "></i>'+$.i18n._("edit email")+'</a></span>';  
          t+='<span class="item item5"><a name="" id=""  z-action="delete"  z-state="'+state+'" z-what="'+what+'" z-i="'+i+'" z-to="'+to+'" target="blank" href="#" rel="" class="action"><i class="icon-fa-trash mr6 "></i>'+$.i18n._("delete email")+'</a></span>';  
          t+='<span class="item item5"><a name="" id=""  z-action="test"  z-state="'+state+'" z-what="'+what+'" z-i="'+i+'" z-to="'+to+'" z-fname="'+filename+'" target="blank" href="#" rel="" class="action"><i class="icon-fa-envelope mr6 "></i>'+$.i18n._("test email")+'</a></span>';  

          t+='<span class="item item4 file-title">'+$.i18n._( helptxt)+'</span>';  


          t+='</div>';
        }) // end each ROUTE
        t+='</div></div><div class="clearer">&nbsp;</div>';
      }); 

      t+='</div>';
    }); 
    t+='</div>';


    // header
     // Actions BUTTONS TOP
    th+='<div><ul class="subaction-nav actions">',
    th+='<li><a name="" id="" z-what="emails" z-action="saveroutingtable"  z-fname="" href="" rel="" class="dm_button2 action"><i class="icon-fa-save"></i>'+$.i18n._("save routingtable")+'</a></li>';
    th+='<li><a name="" id="" z-what="emails" z-action="sendallmails"  z-fname="" href="" rel="" class="dm_button2 action"><i class="icon-fa-envelope"></i>'+$.i18n._("test all emails")+'</a></li>';
    th+='<div class="clearer">&nbsp;</div></ul></div><div class="clearer borderbottom">&nbsp;</div>';


    t=th+t; 
    // display
    $('#adlist').html('').hide();
    $('#forminput').html('').hide();
    $('#addetails').html(t).show();

    // update the breadcrumb
    update_DOM_breadcrumbs(0,0, 1, subaction);


    // make an ajax call to sanitize existance of emails
    $('#addetails  input[type=checkbox]').each(function(){
      var fn = $(this).attr('z-fname');
      var inputObj  =$(this); 
      twhat ="emails"; ta="exist"; 
      totalajaxdata = twhat+"="+ta+"&fname="+fn; 
      serverurl =  "phpsvr/emails_templates_server.php";
      $.ajax({
        type: "POST", url: serverurl, data: totalajaxdata,dataType: "json",  
        success:  function(data){
          if (data.success) t='<span class="icon-fa-check mr6" style="color:green;"></span>';
          else t='<span class="icon-fa-times mr6" style="color:red;"></span>';
          inputObj.next().after(t);
          if (data.data.title){
            // replace title 
            inputObj.parent().find('.file-title').html('* '+data.data.title) ; 
          }
        }
      });

    }); 

    //---------- even handlers 
    // -- actions on checkboxes 
    $('#addetails  input[type=checkbox]').change(function () {
      var val = $(this).is(':checked')
      allroutes[ $(this).attr('z-what')][ $(this).attr('z-state')][ $(this).attr('z-i')].en = val ; 
    });

    // -- all others actions 
    $('#addetails .action').click (function(e) {
        e.preventDefault();

        var twhat = $(this).attr('z-what');
        var ta = $(this).attr('z-action'); 
        var fn = $(this).attr('z-fname');
        var fstate = $(this).attr('z-state');
        var fi = $(this).attr('z-i');
        var fto = $(this).attr('z-to');

        if (ta == "read") {
          var aparam = twhat+"=read&fname="+fn; 
          ajax_action(aparam);  
        }
        else if (ta =="cancel") {
          $('#addetails').slideUp().empty(); 
        }
        else if (ta =="test"){
         ajax_action("emails="+ta+"&fname="+fn+'&email='+cur_user.email+"&fwhat="+twhat+'&fto='+fto+'&fstate='+fstate); 
        }
        else if (ta =="sendallmails"){
          afterajax = twhat+"="+ta+'&email='+cur_user.email ; 
          display_DIALOG_BOX(ta+" confirmation title",'', ta+" confirmation body",afterajax, '','');
        }
        else if (ta =="saveroutingtable") {
          dout = JSON.stringify(allroutes) ; 
          ajax_action(twhat+"="+ta+"&fname="+fn+'&payload='+dout+'&email='+cur_user.email); 
        }
        else if (ta=="addroute"){
          // display dialog box
          //t='<div class="labelform "><div>Nom de Domaine FQDN : </div></div>'; 
          //t+='<div class="adinput "><input name="domain_fqdn" id="domain_fqdn" size="undefined" maxlength="undefined" type="text" class="text input-xxlarge" value="http://localhost/zads60/"><div class="clearer">&nbsp;</div></div>';
          var ahref2='local=true&routes=add&what='+$(this).attr('z-what')+'&state='+$(this).attr('z-state')+'&i='+$(this).attr('z-i'); 
          var troutes= allroutes[ $(this).attr('z-what')][ $(this).attr('z-state')]; 
          destinations = build_destinations(troutes); 
          display_DIALOG_BOX("Confirm route add",'', "Please confirm route ad ", ahref2, "inselect", destinations);          
          // allroutes[ $(this).attr('z-what')][ $(this).attr('z-state')][ $(this).attr('z-i')].en = val ; 
        } else if (ta == "delete") {
          var ahref2='local=true&routes=delete&what='+$(this).attr('z-what')+'&state='+$(this).attr('z-state')+'&i='+$(this).attr('z-i'); 
          $(this).parent().addClass('todelete');
          display_DIALOG_BOX("Confirm deletion",{title:$(this).attr('z-to'), id:''},  "Please confirm deletion of this route : ", ahref2);  
        }

    }); 

}

function build_destinations(routes){
   // take each routes and remove the which one is existing 
   var out=[]; 
   out.push({ name : '-- select one destination --', value:0 ,  style:''}); 
   $.each(['ADMIN', 'USER', 'OWNER', 'ADMIN_REPORTS', 'SUPPORT', 'SALES' ], function( index, dest ) {
      exclude=false; 
      $.each(routes, function(i, route) {
        to = route.to; 
        if (to==dest){
          exclude=true; 
        }
      });
      if (!exclude){
        out.push({ name : dest, value : dest,  style:''}); 
      } 
   });
   return out; 
}; 


/**-----------------------------------------------------------------------------
* This function display the settings form for special cases 
* @param action : always CREATE
* @param what   : =settings 
* @param alldata   : all datas    
* @return TRUE
*-----------------------------------------------------------------------------*/
function display_special_settings_form(action,what,alldata){
  var t=''; var tht=''; 
  var data=alldata.data[0]; // extract the real interesting data ! 
  var sec =  alldata.section;

  // for payoptions, display name, oi, description, pricettc, priceht, enable, desc, 
  if (sec=="payoptions"){

    o_data =  data.options; 
    tht+='<h1 class="orange_text">'+$.i18n._("header text settings "+alldata.section)+'</h1>'; 
    tht+='<p>'+$.i18n._("header text paragraph "+alldata.section)+'</p>';

    t+='<div class="settings_special_wrapper">';

    // display the general enabling option 
    t+='<div class="labelform "><span>'+$.i18n._('desc_payoptions_enable')+'</span></div>';
    t+='<div class="option">';

    elemchecked=(data.enable) ? "checked": "";
    t += '<div class="elem">';
    t +=  '<div class="onoffswitch-wrapper">';
    t +=  '<input name="general_enable"   z-id="general_enable" id="general_enable"  type="checkbox" class="checkboxx onoffswitch-checkbox" value="true" '+elemchecked+' ></input>';           
    
    // special formating for the CSS SWITCH
    t +='<label class="onoffswitch-label" for="general_enable">';
    t +='<div class="onoffswitch-inner"></div>';
    t +='<div class="onoffswitch-switch"></div>';
    t +='</label>';
    t += '</div>';
    t += '</div>';

    t+='<div class="clear"></div>';
    t+='</div>';


    $.each(o_data, function(i, elem) {

    
      if (elem.type=='labeldummy' || elem.type=='servicedummy') 
        t+='<div class="option-spacer"></div>'; // display a spacer
      else {

         if  (elem.type=="label") clp=" islabel"; else clp=""; 
         t+='<div class="option '+elem.name+' '+clp+'">';

        // name 
        t+='<div class="labelform "><span>'+$.i18n._('post '+elem.name)+'</span></div>';

        elemchecked=(elem.en) ? "checked": "";
        t += '<div class="elem">';
        t +=  '<div class="onoffswitch-wrapper">';
        t +=  '<input name="en"   z-id="'+elem.name+'" id="'+elem.name+'" z_linkedobj="'+elem.z_linkedobj+'"  type="checkbox" class="checkboxx onoffswitch-checkbox" value="true" '+elemchecked+' ></input>';           
        
        // special formating for the CSS SWITCH
        t +='<label class="onoffswitch-label" for="'+elem.name+'">';
        t +='<div class="onoffswitch-inner"></div>';
        t +='<div class="onoffswitch-switch"></div>';
        t +='</label>';
        t += '</div>';
        t += '</div>';

        if  (elemchecked) displayclass=""; else  displayclass="hideit"; 

            // new line
          if (elem.type !='label'){
            // create a subsction 
            t+='<div class="clear"></div>';
            t+='<div class="option-subsection '+displayclass+' ">';
          }

            // desc
            t += '<div class="elem">';
            t += '<span class="first">'+$.i18n._("settings_desc")+'</span><input name="desc" id="" size="40" type="text" class="text input-medium" value="'+elem.desc+'">';
            t += '</div>';

          if (elem.type !='label'){
            // OI 
            t += '<div class="elem">';
            t += '<span>'+$.i18n._("settings_oi")+'</span><input name="oi" id="" size="30" type="text" class="text input-medium" value="'+elem.oi+'">';
            t += '</div>';

            // new line
            t+='<div class="clear"></div>';

            // services prices are managed by another field
            if (elem.type=="service"){
              t += '<div class="elem">';
              t += '<span class="first">'+$.i18n._("settings_price")+'</span><span>'+$.i18n._("Services prices are managed into the packs")+'</span>';
              t += '</div>';

            } else {
            // price HT
              t += '<div class="elem">';
              t += '<span class="first">'+$.i18n._("settings_priceTTC")+'</span><input name="price" id="" size="6" type="text" class="text input-mini" value="'+elem.price+'"><span>'+cur_currency+'</span>';
              t += '</div>';


              // price HT
              t += '<div class="elem">';
              t += '<span>'+$.i18n._("settings_priceHT")+'</span><input name="price_pro_ht" id="" size="6" type="text" class="text input-mini" value="'+elem.price_pro_ht+'"><span>'+cur_currency+'</span>';
              t += '</div>';
            
              // case of addpictures -> display the bn
              if (elem.name=="addpics"){
                t += '<div class="elem">';
                t += '<span>'+$.i18n._("settings_nb_addpics")+'</span><input name="nb" id="" size="6" type="text" class="text input-mini" value="'+elem.nb+'"><span>'+$.i18n._("pictures")+'</span>';
                t += '</div>';
              }



            }

            if (elem.type=="user-subscription"){
              // new line
              t+='<div class="clear"></div>';

              // en
              elemchecked=(elem.isrecurrent) ? "checked": "";
              t += '<div class="elem">';
              t += '<span class="first" >'+$.i18n._("settings_isrecurrent")+'</span>'; 
              t +=  '<div class="onoffswitch-wrapper">';
              t +=  '<input name="isrecurrent"  z-id="'+elem.name+'" id="'+elem.name+'_isrecurrent" z_linkedobj="'+elem.z_linkedobj+'"  type="checkbox" class="checkboxx onoffswitch-checkbox" value="yes" '+elemchecked+' ></input>';           
              
              // special formating for the CSS SWITCH
              t +='<label class="onoffswitch-label" for="'+elem.name+'_isrecurrent">';
              t +='<div class="onoffswitch-inner"></div>';
              t +='<div class="onoffswitch-switch"></div>';
              t +='</label>';
              t += '</div>';
              t += '</div>';


              // section for options related to recurrent billing   
              if  (elem.isrecurrent) displayclass=""; else  displayclass="hideit"; 
              t+='<div class="subsection-isrecurrent '+displayclass+'">';

                // BILLING PERIOD
                t += '<div class="elem radio-elem">';

                

                t += '<span>'+$.i18n._("settings_billingperiod")+'</span>';

                // construct the RADIO 
                var periodAr = ['Day','Week','Month','Year'];
                for(var i=0; i<periodAr.length; i++){
                  var period=periodAr[i];
                  var radiochecked= (elem.billingperiod==period) ? ' checked="checked"' : ''; 
                  t += '<input name="'+elem.name+'_billingperiod" id="" type="radio" class="text" value="'+period+'" '+radiochecked+' > '+$.i18n._(period);

                }

                t += '</div>';

                // BILLING CYCLE 
                t += '<div class="elem">';
                t += '<span>'+$.i18n._("settings_billingfrequency")+'</span><input name="billingfrequency" id="" size="30" type="text" class="text input-mini" value="'+elem.billingfrequency+'">';
                t += '</div>';
              
              t+='<div class="clear"></div>';
              t+='</div>';

            }



            // end subsection
            t+='<div class="clear"></div>';
            t+='</div>';

          }

      
    
        t+='<div class="clear"></div>';
        t+='</div>';



      } // end IF label 


    }); 
    t+='</div>';
  } // end IF section PAYOPTIONS 


  // --- case of FIELDS
  if (sec=="userfields" || sec=="adfields" ){

    // header 
    tht='<h1 class="orange_text">'+$.i18n._("header text settings "+alldata.section)+'</h1>'; 
    tht+='<p>'+$.i18n._("header text paragraph "+alldata.section)+'</p>';

    // wrapper
    t+='<div class="settings_special_wrapper tbl">';

    // each options 
    o_data =  data; 
    $.each(o_data, function (i,e){
      
      // -- display the elem 
      t += '<div class="elem tblrow field '+e.name+'">';

      var desc = (e.desc =="*" || e.desc=='') ?   'desc_'+e.name  : e.desc ; 
      t += '<div class="tblcell bold">'+$.i18n._(desc)+' ('+e.name+')</div>';

      if (e['disabled']) xdisabled= ' disabled="disabled"'; else xdisabled='';
      elemchecked=(e.en) ? "checked": "";
      t += '<div class="tblcell"><input name="en" type="checkbox" value="true" class="checkbox mr6" '+elemchecked+' '+xdisabled+' ><span>'+$.i18n._("is_enabled")+'</span></div>';
      elemchecked=(e.mandatory) ? "checked": "";
      t += '<div class="tblcell"><input name="mandatory" type="checkbox" value="true" class="checkbox mr6" '+elemchecked+' '+xdisabled+' ><span>'+$.i18n._("is_mandatory")+'</span></div>';
     
      // -- help 
      var thelp=''; 
      if (typeof e.help !== "undefined"){
        var helptitle = (e.help =="*" || e.help=='') ?   'help_'+e.name  : e.help ; 
        thelp='<span class="icon-menu ttip help" title="'+$.i18n._(helptitle)+'"><i class="help_icon_form icon-fa-question-circle mr6"></i>';
      }
      t += '<div class="tblcell">'+thelp+'</div>';


      t += '</div>';
    }); 


    // end wrapper
    t+='<div class="clear"></div>';
    t+='</div>';

  } // --- end FIELDS




  if (sec=="pricingplan")
  {

    o_data =  data.user; 
    tht+='<h1 class="orange_text">'+$.i18n._("header text settings "+sec)+'</h1>'; 
    tht+='<p>'+$.i18n._("header text paragraph "+sec)+'</p>';

    t+='<div class="settings_special_wrapper">';


    // display the general enabling option 
    t+='<div class="labelform "><span>'+$.i18n._('desc_payoptions_enable')+'</span></div>';
    t+='<div class="option">';

    elemchecked=(data.enable) ? "checked": "";
    t += '<div class="elem">';
    t +=  '<div class="onoffswitch-wrapper">';
    t +=  '<input name="general_enable"   z-id="general_enable" id="general_enable"  type="checkbox" class="checkboxx onoffswitch-checkbox" value="true" '+elemchecked+' ></input>';           
    
    // special formating for the CSS SWITCH
    t +='<label class="onoffswitch-label" for="general_enable">';
    t +='<div class="onoffswitch-inner"></div>';
    t +='<div class="onoffswitch-switch"></div>';
    t +='</label>';
    t += '</div>';
    t += '</div>';

    t+='<div class="clear"></div>';
    t+='</div>';


      $.each(o_data, function(i, elem) {

    
      if (elem.type=='labeldummy' || elem.type=='servicedummy') 
        t+='<div class="option-spacer"></div>'; // display a spacer
      else {

         if  (elem.type=="label") clp=" islabel"; else clp=""; 
         t+='<div class="option '+elem.id+' '+clp+'">';

        // name 
        t+='<div class="labelform "><span>'+$.i18n._('post '+elem.id)+'</span></div>';

        elemchecked=(elem.en) ? "checked": "";
        t += '<div class="elem">';
        t +=  '<div class="onoffswitch-wrapper">';
        t +=  '<input name="en"   z-id="'+elem.id+'" id="'+elem.id+'" z_linkedobj="'+elem.z_linkedobj+'"  type="checkbox" class="checkboxx onoffswitch-checkbox l1" value="true" '+elemchecked+' ></input>';           
        
        // special formating for the CSS SWITCH
        t +='<label class="onoffswitch-label" for="'+elem.id+'">';
        t +='<div class="onoffswitch-inner"></div>';
        t +='<div class="onoffswitch-switch"></div>';
        t +='</label>';
        t += '</div>';
        t += '</div>';

        if  (elemchecked) displayclass=""; else  displayclass="hideit"; 

            // new line
          if (elem.type !='label'){
            // create a subsction 
            t+='<div class="clear"></div>';
            t+='<div class="option-subsection '+displayclass+' ">';
          }

            // desc
          

          if (elem.type !='label'){

            t+=build_D_E_SPECIAL(elem, 'name', 'input-medium', 'first ',sec);
            t+=build_D_E_SPECIAL(elem, 'type', 'input-mini', '',sec);
            // t+=build_D_E_SPECIAL(elem, 'xtype', 'input-mini', '',sec);
            t+=build_D_E_SPECIAL(elem, 'xtype', 'radio xtype_radio', '',sec,'',['base', 'trial','pack']);

            t+=build_D_E_SPECIAL(elem, 'default', 'checkbox', '',sec);
            t+='<div class="clear"></div>';  // new line

            t+=build_D_E_SPECIAL(elem, 'desc', 'input-large', 'first ',sec);
            t+=build_D_E_SPECIAL(elem, 'pricedesc', 'input-medium', '',sec);
            t+='<div class="clear"></div>';  // new line

            t+=build_D_E_SPECIAL(elem, 'duration', 'input-mini', 'first ',sec);
            t+=build_D_E_SPECIAL(elem, 'bgcolor', 'input-mini', '',sec);
            t+=build_D_E_SPECIAL(elem, 'us_protype', 'input-mini', '',sec);

            t+='<div class="clear"></div>';  // new line
            t+=build_D_E_SPECIAL(elem, 'ca_restriction', 'input-medium', '',sec);
            

            t+='<div class="clear"></div>';  // new line
            // prices
            t+=build_D_E_SPECIAL(elem, 'prices_details', '', 'span-fullwidth',sec);
            t+='<div class="clear"></div>';  // new line
            t+=build_D_E_SPECIAL(elem, 'payoption', 'input-medium', 'first ',sec);
            t+='<div class="clear"></div>';  // new line
            // t+=build_D_E_SPECIAL(elem, 'price_type', 'radio price_type_radio', 'first ',sec,'',['flat', 'volume']);
            // t+='<div class="clear"></div>';  // new line
            if (elem.price.length>0 && elem.type=="v2"){
              $.each(elem.price, function(i, ep) {
                 t+=build_D_E_SPECIAL(ep, 'n', 'input-mini', 'first l3 ',sec,'','','pricegrid');
                 t+=build_D_E_SPECIAL(ep, 'ad_nb', 'input-mini', ' l3 ',sec,'','','pricegrid');
                 t+=build_D_E_SPECIAL(ep, 'ttc', 'input-mini', ' l3 ',sec,'','','pricegrid');
                 t+=build_D_E_SPECIAL(ep, 'ht', 'input-mini', ' l3 ',sec,'','','pricegrid');
                 t+='<div class="clear"></div>';  // new line
              });
            } else t+='<span>'+$.i18n._('Price to be defined in catalogue section for this reference')+'</span>'; 
            
            // delimiter 
            // list of fields which need an INPUT box 
            var isval= new Array(
              'us_subscription','us_skills','us_links','ad_links','ad_nb','ad_nbpics','ad_duration'
              ,'ad_nbvideos','ad_videourl','ad_audiourl','us_videourl','us_audiourl','ca_restricted'
              ,'free_text1', 'free_text2', 'free_text3'
            );

            // fields - ADS
            t+=build_D_E_SPECIAL(elem, 'ad_details', '', 'span-fullwidth',sec);
            t+='<div class="clear"></div>';  // new line
            $.each(elem.details, function(i, elem2) {
              if (elem2.n.indexOf('ad_')!=-1){
                t+=build_D_E_SPECIAL(elem2, 'v', 'checkbox', 'l2',sec); // visible flag
                if ($.inArray(elem2.n,isval)!=-1){
                  t+=build_D_E_SPECIAL(elem2, elem2.n, 'input-mini', 'span2 l2',sec,'val');
                } else {
                  t+=build_D_E_SPECIAL(elem2, elem2.n, 'checkbox', 'span2 l2',sec,'val');
                }
                t+='<div class="clear"></div>';  // new line
              }
            }); 

            // fields - USERS
            t+=build_D_E_SPECIAL(elem, 'us_details', '', 'span-fullwidth',sec);
            t+='<div class="clear"></div>';  // new line

            $.each(elem.details, function(i, elem2) {
              if (elem2.n.indexOf('us_')!=-1){
                t+=build_D_E_SPECIAL(elem2, 'v', 'checkbox', 'l2',sec); // visible flag
                if ($.inArray(elem2.n,isval)!=-1){
                  t+=build_D_E_SPECIAL(elem2, elem2.n, 'input-mini', 'span2 l2',sec,'val');
                } else {
                  t+=build_D_E_SPECIAL(elem2, elem2.n, 'checkbox', 'span2 l2',sec,'val');
                }
                t+='<div class="clear"></div>';  // new line
              }
            });

            // fields - FREE TEXTE
            t+=build_D_E_SPECIAL(elem, 'free_texts', '', 'span-fullwidth',sec);
            t+='<div class="clear"></div>';  // new line

            $.each(elem.details, function(i, elem2) {
              if (elem2.n.indexOf('free_')!=-1){
                t+=build_D_E_SPECIAL(elem2, 'v', 'checkbox', 'l2',sec); // visible flag
                if ($.inArray(elem2.n,isval)!=-1){
                  t+=build_D_E_SPECIAL(elem2, elem2.n, 'input-large', 'span2 l2',sec,'val');
                } else {
                  t+=build_D_E_SPECIAL(elem2, elem2.n, 'checkbox', 'span2 l2',sec,'val');
                }
                t+='<div class="clear"></div>';  // new line
              }
            });  

            // end subsection
            t+='<div class="clear"></div>';
            t+='</div>';

          }

      
    
        t+='<div class="clear"></div>';
        t+='</div>';



      } // end IF label 


    }); 
    t+='</div>';
  } // end IF section PRINCINGPLAN 



  // add the MENU and FORM WRAPPER
  if (t!='')
  {

    var st='';
    st+='<ul class="" id="settings_nav_menu">';
    $.each(alldata.sectionslist, function(i, e) {
       var thecl = (e.n==alldata.section)? 'active':''; // active menu 
       st+='<li class="'+thecl+'" id="">';
       st+='<a nottip="yes" class="" id="" name="settings_section_nav" title="'+$.i18n._('settings_menu_'+e.s)+'" z-href="settings=load&section='+e.n+'" href="#">';
       st+='<i class="icon-fa-'+e.i+'"></i>'; //icon 
       st+='<span>'+$.i18n._('settings_menu_'+e.s)+'</span>'; // text 
       if (e.local) st+='<span class=" flags '+cur_lang+'"></span>';
       
       st+='</a>';  
    });
    st+='</ul>';
    st+='<div class="clear"></div>';

    // add the session details 
    t += '<input type="hidden" name="section" value="'+alldata.section+'" />';
  
    var tb=''; 
    actionstr="settings=update"; value='40';
    if (ff) {ff=false; stc="default";}else stc="";
    tb += '<div class="adactions" align="center">';
    tb += '<div id="adactions_btons_inner"><ul id="bton_tools2">';
    tb += '<li class="'+stc+'"><a title="" what="'+what+'" href="#" z-href="'+actionstr+'&forceflag='+value+'" name="save" class="dm_button2" >';
    tb += '<i class="icon-fa-'+status_icon[value]+' mr6"></i>'+$.i18n._("BTN "+what+" "+ad_status_name[value]);
    tb += '</a></li>';
    tb +='</ul></div></div>';

    // finalize complement
    t='<div id="formsettings"><form id="form2" name="settings" class="settings-special">'+tht+st+t+tb+'</form></div>'; 
  }

  // display
  $('#addetails').html('').hide();
  $('#forminput').html(t).show();

  //activate keyboard handlers
  disable_keyboard_nav(); // reset 
  activate_keyboard_nav("admin_settings_form"); // activate the navigation

  /*-- handlers to manage settings displayed --*/

  $('#form2 #settings_nav_menu a[name=settings_section_nav]').click (function(e) {
     e.preventDefault();
     var zhref= $(this).attr('z-href');
     ajax_action(zhref);
     return true;  
  }); 

 $('#form2 .onoffswitch-checkbox').change(function(e) {
    var thisoption= $(this).attr('z-id'); 
    var thisname= $(this).attr('name'); 
    var targetsection =  (thisname=="en") ? ".option-subsection" : ".subsection-"+thisname; 
    $('#form2 .option.'+thisoption+' '+targetsection).toggleClass("hideit");
 });
  

  $('#form2 a[name=save]').click (function(e) {
    e.preventDefault();
    twhat = $(this).attr('what');
    var zhref= $(this).attr('z-href');

    
    // FIELDS 
    if (in_array(sec, ['userfields', 'adfields'])){
      $.each(o_data, function(i, elem) {
        rawobj = $('#form2 .field.'+elem.name);
        elem.en    = rawobj.find('input[name=en]').is(':checked');
        elem.mandatory    = rawobj.find('input[name=mandatory]').is(':checked');
      });
    }  

    // update all the json object with INPUT values before sendinf it  back 
    if (sec=="payoptions") {
      $.each(o_data, function(i, elem) {
        rawobj = $('#form2 .option.'+elem.name);
        elem.oi    = rawobj.find('input[name=oi]').val();
        elem.desc  = rawobj.find('input[name=desc]').val(); 

        if (elem.type=="service") elem.price = '';
        else {  
          elem.price = rawobj.find('input[name=price]').val();  
          elem.price_pro_ht = rawobj.find('input[name=price_pro_ht]').val();  
        }
        elem.en    = rawobj.find('input[name=en]').is(':checked');

        elem.isrecurrent = (rawobj.find('input[name=isrecurrent]').is(':checked')) ? "yes" : "";
        // elem.billingperiod = rawobj.find('input[name=billingperiod]').val();  
        elem.billingperiod = rawobj.find('input:radio[name='+elem.name+'_billingperiod]:checked').val();  
        elem.billingfrequency = rawobj.find('input[name=billingfrequency]').val(); 

        // case of nb pictures 
        if (elem.name=="addpics") elem.nb = rawobj.find('input[name=nb]').val(); 

        // default 
        elem.totalbillingcycles=0; 

      });
    }

    if (sec=="pricingplan") {
      $.each(o_data, function(i, elem) {
        rawobj = $('#form2 .option.'+elem.id);

        // allocate variable for the L1 step 
        $.each(rawobj.find('input.l1'), function (i,e){
          if ($(this).attr('type')=="text") var yval=  $(this).val(); 
          if ($(this).attr('type')=="checkbox") var yval= $(this).is(':checked'); 
          
          if ($(this).attr('type')=="radio") { 
            var yval=  $(this).val(); 
            if  ($(this).is(':checked')){
              elem[$(this).attr('orig_name')] = yval; // update the variable 
            }
          } else 
            elem[$(this).attr('name')] = yval; // update the variable 
        });

        // allocate variable for DETAILS 
        $.each(elem.details, function(i, elem2) {
          var inputelem_val = rawobj.find("input[name='"+elem2.n+"']"); 
          if (inputelem_val.attr('type')=="checkbox") elem2.val =  inputelem_val.is(':checked');
          else elem2.val =  inputelem_val.val();
          // visivility flag 
          elem2.v = rawobj.find("input[name='"+elem2.n+"_v']").is(':checked');
        }); 

        // allocate variable for PRICING GRID  
        $.each(elem.price, function(i, elem3) {
          elem3.ad_nb = parseInt(rawobj.find("input.l3[name='pricegrid_"+elem3.n+"_ad_nb']").val());
          elem3.ttc = parseFloat(rawobj.find("input.l3[name='pricegrid_"+elem3.n+"_ttc']").val());
          elem3.ht = parseFloat(rawobj.find("input.l3[name='pricegrid_"+elem3.n+"_ht']").val());
          //!! important to be at the end !! 
          elem3.n = rawobj.find("input.l3[name='pricegrid_"+elem3.n+"_n']").val();
        });


      });
    }

    // general_enable flag

    data.enable = $('#form2  input[name=general_enable]').is(':checked');
    
    if (sec=="payoptions") data.options=o_data;   
    if (sec=="pricingplan") data.user=o_data;
    if (in_array(sec, ['userfields', 'adfields'])) {
        
      // DEBUG, comect all fields the fisrt time
      // o_data=[]; // reset the table 
      // $.each(userform.form1, function  (i,e){
      //   xm = (typeof e.mandatory !== "undefined") ? ((e.mandatory=='yes') ?true : false)  : false ; 
      //   xh =  (typeof e.help !== "undefined") ?  e.help : ''; 
      //   o_data.push({name : e.name, desc :e.desc, en : true, mandatory : xm, help : xh}); 
      // });  

      data=o_data;
    }

    dout = JSON.stringify(data) ; 
    // if (sec=="pricingplan") return false; // quit debug


    ajax_action('settings=update&section='+alldata.section+'&payload='+dout ); 
  }); 
  
  return true;
};


/**-----------------------------------------------------------------------------
* This function is the main loop to launch Dashboard display 
* 
* @param {scope}  : optionnal  : indicate if it's the global dashboard of the "MY" one.
* @return TRUE
*-----------------------------------------------------------------------------*/

function display_DASHBOARD(scope){
  // stop here if not logged in
  //if ((!cur_user) || (cur_user.usertype!=9)){
  if (typeof scope == 'undefined') scope="";

  if ((!cur_user)){
    message = "This operation is not authorized !"; 
    displayMessage(message,false,'',"stats");
    return false; 
  } 
  if (scope) hashx = scope+'dashboard';
  else hashx = 'dashboard';
  
  $("#pages").hide();
  $("#forminput").hide();
  
  addToNavigatorHistory(hashx,'local'); 
  //load JS lib for graphs, when finished, this call the init-js_objects 
  HIGHSLIDE_loadScript(scope);  
    
  // initialize the display zone   
  init_dashboard_display(scope); 

  update_DOM_breadcrumbs('', 0, 1, scope+"dashboard"); 
 
  return true; 
}; 

/**-----------------------------------------------------------------------------
* This function update existing Graph with received datas
*
* @param {xwhat}  : string - the graph indicator
* @param {xdata}   : JSON array containing the data to be discplayed 
* @return {String} HTML content 
*-----------------------------------------------------------------------------*/
function update_graph(xwhat, xdata ){

    if (!xdata.serie1){
      // delete the previously created graph & add a genric text 
      $("#dash > #"+xwhat+" .inner.graph").removeClass("graph").html('<span class="dashnodata">'+$.i18n._('dash no data')+'</span>'); 
      $("#dash > #"+xwhat+" .settings").remove(); 
      return true; // exit the function 
    } 
    var tmpar = new Array();
    // parse graph type & get back idx into json table. 
    xwhatArr= xwhat.split("_"); xxwhat= xwhatArr[0]; xxaxis = xwhatArr[3]; xyaxis=xwhatArr[1]; 
    graphDesc = JSON_find_elem_byName(dash_elem_list, xwhat);  
    graphObj = graphDesc.linkedobj;
    
    colorAr= ['#058DC7', '#50B432', '#ED561B', '#DDDF00', '#24CBE5', '#64E572']; 
  
    
     if (     (xwhat=="ad_vol_per_cat")
        ||  (xwhat=="user_vol_per_type")
        ||  (xwhat=="user_vol_per_protype")
        ||  (xwhat=="ad_vol_per_type")
        ||  (xwhat=="ad_vol_per_delete")
        ||  (xwhat=="ad_vol_per_user")
        ||  (xwhat=="top_dashboard")
      )
    {
      // update the series into the object graph 
      $.each(xdata.serie1, function(i, e) {
        if (xwhat=="ad_vol_per_cat"){
          if  (e.type!="zetvu")
            tmpar.push([e.cattitle, 1*e.adsnb]);
        }else  if (xwhat=="ad_vol_per_user"){
          if (1*e.nbusers>0)
            tmpar.push([e.nb+" ad", 1*e.nbusers]);
        }
        else  if (xwhat=="top_dashboard"){
            tmpar.push([e.type, 1*e.adsnb]);
        }
        else  if (xwhat=="user_vol_per_type"){
            if (e.type=="") xval = "local"; 
            else xval = e.type; 
            tmpar.push([xval, 1*e.metrics]);
        }
        else 
          tmpar.push([e.type, 1*e.metrics]);
      });
    
        graphObj.addSeries({
            data: tmpar , 
            zIndex:100       
        });
    }
    
   if (     (xwhat=="ad_vol_per_age")
        ||  (xwhat=="user_vol_per_age")
      )
    {
      // remove the existing series 
      gl=graphObj.series.length; 
      for (var gi=0; gi<gl;gi++) { graphObj.series[0].remove();};
    
      // update the series into the object graph 
      var tmpar = new Array();
      $.each(xdata.serie1, function (i, e){
          ydate= e.datestamp+12*60*60*1000; // to correct UTC bug from Highchart
          //ydate= e.datestamp; 
          yval= e.metrics; 
          return tmpar.push([ydate,1*yval]);
      }); 
      
      // set max time 
      //graphObj.xAxis[0].setExtremes(0, 5);
      var d = new Date();
      graphObj.xAxis[0].options.max = Date.UTC(d.getFullYear(), d.getMonth()+1 , d.getDate());      
      seriename = $.i18n._(ad_status_name[40]);
      
      // add the serie
      graphObj.addSeries({
          name : seriename,
          data: tmpar,
          color : colorAr[0] ,
          symbol: "circle"             
      });
      
    }
    
    
    // format for TIME 
    // series: [{ name: 'thename', data: [ [Date.UTC(1970,  9, 27), 0   ],[Date.UTC(1970, 10, 10), 0.6 ]]]}, {serie2...}]
    if (    (xwhat=="ad_vol_per_time")
         || (xwhat=="ad_vol_per_status")
         || (xwhat=="user_vol_per_time")
       )
    {
    
      // select what to be displayed 
      if (xxwhat=="ad"){
        if (xxaxis=="status") xastatus2display= new Array('a10','a40','a80', 'a15');
        else                  xastatus2display= new Array('a10', 'a40', 'a15');
      }
      if (xxwhat=="user") xastatus2display=new Array('u');
      var serieidx=0;
      
      // remove all series before creating a new one
      gl=graphObj.series.length; 
      for (var gi=0; gi<gl;gi++) { 
        graphObj.series[0].remove(); // remove on same index as they are decreased from list
      };
   
      $.each(xastatus2display, function(zi,zval) {
        var tmpar = new Array();
        serieidx=serieidx+1; 
        $.each(xdata.serie1, function(i, e) { 
           ydate= e.datestamp+12*60*60*1000; // to correct bug from Highchart on dates
           if (zval=="a40") {
               if (e.metrics["a40"]) yval= parseInt(e.metrics["a40"]); else yval=0; 
               if ((e.metrics["a45"])) yval+= parseInt(e.metrics["a45"]);  
            } else
              if (e.metrics[zval]) yval=e.metrics[zval]; else yval=0; 
            tmpar.push([ydate,1*yval]);  
        });
        sid=1*serieidx-1; 
       
        // update the series name
        if (xxwhat=="ad") seriename=$.i18n._(ad_status_name[zval.substr(1,2)]);
        if (xxwhat=="user") seriename=$.i18n._('cumul users');
        
          
        graphObj.addSeries({
            name : seriename,
            data: tmpar, 
            color : colorAr[zi],
            symbol: "circle"    
        });
        
        /* DO NOT DELETE - UPDATE TEMPLATE WHEN SERIE IS DEFINED
        graphObj.series[sid].name=seriename; // set the series name
        graphObj.series[sid].legendItem.attr('text', seriename);
        graphObj.legend.renderLegend(); // update the series title 
        graphObj.series[sid].setData(tmpar, true); // update the data
        */ 
      });
    }
    
}; 


/**-----------------------------------------------------------------------------
* This function update the table datas associated with a graph 
*
* @param {d}  : sjon object received from AJAX call {data=xx; what=xx; userid=xx}
* @return {String} HTML content 
*-----------------------------------------------------------------------------*/
function update_graph_table(d){
    var tmpar = new Array();
    var tmph=''; 
    
    var xwhat=d.what; 
    var xdata=d.data; 
    var xuserid=d.userid; // only if exist
    
    if (xuserid) urluserid="&userid="+xuserid; 
    else urluserid=""; 
    
    // parse graph type & get back idx into json table. 
    xwhatArr= xwhat.split("_"); xxaxis = xwhatArr[3]; xyaxis=xwhatArr[1]; wwhat=xwhatArr[0];
    graphDesc = JSON_find_elem_byName(dash_elem_list, xwhat);  
    graphObj = graphDesc.linkedobj;
    
    if (xwhat=="top_dashboard"){
      // create the table chart on Left Part 
      tmph +='<div class="figure">';
      tmph +=$.i18n._n('%s ad','%s ads' , xdata.totnb_ads,[xdata.totnb_ads]);
      if (urluserid) tmph +='<a name="manage_dash_menu" href="#action=nav&what=myads_all'+urluserid+'">'+$.i18n._('dash manage ads')+'</a>' ;
      else  tmph +='<a name="manage_dash_menu" href="#action=nav&what=manage_ads">'+$.i18n._('dash manage ads')+'</a>' ;
      
      tmph+='<br>'; 
      if (cur_user.usertype<8){toto=1} 
      else {
        if (xdata.totnb_users){
          tmph +=$.i18n._n('%s user','%s users' , xdata.totnb_users,[xdata.totnb_users]);
          tmph +='<a name="manage_dash_menu" href="#action=nav&what=manage_users">'+$.i18n._('dash manage users')+'</a>' ;
          tmph+='<br>'; 
        }
        if (xdata.totnb_cats){
          tmph +=$.i18n._n('%s cat','%s cats' , xdata.totnb_cats,[xdata.totnb_cats]);
          tmph +='<a name="manage_dash_menu" href="#action=nav&what=manage_cats">'+$.i18n._('dash manage cats')+'</a>' ;
          tmph +='</div>';  
        }
      }
      $('#dash #'+xwhat+' .col1.data').html(tmph); 
      
      // create the table chart on RIGHT Part        
      // select the list of data to be displayed if present ! 
      xastatus2display= new Array('a40','a45','a20','a15','a10','a80','a90');
      yd= xdata.serie2;
       var tmpar = new Array();
        $.each(yd, function (ekey, eval){
          if ($.inArray(ekey,xastatus2display)!=-1){
            tmpar.push({status:ekey, val:eval});
          }
       }); 
      // create the table char 
      coldata=["status", "val"];
      $('#dash #'+xwhat+' .col2.data').html(create_table_chart(tmpar,coldata,"val",'','',xuserid)); 
      
    }
    
    if (xwhat=="ad_vol_per_cat"){
      // create the table char 
      coldata=["cattitle", "adsnb"];
      $('#dash #'+xwhat+' .data').html(create_table_chart(xdata.serie1,coldata,"adsnb")); 
    }
    
    if (     (xwhat=="ad_vol_per_type") 
          || (xwhat=="user_vol_per_type")
          || (xwhat=="user_vol_per_protype")  
           || (xwhat=="ad_vol_per_delete") 
       ){
      // create the table char 
      coldata=["type", "metrics"];
      $('#dash #'+xwhat+' .data').html(create_table_chart(xdata.serie1,coldata,"metrics")); 
    }
    
    if (     (xwhat=="ad_vol_per_user") 
       ){
      // create the table char 
      coldata=["nb", "nbusers"];
      $('#dash #'+xwhat+' .data').html(create_table_chart(xdata.serie1,coldata,"nbusers")); 
    }
    
    
     if (     (xwhat=="ad_vol_per_status") 
          || (xwhat=="ad_vol_per_time") 
          || (xwhat=="user_vol_per_time") 
       ){
       // data are sorted by date so take the latest one.
       if (!xdata.serie1) return ''; // quit if no data 
       yd = xdata.serie1; ydlen  = yd.length -1;  
       yd=yd[ydlen];
       
       // get the data filter 
       if (wwhat=="ad"){
        if (xxaxis=="status") xastatus2display= new Array('a10', 'a15','a40','a80');
        else                  xastatus2display= new Array('a10', 'a15', 'a40');
       } else xastatus2display= new Array('u');
       
       var tmpar = new Array();
       $.each(xastatus2display, function (i, statusval){
          if (statusval=="a40") {
            if  (yd.metrics["a40"]) yval= parseInt(yd.metrics["a40"]); else yval=0; 
            if  (yd.metrics["a45"]) yval+= parseInt(yd.metrics["a45"]); 
            //yval= parseInt(yd.metrics["a40"]) + parseInt(yd.metrics["a45"]);
            }
          else { 
          if (yd.metrics[statusval]) yval=yd.metrics[statusval]; else yval=0;
          }
          tmpar.push({status:statusval, val:yval});
       });  
      // create the table char 
      coldata=["status", "val"];
      $('#dash #'+xwhat+' .data').html(create_table_chart(tmpar,coldata,"val")); 
    }
    
  
    // ----------   event handlers -----------------------------------
    if (xwhat=="top_dashboard"){ // do that to allocate only 1 handler
      $('#dash a[name=manage_dash_menu]').click(function(e) {
           e.preventDefault();
           ahref = $(this).attr('href');  
           eval_href ( ahref, "anchor1");  
           var tmpx = ahref.split("#");
           ahref2 = tmpx[tmpx.length-1]; // get just the final elements after latest # to correcr IE bug.
          
           if (anchor1.action=="nav"){
            menurule=JSON_find_elem_byName(menu_nav.admin, anchor1.what);
            if (menurule){ 
              //ajaxparam= menurule.param.split("#")[1]+"&nav="+menurule.name;
              ajaxparam= menurule.param.split("#")[1]+"&nav=admin";
              if (menurule.userlevel != "9") ajaxparam += '&userid='+cur_user.id;
              ajax_action (ajaxparam);
              

              display_DOM_subnav(menu_nav.admin, "admin", menurule.name);

              addToNavigatorHistoryAndCurrent(ajaxparam);
              
              }
            else {
              displayMessage("Action not yet available", true, "info");
              }
           }        
          return true; 
      });
    }
    // - event handler for links inside the tables 
     $('#dash #'+xwhat+' [name=link_to_list]').click(function(e) {
      awhat = $(this).attr('what');
      aid=$(this).attr('whatid');
      auserid=$(this).attr('userid');
      
      if  (awhat=="cat") ajaxparam= 'action=list&what=ad&catid='+aid;
      if  (awhat=="ad") ajaxparam= 'action=list&what=ad&status='+ad_status_name[aid.substring(1)].toLowerCase()+"&nav=admin"; 
      
      // add user id 
      if (auserid) ajaxparam += '&userid='+auserid; 
        
      ajax_action (ajaxparam);
      addToNavigatorHistoryAndCurrent(ajaxparam);
      
      return false; 
     }); 
    
}; 


/**-----------------------------------------------------------------------------
* This function convert a given table into an HTML table 
* @param {jsondata}  JSON Array  : data containing all the elements
* @return {String} HTML content 
*-----------------------------------------------------------------------------*/
function  build_simple_table (alldata, cl, maxline){
  var th='';
  var line=1; var firstline=true; var newcol=false; 
  if (!maxline) maxline= 9999; 
  
    $.each(alldata.data, function (ekey, eval){

      if (newcol){
        th +="</tbody></table>"; // close the table 
        th +='</div>'; 
      }

      // open that table
      if (firstline || newcol) {
        th +='<div class="column" style="float:left;">'; 
        th +='<table class="'+cl+'"><tbody>'; 
        firstline=false; newcol=false; 
      
      }

      // display the content 
      th+="<tr>";
      th+="<td>"+ekey+"</td>"; 
      th+="<td>"+decodeURIComponent(eval)+"</td>"; 
      th+="</tr>";

      // manage the counters 
      line++;
      if (line > maxline) {
        line=1; 
        newcol=true; 
      }
    })

    // close the job
    th +="</tbody></table>"; // close the table 
    th +='</div>'; 
    th+='<div class="clear"></div>';
  
  return th; 
}; 


/**-----------------------------------------------------------------------------
* This function build an HTML TABLE using object as input
*
* @param {jsondata}  JSON Array  : data containing all the elements
* @param {ar_key}   String Array  : OPTIONNAL  : contains the list of labels to display
* @param {percentkey}   STRING  : OPTIONNAL  : when set indicate which string to make % off
* @param {maxentry}   INTEGER  : OPTIONNAL  : max number of lines to be displayed - default to 5 - set to 0 for infinite
* @param {dispmode}   STRING  : OPTIONNAL  :  special display mode (logsmode = log table)
* @param {userid}   STRING  : OPTIONNAL  :  userid if exists to influence the link
* @param {actions}   STRING  : OPTIONNAL  :  define if wemust display Actions Buttons on this elemen M=modify D=delete R=refresh P=publish
* 
* @return {String} HTML content 
*-----------------------------------------------------------------------------*/
function create_table_chart(jsondata, ar_key, percentkey, maxentry,dispmode,userid,actions, what){
  var th=""; 
  var cl="";
  var maxline=5; if (maxentry) maxline = maxentry;
  var thepercidx=0;

  if (what=="ads") what="ad";  if (what=="users") what="user"; if (what=="cats") what="cat";
  
  if (!jsondata){return th}; 
    
  // case of percentage requested
  if (percentkey){
    cnt=0; 
    // get the sum to determine max
    $.each(jsondata, function(i, e) {
      cnt += 1*e[percentkey];
    }); 
  }
  // get automatically the list of labels either from json itself or from indicated list
  if  (!ar_key) {
    esw= swapJsonKeyValues(jsondata[0]); // take first line of data
  } else esw=ar_key;
  if (percentkey) esw.push("%"+percentkey); // add percentage
  
  // find back position of the percent field 
  if (percentkey){
  for (var ix=0; ix<esw.length;ix++){ if (esw[ix]== percentkey) thepercidx=ix;}
  }
  
  //--- starts generating the HTML 
  th+='<table id="table_gen">';
  // output the header 
  th+='<thead> <tr>';
  for (var ix=0; ix<esw.length;ix++){
    if (dispmode!="logsmode") if (ix=="0") cl="text"; else cl=""; 
    else cl="text";
  
    //if (((dispmode=="logsmode") && (esw[ix].indexOf('title') == -1)) || (dispmode!="logsmode"))
      th+='<th class="'+cl+'">'+$.i18n._('a_'+esw[ix])+ '</th>';
    
  };

  // add the action menu
  if (actions)    th+='<th class="'+cl+'">'+$.i18n._('actions')+ '</th>';

  th+='</tr></thead><tbody>'; 
  
  // output the data 
  ln=0; hascumul=false; cumulval=new Array(), elemval=''; 
  $.each(jsondata, function(i, e) {
      ln+=1; 
      if ((ln < maxline) || (dispmode=="logsmode")){

        var trcl =""; 
        // special case for users to indicate admin
        if (what=="user" && e['assocprojects']=='10') trcl += ' user_is_superadmin'; 
        if (what=="user" && e['usertype']=='9') trcl += ' user_is_admin'; 

        th+='<tr class="'+trcl+'">';
        // each element to be displayed 
        for (var ix=0; ix<esw.length;ix++){
            elemkey = esw[ix];
            cl = ' ';  
            
            if (dispmode=="logsmode"){
              displayit=true; 
              cl = ' text ';  
              // color code 
              cl_color_grey= new Array('10','00', '20', '60');
              cl_color_green= new Array('40', '45');
              cl_color_red= new Array('80', '90');
              
              // special mode for LOGs  : 
              // replace date by string, change usersid with link, add color 
              elemval = e[elemkey];
              if (elemkey.indexOf('date') != -1 && (elemkey.indexOf('bo_') == -1 || elemkey.indexOf('bo_moddate') != -1)) {
                if (e[elemkey]=='0000-00-00 00:00:00') elemval='-';
                else elemval = convert_delta_date_2_String(toTimestamp(e[elemkey]),true); 
              }
              if ((elemkey.indexOf('startdate') != -1) || (elemkey.indexOf('enddate') != -1)|| (elemkey.indexOf('expiredate') != -1)) {
                if (e[elemkey]=='0000-00-00 00:00:00') elemval='-';
                else elemval = convert_delta_date_2_String(toTimestamp(e[elemkey]),false, 'noprefix'); 

                // check if start date is expired for enddate only
                if ((elemkey.indexOf('enddate') != -1) || (elemkey.indexOf('expiredate') != -1)){
                  if ( toTimestamp(e[elemkey]) <  new Date().getTime() ) cl+= " expireddate" ;
                }

              }
              if (elemkey.indexOf('action') != -1) {
                elemval = $.i18n._(elemval);
                }
              if (elemkey.indexOf('CTR') != -1) {
                // CTR = click through rate
                if (e["impressions"]>0 ) var ctr =  Math.round(10000*(parseInt(e["clicks"]) /  parseInt(e["impressions"])))/100; 
                else var ctr=0;
                elemval =ctr+"%";
                }

              if (elemkey.indexOf('title') != -1) { 
                displayit=true; // do not display
                if (elemkey=="dyn_title") {
                  if (e['action']=='cron') elemval="";
                  else {
                    if (e['what']=="user") elemval = '<a title="'+e['username']+'" name="display_elem" class="" href="#action=display&what='+e["what"]+'&id='+e["whatid"]+'">'+ e['username']+'</a>';
                    if (e['what']=="ad") elemval = '<a title="'+e['adtitle']+'" name="display_elem" class="" href="#action=display&what='+e["what"]+'&id='+e["whatid"]+'">'+ e['adtitle']+'</a>';
                    if (e['what']=="cat") elemval = '<a title="'+e['cattitle']+'" name="display_elem" class="" href="#action=display&what='+e["what"]+'&id='+e["whatid"]+'">'+ e['cattitle']+'</a>';  
                  }
                } else{
                
                  if (what=="ad" || what=="user"){
                    // add a link to opn the element when ckicking 
                    elemval = '<a name="display_local_elem" href="#" z-lid="'+i+'" z-what="'+what+'">'+elemval+'</a>';
                  }

                  // case of cat--  display a TAG for the sub categorie
                  if ((what=="cat") && (e['parentid']!='') && (e['parentid']) ){
                    t2 = '<i class="icon-fa-ellipsis-horizontal mr6"></i>'+elemval;
                  } else t2=elemval ; 
                  elemval = '<a name="display_local_elem" href="#" z-lid="'+i+'" z-what="'+what+'">'+t2+'</a>';

                  // patch for logs 
                  if (what=="logs"){
                    elemval = '<a title="'+t2+'" name="display_elem" class="" href="#action=display&what='+e["what"]+'&id='+e["whatid"]+'">'+ t2+'</a>';
                  }

                  if (what=="alerts"){
                    elemval = t2; // plain with np links 
                  }
                }

              }


              // case of PArent id d
              if (what=="cat"  && elemkey=="parentid") {
                if (elemval){
                  t2= JSON_find_elem_byValue(cat_options,elemval).name; 
                  elemval =  t2 +'('+elemval+')'; 
                  if (t2 === undefined)  elemval='<span class="forced-red"><i class="icon-fa-warning mr6"></i>'+elemval+'</span>'; 
                }
              }


              if ((elemkey.indexOf('state') != -1) || (elemkey.indexOf('status') != -1)){ 
                if (elemkey=='paymentstatus')  elemval = $.i18n._('paypal_status_'+elemval); // paypal display status 
                else {
                  elemval = ad_status_name[elemval]; 
                  if (typeof elemval != "undefined" ){
                    if (isPageAdmin) elemvallabel="SHORT "+elemval; 
                    else elemvallabel = elemval;
                    elemval = '<div class="adlist_status '+ elemval+'">'+ $.i18n._(elemvallabel)+'</div>';
                  } else elemval=""; 
                }
              }
              if (elemkey.indexOf('protype') != -1) {
                  statusname = 'protype_'+elemval; 
                  elemval = '<span id="" class="adlist_protype '+statusname+' ttip" title="'+$.i18n._("help_on_status "+statusname)+'">'+$.i18n._(statusname)+'</span>';
              }

               if (elemkey.indexOf('auth') != -1) {
                  elemval = '<div id="" class="auth-type-'+elemval+' " title="'+$.i18n._("help_on_auth_type "+elemval)+'">'+$.i18n._('auth-type-'+elemval)+'</auth>';
              }
                  
              if (elemkey.indexOf('severity') != -1) { 
                elemval = '<div class="adlist_status severity_'+ elemval+'">'+ $.i18n._('severity_'+elemval)+'</div>';
              }
              
              if (elemkey == "whatid") {
                if  (e["action"]!="delete") // display link only if article is not deleted
                { 
                  titletxt=""; 
                  if (e["cattitle"]) titletxt +=  e["cattitle"];
                  if (e["adtitle"])  titletxt +=  e["adtitle"];  
                  if (e["what"]=="user") titletxt=""; // patch to avoid issue with PAYPAL infos
                  
                  if (e["what"] == "servi") elemval = elemval;
                  else { var zwhat = e['what'] ; 
                    elemval = '<a title="'+titletxt+'" name="display_elem" class="" href="#action=display&what='+zwhat+'&id='+elemval+'">'+ elemval+'</a>';
                  }
                }
              }

              // Z6.1.5
              if (elemkey == "recurrent"){
                if (elemval=="") elemval='-';
              }


              // Z6.1.5
              if (elemkey == "abuse"){
                if (elemval) elemval='<i class="icon-fa-warning mr6 " style="color:red;"></i>';
              }

              if (elemkey == "transactionid") {
                  // if admin, indicate the details of the transaction if not, no link
                  if (isAdmin && isPageAdmin){
                    var xtitle = $.i18n._('Get details directly from PAYPAL') ; 
                    elemval = '<a title="'+xtitle+'" name="display_elem" class="" href="#payments=details&tid='+e['transactionid']+'">'+elemval+'</a>';
                  }

              }

              if (elemkey == "displayinvoiceaction") {
                var xtitle =  (e['recurrent']=="yes")?  $.i18n._("recurrent paiement") + ' ' + $.i18n._('display invoice details') : $.i18n._("one-shot transaction") + ' '+$.i18n._('display invoice details'); 
                elemval = '<a title="'+xtitle+'" name="display_invoice" class="" href="#" z-tid="'+e['transactionid']+'"><i class="icon-fa-search-plus mr6"></i></a>';

              }

              if (elemkey == "what") { 
                elemval = $.i18n._(elemval); 
              }

              if (elemkey == "type") {
                 elemval = '<span class="badge grey">'+$.i18n._('admin_'+what+'_type_'+elemval)+'</span>'; 
              }

              if (elemkey == "ip") {
                    var xtitle = $.i18n._('geolocal ip') ; 
                    elemval = '<a title="'+xtitle+'"  class="" href="https://geoiptool.com/?IP='+e['ip']+'" target="_blank">'+elemval+'</a>';
              }

              if (elemkey == "description") {
                    elemval = elemval
              }

               if (elemkey == "ratings") {
                elemval=''; 
                var real_ratings_nbr = (coms_settings.coms_rating_visual=="pnn") ? 3 : coms_settings.coms_rating_nbr ;
                for (var r = 1; r <= real_ratings_nbr; r++) elemval +=  e['rating'+r] +'/';
                elemval = elemval.slice(0, -1);
              }
                      
              if (elemkey.indexOf('desc') != -1 &&  what!="coms") {
                syslogs= new Array('cron','auth', 'sec');  
                if ((elemval) && !($.inArray(e['action'],syslogs)!=-1)) {// merge values if not auth 
                  
                  if (e['desc'].split("|")[1]){
                    elemval =  $.i18n._('log_'+e['action']+'_'+ad_status_name[elemval.split("|")[0]]) + ' ('+ $.i18n._(e['desc'].split("|")[1])+') ';
                  } else 
                  elemval = $.i18n._('log_'+e['action']+'_'+ad_status_name[elemval.split("|")[0]]);
                }
                else {

                  if (e['desc'].split("|")[1]){
                    elemval =  $.i18n._('log_'+e['action']+'_'+e['desc'].split("|")[0])+ ' ('+e['desc'].split("|")[1]+')';
                    } 
                   else 
                    if (e['desc']!='')
                      elemval =  $.i18n._('log_'+e['action']+'_'+e['desc'].split("|")[0]);
                    else 
                      elemval =  $.i18n._('log_'+e['action']);
                  }
                if ($.inArray(e[elemkey], cl_color_grey) !=-1) cl += 'txt_grey';
                if ($.inArray(e[elemkey], cl_color_green) !=-1) cl += 'txt_green'; 
                if ($.inArray(e[elemkey], cl_color_red) !=-1) cl += 'txt_red';  
              }


              // user id 
              if (in_array(elemkey, ['fromid','toid', 'userid'])) { 
                elemval = '<a href="#action=display&what=user&nav=admin&id='+e[elemkey]+'" name="display_elem" ><span>'+e[elemkey]+'</span></a>';
              }

              if (elemkey.indexOf('username') != -1) { 
                // check if robot 
                if (e["userid"]==0 && !e["username"]){
                  // Z6.1.3
                  if (display_settings.robot_name) elemval = '<span>'+display_settings.robot_name+'</span>';
                  else  elemval = '<span>robot</span>';
                } else {
                  if (what!="ad"){
                    // add the photo if exists 
                    elemurl = e["imgurl"]; 
                    elemval = e[elemkey];
                    if ((elemurl!="") && (elemurl)){
                      imgname= elemurl.split(";")[0]; imgname = imgname.split("|")[0]; 
                      imgfullurl = e["imgpath"]+"tn_"+imgname;
                      elemval = '<img src="'+imgfullurl+'" class="mini"><span>'+e[elemkey]+'</span>';
                    }
                  } else {
                    // case of ads 
                    elemval = '<a href="#action=display&what=user&nav=admin&id='+e['userid']+'" name="display_elem" ><span>'+e[elemkey]+'</span></a>';
                  }
                }
                
              }

              // link to display user 
              if ((what=="user" || what=="users") && (elemkey.indexOf('email') != -1 || elemkey.indexOf('username') != -1)) { 
                  // add a link to opn the element when ckicking 
                  elemval = '<a name="display_local_elem" href="#" z-lid="'+i+'" z-what="'+what+'">'+elemval+'</a>';
              }

              //Z6.4.0 
              // case of Vfileds 
              if (elemkey == "catlvfields"){
                t2='';
                  if (elemval) {
                    t2 +=' <i class="icon-fa-sitemap mr6"></i>'+count_vfields(elemval, 'cat'); 
                    t2 +=' <i class="icon-fa-search mr6"></i>'+count_vfields(elemval, 'search'); 
                  }
                  elemval = t2;                
              }

              if (elemkey == "hascalendar"){
                if (elemval) elemval = ' <i class="icon-fa-calendar mr6"></i>'; 
              }

               if (elemkey == "adultflag"){
                if (elemval) elemval = ' <i class="icon-fa-warning mr6"></i>'; 
              }

              if (elemkey == "pricetype"){
                if (elemval) elemval = (elemval=="nopr") ? ' <i class="icon-fa-ban mr6"></i>' : 'catpricetype_'+elemval ; 
              }


              if (elemkey == "totnbads"){
                if (!parseInt(elemval))  elemval = '-'; 
                // add a link if it's a users 
                 if (elemval && what=="user"){
                  t2=elemval ; target_what='ad' ; 
                  elemval = '<a name="display_related_elem" href="#" z-relatedid="'+e['id']+'" z-what="'+target_what+'">'+t2+'</a>';
                 }
              }

        
            } else
            // normal mode of statistics  
            {
              if (elemkey!=("%"+percentkey)) { 
                // case of cat -> display a link to cat list
                // case of Status -> display link to status list
                if (elemkey=="cattitle") elemval = '<a name="link_to_list" what="cat" userid="'+userid+'" whatid="'+e["catid"]+'"href="#">'+ e[elemkey]+'</a>';
                else if (elemkey=="status") elemval = '<a name="link_to_list" what="ad" userid="'+userid+'" whatid="'+e["status"]+'"href="#">'+ $.i18n._(e[elemkey])+'</a>';
                else elemval = e[elemkey];
              }
              else { 
                
                if (cnt!=0)
                  theval = Math.round((1*e[percentkey]/cnt)*1000)/10; 
                else  theval=0;

                elemval=theval +"%";
                elemval='<div class="bar" style="width:'+theval+'%;"></div>'+elemval; 
                cl+=" perc ";               
              }
              if (ix=="0") {cl="text"; elemval=$.i18n._(elemval);}
            }

            // generate the HTML
            if (((dispmode=="logsmode") && (displayit)) || (dispmode!="logsmode")) 
              th+='<td class="'+cl+'">'+elemval+'</td>';
            
            
          } // end of FOR

          // === add the action buttons 
          if (actions){
            // actions="MPDR"; // debug
            xtrameta = ' z-from="admin" '; 
            if (e['hashid']) xtrameta= ' z-hashid="'+e['hashid']+'" ';else xtrameta+=""; 
            xtrameta+=(e['type']) ? 'z-type="'+e['type']+'" ' : ""; // to manage zetevu case
            var elemvalactions=''; 


            //Z5.6.2  - order up and order down for Categories 
            if (actions.indexOf('O') != -1) { 
              var eorder = e['order'];
              var orderup=parseInt(eorder)-1; var orderdown=parseInt(eorder)+1; 
              if (eorder >0) elemvalactions+='<a id="item-up" title="'+$.i18n._("cat order minus")+'" action="updateorder" rel="'+e["id"]+'" z-dir="up" z-order="'+orderup+'" name=""  what="'+what+'" href="#"> <i class="icon-fa-arrow-up"></i> </a>';
              elemvalactions+='<a id="item-down" title="'+$.i18n._("cat order plus")+'" action="updateorder" rel="'+e["id"]+'" name=""  what="'+what+'" href="#" z-dir="down" z-order="'+orderdown+'"> <i class="icon-fa-arrow-down mr6"></i></a>';
            }

            if (actions.indexOf('M') != -1)
              elemvalactions+='<a href="" title="'+$.i18n._('edit')+'" name="manage_banner" adid="'+i+'" rel="'+e["id"]+'" action="edit" '+xtrameta+' ><i class="icon-fa-edit mr6"></i></a>';
            if (actions.indexOf('P') != -1){
              if (e['status']=="20" || e['status']=="60" || e['status']=="15") elemvalactions+='<a href="" title="'+$.i18n._('publish')+'" name="manage_banner" adid="'+i+'" rel="'+e["id"]+'" action="publish" '+xtrameta+'><i class="icon-fa-check mr6"></i></a>';    
              if (e['status']=="40") elemvalactions+='<a href="" title="'+$.i18n._('un publish')+'" name="manage_banner" adid="'+i+'" rel="'+e["id"]+'" action="unpublish" '+xtrameta+'><i class="icon-fa-minus-square-o mr6"></i></a>';    
            }
            if (actions.indexOf('D') != -1 ){
              var xicon = (what=="coms") ? 'ban' : 'trash-o'; 
              if (what=="coms" && e['status']=="80") toto=1; 
              else elemvalactions+='<a href="" title="'+$.i18n._('delete')+'" name="manage_banner" adid="'+i+'" rel="'+e["id"]+'" action="delete" '+xtrameta+'><i class="icon-fa-'+xicon+' mr6"></i></a>';    
              
            }
            if (actions.indexOf('T') != -1 &&  e['status']=="80") 
              elemvalactions+='<a href="" title="'+$.i18n._('trash')+'" name="manage_banner" adid="'+i+'" rel="'+e["id"]+'" action="trash" '+xtrameta+'><i class="icon-fa-trash-o mr6"></i></a>';    
            
            if (actions.indexOf('R') != -1)
              if ((e['clicks'] !="0") || (e['impressions'] !="0"))  elemvalactions+='<a href="" title="'+$.i18n._('resetclicks')+'" name="manage_banner" adid="'+i+'" rel="'+e["id"]+'" action="resetclicks" '+xtrameta+'><i class="icon-fa-refresh mr6"></i></a>';    
            

            if (actions.indexOf('L') != -1)
              if ((e['likes'] !="0"))  elemvalactions+='<a href="" title="'+$.i18n._('resetlikes')+'" name="manage_banner" adid="'+i+'" rel="'+e["id"]+'" action="resetlikes" '+xtrameta+'><i class="icon-fa-refresh mr6"></i></a>';    
            
            th+='<td class=" actions '+cl+'">'+elemvalactions+'</td>';
          }

        th+='</tr>';
      } else   {
          hascumul=true; // indicate we have cumul line 
          for (var ix=0; ix<esw.length;ix++){
              elemkey = esw[ix]; 
              //if (ix=="0") cl="text"; else cl=""; 
              if (elemkey!=("%"+percentkey)) {
                if (cumulval[ix]) cumulval[ix]+= parseInt(e[elemkey]); 
                else cumulval[ix]= parseInt(e[elemkey]);
              }
            }
      }
  });
  // cumul part 
  if (hascumul){
   th+='<tr>';

    for (var ix=0; ix<esw.length;ix++){
        cl="";
        elemkey = esw[ix]; 
        if (elemkey!=("%"+percentkey)) elemval = cumulval[ix]; 
        else {
          theval = Math.round((1*cumulval[thepercidx]/cnt)*10000)/100; 
          elemval=theval +"%";
          elemval='<div class="bar" style="width:'+theval+'%;"></div>'+elemval; 
          cl+=" perc "; 
        }
        
        if (ix=="0") {cl="text";elemval = $.i18n._('others');} 
        th+='<td class="'+cl+'">'+elemval+'</td>';
      }
   th+='</tr>';
  }
  
  th+='</tbody></table>';
  
  return th; 
}


/**-----------------------------------------------------------------------------
* This function create the javascript GRAPH objects
*
* @param {string} renderto_id : the DOM ID of the elements to render the JS object
* @param {string} xtype : indicate the type  : pie|colomn|line|spline 
* @param {string} title  : title of the graph 
* @param {string} xdesc  : give formated details on graph content : WHAT_YAXIS_per_XAXIS
* @param {string} yaxis_title  : title of the Y-AXIS 
* 
* @return {string} the HTLM element
*-----------------------------------------------------------------------------*/
function create_js_chart(renderto_id, xtype, title , xdesc){
  var options; 
  
  // general options applicable to all charts
  options = {
      chart: {
         renderTo: renderto_id,
         defaultSeriesType: xtype,
         borderColor: '#EEE',
         borderWidth: 1 
         
         /*
         marginLeft: 20,
         marginRight: 20,
         marginBottom: 40
        */
      },
      title: { 
        text: title, 
        margin : 7
      },
      credits: { enabled: false },
      
      tooltip: {
         formatter: function() {
            //return '<b>'+ this.point.name +'</b>: '+this.point.y+'-'+ Math.round(this.percentage*10)/10 +' %';
            if (this.point.name)
              ttiphtml = '<b>'+ $.i18n._(this.point.name) +'</b>: '+this.point.y;
            else ttiphtml =  '<b>'+ 'no name' +'</b>: '+this.point.y;
            return ttiphtml; 
         }
      },
      
      
      yAxis : {
        allowDecimals: false,
        min: 0,
        title: {
            enabled: true
        }
      },
      // default colors and symbols
      colors: ['#058DC7', '#50B432', '#ED561B', '#DDDF00', '#24CBE5', '#64E572', '#FF9655', '#FFF263', '#6AF9C4'],
      symbol: ['circle'], 
      
      plotOptions: {
      
         pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            //size: '90%',
            //center : ['80%', '80%'],
            innerSize : '30%',
            dataLabels: {
               enabled: true,
               color:  '#000000',
               connectorColor: '#000000',
               formatter: function() {
                  return '<b>'+ $.i18n._(this.point.name) +'</b>: '+ Math.round(this.percentage*10)/10 +' %';
               }
            }
            //, 
            //showInLegend: true
            
         },
         column : {
            showInLegend: false,
            
            dataLabels: {
               enabled: true,
               align : 'left',
               rotation : 270,
               x: 4,
               //y: 0,
               color:  '#000000',
               connectorColor: '#000000',
               formatter: function() {
               //if (this.point.x<3)
                  return  this.point.name;
               }
            }
         },
         area: {
            stacking: 'percent',
            //stacking: 'normal',
            lineColor: '#ffffff',
            lineWidth: 1,
            marker: {
               lineWidth: 1,
               lineColor: '#ffffff'
            }
         },
         bar: {
            dataLabels: {
               enabled: true
            }
         }
        
      }
      /*
      ,
      legend:{
           layout:'vertical',
           float: true,
           align: 'right'
       }
       */ 

   };
  
  // complent with specific details linked to grapsh descritpion 
  xdescArr= xdesc.split("_"); xxaxis = xdescArr[3]; xyaxis=xdescArr[1];
     
  if ((xxaxis=="time") || (xxaxis=="status") || (xxaxis=="age"))  {
  
    // xaxis options
    options = $.extend(options, {xAxis : { type: 'datetime'}});
    
    // manage tooltip zone 
    if (xtype=="area"){
      ttformater = function(){
          ttiphtml= '<b>'+ this.y + '</b><br/>'+ Highcharts.numberFormat(this.percentage, 1) +'%';
        return ttiphtml;
      };
      
    }else {
      ttformater = function(){
        //return '<b>'+ this.y + '('+this.series.name +')</b><br/>'+ Highcharts.dateFormat('%e. %b', this.x);
          ttiphtml = '<b>'+ this.y + '</b><br/>'+ Highcharts.dateFormat('%e. %b', this.x);
         return ttiphtml;
      };
    }
    // !!! bug on tooltip if bad formating  !!! to be checked later 
    options =  $.extend(options, {tooltip: { formatter: ttformater}});
  } else {
   if (xtype=='column')  
       options = $.extend(options, {xAxis: {labels: { enabled: false }}});
  }
  
  if ((xyaxis=="vol")) {
    if (xtype=='bar')  
     options = $.extend(options, {xAxis: { labels: { rotation: -45, align: 'right', style: { font: 'normal 13px Verdana, sans-serif'}}}});

    options = $.extend(options, {yAxis : { allowDecimals: false, min: 0,   title: {  enabled:true,  text: 'volume'}}});  


 }
  return new Highcharts.Chart(options);
}; 



/**-----------------------------------------------------------------------------
* array to save graph variables
* @name :  var name 
* @title : title to be displayed (master which will be translated at display time)
* @graphtype : type of highgraph chart {all the highcharts type } if set to NULL-> no graph
* @acl : Access control level (who can see that) : 0 = all, 8 =editor or higher, 9=admin  
* @withdata :  'yes' to add a table with data 
* @style :  display style (one column of two columns)
* @cola and @colb   : what to display on colA and cold B(when present) can be {data|graph}
* @checked  : whether this graph is displayed or not at launch time 
* @linkedobj : reserver for future use 
* @ptime  : (optionnal) indicate for a time graph if the period selection filter should be displyed and whats the default  
*           {all|thisyear|thisquarter|thismonth}
* 
* @return {string} the HTLM element
*-----------------------------------------------------------------------------*/
var dash_elem_list=new Array (
    { name : 'top_dashboard', acl:1 , title : 'top_dashboard', graphtype :'', withdata:'yes', style:'two-col', cola:'data', colb:'data', checked: 'yes'}, 
    { name : 'ad_vol_per_cat',acl:1 , title : 'ad_vol_per_cat', graphtype :'column', withdata:'yes', style:'two-col', cola:'graph', colb:'data',checked: 'yes', linkedobj:''}, 
    { name : 'ad_vol_per_type', acl:1 , title : 'ad_vol_per_type', graphtype :'pie', withdata:'yes', style:'two-col', cola:'graph', colb:'data',checked: 'yes', linkedobj:''},
    { name : 'ad_vol_per_time', acl:8 , title : 'ad_vol_per_time', graphtype :'spline', withdata:'yes', style:'two-col', cola:'graph', colb:'data',checked: 'yes', linkedobj:'', ptime:'thisyear'},
    { name : 'ad_vol_per_status', acl:8 , title : 'ad_vol_per_status', graphtype :'area', withdata:'yes', style:'two-col', cola:'graph', colb:'data',checked: 'yes', linkedobj:'', ptime:'thismonth'},
    { name : 'ad_vol_per_delete', acl:8 , title : 'ad_vol_per_delete', graphtype :'pie', withdata:'yes', style:'two-col', cola:'graph', colb:'data',checked: 'yes', linkedobj:''},
    { name : 'ad_vol_per_age', acl:1 , title : 'ad_vol_per_age', graphtype :'scatter', withdata:'yes', style:'one-col', cola:'graph', colb:'data',checked: 'yes', linkedobj:'', ptime:'all'},
    { name : 'user_vol_per_time', acl:8 , title : 'user_vol_per_time', graphtype :'spline', withdata:'yes', style:'two-col', cola:'graph', colb:'data',checked: 'yes', linkedobj:'', ptime:'thismonth'},
    { name : 'user_vol_per_age', acl:8 , title : 'user_vol_per_age', graphtype :'scatter', withdata:'yes', style:'one-col', cola:'graph', colb:'data',checked: 'yes', linkedobj:'', ptime:'all'},
    { name : 'user_vol_per_type', acl:8 ,title : 'user_vol_per_type', graphtype :'pie', withdata:'yes', style:'two-col', cola:'graph', colb:'data',checked: 'yes', linkedobj:''},
    { name : 'user_vol_per_protype', acl:8 ,title : 'user_vol_per_protype', graphtype :'pie', withdata:'yes', style:'two-col', cola:'graph', colb:'data',checked: 'yes', linkedobj:''},
    { name : 'ad_vol_per_user', acl:8 , title : 'ad_vol_per_user', graphtype :'pie', withdata:'yes', style:'two-col', cola:'graph', colb:'data',checked: 'yes', linkedobj:''}
);

/**-----------------------------------------------------------------------------
* This function initialize the display zone for Stats DASHBOARD
* 
* @return {string} the HTLM element
*-----------------------------------------------------------------------------*/
function init_dashboard_display(scope){
  var th=''; 
  
  // clean the detailled view in case of something still exist 
  $('#addetails').html('');
  
  th+='<div class="" id="dash">';

  th+='</div>';

  //append all this content
  $('#adlist').html(th).show();
  
  th=''; 
  $.each(dash_elem_list, function(i, e) {
    // check for Authorization to do that 
    //if (cur_user.usertype>=e.acl){
    if ((e.acl!='') && (cur_user.usertype>=e.acl) && !(scope=="my" && e.acl>1)) {
      th=''; 
      th+='<div class="wrapper" id="'+e.name+'">'; 
      // title 
      th+='<div class="title" id=""><span>'+$.i18n._(e.title)+'</span></div>';
      
      // preference menu if time  limited 
      en = e.name;
      //if ((en.indexOf('_time') != -1) || (en.indexOf('_age') != -1)|| (en.indexOf('_status') != -1))
      if (e.ptime)
      {
        th+='<div class="settings" id="set_'+en+'">';
        th+=$.i18n._('Observation period : ');
        ptimear  =['all', 'thisyear', 'thisquarter', 'thismonth']; 
        $.each(ptimear, function(j, pe) {
          if (pe==e.ptime) elemchecked=' checked="checked"'; 
          else elemchecked='';  
          th += '<input type="radio" class="radiox" name="timeperiod_'+i+'" rel="'+en+'" value="'+pe+'"  '+elemchecked+' >'+$.i18n._(pe);
        });
        th += '</div>';
      }
      
      if (e.graphtype){ idx=e.graphtype + '_' + e.name; clx2 = ' graph '+e.graphtype;} 
      else { idx="";  clx2 ='';}
      if (e.style=="two-col") clx="col1"; else clx=""; 
      
      // display first col
      if (e.cola=="graph") {clx3=clx2; idx3=idx;} else {clx3="data"; idx3="";} 
      th+=' <div class="inner '+clx+' '+clx3+' '+e.style+'" id="'+idx3+'">';
      th+=' </div>';
      
      // display second call if exist
      if (e.style=="two-col"){
        if (e.colb=="graph") {clx3=clx2; idx3=idx;} else {clx3="data"; idx3="";} 
        th+=' <div class="inner col2 '+clx3+ ' '+e.style+'" id="'+idx3+'">';
        th+=' </div>';
      }
      th+='</div>';
      //append all this content
      $('#dash').append(th);
    }
  });
  
  /* add global event handler to all radio buttons */
  $('#dash .settings .radiox').change(function() {
    thegraph = $(this).attr('rel'); 
    theval = $(this).val(); 
    // recall ajax to update datas 
    param = 'stats='+thegraph+'&p='+theval; 
    if (scope=="my") param +="&userid="+cur_user.id; 
    ajax_stats_action(param); 
  });
  
  return true;
}; 


/**-----------------------------------------------------------------------------
* This function initialize the graph creation and Ajax calls 
*-----------------------------------------------------------------------------*/
function init_graphs(scope){

  var cur_filter=''; 
  // loop though each graph 
  $.each(dash_elem_list, function(i, e) {
  
    // check for Authorization to do that 
    if ((e.acl!='') && (cur_user.usertype>=e.acl) && !(scope=="my" && e.acl>1)) {
      
      // add the graph object
      if (e.graphtype){
        idx=e.graphtype + '_' + e.name;
        // update the graph object
        obj = create_js_chart (idx, e.graphtype, e.title,e.name);
        obj.title.hide();
        
        // link the graph object to the array
        e.linkedobj = obj; // save the abj into the link 
      }
      
      //ajax call to get the datas
      param = 'stats='+e.name; 
      if (e.ptime) param += '&p='+e.ptime; // add the time limit when appropriate 
      if (cur_filter) param += '&'+cur_filter; 
      if (scope=="my") param += '&userid='+cur_user.id; // add userid if not admin or editor
      ajax_stats_action(param); 
    }
  });
  return true; 
};



// ----------------------------------------------------------------------------
// web RTC core functions
// ----------------------------------------------------------------------------
// var audioSelect = document.querySelector("select#audioSource");
// var videoSelect = document.querySelector("select#videoSource");

// // this code works only on HTTPS files which remembers the LABELS
// function gotSources(sourceInfos){

//   console.log(sourceInfos); 

//   for (var i = 0; i != sourceInfos.length; ++i) {
//     var sourceInfo = sourceInfos[i];
//     var option = document.createElement("option");
//     option.value = sourceInfo.id;
//     if (sourceInfo.kind === 'audio') {
//       option.text = sourceInfo.label || 'microphone ' + (audioSelect.length + 1);
//       audioSelect.appendChild(option);
//     } else if (sourceInfo.kind === 'video') {
//       option.text = sourceInfo.label || 'camera ' + (videoSelect.length + 1);
//       videoSelect.appendChild(option);
//     } else {
//       console.log('Some other kind of source: ', sourceInfo);
//     }
//   }
// }

// if (typeof MediaStreamTrack === 'undefined'){
//   console.log('This browser does not support MediaStreamTrack.\n\nTry Chrome Canary.');
// } else {
//   MediaStreamTrack.getSources(gotSources);
// }
// // this code works only on HTTPS files which remembers the LABELS


// init_webrtc(); 
var is_webrtc_capable=false; 
var is_live_stream_open=false; // indicate whether a live strem is open or not
var recorderNode ; // FO NOT CHANGE !!!  very important to make it global variable otherwise, this does not work !  
var globalMediaStream; // variable to stode the media stream 

// normalize the access and check if capable 
if (!navigator.getUserMedia)
  navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia ||
                navigator.mozGetUserMedia || navigator.msGetUserMedia;
is_webrtc_capable = navigator.getUserMedia ; 
var pid=0; 
var prev_media_opts=''; 



/**-----------------------------------------------------------------------------
* This function display the booth into a model box and adapt labels and buttons to context 
*-----------------------------------------------------------------------------*/
function display_booth(media_opts){

   //Get the window height and width
    var winH = $(window).height();
    var winW = $(window).width();

    var boothid='#my_booth';
    
    // var maskHeight =getPageHeight()+$(window).scrollTop(); // add the scroll 
    var maskHeight = Math.max(getFullPageHeight(),getPageHeight()+$(window).scrollTop()); // http://www.howtocreate.co.uk/tutorials/javascript/browserwindow
    var maskWidth = winW;
    
    //Set height and width to mask to fill up the whole screen and display it
    $('#my_booth_mask').css({'width':maskWidth,'height':maskHeight}).fadeTo("fast",0.5);

    // init default textes
    $(boothid+' .wrapper').hide(); // hide all eements =RESET
    $(boothid+' .dm_button2').each(function(){ // set displayed test 
      $(this).find('label').text($.i18n._($(this).attr('z-label')));
    }); 
     $(boothid+' .hastext').each(function(){ // set displayed test 
      $(this).text($.i18n._($(this).attr('z-label')));
    });

    $(boothid+' h1').html($.i18n._('media booth h1 - '+media_opts)); 
    $(boothid+' .intro_p').html($.i18n._('media booth into - '+media_opts)); 

    // reset the record duration
    $(boothid+' .record_duration').html('0:000'); 
    $('.snap_effect_btn').addClass('disabled'); // set to normal
    $('.snap_download_btn').addClass('disabled'); // set to normal 
    $('.snap_save_btn ').addClass('disabled'); // set to normal 

    $(boothid+' .' +media_opts).show(); 


    // very IMPOSTANT TO POSITION THIS HERE ! 
    tleft = Math.max(0,(winW/2-$(boothid).width()/2) + $(window).scrollLeft());
    ttop = Math.max(0,(winH/2-$(boothid).height()/2) + $(window).scrollTop());
    $(boothid).css('top', ttop);// auto adjust
    // $('#my_booth').css('top', '100px'); // forced 
    $(boothid).css('left', tleft);

    
    // display final  !! 
    $(boothid).show(); 

    // remove all events handlers from previous call 
    $(boothid).find('*').unbind() ; 

}


/**-----------------------------------------------------------------------------
* This function initialize the webrtc session and display dynamics
* media_options defines what we want to do with the multitemdia interface 
*   can be  : picture_snap | audio_recording | video_recording 
* src type if the source elemen namecalling this function -  (used when saving on server side) 
*-----------------------------------------------------------------------------*/
function init_webrtc(media_options, srctype){
  if (typeof media_options === 'undefined') var media_opts="all"; else var media_opts = media_options;
    
  // check if settings enable this feature
  if (   (media_opts=="audio_recording" && !display_settings.audio.audio_rec_online) 
      || (media_opts=="video_recording" && !display_settings.video.video_rec_online) 
      || (media_opts=="picture_snap" && !display_settings.picture_rec_online) 
      ) {
    message = 'If you reject access to your local media, this feature cannot be used. Bye.';
    displayMessage(message,false);
    return false; //exit the function 
  }


  // audio context = graph representing connection between audio nodes 
  window.AudioContext = window.AudioContext || window.webkitAudioContext;
  var audioCtx = new AudioContext();
  var real_sample_rate = audioCtx.sampleRate; // get the sample rate capabilities of the device
  var gainNode = audioCtx.createGain();
  var analyserInNode = audioCtx.createAnalyser();
  var analyserOutNode = audioCtx.createAnalyser();
  var bufferSize = 2048;

  // create Oscillator node DEBUG 
  // var oscillator = audioCtx.createOscillator();
  // oscillator.type = 'sine';
  // oscillator.frequency.value = 400; // value in hertz
  // oscillator.start();

  var display_analysers=true; 

  // init the system sounds tracks
  var sys_sound_collection = init_sys_sounds(); 

  // Audio format options   
  var wav_channels=2; // set to 1 for Mono_ 2 for 2 channels 
  var wav_sampleRate=16000; // forced sample resolution on kHz  can be 8000, 16000, set to FALSE to use default 



  function process_webrtc(localMediaStream){
      // init the display zones 
        display_booth(media_opts);


        // CLOSEEVENT  all media stram collection. 
        $('#my_booth .close').click(function(e){ 
          // localMediaStream.stop(); is_live_stream_open=false;
          $('#my_booth_mask').hide(); $('#my_booth').hide(); 
          // disconnect all audio nodes: 
          microphoneNode.disconnect(gainNode);
          analyserInNode.disconnect(recorderNode);
          recorderNode.disconnect(audioCtx.destination);
          recording=false; 
        }); 

        //connect video stream to video booth
        var _video = $('#my_booth #my_main_video')[0];
        _video.src = window.URL.createObjectURL(localMediaStream);

        // Note: onloadedmetadata doesn't fire in Chrome when using it with getUserMedia.
        // See crbug.com/110938.
        // onloadedmetadata --> replaced with Canplay to be compatible with firefox
        // oncanplay -> called each timeanew stream arrives 
        _video.onloadedmetadata = function(e) {

          _snap_canvas=$('#my_booth #snap_canvas')[0];
          _snap_canvasCtx = _snap_canvas.getContext('2d'); 

          ratio = _video.videoWidth  / _video.videoHeight;
          if (_video.videoWidth==0) ratio = 1.34; // FIREFOX bug whenre  videoWidth is not defined at that time ! 

          if (_video.videoWidth>0) w=_video.videoWidth ; 
          else w = _video.offsetWidth;

          //w=210; 
          h = parseInt(w / ratio, 10);
          _snap_canvas.width = w;
          _snap_canvas.height = h;

          var record_name ="no name yet";
          var genuine_snap_imageData=[]; // to store genuine image datas
          var genuine_dataCopy=[];

          $('.video_snap_btn').click(function(e){
            e.preventDefault();
            var vc =$("#video-countdown"); 
            var counter = 3;   

            // launch the count down 
            vc.css({visibility: "visible"}).html("<p>" + counter + "</p>").show(); 
            vc.delay(400).fadeOut(100);
           
            play_track(sys_sound_collection, 'countdown' );

            setTimeout(ct_action, 700); 


            function ct_action(){
                counter--; 
                if (counter == 0) {
                    // hide counter
                    vc.css({visibility: "hidden"}).html("<p>" + counter + "</p>").hide();
                    play_track(sys_sound_collection, 'capture' );
                     $("#video-flash").show();  // fhow the flash 
                     setTimeout(function() {
                        $("#video-flash").fadeOut(250);
                        // finished and take the picture
                        // _snap_canvasCtx.fillStyle = "black"; // this is for the background not beeing black 
                        _snap_canvasCtx.fillRect(0,0,w,h); 
                        _snap_canvasCtx.drawImage(_video, 0,0,w,h);

                        genuine_snap_imageData = _snap_canvasCtx.getImageData(0, 0, w, h);
                        genuine_dataCopy = new Uint8ClampedArray(genuine_snap_imageData.data);

                        // reset the effect button 
                        $('.snap_effect_btn').removeClass('disabled').attr('z-id', '0'); // set to normal
                        $('.snap_download_btn').removeClass('disabled'); // set to normal 
                        $('.snap_save_btn ').removeClass('disabled'); // set to normal 
 
                        $(".video_effect").text($.i18n._("effect_"+effectsList[0])).show(); 
                        $('.video_effect_range_wrapper').hide();


                     }, 250); 
                    
                } else {
                    vc.html("<p>" + counter + "</p>").show().delay(400).fadeOut(100);
                    setTimeout(ct_action, 700); 
                    play_track(sys_sound_collection, 'countdown' );

                }
            }
          });

          var effectsList = Array('nornal', 'sepia', 'brightness', 'contrast', 'desaturate','grayscale', 'threshold', 'noise', 'invert');
          // to apply effects  
          $('.snap_effect_btn').click(function(e){
            e.preventDefault(); 
            // var rneffect=effectsList[Math.floor(Math.random()*effectsList.length)];
            
            var cur_effectid = parseInt($(this).attr('z-id'))+1; 
            var rneffect = effectsList[cur_effectid];

            if (cur_effectid >= effectsList.length-1) $(this).attr('z-id','-1'); 
            else $(this).attr('z-id',cur_effectid);

            // console.log(rneffect);
            $(".video_effect").text($.i18n._("effect_"+rneffect)).show(); 

            // display ofnot the range slider to tune effects 
            if (in_array(rneffect, ['threshold','brightness', 'noise', 'contrast', 'desaturate'])){
              $('.video_effect_range_wrapper').show(); $('#video_effect_range').val(25);$('.video_effect_range_value').text("25");
            } else $('.video_effect_range_wrapper').hide();

            var imagex = genuine_snap_imageData;
            imageDatax = imagex.data
            imageDatax.set(genuine_dataCopy); // restaure the original datas before processing it

            if (rneffect!="normal") imagex.data = addEffects(imageDatax,rneffect);               
            _snap_canvasCtx.putImageData(imagex, 0, 0);

          }); 

          // effect on slider 
          $('#video_effect_range').change(function(){
            var var1 = $(this).val();
            var cur_effect = effectsList[$('.snap_effect_btn').attr('z-id')]; 
            $('.video_effect_range_value').html(var1);
            if (in_array(cur_effect, ['threshold','brightness', 'noise', 'contrast','desaturate'])){
              var imagex = genuine_snap_imageData;
              imageDatax = imagex.data
              imageDatax.set(genuine_dataCopy); // restaure the original datas before processing it
              imagex.data = addEffects(imageDatax,cur_effect, var1);               
              _snap_canvasCtx.putImageData(imagex, 0, 0);

            } 
          }); 

      
          $('.snap_download_btn').click(function(e){
              e.preventDefault();  
              record_name =  'my_snap_' + new Date().getTime() + '.png'; 
              snap_url=_snap_canvas.toDataURL('image/png'); 
              $('.snap_download_hidden').attr('href', snap_url).attr('download', record_name); 
              $('.snap_download_hidden')[0].click(); 
              // window.open(snap_url);
          });

          $('.snap_save_btn').click(function(e){

              if ($(this).hasClass('disabled')) return false ; // quit 

              var datauri =  _snap_canvas.toDataURL('image/png'); 

              if (datauri) {
                payload= "action=save&type=pictureblob&subtype="+srctype+"&name=mysnap.png&datauri="+datauri;
                $.ajax({
                  type: 'POST', url: "phpsvr/tmp2.php",
                  data: payload,
                  // cache: false,contentType: false, processData: false,
                  dataType: "json", // important to indicate the returned format 
                  xhr: function() {
                     var req = $.ajaxSettings.xhr();
                      if (req) {
                          req.upload.addEventListener('progress', function(e) {
                            if (e.lengthComputable) {
                              var percentVal = Math.round(e.loaded / e.total * 100)  + '%';
                              // console.log(percentVal); 
                              // rel_progress.find('.bar').width(percentVal) ; 
                              // rel_progress.find('.percent').html(percentVal);
                            }
                          }, false);
                      }
                      return req;
                  },
                  success: function (response) {
                    var t3='';
                    if (response.success){
                      // console.log(response.data);
                      // add all the medias elements 
                      // var thisbaseidx = "filename"; // for audio or video 
                      var thisbaseidx = (response.sftype) ? (response.sftype) : "filename" ; 
                      var imgid = findFreeImgPreviewId(thisbaseidx); 
                      if (!imgid) displayMessage("no more space left to save the recorded element", false); 
                      else {
                        // normal case =  add the preview area and copy call the display content 
                        // var thebutton = $('#uploadbtn_'+thisbaseidx+'_'+imgid) ; 
                        // var previewid = thisbaseidx+"_fileupload_preview_"+imgid; 
                        // var previewthumbid = thisbaseidx+"_fileupload_thumb_"+imgid; 
                        // thebutton.before('<div class="fileupload_preview '+thisbaseidx+'" id="'+previewid+'"  imgid="'+imgid+'"><img width="40px" height="40px" src="" id="'+previewthumbid+'"></div>'); 
                        // thebutton.hide();
                        // addDomImgPreview(previewid,response.data,thisbaseidx); // add the image in the right place  

                        var wherepreview = $('#uploadbtn_'+thisbaseidx+'_'+imgid); 
                        add_media_preview(wherepreview, response.data);

                        $('#my_booth .close').click(); // exit the window
                      }

                    } else {
                      //alert (response.message);
                      displayMessage(response.message, false); 
                    }
                  } // end success
                });// end Ajax call 
              }
            });
        };


        // process the audio files - create aa Source audio NODE which can then be connected 
        // microphone -> processing -> destination ; 
        var microphoneNode = audioCtx.createMediaStreamSource(localMediaStream);
        // var microphoneNode=oscillator; // DEBUG
        recorderNode = audioCtx.createScriptProcessor(bufferSize, 2, 2);

        // connect all that
        microphoneNode.connect(gainNode);

        
        if (display_analysers){
          gainNode.connect(analyserInNode);
          analyserInNode.connect(recorderNode);
          // recorderNode.connect(analyserOutNode);
          // analyserInNode.connect(analyserOutNode);
          // analyserOutNode.connect(audioCtx.destination);
          recorderNode.connect(audioCtx.destination);
          
        } else {
          gainNode.connect(recorderNode);
          recorderNode.connect(audioCtx.destination);
        }


        // functions for the analyzers 
        if (display_analysers){
          var canvas_in = document.querySelector('#in-visu');
          visualize(analyserInNode,canvas_in);
        }

        var leftchannel = [];
        var rightchannel = [];
        var recorder = null;
        var recording = false;
        var recordingLength = 0;

        // event handlers for the mute button 
        $('#my_booth .mute_btn').click(function(e){
          $(this).toggleClass('muted'); 
          if ($(this).hasClass('muted')) gainNode.gain.value=0 ; // 1 for unmute  
          else gainNode.gain.value=1 ;
        }); 

        $('#my_booth .record_btn').click(function(e){

          $('.visu_timeline').hide(); 

          if ($(this).hasClass('recording')) { 
            $(this).removeClass('recording') .find('label').text($.i18n._($(this).attr('z-label')));
            recording=false;
            if (recordingLength) {
              // console.log("recording length="+recordingLength); 
              // console.log("recording time ("+real_sample_rate+") ="+recordingLength/(real_sample_rate)+"s"); 
              create_wav(); 
            }
            else console.log("ERROR - no file recorded");
          } 
          else  {
            $(this).addClass('recording').find('label').text($.i18n._($(this).attr('z-label-alt')));
            recording=true;
            // leftchannel.length = rightchannel.length = 0;
            leftchannel=[]; rightchannel=[]; 
            recordingLength = 0;
            // console.log(recorderNode); 
          } 
        }); 

        // this is called every 48 000 sample per seonds and buffer of 2048
        //= 48000/2048 =  0,042s = 42ms
        var rec_time=0; 
        var it=0;  
        var forcedstop=false; 
        var max_recording_seconds= (display_settings.audio.audio_rec_max_duration ) ? parseInt(display_settings.audio.audio_rec_max_duration) : 600 ; 
        recorderNode.onaudioprocess = function(e){
          // console.log("on audio process for process");
          if (!recording) { rec_time=0;it=0;forcedstop=false;return;} // exit 
          var left = e.inputBuffer.getChannelData(0);
          var right = e.inputBuffer.getChannelData(1);

          // we clone the samples
          leftchannel.push (new Float32Array (left));
          rightchannel.push (new Float32Array (right));
          recordingLength += bufferSize;

          rec_time= (recordingLength/real_sample_rate);
          it++ ; 

          if (rec_time>=max_recording_seconds) {
            recording=false;  it=3; rec_time=max_recording_seconds;forcedstop=true;
          } // stop the rcecording and force a display 
          
          
          if (it==3){ 
            $('.record_duration').html(format("# ##0.000", rec_time) + '/' + max_recording_seconds+'s');
            it=0; 
            if (forcedstop)  
              $('#my_booth .record_btn').click(); // force aclick
          }

          // live display the wav form
          if (!forcedstop){
            var canvaswav = document.getElementById( "wavedisplay" );
            drawBuffer(canvaswav, left );
          }

        }



        
        // create the wav file from input buffer 
        function create_wav(){
            // we flat the left and right channels down
            var leftBuffer = mergeBuffers ( leftchannel, recordingLength );
            var rightBuffer = mergeBuffers ( rightchannel, recordingLength );

            // display them into visualization screen
            var canvaswav = document.getElementById( "wavedisplay" );
            drawBuffer(canvaswav, leftBuffer );

            // we interleave both channels together
            var interleaved = interleave ( leftBuffer, rightBuffer );
            var view  = encodeWAV(interleaved) ;    


            // our final binary blob
            var blob = new Blob ( [ view ], { type : 'audio/wav' } );
            var record_name =  'my_recording_' + new Date().getTime() + '.wav'; 
            
            // let's save it locally
            var url = (window.URL || window.webkitURL).createObjectURL(blob);

            // saveit temporaty in an audio player
            _audioPlayer=$("#wav_audio_player")[0];
            _audioPlayer.src = url ;
            _audioPlayer.play(); // play by default

            $('.wav_playstop_btn').click(function (e){
              e.preventDefault();
              if(_audioPlayer.paused) { _audioPlayer.play(); $(this).find('label').text($.i18n._($(this).attr('z-label-alt')));  }
              else {_audioPlayer.pause(); _audioPlayer.currentTime = 0; $(this).find('label').text($.i18n._($(this).attr('z-label'))); }// force a stop !
            }); 

            _audioPlayer.addEventListener('timeupdate',function (){
                var duration = _audioPlayer.duration;    // Durée totale
                var time     = _audioPlayer.currentTime; // Temps écoulé
                var fraction = time / duration;
                var percent  = Math.ceil(fraction * 100);

                $('.visu_timeline').css('width', 300*fraction+'px').show(); 

                // var _progressbar = _controls.find('.media-progress .progress-bar');
                // _progressbar.width(percent + '%');
                // _progressbar.text(percent + '%');

                // var _progresstime = _controls.find('.progress-time');
                // _progresstime.text(formatTime(time));

                // var _progressduration = _controls.find('.progress-duration');
                // _progressduration.text(formatTime(duration));

                // end of file 
                play_stop_ctrl = $('.wav_playstop_btn'); 
                if (fraction==1)
                  play_stop_ctrl.find('label').text($.i18n._(play_stop_ctrl.attr('z-label'))); // play 
                else {
                 if(!_audioPlayer.paused) play_stop_ctrl.find('label').text($.i18n._(play_stop_ctrl.attr('z-label-alt'))); // pause display
                }

            });


            // create a link andsimulate a click on it 
            // var link = window.document.createElement('a');
            // link.href = url;
            // link.download = 'output.wav';
            // var click = document.createEvent("Event");
            // click.initEvent("click", true, true);
            // link.dispatchEvent(click);

            $('.wav_download_btn').attr('href', url).attr('download', record_name).click(function(e){
              donothing=1;
            }); 

            // save it on server side 
             $('.wav_save_btn').click(function (e){
              e.preventDefault();

              var payload=new FormData();
              payload.append("uploadedfile",blob, record_name);
              payload.append( 'type', 'audioblob' );
              payload.append( 'lid', 0);
              payload.append( 'what', 'ad' );

              //hide the button and display the loading
              var rel_progress=$('.wav_save_progress'); 
              rel_progress.show();
              $(this).hide();  

              // make the ajax call
              $.ajax({
                type: 'POST',
                url: "phpsvr/tmp2.php",
                data: payload,
                cache: false,contentType: false,processData: false,
                dataType: "json", // important to indicate the returned format 
                xhr: function() {
                    var req = $.ajaxSettings.xhr();
                    if (req) {
                        req.upload.addEventListener('progress', function(e) {
                          if (e.lengthComputable) {
                            var percentVal = Math.round(e.loaded / e.total * 100)  + '%';
                            //console.log(percentVal); 
                            rel_progress.find('.bar').width(percentVal) ; 
                            rel_progress.find('.percent').html(percentVal);
                          }
                        }, false);
                    }
                    return req;
                },
                
                success: function (response) {
                  var t3='';

                  if (response.success){
                    // add all the medias elements 
                    // add_media_preview(xtop, response.data);
                    // console.log(response.data);
                    var thisbaseidx = (response.type=="audioblob") ? "audiourl" : "videourl" ; // for audio or video 
                    var imgid = findFreeImgPreviewId(thisbaseidx); 
                    if (!imgid) displayMessage("no more space left to save the recorded element", false); 
                    else {
                      // normal case =  add the preview aread and copy call the display content 
                      // var thebutton = $('#uploadbtn_'+thisbaseidx+'_'+imgid) ; 
                      // var previewid = thisbaseidx+"_fileupload_preview_"+imgid; 
                      // var previewthumbid = thisbaseidx+"_fileupload_thumb_"+imgid; 
                      // thebutton.before('<div class="fileupload_preview '+thisbaseidx+'" id="'+previewid+'"  imgid="'+imgid+'"><img width="40px" height="40px" src="" id="'+previewthumbid+'"></div>'); 
                      // thebutton.hide();
                      // addDomImgPreview(previewid,response.data,thisbaseidx); // add the image in the right place  

                      var wherepreview = $('#uploadbtn_'+thisbaseidx+'_'+imgid); 
                      add_media_preview(wherepreview, response.data);

                      $('#my_booth .close').click(); // exit the window
                    }
                  } else {
                    //alert (response.message);
                    displayMessage(response.message, false); 
                    // rel_topobj = rel_button.parent();
                    // rel_topobj.find('.pic_photo_upload').removeClass('progressing');
                    // rel_topobj.find('.progress').hide();
                    // rel_topobj.find('.hidden-file-input').show();
                  }
                  
                } // end success
              });




            }); 

        }


        // audio processig elements
        function interleave(inputL, inputR){

          var  mono_channel= (wav_channels==1)? true: false; 
          var resamplingratio=false; 

          if (mono_channel) var length = inputL.length ;
          else var length = inputL.length + inputR.length;

          //applying the resampling
          if (wav_sampleRate){
             resamplingratio =   real_sample_rate/wav_sampleRate ; 
             // console.log(resamplingratio) ; 
             length=length/resamplingratio ; // reduce the length
          }

          var result = new Float32Array(length);

          var index = 0,inputIndex = 0;
          while (index < length){
            if (mono_channel){
              result[index++] =0.5 * (inputL[inputIndex] + inputR[inputIndex]);
            }
            else {
              result[index++] = inputL[inputIndex];
              result[index++] = inputR[inputIndex];
            }
            // make the resampling 
            if (resamplingratio>1) inputIndex += resamplingratio;
            else inputIndex++
          }
          return result;
        }


        function mergeBuffers(recBuffers, recLength){
          var result = new Float32Array(recLength);
          var offset = 0;
          for (var i = 0; i < recBuffers.length; i++){
            result.set(recBuffers[i], offset);
            offset += recBuffers[i].length;
          }
          return result;
        }

        function writeUTFBytes(view, offset, string){ 
          var lng = string.length;
          for (var i = 0; i < lng; i++){
            view.setUint8(offset + i, string.charCodeAt(i));
          }
        }

        function encodeWAV(samples){
          var buffer = new ArrayBuffer(44 + samples.length * 2);
          var view = new DataView(buffer);
          var sampleRate = 44100;
          if (wav_sampleRate) sampleRate = wav_sampleRate ; // modify the sample resolution 

          // .WAV - STANDARD 
          // 44.1 kHz
          // 16 bit 
          // stereo
          // = 176kB/sec  -> 30 sec = 5,2MB ! 

          // .WAV - LOW RESOLUTION  
          // 8 kHz
          // 16 bit 
          // stereo
          // = 32kB/sec  -> 30 sec = 0,96MB ! 

          // .WAV - MEDIUM RESOLUTION  
          // 16 kHz
          // 16 bit 
          // stereo
          // = 64kB/sec  -> 30 sec = 2MB ! 

          // write the WAV container, check spec at: https://ccrma.stanford.edu/courses/422/projects/WaveFormat/
          /* RIFF identifier */
          writeString(view, 0, 'RIFF');
          /* file length = 32 + Subchunk2Size*/
          view.setUint32(4, 32 + samples.length * 2, true);
          /* RIFF type */
          writeString(view, 8, 'WAVE');
          /* format chunk identifier */
          writeString(view, 12, 'fmt ');
          /* format chunk length */
          view.setUint32(16, 16, true);
          /* sample format (raw 1=PCM) */
          view.setUint16(20, 1, true);
          /* channel count 2 for stereo */
          view.setUint16(22, wav_channels, true);
          /* sample rate */
          view.setUint32(24, sampleRate, true);
          /* byte rate (sample rate * block align) SampleRate * NumChannels * bytes per sample */
          view.setUint32(28, sampleRate * wav_channels * 2, true);
          /* block align (channel count * bytes per sample) */
          view.setUint16(32, wav_channels*2, true);
          /* bits per sample here it's 16 */
          view.setUint16(34, 16, true);
          /* data chunk identifier */
          writeString(view, 36, 'data');
          /* data chunk length  Subchunk2Size     = NumSamples * NumChannels * BitsPerSample/8 */
          view.setUint32(40, samples.length * 2, true);

          floatTo16BitPCM(view, 44, samples);

          return view;
        }

        function floatTo16BitPCM(output, offset, input){
          for (var i = 0; i < input.length; i++, offset+=2){
            var s = Math.max(-1, Math.min(1, input[i]));
            output.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
            // output.setInt16(offset,  input[i] * 0x7FFF, true);
          }
        }

        function writeString(view, offset, string){
          for (var i = 0; i < string.length; i++){
            view.setUint8(offset + i, string.charCodeAt(i));
          }
        }
      }



  if (is_webrtc_capable)
  {
    if (media_opts=="audio_recording") web_rtc_context =   {video: false, audio: true}; 
    else if (media_opts=="picture_snap") web_rtc_context =   {video: true, audio: false};
    else  web_rtc_context =   {video: true, audio: true};

    // specila patch to check if we need to re-create the stream 
    if (prev_media_opts!='' && prev_media_opts!=media_opts) { is_live_stream_open=false; globalMediaStream.getTracks().forEach(track => track.stop());}


    // Not showing vendor prefixes.
    if (!is_live_stream_open){
      navigator.getUserMedia(web_rtc_context, 

        // IF SUCCESS  -> function call for success 
        function(localMediaStream) {
          // get the streams 
          // console.log(localMediaStream) ;
          globalMediaStream = localMediaStream ; 
          is_live_stream_open=true;
          prev_media_opts=media_opts; 
          // console.log('== Creating a new MEDIASTREAM ');
          process_webrtc(localMediaStream);

        }, 

        // if ERROR function call for error 
        function(e) {
          message = 'If you reject access to your local media, this feature cannot be used. Bye.';
          displayMessage(message,false);
         
        }
      ); // end call getUserMedio
    } else {
      localMediaStream = globalMediaStream ; 
      process_webrtc(localMediaStream);
      // console.log('== Reusing existing open MEDIASTREAM .... ');

    } // end of when active functions


  } // end is webrtc 
  else {
    message = 'This capability (getUserMedia) is not supported in your browser';
    displayMessage(message,false);
  }
}


function drawBuffer(canvaswav, data ) {
    var width = canvaswav.width, height = canvaswav.height, context = canvaswav.getContext('2d') ; 
    var step = Math.ceil( data.length / width );
    var amp = height / 2;
    // context.fillStyle = "silver";
    context.fillStyle ='rgb(255, 255, 255)';
    context.fillRect(0,0,width,height);
    for(var i=0; i < width; i++){
        var min = 1.0;
        var max = -1.0;
        for (j=0; j<step; j++) {
            var datum = data[(i*step)+j]; 
            if (datum < min)
                min = datum;
            if (datum > max)
                max = datum;
        }
        context.fillStyle = 'rgb(200, 50, 50)';
        // context.fillRect(x,y,width,height);
        context.fillRect(   i,  (1+min)*amp,        2,        Math.max(1,(max-min)*amp));
        // context.fillRect(   i,  (1+min)*amp,        2,  2);
    }
}


function visualize(analyser, canvas){

    WIDTH = canvas.width;
    HEIGHT = canvas.height;

    var canvasCtx = canvas.getContext("2d"); // get an object to be able to draw on it  ! 

    analyser.fftSize = 256; 
    //Is an unsigned long value representing the size of the FFT (Fast Fourier Transform) to be used to determine the frequency domain.   
    
    var bufferLength = analyser.frequencyBinCount;
    //Is an unsigned long value half that of the FFT size. This generally equates to the number of data values you will have to play with for the visualization
    
    var dataArray = new Uint8Array(bufferLength);

    canvasCtx.clearRect(0, 0, WIDTH, HEIGHT);

    function draw() {
      drawVisual = requestAnimationFrame(draw);
      // call the animation toredraw this object 

      analyser.getByteFrequencyData(dataArray);
      //Copies the current frequency data into a Uint8Array (unsigned byte array) passed into it.

      canvasCtx.fillStyle = 'rgb(255, 255, 255)';
      canvasCtx.fillRect(0, 0, WIDTH, HEIGHT);

      var barWidth = (WIDTH / bufferLength) * 2.5;
      var barHeight;
      var x = 0;

      for(var i = 0; i < bufferLength; i++) {
        barHeight = dataArray[i];

        canvasCtx.fillStyle = 'rgb(' + (barHeight+100) + ',50,50)';
        canvasCtx.fillRect(x,HEIGHT-barHeight/2,barWidth,barHeight/2);

        x += barWidth + 1;
      }
    };

    draw();
}

/**-----------------------------------------------------------------------------
* This function initialize the audio sound collection list
*-----------------------------------------------------------------------------*/
function init_sys_sounds(){
    var  e = ["countdown", "capture"];
    var b = {}, audio_collection = {};

    // load all songs
     if (!!window.Audio) {
        for (var f = e.length; f--; ) {
            var g = new window.Audio();
            g.src = "./audio/" + e[f] + ".ogg";
            audio_collection[e[f]] = g ; 
        }
    }
    return audio_collection; 
}


/**-----------------------------------------------------------------------------
* This function play a given track for a given duration from preloaded sound collection 
*-----------------------------------------------------------------------------*/
function play_track(collection, track, duration){
    if (!!window.Audio) {
        setTimeout(function() {
            if (collection[track]) {
                collection[track].play(); 

            }
        }, duration || 0)
    }
}

/**-----------------------------------------------------------------------------
* This function add effects on RDB datas
*-----------------------------------------------------------------------------*/
function addEffects(dRDBA, effect, var1){
    // storead as RGBA
    //Red, Green, Blue and Alpha can be any integer value from 0 to 255, with the Alpha values representing 0 as transparent and 255 as visible.
    var d= dRDBA; 

    for (var i = 0, l = d.length; i < l; i += 4) {
        if (effect=="red"){
            d[i + 1] = 0; // green
            d[i + 2] = 0; // blue
        }

         if (effect=="invert"){
            d[i] = 255 - d[i]; // r
            d[i + 1] = 255 - d[i + 1]; // g
            d[i + 2] = 255 - d[i + 2]; // b
        }
        if (effect=="special"){
           if (d[i] > 127) {
            d[i + 3] = 127;
            }
        }

        if (effect=="grayscale"){
           var v = 0.2126*d[i] + 0.7152*d[i+1] + 0.0722*d[i+2];
           d[i] = d[i+1] = d[i+2] = v ; 
        }

        if (effect=="threshold"){
           var threshold=128; 
           if (var1) threshold = (256*var1/50) ; // patch when variable is defined
           realvar=threshold; 

           var v = ((0.2126*d[i] + 0.7152*d[i+1] + 0.0722*d[i+2]) >= threshold) ? 255:0;
           d[i] = d[i+1] = d[i+2] = v ; 
        }

        if (effect=="brightness"){
          adjustment=40; 
          if (var1) adjustment = (100*var1/50) ;
          realvar=adjustment; 

          d[i] += adjustment;
          d[i+1] += adjustment;
          d[i+2] += adjustment;
         }

              
        if (effect=="sepia"){
          r = d[i];g = d[i+1]; b = d[i+2];
          d[i] = r * 0.393 + g * 0.769 + b * 0.189;
          d[i+1] = r * 0.349 + g * 0.686 + b * 0.168;
          d[i+2] = r * 0.272 + g * 0.534 + b * 0.131;
        }

        if (effect=="contrast"){
          contrastFactor=1; // var1 must be between -255 and 255 
          if (var1) contrastFactor = (259 * ( ((var1-25)*(255/25)) + 255)) / (255 * (259 - ((var1-25)*(255/25)) ));
          realvar=contrastFactor; 

          d[i] = contrastFactor * (d[i] - 128) + 128;
          d[i+1] = contrastFactor * (d[i+1] - 128) + 128;
          d[i+2] = contrastFactor * (d[i+2] - 128) + 128;
        }

        // noise
         if (effect=="noise"){
          noise= 10 ; 
          if (var1) noise = var1 - Math.random() * var1 / 2;
          realvar=noise;
          d[i] += noise;
          d[i+1] += noise;
          d[i+2] += noise;
        }

        // desaturate
        if (effect=="desaturate"){
          desaturate= 0 ; // must be from 0 to 1  max 
          if (var1) desaturate = var1 / 50;
          realvar=desaturate;
          average = ( d[i] + d[i+1] + d[i+2] ) / 3;
          d[i] += ((average - d[i]) * desaturate);
          d[i+1] += ((average - d[i+1]) * desaturate);
          d[i+2] += ((average - d[i+2]) * desaturate);
      }

    } 

    console.log('realvar='+realvar);          
    return d;
}









