
/******************************************************************************
 * ZADS MAIN JS script
 *
 * @category   MainPackage
 * @package    ZADS
 * @author     Patrice COHAUT <patrice.cohaut@gmail.com>
 * @copyright  2013-14 PATMISC
 * @version    6.0.0
 ******************************************************************************/


var advancedcontactform=true;
var cur_user=false;
var EMAILREG=/^([a-zA-Z0-9_\-\.]*)[a-zA-Z0-9]@([a-zA-Z0-9\-\.]*)[a-zA-Z0-9]\.[a-zA-Z]{2,3}$/;

var contactreason_options_obj=  [
    { name : '-- select one --', value : '0', scope :'all',   style:''},
    { name : 'Subscription', value : 'subscription', scope :'all', style:''},
    { name : 'Information', value : 'information', scope :'all', style:''},
    { name : 'Advertising', value : 'advertising', scope :'all', style:''},
    { name : 'Support', value : 'support', scope :'all', style:''},
    { name : 'Other', value : 'other', scope :'all', style:''}
]; 

//-----------------------------------------------------------------------------
$(document).ready(function() {

  //---  init language to define the cur_language and set the right paramaters
  var cur_lang = detect_lang(); 
  $.i18n.setDictionary(my_dictionary[cur_lang]);

  // refresh text from main page calling.  
  $('.totranslate').each(function(idx,elem){
    elem.innerHTML=$.i18n._(elem.innerHTML);
  });

  // create the ScrollToTop button and handler Coutesry Pinterest
  var a = "<a id='ScrollTop' href='#' class='bton dm_button2 ScrollTop Off'><strong>"+$.i18n._('Top')+"</strong></a>";
  $("body").append(a);
  var c = $(window).height() / 2;
  $(window).scroll(function() {
      (window.innerWidth ? window.pageYOffset : document.documentElement.scrollTop) >= c ? $("#ScrollTop").removeClass("Off") : $("#ScrollTop").addClass("Off")
  });
  $("#ScrollTop").click(function() {
      $("html, body").animate({scrollTop: "0px"}, 400);
      return false
  }); 

  // -- map footer links to events
  $(".footer-links").each(function(i,e){
    var xhref = $(this).attr("href");
    if ((xhref=="#") || (xhref=="contact"))  {
      $(this).click(function(e) { 
          e.preventDefault();  
          display_EMAIL_FORM_static('support', "", "", "" );
      return true; 
      }); 
    }
  });



  // special patch for tooltips on pricing table
  $('.tooltipwanna').parent().hover(
    function() {
      $( this ).find('.tooltipwanna').addClass("hovered");
    }, function() {
      $( this ).find('.tooltipwanna').removeClass("hovered");
    }
  );

});


// determine the language to be used 
// decision criterias =  1. cookie present 2.navigator language  
function detect_lang(){
  // manage the authorized list coming back from PHP server though INDEX file. 
  authorized_languages =  $('body').attr('xzads-lang-support'); 

  //GLOBAL cur_lang is a globlal variable ; 
  var cookval =  readCookie('ZADS_LOCAL');
  if (cookval){
        e = $.unserialize(cookval); 
        if (e['type']=='local') cur_lang = e['lang'];       
  } else{
      // get the language code //
      // ---> This is not working, we use the PHP stored info instead (very custom !) 
      //var langcode = (navigator.language) ? navigator.language : nav igator.userLanguage; 
      var langcode= $('body').attr('xzads-lang'); 
      cur_lang = (langcode) ?  langcode : authorized_languages.split(';')[0]; // default to french 
  }
  return cur_lang; 
}

// ----------------------------------------------------------------------------
// Global handling of received AJAX messages 
// ----------------------------------------------------------------------------   
function processAjaxReceivedMessage(data) {
  displayMessage(data.message,data.success,'',data.action);
  return true; 
}; 


function hide_loading_msg(){
  $('#adlist').css("opacity","1");
  $('.oe_wrap').slideUp(200); 
};


/**-----------------------------------------------------------------------------
* This function display an HTML message through a modal box 
*
* @param  str_message {HTML str} text to be displayed 
* @param  msg_success {bool} TRUE if this is a Success/info message FALSE if error
* @param  forcetype {string} force a type to be displayed {no-title | attention | info | checkmark | errorm}
* @param  nav {string} indicate what to do on message closure
* 
*-----------------------------------------------------------------------------*/
function displayMessage(str_message, msg_success, forcetype, nav) {
  
  if (!forcetype || (forcetype=="")){
    if (msg_success){
      type="checkmarkm";  title=$.i18n._("success"); timeout = 2000;  // 2 sec
    }else {
      type="errorm";title=$.i18n._("error");timeout = 0;
    }
    
  } else {
    type=forcetype; timeout = 0;
    if (forcetype=="no-title"){title=''; type='';}
    else title=$.i18n._(forcetype);
  }

  content =  $.i18n._(str_message); 
  id =  "#dialog";   
  launch_modalbox(id, type, title , content, timeout, nav); 

  return true; 
};

 

/**-----------------------------------------------------------------------------
* This function is a genric AJAX call function 
* 
* @param  {boolean}  what2do is the main list of paramaters to send
* @param  {boolean}  add_cur_nav is the list of param to add . if "", then we use the local nav
* @param  {boolean}  valflag : if set to true then check and serialize the form content 
* 
* @return {boolean} true
*-----------------------------------------------------------------------------*/
function ajax_action(what2do, add_cur_nav, valflag, formobj){
  var call_ajax = true ; 
  var dataFORMString="";
  var dataNAVstring="";
  var serverurl="";  
  
  // VALIDATION of the form
  if (valflag){
    if (validate_FORM(formobj)){
     // launch using the serialize feature 
     dataFORMString = "&"+$("#form2").serialize();

     // special case of settings, add the radio / not checked 
     var str='';
     var str1 = $("#form2 input:radio[checked=false].onoffswitch-checkbox").map(function () {
        return this.name + "=" + false; }).get().join("&");
      if (str1 != "" && str != "") str += "&" + str1;
      else str += str1;


      var str='';
      $("#form2 .onoffswitch-checkbox").each(function(){
        if ($(this).is(":checked")) toto=1; 
        else if (str!="") str+="&"+this.name +"=false" ; else  str+=this.name +"=false"; 
      }); 
      
      if (str!='') dataFORMString +="&"+str;


    }
    else {
     call_ajax = false; 
     displayMessage("error in form checking",false);
    }
   }
   
   // MERGE  with current nav if requested 
   if (add_cur_nav && (add_cur_nav!="")) {
    what2do =  merge_href(what2do,add_cur_nav);  
   } 
   else dataNAVstring=""; 
   
   // calculate the ajax param call
   totalajaxdata = what2do+""+dataFORMString;  
   totalajaxdata2 = '#'+totalajaxdata;
   
   
   // check if anchor contains action=list  replaced EVAL function with detection to speed up.
   if (totalajaxdata2.indexOf("action=list") != -1) {
    display_loading_msg("Action in progress ...");
   }

   // detect the settings elements
   if (totalajaxdata2.indexOf("settings=") != -1) {
    serverurl =  "phpsvr/admin_settings.php";
   }  else if (totalajaxdata2.indexOf("emails=") != -1) {
    serverurl =  "phpsvr/emails_templates_server.php";
   }  else if (totalajaxdata2.indexOf("subscribers=") != -1) {
    serverurl =  "phpsvr/subscribers_server.php";
   }
   else if  ((totalajaxdata2.indexOf("res=") != -1) ||  (totalajaxdata2.indexOf("files=") != -1)) {
    serverurl =  "phpsvr/file_manager_server.php";
   } //default server 
   else serverurl =  "phpsvr/tmp1.php";
   
   // add loggeduserid for logs 
   if (cur_user)
    totalajaxdata = totalajaxdata+"&curuserid="+cur_user.id;

   if (call_ajax){
      $.ajax({
        type: "POST",
        url: serverurl,
        data: totalajaxdata,
        success:  function(data){
          hide_loading_msg();
          processAjaxReceivedMessage(data);
        },
        dataType: "json"  
      });
  }
  return (false); 
};


/**-----------------------------------------------------------------------------
* This function lauches  modal box with specified parameters
*
* @param {string} id  id of the Modal box to call 
* @param {string} type  : attention | info | checkmark | error | {nothing -> no title} | dummy (for no image)
* @param {string} title   : title to be displayed in the title area 
* @param {string} content   : content to be displayed in the body area 
* @param {integer} timeout   : amount in Ms to wait before closing automaticlly the modal box. O : no close
* @param {integer} nav   : indication to direct on what to do next closure of the modal box
* @return TRUE if no error found.
* 
*-----------------------------------------------------------------------------*/
function launch_modalbox(id, type, title , content, timeout,nav, size){

    //Get the screen height and width
    //var maskHeight = $(window).height();
    
   //Get the window height and width
    var winH = $(window).height();
    var winW = $(window).width();
    
    var maskHeight =getPageHeight()+$(window).scrollTop();
    var maskWidth = winW;
    

    //Set height and width to mask to fill up the whole screen and display it
    $('#mask').css({'width':maskWidth,'height':maskHeight}).fadeTo("fast",0.5); ;

    // set to full size if specified 
    if (size=="fullwidth") { $(id).css({'width':'auto'});}
    else $(id).css({'width':''});
    
    $(id + ' #mbox-header').remove();  // remove title if exists from previous call
    if ((title!="") || (type!="")) {
      $(id).prepend('<div id="mbox-header"><div class="text">'+title+'</div>'); // add icon
      if ((type!="") && (type!="dummy")) $(id + ' #mbox-header').prepend('<div class="icon '+type+'"></div>'); // add icon
    }
    $(id + ' #mbox-body').html("<p>"+content+"</p>"); 
 
    // add the buttons 
    //$('.mbox-window .close').html($.i18n._("modbox close"));
    tleft = Math.max(0,(winW/2-$(id).width()/2) + $(window).scrollLeft());
    ttop = Math.max(0,(winH/2-$(id).height()/2) + $(window).scrollTop());

    $(id).css('top', ttop);
    $(id).css('left', tleft);
    
    //transition effect
    $(id).fadeIn(200); 
    
    // run timeout if necessary 
    if (timeout !=0) { 
      $(id).delay(timeout).fadeOut('fast', function(){
        $('#mask, .mbox-window').fadeOut('fast');
        if ((nav=="create") || (nav=="update")){
         $('html,body').animate({scrollTop: 0}, 300,'easeOutBack');
        }
        });
      }
     //if close button is clicked
     $('.mbox-window .close').click(function (e) {
      //Cancel the link behavior
      e.preventDefault();
      $('#mask, .mbox-window').hide();
      if ((nav=="create") || (nav=="update"))
        $('html,body').animate({scrollTop: 0}, 300,'easeOutBack');
     });    
  
    //if mask is clicked
    $('#mask').click(function () {
      $(this).hide();
      $('.mbox-window').hide();
      if ((nav=="create") || (nav=="update"))
        $('html,body').animate({scrollTop: 0}, 300,'easeOutBack');
    });   
    
    // if windows is resized when Modal is displayed  
    $(window).bind('resize', function(e) {
    
      var maskHeight = $(document).height(); 
      var maskWidth = $(window).width(); 
  
      //Set height and width to mask to fill up the whole screen 
      $('#mask').css({'width':maskWidth,'height':maskHeight}); 
    });     
};

function hide_modalbox(){
  $('#mask, .mbox-window').hide();
  return true;
}; 



/**-----------------------------------------------------------------------------
* This function build and display the Email formular depending on various conditions
*
* @param  formtype {String} lost|support|contact|remind|abuse|contactuser|feedback
* @param  preHTML {String} html text to be displayed on top the of form.
* @param  elemID {String} ID of the element to which email is attached 
* @param  what {String} the type of element .
* @return {boolean} TRUE when everything goes well
* 
*-----------------------------------------------------------------------------*/
function display_EMAIL_FORM_static(formtype, elemID, what, preHTML ){


  
  t="";
  label_class = "labelform2";

  if (preHTML) t += preHTML;  // to add  pre-messages


  t += '<form id="email_form" name="" action="" class="static_contact_form">  ';
  t +=  '<input type="hidden"  name="type" value="'+formtype+'"></input>';
  t += '<H1 class="orange_text">'+$.i18n._('email '+formtype+' form title')+'</H1>'; 
  t += '<p>'+$.i18n._('email '+formtype+' form introduction')+'</p>'; 
  t += '<BR>';
  

  t += '<div class="'+label_class+'"><div>'+$.i18n._("your email")+':</div></div>';
  t += '<div class="adinput2">';
   if (!cur_user){
      t +=  '<input name="email"  regexp="EMAILREG" mandatory="yes" id="email" size="30" maxlength="60" type="text" class="text" value=""></input>';
    } else {   
    t +=  '<input type="hidden"  id="email" name="email" value="'+cur_user.email+'"></input>';
    t +=  '<span>'+cur_user.email+'</span>';
  }
  t += '</div>';


    
  t += '<div class="'+label_class+'"><div>'+$.i18n._("contact reason")+':</div></div>';
  t += '<div class="adinput2">';
  t +=  '<select  name="contactreason" id="contactreason" mandatory="yes">';
  t += build_DOM_SELECT_options(contactreason_options_obj, '',''); 
  t +=  '</select>';
  t += '</div>';
  t +='<div class="clearer">&nbsp;</div>';  
  
  t += '<div class="'+label_class+'"><div>'+$.i18n._("email title")+':</div></div>';
  t += '<div class="adinput2">';
  t +=  '<input name="emailtitle"  mandatory="yes" id="emailtitle" size="30" maxlength="60" type="text" class="text" value=""></input>';
  t += '</div>';
  
  t += '<div class="'+label_class+'"><div>'+$.i18n._("email description")+':</div></div>';
  t += '<div class="adinput2">';
  t +=  '<textarea name="emaildesc"  mandatory="yes" id="emaildesc" cols="35" rows="5" class="text" value=""></textarea>';
  t += '</div>';

  
  t +='<div class="clearer">&nbsp;</div>';  
  t += '<div class="adactions" align="center">';
  // reserved span to display formular validation errors
  t +='<span id="erroremail" class="error" style="display :none"></span>';

  // button area 
  t += '<div id="adactions_btons_inner"><ul id="bton_tools2">';
  t += '<li><a title="" href="#action=sendmail" class="dm_button2" id="email_btn2">';
  t += '<i class="icon-fa-envelope mr6"></i>'+$.i18n._('submit '+formtype+' email');
  t += '</a></li>';
  t += '</ul>';
  // loading button 
  t += '<div id="email-loading" style="display :none" class="rot-loading"><SPAN></SPAN><p>'+$.i18n._("Message sending in progress")+'</p></div>';
  t += '</div>';
  
  t += '</div>';
  
  t += '</form>';

  // display the form using the launch model form 
  id =  "#dialog"; 
  launch_modalbox(id, '', '' ,t , 0); 
  
  // attach event handlers 
   $('#email_btn2').click (function(e) {
     e.preventDefault();

    var hasError = false;
    var form_hasError = false; // TRUE when at least one error into the form

      $('#email_form :input').each(function(){

        if ($(this).is(":visible")) {
          // find the rule to be applied and check it 
          var varmandatory =  $(this).attr("mandatory");
          var varregexp =   $(this).attr("regexp");
          // convert regexp :   
          var realreg="";
          if (varregexp=="EMAILREG") realreg =  EMAILREG;
          if (varregexp=="NAMEREG") realreg =  NAMEREG; 
          if (varregexp=="PHONENBREG") realreg =  LOC_PHONENBREG; 
          if (varregexp=="URLREG") realreg =  URLREG;  

          hasError = false;    
          
          //console.log(this.name+"-"+$(this).val()+"-"+ this.type+"-"+varmandatory+"-"+realreg); 
          
            if (varmandatory=='yes'){
              // special case for SELECT-ONE 
               if ((this.type=="select-one")) { 
                 if   (($(this).val()=="0")|| ($(this).val()=="00")|| ($(this).val()==0)){
                  error_message=$.i18n._("You must select something.");
                  hasError = true;
                 }
               } 
               // case where Value is BLANK
               else if ($(this).val()=="") {
                  emsg = "You must fill in something.";  
                  error_message=$.i18n._(emsg); 
                  hasError = true;
                } 
               
                else if (!($(this).val().match(realreg))) {
                  error_message=$.i18n._("Incorrect format.");
                  hasError = true;
                }
              }


              if (hasError){


                form_hasError = true;
                $(this).addClass("input-error");
                $("#erroremail").html($.i18n._(error_message)).show();
                 
                // activate binder to remove the error text when selecting someting or typing someting.
                if ((this.type=="select-one") || (this.type=="radio") || (this.type=="checkbox") ){
                  $("#"+this.name).change(function(){
                   $("#"+this.name).parent().children('.error').hide(); 
                   $(this).removeClass("input-error");
                   $("#erroremail").hide();
                  });
                } 
                else
                  $("#"+this.name).keyup(function(){
                   $("#"+this.name).parent().children('.error').hide();
                   $(this).removeClass("input-error"); 
                    $("#erroremail").hide();
                  });

              } 
            } // end of visible 
          }); // end of loop


      if (form_hasError){
        // $("#erroremail").html($.i18n._(error_message)).show();
        return false; 
      } else  
      {
       ahref = $(this).attr('href');
       //ahref = ahref.substring(1); // remove the #
       var tmpx = ahref.split("#");
       ahref = tmpx[tmpx.length-1]; // get just the final elements after latest # to correcr IE bug.
       
       // serialize the form 
       dataString = $("#email_form").serialize();
      
       // make the ajax call
       ajax_action ("sendmail=yes&"+dataString);
       // change the button content :
       $('#bton_tools2').hide();
       $('#email-loading').show();
       return true; 
       
      } 

   });
   
  return true; 
  
}; 

/**-----------------------------------------------------------------------------
* This function build from a JSON array the HTML elements for an OPTION  DOM.
*
* @param dataobj  : the object in JSON format listing the options.
* @param selecteditem : the value of the current selected item (if any).
* @param what : indicate the type of list to match with "scope" filed of JSON table
* @param level means, display only the level indicated here 
* @param hidid  : id of the element to hide from the list (typical SELF)
* @return {string} the HTLM element
* 
*-----------------------------------------------------------------------------*/
function build_DOM_SELECT_options(dataobj, selecteditem, what,level,hideid){
  
  var xdisp ='';
  htmlstr="";
  if (!dataobj) return true;  // case whn no cat defined
  
  $.each(dataobj, function(index, elem) {
  
   if (elem.id=="") tmpid=elem.value; else tmpid=elem.id; 
   if (elem.display) xdisp = elem.display; else xdisp=""; 
   if (elem.name) xname=elem.name; else xname=elem.value; 
   elemclass = elem.style; 

   if (elem.value || (elem.value=="")) xvalue=elem.value; else xvalue = elem.id; //patch for case of no value 
   
   if ((selecteditem) && (selecteditem==xvalue)) {
    elemchecked='selected="selected"';
    elemclass +=' selected'; 
    } else elemchecked=""; 


   // check outthe scope & type element 
   hasToDisplay=false; 
   if ((!what)) hasToDisplay=true; 
   else if (!elem.scope && !elem.type) hasToDisplay=true; 
   else if (((elem.scope) && ((elem.scope=='all') || (elem.scope.indexOf(what) != -1)))) hasToDisplay = true;
   else if (((elem.type) && ((elem.type=='') || (elem.type.indexOf(what) != -1) || (what=='cat')))) hasToDisplay = true; 

   
   // special case for Language (do not display if available is set to false)
   if (elem.hasOwnProperty('available')) {
    if (!elem.available) hasToDisplay=false;
   }

   // manage the L1 and DIASABLED function
   if (elem.level){
    if (elem.level==1) {
        elemclass+= " level1 ";
        xname= ""+$.i18n._(xname).toUpperCase()+"";
        if (elem.type) xname += ' ('+$.i18n._(elem.type + ' only')+')'; 
    } else xname= "-- "+$.i18n._(xname)+"";
    if (elem.childnb) {
      if (level && (elem.level) && (elem.level==level)){toto=1;}
      else {
        xdisp =  " DISABLED "; // if has some child -> we cannot select this  ! 
        elemclass+= " level1 disabled "; 
      }
    }
   } else 
    xname = $.i18n._(xname);

    // patch for level 
    if (level && (elem.level)){
      // hide categories not right level    
      if (elem.level!=level) hasToDisplay=false;
      if (elem.id==hideid) hasToDisplay=false;  // hide the SELF categorie
    }

   // make the real display    
   if (hasToDisplay)
      htmlstr +=  '<option '+xdisp+' value="'+xvalue+'" id="'+tmpid+'" class="'+elemclass+'" '+elemchecked+'  >'+xname+'</option>';
  });
  return htmlstr; 
};
