/******************************************************************************
 * ZADS CUSTOM  JS script
 *
 * @category   CUSTOMPACKAGE for WANNANONCES.COM 
 * @package    ZADS
 * @author     Patrice COHAUT <patrice.cohaut@gmail.com>
 * @copyright  2013-14 PATMISC
 * @version    6.5.6
 ******************************************************************************/


function display_DOM_adlist(whattodisp,dataobj, alldata) {
  //function display_DOM_adlist(whattodisp,dataobj, paged, totnb, sort, view, type, catid, nav, search, status, userid, sortdist) {
    
    var t  = ""; 
    var t2 = "";
    var t_nav="";
    var tmpstr_infinite_nav="";
    var tmpstr_nav_infinite="";
    var adnbr; 
    var imgsize=0;
    var isSearch=false;  if (search && search!="") isSearch=true;
    
    var idxstart = 0; 
    var idxend = 0; 

    // initialize the variable based on global data : 
    var paged = alldata.paged;
    var totnb =  alldata.totnb; 
    var sort = alldata.sort;  
    var view = alldata.view;
    var type = alldata.type;
    var catid = alldata.catid;
    var nav = alldata.nav;
    var search = alldata.search;
    var status = alldata.status;
    var userid = alldata.userid;
    var sortdist = alldata.sortdist;
    var f_locfield =  alldata.locfield; 
    var f_locval = alldata.locval; 

    // Z6.1.5
    // Z6.5.2 - modified to manage default view 
    // if (!view) view = "list"; // default value 
    // var cur_view_class= "list-view"; // defaultvalue for current display view
    cur_list_view=view ;  

    // Z6.1.2 determine if it's a zetevu using the fisrt element
    var this_is_a_zetevu =  (dataobj[0].type=="zetvu" || type=="zetvu") ? true : false; 
    var xdate='', xtitle='', xdesc2='',t2hits=''; // initialize default 
    // end Z6.1.2

    if (!sortdist) sortdist=false; 
    
    // for infinite nav , indicate which iteration we are 
    if (isInfiniteNav && (whattodisp=="ad")){
      infinite_iterationnb+=1; 
      if ((!paged) || (paged==1)) infinite_iterationnb=1; 
      if (enable_infinite_scroll) unbind_win_SCROLL(); // unbind all scroll events
    } else infinite_iterationnb =1; 
    
    if (!sort) sort = "date_desc"; // default value
    
    
    var totaladnbr = totnb;  // total number of returned results .
    var paged=parseInt(paged); 

    if (display_settings) {
      max_pages_to_show = display_settings.max_pages_to_show;  // number of pages to show in direct number.
      AD_ITEMS_PER_PAGE = display_settings.max_items_per_page;
      if (whattodisp=="cat")  AD_ITEMS_PER_PAGE = 50;
    } else {
      max_pages_to_show = 6;
       AD_ITEMS_PER_PAGE = 10; 
    }

    if ((!isInfiniteNav)||(infinite_iterationnb==1)){
      // empty content and hide 
      $('#adlist').html("").hide(); 
      $('#breadcrumbs').html("").hide(); 
      savedit=0; // var used for Googlemap markers
    }    
    // clear and hide other form if already openned
    ad_form_hide(); 
    $('#addetails').html("").hide(); 
    $("#pages").hide(); 
    $("#real_userpro_register_sidebar").remove(); 
    
    // remove existing loading bar if exists 
    $('#adlist #listing-nav-infinite').remove(); 
    
    // get length 
    adnbr =  dataobj.length; 
    if (adnbr>0) {
      // display the Header 
      t += '';  
      t += '<div class="clear" id="listings-header">  ';  
      
      // -------------------- build and display the Navigation bar 
      maxpages = Math.ceil(totaladnbr/AD_ITEMS_PER_PAGE); 

      max_pages_to_show_1 = max_pages_to_show-1 ; 
      half_page_start = Math.floor(max_pages_to_show_1/2);
      half_page_end = Math.ceil(max_pages_to_show_1/2);
      
      pagetostart = paged - half_page_start;
      pagetoend = paged + half_page_end;
      
      end_page = maxpages; 
      nextpage= paged+1;
      prevpage= paged-1;
        
      if (pagetostart<=0) pagetostart=1; 
      if ((pagetoend-pagetostart)!= max_pages_to_show_1) pagetoend = pagetostart + max_pages_to_show_1;
        
      if (pagetoend>maxpages) {
          pagetoend=maxpages;
          pagetostart = maxpages-max_pages_to_show_1; 
       }
      if (pagetostart<=0) pagetostart = 1; 
      
      articlestart = Math.max((paged-1)*AD_ITEMS_PER_PAGE+1, 1); 
      if ((paged*AD_ITEMS_PER_PAGE)>totaladnbr) articleend = totaladnbr; 
      else articleend = (paged*AD_ITEMS_PER_PAGE);
      
      // ------------------- display the NAV banner  -----------------------  
      t_nav += '<div class="clear" id="listings-nav">  '; 
      
      // ---------- breadcrumb -----------------
      var ax = new Array();

      ax.push({text : $.i18n._('Main list') , title: $.i18n._('Main list'), href : '#action=back', cl : 'home', help:'yes'});
    
      // bread for nav 
      if (nav){
        // level1 = My Account or Admin 
        if (userid) ax.push({text : $.i18n._('my_'+nav) , href : '#nav=admin&what=mydashboard', cl :''});
        else ax.push({text : $.i18n._(nav) , href : '#nav=admin&what=dashboard', cl :''});
        
        // if we have a status they we have a Level 2 . All adds or My Adds
        if (status && (status !="") && (status!="admin_") && (status!="admin_all") && (status!="all"))
          if (userid) ax.push({text : $.i18n._('my_'+whattodisp) , href : '#action=list&nav=admin&status=all&userid='+userid+'&what='+whattodisp, cl :''});
          else ax.push({text : $.i18n._('admin_'+whattodisp) , href : '#action=list&nav=admin&status=all&what='+whattodisp, cl :''});
      } 
      else 
        if (type) {
         var p_stub = '#action=list&what='+whattodisp; 
          //z6.1.2 - breadcrumb modifier
          var ttype=(this_is_a_zetevu && zetevu_as_video) ? "bread_zetvu_as_video" : (this_is_a_zetevu && zetevu_as_news) ?  "bread_zetvu_as_news" : type;    
          p_stub += (whattodisp=="user") ? '&utype='+type : '&type='+type ; 
          ax.push({text : $.i18n._(ttype) , title: $.i18n._(type), href : p_stub, cl :''});
      }


      // if user id, add the name of the user
      //Z6.1.2 - removed the display of name as is not indicated usuall
      if (userid && whattodisp!="cat" && !this_is_a_zetevu){
            ussn = dataobj[0].username;
            usln = ussn;
            ax.push({text : ussn, title : usln , href : '#action=display&what=user&id='+userid, cl :''});
      } 


      // patch case of catégory displayed but NAv=admini is not here 
      if (whattodisp=="cat" && !nav){
        if (adnbr==1){ // only one catégory 
          txt= $.i18n._('all admin_cat');
          ax.push({text : txt, title : txt , href : '#action=list&what=cats&nav=admin', cl :''});
        }
      }
      
      // if categorie displayed
      if (catid && catid!=0 )  {
        var catd =  JSON_find_elem_byValue(cat_options,catid); 
        
        cattxt = catd.name; 
        cattxt= get_translated('cat', cur_lang, cattxt);

        if (CAT_WORD_CUT) cattxtshort=my_trim_excerpt(cattxt,CAT_WORD_CUT);

        //Z6.5.3 change - add what2disp user filter
        if ((catd.parentid) &&  (catd.parentid!='') && whattodisp!="user") {
            var catdparent = JSON_find_elem_byValue(cat_options,catd.parentid); 
            catparenttxt=catdparent.name;
            catdparent= get_translated('cat', cur_lang, catdparent);
            if (CAT_WORD_CUT) catparenttxtshort=my_trim_excerpt(catparenttxt,CAT_WORD_CUT);

            // check if master cat or not : 
            if ((catdparent.childnb) && (catdparent.childnb>0)) var xtrapid = "&ispid=yes";
            else  var xtrapid = "";
            ax.push({text : catparenttxtshort, title : catparenttxt , href : '#action=list&what='+whattodisp+'&type='+type+''+xtrapid+'&catid='+catdparent.id, cl :''});
        } 

        // add the category itself
        // check if has child
        //Z6.5.3 change removed else 
        var xtrapid =  (JSON_find_elem_byParentId(cat_options,catd.id)) ? "&ispid=yes" : "";
        ax.push({text : cattxtshort , title: cattxt, href : '#action=list&what='+whattodisp+'&type='+type+''+xtrapid+'&catid='+catid, cl :''});
        
      }

      // search 
      if (search) ax.push({text : $.i18n._("search") , href : '#', cl :''});

      // final end point
      if (nav)
        if  (status && status !="" && (status!="admin_") && (status!="admin_all") && (status!="all")) 
        // push the status info text
        ax.push({text : $.i18n._(status) , href : '#action=list&nav=admin&what='+whattodisp+'&status='+status, cl :''});
        else {
          //Z6.1.2 - patched bread
          var tbend=(this_is_a_zetevu ) ? (zetevu_as_video) ? "zetvu_as_video" : (zetevu_as_news) ? "zetvu_as_news" : "zetvu" : whattodisp;  
          if (userid) ax.push({text : $.i18n._("all my_" + tbend) , href : '#', cl :''});
          else ax.push({text : $.i18n._("all admin_" + tbend) , href : '#', cl :''});
        }
      else {
        // push the all ads display
        //Z6.1.2  - modify end point of breadcrumb 
        var tbend=(this_is_a_zetevu ) ? (zetevu_as_video) ? "zetvu_as_video" : (zetevu_as_news) ? "zetvu_as_news" : "zetvu" : whattodisp;  
        ax.push({text : $.i18n._("all " + tbend) , href : '#', cl :''});
      }

      // --- final BUILD the breadcrumb ----
      t_nav += '<ul id="breadcrumbsul" class="clear">'; 
      $.each(ax, function(i, elem) {
        if ((i+1)==ax.length)
          t_nav += '<li>'+elem.text+'</li>';
        else {
          tt = (elem.help=="yes") ?  'title="'+$.i18n._('help link '+elem.text)+'"' : ""; 
          var ttitle= (elem.title) ? elem.title : elem.text; 
          if (elem.cl=="home") { xtra =  '<i class="icon-fa-home"></i>'; xtext = '';} else { xtra=''; xtext = elem.text;}
          t_nav += '<li><a nottip="yes" title="'+ttitle+'" name="list_ads" href="'+elem.href+'" class="'+elem.cl+'" '+tt+'>'+xtra+xtext+'</a></li>';
          t_nav += '<span>&gt</span>';
        }
      });
      t_nav += '</ul>';
      
      // adding the searh part 
      if (search && search!="") searchtxt = $.i18n._('containing <b>%s</b> word',[search]); else searchtxt=""; 
      t_nav += ' <div class="text-nav">'+searchtxt; 
      t_nav += '</div>';

      //adding the vfields search
      //Z6.5.3 
      if (alldata.f_vfields){
        filtertext='';
          for (var key in alldata.f_vfields){
            if (alldata.f_vfields[key]) filtertext+=alldata.f_vfields[key]+'/';
          }
          
          if (filtertext) {
            filtertext=$.i18n._('filtered : %s',[filtertext]) ; 
            t_nav += ' <div class="text-nav">('+filtertext+')</div>';
          }
      }


      // --- End of BREADCRUMB build 
    
    
      //---- Start of NBR of items and NAVigation  buttons 
      if ((!isInfiniteNav) || (whattodisp!="ad")){
        // --> standard case
        if (pagetostart != pagetoend){ 
          // when more that 1 page to display 
          t_nav += ' <ul id="navpage" class="">';
          t_nav += '<li id="navtxt"> '+$.i18n._('<b>%s</b>-<b>%s</b> of <b>%s</b>',[articlestart,articleend,totaladnbr]) +'</li>';
          if (paged > 1)  
            t_nav += ' <li class="text"> <a nottip="yes" name="filter_list" class="dm_button2 list-nav-prev" title="'+$.i18n._('help prev')+'" href="#action=list&page='+prevpage+'"><i class="icon-fa-chevron-left"></i></a></li>';           
          if ((nextpage <= maxpages) )  
            t_nav += '   <li class="text"> <a nottip="yes" name="filter_list"  title="'+$.i18n._('help next')+'" class="dm_button2 list-nav-next" href="#action=list&page='+nextpage+'"><i class="icon-fa-chevron-right"></i></a></li>';
          t_nav += ' </ul>';
        } else {
          // case of 1 page only
         t_nav += ' <ul id="navpage" class="">';
         t_nav += '<li id="navtxt"> '+$.i18n._('<b>%s</b>-<b>%s</b>',[articlestart,articleend]) +'</li>';
         t_nav += ' </ul>';
        }
      } else {
        // --> case of infinite scroll 
        if ((nextpage <= maxpages)) { 
          tmpstr_nav_infinite = '<div id="listing-nav-infinite" class="infinite_'+infinite_iterationnb+'" style="display:none;">';
          tmpstr_nav_infinite += ' <a nottip="yes" name="filter_list" title="'+$.i18n._('help next')+'" href="#action=list&page='+nextpage+'" class="button_more_2" id="loadmore" href="#"  rel="nofollow" >'+$.i18n._('Load more')+' </a>';
          tmpstr_nav_infinite += ' <div id="inf_loading" class="loading" style="display:none;"></div>'; 
          tmpstr_nav_infinite += '</div>';
        }
        else tmpstr_nav_infinite="";
      }
      
      
      // --- end of the Bread+navigation section 
      t_nav += ' <div class="clearer">&nbsp;</div>'; 
      t_nav += '</div>  '; 
    
      // really display the nbr of ads + breadcrumb
      if (infinite_iterationnb==1)
       $('#adlist').append(t_nav);
      
     // set the actions handlers for breadcrumb
     $('#adlist #breadcrumbsul a[name=list_ads]').click (function(e) {
        e.preventDefault();
        window.location.hash = "";  
        ahref = $(this).attr('href'); 
         var tmpx = ahref.split("#");
         ahref2 = tmpx[tmpx.length-1]; // get just the final elements after latest # to correcr IE bug.
         anchor1=[]; 
         eval_href ( ahref, "anchor1");

         if (anchor1.action=="list") {
            // call ajax to refresh the list
            var filterparams = grab_all_filters('adlist'); 
            //cur_nav_ajax = ahref2; 
            //ajax_action (cur_nav_ajax);
            ajax_action (ahref2+filterparams);
            addToNavigatorHistoryAndCurrent(ahref2+filterparams);

            // refresh the top gallerie on change of categorie
            // if (enable_topgallery_mod ) {
            //   p =cur_nav_ajax+"&priority=topgallery&nav=topbanner&modid=topgallery";
            //   ajax_action(p);
            // } 
            update_widgets(cur_nav_ajax); 
         }
          else if (anchor1.action=="display"){
           if (what=="user") {
            ajax_action(ahref2);
            tr='user-';
            hashx=tr+anchor1.id;
            addToNavigatorHistory(hashx,'local');
            }
         } 

         else if (anchor1.what=="dashboard"){
           display_DASHBOARD();
         } 
         else if (anchor1.what=="mydashboard"){
           display_DASHBOARD('my');
         } 
         else if (anchor1.what=="myservices") {
          display_add_service();
        }
         else if (anchor1.what=="myinvoices") {
          ajax_action (ahref2); 
        }
         else if (anchor1.action=="back"){
           $('#home a').click();
         } else 
          displayMessage("Action not yet available", true, "info");

         return true; 
     });


      // Z6.1.5 ---------   display MAIN  filters & selection 
      // Z6.5.2 modifications
      if (this_is_a_zetevu && zetevu_as_video) {
        cur_view_class= "thumb-view";  
        view="thumb"; 
      } else {
        rep = build_VIEW_MODE_FILTERS(whattodisp, view);
        t+=rep['html']; 
        cur_view_class=rep['cur_view_class'];
        view =  rep['view'];
      }
      cur_list_view =view; 
      // end Z6.1.5 
      

      
      // add button "add a catagory"
      if( isAdmin && ((whattodisp=="cat") || (whattodisp=="user")))  {
        t += ' <ul class="button-options">';
        t += '<a name="add_manage_'+whattodisp+'s" id="add_item_admin" what="'+whattodisp+'"  href="" rel="" class="dm_button2">';
        t += '<i class="icon-fa-plus mr6"></i>'+$.i18n._("add a "+whattodisp);
        t += '</a>';
        t += ' </ul>'; 
      } 
      
      // SORT  options
      if (type!="zetvu"){
        t += ' <ul class="sort-options">';
        t +=  '<select name="filter_list" id="filter_select" >';
        t += build_DOM_SELECT_options(sortoptions_obj, sort,whattodisp); 
        t +=  '</select>';

        // zads4.6 add the around me option 
        //Z6.5.3 updated for on/off of this feature
        if (
              (whattodisp=="ad" && !locale_settings.dis_ad_loc) 
          ||  (whattodisp=="user" && !locale_settings.dis_user_loc) 
          )
        {

          t += '<div class="sort-option-inline icon-menu">'; 
          if ((whattodisp=="ad") && (nav!="admin")) {
              var r= [];
              r= detect_location(); 
              if (r) {
                  t2 = '<span >'; 
                  //t2 += ' <span class="icon icon-locdist"></span>';
                  t2 += ' <i class="icon-fa-compass mr6"></i>';
                  t2 += '<span id="mylocation">'+r["locshort"]+'</span>';
                  t2 += ' <a id="mylocation_check" name="loc-check" href="#"  rel="nofollow" cur_loc="'+r['loclong']+'"  >'+$.i18n._("(change)")+'</a>';
                  t2 += '</span>';
                  xtraattrinput=''; 
              } 
              else {
                  t2 = '<span >'; 
                  // t2 += ' <span class="icon icon-loc"></span>';
                  t2 += ' <i class="icon-fa-compass mr6"></i>';
                  t2 += '<span id="mylocation" >'+$.i18n._(":unknown")+'</span>';
                  t2 += ' <a id="mylocation_check" name="loc-check" href="#" rel="nofollow" cur_loc="">'+$.i18n._("(locate me)")+'</a>';
                  t2 += '</span>';
                  xtraattrinput=' DISABLED'; 
              }

              // add the checkbox
              xtraattrinput += (!sortdist) ? " " : " CHECKED";
                 
              t += '<input id="sort_by_dist" type="checkbox" value="yes" name="sort_dist" '+xtraattrinput+'/>';
              t += '<span >'+$.i18n._("around me :")+'</span>';
              t += t2;
              t += '</div> '; 
          }

        }

        t += ' </ul>';
        t2=''; // reset dit
      }

      // SELECT per STATUS  if admin or my admin 
      if ( (type!="zetvu") 
          && ((whattodisp=="ad") || (whattodisp=="user"))
          && ((nav=="admin") || (nav=="manage_ads") || (nav=="myads_all")) 
          && ((status=="all") ||(status=="admin_all")) 
         ) 
        {
        xstatus= status.split("_")
        if (xstatus[0]=="admin") xstatus = xstatus[1]; else xstatus = xstatus;
        
        t += ' <ul class="filter-status-options">';
        t +='<li class="label">'+$.i18n._("status")+': </li>';
        t +=  '<select name="filter_list" id="status_select" what="'+whattodisp+'" >';
        
        // default option
        if ((!status) || (status=="all") || (status=="admin_all"))
          t +=  '<option  value="all" id="" class="selected" selected="selected"  >'+$.i18n._('all status')+'</option>';
        
        // loop through each counters elements
        if (whattodisp=="ad") var thevar =  cur_user_ads; 
        if (whattodisp=="user") var thevar =  cur_user_relusers; 

        $.each(thevar, function(i,elem){ 
          xname= elem.name.split("_")
          if (xname[0]=="admin") xelemname = xname[1]; else xelemname = xname;
          if ((userid && xname[0]!="admin") || (!userid && (xname[0]=="admin"))) {
            elemnametext = ad_status_name[xelemname]; 
            if  (elemnametext) elemnametext = elemnametext.toLowerCase(); 
            
            if ((elemnametext==xstatus)  || ((elemnametext=="under review") && (xstatus=="pending")))   {elemclass +=' selected';  elemchecked='selected="selected"'; xdisp="";  tmpid="";}
            else { elemclass = "";  elemchecked = ""; xdisp="";  tmpid="";}
            t +=  '<option '+xdisp+' value="'+elemnametext+'" id="'+tmpid+'" class="'+elemclass+'" '+elemchecked+'  >'+$.i18n._(ad_status_name[xelemname])+' ('+elem.val+')</option>';
          }
        });
        t +=  '</select>';
        t += ' </ul>';
        
      }
      // --- end SELECT STATUS filter  

      // // -- CATEGORY TYPE filter 
      // if ( (whattodisp=="cat") ) {
      //   t += ' <ul class="filter-type-options">';
      //   t +=''+$.i18n._("cat type")+': ';
      //   t +=  '<select name="filter-type-options" id="cattype_select" >';
      //   t += build_DOM_SELECT_options(cattype_a, type , whattodisp); 
      //   t +=  '</select>';
      //   t += ' <ul >';
      // } // ----  end Category type 
      
      
      // -- tag for end of section 
      t += '</div>  ';                  
      t += ' <div class="clearer">&nbsp;</div>';

      // construct the second filter line (tsf = TmpHTML Second Filer)
      //Z6.1.5 
      //Z6.5.0
      if (f_locfield || cur_list_view=="videogallery" || cur_list_view=="audiogallery"){
        var tsf ='', tsloc='', tswarning=''; 

        
        // for LOCATION filter 
        if (f_locfield) {
          tsloc += '  <ul class="filter-loc list-second-filter-line" z-params="locfield='+f_locfield+'&locval='+f_locval+'">';
          tsloc += '    <li class="icon-menu"><i class="icon-fa-map-marker fs12 mr6"></i><span class="locfield">'+$.i18n._(f_locfield)+ '</span> : <span class="locval">' + $.i18n._(f_locval)+'</span>';
          tsloc += '    <span class="icon icon-remove"></span>';
          tsloc += '    </li>';
          tsloc += '  </ul>'; 
        }

        // for warning message
        //Z6.5.0
        if (cur_list_view=="videogallery" || cur_list_view=="audiogallery" ){ 
          tswarning += '  <ul class="filter-warning list-second-filter-line" >';
          tswarning += '    <li class=""><span class=""><i class="icon-fa-info-circle fs12 mr6"></i>'+$.i18n._("list filter on "+cur_list_view+" is ON")+ '</span></li>';
          tswarning += '  </ul>'; 
        }

        // final build
        if (tsloc || tswarning ){
          tsf += '<div class="clear" id="listings-header-filters">';
          tsf += tsloc + tswarning ; 
          tsf += '</div>  ';                  
          tsf += ' <div class="clearer">&nbsp;</div>';

          $('#adlist').append(tsf); 

          // ----  even handle when removing the search 
          $('#adlist ul.filter-loc span.icon-remove').click(function(e){
            // remove the filter 
            $(this).parent().remove();
            // patch and reload datas
            // var ajaxparams = cur_nav_ajax.split("&locfield=")[0]; 
            var ajaxparamsJson = serialstring_2_json(cur_nav_ajax) ; 
            ajaxparamsJson = remove_keys_from_json(ajaxparamsJson,['locfield', 'locval', 'flocfield', 'flocregion', 'flocdept', 'f_flocdept', 'f_flocregion', 'f_floccity', 'f_floczipcode']);
            ajaxparams = json_2_str(ajaxparamsJson); 

            // reste the location selections in search bar
            reset_autoLocation(); 
            $('#flocregion, #flocept').val(''); // reste to default value


            ajax_action (ajaxparams);
            addToNavigatorHistoryAndCurrent(ajaxparams); 
          });
        }
      }
      // end Z6.1.5 

      // --> standard case  : apply the standard navigation bar
      if (!isInfiniteNav || infinite_iterationnb==1){
        // display   
        $('#adlist').append(t); 
        page_scroll_top('#adlist');
      }

      // --> infinite nav : add the page indicator 
      if (isInfiniteNav && (whattodisp=="ad")){
        tmpstr_infinite_nav += '<li id="navtxt"> '+$.i18n._('<b>%s</b>-<b>%s</b> of <b>%s</b>',[articlestart,articleend,totaladnbr]) +'</li>';
        $('#adlist').append(tmpstr_infinite_nav);
      }

      // Z7.0.4 -- all / pro / par tabs
      if (display_settings.list_nav_pro_par && (whattodisp=="ad" || whattodisp=="user")){
        var t_tabs=''; 
        t_tabs+='<nav class="listing-tabs clearfix">'; 
        $.each(['all','par','pro'], function (i,e) {
          var xcl= (alldata.ftype==e || alldata.utype==e || (alldata.ftype=='' && e=='all')) ? "active" : ""; 
          var countnb =  alldata.totnb_xt['tot'+e]; 
          var count= format("# ##0.", countnb);
          var ajaxparams='action=list&what='+whattodisp;
          if (e !='all') if (whattodisp=="ad")  ajaxparams += '&ftype='+e; else ajaxparams += '&utype='+e;
          if (countnb>0){ 
            var xprotype=(e!="all") ? e : ''; 
            t_tabs+='<a href="#'+ajaxparams+'" class="listing-tab '+xcl+'" z-protype="'+xprotype+'"   z-href="'+ajaxparams+'">'+$.i18n._(whattodisp+'_tab_'+e)+'<span class="tab-counter">'+count+'</span></a>';
          } else {
            t_tabs+='<span href="#'+ajaxparams+'" class="listing-tab '+xcl+'" z-href="'+ajaxparams+'">'+$.i18n._(whattodisp+'_tab_'+e)+'<span class="tab-counter">'+count+'</span></span>';
          }
        });
        t_tabs+='</nav>'; 
        $('#adlist').append(t_tabs); 
      }
      

      // ---------------  start displaying the list of items  ---------------
      
      t2 += '<ul class="post-list '+cur_view_class+' '+whattodisp+'  infinite_'+infinite_iterationnb+' "  id="ulnb_'+infinite_iterationnb+'" style="display:none;">';
       
      $.each(dataobj, function(i,ad)
      {

        // when in Infinite scroll, display only the delta 
        if ((isInfiniteNav) && (infinite_iterationnb>1) && (whattodisp=="ad")){
          idxstart = (parseInt(infinite_iterationnb)-1)*AD_ITEMS_PER_PAGE; 
          idxend = parseInt(infinite_iterationnb)*AD_ITEMS_PER_PAGE; 
          if ((i<idxstart) || (i>=idxend))
            return true; // exit the each and go to next iteration 
        }
      
        // process the ImageURL value to get only the FIRST file name (thumbnail only)
        var ttheimg =  get_img_url(ad, whattodisp,'list'); 
        var nbpics=ttheimg['nbpics']; 
        var imgfullurl =ttheimg['imgfullurl']; 
        var imgname =ttheimg['imgname']; 
        
        // procedd and display price
        pricevaluetodisplay = build_PRICE_value(ad, cur_currency, whattodisp,'img_overlay');
        //pricevaluetodisplay = price_2_string(ad.price, cur_currency); 

        xtracl=""; 
        // extra class if paid option is set 
        if (has_option_in_param(ad.paidoptions,'specialcolor')) {
          if (has_option_in_param(ad.paidoptions,'specialcoloronceaweek')){
            if (are_dates_samedayoftheweek(ad.firstpublisheddatestamp)) xtracl=" paidhighlight "; 
          } else 
          xtracl=" paidhighlight "; 
        }
        else xtracl=""; 


         // 7.5.5 banners - add it if exists 
        if (!isPageAdmin && i==Math.floor(AD_ITEMS_PER_PAGE/2)){
          if ($('#banner_pos_ad_list_inner_static').length>0){
            t2 += '<li class="'+ad.type+' '+xtracl+'   hidden-xs" >';
            t2 += '<div class="post banner">'; 
            t2 += $('#banner_pos_ad_list_inner_static').html(); 
            t2 += '</div>';
            t2 += '</li>';// do not exit, contunue the display
          } 

          // on mobile 
          if ($('#banner_pos_mob_ad_list_inner_static').length>0){
            t2 += '<li class="'+ad.type+' '+xtracl+'   visible-xs" >';
            t2 += '<div class="post banner">'; 
            t2 += $('#banner_pos_mob_ad_list_inner_static').html(); 
            t2 += '</div>';
            t2 += '</li>';// do not exit, contunue the display
          } 
        }


        // ---- display the content
        //z6.1.2 -- extra size for videos 
        //Z6.1.5 
        xtracl+= ((this_is_a_zetevu && zetevu_as_video) || view=="videogallery")  ? " video_thumbs " : ""; 
        t2 += '<li class="'+ad.type+' '+xtracl+'" id="'+ad.id+'" localid="'+i+'">';
        t2 += '<div class="post" itemscope itemtype="http://schema.org/Product">';  

        // Image
        t2 +='    <div class="pcol-a">';   

        // display rhe "LATEST banner" - new ZADS 4.8 
        if ((whattodisp!="cat"))
          if ((dayskeepasnew>0) &&  ((getTimeLocal()-(86400000)*parseInt(dayskeepasnew)) < ad.moddatestamp)){         
            t2 +='   <h5 class="recentProduct" style="display: block; ">Recent</h5>';
          }
     
        // display the "NEW SINCE LAST VISIT banner" if article is new from last visite. 
        if ((cur_user) && (cur_user.lastvisitstamp < ad.moddatestamp) && display_settings.new_sincelastvisit_en)
          t2 +='    <h5 class="recommendedProduct" style="display: block; ">Recommended Product</h5>';

        // display price decrease
        if (whattodisp=="ad" && display_settings.price_field_second){
          if (ad.pricetype=='' && (parseFloat(ad.price) < parseFloat(ad.price2)))
            t2 +='    <h5 class="pricelower" style="display: block; ">Price decreased</h5>';
        }
        

        // display the status on top of image when in MOBILE view 
        if (user_agent=="mobile_iphone"){
          if (cur_user && ((cur_user.usertype==9) ||(cur_user.id==ad.userid))){
              statusname = ad_status_name[""+ad.status+""]; 
              t2 +=' <div id="" class="msgOverlay '+statusname+' ttip" title="'+$.i18n._("help_on_status "+statusname)+'">'+$.i18n._(statusname)+'</div>';
          }
        }
        
      
        // display the Image thumbnail
        var ttitle =  (whattodisp=="user") ? ad.procpny : ad.title; 
        if (ad.type=="zetvu")  var tsu = build_URL("zetevu", ad.id, ttitle); 
        else  var tsu = build_URL(whattodisp, ad.id, ttitle); 
        tsu = "#!"+tsu;  

        // if a VIDEO ZETEVU and no defautl image , display the video 
        //z6.1.2
        if (this_is_a_zetevu && zetevu_as_video){
          t2 +='      <a class="imgWrapper"  name="show_ad" lid="'+i+'" what="'+whattodisp+'" id="'+ad.id+' "href="'+tsu+'" z-href="#action=show&what='+whattodisp+'&adid='+ad.id+'">';        
          if (!ad.imgurl) // display video if no image 
            t2 +='      <div class="video_thumbnail">'+ad.videoembed+'</div>';
          else { // display image full size 
            turl = (bigimgfullurl) ? bigimgfullurl : imgfullurl ; 
            t2 +='      <img itemprop="image" src="'+turl+'" alt="" class=" '+whattodisp+'" />';
          }
        } else {
          //Z6.1.5 
          if ( view=="videogallery"){
            t2 +='      <a class="imgWrapper"  name="show_ad" lid="'+i+'" what="'+whattodisp+'" id="'+ad.id+' "href="'+tsu+'" z-href="#action=show&what='+whattodisp+'&adid='+ad.id+'">';        
            t2 +='      <div class="video_thumbnail">'+ad.videoembed+'</div>';
          } else {
            t2 +='      <a class="imgWrapper"  name="show_ad" lid="'+i+'" what="'+whattodisp+'" id="'+ad.id+' "href="'+tsu+'" z-href="#action=show&what='+whattodisp+'&adid='+ad.id+'">';        
            t2 +='      <img itemprop="image" src="'+imgfullurl+'" alt="" class=" '+whattodisp+'" />';
          }
        }


          // display price in overlay to IMG   
          if ((whattodisp=="ad") && (ad.type!="zetvu")){
            overlaytxt = pricevaluetodisplay;
            if (overlaytxt) t2 +='      <div class="priceOverlay" >'+overlaytxt+'</div>';
          
            // // display the number of photos 
            // if (nbpics){
            //   overlaytxt = nbpics;
            //   t2 +='     <div class="picsCounterOverlay" >'+overlaytxt+'</div>';
            // }

            //Z6.5.0 - new info banner indicating if video/ pictures / audio  
            if (nbpics || ad.audiourl || ad.videoembed || ad.video2){
              var mediasdetails=''; 
              if (nbpics) mediasdetails+= '<span><i class="icon-fa-camera "></i>'+nbpics+'</span>' ;
              if(ad.audiourl)  mediasdetails+='<span><i class="icon-fa-volume-off "></i>'+ad.audiourl.split(';').length+'</span>' ;
              if(ad.videoembed ||  ad.video2)  {
                var nbvideos =  (ad.videoembed)  ?  1 : 0 ;
                nbvideos=  (ad.video2)  ?  nbvideos++ : nbvideos ;
                mediasdetails+='<span><i class="icon-fa-video-camera "></i>'+nbvideos+'</span>' ;
              }
              if(ad.docurl)  mediasdetails+='<span><i class="icon-fa-file "></i>'+ad.docurl.split(';').length+'</span>' ;
              t2 +='     <div class="medias-info-banner" >'+mediasdetails+'</div>';
            }


          }
          
          // display ribbon for special status of items 
          t2+=build_ribbon(ad);

          // display ribbon for badwords
          if (ad.badwords_res.success){
            t2 +='<div class="icon_overlay badwords" >';
            t2 +='<i class="icon-fa-shield"></i>';
            t2 +='</div>';
          }

        t2 +='      </a>'; // close the image link
        t2 +='    </div>'; // close the panel 


        t2 +='    <div class="pcol-b-c-d-wrap ">';
        
        // =============  title and exercpt P-COLD B ! 
        t2 +='   <div class="pcol-b">';
        var xdesc2='';
        //  --- USER ----------------------------
        if (whattodisp=="user") {

          // chose Name of company name or fisrt name / last name
          todisplay = (ad.protype=="pro")? highlight_txt(ad.procpny,search) : highlight_txt(ad.firstname,search)+' '+highlight_txt(ad.lastname,search);
          xtitle = todisplay ; 

          // add the PRO logo if exist       
          todisplayafter=''; 
          if ((ad.protype=="pro" && has_multiple_protype) || (cur_user && ((cur_user.usertype==9) ||(cur_user.id==ad.userid)))){
            statusname = 'protype_'+ad.protype; 
            todisplayafter = '<span id="" class="adlist_protype '+statusname+' ttip" title="'+$.i18n._("help_on_status "+statusname)+'">'+$.i18n._(statusname)+'</span>';
          }
   
          var tsu = build_URL(whattodisp, ad.id, ad.procpny); tsu = "#!"+tsu;  
          t2 +='      <h3><a name="show_ad" what="'+whattodisp+'" lid="'+i+'" id="'+ad.id+'"  href="'+tsu+'" z-href="#action=show&what='+whattodisp+'&adid='+ad.id+'">'+todisplay+'</a>'+todisplayafter+'</h3>';
          // skills
          t2 += '<div id="skills">'+build_RATING(ad.skills, 5, true ,catid)+'</div>';
          t2 += '<div class="clear"></div>'; 
          // bio 
          if (ad.bio!="") {
              xdesc = my_trim_excerpt(ad.bio, 16, search);
              xdesc2 = ad.bio;
              t2 +='      <p>'+xdesc+'</p>  ';
          }
          t2 +='  </p>  ';
        }
        else {
          //  --- ZETEVU ----------------------------
          if (ad.type=="zetvu"){

             // z6.1.2
            if (zetevu_as_news || zetevu_as_video){
              // display it as a regular news  : 
              var tsu = build_URL("zetvu", ad.id, ad.title); tsu = ESCAPECHAR+tsu;  
              txttodisp = ad.title;xtitle=  txttodisp;
              t2 +='     <h3><a itemprop="name" name="show_ad" what="'+whattodisp+'" lid="'+i+'" id="'+ad.id+'" href="'+tsu+'" z-href="#action=show&what='+whattodisp+'&adid='+ad.id+'">'+txttodisp+'</a></h3>';
              
              // --- date --- 
              // z6.1.2
              xdate =   convert_delta_date_2_String(ad.moddatestamp,true);
              t2 +='     <div id="post-date" class="post-date">'+xdate+'</div>';

              xdesc = my_trim_excerpt(ad.desc, 16, search);
              xdesc2 = ad.desc;
              t2 +='     <p itemprop="description">'+xdesc+'</p> ';
            } 
            else {
              t2 +='      <h3 class="hideit" ><span class="zetvu-title">'+ ad.title+'</span>'+my_trim_excerpt(ad.desc, 10, search)+'</h3> ';
              // z6.1.2
              xdate =   convert_delta_date_2_String(ad.moddatestamp,true);
              t2 +='     <div id="post-date" class="post-date">'+xdate+'</div>';

              t2 +='      <p><span class="zetvu-title">'+ ad.title+'</span>'+my_trim_excerpt(ad.desc, 32, search)+'</p> ';
              xtitle = ad.title;
            }
          }
          else { 
            //  --- AD REGULAR ----------------------------
            // display title 
            if (isSearch) txttodisp = highlight_txt(ad.title, search); 
            else txttodisp = ad.title;
            xtitle=  txttodisp;

          
            // -- title 
            var tsu = build_URL(whattodisp, ad.id, ad.title); tsu = ESCAPECHAR+tsu;  
            t2 +='      <h3><a itemprop="name" name="show_ad" what="'+whattodisp+'" lid="'+i+'" id="'+ad.id+'" href="'+tsu+'" z-href="#action=show&what='+whattodisp+'&adid='+ad.id+'">'+txttodisp+'</a></h3>';
            
            // display statc special fields (CUSTOM and function must be modified in CUSTOM.JS)
            if (display_settings.adlist_custom_fields_col_d) {
              t2+= build_CUSTOM_PCOL_B_CONTENT(ad,whattodisp,dataobj);
            }

            // display the CATEGORY  link on top of the image
            // if ((whattodisp=="ad")) {
            //   cattxt = JSON_find_elem_byValue(cat_options,ad.catid).name; 
            //   var tssu='';
            //   if (cattxt){
            //     cattxt= get_translated('cat', cur_lang, cattxt); 
            //     tssu = build_URL('cat', ad.catid, cattxt); tsu = "#!"+tssu;  
            //   }

            //   t2 +='     <div class="category-title" id="'+ad.catid+'">';
            //   t2 +='<a name="manage_ad" title="'+cattxt+'" z-surl="'+tssu+'" href="'+tsu+'" z-href="#action=list&what=ad&catid='+ad.catid+'">'+cattxt+'</a></div>';
            // }


            // -- DESCRIPTION 
            //Z6.5.1 - special display for audio gallery
            if (view=="audiogallery"){
              has_media_displayed=true; 
              t2+=build_AUDIO_PLAYER(whattodisp, ad, true);  
            } else { 
              xdesc = my_trim_excerpt(ad.desc, 16, search);
              xdesc2 = ad.desc;
              // t2 +='      <p class="list_description" itemprop="description">'+xdesc+'</p>  ';
            }


            // -- Z6.0 PAY MOW  ! Button 
              if (ad.status=="15"){
                t2 +='<div id=""><a name="show_ad" class="dm_button2" what="'+whattodisp+'" lid="'+i+'" id="'+ad.id+'"  href="'+tsu+'" z-href="#action=show&what='+whattodisp+'&adid='+ad.id+'"><i class="icon-fa-shopping-cart mr6"></i>'+$.i18n._("Pay now")+'</a></div>';
            }

          }
        }
        t2 +='    </div>';
        
        // t2 +='    <div class="pcol-c-d-wrap">';
        // t2 +='    <div class="inner">'; // inner area


        // ===========   additionnal public informations
        t2 +='   <div class="pcol-c">';
        //  --- USER ----------------------------
        if (whattodisp=="user") {
          // last modification date 
          xdate = convert_delta_date_2_String(ad.moddatestamp, true);
          t2 +='     <div id="post-datelastvisit" class="post-date">'+xdate+'</div>';
          
          // web site
          if (ad.prowebsite)  {
            linktodisplay =  url_normalize( ad.prowebsite);  
            linklabel = $.i18n._("link to website");
            t2 +='     <div id="post-prowebsite" class="post-prowebsite"><a name=""  href="'+linktodisplay+'" target="_blank" ><span class="icon"></span> '+linklabel+'</a></div>';

          }
          
          // display location 
          t2+= build_elem_location(whattodisp, ad, i  ); 
          


        } else {
          //  --- AD / ZETEVU ----------------------------
          // --- price ---  

          if (vtags_settings.vtag1_boolean && whattodisp=="ad"){
              if (ad.vtag1) vcl="true"; else vcl="false"; 
              t2+='<div><Span class="vtag_badge vtag1_'+vcl+'">'+$.i18n._('desc_vtag1_'+vcl)+'</span></div>';
            }

          if (whattodisp=="ad"){
            pricevaL2 = build_PRICE_value(ad, cur_currency, whattodisp,'inline_list');
            t2 +='     <div itemprop="price" class="post-price">'+pricevaL2+'</div>';
          }

          // --- urgent flag  ---  
          if ( ad.urgent)
            t2 +='      <div class="urgent"><i class="icon-fa-exclamation mr6"></i><span>'+$.i18n._('urgent')+'</span></div>';  
          else {
            // display adummy blank element 
            t2 +='      <div class="urgent_space only_gallery">&nbsp;</div>';  
          }

          // --- date --- 
          xdate =   convert_delta_date_2_String(ad.moddatestamp,true);
          t2 +='     <div id="post-date" class="post-date">'+xdate+'</div>';
                   
          // display number of adds in case of CAT
          if (whattodisp=="cat"){
            if (ad.totnbads > 0) {
            thehref= "#action=list&what=ad&status=all&catid="+ad.id; 
            t2 +='  <div id="post-nbads" class="post-nbad"><span class="icon"></span><a name="manage_ad" href="'+thehref+'">'+$.i18n._n("%s ad","%s ads", ad.totnbads, [ad.totnbads])+'</a></div>';
            }

            // type of category 
            statusname = "cattype_"+ad.type;
            t2 +='     <div id="" class="adlist_status '+statusname+' ttip" title="'+$.i18n._("help_on_cattype "+statusname)+'">'+$.i18n._(statusname)+'</div>';
      
          }

          //Z7.4.1
          var tfag=''; 
          if (locale_settings.locale_disp_mode=="flag"){
            if (ad.loccountrycode) tfag +='  <div class="adlist-flag"><span class="flags '+ad.loccountrycode.toLowerCase()+'"></span></div>';
          }

          // location 
          t2+='<div class="flag-plus-location clearfix ">'+tfag+build_elem_location(whattodisp, ad, i  )+'</div>'; 

            // @zads4.6 display distance
            if ($('.sort-options #sort_by_dist').attr('checked')){  
              if ((ad.locdist && (ad.locdist>=0) && ad.locdist<1000)){
                t2 +='    <div id="post-locdist" class="post-locdist"><i class="icon-fa-compass mr6"></i> '+ad.locdist+' ('+locale_default_unit+'s)</div>';
              }  
            }

            // add the PRO logo if exist
            // Z6.5.3 -> filter protype when only 1 type !
            if (whattodisp=="ad"){
              if (ad.protype && has_multiple_protype){
                statusname = 'protype_'+ad.protype; 
                t2 += ' <div><span id="" class="adlist_protype '+statusname+' ttip" title="'+$.i18n._("help_on_status "+statusname)+'">'+$.i18n._(statusname)+'</span></div>';
              }
            } 
          
          }
 
        t2 +='   </div>';
        
        // --- ACTIONS 
        // - public : save as favorite. 
        // - admin or owner :  modify - delete - approve --> edit.
        //---------------------------------------------
         
        t2 +='   <div class="pcol-d">';
        t2 += '  <div class="panel-inner2">';
        
        if (cur_user && (cur_user.usertype==9 || cur_user.id==ad.userid ) ){
          // status of publication
          statusname = ad_status_name[""+ad.status+""];
          if ((ad.logs) && (ad.status=='45')) { // if a data is indicated into the log section, this means WILLEXPIRE or WILL EXPIRE
              nextstamp = toTimestamp(ad.logs)+days_notif*24*60*60*1000;  
              nextstamp = convert_delta_date_2_String(nextstamp,true);
          } else { 
            if (ad.status=='80') {
                  nextstamp = toTimestamp(ad.moddate)+days_archive*24*60*60*1000;
                  nextstamp = convert_delta_date_2_String(nextstamp,true);
            }
            else nextstamp=''; 
          }
          t2 +='      <div id="" class="adlist_status '+statusname+' ttip" title="'+$.i18n._("help_on_status "+statusname)+' '+nextstamp+'">'+$.i18n._(statusname)+'</div>';


          // add the PRINCING PLAN if exist
          //Z6.5.3     
          if (ad.plan){
            var plo = JSON_find_elem_byValue(pricing_plan_options, ad.plan); 
            plansname = plo.sname; 
            planlname = plo.name;
            t2 += '<div id="" class="adlist_plan '+ad.plan+' ttip" title="'+$.i18n._(planlname)+'">'+$.i18n._(plansname)+'</div>';
          }


          // modify / edit button
          var xwhat = (whattodisp=="ad" && ad.type=="zetvu" ) ? "zetvu" : whattodisp ; 
          t2 += '<div><a class=" dm_button3 " name="manage_ad" id="0" title="" lid="'+i+'" what="'+xwhat+'" href="#action=edit&what='+xwhat+'&adid='+ad.id+'&lid='+i+'"><i class="icon-fa-edit mr6"></i>'+$.i18n._(whattodisp+' edit')+'</a></div>';

        }


        // edit de

       // hits 
        if ((whattodisp=="ad" && ad.type!="zetvu") || (whattodisp=="user")) {
            if (ad.hits>0 && ((display_settings.en_ad_hits && whattodisp=="ad") || display_settings.en_user_hits && whattodisp=="user")) {
             ltext = (display_settings.main_content_width_short_en) ? "%s": "hits : %s times";
             t2 +='     <div id="item-hits " class="level1 floatmr6"><i class="icon-fa-eye mr6"></i> '+$.i18n._(ltext ,[ad.hits])+' </div>';
            }

            //Z6.5.6
            if ((( whattodisp=="ad" && display_settings.en_ad_likes ) || (whattodisp=="user" && display_settings.en_user_likes) ))  {
             t2+=build_LIKES(ad, whattodisp); 
            }

            //Z6.8  add vcounters results is presents
            if (ad.vcounters){
              var vcounters= $.parseJSON(ad.vcounters); // php retuns a valid JSON document
              $.each(vcounters, function(k,v){
                // console.log("vcounter ket/value=", k, v);
                var ltext ="post_vcounters_"+k; var licon = (k=="email") ? "envelope" : "phone"; 
                t2 +='     <div id="item-vcounters" class="level1 floatmr6"><i class="icon-fa-'+licon+' mr6  ttip" title="'+$.i18n._("help_on_"+ltext)+'"></i> '+$.i18n._("%s "+ltext ,[v])+' </div>';
              }); 
            }
        }

        // nbr of ads in case of user
          if ((whattodisp=="user") && (ad.totnbads > 0)) {
            thehref= "#action=list&what=ad&userid="+ad.id; 
            lttext = (display_settings.main_content_width_short_en) ? $.i18n._n("%s An.","%s An", ad.totnbads, [ad.totnbads]) : $.i18n._n("%s ad","%s ads", ad.totnbads, [ad.totnbads]);

            t2 +=' <div id="post-nbads" class="post-nbad"><i class="icon-fa-tags mr6"></i><a name="manage_ad" href="'+thehref+'">'+lttext+'</a></div>';
            //t2 +=' <div id="post-nbads" class="post-nbad"><i class="icon-fa-tags icon-b-13em"></i><a name="manage_ad" href="'+thehref+'">'+$.i18n._n("%s ad","%s ads", ad.totnbads, [ad.totnbads])+'</a></div>';
          }

          // --- link to the user if it's an AD and not in "short display mode"
          if (whattodisp=="ad" && !display_settings.main_content_width_short_en)
            t2 += build_user_LINK(ad, whattodisp, "list");

          // always display this direct for Zetvu  items 
          if ((ad.type==="zetvu")){
              linktodisplay = "#action=emailhim&adid="+ad.id; 
              t2 +='      <div id="item-email" class="level1"><a name="manage_ad" lid="'+i+'" what="'+whattodisp+'" href="'+linktodisplay+'"><i class="icon-fa-envelope mr6"></i>'+$.i18n._("contact him")+' </a></div>';
          }


        
        
        //all other actions , add a nav bar if not in (short display mode)
        if (!display_settings.main_content_width_short_en)
         t2 += build_DROP_MENU(dataobj, i,ad.id, whattodisp, ad.type, ad.userid, ad.status);

        // display statc special fields (CUSTOM and function must be modified in CUSTOM.JS)
        if (display_settings.adlist_custom_fields_col_d) {
          t2+= build_CUSTOM_PCOL_D_CONTENT(ad,whattodisp,dataobj);
        }

  
        t2 += '  </div>'; // end pannel-inner 
        t2 +='   </div>';// end pcol-d
        
        // t2 +='    </div>'; // end pcol-c and D  INNER
        
        // // add the menu "under"
        // t2 +='<div class="postunder">';
        // t2 += '  <a name="swiperight" adid="'+ad.id+'" id="add_cat" what=""  href="" rel="" class="dm_button_nopad left">';
        // t2 += '  <span class="next"></span>';
        // t2 += '  </a>';
        // t2 += build_DROP_MENU(dataobj, i,ad.id, whattodisp, ad.type, ad.userid, ad.status, 'dummy');
        // t2 +='   <div class="clearer">&nbsp;</div>';
        // t2 +='</div>';
        
        // t2 +='    </div>'; // end pcol-c and D WRAPPER 


        t2 +='    </div>'; // end pcol-b-c-d wrapper
  
        // as thumb view, add the howver  element  
        //if (cur_view_class=="thumb-view"){
        // z6.1.2 - overlay only if not a video 
        if (!(this_is_a_zetevu && zetevu_as_video && ad.imgurl=="")){  
          t2 += '<div class="hd">';
          t2 += '      <a name="show_ad" what="'+whattodisp+'" lid="'+i+'" id="'+ad.id+'" href="#action=show&what='+whattodisp+'&adid='+ad.id+'" >';
          t2 += '  <div class="rebloger">';
          t2 += '    <span class="title">'+xtitle+'</span>';
          t2 += '   <div class="noteee">';
          t2 += '     <span>'+xdate+'</span>';
          t2 += '    </div>';
          t2 += '    <p>'+xdesc2+'</p>';
          t2 += '  </div>';
          t2 += ' </a>';
          t2 += '</div>';
        }

        //}
        t2 +='  <div class="clearer">&nbsp;</div>';

        t2 +='</div>';
        
        t2 +='</li>';
      });
      t2 += '</ul>';
      
      //remove all existing  zoom containers
      $('.zoomContainer').remove(); 

      // --> standard case
      if (!isInfiniteNav) {
        $('#adlist').hide().append(t2); 

        // bottom nav - display and patch the fisrt nav
        $('#adlist').append(t_nav); 
        $('#adlist #listings-nav').first().addClass('listings-nav-top'); 

        $('#adlist .infinite_'+infinite_iterationnb).show(); 
        $('#adlist').fadeIn();

        page_scroll_top('#adlist'); 

        // -- activate arrow (KEYBOARD) navigation 
        activate_keyboard_nav("list_elems"); 
      }
      else {
      // --> infinite scroll case 
        $('#adlist').show(); // show in case of not already displayed 
        $('#adlist').append(t2); // add the new content (should be display:none)
        $('#adlist').append(tmpstr_nav_infinite); // add the bottom navigation 
        $('#adlist .infinite_'+infinite_iterationnb).fadeIn(); 
        // bind windows scroll listener only if a MORE BUTTON is present
        if (tmpstr_nav_infinite!="") 
          if (enable_infinite_scroll) bind_win_SCROLL();
          
        if ((view=="maplist") && (infinite_iterationnb>1)){
           // update the new bottom position . this is userd by the stickyfloat plugging
           bottomPos = $('#map_canvas').parent().height() - $('#map_canvas').height(); 
        } 
        
        if (idxstart!=0){ 
          $(window).scrollTop(savedWindowsOffsetTop); // moving to last recorded offset
        }
       }

        // --- ADVERTISING SECTION (only for add and not when administrator and not when isleadflet
        if ((whattodisp=="ad" || whattodisp=="user") && !isleaflet && !isPageAdmin){
             var banobj = $('#banner_pos_'+whattodisp+'_list_center_top'); 
             if (banobj.length > 0) {
                $('#banner_pos_page_center_top .altbanner').html(banobj.html()).show();
                $('#banner_pos_page_center_top .genuinebanner').hide();
            }
             else {
              $('#banner_pos_page_center_top .altbanner').hide();
              $('#banner_pos_page_center_top .genuinebanner').show();
             }
        }
        // activate  CLICK EVENT handler on banners
        init_banners2(); 

       
       // special case of googlemap : force a refresh 
       if (view=="maplist") {
          //insert the area map the first time 
          if (infinite_iterationnb==1) {
            curFirstUL = $("ul.post-list#ulnb_1"); 
            curFirstUL.before('<div id="map_canvas"></div>');
            // call googlemap and apply the stick float effect only if not on smartphone

            gmap_init(); // init the map 
            
            if (Wwindow>480) $('#map_canvas').stickyfloat({duration: 300});
          }
          
          // add markers placeholder to new items
          $('ul.post-list#ulnb_'+infinite_iterationnb+' li div.post').prepend('<div class="map_markers"></div>');
          gmap_drop_markers(dataobj,whattodisp, infinite_iterationnb); // drop the markers when location is indicated
       };
      
        // activate the tooltips on new links
        activate_tooltip('.ttip');

        // activate scroll on mouvemove 

        if (display_settings.activate_text_scroll){
         
          function startScroll(e) 
          { 
             var div = $(this).bind('mousemove',scrollThis); 
             var o = div.offset(); 
             this.tempPosition = { 
                left:o.left, 
                top:o.top, 
                right:o.left+div.width(), 
                bottom:o.top+div.height(), 
                scrollOffsetX:this.scrollWidth-this.clientWidth, 
                scrollOffsetY:this.scrollHeight-this.clientHeight 
             }; 
            
          } 

          function stopScroll(e) { 
             $(this).unbind('mousemove').removeAttr('tempPosition');
            
          } 

          function scrollThis(e) { 
             this.scrollTop = 2*(e.pageY - this.tempPosition.top) ;              
          } 
           $('.hd p').hover(startScroll,stopScroll); 
        }

        //Z6.5.1 - audio contorl on display list
        if ($('#adlist .audio-player').length > 0 ) {
           // activate each player 
          $('#adlist .audio-player').each(function(index, elem) {
              activate_AUDIO_CONTROLS($(this).attr('z-id'));
          }); 
        }


      
        // event handlers for Dropdown links
        $("#adlist .drop-down-container .tw-button").click (function(e) {
            e.preventDefault(); e.stopPropagation();
            adid=$(this).attr('adid');
            swipeLeft_LIPost(adid); 
          });
          
          $("#adlist a[name=swiperight]").click (function(e) {
            e.preventDefault();
            e.stopPropagation();
            adid=$(this).attr('adid');
            swipeRight_LIPost(adid); 
          });
           
        // allocate the event handlers for DISPLAY LAYOUT mode
        if (infinite_iterationnb==1) {
          $('ul.view-options > LI > A').click(function(e) { 
            e.preventDefault();
            myClass = $(this).parent().attr("class");

            curUL = $("ul.post-list"); 
            if (curUL.hasClass(myClass+"-view")) return true; // do nothing
            else {
              // exit option when Gmap is not loaded
              if ((!gmap_script_loaded) && (myClass=="maplist")){
               displayMessage("Error in Google Map loading. Check your internet connection.",false); 
               return false;
               } 
               
              // toggle the class
              $('ul.view-options > li > a').removeClass("selected");
              $(this).addClass("selected");
              
              // engage the transition fom previous to after
              curUL.fadeOut("fast", function() {
                // do it only for the fisrt UL

                if ((myClass=="maplist")){
                  if  ($(this).attr("id")=="ulnb_1"){
                    savedit=0; // reinit the save in case of aleady allocated 
                    // load the map area 
                    //curFirstUL = $("ul.post-list#ulnb_1"); 
                    curFirstUL = $(this); 
                    curFirstUL.before('<div id="map_canvas"></div>');
                    // call googlemap and apply the stick float effect only if not on smartphone

                    gmap_init(); // init the map 
                    
                    if (Wwindow>480) $('#map_canvas').stickyfloat({duration: 400});
                    // add markers placeholder to new items
                    $('ul.post-list li div.post').prepend('<div class="map_markers"></div>');
                    gmap_drop_markers(dataobj,whattodisp, 1); // drop the markers when location is indicated
                  }
                } else
                  $('#map_canvas').stop().animate({'width':'0px'},300,'', function() {
                    $(this).remove();
                    $('ul.post-list li div.post .map_markers').remove();
                    $('ul.post-list li ').removeClass('hasfocus hasinfofocus');
                    
                    });            
               
               //Z6.1.5  - START OF mods          
                $(this).removeClass('thumb-view list-view simplelist-view maplist-view videogallery-view audiogallery-view');
                if (myClass=="gallery") ULclass="thumb-view";
                else if (myClass=="") ULclass ="list-view";
                else                ULclass =myClass+"-view"; 
                $(this).fadeIn("fast").addClass(ULclass);

                if (myClass=="videogallery" || myClass=="audiogallery" || cur_list_view=="videogallery" || cur_list_view=="audiogallery") {
                  // force a refresh with new view mode (alike apage next)

                  var filterparams = grab_all_filters('adlist'); 
                 // type and catid
                 filter_plus=""; 
                 if (type)  filter_plus+="&type="+type; 
                 if (catid) filter_plus+="&catid="+catid; 

                 ahref="dummy=1"; 
                 totparams=  ahref+filterparams+filter_plus;
                 
  
                 // make the ajax call  
                 ajax_action (totparams, cur_nav_ajax); 

                }
                //Z6.1.5 -END OF mods 

              });
            }
          });
        }
        
       // event handler for the show buttons 
       $('#adlist ul#ulnb_'+infinite_iterationnb+' a[name=show_ad]').click (function(e) {

         e.preventDefault();
         adidx=$(this).attr('lid');       // get local id 
         id=$(this).attr('id');           // get real id 
         whatidx=$(this).attr('what');    // get what 
         what2=$(this).attr('what2');     // location if exists
        
         if (((whatidx=="ad")||(whatidx=="cat")) && (what2=="user")){
          // special case of MLink to a USER 
          ahref=$(this).attr('z-href'); 
          ahref = ahref.substring(1);
          ajax_action(ahref);

         } else {
           // add +1 to hit counter only if no admin
           if ((!cur_user) || (cur_user.usertype!=9)){ 
            ajaxparam= 'action=updatehit&what='+whatidx+'&id='+id;
            ajax_action(ajaxparam);
            dataobj[adidx]["hits"]=parseInt(dataobj[adidx]["hits"])+1; // update local table
           }
           // display the element 
           if ((whatidx=="ad") && file_manager_mode) toto=1; // do nothing
           else { 
            elem_display(adidx, whatidx,'',what2);
            
           }
         }
         return true; 
       });
     
       // event handler for navigation links
       $('#adlist #listings-nav a[name=filter_list], #adlist #listing-nav-infinite a[name=filter_list], #adlist .listing-tab' ).click (function(e) {
         e.preventDefault();        

        if ($(this).parent().attr('id')=="listing-nav-infinite") {
            if ( $('#addetails:visible') && $('#addetails').html() ) return true; // do nothing when displaying something 
            
            $(this).next().show(); // display the loading bar
            $(this).remove(); // remove the button 
            $('.tooltip_tweet').hide(); // remove the tooltip displayed when clicking 
            savedWindowsOffsetTop = $(window).scrollTop();
        }


        // prevent click on already active tabs
        if ($(this).hasClass('listing-tab') && $(this).hasClass('active')) return true // do nothing this is already active
                
        ahref = $(this).attr('href');
        var tmpx = ahref.split("#");
        ahref = tmpx[tmpx.length-1]; // get just the final elements after latest # to correcr IE bug.
          

        var filterparams = grab_all_filters('adlist'); 
        var advsearch_params= $("#advsearch-form").serialize();
        filterparams += "&"+advsearch_params;


        // extra filters 
        filter_plus=""; 

        // protype filter : get the active tab if selected
        if (display_settings.list_nav_pro_par){
          activeTab =  $('.listing-tab.active'); 
          if (!$(this).hasClass('listing-tab')) filter_plus+="&ftype="+activeTab.attr('z-protype'); 
        }

        // type and catid
        if (type)  filter_plus+="&type="+type; 
        if (catid) filter_plus+="&catid="+catid; 
        ajax_action (ahref + filterparams+filter_plus, cur_nav_ajax); 

         
        // merge the actions and add to navigation history
        mhref = merge_href(ahref,cur_nav_ajax);          
        addToNavigatorHistory(mhref); 
         
        return true; 
       });
      


       if (infinite_iterationnb==1) {
       // event handler for the filter list
         $('#adlist .sort-options a[name=filter_list]').click (function(e) {
           e.preventDefault();
           ahref = $(this).attr('href');
           //ahref = ahref.substring(1); // remove the #
           var tmpx = ahref.split("#");
           ahref = tmpx[tmpx.length-1]; // get just the final elements after latest # to correcr IE bug.
           
           var filterparams = grab_all_filters('adlist'); 
            var advsearch_params= $("#advsearch-form").serialize();
            filterparams += "&"+advsearch_params;


           // type and catid
           filter_plus=""; 
           if(type) filter_plus+="&type="+type; 
           if (catid)filter_plus+="&catid="+catid; 
                    
           //ajax_action (ahref+"&view="+viewoption[1]+filter_plus, cur_nav_ajax); 
           ajax_action (ahref + filterparams+filter_plus, cur_nav_ajax); 
           
           return true; 
         });
       
          // event handler for the SORT SELECT LIST 
          $('#adlist .sort-options #filter_select').change(function() {
           var ahref = "action=list&what="+whattodisp;
           var filterparams = grab_all_filters('adlist'); 
           var filter_plus=""; 
           if(type) filter_plus+="&type="+type; 
           if (catid)filter_plus+="&catid="+catid; 
           ajax_action (ahref+filterparams+filter_plus, cur_nav_ajax);
           addToNavigatorHistoryAndCurrent( ahref+filterparams+filter_plus);
           return false; 
          });

          // event handler for the STATUS FILTER SELECT LIST 
          $('#adlist .filter-status-options #status_select , #adlist .filter-type-options #cattype_select').change(function() {

           //var thewhat = $(this).attr("what"); 
           var ahref = "action=list&what="+whattodisp;
           var thisid =  $(this).attr('id'); 
           var filterparams = grab_all_filters('adlist'); 
           var advsearch_params= $("#advsearch-form").serialize();
          filterparams += "&"+advsearch_params;
           
           // dont take current nav as duplicatied content 
           extraparams= "&nav=admin";
           if (userid) extraparams+="&userid="+userid;
           ajax_action (ahref+filterparams+extraparams,'');
           
           // save nav with filter (but not all elements)
           if (thisid=="status_select") fql="&status="+$(this).find("option:selected").val();
           if (thisid=="cattype_select") fql="&type="+$(this).find("option:selected").val();

           cur_nav_ajax =  ahref+fql+extraparams;
           addToNavigatorHistoryAndCurrent(cur_nav_ajax);
           
           return false; 
          });

          // event handler for the location button    
          $('.sort-options a[name=loc-check]').click (function(e) {
           e.preventDefault();
           var cur_loc = $(this).attr('cur_loc');
            // verify that googlemap is loaded 
            if ((!gmap_script_loaded)){
              displayMessage("Error in Google Map loading. Check your internet connection.",false);
            } else{ 
              geoloc(cur_loc, 'sort');
            }
           return true; 
          });

          $('.sort-options #sort_by_dist').change(function(e) {
           e.preventDefault();
       
           var ahref = "action=list&what="+whattodisp;
           var filterparams = grab_all_filters('adlist'); 
           var advsearch_params= $("#advsearch-form").serialize();
           filterparams += "&"+advsearch_params;

           var filter_plus=""; 
            
           if(type) filter_plus+="&type="+type; 
           if (catid)filter_plus+="&catid="+catid; 
           
           ajax_action (ahref+filterparams+filter_plus);
           cur_nav_ajax =  ahref+filterparams+filter_plus;
           addToNavigatorHistory(cur_nav_ajax);

           return false; 
          });
        
      } // end in fonite nav 

   
       // event handler for the show buttons 
       $('#adlist ul#ulnb_'+infinite_iterationnb+' a[name=manage_ad]').click (function(e) {
         e.preventDefault();

         // special case for links with a SEO mechanism in place Z4.9
         var isseo=false; 
         var theattr='href';
         if ($(this).attr('z-href')) {theattr = "z-href"; isseo=true; }  

         ahref = $(this).attr(theattr);
         var tmpx = ahref.split("#");
         ahref2 = tmpx[tmpx.length-1]; // get just the final elements after latest # to correcr IE bug.
         ahref3=ahref2;  
         if (cur_user) ahref2 +="&userid="+cur_user.id; // add cur_user id
        
         adidx=$(this).attr('lid'); // get local ID
         adwhat=$(this).attr('what');
   
         // evaluate the anchor value 
         eval_href(ahref, "anchor1"); 
       
         if ((anchor1.action)) {    
           if ((anchor1.action=="updatefav")) {    
            newfav = anchor1.adid; // calculate the new elements
            action2 = $(this).attr('action2'); // action2 to get if add or remove
            ajax_action (ahref2+"&action2="+action2+"&newfav="+newfav);
            
            // toggle the icon + text on the fav menu
            if (action2=="del") $(this).attr('action2','add').removeClass('del').html('<span class="icon"></span> '+$.i18n._('ad savefav')); 
            else  $(this).attr('action2','del').addClass('del').html('<span class="icon"></span> '+$.i18n._('ad del savefav'));
             
           }
           else if  (anchor1.action=="delete") 
              elem_delete(adidx, anchor1.what);
           else if  (anchor1.action=="updatestatus") {
             if  (adwhat=="ad")  
              display_DIALOG_BOX("Confirm modification",dataobj[adidx], "Please confirm modification to status "+anchor1.forceflag+" of :", ahref2, "inselect", sup_causes)
              else 
               display_DIALOG_BOX("Confirm modification",dataobj[adidx], "Please confirm modification to status "+anchor1.forceflag+" of :", ahref2)
           }
           else if  (anchor1.action=="emailhim")
              display_EMAIL_FORM("contact", anchor1.adid, adwhat, "" );
          else if (anchor1.action=="contactuser")
              display_EMAIL_FORM("contactuser", anchor1.adid, adwhat, "" ); 
          else if (anchor1.action=="emailad")
              display_EMAIL_FORM("remind", anchor1.adid, adwhat, "" );
          else if (anchor1.action=="login")
              display_LOGIN_FORM();    
          else if (anchor1.action=="download")
              dowload_file(anchor1.adid);         
          else if (anchor1.action=="list"){ 
             if (isseo) {
                ajax_action (ahref3);
                addToNavigatorHistoryAndCurrent('!!'+$(this).attr('z-surl'), 'localseo',ahref3); 
              } 
              else {
                ajax_action (ahref3);
                addToNavigatorHistoryAndCurrent(ahref3);   
              }       
           }
          else if (anchor1.action=="updateorder"){ 
             ajax_action (ahref3);
           }
          else if (anchor1.action=="updatelikes"){ 
            ajax_action (ahref3);
            // update the cookie assuing it's ok !
            cookval_before =  readCookie(COOKIEPREFIX+'_LIKES'); 
            texttoadd =  '&'+whattodisp+'='+anchor1.id+'&'; 
            if (cookval_before) cookietext=cookval_before+texttoadd; else cookietext = texttoadd ; 
            createCookie(COOKIEPREFIX+'_LIKES',cookietext, COOKIE_DURATION_1YEAR);
            // update the display 
            xval=parseInt($(this).attr('z-val')) + 1  ; 
            $(this).replaceWith(build_LIKES({likes:xval, id:$(this).attr('z-id')},whattodisp)); // update the dom 
           }
           // case of edit/modify
           else {
             if (adwhat=="cat") 
              elem_modify(adidx,'cat');
             else if (adwhat=="user") 
              elem_modify(adidx,'user');
             else if (adwhat=="zetvu") 
              elem_modify(adidx,'zetvu');
             else 
              //ad_modify(adidx);
              elem_modify(adidx,'ad');
            } 
            $('.drop-down-box').hide(); // hide all box
          }
         return true; 
         
       });
       
       activate_handler_on_broken_images('.imgWrapper img');
        
        if (infinite_iterationnb==1) {
           if ((whattodisp=="cat")|| (whattodisp=="user")) {
          // -- activate event handlers   
            $("#add_item_admin").click(function(e) { 
              e.preventDefault();
              adwhat=$(this).attr('what');
              $('#forminput').html(""); 
              elem_create_modify("create", adwhat);
            }); 
          }
        }

       // activate the tooltips on new links
        activate_tooltip('a');
    }
    return true; 
}; 





