/******************************************************************************
 * ZADS CUSTOM  JS script
 *
 * @category   CUSTOMPACKAGE for WANNANONCES.COM 
 * @package    ZADS
 * @author     Patrice COHAUT <patrice.cohaut@gmail.com>
 * @copyright  2013-14 PATMISC
 * @version    6.5.6
 ******************************************************************************/

pricetype_options = new Array (
    { name : 'price', value : '', id :'',  what:'ad', style:'', scope :'all', checked: 'checked'},
    { name : 'to be discussed', value : 'tbdi', id :'',  what:'ad', scope :'par|pro', style:'', checked: ''}, 
    { name : 'make an offer', value : 'mano', id :'',  what:'ad', scope :'par|pro', style:'', checked: ''}, 
    { name : 'on quote', value : 'onqo', id :'',  what:'ad', scope :'par|pro', style:'', checked: ''}, 
    { name : 'model dependant', value : 'mode', id :'',  what:'ad', scope :'par|pro', style:'', checked: ''}
    // ,{ name : 'salaires', value : 'sala', id :'',  what:'ad', scope :'par|pro', style:'', checked: ''}  
); 



// --------------------            modifications pour DUJMUSIC ------------------------------------------------------- //

pricetype_options = new Array (
    { name : 'price', value : '', id :'',  what:'ad', style:'', scope :'all', checked: 'checked', withvalue:true},
    { name : 'to be discussed', value : 'tbdi', id :'',  what:'ad', scope :'par|pro', style:'', checked: '', withvalue:true} 
    //{ name : 'on quote', value : 'onqo', id :'',  what:'ad', scope :'par|pro', style:'', checked: ''}, 
    //{ name : 'model dependant', value : 'mode', id :'',  what:'ad', scope :'par|pro', style:'', checked: ''}
    // ,{ name : 'salaires', value : 'sala', id :'',  what:'ad', scope :'par|pro', style:'', checked: ''}  

); 



var bookingform = {
     // the  Main form as displayed when creating of modifying an article   
     form1 : [
      {name: 'label2', type : 'label', desc :'booking details'},
        {name: 'bo_ad_id', type : 'input', mandatory :'yes', regx:'', size : '40' , desc :'*', help :'*',  checked: 'no', default_val :''},
        {name: 'bo_title', type : 'input', mandatory :'yes', regx:'', size : '40' , desc :'*', help :'*',  checked: 'no', default_val :''},
        {name: 'bo_start_end_date', field1:'bo_start_date', field2:'bo_end_date', type : 'date-double', subtype:'date', mandatory :'yes', size : '20' ,  desc :'*', postlabel:'', help :'', checked: 'no', default_val1 :'today'},       
        //{name: 'bo_nbadults',  type : 'select', mandatory :'yes',  linkedobj : options_nbqty , desc :'*', postlabel:'', help :'', checked: 'no', default_val :'1'},       
      {name: 'label2', type : 'label', desc :'booking user details'},
         //{name: 'bo_gender', type : 'radio',  regx:'',  linkedobj : options_gender , size : '' , desc :'*',help :'',  checked: 'no', default_val :''  },
         {name: 'bo_firstname', type : 'input',  regx:'', size : '30' , desc :'firstname', help :'',  checked: 'no', default_val :''  },
         {name: 'bo_lastname', type : 'input',  regx:'', size : '30' , desc :'lastname', help :'',  checked: 'no', default_val :''  },
         {name: 'bo_email', type : 'input', subtype:'email' , regx:EMAILREG , size : '40', maxsize:'60', desc :'user email',  help :'help email rules', checked: 'no', default_val :''  },
         {name: 'bo_location', type : 'input', regx:'GEOLOCATION' , size : '40', maxsize:'100' , desc :'user location', postmenu:'loc' , help :'help indicate for example a zip code or town', checked: 'no', default_val :''  },
         {name: 'bo_comments', type : 'textarea',regx:'', rowssize:'2', size : '70', maxchar : '250' , desc :'*', help :'', checked: 'no', default_val :''  },
      {name: 'label2', type : 'label', desc :'booking other details', onlymodify:'yes' ,accesslevel:'9'},
        {name: 'bo_moddate', accesslevel:'1', type : 'span-hidden', mandatory :'', onlymodify:'yes' , size : '20' ,regx:DATEREG,  desc :'*', postlabel:'', help :'' },
        {name: 'bo_moddate', accesslevel:'5', type : 'span-hidden', mandatory :'', onlymodify:'yes' , size : '20' ,regx:DATEREG,  desc :'*', postlabel:'', help :''},        
        {name: 'bo_moddate', accesslevel:'9', type : 'input', subtype:'datetime', mandatory :'', onlymodify:'yes' , size : '20' ,regx:DATEREG,  desc :'*', postlabel:'', help :'' },       
        {name: 'userid', type : 'input',  accesslevel:'9', onlymodify:'yes', mandatory :'yes', regx:'', size : '4' , desc :'userid', postlabel:'id of article owner', help :'',  checked: 'yes', default_val :''  },
        {name: 'status', type : 'span', onlymodify:'yes' , size : '' , desc :'ad status', postlabel:'', help :'' }

      ]
};

function init_local_vars_POST_CUSTOM(){

    var idx=''; 

    // hide location & date/time 
    idx=  JSON_find_index(adform.form_disp_panel_misc, 'moddate'); 
    adform.form_disp_panel_misc[idx].hide= true;

    idx=  JSON_find_index(adform.form_disp_panel_misc, 'location'); 
    adform.form_disp_panel_misc[idx].hide= true;

    idx=  JSON_find_index(adform.form_disp_panel_misc, 'vcounters'); 
    adform.form_disp_panel_misc[idx].hide= true;



}

/**-----------------------------------------------------------------------------
* This function display the advanced search bar 
*-----------------------------------------------------------------------------*/
function display_ADV_SEARCH_FORM(context) {

  var t=''; var t2=''; var one_line_search = (display_settings.advs_forced_vfields ) ? true: false;  
  t+='<div id="advsearch_area" class="">'; 
  t+='  <form id="advsearch-form">';

  if (!one_line_search){
    t+='    <div class="advs-title">'+$.i18n._("Advanced search :")+'</div>'; 
    t+='    <i class="action-close icon-fa-times-circle" z-action="close"/>'; 
    t+='    <div class="clear"></div>';
  }

  t+='    <div class="advsearch-main">'; 

  // display the search free text only if option not disabled 
  if (!display_settings.advs_no_freetext)
    t+='      <input type="text" tabindex="0" size="40" class="advs-in" id="advsearch" name="q" placeholder="" value="" autocomplete="off">'; 
  

  // first part of the search 
  t+='      <div class="advs-in advsearch-main-select-cat">'; 
  t += '      <select name="fcat" id="fcat" >';
  t +=        build_DOM_SELECT_options(cat_options,'' , "ad"); 
  t += '      </select>';
  t+='      </div>'; 


  var floc = display_settings.adv_search_location
  if (floc){
      t +='      <div class="advs-in advsearch-main-select-location">'; 
      t += '      <select name="f'+floc+'" id="f'+floc+'" >';
      t +=  '       <option  value="" id="" class=""   >'+$.i18n._('-- anywhere locregion --')+'</option>';
      // t+= getLocationsList(); 
      t += '      </select>';
      t+='      </div>'; 
  }


    t+='      <div class="advsearch-link">'; 
    t+='        <a name="" id=""  target="_blank" href="./docs/contrat.pdf" rel="" class="dm_button2 advs-in" style="width:200px;" ><i class="icon-fa-file-text-o"/>'+$.i18n._("Le contrat de location")+'</a>';
    t+='      </div>';


    t+='      <div class="advsearch-button top-search">'; 
    t+='        <a name="add_item" id="advsearch_submit_top" what="ad" type="buy" href="" rel="" class="dm_button2 advs-in "><i class="icon-fa-search"/>'+$.i18n._("Search")+'</a>';
    t+='      </div>';


  // display options only if no bar not activated 
  if (!display_settings.nav_no_bar){
      t +='      <div class="advs-in advsearch-main-select-type">'; 
      t += '      <select name="fwhat" id="fwhat" >';
      t +=  '<option  value="" id="" class=""   >'+$.i18n._('-- all type --')+'</option>';
      t +=        build_DOM_SELECT_options( options_a,'' , 'ad'); 
      t += '      </select>';
      t+='      </div>'; 
  }

  
  // compact the display for one-line search   
  if (one_line_search){
    // search button 
    ts=''; 
    ts+='    <div class="advsearch-button">'; 
    ts+='      <a name="add_item" id="advsearch_submit" what="ad" type="buy" href="" rel="" class="dm_button2 advs-in"><i class="icon-fa-search"/>'+$.i18n._("Search")+'</a>';
    ts+='    </div>';

    if (display_settings.advs_forced_vfields) {

      var tvfa= display_settings.advs_forced_vfields.split('|'); 
      $.each(tvfa, function(i, e) {
         tvadata= JSON_find_elem_byID(vfields_list,e); 
         if (tvadata) t2+=  vield_2_html(tvadata,"withlabelequaltitle", '', 'search'); // display fresh values 
      });

      if (t2)  t+='<div class="oneline-search">'+ t2+'</div>'+ts;
    }
  }
  else {
    // close button to go back 
    // t+='    <div class="advsearch-actions">'; 
    // t+='      <i class="action-close icon-fa-times-circle" z-action="close"/>'; 
    // t+='    </div>'; 
    // t+='      <div class="clear"></div>';
    t+='    <div class="clear"></div>'; 
    t+='    </div>';
    
    // second part of the search 
    t+='    <div class="advsearch-second">'; 
    t+='    </div>';
    t+='      <div class="clear"></div>'; 

    // search button area 
    t+='    <div class="advsearch-footer">'; 
    t+='      <div class="advsearch-footer-wrapper">'; 
    
   // urgent tag
    if (display_settings.urgent_ads_en){
      t+='    <div class="advsearch-urgent advs_checkbox">';
      t+='    <input type="checkbox" id="furgent" name="furgent" value="1"/>';
      t+='      <span>'+$.i18n._('Search in ads')+'<span class="urgent"><i class="icon-fa-exclamation mr6 ml6" class="" ></i>'+$.i18n._('urgents')+'</span>'+$.i18n._("only")+'</span>'; 
      t+='    </div>';
    }

    if (display_settings.advs_in_title_only && !display_settings.advs_no_freetext){
    // if (display_settings.advs_in_title_only ){
      t+='    <div class="advsearch-title-only advs_checkbox">';
      t+='    <input type="checkbox" id="ftitleonly" name="ftitleonly" value="1"/>';
      t+='      <span>'+$.i18n._("advs in title only")+'</span>'; 
      t+='    </div>';
    }

    if (display_settings.advs_with_photo) {
      t+='    <div class="advsearch-with-photo advs_checkbox">';
      t+='    <input type="checkbox" id="fwithphoto" name="fwithphoto" value="1"/>';
      t+='      <span>'+$.i18n._("advs with photo")+'</span>'; 
      t+='    </div>';
    }

    if (display_settings.advs_with_video) {
      t+='    <div class="advsearch-with-video advs_checkbox">';
      t+='    <input type="checkbox" id="fwithvideo" name="fwithvideo" value="1"/>';
      t+='      <span>'+$.i18n._("advs with video")+'</span>'; 
      t+='    </div>';
    }

    if (display_settings.advs_with_audio) {
      t+='    <div class="advsearch-with-audio advs_checkbox">';
      t+='    <input type="checkbox" id="fwithaudio" name="fwithaudio" value="1"/>';
      t+='      <span>'+$.i18n._("advs with audio")+'</span>'; 
      t+='    </div>';
    }


    t+='      <div class="advsearch-button bottom-search">'; 
    t+='        <a name="add_item" id="advsearch_submit" what="ad" type="buy" href="" rel="" class="dm_button2 advs-in "><i class="icon-fa-search"/>'+$.i18n._("Search")+'</a>';
    t+='      </div>';

    t+='      <div class="clear"></div>'; 
    t+='    </div>';
  }
   
  t+='      <div class="clear"></div>'; 
  t+='    </div>';
  
  t+='  </form>';
  t+='</div>'; 



  //change the class in case of NO nav bar 
  if (display_settings.nav_no_bar) $('#main-nav-adv-search').addClass('nav-no-bar');


  // ----- display into the content ------ 
  if (context=="startup")
  { 
    $('#main-nav-adv-search').hide().html(t).show();
    $('#main-nav-search').hide();
  }
    else 
  {
    $('#main-nav-adv-search').hide().html(t).slideDown();
    if (!isPageAdmin) $('#main-nav-search').slideUp(); 
  }


  // get location and display it if make sense 
  if (floc){
    if (locations_list_options.length==0)
      t = getLocationsList();
    else
    {
      t= buildOptionsLocationsList(locations_list_options); 
      $('.advsearch-main-select-location select').html(t) ;
    }

  }


  // activate autocomplete on input element 
  if (display_settings.adv_search_autosuggest){
    init_autocomplete('#advsearch','ajax'); 
  }


  // --- events handlers 
  // submit button 
  $("#advsearch_submit, #advsearch_submit_top").click(function(e) { 
    e.preventDefault();  launch_ADV_SEARCH();  return true; 
  }); 


  // search button 
  $("#advsearch").keypress(function (e) {
    if (e.which == '13') {
       e.preventDefault();
       launch_ADV_SEARCH(); 
       return true; 
     }
   });

  $(".advsearch-actions i, i.action-close ").click(function(e) { 
    e.preventDefault();  
    if ($(this).attr('z-action')=="close") { $('#advsearch_area').slideUp(); $('#main-nav-search').show();}
    return true; 
  }); 


  // detect changes to search field categorie 
    // change in category select list 
  if  (display_settings.vfields_search){
    $('#fcat').change(function(e) {
        var t='';
        var tid=  $(this).val(); 
    
        //check if category has associated vfields (search fields)
        var tvf= JSON_find_elem_byID(cat_options,tid).catlvfields; 
        if (tvf) {
          var tvfa= tvf.split('|'); 
          $.each(tvfa, function(i, e) {
            e = e.split(';')[0]; // protection 
            tvadata= JSON_find_elem_byID(vfields_list,e); 
              t+=  vield_2_html(tvadata,"withlabelequaltitle", '',  "search"); // display fresh values 
          });

          if (t !='') {
            t= '<div class="">'+t+'<div class="clear"></div></div><div class="clear"></div>'; 
            $('.advsearch-second').html(t); // append to the second search field 
          } else  $('.advsearch-second').html(''); // clean up the zone 
        } else  $('.advsearch-second').html(''); // clean up the zone 
      });
  }
  
  // end of function 

  return true; 
}


