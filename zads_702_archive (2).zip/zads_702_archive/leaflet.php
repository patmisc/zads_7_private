
<?php 

  // ----- SET Tag for Admin pages   ----// 
  $isPageAdmin = false; $preload_facebook_js=false; 
  if ($isPageAdmin) $bodyextraclass = "admin-page"; else $bodyextraclass="";

  // ----- INIT ESSENTIAL SETTINGS =  LANGUAGE  ----// 
  include_once "./phpsvr/init_settings.php";

  // ----- BANNERS ----// 
  include_once "./phpsvr/banners.php"; 

  // ----- HTML SNAPSHOT FOR SEO   ----// 
  include_once "./phpsvr/html_snapshot_lib.php"; 
  $r= detect_escaped_fragment();


?> 
 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr">
<head>	

  <!-- SEO optimization = TITLE, DESC and META dynamically displayed -->
  <?php 

    if ( ($r==false) && !(isset($_GET['gplus'])) ) { 
       // DEFAULT HOME 
       $metasAr = Array('title'=> $cust_title, 'desc'=>$cust_description, 'image'=>$cust_logo_fb_uri, 'url'=>$DOMAIN_FQDN, 'gplus'=>$cust_gplus_url); 
    } else { 
      if (isset($_GET['gplus'])){
        // generate dynamically title & description depending on nav // 
        $metasAr = Array('title'=> trim($_GET['title']), 'desc'=>trim($_GET['desc']), 'image'=>trim($_GET['image']), 'url'=>trim($_GET['realurl'])); 
      } else {
        // HTML snapshop
        $metasAr = get_metas($r);
      }
    }

    // display METAS in all cases 
    echo display_metas($metasAr);  
   ?>

  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />  
 
  <!-- not really used by SEO -->
  <meta name="keywords" lang="<?php echo $cust_lang;?>" content="<?php echo $cust_keywords;?>" /> 
 
  <link rel="shortcut icon" type="image/x-icon" href="<?php echo $cust_favicon_uri;?>"> 
  <link rel="icon" type="image/x-icon" href="<?php echo $cust_favicon_uri;?>">
  <!-- <link rel="shortcut icon" href="favicon.ico" /> -->

  <!-- SRC image for FACEBOOK sharing  -->
  <link rel="image_src" href="<?php echo $cust_favicon_uri;?>" / >
  
  <!-- LIB stylesheets -->
   
 <!--  <link rel="stylesheet" media="all" type="text/css" href="css/skeleton.css"  />
  <link rel="stylesheet" media="all" type="text/css" href="css/chosen.css"  />
 -->

  <link rel="stylesheet" media="all" type="text/css" href="<?php echo $ROOT_LIBS_URL;?>css/patmisc.lib.min.css"  />
  <link rel="stylesheet" media="all" type="text/css" href="<?php echo $ROOT_LIBS_URL;?>css/datepicker.css"  />

   <!-- awesome font  -->
  <!-- <link rel="stylesheet" media="all" type="text/css" href="css/font-awesome.min.css"> -->
  <link rel="stylesheet" media="all" type="text/css" href="css/font-awesome.css">
  <!--[if IE 7]>
  <link rel="stylesheet" href="/css/font-awesome-ie7.css">
  <![endif]-->
  
  <!-- THEME and CUSTOM  stylesheets -->
  <?php if (isset($THEME_MASTER_CSS_URL) && $THEME_MASTER_CSS_URL!="") { ?> 
  <link rel="stylesheet" media="all" type="text/css" href="<?php echo $THEME_MASTER_CSS_URL;?> "  />
  <?php } else { ?>
    <link rel="stylesheet" media="all" type="text/css" href="css/theme_style.css"  />
  <?php } ?> 
  
  <?php if (isset($THEME_CSS_URL) && $THEME_CSS_URL!="") { ?> 
    <link rel="stylesheet" media="all" type="text/css" href="<?php echo $THEME_CSS_URL;?> "  />
  <?php } else { ?>
    <link rel="stylesheet" media="all" type="text/css" href="css/custom_style.css"  />
  <?php } ?> 


    
  <!--[if IE 6]> 
  <link rel="stylesheet" href="theme_style_IE6.css" type="text/css" media="screen" /> 
  <![endif]-->
  
  <link rel="stylesheet" media="screen and (min-device-width: 320px) and (max-width:480px)" href="css/mobile.css" type="css/text/css" />
  <link rel="stylesheet" media="screen and (min-device-width: 481px) and (max-device-width: 799px)" type="text/css" href="css/tablet.css"/>
  <link rel="stylesheet" media="screen and (min-width: 481px) and (max-width: 799px)" type="text/css" href="css/tablet.css"/>
  
  
  <!--  special meta for tablets and smartphones -->
  <meta name="viewport" content="width=device-width" /> 
  <link rel="apple-touch-icon" href="zadsmobicon.png" /> 
  <meta name="apple-mobile-web-app-capable" content="yes" />
  <meta name="apple-mobile-web-app-status-bar-style" content="black" />
  <link rel="apple-touch-startup-image" href="bg/iphonestartup2.png"/>
  <!-- <link rel="apple-touch-icon-precomposed" href="/images/icon.png"/> -->
  
  <!-- RSS feeds --> 
  <link rel="alternate" type="application/rss+xml" href="phpsvr/tmp1.php?rss=sell"  title="<?php echo $cust_motto;?> 10 dernieres offres et demandes" />
  <?php if ($ZETVU_AS_NEWS) { ?> 
  <link rel="alternate" type="application/rss+xml" href="phpsvr/tmp1.php?rss=zetvu"  title="<?php echo $cust_motto;?> 10 derniers ZeTvu" />
  <?php } ?> 

  <!-- meta for crawling AJAX elements -->
  <meta name="fragment" content="!">

  
  <!-- native javascript functions (no jquery) to make some tests before starting HTML -->
  <script type="text/javascript" src="lib/patmisc.preload.toolkit.min.js"></script> 

  <!-- adblocker detection  -->
  <script type="text/javascript" src="lib/ads.js"></script>

    <!-- set variable for admin  --> 
  
    <script type="text/javascript">
      var preload_facebook_js=false;  // default value
      <?php if ($isPageAdmin){?>
        var isPageAdmin=true; 
        
      <?php } else { ?>
        var isPageAdmin=false; 
    <?php } ?>
    </script>
  
</head>

<!-- <body id="top"> -->
<body id="top" style=" <?php echo $bodyextrastyle ?> " class=" <?php echo $bodyextraclass ?> " lang="<?php echo $cust_lang; ?>" xzads-lang="<?php echo $cust_lang_long; ?>" xzads-lang-support="<?php echo $cust_lang_support; ?>">

  <!-- placeholder for Facebook javascript-->
  <div id="fb-root"></div>

  <!-- MODL BOX !!!! BUT BE PUT FIRST  after the body ********* --> 
      <div id="boxes">
      	<div id="dialog" class="mbox-window">
          <div id="mbox-close"> <a href="#" id="close" class="close"></a></div>
      	  <!-- empty space for mbox-header-->
      	  <div class="clearer">&nbsp;</div>
        	<div id="mbox-body">
          </div>  		
      		<div id="mbox-footer"> <a href="#" class="close"></a></div>
        </div>
       	<div id="mask"></div>
       	<div id="mask2"></div>
      </div>
      
      	<!-- Global message Area  --> 
          <div id="global_message" class="error" style="display:none;">
            <a href="" class="msg-close" nottip="yes"></a>
            <p id="inner"></p>  
          </div>
          <div class="clearer">&nbsp;</div>   
        
  <div id="site" class="leaflet">
	<div class="center-wrapper">
	 <div class="center-wrapper-inner">
	 
		<div class="main" id="main-two-columns">
			<div class="left" id="main-left"> 
         
        <!-- Overlay message area --> 
        <div id="oe_wrap" class="oe_wrap" style="display:none;">
          <div class="icon"></div><div class="content"></div><div id="oe_close"></div>
        </div>    
              
         <!-- AREA to display Breadcrumb  --> 
         <!--
          <div id="breadcrumbs" class="clear" style="display:none;">
        	</div> 
          -->
      	
          <!-- AREA to display Ad details  --> 
          <div id="addetails" class="addetails" > 
          </div>
          
          <div class="clearer">&nbsp;</div>           

        	<div class="clearer">&nbsp;</div>

			</div>
			
			<div class="clearer">&nbsp;</div>
			
      
      <div id="dashboard">
         <?php  if ($cust_logo_uri) { ?>
          <img src="<?php echo $cust_logo_uri;?>  "></img>
         <?php } ?>
       <span id="footertext"> <?php echo (stripslashes($cust_site_motto)); ?></span>
        <P class="center"><a href="#" id="fullfqdn"></a></p>
      </div>

		</div>
        

	</div>
	</div>
</div>

  <!-- Jquery LIB -->                                                                    
  <!--<script type="text/javascript" src="lib/jquery.js"></script>-->  
  <script type="text/javascript" src="lib/jquery-1.4.4.min.js"></script> 
  
  <script type="text/javascript">
  loadanim = false;
  </script>
  

  <!-- Jquery address plug-in -->
  <script type="text/javascript" src="lib/jquery.address-1.3.1.min.js"></script>                                                                  
  <script type="text/javascript" src="lib/jquery.easing.1.3.min.js"></script>                                                                  
  <script type="text/javascript" src="lib/jquery.zads.toolkit.js"></script> 

  <!-- LANGUAGE File (MASTER) -->
  <?php if (!$DISABLE_TRANSLATION) { ?> 
    <script type="text/javascript" src="lang/<?php echo str_replace('_','-',$cust_lang_long); ?>.js"></script>
  <?php }?>


    <!-- DATE PICKER --> 
  <script type="text/javascript" src="<?php echo $ROOT_LIBS_URL;?>lib/bootstrap-datepicker.min.js"></script>        

  <!-- LANGUAGE File (CUSTOM) - COMING ON TOP OF EXISTING ONE -->
  <?php if (isset($THEME_CUST_LANG_URL) && $THEME_CUST_LANG_URL!="" && !$DISABLE_TRANSLATION) { ?> 
    <script type="text/javascript" src="<?php echo $THEME_CUST_LANG_URL.str_replace('_','-',$cust_lang_long); ?>.js"></script>
  <?php }?>
  
  
  <script type="text/javascript" src="lib/jquery.qrcode.min.js"></script> 
  
  <!-- location Array (Javascript) --><!-- 
  <script type="text/javascript" src="lib/ArrayDept.js"></script>
   -->

  <!-- HELLO- SSO plugin -->
 <?php if ($OAUTH_SSO_EN) { ?> 
  <script type="text/javascript" src="lib/hello.min.js"></script>    
 <?php }?>

  <!-- Core feature of ZADS--> 
  <script type="text/javascript" src="js/zads.js"></script> 
  <!-- SECOND STAGE  feature of ZADS--> 
  <script type="text/javascript" src="js/zads_post.js"></script> 

  <!-- CUSTOM STAGE  feature of ZADS--> 
  <?php if (isset($THEME_EXTRA_JS_URL) && $THEME_EXTRA_JS_URL!="") { ?> 
   <script type="text/javascript" src="<?php echo $THEME_EXTRA_JS_URL;?>"></script> 
  <?php } ?>
  
  <!-- google map API *** asynchronously loaded *** --> 
  
  <!-- evernote script *** asynchronously loaded *** --> 

</body>
</html>
