<?php
/******************************************************************************
 * ZADS EMAIL TEMPLATES  SERVER 
 * 
 * Note :  works SETTINGS.PHP file & LOCALIZATION.PHP
 *  
 * @category   CorePackage
 * @package    ZADS
 * @author     Patrice COHAUT <patrice.cohaut@gmail.com>
 * @copyright  2013 PATMISC
 * @version    5.1
 ******************************************************************************/

require_once("multitenants_settings.php");   
require_once($SETTINGS_PATH."settings.php");
require_once("functions.php"); 
require_once("localization.php");  

if (!session_is_admin()) die ('not the right access level') ; // exit if not ADMIN 

// general variable 
date_default_timezone_set('Europe/Paris');
//force a debug based on settings file Zads5.0
$debug_tmp=0; 
if ($ENABLE_DEBUG_MODE) $debug_tmp=1; 
$trace='';
if ($debug_tmp==1) { 
	error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING); 
	$debugoutputfile = "debugoutput.htm";
	$debugfile=$debugoutputfile;
	$debugfile = fopen($debugoutputfile,"a"); if(!$debugfile) { echo "Error writing to the output file.\n";}

}
else error_reporting(E_ERROR |  E_PARSE);
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING | E_DEPRECATED));

$fullfqdn = $DOMAIN_FQDN; 



if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $thisip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $thisip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $thisip = $_SERVER['REMOTE_ADDR'];
}

// logfile('', '[EMAIL TEMPLATES  SERVER ] --------------------------------------', __LINE__); // start a new call of file  

// special switch to disable the function directly into PH 
if (!$ENABLE_EMAILS_TEMPLATES) {
	 $json = array(
                  'success' => false,
                  'message' => "emails templates mode not activated in Configuration",
                  'action' => $action,
                  'subaction'=>$subaction
              );
	 echo json_encode($json); 
	die; //exit clause
}


// TEMPLATE_VERSION  can be V1 (default)  V2=withTITLE inside HTML elements 
if ($EMAILS_TEMPLATES_ENH) define('EMAIL_TEMPLATE_VERSION', "V2");
else define('EMAIL_TEMPLATE_VERSION', "V1");


// URL
if (EMAIL_TEMPLATE_VERSION=="V2")
 if ($EMAILS_TEMPLATES_DIR) $dir= $EMAILS_TEMPLATES_DIR.$cust_lang_long.'/';
 else $dir= 'locale_emails/'.$cust_lang_long.'/';
else $dir= 'emails_templates/'.$cust_lang_long.'/';
define('ROOT_URL', './phpsvr/'.$dir);


// -------------- SERVLET FOR ACTIONS   ----------------------
if( isset($_POST["emails"]) ) {

	if  (isset($_POST["emails"])) $subaction = $_POST["emails"];
	else if (isset($_POST["emails"]))  $subaction = $_POST["emails"];
	$action =  "emails";
	$success=false; $message="Ajax Call not recognized"; 

  	$ret=false;
  	$sort = isset($_POST["sort"]) ? $_POST["sort"] : null; //possible values are  : name, type, size, date
	$trace.="-- $subaction --";


 	//----- LIST -----------------------------
	if ($subaction=="list"){
		$message=""; 
		// get the list of files - use default DIRECTORY for seurity reason 
		
		$dirlink = @opendir($dir);
		
		// make the search in directory 
		$filelist = array();
		while (($file = readdir($dirlink)) !== false) {
			if (		$file != "." 
					&& 	$file != ".." 
					&& !is_dir("{$dir}/{$file}")
					&& ft_get_ext($file)!="bak"
				)
			{
				$c = array();
				$c['name'] = $file;
				// $c['htmlencoded'] = base64_encode(utf8_decode(file_get_contents($dir.$file)));
				$c['modified'] = @filemtime("{$dir}/{$file}");
				$c['size'] = @filesize("{$dir}/{$file}");
				$filelist[] = $c;
			}
		}
		closedir($dirlink);

		if (!is_array($filelist)) {
			$success=false;
			$message="Could not open directory"; 
			$ret=false; 
		} else {
			$success=true;
			foreach ($filelist as $c) {
				$toto=1;// FUTURE PROCESSING /FILTERING 
			}
			$ret = $filelist; 
			$message=""; 
		}
	}

	//----- READ  -----------------------------
	if ($subaction=="read") {
		$message="";
		$trace.="-- in read --";
		$is_hf= false; 


		if  (isset($_POST["fname"])) { // fine name is defined 
			$filename = $_POST["fname"]; 

			$filefullcontent=file_get_contents($dir.$filename);

		    if (strpos($filename, '_header') !== false || strpos($filename, '_footer') !== false){
		    	$html_content = $filefullcontent;
		    	$is_hf= true; 
		    }else {
			    if (EMAIL_TEMPLATE_VERSION=="V2") {
			        $html_title =  get_innert_html_from_str($filefullcontent, 'title');
			        $html_content = get_innert_html_from_str($filefullcontent, 'body');
			    } else {
			    	$html_content = $filefullcontent; 
			    }
			}

			$ret = array();
			$ret['name'] = $filename;
			$ret['isplaintxt'] = $is_hf;
			$ret['htmlencoded'] = base64_encode(utf8_decode($html_content));
			if (EMAIL_TEMPLATE_VERSION=="V2") $ret['subjectencoded'] = base64_encode(utf8_decode($html_title));
			$success=true;
		}
	}



	//----- SAVE  -----------------------------
	if ($subaction=="save"){
		$message=""; 

		$htmlcode = $_POST["htmlcode"] ;
		$subject = $_POST["subject"] ;
		$fname = $_POST["fname"] ;

		$fnamear = explode(".",$fname);
		$fnamenoext = $fnamear[0];
		$fnameext = $fnamear[1];

		// // get the variable 
		if (get_magic_quotes_gpc()){
    		$htmlcode =  stripcslashes($htmlcode); // remove the / added by magic quote option
    		if (EMAIL_TEMPLATE_VERSION=="V2") $subject=stripcslashes($subject); 
    	}

    	// $htmlcode =  utf8_encode(base64_decode($htmlcode)); // remove the / added by magic quote option
  		// $htmlcode =  base64_decode($htmlcode); // remove the / added by magic quote option


		// get the list of files - use default DIRECTORY for seurity reason 
		
		$filepath = $dir.$fname; 
		$filepathbak = $dir.$fnamenoext.'_'.date("Ymd-His").".bak";
		
        // save existing  files as old for backup reason 
        if ($htmlcode) {
        	// $trace = rename($filepathbak, $filepath);
        	$bakuphtml = file_get_contents($filepath);
        	file_put_contents($filepathbak, $bakuphtml);

        	// save the content 
        	if (strpos($fname, '_header') !== false || strpos($fname, '_footer') !== false){
				$finalcontent =  $htmlcode ; 
        	} else {
				if (EMAIL_TEMPLATE_VERSION=="V2"){
					$finalcontent =  "<title>".$subject."</title>\n";
					$finalcontent .=  "<body>\n".$htmlcode."\n</body>";
				} else $finalcontent =  $htmlcode ; 
			}
        	$status = file_put_contents($filepath, $finalcontent);

        } else $status=false; // force an error

		if (!$status) {
			$success=false;
			$message="Error in updating content"; 
			$ret=false; 
		} else {
			$success=true;
			$ret = true; 
			$message  = "File saved successfully !"; 
		}
	}


	//----- SEND A TEST EMAIL-----------------------------
	if ($subaction=="test"){
		$message=""; 
		$destemail = $_POST["email"] ;
		$fname = $_POST["fname"] ;
		$rule=$_POST["rule"]; 

		$in_what=$_POST["fwhat"]; 
		$in_state=$_POST["fstate"]; 
		$in_to=$_POST["fto"]; 

		define('EMAIL_FORMAT_UTF8', true);
		$input_datas_is_utf8=true; // indicate that below input datas are in UTF8 format !

		if ($thisip && in_array($in_what, ['core', 'user']))
		{
          $r=get_IP_details($thisip); 
          $thisipdetails=$r["serialized"]; // get a textual value 
		}

		$thisbrowser = getBrowser(); 


		$dataobjsample=array(
			'core'=> array(
							'title'=> 'Ceci est une annonce éà de test fictive'
							, 'firstname'=> 'Acme éà firstname'
							, 'lastname'=> 'Acme éà lastname'
							, 'uemail'=>'test.user@acmeinc.com'
							, 'email'=>'test.user@acmeinc.com'
							, 'id'=>777
							, 'ip'=>$thisip
							// , 'ipdetails'=>"hostname : feg67-1-82-244-195-171.fbx.proxad.net<br>city : Eschau<br>region : Bas-Rhin<br>country : FR<br>loc : 48.4890,7.7164<br>org : AS12322 Free SAS<br>postal : 67114" 
							, 'ipdetails'=> $thisipdetails
							, 'userenv' =>  $thisbrowser
							, 'msg'=> 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam tempus, eros vitae eleifend pellentesque, turpis sem dictum urna, ac aliquam dolor velit eget mi. Nullam porttitor, felis vel vestibulum venenatis, nulla odio tristique libero, vel tristique massa velit vel quam. Ut a metus mollis, aliquet sem ut, hendrerit erat. Mauris elementum nibh sit amet lorem cursus bibendum. Integer et enim laoreet, imperdiet ex et, sagittis neque')
		
			,'ad'=> array(
							'title'=> 'Ceci est une annonce éà de test fictive'
							, 'firstname'=> 'Acme éà firstname'
							, 'lastname'=> 'Acme éà lastname'
							, 'uemail'=>'test.user@acmeinc.com'
							, 'id'=>777
							, 'paymenturl'=>$fullfqdn.'link=123GST42545765Z7Z65'
							, 'msg'=> 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam tempus, eros vitae eleifend pellentesque, turpis sem dictum urna, ac aliquam dolor velit eget mi. Nullam porttitor, felis vel vestibulum venenatis, nulla odio tristique libero, vel tristique massa velit vel quam. Ut a metus mollis, aliquet sem ut, hendrerit erat. Mauris elementum nibh sit amet lorem cursus bibendum. Integer et enim laoreet, imperdiet ex et, sagittis neque')
			
			,'notif'=> 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam tempus, eros vitae eleifend pellentesque, turpis sem dictum urna, ac aliquam dolor velit eget mi. Nullam porttitor, felis vel vestibulum venenatis, nulla odio tristique libero, vel tristique massa velit vel quam. Ut a metus mollis, aliquet sem ut, hendrerit erat. Mauris elementum nibh sit amet lorem cursus bibendum. Integer et enim laoreet, imperdiet ex et, sagittis neque'
			
			,'cron'=> 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam tempus, eros vitae eleifend pellentesque, turpis sem dictum urna, ac aliquam dolor velit eget mi. Nullam porttitor, felis vel vestibulum venenatis, nulla odio tristique libero, vel tristique massa velit vel quam. Ut a metus mollis, aliquet sem ut, hendrerit erat. Mauris elementum nibh sit amet lorem cursus bibendum. Integer et enim laoreet, imperdiet ex et, sagittis neque'
			,'service'=> array(
							'name'=> 'Ceci est le nom du service'
							, 'sdesc'=> 'SERVICE 1'
							, 'userid'=> 9999
							, 'id'=>777
							)

			,'lost'=> array(
							'email'=>'test.user@acmeinc.com'
							, 'id'=>777
							, 'password'=>$thisip
							, 'reseturl' => $fullfqdn.'link=123GST42545765Z7Z65'
							)

			,'user'=> array(
							 'firstname'=> 'Acme éà firstname'
							, 'lastname'=> 'Acme éà lastname'
							, 'email'=>'test.user@acmeinc.com'
							, 'id'=>777
							, 'ip'=>$thisip
							, 'paymenturl'=>$fullfqdn.'link=123GST42545765Z7Z65'
							, 'ipdetails'=>$thisipdetails
							, 'msg'=> 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam tempus, eros vitae eleifend pellentesque, turpis sem dictum urna, ac aliquam dolor velit eget mi. Nullam porttitor, felis vel vestibulum venenatis, nulla odio tristique libero, vel tristique massa velit vel quam. Ut a metus mollis, aliquet sem ut, hendrerit erat. Mauris elementum nibh sit amet lorem cursus bibendum. Integer et enim laoreet, imperdiet ex et, sagittis neque'
							)
			
			,'support'=> array(
							  'emailtitle'=> 'Ceci est le titre du message'
							, 'firstname'=> 'Acme prénom'
							, 'lastname'=> 'Acme nom de famille'
							, 'emailfrom'=>'test.user@acmeinc.com'
							, 'phone'=> '0311223344'
							, 'procpny'=> 'ACME INC'
							, 'emailstamp'=> '2016-01-01 00:00:00'
							, 'id'=>777
							, 'ip'=>$thisip
							, 'userenv' => $thisbrowser
							, 'ipdetails'=>$thisipdetails
							, 'emaildesc'=> 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam tempus, eros vitae eleifend pellentesque, turpis sem dictum urna, ac aliquam dolor velit eget mi. Nullam porttitor, felis vel vestibulum venenatis, nulla odio tristique libero, vel tristique massa velit vel quam. Ut a metus mollis, aliquet sem ut, hendrerit erat. Mauris elementum nibh sit amet lorem cursus bibendum. Integer et enim laoreet, imperdiet ex et, sagittis neque'
							, 'title'=> 'Ceci est une annonce éà de test fictive'
							)

		);

		// try to decode 
		if (!isset($_POST["fstate"])){
			$fname_noext = explode(".", $fname);
			$fnameAr = explode("_", $fname_noext[0]);
			$in_what=$fnameAr[1]; 
			$in_state=$fnameAr[2];
			$in_to=$fnameAr[0];
		}

		// add debug elements 
		// $html_content = "<br>*** THIS IS A TEST EMAIL ***<br> *** FILENAME = $fname ***<br><br>" . $html_content ;

		// get the sample datas 
		$in_what_sample=$in_what;
		if (in_array($in_what, ['support','feedback','abuse', 'remind','contact','contactuser']) ) $in_what_sample='support'; 
		if (in_array($in_what, ['lost','reactivateaccount','lost-link']) ) $in_what_sample='lost'; 

		$dataobj=$dataobjsample[$in_what_sample];

		$result = build_message_based_template($in_what, $in_state,  ["title"=>'TEST',  "to"=> $in_to], $dataobj); 
		if ($EMAILS_TEMPLATES_ENH && $result  ){
           $html_content =   $result ['body'] ; 
           $html_title =  $result ['title'] ;
        } else {
          $html_content = $result ; 
        }


		if (EMAIL_FORMAT_UTF8) $message=$html_content;
		else $message=utf8_decode($html_content);	

		// title
		$html_title = "TEST ** ".$html_title;
		if (EMAIL_FORMAT_UTF8) $subject=$html_title;
		else $subject=utf8_decode($html_title);	

		// recipient 
		$recipient = $destemail;
		$headers  = 'MIME-Version: 1.0' . "\r\n";

		// header 
		if (EMAIL_FORMAT_UTF8) $headers .= 'Content-type: text/html; charset=utf-8' . "\r\n"; // for HTML documents
		else   $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; // for HTML documents
	    $headers .= "From: $EMAIL_FROMADMIN" . "\r\n";


	    // add debug informations if <!--[DEBUG]--> present in the content
	    if (strpos($message, '<!--[DEBUG]-->') !== false){
	    	$debugmessage =  "*** test message -> TEMPLATE : $fname TO : $in_to ***"; 
	    	$debugmessage = '<tr><td align="center" bgcolor="#000" style="color:#FFF; font-size:10px;padding: 0px 10px 0px 10px;">'.$debugmessage.'</td></tr>';
	    	$message = str_replace('<!--[DEBUG]-->',$debugmessage, $message, $count);
    	}	

	    				
	    // save for backup 
	    $emailmessage=$message; 
	 
		if (mail ("$recipient", "$subject", "$message", "$headers")){
			$message="Test Mail sent successfully to $recipient"; 
			$success=true; 
			logfile('notice',"email sent correctly to $recipient"); 
		} else {
			$message="Problem while sending the test email to $recipient"; 
			$success=false; 
			logfile('error',"email not sent to  $recipient");
		}

		// debug, save last sent email 
		$email_log= fopen('./logs/lastemail.html',"w");
		$ret = fwrite($email_log,$emailmessage); 

	}

	//----- SANITIZE routes & files-----------------------------
	if ($subaction=="checkup") {
		$message=""; 
	    $cachedir =  $SETTINGS_PATH ;
	    $filename = "emailroutes.json"; 
	    $emailRoutingTable = json_decode(file_get_contents($cachedir.$filename), true);
		$ret =  sanity_check_routing($emailRoutingTable, true, false);
		$ret = base64_encode(utf8_decode($ret));
	}

	  //----- check if one file exists -----------------------------
	  if ($subaction=="exist") {
	    $message=""; 
	    $fname = $_POST["fname"] ;
	    $ret = array('filename' => $fname, 'title'=>''); 
	    if (file_exists ($dir.$fname)) {
	      $success=true;
	      $filefullcontent=file_get_contents($dir.$fname);
	      $html_title =  get_innert_html_from_str($filefullcontent, 'title');
	      $ret['title'] =  $html_title; 
	    }
	    else {
	      $success=false;
	      $message  = $dir.$fname." does not exist !"; 
	    }
	  }

	//----- SANITIZE routes & files-----------------------------
	if ($subaction=="sendallmails"){
		$message="All emails sent successfully to $EMAIL_ADMIN "; 
	    $cachedir =  $SETTINGS_PATH ;
	    $filename = "emailroutes.json"; 
	    $emailRoutingTable = json_decode(file_get_contents($cachedir.$filename), true);
		$ret =  sanity_check_routing($emailRoutingTable, true, true); 
		$ret = base64_encode(utf8_decode($ret));
	}

  //----- Get JSON routing table -----------------------------
	if ($subaction=="getroutingtable"){
		$message="ok "; 
		$success=true; 
		// $cachedir = "./cache/"; 
    	$cachedir =  $SETTINGS_PATH ;
		$filename = "emailroutes.json"; 
		$ret = json_decode(file_get_contents($cachedir.$filename));
	}

  //----- save JSON routing table -----------------------------
	if ($subaction=="saveroutingtable"){
		$message="ok "; 

		$fname = $_POST["fname"] ;
		$payload = $_POST["payload"] ;

		// $cachedir = "./cache/"; 
    	$cachedir =  $SETTINGS_PATH ;
		if (!$fname) $filename = "emailroutes.json"; 
		else $filename = $fname;

		if (get_magic_quotes_gpc()) $payload =  stripcslashes($payload);
		
		$payload = indent($payload);
		$st = file_put_contents($cachedir.$filename, $payload);
		if ($st){
			$success=true; 
			$message="Routing table saved successfully";
		} else {
			$success=false; 
			$message="Error in writing file $cachedir.$filename ";
		}
	}


 //----- out the message -----------------------------
  // prepare the output code          
     $json = array(
                  'success' => $success,
                  'message' => $message,
                  'action' => $action,
                  'subaction'=>$subaction,
                  'data' => $ret,
                  'rooturl'=>ROOT_URL,
                  'trace'=>$trace
              );
              
 
     // if ($debug_tmp==1){ // add debug info into the stream when working local
     //   $json["xdebug"]= array(
     //              'sql'=> $ret[sql], 
     //              'sqlerror'=> $ret[sqlerror],
     //              'sql2'=> $ret[sql2],
     //              'in'=> $ret[indata]
     //            );  
     // }
    echo json_encode($json); 

}

function array_find_by_key($inAr, $keyname, $valuetofind){
	$out=false;
	if (count($inAr)>0){
		foreach ($inAr as $key1 => $value1) {
			foreach ($value1 as $key2 => $value2) {
				if ($key2==$keyname && $value2==$valuetofind){
					return $key1; 
				}
			}
		}
	}
	return $out; 
}


/**
 * create an HTML message based on a template 
 * @param $what string  	: the element (ad, user, ...)
 * @param $state string  	: the state 
 * @param $theemailrule  	: array containing the TITLE and TO 
 * @return string  : the email CONTENT (HTML or TEXT) 
 * @author Patrice COHAUT
 */

  // $input_datas_is_utf8=true; 
  function utf8_adapt($strin){
  	global $input_datas_is_utf8;

  	if ($input_datas_is_utf8) $out=$strin; 
  	else $out = utf8_decode($strin); 
  	return $out;
  }

function build_message_based_template($what, $state, $theemailrule, $dataobj){

  // existing vocabulory 
  // [SITE_NAME], [SITE_MOTTO], [SITE_CUSTOMER],  [SITE_FQDN], [SITE_LOGO]
  // [EMAIL_TITLE], 
  // [AD_TITLE] , [AD_ID], [AD_URL] , [AD_LEAFLET_URL],
  // [CUR_DATE] , 
  // [USER_FIRSTNAME], [USER_LASTNAME], [USER_EMAIL],  [USER_URL],  [MESSAGE] 


  $tags_library = array(
  	"general" => array('SITE_NAME', 'SITE_MOTTO', 'SITE_CUSTOMER',  'SITE_FQDN', 'SITE_LOGO', 'SITE_COPYRIGHT', 'CUR_DATE', 'CUR_YEAR', 'STATIC_EMAIL_IMAGE_URL', 'BANNER_EMAIL_IMAGE_URL')
  	,"ad"=> array('AD_TITLE' , 'AD_ID', 'AD_URL' , 'AD_LEAFLET_URL', 'PAY_URL')
  	,"user"=>array('USER_FIRSTNAME', 'USER_LASTNAME', 'USER_EMAIL',  'USER_URL', 'USER_IP', 'USER_IP_DETAILS')
  	,"cron"=>array('CRONMESSAGE')
  	,"notif"=>array('NOTIFMESSAGE')
  	,"lost"=>array('LOGIN', 'PASSWORD', 'LOGIN_URL')
  	,"reactivateaccount"=>array('LOGIN', 'PASSWORD', 'LOGIN_URL')
  	,"lost-link"=>array('RESET_URL')
	,"service"=>array('SERVICE_NAME', 'SERVICE_SDESC', 'SERVICE_ID',  'USER_URL')
	,"support"=>array('CONTACT_REASON', 'CONTACT_TITLE', 'CONTACT_DETAILS',  'CONTACT_ENV', 'CONTACT_EMAILFROM', 'CONTACT_FIRSTNAME', 'CONTACT_LASTNAME',  'CONTACT_PROCPNY', 'CONTACT_DATE')
  	,"feedback"=>array('CONTACT_REASON', 'CONTACT_TITLE', 'CONTACT_DETAILS',  'CONTACT_ENV', 'CONTACT_EMAILFROM', 'CONTACT_FIRSTNAME', 'CONTACT_LASTNAME',  'CONTACT_PROCPNY', 'CONTACT_DATE')
  	,"abuse"=>array('CONTACT_REASON', 'CONTACT_TITLE', 'CONTACT_DETAILS',  'CONTACT_ENV', 'CONTACT_EMAILFROM', 'CONTACT_FIRSTNAME', 'CONTACT_LASTNAME',  'CONTACT_PROCPNY', 'CONTACT_DATE')
  	,"remind"=>array('CONTACT_REASON', 'CONTACT_TITLE', 'CONTACT_DETAILS',  'CONTACT_ENV', 'CONTACT_EMAILFROM', 'CONTACT_FIRSTNAME', 'CONTACT_LASTNAME',  'CONTACT_PROCPNY', 'CONTACT_DATE')
  	,"contact"=>array('CONTACT_REASON', 'CONTACT_TITLE', 'CONTACT_DETAILS',  'CONTACT_ENV', 'CONTACT_EMAILFROM', 'CONTACT_FIRSTNAME', 'CONTACT_LASTNAME',  'CONTACT_PROCPNY', 'CONTACT_DATE')
  	,"contactuser"=>array('CONTACT_REASON', 'CONTACT_TITLE', 'CONTACT_DETAILS',  'CONTACT_ENV', 'CONTACT_EMAILFROM', 'CONTACT_FIRSTNAME', 'CONTACT_LASTNAME',  'CONTACT_PROCPNY', 'CONTACT_DATE')

  );  	


  global $fullfqdn; 
  global $SITE_NAME; 
  global $SITE_MOTTO; 
  global $SITE_CUSTOMER; 
  global $debugfile;
  global $cust_lang_long;
  global $EMAILS_TEMPLATES_ENH; 
  global $EMAILS_TEMPLATES_DIR;
  global $LOGO_FQDN; 
  global $cust_site_copyright;
  global $STATIC_EMAIL_IMAGE_URL;

  if (!defined("CACHE_PATH")) define('CACHE_PATH', 'cache/');


  //Z6.2.0
  global $supportfeedback_name_translation; 

  if (!defined('EMAIL_TEMPLATE_VERSION')){
  	if ($EMAILS_TEMPLATES_ENH) define('EMAIL_TEMPLATE_VERSION', "V2");
  	else define('EMAIL_TEMPLATE_VERSION', "V1");
  }

  $stamp2= date( 'Y-m-d H:i:s', time());
  $dest = $theemailrule["to"]; // AMDIN, USER, OWNER 
  $map = array(); //mapping table between input data and reported value 

  // logfile('', "{build_message_based_template} : in the email templating function"); 

  $map["SITE_NAME"]= utf8_adapt($SITE_NAME); 
  $map["SITE_MOTTO"]= utf8_adapt($SITE_MOTTO); 
  $map["SITE_CUSTOMER"]= utf8_adapt($SITE_CUSTOMER); 
  $map["SITE_FQDN"]= $fullfqdn;
  $map["SITE_LOGO"]= str_replace('./',$fullfqdn, $LOGO_FQDN, $count); 
  $map["SITE_COPYRIGHT"]= $cust_site_copyright; 

  // images 
  $map["STATIC_EMAIL_IMAGE_URL"]=($STATIC_EMAIL_IMAGE_URL)? $STATIC_EMAIL_IMAGE_URL : ''; 

  
  $map["CUR_DATE"]= $stamp2;
  $map["CUR_YEAR"]= date("Y");
  $map["EMAIL_TITLE"]=$theemailrule["title"];
  
  //if (($what=="ad") || ($what=="user")){
  $map["AD_URL"]= $fullfqdn.'#item-'.$dataobj["id"]; 
  $map["AD_TITLE"]= htmlspecialchars(utf8_adapt(stripslashes($dataobj["title"])));
  $map["AD_ID"]= $dataobj["id"];
  $map["AD_LEAFLET_URL"]= $fullfqdn.'leaflet.php#item-'.$dataobj["id"];
  $map["USER_FIRSTNAME"]= utf8_adapt($dataobj["firstname"]);
  $map["USER_LASTNAME"]= utf8_adapt($dataobj["lastname"]);
  $map["USER_EMAIL"]=$dataobj["uemail"];
  $map["USER_URL"]= $fullfqdn.'#user-'.$dataobj["id"];
  $map["MESSAGE"] = nl2br(utf8_adapt(stripslashes($dataobj["msg"]))); 


  $map["MYSERVICES_URL"]= $fullfqdn.'#myservices';

  // for debug, display all content 
  // $map["MESSAGE"] .= serialize($dataobj);  

  if (($what=="cron"))  {
    $map["CRONMESSAGE"]=$dataobj; 
  }

   if (($what=="notif"))  {
    $map["NOTIFMESSAGE"]=$dataobj; 
  }

  if (($what=="lost")  || ($what=="reactivateaccount") )  {
     $map["LOGIN"] = $dataobj["email"]; 
     $map["PASSWORD"] = $dataobj["password"]; 
     $map["LOGIN_URL"]= $fullfqdn.'#login';
  }

  if (($what=="lost-link") )  {
     $map["RESET_URL"] = $fullfqdn.'#'.$dataobj["reseturl"]; 
  }
  if ( ($what=="user") || ($what=="core")){
     $map["USER_EMAIL"]=$dataobj["email"]; // special patch
     $map["LOGIN"] = $dataobj["email"]; 
     $map["PASSWORD"] = $dataobj["password"]; 
     $map["LOGIN_URL"]= $fullfqdn.'#login'; 
     $map["USER_IP"]= $dataobj["ip"];
     $map["USER_IP_DETAILS"]= $dataobj["ipdetails"];
   }

    if (($what=="service"))  {
     $map["SERVICE_NAME"] = $dataobj["name"]; 
     $map["SERVICE_SDESC"] = $dataobj["sdesc"]; 
     $map["SERVICE_ID"] = $dataobj["id"]; 
     // patch the USER_URL value 
     $map["USER_URL"]= $fullfqdn.'#user-'.$dataobj["userid"];
    
  }

   if ($state=="15"){
      $map["PAY_URL"]=$dataobj["paymenturl"];
   }

  //fwrite($debugfile,"-- Var assigned  ---");


  // get the template file name

	// -- generic rules
   $tpl_name=$dest."_".$what."_".$state.".html"; 

	// -- exceptions    
	if (($what=="ad") && ($dest=="USER" || $dest=="OWNER")) $tpl_name="owner_ad_".$state.".html";
	if (($what=="user") && ($dest=="USER" || $dest=="OWNER")) $tpl_name="owner_user_".$state.".html";

	if (($what=="curuser") && ($dest=="USER" || $dest=="OWNER")) $tpl_name="owner_user_".$state.".html";
	if (($what=="curuser") && ($dest=="ADMIN")) $tpl_name="admin_user_".$state.".html";

	if (($what=="service") && ($dest=="USER" || $dest=="OWNER")) $tpl_name="owner_service_".$state.".html";
	  
	// cron
	if (EMAIL_TEMPLATE_VERSION!="V2") {
	    if (($what=="cron")) $tpl_name="cron.html";
	    if (($what=="notif")) $tpl_name="notif.html";
	    if (($what=="lost-link")) $tpl_name="lost_password_link.html";
	    if (($what=="lost")) $tpl_name="lost_password.html";
	    if ($what=="remind") $tpl_name="user_reminder_00.html";
	    if (($what=="reactivateaccount")) $tpl_name="reactivate_account.html";
	}

	  if (($what=="support") || ($what=="feedback") || ($what=="abuse")|| ($what=="remind") || ($what=="contact") || ($what=="contactuser"))  
	  {
	    
	   if ($what=="abuse"){
	      $tpl_name="admin_abuse_00.html"; // for admin
	      if ($dest=="USER")  $tpl_name="user_abuse_00.html";
	    } else if ($what=="contact"){ // contact between USER and OWNER based on an ad
	      if ($dest=="USER")  $tpl_name="user_contact_00.html";
	      if ($dest=="OWNER")  $tpl_name="owner_contact_00.html";
	    } else if ($what=="contactuser"){ // contact between USER and OWNER based on an ad
	      if ($dest=="USER")  $tpl_name="user_contactuser_00.html";
	      if ($dest=="OWNER")  $tpl_name="owner_contactuser_00.html";
	    } else if ($what=="remind"){ // contact between USER and OWNER based on an ad
	      if ($dest=="USER")  $tpl_name="user_remind_00.html"; 
	    } else if (($dest=="USER" || $dest=="OWNER"))
	      $tpl_name="owner_support_00.html";
	      else 
	      $tpl_name="admin_support_00.html";
	  
	    // assign variables
	    $map["CONTACT_REASON"]=$supportfeedback_name_translation[$dataobj["contactreason"]];
	    $map["CONTACT_TITLE"]=utf8_adapt(stripslashes($dataobj["emailtitle"]));
	    $map["CONTACT_DETAILS"]=nl2br(utf8_adapt(stripslashes($dataobj["emaildesc"])));
	    $map["CONTACT_ENV"]=utf8_adapt($dataobj["userenv"]);
	    $map["CONTACT_EMAILFROM"]=utf8_adapt($dataobj["emailfrom"]);
	    $map["CONTACT_FIRSTNAME"]=utf8_adapt($dataobj["firstname"]);
	    $map["CONTACT_LASTNAME"]=utf8_adapt($dataobj["lastname"]);
	    $map["CONTACT_PHONE"]=utf8_adapt($dataobj["phone"]);
	    $map["CONTACT_PROCPNY"]=utf8_adapt($dataobj["procpny"]);
	    $map["CONTACT_DATE"]=utf8_adapt($dataobj["emailstamp"]);

	  }


  // lowercase all 
  $tpl_name=strtolower($tpl_name); 


  // dump the map for debug 
  $map_dump = print_r($map, true);
  logfile('debug', "{build_message_based_template} : $map_dump"); 

  // get the directory and full fqdn of the templated
	if (EMAIL_TEMPLATE_VERSION=="V2")
	 if ($EMAILS_TEMPLATES_DIR) $tpl_dir= $EMAILS_TEMPLATES_DIR.$cust_lang_long.'/';
	 else $tpl_dir= 'locale_emails/'.$cust_lang_long.'/';
	else $tpl_dir= 'emails_templates/'.$cust_lang_long.'/';
	$tpl_full_fqdn = $tpl_dir.$tpl_name;

  // log
  logfile('', "{build_message_based_template} :for WHAT=$what, STATE=$state > template FQDN = $tpl_full_fqdn :  DEST = $dest "); 

  if (file_exists($tpl_full_fqdn)) {
    $tpl_content = file_get_contents($tpl_full_fqdn);

    // format the email : 
    // create the final HTML BODY to be sent by email  
    $htmfull_emailtest = $tpl_content;
    
    if (EMAIL_TEMPLATE_VERSION=="V2") {
        $html_title =  get_innert_html_from_str($htmfull_emailtest, 'title');
        $htmfull_emailtest = get_innert_html_from_str($htmfull_emailtest, 'body');
    } else  {
      $htmfull_emailtest = utf8_adapt($tpl_content);
    }

    // check if other elements to add : 
    $inherited_content=  array( 
    	array("tag"=>"<!--[ZADS_FOOTER]-->", "url"=>"admin_core_footer.html")
    	,array("tag"=>"<!--[ZADS_HEADER]-->", "url"=>"admin_core_header.html")
    ); 
    foreach ($inherited_content as $key => $inherit) {
    	$inh_tag =  $inherit['tag']; 
    	$inh_url =  $inherit['url']; 

    	if (strpos($tpl_content, $inh_tag) !== false){
    		$tlp_inh_fqdn  = $tpl_dir.$inh_url;
	  		if (file_exists ($tlp_inh_fqdn)) {
	    		$fc=file_get_contents($tlp_inh_fqdn);
	    		$fcb = $fc ;  // not in valid HTML format !
	    		$htmfull_emailtest = str_replace($inh_tag,$fcb, $htmfull_emailtest, $count);
	  			logfile('', "{build_message_based_template} : detected $inh_tag, adding content of $tlp_inh_fqdn "); 
	  		} 
    	}	 
    }

    // image banners
    $inh_tag='[BANNER_EMAIL_1_IMG_URL]'; 
    if (strpos($htmfull_emailtest, $inh_tag) !== false){
    	$cache_banners = json_decode(file_get_contents(CACHE_PATH."banners.json"),true);
		if ($cache_banners) 
		{
		  	$idx=array_find_by_key($cache_banners['datas'], "position", "email_1");
			if ($idx){
				$thiselem=$cache_banners['datas'][$idx];
				$fcb = base64_decode(stripslashes($thiselem['htmlcode'])); 
				$htmfull_emailtest = str_replace('[BANNER_EMAIL_1_IMG_URL]',$fcb, $htmfull_emailtest, $count); 
				$fcb = stripslashes($thiselem['clicktrackingurl']);  
			    $htmfull_emailtest = str_replace('[BANNER_EMAIL_1_CLICK_URL]',$fcb, $htmfull_emailtest, $count);  
			}
		}
    } 

    // process the final mapping 
    foreach ($map as $k => $v) {
      $htmfull_emailtest = str_replace("[".$k."]",$v, $htmfull_emailtest, $count);
    }
     
    // convert from UTF8 -> LATAM Format 
    // $htmfull_emailtest = utf8_adapt(stripslashes($htmfull_emailtest));  
    if (EMAIL_TEMPLATE_VERSION=="V2") {
      $out =array();$out['body'] = $htmfull_emailtest; $out['title'] = $html_title ; 
      return $out;
    }
    else return($htmfull_emailtest); 
  } 
  else {
    logfile('NOTICE', "{build_message_based_template} : $tpl_full_fqdn : file does not exist"); 
    return false; // no file content 
  }

}


function get_innert_html_from_str($tpl_content, $tagName){

    // $DOM = new DOMDocument;
    $DOM = new DOMDocument('1.0', 'UTF-8');
    // mandatory to forcethis to understand that this is UTF8 document 
    $tpl_content= '<meta http-equiv="Content-Type" content="text/html; charset=utf-8">'.$tpl_content;
    $DOM->loadHTML($tpl_content);
    $items = $DOM->getElementsByTagName($tagName);
    for ($i = 0; $i < $items->length; $i++){
      $result = get_inner_html($items->item($i)) ;
      return $result; 
    }
}

function get_inner_html( $node ) {
    $innerHTML= '';
    $children = $node->childNodes;
    foreach ($children as $child) {
        $innerHTML .= $child->ownerDocument->saveXML( $child );
    }
    return $innerHTML;
}


function  get_IP_details($ip) {
    require_once ("inc/generic_API_client.php");
    $r=array(); 
    if(!filter_var($ip, FILTER_VALIDATE_IP)) {
        $r['message']= "Not a valid IP address!";
        $r['success']=false; 
    } else
    {
      // get IP address details 
      $url = "http://ipinfo.io/$ip" ; 
      $r= simple_rest_client($url, 'GET');

      if ($r['success']){
        $rstr=''; 
        foreach ( $r['response'] as $key => $value){
          $rstr .= "$key : $value \n<br>  " ;
        }
        $r['serialized'] = $rstr ;
      } else $r['serialized'] = "" ;
    } 
    return $r;
}

function  array_to_html($Ar){
	$out='';
	$rstr=''; 
    foreach ($Ar as $key => $value){
      $rstr .= "$key : $value \n<br>  " ;
    }
    $out=$rstr; 
	return $out; 	
}


function sanity_check_routing($emailRoutingTable, $silent, $sendemail){
	// read each routing rule and check if filexist
	global $dir; 
	global $EMAIL_ADMIN;
	global $EMAIL_FROMADMIN;


	$count=0;
	$tpl_name='';
	$trail ='';


	foreach ($emailRoutingTable as $what => $rule1) {
		foreach ($rule1 as $status => $rules) {
			foreach ($rules as $idx => $rule) {
				$count+=1; 
				$to = $rule['to'];
				$title =  $rule['title'];
				$tpl_name='';

				// route 
        $idroute = "$count - route =". strtolower($to."_".$what."_".$status) ; 
				$trail .= $idroute ; 

				// get the template name
				if (in_array($what, ['ad','user','service', 'curuser']) && $to=="USER") $to="OWNER";
				 if (($what=="support") || ($what=="feedback") || ($what=="abuse") || ($what=="contact") || ($what=="contactuser"))  
				  {
				    if ($what=="abuse"){
				      $tpl_name="admin_abuse_00.html"; // for admin
				      if ($to=="USER")  $tpl_name="user_abuse_00.html";
				    } else if ($what=="contact"){ // contact between USER and OWNER based on an ad
				      if ($to=="USER")  $tpl_name="user_contact_00.html";
				      if ($to=="OWNER")  $tpl_name="owner_contact_00.html";
				    } else if ($what=="contactuser"){ // contact between USER and OWNER based on an ad
				      if ($to=="USER")  $tpl_name="user_contactuser_00.html";
				      if ($to=="OWNER")  $tpl_name="owner_contactuser_00.html";
				    } else if (($to=="USER" || $dest=="OWNER"))
				      $tpl_name="owner_support_00.html";
				    else 
				      $tpl_name="admin_support_00.html";
				}

				// default when not overwritten
				if (!$tpl_name) $tpl_name = strtolower($to."_".$what."_".$status).".html" ; 
				$filename=$tpl_name; 
				$trail .= ' - file ='. $filename ; 

				if (file_exists ($dir.$filename)){
				 $trail .= '<span style="color:green;margin-left:10px;">OK</span>';
				 // open the file and get the title 
				 $filefullcontent=file_get_contents($dir.$filename);
		         $html_title =  get_innert_html_from_str($filefullcontent, 'title');
		         $html_content = get_innert_html_from_str($filefullcontent, 'body');

		         if ($html_title != $title){
		         	$trail .= utf8_decode("$html_title vs $title");
		         	$trail .= '<span style="color:red;margin-left:10px;">Name Mismatch -- correcting</span>';
					$finalcontent =  "<title>".$title."</title>\n";
					$finalcontent .=  "<body>\n".$html_content."\n</body>";
        			$st = file_put_contents($dir.$filename, $finalcontent);
		         } else {
		         	$trail .= utf8_decode("$html_title");
		         }
		         
				} else {
					// file does not exist 
					$trail .= '<span style="color:red;margin-left:10px;">Does not exist</span>';
					$trail .= utf8_decode($title);
					$html_content = '<span style="color:red;margin-left:10px;">Missing template for '.$tpl_name.'</span>';
				}
				$trail .= "<br>"; 

				// ---  send an email 
				if ($sendemail) {
					$headers  = 'MIME-Version: 1.0' . "\r\n";
					$headers .= 'Content-type: text/html; charset=utf-8' . "\r\n"; // for HTML documents
				    $headers .= "From: $EMAIL_FROMADMIN" . "\r\n";
				    $subject= "BULKTEST *** $title" ; 
				    $message = $html_content; 
            $message = "TRACE : ROUTE = $idroute <br> FILE = $filename<br><br>".$message;
				    $recipient = $EMAIL_ADMIN ; 

					if (mail ("$recipient", "$subject", "$message", "$headers")){
						$message="Test Mail sent successfully to $recipient<br>"; 
						$success=true; 
					} else {
 						$message = '<span style="color:red;margin-left:10px;">Error in sending message '.$tpl_name.'</span><br>';
					}
					$trail .=$message; 
				}
			}
		}
	} 

	if (!$silent)  echo $trail ; 
	return $trail; 
}





/* not an ajax call = a direct call */ 
if(empty($_SERVER['HTTP_X_REQUESTED_WITH']) && !defined('SENTINEL') ) {
	// save in the cache file the routing table
	$cachedir = "./cache/"; 
	$filename = "emailroutes.json"; 
	$rtconfig = json_encode($emailRoutingTable, JSON_PRETTY_PRINT) ; 
	// $rtconfig = json_encode($emailRoutingTable) ; 
	$st = file_put_contents($cachedir.$filename, $rtconfig);
	sanity_check_routing($emailRoutingTable, false, false); 
}


?>