
--
-- Contenu de la table `test45vfields`
--

INSERT INTO `test45vfields` (`id`, `moddate`, `int_label`, `disp_label`, `domtype`, `domsubtype`, `stype`, `values`, `unit`, `default`, `userid`, `forwhat`, `scope`, `status`, `linkedvfield`, `xmandatory`, `xmin`, `xmax`, `xregx`, `forprofile`, `xvisible`) VALUES
(12, '2013-12-22 20:57:44', 'radio buttons', 'radio buttons', 'radio', 'various', '', 'radio 1|radio 2', '', NULL, '86', '', 'cat', '40', '', '', '', '', '', '', ''),
(9, '2013-12-29 17:07:44', 'Energie - auto', 'Energie', 'select', 'various', '', 'Diesel|Essence|GPL|Electrique|Autre', '', NULL, '86', '', 'cat', '40', '', '', '', '', '', '', ''),
(30, '2013-12-29 17:13:13', 'Cylindrée - moto', 'Cylindrée', 'input', 'integer', '', '', 'cm3', NULL, '86', 'ad', 'cat', '40', '', '', '', '', '', '', ''),
(13, '2013-12-22 20:57:55', 'Surface', 'Surface', 'input', 'integer', '', '', 'm2', NULL, '86', 'ad', 'cat', '40', '', '', '', '', '', '', ''),
(14, '2013-12-22 20:56:58', 'Kilométrages', 'Kilométrages', 'input', 'integer', '', '', 'kms', NULL, '86', 'ad', 'cat', '40', '', '', '', '', '', '', ''),
(31, '2013-12-30 14:57:10', 'Boite vitesse- auto- recherche', 'Boite de vitesse', 'select', 'various', '', 'automatique|Manuelle', '', NULL, '86', 'ad', 'search', '40', '27', '', '', '', '', '', ''),
(16, '2013-12-22 20:57:50', 'Piéce immo', 'Piéces', 'input', 'integer', '', '', '', NULL, '86', 'ad', 'cat', '40', '', '', '', '', '', '', ''),
(17, '2013-12-22 20:57:17', 'Type immo', 'Type de bien', 'select', 'various', '', 'Maison|Appartement|Terrain|Location de vacances|Parking|Autre', '', NULL, '86', '', 'cat', '40', '', '', '', '', '', '', ''),
(18, '2013-12-22 20:57:12', 'Vet - type', 'Type', 'select', 'various', '', 'Femme|Femme enceinte|Homme|Enfant', '', NULL, '86', 'ad', 'cat', '40', '', '', '', '', '', '', ''),
(19, '2013-12-22 20:57:05', 'Capacité-location', 'Capacité', 'input', 'integer', '', '', 'Pers', NULL, '86', '', 'cat', '40', '', '', '', '', '', '', ''),
(20, '2013-12-22 20:56:53', 'Class-energie-immo', 'Classe énergie', 'select', 'various', '', 'A (moins de 50)|B (de 51 à  90)|C (de 91 à  150)|D (de 151 à  230)|E (de 231 à  330)|F (de 331 à  450)|G (de 451 à  590)|H (de 591 à  750)|I (751 et plus)|Vierge', '', NULL, '86', '', 'cat', '40', '', '', '', '', '', '', ''),
(21, '2013-12-22 20:56:47', 'Ges-immo', 'GES', 'select', 'various', '', 'A (moins de 5)|B (de 6 à  10)|C (de 11 à  20)|D (de 21 à  35)|E (de 36 à  55)|F (de 56 à  80)|G (de 81 à  110)|H (de 111 à  145)|I (146 et plus)|Vierge', '', NULL, '86', '', 'cat', '40', '', '', '', '', '', '', ''),
(22, '2013-12-22 20:56:39', 'Meublé O/N', 'Meublé', 'select', 'various', '', 'Meublé|Non Meublé', '', NULL, '86', '', 'cat', '40', '', '', '', '', '', '', ''),
(23, '2013-12-22 20:56:19', 'Piscine', 'Piscine', 'checkbox', 'various', '', 'Piscine', '', NULL, '86', '', 'cat', '40', '', '', '', '', '', '', ''),
(26, '2014-01-26 16:35:26', 'pointure-chaussure', 'Pointure', 'select', 'various', '', '16|17|18|19|20|21|22|23|24|25|26|27|28|29|30|31|32|33|34|35|36|37|38|39|40|41|42|43|44|45|46|47|48|49|50+', '', NULL, '0', 'ad', 'cat', '40', '', '', '', '', '', '', ''),
(27, '2013-12-29 17:07:56', 'Boite-vitesse - auto', 'Boite de vitesse', 'select', 'various', '', 'Manuelle|Automatique', '', NULL, '86', 'ad', 'cat', '40', '', '', '', '', '', '', ''),
(28, '2013-12-29 17:00:43', 'Année- modéle- auto', 'Année modéle ', 'select', 'various', '', '2013|2012|2011|2010|2009|2008|2007-', '', NULL, '86', '', 'cat', '40', '', '', '', '', '', '', ''),
(29, '2013-12-29 17:01:31', 'marque voiture', 'Marque', 'select', 'various', '', 'Peugeot|Citroen|Renault|Volvo', '', NULL, '86', 'ad', 'cat', '40', '', '', '', '', '', '', ''),
(32, '2013-12-30 16:42:36', 'Energie -auto- recherche', 'Energie', 'select', 'various', '', 'Diesel|Essence|GPL|Electrique|Autres', '', NULL, '86', '', 'search', '40', '9', '', '', '', '', '', ''),
(33, '2013-12-30 17:09:38', 'kms-range-min', 'Kms (min)', 'select', 'various', 'min', '0|10000|20000|30000|40000|50000|60000|100000', 'km', NULL, '86', 'ad', 'search', '40', '14', '', '', '', '', '', ''),
(34, '2013-12-30 17:10:53', 'kms-range-max', 'km (max)', 'select', 'various', 'max', '10000|25000|50000|100000|200000', 'km', NULL, '86', 'ad', 'search', '40', '14', '', '', '', '', '', ''),
(35, '2013-12-30 18:28:21', 'Annee modéle MIN - auto - recherche', 'Année (min)', 'select', 'various', 'min', '2013|2012|2011|2010|2009-', '', NULL, '86', 'ad', 'search', '40', '28', '', '', '', '', '', ''),
(36, '2013-12-30 18:29:40', 'Année modéle MAX - auto - recherche', 'Année (max)', 'select', 'various', 'max', '2013|2012|2011|2010|2009-', '', NULL, '86', 'ad', 'search', '40', '', '', '', '', '', '', ''),
(38, '2013-12-30 18:58:01', 'Prix Min - input- libre - recherche', 'Prix (min)', 'input', 'various', 'min', '', '', NULL, '86', '', 'search', '40', 'price', '', '', '', '', '', ''),
(39, '2013-12-30 18:59:28', 'Prix - range Min  ', 'Prix (min)', 'select', 'various', 'min', '0|1000|2000|3000|4000|5000|10000|20000', '', NULL, '86', 'ad', 'search', '40', 'price', '', '', '', '', '', ''),
(40, '2013-12-30 21:34:43', 'Prix Max - range ', 'Prix (max)', 'select', 'various', 'max', '1000|2000|3000|5000|10000|20000+', '', NULL, '86', '', 'search', '40', 'price', '', '', '', '', '', ''),
(41, '2014-01-26 16:24:40', 'Champ libre usager 1', 'Champ libre usager 1', 'input', 'various', '', '', '', NULL, '0', 'user', 'cat', '60', '', '', '', '', '', '', ''),
(42, '2014-01-26 16:24:14', 'Champs liste deroulante usager ', 'Champs liste ', 'select', 'various', '', 'one|two|three|four', 'pol', NULL, '0', 'user', 'cat', '60', '', '', '', '', '', '', ''),
(47, '2014-04-06 11:04:02', 'recherche champ long ', 'recherche champ long ', 'select', 'various', '', 'Valeur 1 MAJ|Valeur 2 MAJ|Valeur 3 MAJ', '', NULL, '200', '', 'search', '40', '46', '', '', '', '', '', ''),
(46, '2014-04-06 11:03:10', 'Champ nom long', 'champ nom long ', 'select', 'various', '', 'Valeur 1 MAJ|Valeur 2 MAJ|Valeur 3 MAJ', '', NULL, '0', '', 'cat', '40', '', '', '', '', '', '', '');
