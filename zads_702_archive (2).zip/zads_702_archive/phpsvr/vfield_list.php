<?php
/******************************************************************************
 * ZADS VFIELD LIST GET 
 * 
 * Note :  works bootstrap0.php
 *
 * @category   CorePackage
 * @package    ZADS
 * @author     Patrice COHAUT <patrice.cohaut@gmail.com>
 * @copyright  2017 PATMISC
 * @version    7.4.0
 ******************************************************************************/

define('DB_MODE', 'both'); // both =  create two db accesses (one with old mode and one with new mode)
require_once("bootstrap0.php"); 
// die('coucou');


define('OUTPUT_DATA_FORMAT', 'HTML'); // both =  create two db accesses (one with old mode and one with new mode)

if (isset($_GET['key']) ) {
  $type= $_GET['key']; 
  $value = $_GET['value']; 

  // general variables
  $now= date( 'Y-m-d H:i:s', time());

  // simply query the value from the db

    // $result = $dbb->get(DB_TABLE_LISTS, ["value"] , " `key`='$key'");  
    

    $result = $dbb->select(DB_TABLE_LISTS,  ["value"] , "  `type`='$type' and `key` LIKE '$value%' "); 
    $maxresults = count($result); 
    
    if (OUTPUT_DATA_FORMAT=="HTML"){
       $outStr=''; 
      foreach ($result as $key => $value) {
        $outStr.='<option value="'.$value['value'].'">'.$value['value'].'</option>'; 
      }
      $loglist  =  $outStr;
    } else $loglist = $result; 


    // $thisuserid=0; 
    // $result = $dbb->get(DB_TABLE_USERS, ["id", "verify", "email", "phone", "phone2"] , " id=$thisuserid");
    // $loglist = $result; 

    // -- output result ------------- 
    $json = array(
        'totnb' =>$maxresults,
        'data' => $loglist
    );

 if ($debug_tmp==1){ // add debug info into the stream when working local

  $query = $dbb->get_log();
  $trace .= $dbb->get_logtime();

   $json["xdebug"]= array(
            'lastquery'=> $query,
            'trace'=>$trace,
            '$_SESSION'=>$_SESSION,
            '$_GET'=>$_GET
            );  
   }
  encode_json_and_send_with_compression($json);   
}
else {
  exit ('hi from '.basename($_SERVER["SCRIPT_FILENAME"]));
}


?>