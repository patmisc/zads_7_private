<?php
/******************************************************************************
 * ZADS BANNER Server Script
 * 
 * Note :  works with DB_SETTINGS.PHP &  SETTINGS.PHP file & LOCALIZATION.PHP
 * LINKED LIB: facebook.php ; 
 *  
 * @category   CorePackage
 * @package    ZADS
 * @author     Patrice COHAUT <patrice.cohaut@gmail.com>
 * @copyright  2013 PATMISC
 * @version    4.7
 ******************************************************************************/
/* Disable direct access.*/
if(!strcasecmp(basename($_SERVER['SCRIPT_NAME']),basename(__FILE__))) 
die('ZADS- Direct Access to this file not allowed!');
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING | E_DEPRECATED));

/* detect the PHP version */ 
if(function_exists('phpversion'))
   $v = phpversion();
  elseif(PHP_VERSION)
   $v = PHP_VERSION;
  else
   $v =  'Impossible de détecter la version PHP';
$phpVersion = intval(str_replace('.','',$v));

// load libraries & settings 
require_once("multitenants_settings.php"); 
require_once($SETTINGS_PATH."db_settings.php");  
require_once($SETTINGS_PATH."settings.php");
require_once("localization.php");

require_once ('inc/Mobile_Detect.php');
$detect = new Mobile_Detect;

// Any mobile device (phones or tablets).
if ( $detect->isMobile() ) {
  $ismobile=true; 
} else $ismobile=false;


// set default timezone 
date_default_timezone_set('Europe/Paris');

$debug ="";
$debug_tmp = 0 ; // 0= server 1=local
if (( $_SERVER['SERVER_ADDR'] != "127.0.0.1") ||( !$_SERVER['SERVER_ADDR'] ))  $debug_tmp=0; else $debug_tmp=1; 
$nomessage = 0;  // 0= flag to indicate wether to end a message or not

$serverremotehostx ='';
$serverremoteaddr = $_SERVER['REMOTE_ADDR'];  
$debughostinfo = "remote host=".$serverremotehostx ." | remote ip= ". $serverremoteaddr;

$databasehost = $DB_HOST;
$databaseusername =$DB_USERNAME;  
$databasepassword =$DB_PASSWORD;  

$databasename = $DB_NAME;  //cads = classified adds. 
$dbItemsTable = $DB_PREFIX.$DB_TABLE_ITEMS ; 
$dbCatsTable = $DB_PREFIX.$DB_TABLE_CATS; 
$dbUsersTable = $DB_PREFIX.$DB_TABLE_USERS; 
$dbStatsTable = $DB_PREFIX.$DB_TABLE_STATS; 
$dbLogsTable = $DB_PREFIX.$DB_TABLE_LOGS; 
$dbPaymentsTable = $DB_PREFIX.$DB_TABLE_PAYMENTS;
$dbBannersTable = $DB_PREFIX.$DB_TABLE_BANNERS;

$fullfqdn = $DOMAIN_FQDN; 

$dbThisTable=""; 

if ($debug_tmp==1) {
// debug output file 
  $debugoutputfile = "debugoutput.htm"; // only if save=1
  $debugfile = fopen($debugoutputfile,"a"); if(!$debugfile) { echo "Error writing to the output file.\n";}
  
  $debugoutputfilehtml = "debugoutput.html"; // only if save=1
  $debugfilehtml = fopen($debugoutputfilehtml,"a");if(!$debugfilehtml) { echo "Error writing to the output file.\n";}

} 


//  --- open socket to MySQL database
$con = mysql_connect ($databasehost,$databaseusername, $databasepassword)or die();
mysql_select_db ( $databasename ) or die();

mysql_query("SET NAMES 'utf8'");

$message = "";
$success=false; 
$what = ""; 

$banner_en = true; 


$action='list'; 

/* -------------------- MAIN PROCESSING PART -------------------*/
if ($banner_en && !$isPageAdmin) {
  $noresulttosend =false;
  
  $dbThisTable = $dbBannersTable;

  $action = "list"; // default action

  // multipurpose variables  
  $msg=""; 
  $filter=""; 
  $sql_sort="";
  $sqlerror='';
  $datalist = Array ();
  

// get the banners @zads4.1
  if ($ENABLE_BANNER_ADSENSE){
    //$banner_adsense_src_1= urlencode(file_get_contents('./vars/banner1.txt'));
    $banner_adsense_src_1= base64_encode(file_get_contents('vars/banner1.txt'));
    $banner_adsense_pos_1= $BANNER_ADSENSE_POS_1; 
    $banner_adsense_src_2= base64_encode(file_get_contents('vars/banner2.txt'));
    $banner_adsense_pos_2= $BANNER_ADSENSE_POS_2; 


    // construct the banner specific query
    // query all banners list which are ACTIVE (status=40) & curent-date is valid 
    // and different from _news_ or _alert_ as this will be managed by AJAX side 
    // return the content + url + id + position 
   
    $join=""; 
    $filter = " WHERE `$dbThisTable`.`status` IN ('40','45')"; // published
    $filter .= " AND   ( `$dbThisTable`.`position` NOT LIKE  'news_%' ) "; // not a news
    $filter .= " AND   ( `$dbThisTable`.`position` NOT LIKE  'alert%' ) "; // not a news
    $filter .= " AND   ( NOW() BETWEEN `$dbThisTable`.`startdate` AND  `$dbThisTable`.`enddate` )  "; // publicehd

    $sql_sort=" ORDER BY `$dbThisTable`.`position` , RAND()";
    $sql_limit =""; 
    $sql_group ="";

    $queryban = "SELECT `$dbThisTable`.`id`,`$dbThisTable`.`htmlcode`,`$dbThisTable`.`position`,`$dbThisTable`.`clicktrackingurl` FROM `$dbThisTable` ".$join .$filter." ". $sql_sort . " " . $sql_group . " " .$sql_limit  ; 
    $result = @mysql_query($queryban);

    $totnbrofresults = @mysql_num_rows($result);
    if (($totnbrofresults) && ($totnbrofresults !=0)){
      $idx=0;
      $outdata=""; 
      // first item is generic
      $bannerlist = Array ();
      $idx=0;

      // just extract the fisrt elements of each type 
      $firsttimeposition=true; 
      $prevposition=""; 
      $displayit=false; 

      while ($row = mysql_fetch_object($result)) { 

        // check if it is the first one 
        if ($firsttimeposition) { $prevposition = $row->position; $firsttimeposition=false; $displayit=true;}
        else if ($row->position != $prevposition) {$displayit=true; }
        else $displayit=false; 
        $prevposition = $row->position; 

        if (!$ismobile && strstr($row->position, 'mob_')) $displayit=false; 

        // save only the fisrt one of each type ! 
        if ($displayit) {
          $outdata = Array (
                'htmlcode' => stripslashes($row->htmlcode),
                'clicktrackingurl'=>stripslashes($row->clicktrackingurl),
                'id'=> $row->id,
                'position'=> $row->position 
              );
         $bannerlist[$idx] = $outdata; 
         $idx+=1; 
        }
      }
     } else {
     $bannerlist = Array ();
    }
  }

  // here is the list of banners 

  //var_dump($bannerlist);


 $thebanners = Array ();

  // check which one to display finaly in each zone : 
 if (count($bannerlist)>0){
      foreach($bannerlist as $b){

        // --- allocate to right variables
        $thebanners[$b['position']] =  $b;
        //var_dump($thebanners[$b['position']]);
       
        // --- update impressions  --- 
        $id=$b['id'];
        $query = "UPDATE `".$dbThisTable."` SET   
            `impressions` = `impressions`+1
            WHERE ((`id` = '".$id."')) ";
        $result = mysql_query($query);  

      }
 }

}

 function display_banner($thiselem){
    if ($thiselem){ 
       if ($thiselem['clicktrackingurl'])
        $thisbannercontent = '<a class="bannerwithclick" name="clicktracker" rel="'.$thiselem['id'].'" target="_blank" href="'.$thiselem['clicktrackingurl'].'" alt="banner">'.base64_decode($thiselem['htmlcode']).'</a>'; 
      else 
        $thisbannercontent = base64_decode($thiselem['htmlcode']); 
      echo  $thisbannercontent; 
     
    }
    
  };

  function has_banner($thiselem){
    if ($thiselem){ 
      return "sectbanner"; 
    }
    else return "";
  };




?>