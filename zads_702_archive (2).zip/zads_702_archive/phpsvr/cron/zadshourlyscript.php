
<?php   

require_once("../multitenants_settings.php"); 
require_once("../".$SETTINGS_PATH."settings.php"); 


// get anc ckecksecurity key token=KEY ni GET paramaters
// we don't use HTTP basic auth becausenot supported by all conjob programs
// for testing reasons, we bypass the ones
if ($CRON_TOKEN){
  $ok=false; 
  if ($_SERVER['REMOTE_ADDR'] == $_SERVER['SERVER_ADDR'] ) $ok=true; 
  if (isset($_GET["token"]) && $_GET["token"]==$CRON_TOKEN) $ok=true;
  if (!$ok ) die('wrong TOKEN');
}

//pre-checks set timeout
function_exists('curl_version') or die('CURL support required');

if (array_search('set_time_limit', explode(',', ini_get('disable_functions'))) === false) {
 @set_time_limit(30);
}

/*------------------------------- HOURLY SCIPT (or less)------------------------------*/

$callstr = $DOMAIN_FQDN.'phpsvr/tmp1.php';
// $callstr = 'tmp1.php'; 
$ch = curl_init($callstr);

// curl_setopt($ch, CURLOPT_HTTPHEADER, array( 'Expect:', 'X-API-Key: '.$CRON_TOKEN));


echo "calling  $callstr\r";
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "batch=hourly");
curl_setopt($ch, CURLOPT_USERAGENT, "CURL");
$ref_url = $DOMAIN_FQDN;    
curl_setopt($ch, CURLOPT_REFERER, $ref_url);
$apiresponse = curl_exec($ch);
curl_close($ch);


// display the result  
echo $apiresponse;

?>

