<?php
/******************************************************************************
* * ZADS MULTITENNANTS SETTINGS variables
*
* Note :  VERY IMPORTANT FILE - DO NOT DELETE IT
*
* @category   Settings
* @package    ZADS
* @author     Patrice COHAUT <patrice.cohaut@gmail.com>
* @copyright  2014 PATMISC
* @version    6.1
******************************************************************************/

/* Disable direct access.*/
// if(!strcasecmp(basename($_SERVER['SCRIPT_NAME']),basename(__FILE__)))
// die('ZADS- Direct Access to this file not allowed!');

/* multitenant management */
// $SETTINGS_PATH="settings_wanna/";
$SETTINGS_PATH="";

// defautl value
if ($SETTINGS_PATH=="") $SETTINGS_PATH="settings/";

?>
