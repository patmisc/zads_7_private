<?php
/******************************************************************************
 * ZADS Secondary Server Script managing file upload & image manipulations
 * 
 * Note :  works with SETTINGS.PHP
 *  
 * @category   CorePackage
 * @package    ZADS
 * @author     Patrice COHAUT <patrice.cohaut@gmail.com>
 * @copyright  2010-2015 PATMISC
 * @version    6.8.0
 ******************************************************************************/


/* Disable direct access.*/
// if(!strcasecmp(basename($_SERVER['SCRIPT_NAME']),basename(__FILE__))) 
// die('ZADS- Direct Access to this file not allowed!');

require_once("multitenants_settings.php"); 
require_once($SETTINGS_PATH."db_settings.php");  
require_once($SETTINGS_PATH."settings.php");
// set default timezone 
date_default_timezone_set('Europe/Paris');

/* force to report all errors */
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING | E_DEPRECATED));
ini_set("display_errors", 1); 

$debug ="";
$debug_tmp = 0 ; // 0= server 1=local
$debugtrail=""; 

//force a debug based on settings file Zads5.0
if ($ENABLE_DEBUG_MODE) $debug_tmp=1; 
$debug_level = ($DEBUG_LEVEL) ? $DEBUG_LEVEL : 7 ;

// if ( $_SERVER['SERVER_ADDR'] != "127.0.0.1") $debug_tmp=0; else $debug_tmp=1; 
$nomessage = 0;  // 0= flag to indicate wether to end a message or not
$debugoutputfile = "debugoutput.htm"; // only if save=1

if ($debug_tmp==1) {
  $debugfile = fopen($debugoutputfile,"a"); if(!$debugfile) { echo "Error writing to the output file.\n";}
  logfile('', '[tmp 2] --------------------------------------', __LINE__); // start a new call of file 
  // Report all errors except E_NOTICE  and WARNINGS
  error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);
} else {
  // Report simple running errors
  error_reporting(E_ERROR |  E_PARSE | E_DEPRECATED);
}



$message = "";
$success=false; 
$what = ""; 
$action="";

//  ---- processing part for cads --------------------------
// Where the file is going to be placed 
$target_path_DEF = '../uploads/'; 
$target_path_from_root_DEF ="./uploads/";  

// *** DEPRECATED ***
// $dest_path = '../uploads/img/'; 
// $dest_path_FILE = '../uploads/files/'; 

if ($FILES_MANAGER_DIR) { 
  $dest_path_RESSOURCES = ".".$FILES_MANAGER_DIR;
  $target_path_from_root_RESSOURCES = $FILES_MANAGER_DIR;
} else {
  $dest_path_RESSOURCES = '../uploads/files/'; 
  $target_path_from_root_RESSOURCES = './uploads/files/'; 
}

$allowedextensions = array("jpeg", "jpg", "gif", "png", "JPEG", "GIF", "PNG", "JPG");
$allowedextensions_RESSOURCES = array("jpeg", "jpg", "gif", "png", "JPEG", "GIF", "PNG", "JPG","ICO","ico","SWF","swf","css", "CSS","js", "JS","PHP", "php","HTM", "htm");
$allowedextensions_RESSOURCES_SYSTEM = array("ICO","ico","SWF","swf","css", "CSS","js", "JS","PHP", "php","HTM", "htm");
$allowedextensions_AUDIO = explode("|", $AUDIO_FILE_EXT); 
$allowedextensions_VIDEO = explode("|", $VIDEO_FILE_EXT); 
$allowedextensions_DOC = explode("|", $DOC_FILE_EXT); 


//  ---- frce download of the file --------------------------
if (isset($_GET["forcedownload"])) {

  // filedata = urlobj.filename+"|"+urlobj.basename+"|"+urlobj.filesize;
  $filedataAr = $_GET['filedata'];$filedataAr=explode( '|', $filedataAr); 
  $genuineFileName = $filedataAr[1];
  $filesize =  $filedataAr[2];
  $filename =  $filedataAr[0];

  $filenameurl1 = "../uploads/".$filename; 
  $filenameurl2 = "../uploads/img/".$filename; 
  if (file_exists($filenameurl1))  $where="draft"; 
  else if (file_exists($filenameurl2)) $where="published"; 
  else { $where=false; echo "error with  $filenameurl1 or $filenameurl2 "; var_dump($filedataAr); exit; } 


  if ($where) {

    if ($where=="draft") $finalfilename = $filenameurl1; 
    else $finalfilename = $filenameurl2; 

    switch(strrchr($filename, ".")) {

      case ".gz": $type = "application/x-gzip"; break;
      case ".tgz": $type = "application/x-gzip"; break;
      case ".zip": $type = "application/zip"; break;
      case ".pdf": $type = "application/pdf"; break;
      case ".png": $type = "image/png"; break;
      case ".gif": $type = "image/gif"; break;
      case ".jpg": $type = "image/jpeg"; break;
      case ".txt": $type = "text/plain"; break;
      case ".htm": $type = "text/html"; break;
      case ".html": $type = "text/html"; break;
      default: $type = "application/octet-stream"; break;

    }

    header("Content-disposition: attachment; filename=$genuineFileName"); 
    header("Content-Type: application/force-download"); 
    header("Content-Transfer-Encoding: $type\n"); // Surtout ne pas enlever le \n
    header("Content-Length: ".filesize($finalfilename)); 
    header("Pragma: no-cache"); 
    header("Cache-Control: must-revalidate, post-check=0, pre-check=0, public"); 
    header("Expires: 0"); 
    readfile($finalfilename); 


    // header('Content-Description: File Transfer');
    // header('Content-Type: application/octet-stream');
    // header('Content-Disposition: attachment; filename='.$finalfilename);
    // header('Expires: 0');
    // header('Cache-Control: must-revalidate');
    // header('Pragma: public');
    // header('Content-Length: ' . $filesize);
    // readfile($finalfilename);
    exit;
}




}


//  ---- processing the test action  : test=watermark --------------------------
if (isset($_POST["testtmp2"])) { 

  //   // check that ADMIN person only 
    $SECRETPASS="b3bcffd15748055a"; 
    $secret = $_POST["secret"];  
    if (!session_is_admin() &&  !$secret==$SECRETPASS)  { 
      $rep=array( 'success' => false, 'message' => "This operation is not authorized !") ; 
      echo json_encode($rep) ; die ;
    }


  //   //process the variables
    $action = "testtmp2"; 
    $what = $_POST["testtmp2"];

    //  ---- ase of test=watermark --------------------------
    if ($what=="watermark"){
      if ($WATERMARK_FILE_URL){
        $watermark =$WATERMARK_FILE_URL; 
      } else {
        if ($WATERMARK_FREE_TEXT); 
          $text2img_res= text_2_image($WATERMARK_FREE_TEXT, '../uploads/files/text_watermark.png', false, 12); 
          $watermark =  $text2img_res['savedurl'] ; $has_watermak=true; 
      }
      $sourcePathOfTestImage= "../img/donotdeletepicture.jpg"; 
      $destPathOfTestImage =  "../uploads/testwatermark.jpg"; 
      $out_res= add_watermark($sourcePathOfTestImage, $watermark, $destPathOfTestImage, strtolower($WATERMARK_POS) ); 


      $rep=array( 'success' => true, 'action' => $action, 'what' => $what, 'message' => "", 'data' => $out_res) ; 
      echo json_encode($rep) ; die ;
  }
}

//  ---- processing the action  --------------------------
if (!empty($_FILES) || isset($_POST["action"]) ) {

  //Z6.5.5
  // if its an action=save with datauri inside the call, then datas are "inline"  and not in the FILE object 
  if (isset($_POST["action"])) {
      $is_ajax_inlinedata=true; 
      $action = $_POST["action"];
      if ($action=="") die('action NULL received - cheating ?'); // SECURITY protectio
      $datauri = (isset($_POST["datauri"])) ?  $_POST["datauri"] : ""; 
  }
  else $is_ajax_inlinedata=false;

  // get the type of file = NAMEof it(filename, avatarimg, bannerimg,..audiourl,...)
  $ftype = (isset($_POST["type"])) ?  $_POST["type"] : "file"; // type of file helping for the naming and also redim function
  if (strpos($ftype,"audio")!== false) $is_audio=true; else $is_audio=false; 
  if (strpos($ftype,"video")!== false) $is_video=true; else $is_video=false; 
  if (strpos($ftype,"doc")!== false) $is_doc=true; else $is_doc=false; 

  //Z720 -> can force a destination directory 'files' for example 
  $dest = (isset($_POST["dest"])) ?  $_POST["dest"] : "";
  if ($dest=="files") $ftype="ressources"; // force to be ressources

  //@Z5.1 - change destination if it's a ressource file 
  if ($ftype=="ressources" || $ftype=="banimgurl" ){
    $target_path_DEF = $dest_path_RESSOURCES;
    $target_path_from_root_DEF = $target_path_from_root_RESSOURCES;
    $allowedextensions = $allowedextensions_RESSOURCES;

    // protection, must be ba admin to do that
    if (!session_is_admin()) { 
      $rep=array( 'success' => false, 'message' => "This operation is not authorized !") ; 
      echo json_encode($rep) ; die ;
    } 
  }

  // Define file size limit in Bytes
  if ($MAX_PIC_SIZE) $limit_size=$MAX_PIC_SIZE; else $limit_size=500000;

  //Z6.5.0 - audio files pocessing 
  // special patch for audio files
  if ($is_audio){
    $allowedextensions =  $allowedextensions_AUDIO ;
    $limit_size =$AUDIO_FILE_MAX_SIZE ;
  }

  if ($is_video){
    $allowedextensions =  $allowedextensions_VIDEO ;
    $limit_size =$VIDEO_FILE_MAX_SIZE ;
  }

  if ($is_doc){
    $allowedextensions =  $allowedextensions_DOC ;
    $limit_size =$DOC_FILE_MAX_SIZE ;
  }


  // delete all files from upload rep. with tand older than xx (in seconds)
  if ($ftype!="ressources" && $ftype!="banimgurl" ){
    deleteFiles( $target_path_DEF, "" , "432000" ); // 5 days
  }


  //Z6.5.5
  if ($is_ajax_inlinedata) {
    // analyse the content and decode the payload   
    list($rftype, $datauri) = explode(';', $datauri);
    list(, $extension) = explode('/', $rftype);
    list(, $datauri)      = explode(',', $datauri);
    //var_dump($datauri);
    $datauri = str_replace(' ','+',$datauri); // essential if data is derived from Canvas.toDataURL()
    $datauri = base64_decode($datauri);
    $bname  = $_POST["name"] ; 
    $filesizex=strlen($datauri); 
    $sftype = $_POST["subtype"] ; 
  } else {
    // notmal case with files 
    $pathinfo_file = pathinfo($_FILES['uploadedfile']['name']);
    $bname=basename( $_FILES['uploadedfile']['name']);
    // $extension =  $pathinfo_file['extension']; 
    $extension =  strtolower($pathinfo_file['extension']); // important
    $filesizex = $_FILES['uploadedfile']['size']; 
  }

  $debugtrail.="-> extension is $extension, name=$bname, type=$ftype,size = $filesizex ";

  //Z6.5.5 - check for systéme files (files=ressources where the name must not be changed and thumbnail is a defautl con) 
  if (($ftype=="ressources" || $ftype=="banimgurl") && in_array($extension, $allowedextensions_RESSOURCES_SYSTEM)) {
    $is_file_sys=true; 
    $debugtrail.="-> this is a SYS file";
  } else $is_file_sys=false; 
  

  $what = "fileupload"; 
 
  // --- DEFINITIONS 
  // tn= general thumbnail 
  // tn2 = alternative size thumbnail for PINTEREST eg.
  // tnx= resized file when AUTO-RESIZE option is SET 
  if (!$is_file_sys) {
    //werename the file 
    $destname = "tmp_".date("Ymd-His").".".$extension;
    $tn_destname = "tn_tmp_".date("Ymd-His").".".$extension;
    $tnx_destname = "tmp_".date("Ymd-His").".".$extension;
    $tn2_destname = "tn2_tmp_".date("Ymd-His").".".$extension;

    $target_path = $target_path_DEF . basename( $destname); 
    $target_path_from_root = $target_path_from_root_DEF. basename( $destname); 
    $tn_target_path = $target_path_DEF . basename( $tn_destname); 
    $tnx_target_path = $target_path_DEF . basename( $tnx_destname); 
    $tn2_target_path = $target_path_DEF . basename( $tn2_destname); 
    $tn_target_path_from_root = $target_path_from_root_DEF. basename( $tn_destname);


  } else {
    // we don't rename the file 
    $destname = $bname ;
    $lextension = strtolower($extension); 
    $tn_destname = $lextension.".png";

    $tn_IMG_target_path_DEF = '../img/fileicons/'; 
    $tn_IMG_target_path_from_root_DEF ="./img/fileicons/";

    $target_path = $target_path_DEF . basename( $destname); 
    $target_path_from_root = $target_path_from_root_DEF. basename( $destname); 
    $tn_target_path = $tn_IMG_target_path_DEF . basename( $tn_destname); 
    $tn_target_path_from_root = $tn_IMG_target_path_from_root_DEF. basename( $tn_destname);

    // force max size
    if ($FILES_MANAGER_MAX_SIZE) $limit_size=$FILES_MANAGER_MAX_SIZE;

  }
 
  /*
  $new_w = 80; 
  $new_h= 60; 
  */
  
  /* define default size for the thumbnail creation */ 
  /* 
  example of Google Adsense Banner size  
  Leaderboard (728 x 90)  Banner (468 x 60) Half Banner (234x60) 
  Button (125x125) Skyscraper (120x600) Small Rectangle (180x150) ...
  --
  example of pinterest dim size 
  image width = 192 px
  --
  example photos d'identité 
  La photo doit mesurer 35mm x 45mm.  : en 150 dpi -> 207x266px
  */
  $sftype_name_blob = array("filename","filename","filename");

  $new_w = 200; $new_h= 200;// default values
  if (($ftype=="file") || ($ftype=="filename") || ($ftype=="pics")|| ($ftype=="folioimg") || ($ftype=="pictureblob" && in_array($sftype,$sftype_name_blob)) ) 
    { $new_w = 150; $new_h= 112; }
  if ($ftype=="avatarimg" || ($ftype=="pictureblob" && $sftype=="avatarimg"))
    { $new_w = 125; $new_h= 160; } // same as ID card photo
  if ($ftype=="probannerimg")
    { $new_w = 300; $new_h=37 ; } // leaderboard adapted for mobile sites

  // debug info
  $debugtrail.="->ext = $extension vs - allowed = $allowedextensions";
  $debugtrail.=", size = $filesizex vs $limit_size";

  // important notice:
  // when upload file size is higher than the SYSTEM post_max_size , then $_FILE input is empty (extension and Size)
  // post_max_size can only be changed into php.ini or .htaccess files
  // typical htaccess directives
  // php_value upload_max_filesize 20M
  // php_value post_max_size 20M
  // php_value max_execution_time 200
  // php_value max_input_time 200

  if (!(in_array($extension, $allowedextensions))) {
      $message.=  "Not the right file extension.";
  } else if ($filesizex>$limit_size){ 
      $message.=  "file size exceed limit.";
  } else 
  {  

    // copy the file in the right place 
    if ($is_ajax_inlinedata){
      $copyfileresult = file_put_contents($target_path, $datauri);
    } else {
      $copyfileresult = move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path); 
    }

    // continue 
      if($copyfileresult) {
          $message.=  "The file ".  $bname. " has been uploaded";
          $message.=  "- size = ". $filesizex;
          $fileurl = $target_path_from_root;
          $success=true; 
          $addWattermarkLater=false;


          // resize first if defined  --> create a resized image 672px width 
          if ($AUTO_PICS_RESIZE && !$is_audio && !$is_video && !$is_file_sys  && !$is_doc){
            if (($ftype=="file") || ($ftype=="filename") || ($ftype=="pics") ){
              $newx_w = 672; $newx_h= 500; // resize on bet of the two dim

              $debugtrail.="-> AUTO_PICS_RESIZE : ";
              createthumb($target_path,$tnx_target_path,$newx_w,$newx_h, 'adjust-two-dim');

              // override image to use it as a default one 
              $destname =  $tnx_destname ;
              $fileurl = $target_path_from_root_DEF. basename( $destname); // superseed size 
              $target_path = $tnx_target_path ; 
            } 
          }


          // add wattermark on main image before thumbs are created 
          if ($WATERMARK_EN){
            $has_watermak=false;
            if ($WATERMARK_FILE_URL){
              $watermark =$WATERMARK_FILE_URL; 
              $has_watermak=true; 
            } else {
              if ($WATERMARK_FREE_TEXT) {
                $text2img_res= text_2_image($WATERMARK_FREE_TEXT, '../uploads/files/text_watermark.png', false, 12); 
                $watermark =  $text2img_res['savedurl'] ; $has_watermak=true; 
              }
            }

            if ($has_watermak && $ftype!="ressources" && $ftype!="banimgurl" && $ftype!="avatarimg" && $ftype!="probannerimg" && $ftype!="pictureblob")
              if ($extension!="png") {
                $water_res= add_watermark($target_path, $watermark, $target_path ,strtolower($WATERMARK_POS) ); 
              } else $addWattermarkLater=true; 
          }



          // create the FIRST thumb 
          if (!$is_audio && !$is_video && !$is_file_sys && !$is_doc){
            $debugtrail.="-> CREATE-FIRST-THUMB : ";
            createthumb($target_path,$tn_target_path,$new_w,$new_h);
          }

          $tn_fileurl = $tn_target_path_from_root;


          // create a SECOND thumb for pinterest and other sites
          if (($ftype=="file") || ($ftype=="filename") || ($ftype=="pics") || ($ftype=="avatarimg")){
             $new2_w = 190; $new2_h= 0; // resize on 1 dimension only 
             if (!$is_audio) {
              $debugtrail.="-> CREATE-SECOND-THUMB : ";
              createthumb($target_path,$tn2_target_path,$new2_w,$new2_h);
             }
          } 
                    

          if ($addWattermarkLater){
            $debugtrail.="-> ADD-WATTERMARK : ";
            $water_res= add_watermark($target_path, $watermark, $target_path ,strtolower($WATERMARK_POS) );
          } 

      } else{
        if ($is_ajax_inlinedata){
           $success=false;  $message=_("Unable to save the file");
        }
        else {
          $message.=  "There was an error uploading the file, please try again!";
          $message.= $_FILES['uploadedfile']['tmp_name'];
          $message.= "--> to = $target_path";
          $message.=  "- error = ". file_upload_error_message($_FILES['uploadedfile']['error']); 
        }
      }
  }

  $json = array(
                'success' => $success,
                'message' => $message,
                'what' => $what,
                'action' => $action,
                'type' => $_POST["type"],
                'ftype' => $ftype,
                'sftype' => $sftype,
                'dest' => $dest,
                'lid'=>$_POST["lid"], 
                'data' =>  Array (
                          'fileurl'=> $fileurl,
                          'tnfileurl'=> $tn_fileurl,
                          'filename'=> basename( $destname), 
                          'basename'=> $bname, 
                          'filesize'=>$filesizex,
                          'ext'=>$extension

                          )
              );

  if ( $debug_tmp==1){
      $json['debug'] = Array(
        'debugtrail'=> $debugtrail,
        'debug'=> $_FILES['uploadedfile']['tmp_name'],
        'key1' => $_POST['example_key1'], 
        'watermark'=>$water_res,
        'text2img_res'=>$text2img_res,
        '_FILES'=>$_FILES,
        '_POST' => $_POST,
        'limit size'=>$limit_size,
        '_post_max_size'=>ini_get('post_max_size'),
        'is_file_sys'=>$is_file_sys,
        'version'=>"704-001"  
      );

      logfile('debug', 'debug trail  = '.$debugtrail); 

  }
      

      $agent=strtoupper($_SERVER['HTTP_USER_AGENT']);
      $isIE=(strpos($agent,'MSIE')!==false || strpos($agent,'TRIDENT')!==false);
      if (!$isIE) header('Content-Type: application/json');
      echo json_encode($json);
}
else   {

    $json = array(
                'success' => false,
                'message' => 'Something wrong appends .. sorry'
              );

     if ( $debug_tmp==1){
      $json['debug'] = Array(
        'debugtrail'=> $debugtrail,
        'debug'=> $_FILES['uploadedfile']['tmp_name'],
        'key1' => $_POST['example_key1'], 
        'watermark'=>$water_res,
        'text2img_res'=>$text2img_res,
        '_FILES'=>$_FILES,
        '_POST' => $_POST,
        'limit size'=>$limit_size,
        '_post_max_size'=>ini_get('post_max_size'),
        'is_file_sys'=>$is_file_sys 
      );

      logfile('error', 'debug trail  = '.$debugtrail); 
    }

    $agent=strtoupper($_SERVER['HTTP_USER_AGENT']);
    $isIE=(strpos($agent,'MSIE')!==false || strpos($agent,'TRIDENT')!==false);
    if (!$isIE) header('Content-Type: application/json');
    echo json_encode($json);
}
// testthumbgenerator(); 



function earlyExit($message){

  global $debug_tmp;
  global $debugtrail;  

   $json = array(
                'success' => false,
                'message' => $message
              );

    $agent=strtoupper($_SERVER['HTTP_USER_AGENT']);
    $isIE=(strpos($agent,'MSIE')!==false || strpos($agent,'TRIDENT')!==false);
    if (!$isIE) header('Content-Type: application/json');
    echo json_encode($json);
    
    if ( $debug_tmp==1){
      logfile('error', 'early exit  = '.$message); 
      logfile('error', 'debug trail  = '.$debugtrail); 
    }


    die ;


}


// *********** test generator of tumbnais  ************
function testthumbgenerator(){
  // default
  $new_w = 80; 
  $new_h= 60;

  // for pictures (standard format)
  $new_w = 150; $new_h= 112;

  $pics=directory('../uploads/oldsite/','jpg,JPG,JPEG,jpeg,png,PNG,GIF,gif');
  $cnt=0; 
  //$pics=ditchtn($pics,'tn_');
  if ($pics[0]!='')
  {
    $cnt+=1; 
    if ($cnt < 10){
  	 foreach ($pics as $p)
  	 {
      //echo "------ processing file : $p  : \n<br/>";
      createthumb('../uploads/oldsite/'.$p,'../uploads/oldsite/tn_'.$p,$new_w,$new_h);
  	 }
    } else return false ; // quit the function
  }
}

// ----------------------------------------------------------------------------
// create thumbnail 
// ----------------------------------------------------------------------------
function createthumb($name,$filename,$new_w,$new_h,$mode){
  
  global $debugtrail; 

  //Sometimes if the .jpg image got small errors inside (you cannot see that), all transparent pixels turn to black color.Try to use:
  ini_set('gd.jpeg_ignore_warning', 1);
  
  
  // determine the mode of resampling  : 
  // mode="resample"  : take the new width & height and re-center the image 
  // mode ="adjust-one-dim" : adjust 1 dimension based on given elements 
  
  if (!$mode){
    if (($new_w!=0) && ($new_h !=0)) $mode =  "resample"; 
    else $mode =  "adjust-one-dim"; 
  }
  
  $debugtrail.=" | inCreateThumb > mode = $mode"; 
  $debugtrail.=", from  $name  to  $filename"; 
  
	// create the Image object from the file 
  $system=explode('.',$name);
  $ext = $system[3]; 
  $ext_lower =  strtolower($ext); 
  $debugtrail.=", ext=$ext"; 

  $info = getimagesize($name);
  $debugtrail.=", getimagesize =   ";
  if($info === false) $debugtrail.=" - this image is not a valid image  ";
  else $debugtrail.=" - ".$info['mime']." - $info[2] - $info[3] "; 


  // patch image ytpe which are not coherent with real images type 
  $x_ext = $ext ; 
  if ($info['mime']=="image/gif") {
    $x_ext="gif"; $debugtrail.=", swapping to gif extension";
  }
  
	if (preg_match('/jpg|jpeg|JPEG|JPG/',$x_ext)){
		$src_img=imagecreatefromjpeg($name);
    $debugtrail.=", jpeg image detected ";

    if (!$src_img)  {
      $debugtrail.=", ERROR Failed to load jpeg image ";
      earlyExit("Corrupted JPG format, please save this image in another format"); 
    }

	}
	if (preg_match('/png|PNG/',$x_ext)){
		$src_img=imagecreatefrompng($name);
    $debugtrail.=", png image detected"; 
	}
	if (preg_match('/gif|GIF/',$x_ext)){
		$src_img=imagecreatefromgif($name);
    $debugtrail.=", gif image detected"; 
	}
	$debugtrail.=", result = $src_img ";

	// calculate the dimensions based on existing image dimensions
  $old_x=imageSX($src_img);
  $old_y=imageSY($src_img);
  $debugtrail.=", old size initial = ($old_x - $old_y) | ";

  //echo "------------- old size = $old_x, $old_y  \n<br/>";
  if ($mode =="adjust-one-dim"){
  
    if ($new_w > $new_h) { // if dimention using the width 
      $thumb_w=$new_w;
      $thumb_h=$old_y*($new_w/$old_x);
    }
    
    if ($new_h > $new_w) { // if dimention using the height 
      $thumb_h=$new_h;
      $thumb_w=$old_x*($new_h/$old_y);
    }
    $src_x=0; $src_y=0;
     
     
  }

  if ($mode =="adjust-two-dim"){

      if ($old_x > $old_y) { // horizontal image 
        $thumb_w=$new_w;
        $thumb_h=$old_y*($new_w/$old_x);
      }
      if ($old_x < $old_y) { // vertical image
        $thumb_w=$old_x*($new_h/$old_y);
        $thumb_h=$new_h;

        // patch to resize on max. on n'utiliser que la largeur et on patch
        $thumb_w=$old_x*($new_w/$old_y);
        $thumb_h=$new_w;

      }
      if ($old_x == $old_y) {
        $thumb_w=$new_w;
        $thumb_h=$new_h;
      }
      
      $src_x=0; $src_y=0;
  }

  if ($mode =="resample"){
    if (($old_x/$old_y) > ($new_w/$new_h)){
      $src_x= ($old_x-($old_y*($new_w/$new_h)))/2; 
      $src_y=0; 
      $old_x = ($old_y*($new_w/$new_h)); 
      
    } else {
      $src_y= ($old_y-($old_x*($new_h/$new_w)))/2; 
      $src_x=0; 
      $old_y=($old_x*($new_h/$new_w)); 
    }
  
    //force resample to be exact size 
    $thumb_w=$new_w;
    $thumb_h=$new_h;
  }
  
   $debugtrail.=", old size after treatment = ($old_x - $old_y)";
   $debugtrail.=", src x and y = $src_x- $src_y";
   $debugtrail.=", new size = ($thumb_w - $thumb_h)";

  // create the image thumbnail
  $dst_img=ImageCreateTrueColor($thumb_w,$thumb_h);



  // pos treatment for Transparent PNG 
  switch ($ext_lower)
  {
  case "png":
      // // integer representation of the color black (rgb: 0,0,0)
      // $background = imagecolorallocate($dst_img, 255, 255, 255);
      // // removing the black from the placeholder
      // imagecolortransparent($dst_img, $background);

      // // turning off alpha blending (to ensure alpha channel information is preserved, rather than removed (blending with the rest of the image in the form of black))
      // imagealphablending($dst_img, false);

      // // turning on alpha channel information saving (to ensure the full range of transparency is preserved)
      // imagesavealpha($dst_img, true);

      // imagealphablending($dst_img, FALSE);
      // imagesavealpha($dst_img, TRUE);

      // -- SOLUTION 3
      // fill new image with white 
      // $bg = imagecolorallocate($dst_img, 255, 255, 255);
      // imagefill($dst_img, 0, 0, $bg);
      // imagecopy($white, $trans, 0, 0, 0, 0, $w, $h);
      // imagecopy($dst_img,$src_img,0,0,$src_x,$src_y,$thumb_w,$thumb_h,$old_x,$old_y); 

      // -- SOLUTION 4
      // imagealphablending($dst_img, false);
      // imagesavealpha($dst_img, true); 
      
      // $transparent = imagecolorallocatealpha($dst_img, 255, 255, 255, 127);
      // imagefilledrectangle($dst_img, 0, 0, $thumb_w, $thumb_h, $transparent);

      // -- SOLUTION 5
      // imagealphablending($dst_img, false);
      // imagesavealpha($dst_img, true);


      // -- SOLUTION 6
            // integer representation of the color black (rgb: 0,0,0)

        $background = imagecolorallocate($dst_img, 255, 255, 255);
 
        // removing the black from the placeholder
        imagecolortransparent($dst_img, $background);
 
        // turning off alpha blending (to ensure alpha channel information 
        // is preserved, rather than removed (blending with the rest of the 
        // image in the form of black))
        imagealphablending($dst_img, false);
 
        // turning on alpha channel information saving (to ensure the full range 
        // of transparency is preserved)
        imagesavealpha($dst_img, true);


      break;
  // case "gif":
  //     // integer representation of the color black (rgb: 0,0,0)
  //     $background = imagecolorallocate($dst_img,  255, 255, 255);
  //     // removing the black from the placeholder
  //     imagecolortransparent($dst_img, $background);
  //     break;
  }

  // if ($ext_lower !="png")
	imagecopyresampled($dst_img,$src_img,0,0,$src_x,$src_y,$thumb_w,$thumb_h,$old_x,$old_y); 
  // imagecopy($dst_img,$src_img,0,0,$src_x,$src_y,$thumb_w,$thumb_h,$old_x,$old_y); 
  
  //create the PNG image
    if (preg_match("/png|PNG/",$ext))
    {
  	 $result = imagepng($dst_img,$filename,1);
     $debugtrail.=", png image generated "; 
    } 
    else if (preg_match("/jpg|jpeg|JPEG|JPG/",$ext)){
     $result = imagejpeg($dst_img,$filename); 
     $debugtrail.=", jpg image generated "; 
    }
    else  if (preg_match('/gif|GIF/',$ext)){
      $result = imagegif($dst_img,$filename);
      $debugtrail.=", gif image generated "; 
    }
    else {
      $debugtrail.=", ERROR no extensions match imagecreation ";
      earlyExit("ERROR no extensions match imagecreation"); 
    }
    imagedestroy($dst_img); 

  $debugtrail.="|"; 
  return $result; 
}




function imagetranstowhite($trans) {
    // Create a new true color image with the same size
    $w = imagesx($trans);
    $h = imagesy($trans);
    $white = imagecreatetruecolor($w, $h);
 
    // Fill the new image with white background
    $bg = imagecolorallocate($white, 255, 255, 255);
    imagefill($white, 0, 0, $bg);
 
    // Copy original transparent image onto the new image
    imagecopy($white, $trans, 0, 0, 0, 0, $w, $h);
    return $white;
}



 function add_watermark($source, $watermark_in,  $save, $watermark_pos=null, $width = null, $height = null) {

        $r_error='';

        $watermark = @imagecreatefrompng($watermark_in)
            or $r_error.="Impossible d'ouvrir le fichier ($watermark).";
        imageAlphaBlending($watermark, false);
        imageSaveAlpha($watermark, true);
 

        $imageString = @file_get_contents($source)
            or $r_error.="Impossible d'ouvrir le fichier ($source).";
        $image = @imagecreatefromstring($imageString)
            or $r_error.="Format de fichier ($source) inconnu.";
        // imageAlphaBlending($image, false);
        // imageSaveAlpha($image, true);

        $imageWidth = imageSX($image);
        $imageHeight = imageSY($image);
 
        if (!($width)) {
            $watermarkWidth = imageSX($watermark);
        } else {
            $watermarkWidth = $width;
        }
 
        if (!($height)) {
            $watermarkHeight = imageSY($watermark);
        } else {
            $watermarkHeight = $height;
        }
 

        // manage the position of the water
        if ($watermark_pos=="bottomleft"){
          $coordinateX = 5;
          $coordinateY = ($imageHeight - 5) - ($watermarkHeight);
        } 
        else if ($watermark_pos=="topright") {
          $coordinateX = ($imageWidth - 5) - ($watermarkWidth);
          $coordinateY = 5;
        }
        else if ($watermark_pos=="topleft") {
          $coordinateX = 5;
          $coordinateY = 5;
        }
        else if (!$watermark_pos || $watermark_pos=="bottomright"){
          $coordinateX = ($imageWidth - 5) - ($watermarkWidth);
          $coordinateY = ($imageHeight - 5) - ($watermarkHeight);
        } 

        $r_copy = imagecopy($image, $watermark, $coordinateX, $coordinateY, 0, 0, $watermarkWidth, $watermarkHeight);
        // $r_copy = imagecopymerge($image, $watermark, $coordinateX, $coordinateY, 0, 0, $watermarkWidth, $watermarkHeight, 0);


        $system=explode('.',$save);
        $ext = $system[count($system)-1]; 
        $ext =  strtolower($ext); 

        //create the PNG image
        if (preg_match("/png/",$ext))
        {
          $r_save = imagepng($image,$save,1); ; // was previously 0 
          // convertPNGto8bitPNG($save, $save);
        } 
        if (preg_match("/jpg/",$ext)){
         $r_save = imagejpeg($image,$save); 
        }
        else {
         $r_save = imagegif($image,$save); 
        }

        imagedestroy($image);
        imagedestroy($watermark);


        return array(
          'r_error' => $r_error,
          'r_save' =>$r_save,
          'r_copy'=> $r_copy, 
          'save_out'=>$save,
          'water_in'=>$watermark_in,
          'pos'=>$watermark_pos
        );

    }


    function convertPNGto8bitPNG($sourcePath, $destPath) {
      $srcimage = imagecreatefrompng($sourcePath);
      list($width, $height) = getimagesize($sourcePath);
      $img = imagecreatetruecolor($width, $height);
      $bga = imagecolorallocatealpha($img, 0, 0, 0, 127);
      imagecolortransparent($img, $bga);
      imagefill($img, 0, 0, $bga);
      imagecopy($img, $srcimage, 0, 0, 0, 0, $width, $height);
      imagetruecolortopalette($img, false, 255);
      imagesavealpha($img, true);
      imagepng($img, $destPath);
      imagedestroy($img);
    }



/**
* This function convert a text tring into an image file 
* @param string $text_in =  the text to convert 
* @param string $save =  the url where to save the file. if NULL, the image will be displayed directly  
* @param string $transparentbg =  boolean to indicate if we whant a transparent cbackground color or white color 
* @return nothing if save is NULL otherwise an Array with result and saved URL
*/
  function text_2_image($text_in, $save=null, $transparentbg=null, $font_size=null){

    // some variables to set
    if ($font_size) $font=$font_size;
    else $font  = 4;
    
    $width  = ImageFontWidth($font) * strlen($text_in);
    $height = ImageFontHeight($font);
    $r_error=''; 

    // get outputextension
    $url_pieces=explode('.',$save);
    $ext = $url_pieces[count($url_pieces)-1]; 
    $ext =  strtolower($ext); 

    // lets begin by creating an image
    $im = @imagecreatetruecolor($width,$height)
    or $r_error.="text-2-image : impossible to create true color image with $text_in";

    if ($transparentbg) {
      // add the transparent background
      imagealphablending($im, false); 
      imagesavealpha($img, true);
      $trans_colour = imagecolorallocatealpha($img, 0, 0, 0, 127);
      imagecolortransparent($im, $trans_colour); // VERY IMPORTANT !!!! 
      imagefill($img, 0, 0, $trans_colour);

      $ext='png' ;// force extension to be png 
      $url_pieces[count($url_pieces)-1]=$ext;
      $save = implode('.', $url_pieces); 

      $text_color = imagecolorallocate($im, 1, 1, 1); // not totaly black otherwise is indide transperenttest ! 

    } else {
      $white_background = imagecolorallocate($im, 255, 255, 255);
      imagefill($im, 0, 0, $white_background);

      //black text
      $text_color = imagecolorallocate($im, 0, 0, 0);
    }

    $r_imgstring = imagestring($im, $font, 0, 0,  $text_in, $text_color);

    
    // save it or send back directly the result 
    if ($save){
      if ($ext=="png") imagepng($im,$save);
      if ($ext=="jpg" || !$ext) imagejpeg($im,$save); 

         return array(
            'r_error'=>$r_error, 
            'savedurl'=>$save
          );
     } else {
        header ("Content-type: image/png");
        imagepng($im);
     }


    }


/*
        Function directory($directory,$filters)
        reads the content of $directory, takes the files that apply to $filter 
		and returns an array of the filenames.
        You can specify which files to read, for example
        $files = directory(".","jpg,gif");
                gets all jpg and gif files in this directory.
        $files = directory(".","all");
                gets all files.
*/
function directory($dir,$filters)
{
	$handle=opendir($dir);
	$files=array();
	if ($filters == "all"){while(($file = readdir($handle))!==false){$files[] = $file;}}
	if ($filters != "all")
	{
		$filters=explode(",",$filters);
		while (($file = readdir($handle))!==false)
		{
			for ($f=0;$f<sizeof($filters);$f++):
				$system=explode(".",$file);
				if ($system[1] == $filters[$f]){$files[] = $file;}
			endfor;
		}
	}
	closedir($handle);
	return $files;
}

// ----------------------------------------------------------------------------
// manage error messages when uploading files 
// ----------------------------------------------------------------------------
function file_upload_error_message($error_code) {
    switch ($error_code) { 
        case UPLOAD_ERR_INI_SIZE: 
            return 'The uploaded file exceeds the upload_max_filesize directive in php.ini'; 
        case UPLOAD_ERR_FORM_SIZE: 
            return 'The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form'; 
        case UPLOAD_ERR_PARTIAL: 
            return 'The uploaded file was only partially uploaded'; 
        case UPLOAD_ERR_NO_FILE: 
            return 'No file was uploaded'; 
        case UPLOAD_ERR_NO_TMP_DIR: 
            return 'Missing a temporary folder'; 
        case UPLOAD_ERR_CANT_WRITE: 
            return 'Failed to write file to disk'; 
        case UPLOAD_ERR_EXTENSION: 
            return 'File upload stopped by extension'; 
        default: 
            return 'Unknown upload error - pat'; 
    } 
} 

// ----------------------------------------------------------------------------
// deleteFiles
// ----------------------------------------------------------------------------
function deleteFiles($dossier_traite , $extension_choisie, $age_requis)
{
  //on ouvre le dossier
  $repertoire = opendir($dossier_traite);
  
  //on lance notre boucle qui lira les fichiers un par un
  while(false !== ($fichier = readdir($repertoire)))
  {
  //on met le chemin du fichier dans une variable simple
  $chemin = $dossier_traite."/".$fichier;
          
  //les variables qui contiennent toutes les infos nécessaires
  $infos = pathinfo($chemin);
  $extension = $infos['extension'];

  $age_fichier = time() - filemtime($chemin);
          
  //on n'oublie pas LA condition sous peine d'avoir quelques surprises :p
          //if($fichier!="." AND $fichier!=".." AND !is_dir($fichier) AND $extension == $extension_choisie AND $age_fichier > $age_requis)
          if($fichier!="." AND $fichier!=".." AND !is_dir($fichier)  AND $age_fichier > $age_requis)          {
          unlink($chemin);
          }
  }
  closedir($repertoire); //on ferme !
}


function session_is_admin(){
  $curuser_is_admin=false;
  session_name("ZADSSESID"); 
  if ($_COOKIE["ZADSSESID"] !="") { // detect if a session is set . session_id does not give the result
    session_start();
    if (isset($_SESSION['user_type'])) {
      $curuser_type = $_SESSION['user_type']+0; 
      if ($curuser_type==9) $curuser_is_admin=true;
    }
  }
  return $curuser_is_admin;
}


/**-----------------------------------------------------------------------------
* This function log an event into TEXT file(s)
*-----------------------------------------------------------------------------*/
function logfile($status, $msg, $line=null){

  // status per SYSLOG definition 
  // PANIC (0) | ALERT (1) | CRTI (2) | ERROR (3) | WARNING (4) | NOTICE (5) | INFO (6) | DEBUG (7)
  $debug_matrix =  array (
      "PANIC" => 0, "ALERT" => 1, "CRTI" => 2, "ERROR" => 3, "WARNING" => 4, "NOTICE" => 5, "INFO" => 6, "DEBUG" => 7
      );

  global $debug_tmp; 
  global $debug_level;
  global $debugfile; 

  // $debug_level="7";

  $style =""; $disp_status=""; 

  $_SEPARATOR=" - "; // separator 

  if ($debug_tmp==1) {

    if ($status=="") $status="DEBUG"; 
    if (strtolower($status)=="error" || strtolower($status)=="notice" || strtolower($status)=="warning") 
      $style="color:red;";

    $hm = "<div>"; 
    $hm .= "<span class='date' style='font-size:0.8em;'>".date('Y-m-d H:i:s',time()).'</span>'; 
    $hm .= $_SEPARATOR; 
    $hm .= '<span class="" style="'.$style.'">'. strtoupper($status).'</span>'; 
    $hm .= $_SEPARATOR; 
    if ($line) {
      $hm .= '<span class="" style="">'. strtoupper($line).'</span>'; 
      $hm .= $_SEPARATOR; 
    }
    //$hm .= strtolower($msg);
    $hm .= $msg;
    $hm .= "</div>"; 

    // final write to file if level if higher
    if ( $debug_matrix[strtoupper($status)]  <= intval($debug_level)) { 
      fwrite($debugfile,$hm);
    } 
  }
  return true; 
}


?>
