<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <title></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    </head>
    <body>
        <?php


        // if(!strcasecmp(basename($_SERVER['SCRIPT_NAME']),basename(__FILE__))) 
        // die('ZADS- Direct Access to this file not allowed!');

        // include class
        require_once('inc/SitemapGenerator.php');

        // include settings file
        // require_once("settings/db_settings.php");  
        require_once("multitenants_settings.php"); 
        require_once($SETTINGS_PATH."db_settings.php");  
        // require_once($SETTINGS_PATH."settings.php");
        require_once("init_settings.php"); 
        require_once("localization.php");



        function format_url_for_seo($in){

            $out=$in;
            $out = strtolower(utf8_decode(stripslashes($in)));
            //$out = strtolower(stripslashes($in));
            $out = mb_convert_encoding($out, "UTF-8");

            // $out = strtr($out, "éèêàç", "eeeac");
            // replace é and è and ê by e
            $out = str_replace("é","e", $out);
            $out = str_replace("è","e", $out);
            $out = str_replace('ê','e', $out);
            $out = str_replace('à','a', $out);
            $out = str_replace('ç','c', $out);
            //$out = strtolower(utf8_decode(stripslashes($out)));

            // replace space and other chars with '-'
            $out = preg_replace("![^a-z0-9]+!i", "-", $out);
            return $out; 
        }; 


        // set default timezone 
        date_default_timezone_set('Europe/Paris');

        $debug ="";
        $debug_tmp = 0 ; // 0= server 1=local
        if (( $_SERVER['SERVER_ADDR'] != "127.0.0.1") ||( !$_SERVER['SERVER_ADDR'] ))  
            $debug_tmp=0; else $debug_tmp=1; 
        $nomessage = 0;  // 0= flag to indicate wether to end a message or not

        $serverremotehostx ='';
        $serverremoteaddr = $_SERVER['REMOTE_ADDR'];  
        $debughostinfo = "remote host=".$serverremotehostx ." | remote ip= ". $serverremoteaddr;

        $databasehost = $DB_HOST;
        $databaseusername =$DB_USERNAME;  
        $databasepassword =$DB_PASSWORD;  
        $databasename = $DB_NAME;  //cads = classified adds. 
        $dbItemsTable = $DB_PREFIX.$DB_TABLE_ITEMS ; 
        $dbCatsTable = $DB_PREFIX.$DB_TABLE_CATS; 
        $dbUsersTable = $DB_PREFIX.$DB_TABLE_USERS; 
        $dbStatsTable = $DB_PREFIX.$DB_TABLE_STATS; 
        $dbLogsTable = $DB_PREFIX.$DB_TABLE_LOGS; 
        $dbPaymentsTable = $DB_PREFIX.$DB_TABLE_PAYMENTS;
        $dbBannersTable = $DB_PREFIX.$DB_TABLE_BANNERS;

        //  --- open socket to MySQL database
        $con = mysql_connect ($databasehost,$databaseusername, $databasepassword)or die();
        mysql_select_db ( $databasename ) or die();

        mysql_query("SET NAMES 'utf8'");

        $message = "";
        $success=false; 
        $what = ""; 
        $dbThisTable="";
        $fullfqdn = $DOMAIN_FQDN; 


        // create object

        echo ('Welcome to ZADS.FR sitemap generator  ! <br>'); 

        $sitemap = new SitemapGenerator( $fullfqdn, '../');

        
        // --- part 1 : add the Main NaV 
        $nav = Array ('home', 'sell', 'buy', 'shops'); 
        if (!$DISABLE_ZETVU &&  $SEO_INCLUDE_ZETVU)  $nav = Array ('home', 'sell', 'buy', 'shops', 'zetevu');

            // already within a UL part , so display only the LI parts
        foreach ( $nav as $key => $value) {
            $link = $ESCF.$trans[$cust_lang_long][$value];
            $sitemap->addUrl($DOMAIN_FQDN.$link,  date('c'),  'daily',    '1');
        }


        // --- part 2 : add the list of categories 

        $dbThisTable = $dbCatsTable; 
        $filter = " WHERE `$dbThisTable`.`status` IN ('40','45', '46')"; // published
        $sql_sort=" ORDER by  `$dbThisTable`.`title` DESC ";
        $sql_limit =""; 
        $sql_group ="";

        $query = "SELECT `$dbThisTable`.`title`, `$dbThisTable`.`id`, `$dbThisTable`.`description`
                  FROM `$dbThisTable` ".$join .$filter." ". $sql_sort . " " . $sql_group . " " .$sql_limit  ; 
        // make the real query 
        $result = @mysql_query($query);

        // add to sitemap 
        while ($row = mysql_fetch_object($result)) {
           $link = $ESCF.$trans[$cust_lang_long]['cat'].'/'.$row->id.'/'.format_url_for_seo($row->title);

            $sitemap->addUrl($DOMAIN_FQDN.$link,  date('c'),  'daily',    '0.5');
        }

        // --- part 3 : add the list of adds (fisrt top 100 ! )

        $dbThisTable = $dbItemsTable; 
        $filter = " WHERE `$dbThisTable`.`status` IN ('40','45', '46') AND  `$dbThisTable`.`type`  NOT LIKE  'zetvu' "; // published
        $sql_sort=" ORDER by  `$dbThisTable`.`moddate` DESC ";
        $sql_limit =" LIMIT 0, 300"; 
        $sql_group ="";

        $query = "SELECT `$dbThisTable`.`title`, `$dbThisTable`.`id`, `$dbThisTable`.`description`
                  FROM `$dbThisTable` ".$join .$filter." ". $sql_sort . " " . $sql_group . " " .$sql_limit  ; 
        // make the real query 
        $result = mysql_query($query);
        // add to sitemap 
        while ($row = mysql_fetch_object($result)) {
           $link = $ESCF.$trans[$cust_lang_long]['ad'].'/'.$row->id.'/'.format_url_for_seo($row->title);
           $sitemap->addUrl($DOMAIN_FQDN.$link,  date('c'),  'daily',    '0.8');
        }


        // --- part 4 : add the list of published users 

        $dbThisTable = $dbUsersTable; 
        $filter = " WHERE `$dbThisTable`.`status` IN ('40','45', '46') AND `$dbThisTable`.`protype` IN ('pro','pub')"; // published
        $sql_sort=" ORDER by  `$dbThisTable`.`moddate` DESC ";
        $sql_limit =" LIMIT 0, 100"; 
        $sql_group ="";

        $query = "SELECT `$dbThisTable`.`procpny`, `$dbThisTable`.`id`, `$dbThisTable`.`bio`
                  FROM `$dbThisTable` ".$join .$filter." ". $sql_sort . " " . $sql_group . " " .$sql_limit  ; 
        // make the real query 
        $result = mysql_query($query);

        // add to sitemap 
        while ($row = mysql_fetch_object($result)) {
           $link = $ESCF.$trans[$cust_lang_long]['user'].'/'.$row->id.'/'.format_url_for_seo($row->procpny);
            $sitemap->addUrl($DOMAIN_FQDN.$link,  date('c'),  'daily',    '0.8');
        }

        // --- part 5 : add the list of zetvu/news 
        if (!$DISABLE_ZETVU && $SEO_INCLUDE_ZETVU && ($ZETVU_VISIBLE_ACL=="0" || $ZETVU_VISIBLE_ACL==0)) {

            $dbThisTable = $dbItemsTable; 
            $filter = " WHERE `$dbThisTable`.`status` IN ('40','45', '46') AND  `$dbThisTable`.`type` = 'zetvu' "; // published
            $sql_sort=" ORDER by  `$dbThisTable`.`moddate` DESC ";
            $sql_limit =" LIMIT 0, 20"; 
            $sql_group ="";

            $query = "SELECT `$dbThisTable`.`title`, `$dbThisTable`.`id`, `$dbThisTable`.`description`
                      FROM `$dbThisTable` ".$join .$filter." ". $sql_sort . " " . $sql_group . " " .$sql_limit  ; 
            // make the real query 
            $result = mysql_query($query);
            // add to sitemap 
            while ($row = mysql_fetch_object($result)) {
               // get zetevu label
               if  ($ZETVU_AS_NEWS) $zetevuLabel = $trans[$cust_lang_long]['news'];
               else if  ($ZETVU_AS_VIDEO_TUTO) $zetevuLabel = $trans[$cust_lang_long]['videos'];
               else $zetevuLabel = $trans[$cust_lang_long]['zetevu'];

               // publich the links
               $link = $ESCF.$zetevuLabel.'/'.$row->id.'/'.format_url_for_seo($row->title);
               $sitemap->addUrl($DOMAIN_FQDN.$link,  date('c'),  'daily',    '0.8');
            }

        }


        // --- part 6 : add the link to footer links 

        // low footer

        if ($cust_tandc_url) $sitemap->addUrl($cust_tandc_url,  date('c'),  'monthly',    '0.3');
        if ($cust_pub_url) $sitemap->addUrl($cust_pub_url,  date('c'),  'monthly',    '0.3');
        if ($cust_aboutus_url) $sitemap->addUrl($cust_aboutus_url,  date('c'),  'monthly',    '0.3');
        if ($cust_faq_url) $sitemap->addUrl($cust_faq_url,  date('c'),  'monthly',    '0.3');
        if ($cust_demo_url) $sitemap->addUrl($cust_demo_url,  date('c'),  'monthly',    '0.3');
        if ($cust_help_url) $sitemap->addUrl($cust_help_url,  date('c'),  'monthly',    '0.3');

    
        // create sitemap
        $sitemap->createSitemap();
        echo ('... sitemap created <br>'); 

        // write sitemap as file
        $sitemap->writeSitemap();
        echo ('... sitemap written <br>'); 

        // update robots.txt file
        //$sitemap->updateRobots();

        // submit sitemaps to search engines
        echo ('... sending sitemap to search engines<br>'); 
        $res=$sitemap->submitSitemap();

        foreach($res as $engine) {
            echo '<br> ---------- '; 
            foreach($engine as $key => $value){ 
                echo "<br> $key = $value"; 
            }
          }

        echo ('<br>------ BRAVO - finished <br>'); 

        ?>
    </body>
</html>