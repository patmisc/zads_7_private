<?php


// ############# SERVLET FOR BANNERS REQUESTS  ###########################

if (isset($_POST["coms"]) ) {

  // general variables
  $now= date( 'Y-m-d H:i:s', time());
  $dest_path_from_root_user ='./uploads/user/';

  $coms = $_POST["coms"] ;
  $action = "list"; // default action
  $action = $coms; 
  $dbThisTable = $dbComsTable; 

  $type = secure_var($_POST["type"]) ; if (!isset($_POST["type"])) $type="review"; 
  

  $status = secure_var($_POST["forceflag"]) ;
  
  /* check if user has the right to do so if ok , continue ,  else, page is exited with a special message*/
  $user_details = check_userRights("coms", $action); 
  
  // identify selector
  $what = secure_var($_POST["what"]) ;            // SECURITY 
  $laction = secure_var($_POST["laction"]) ;      // SECURITY 
  $id = $_POST["id"]+0 ; 

        //   `id` int(11) NOT NULL AUTO_INCREMENT,
        // `moddate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
        // `createdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',

        // `type` varchar(10) NOT NULL DEFAULT 'review',
        // `status` varchar(2) NOT NULL,
        // `hits` int(10) NOT NULL DEFAULT '0',
        // `likes` int(10) NOT NULL DEFAULT '0',
        // `title` varchar(255) DEFAULT NULL,
        // `description` varchar(1000) DEFAULT NULL,

        // `comid` varchar(32) NOT NULL,  
        // `fromid` int(11) NOT NULL DEFAULT '0',
        // `toid` varchar(32) NOT NULL DEFAULT '0',
        // `replyid` int(11) NOT NULL DEFAULT '0',
        // `fromusername` varchar(30) NOT NULL,
        // `fromemail` varchar(40) NOT NULL,

        // `fromip` INT(11) UNSIGNED,
        // `toip` INT(11) UNSIGNED,

        // `abuse` varchar(2) NOT NULL,

        // `rating1` FLOAT default 0,
        // `rating2` FLOAT default 0,
        // `rating3` FLOAT default 0,

  // content
  // TYPE : can be "REVIEW || COMMENT || CONVERSATION || QUESTION "

  $description = secure_var($_POST["description"]) ; 
  $title = secure_var($_POST["title"]) ; 
  $adid = $_POST["adid"]+0 ;
  $fromid = $_POST["fromid"]+0 ; 

  // to id can be an integer of a 
  $toid = (isset($_POST["toid"])) ?  $_POST["toid"] : '0' ;
  
  $rating1 = (isset($_POST["rating1"])) ?  $_POST["rating1"]*1 : 0 ;
  $rating2 = (isset($_POST["rating2"])) ?  $_POST["rating2"]*1 : 0 ;
  $rating3 = (isset($_POST["rating3"])) ?  $_POST["rating3"]*1 : 0 ;

  // IP address are stored as INTEGERS for a better performance and check 
  // var_dump(ip2long('209.85.227.147'));
  // var_dump(long2ip(3512066963));
  $fromip =ip2long($_SERVER['REMOTE_ADDR']);
  $toip=0; // we don't know it  ! 

  $nav=$_POST["nav"];  
  $sort=$_POST["sort"];
  $sortoriginal = $sort;
  $sort=explode("_",$sort); 
  $sort_dir = $sort[1];
  $sort_by = $sort[0];
  

  //common
  $curuserid = $_POST["curuserid"]+0 ; // SECURED 
  $userid = $_POST["userid"]+0 ; // SECURED 

  // filter
  $faction = $_POST["faction"] ;
  $fseverity = $_POST["fseverity"] ;
  $fwhat = trim(secure_var($_POST["fwhat"]));
  $search=trim(secure_var($_POST["search"])); // SECURITY 
  $ftime=trim(secure_var($_POST["ftime"])); // SECURED 
  $fuserid = $_POST["fuserid"]+0 ; // SECURED 
  $fadid = $_POST["fadid"]+0 ; // SECURED 
  $fstatus = secure_var($_POST["fstatus"]) ; 
  $ftype = secure_var($_POST["ftype"]) ; 

  // indicate this is an inline display area for a given ID   
  $inlinefor =  $_POST["inlinefor"]+0 ; // SECURED 
  if ($action=="load" && $fadid) $inlinefor=$fadid; 

  $msg=""; 
  $filter=""; 
  $sql_sort="";
  $success=false; 
  $view_mode ='';

  $maxresults=1; 


  $noQuery= false; 

  //----- LIST action -----------------------------
  if ($action=="list" || $action=="load"){

    // other filter / sort and actions
    if (isset($_POST["page"]))$paged = $_POST["page"]+0; else  $paged =1;  

    if (isset($_POST["eppage"])) $eppage =$_POST["eppage"]*1; else  {
      if ($action=="load") $eppage=$COMS_MAX_DISPLAYED; 
      else $eppage=50;
    } 

    // sorting option 
    if ($sort_by) {
      if ($sort_by=="date") $xsort_by="moddate"; else $xsort_by=$sort_by ;   
      $sql_sort ="  ORDER BY `$dbThisTable`.`".$xsort_by."` ".$sort_dir;
    }
    else $sql_sort.=" ORDER BY `$dbThisTable`.`moddate` DESC ";  
    
    if ($id && $id>0) {
      $filter.="  WHERE `$dbThisTable`.`id` = '$id' ";
      $limit=" LIMIT 0, 30 "; // no limit on the request
    } else {
      $itemstart = ((int)$paged -1) * $eppage; 
      if ($eppage) $limit = "LIMIT ".$itemstart.", $eppage"; // set a limit if different from zero 
    } 
    
    // search condition
    if ($search)  {
      $f_stub =" ( (`$dbThisTable`.`whatid` = '".$search."') OR (`$dbThisTable`.`description` like  '%".$search."%') ) ";
      $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
    }

    // filter per AD ID 
    if (($fadid)) {
      $f_stub = " `$dbThisTable`.`whatid` =  '$fadid' AND `$dbThisTable`.`what` =  '$what'";
      $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
    
      // check is owner   
      // if (!$curuser_is_admin) {
      //   $query_owner = "SELECT `userid` FROM `$dbItemsTable` WHERE `id`='$fadid' AND `userid`='$curuserid' "; 
      //   $result_owner = @mysql_query($query_owner);
      //   if ($result_owner && mysql_num_rows($result_owner)) 
      //     { $curuser_is_owner=true; } 
      //   else logfile('error', 'error in coms/list/check owver  '.mysql_error());
      // }
    }

    // filter per type
    if ($ftype){
      $f_stub = " `$dbThisTable`.`type` =  '$ftype' ";
      $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
    }

    // view mode 
    if ($curuser_is_admin || $curuser_is_owner) {
      $view_mode = 'extended';
    }  

    // // limite to current user id if not administrator
    // if (!$curuser_is_admin && $curuserid){
    //   $f_stub = " `$dbThisTable`.`userid` =  '$curuserid' ";
    //   $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
    // }

    // status filter   
    // apply a filter on status (only publiched is not admin or owner)  
    if ($view_mode!='extended'){
      $f_stub = " `$dbThisTable`.`status` =  '40' ";
      $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
    } else {
      $f_stub=""; 
      if ($fstatus=="20")  $f_stub = " `$dbThisTable`.`status` =  '20' ";
      if ($f_stub) $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
    }

    // multiple join elements from AD + USER + CATS
    $join = " LEFT OUTER JOIN `$dbUsersTable` ON `$dbThisTable`.`fromid`= `$dbUsersTable`.`id` ";
    $join .= " LEFT OUTER JOIN `$dbItemsTable` ON `$dbThisTable`.`whatid`= `$dbItemsTable`.`id` ";
    
    // make a pre-query to get total list of results 
    // get prequery for ratings
    $xtraFields="";
    if ($ftype=="review") {
          if ($COMS_RATING_VISUAL=="pnn") $ratingnbr = 3; else $ratingnbr=$COMS_RATING_NBR;
          for ($i = 1; $i <= $ratingnbr; $i++) {
            $xtraFields .= ", SUM(`$dbThisTable`.`rating$i`) AS 'sum_rating$i' ";
          }
    }
    // extra filtering to get only approved values 
    $f_stub = " `$dbThisTable`.`status` IN ('40','45','46')  ";
    if ($f_stub) $filterfull =($filter=="") ? $filter." WHERE $f_stub " : $filter." AND $f_stub "; 



    $queryfull = "SELECT COUNT(`$dbThisTable`.`id`) AS 'maxresults' $xtraFields FROM `$dbThisTable` "  .$filterfull;
    $resultfull = mysql_query($queryfull);
    $maxresults=0;
    if (!$resultfull ) logfile('error', 'error in bookings/list - tot results '.mysql_error());
    else  {
      $rowfull = mysql_fetch_object($resultfull);
      $maxresults =  $rowfull->maxresults;

      $counters=false;
      if ($ftype=="review" && $maxresults>0) {
        $counters=Array ();
        if ($COMS_RATING_VISUAL=="pnn") $ratingnbr = 3; else $ratingnbr=$COMS_RATING_NBR;
            for ($i = 1; $i <= $ratingnbr; $i++) {
              $index = "sum_rating$i";
              if ($COMS_RATING_VISUAL=="pnn") $counters[]=$rowfull->$index  ;
              else  $counters[]=$rowfull->$index / $maxresults ; 
            }
      }
    }
    
    //-- make the full query
    $query = "SELECT `$dbThisTable`.* ,`$dbUsersTable`.`username`,  `$dbUsersTable`.`protype`, `$dbUsersTable`.`avatarimg`, `$dbUsersTable`.`gender`,`$dbItemsTable`.`title` as adtitle FROM `$dbThisTable` ".$join .$filter." ". $sql_sort . " " . $limit ; 
    $result = mysql_query($query);
    $totnbrofresults = mysql_num_rows($result);
    if (!$result )logfile('error', 'error in coms/list '.mysql_error());

    $idx=0;


    if ($action=="load" && !$curuser_is_admin && !$curuser_is_owner)  $view_mode = 'short';


    if (($totnbrofresults) && ($totnbrofresults !=0)){
      $idx=0;
      $outdata=""; 
      // first item is generic
      $loglist = Array ();
      $idx=0; $lastupdate=''; 
      while ($row = mysql_fetch_object($result)) { 
        $thistate= explode("|",$row->desc); 
        $thistate = $thistate[0]; 
        $outdata = Array (
            'id' => $row->id ,
            'comid' => $row->comid ,
            'moddate'=>  $row->moddate,
            'title'=> $row->title,
            'description'=> $row->description,
            'fromid' => $row->fromid,
            'username' => $row->username,
            'gender' => $row->gender,
            'avatarimg' => $row->avatarimg ,
            'protype' => $row->protype ,
            'imgpath'=>($row->avatarimg) ? $dest_path_from_root_user:'',
            );
        // keep track of last update date
        if ($row->bo_moddate >  $lastupdate) $lastupdate=$row->bo_moddate;

        // add rating
        if ($ftype=="review") {
          // $outdata['rating1']=$row->rating1;
          if ($COMS_RATING_VISUAL=="pnn") $ratingnbr = 3; else $ratingnbr=$COMS_RATING_NBR;
          for ($i = 1; $i <= $ratingnbr; $i++) {
            $index = "rating$i";
            $outdata[$index]=$row->$index;
          }
        }

         // extended mode  
        if ($view_mode=="extended"){
            $outdata['whatid']=$row->whatid;
            $outdata['toid']=$row->toid;
            $outdata['status']=$row->status;
            $outdata['type']=$row->type;
            $outdata['abuse'] = $row->abuse;
            $outdata['what'] = $row->what;
        }


        if ($COMS_COMMENT_LIKES_EN){
          $outdata['likes']=$row->likes;
        }

       $loglist[$idx] = $outdata; 
       $idx+=1; 
      }
     } else {
      $loglist = Array ();
     }
    $success=true;
  }

 // ----------- LOG DELETION ----------------------
  else if ($action=='purgedeleted') {
    // must be adminonly
     // make the delete action 

    $filter = " WHERE ((`status` = '80'))" ; 
    if ($ftype){
      $f_stub = " `$dbThisTable`.`type` =  '$ftype' ";
      $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
    }

      $query = "DELETE FROM `".$dbThisTable."` $filter ";
      $result = @mysql_query($query);
      if (!$result)  { 
        $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
        logfile('error',$sqlerror);
        $msg = "Doh! Something happened : ".$sqlerror;
        $success=false;
      } else {
        $msg = "Yay! Everything went well!";
        $success=true;
      }
  }



  // ----------- LOG DELETION ----------------------
  else if ($action=='delete') {

    // make the delete action either on whole conversastion on on single id
    if (!$ftype) $ftype=$type; // done for response in JSON

      if (isset($_POST["comid"])) {
        $comid = $_POST["comid"]*1 ; 
        // $query = "DELETE FROM `".$dbThisTable."`  WHERE ((`comid` = '".$comid."')) ";
        $query = "UPDATE `".$dbThisTable."` SET   `moddate` = '".$now."', `status` = '80' WHERE ((`comid` = '".$comid."')) ";
      }
      else  
        // $query = "DELETE FROM `".$dbThisTable."`  WHERE ((`id` = '".$id."')) ";
        $query = "UPDATE `".$dbThisTable."` SET   `moddate` = '".$now."', `status` = '80' WHERE ((`id` = '".$id."')) ";
      
      $result = @mysql_query($query);
      if (!$result)  { 
        $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
        logfile('error',$sqlerror);
        $msg = "Doh! Something happened : ".$sqlerror;
        $success=false;
      } else {
        $msg = "Yay! Everything went well!";
        $success=true;
      }
    
  } 

  else if ($action=='trash') {
    // delete definitively the element 
    if (!$ftype) $ftype=$type; // done for response in JSON

      $filter = " WHERE ((`status` = '80'))" ; 
      if (isset($_POST["comid"])) {
        $comid = $_POST["comid"]*1 ; 
        $f_stub = " `$dbThisTable`.`comid` =  '$comid' ";
      } else $f_stub = " `$dbThisTable`.`id` =  '$id' ";
      $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub ";

      $query = "DELETE FROM `".$dbThisTable."` $filter ";
      $result = @mysql_query($query);
      if (!$result)  { 
        $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
        logfile('error',$sqlerror);
        $msg = "Doh! Something happened : ".$sqlerror;
        $success=false;
      } else {
        $msg = "Yay! Everything went well!";
        $success=true;
      }
    
  } 
  //----- CREATE/MODIFY/DELETE action -----------------------------
  else if (($action=="create") || ($action =="update") || ($action=="updatestatus") || ($action=="publish")|| ($action=="unpublish") || ($action=="abuse")
        || ($action=="like") || ($action=="dislike") ||  ($action=="resetlikes")
        || ($action=="reply")
    ){

    if (!$ftype) $ftype=$type; // done for response in JSON
    $updateCookie=false; 

    // -- BUILD THE QUERY 
    //---- CREATE action ----------------

    if (($action=="create")) { 
      // token  
      $comid = bin2hex(openssl_random_pseudo_bytes(16));

      // default status
      if(!$status) {
        if (($type=="comment" && $COMS_COMMENT_AUTO_APPROUVE) || ($type=="review" && $COMS_RATING_AUTO_APPROUVE))
          $status="40";
        else
          $status="20";  

        // control for review 
        if ($type=="review" && $COMS_RATING_MULTIVOTES_EN==false && !$curuser_is_admin){
          $toSearch = ";".$what.'='.$adid.";";
          if (isset($_COOKIE[$COOKIENAME."_VOTES"])) {
            // check if cookie value exist for this
            $cokVal=trim($_COOKIE[$COOKIENAME."_VOTES"]); 
            $found = strpos($cokVal,$toSearch) !== false ? true : false;
            if ($found) { $noQuery=true; $msg="Only one vote permitted";}
            else $updateCookie=$toSearch; 
          } 
          else $updateCookie=$toSearch;
        }


        // control for SELF RATING
         if ( $type=="review" && $COMS_RATING_SELF==false && !$curuser_is_admin 
              && $what=="user" &&  ($adid ==  $curuser_id ) ){
          $noQuery=true; $msg="Not authorized";
        }



      } 

      // protection 
      if ($description=="") $noQuery=true; 

        $query = "INSERT INTO `".$dbThisTable."` 
          ( `comid`, `createdate`, `moddate`,  `title`, `description`, `type`,`status`, `what`, `whatid`, `fromid`, `fromip`, `toid`, `toip`, `rating1`, `rating2`, `rating3`) ";
        $query .= "VALUES (  '$comid', '$now', '$now', '$title', '$description', '$type','$status', '$what', '$adid', '$fromid','$fromip','$toid','$toip', '$rating1', '$rating2', '$rating3');";       
      
      $ftype=$type;
      $id= mysql_insert_id(); 
      $fadid =$adid;
    }

    //---- UPDATE action ----------------
    if (($action=="update")){ 
      // token  

      // default status
      if(!$status) {
        if (($type=="comment" && $COMS_COMMENT_AUTO_APPROUVE) || ($type=="review" && $COMS_RATING_AUTO_APPROUVE))
          $status="40";
        else
          $status="20";  
      } 

      // protection 
      if ($description=="") $noQuery=true; 
            
        $query = "UPDATE `".$dbThisTable."` SET   
          `moddate` = '".$now."', 
          `title`='".$title."',
          `description`= '".$description."',
          `status`='".$status."',
          `rating1`='".$rating1."',
          `rating2`='".$rating2."',
          `rating3`='".$rating3."'
          WHERE ((`id` = '".$id."')) ";
        

        $ftype=$type;
        $fadid =$adid;
    }


    //updatestatus
    if ($action =="updatestatus"){
      $query = "UPDATE `".$dbThisTable."` SET   
        `moddate` = '".$now."', 
        `status` = '".$status."'
        WHERE ((`id` = '".$id."')) ";
    }

    // publish and unset ABUSE 
    if ($action =="publish"){
      $query = "UPDATE `".$dbThisTable."` SET   
        `moddate` = '".$now."', 
        `status` = '40' ,
        `abuse` = ''
        WHERE ((`id` = '".$id."')) ";
    }


    // remove from publishing 
    if ($action =="unpublish"){
      $query = "UPDATE `".$dbThisTable."` SET   
        `moddate` = '".$now."', 
        `status` = '60'
        WHERE ((`id` = '".$id."')) ";
    }

    if ($COMS_COMMENT_LIKES_EN){
      if ($action =="like"){
        $query = "UPDATE `".$dbThisTable."` SET   
          `moddate` = '".$now."', 
          `likes` = `likes`+1
          WHERE ((`id` = '".$id."')) ";
      }

      if ($action =="dislike" && $COMS_COMMENT_DISLIKE_EN){
          $query = "UPDATE `".$dbThisTable."` SET   
            `moddate` = '".$now."', 
            `likes` = `likes`-1
            WHERE ((`id` = '".$id."')) ";
      }

      if ($action =="resetlikes"){
        $query = "UPDATE `".$dbThisTable."` SET   
          `moddate` = '".$now."', 
          `likes` = 0
          WHERE ((`id` = '".$id."')) ";
      }

    }

    // remove automatically from publishing 
    if ($action =="abuse"){
      $ftype=$type;
      $xtra= ($COMS_ABUSE_UNPUBLISH_AUTOSET) ?  "  `status` = '60', " : "";
      $query = "UPDATE `".$dbThisTable."` SET   
        `moddate` = '".$now."', $xtra
        `abuse` = '1'
        WHERE ((`id` = '".$id."')) ";
    }

    // -- MAKE THE QUERY
    if ($noQuery){
      if (!$msg) $msg="invalid or missing inputs";
      $success=false; 
    }
    else 
    $result = mysql_query($query);  
          
    
    // -- OUTPUT RESULTS 
    $sqlerror=""; 
    if (!$result) {
      $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
      logfile('error',$sqlerror); 
    } else {
      $success=true; 

      if ($updateCookie) {
        $cookietxt=";"; // default value 
        if (isset($_COOKIE[$COOKIENAME."_VOTES"]))  $cookietxt=trim($_COOKIE[$COOKIENAME."_VOTES"]);
        $cookietxt=   $cookietxt.substr($updateCookie, 1);
        setcookie($COOKIENAME."_VOTES" ,$cookietxt , (time() + 31536000), '/');
      }

    }
  } // end of CREATE



    // -- output result ------------- 
    $json = array(
        'success' => $success,
        'totnb' =>$maxresults,
        'message'=> $msg,
        'action' => "coms",
        'subaction' => $action,
        'what' => $what,
        'nav'=>$nav,
        'sort'=>$sortoriginal,
        'paged' => $paged,
        'eppage'=>$eppage,
        'search'=>$search,
        'faction'=>$faction,
        'ftype'=>$ftype,
        'id' => $id,
        'comid' => $comid,
        'toid'=>$toid,
        'inlinefor'=>$inlinefor,
        'fadid' => $fadid,
        'counters'=>$counters,
        'data' => $loglist,
    );
  

 if ($debug_tmp==1){ // add debug info into the stream when working local
     $json["xdebug"]= array(
              'sqldebug'=> $query,
              'sqlfulldebug'=>$queryfull,
              'filter'=>$filter,
              'laction'=>$laction,
              'corefilter'=>$corefilter,
              'forceduserid'=>$forceduserid,
              'curuserid'=>$curuserid,
              'curuser_is_admin'=>$curuser_is_admin, 
              'curuser_is_owner'=>$curuser_is_owner, 
              'id'=>$id, 
              'cookietxt'=>$cookietxt,
              'cokVal'=>$cokVal,
              'userdetails'=>$user_details
              );  
   }

  // ob_start('ob_gzhandler');
  // echo json_encode($json);
  encode_json_and_send_with_compression($json); 
}

?>