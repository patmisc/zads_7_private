<?php
/******************************************************************************
 * ZADS Secondary Server Script managing file upload & image manipulations
 * 
 * Note :  works with SETTINGS.PHP
 *  
 * @category   CorePackage
 * @package    ZADS
 * @author     Patrice COHAUT <patrice.cohaut@gmail.com>
 * @copyright  2010-2012 PATMISC
 * @version    3.6
 ******************************************************************************/

/* Disable direct access.*/
if(!strcasecmp(basename($_SERVER['SCRIPT_NAME']),basename(__FILE__))) 
die('ZADS- Direct Access to this file not allowed!');


require_once("multitenants_settings.php"); 
require_once($SETTINGS_PATH."db_settings.php");  
require_once($SETTINGS_PATH."settings.php");
require_once("localization.php");  
require_once("functions.php");    



$debug ="";
$debug_tmp = 0 ; // 0= server 1=local
if ( $_SERVER['SERVER_ADDR'] != "127.0.0.1") $debug_tmp=0; else $debug_tmp=1; 
$nomessage = 0;  // 0= flag to indicate wether to end a message or not

if ($debug_tmp==1) { error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);
} else {error_reporting(E_ERROR |  E_PARSE);
}

$message = "";
$success=false; 
$what = ""; 
$action="";

//  ---- processing part for cads --------------------------
// Where the file is going to be placed 
$target_path_DEF = '../uploads/'; 
$dest_path = '../uploads/img/'; 
$dest_path_FILE = '../uploads/files/'; 
$target_path_from_root_DEF ="./uploads/";  

// Define file size limit in Bytes
//$limit_size=500000;
if ($MAX_PIC_SIZE) $limit_size=$MAX_PIC_SIZE; else $limit_size=500000;

if (isset($_FILES)){
  // delete all files from upload rep. with type jpg and older than xx (in seconds)
  deleteFiles( $target_path_DEF, "" , "180" );

  $pathinfo_file = pathinfo($_FILES['uploadedfile']['name']);
  $extension =  $pathinfo_file['extension']; 
  $filesizex = $_FILES['uploadedfile']['size']; 
  $allowedextensions = array("jpeg", "jpg", "gif", "png", "JPEG", "GIF", "PNG", "JPG");
  $what = "fileupload"; 
  
  $destname = "tmp_".date("Ymd-His").".".$extension;
  $target_path = $target_path_DEF . basename( $destname); 
  $target_path_from_root = $target_path_from_root_DEF. basename( $destname); 
  
  // path names for thumbnails
  $tn_destname = "tn_tmp_".date("Ymd-His").".".$extension;
  $tn_target_path = $target_path_DEF . basename( $tn_destname); 
  $tn_target_path_from_root = $target_path_from_root_DEF. basename( $tn_destname);
  /*
  $new_w = 80; 
  $new_h= 60; 
  */
  $new_w = 150; 
  $new_h= 112; 
  
  if (!(in_array($extension, $allowedextensions))) {
      $message.=  "Not the right file extension.";
  } else if ($filesizex>$limit_size){ 
      $message.=  "file size exceed limit.";
  } else 
  {          
      if(move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path)) {
          $message.=  "The file ".  basename( $_FILES['uploadedfile']['name']). " has been uploaded";
          $message.=  "- size = ". $_FILES['uploadedfile']['size'];
          $fileurl = $target_path_from_root;
          $success=true; 
          // create the thumbnail
          createthumb($target_path,$tn_target_path,$new_w,$new_h);
          $tn_fileurl = $tn_target_path_from_root;
      } else{
          $message.=  "There was an error uploading the file, please try again!";
          $message.=  "- error = ". file_upload_error_message($_FILES['uploadedfile']['error']); 
      }
  }
  $json = array(
                'success' => $success,
                'message' => $message,
                'what' => $what,
                'action' => $action,
                'data' =>  Array (
                          'fileurl'=> $fileurl,
                          'tnfileurl'=> $tn_fileurl,
                          'filename'=> basename( $destname), 
                          'basename'=> basename( $_FILES['uploadedfile']['name']), 
                          'filesize'=>$_FILES['uploadedfile']['size'],
                          'key1' => $_POST['example_key1'] )
              );
      echo json_encode($json);
}

//testthumbgenerator(); 

// *********** test generator of tumbnais  ************
function testthumbgenerator(){
  $new_w = 80; 
  $new_h= 60;
  $pics=directory('../uploads/img/','jpg,JPG,JPEG,jpeg,png,PNG,GIF,gif');
  //$pics=ditchtn($pics,'tn_');
  if ($pics[0]!='')
  {
  	foreach ($pics as $p)
  	{
      //echo "------ processing file : $p  : \n<br/>";
      createthumb('../uploads/img/'.$p,'../uploads/img/tn_'.$p,$new_w,$new_h);
  	}
  }
}


// ----------------------------------------------------------------------------
// create thumbnail 
// ----------------------------------------------------------------------------
function createthumb($name,$filename,$new_w,$new_h){
	// create the Image object from the file 
  $system=explode('.',$name);
  $ext = $system[3]; 
  
	if (preg_match('/jpg|jpeg|JPEG|JPG/',$ext)){
		$src_img=imagecreatefromjpeg($name);
	}
	if (preg_match('/png|PNG/',$ext)){
		$src_img=imagecreatefrompng($name);
	}
	if (preg_match('/gif|GIF/',$ext)){
		$src_img=imagecreatefromgif($name);
	}
	
	// calculate the dimensions based on existing image dimensions
  $old_x=imageSX($src_img);
  $old_y=imageSY($src_img);
  //echo "------------- old size = $old_x, $old_y  \n<br/>";
  /*
  if ($old_x > $old_y) {
  	$thumb_w=$new_w;
  	$thumb_h=$old_y*($new_h/$old_x);
  }
  if ($old_x < $old_y) {
  	$thumb_w=$old_x*($new_w/$old_y);
  	$thumb_h=$new_h;
  }
  if ($old_x == $old_y) {
  	$thumb_w=$new_w;
  	$thumb_h=$new_h;
  }
  */
  if (($old_x/$old_y) > ($new_w/$new_h)){
    $src_x= ($old_x-($old_y*($new_w/$new_h)))/2; 
    $src_y=0; 
    $old_x = ($old_y*($new_w/$new_h)); 
    
  } else {
    $src_y= ($old_y-($old_x*($new_h/$new_w)))/2; 
    $src_x=0; 
    $old_y=($old_x*($new_h/$new_w)); 
  }

  //force resample to be exact size 
  $thumb_w=$new_w;
  $thumb_h=$new_h;
  
  //echo "------------- old  size 2 = $old_x, $old_y  \n<br/>";
  //echo "------------- src x and y = $src_x, $src_y  \n<br/>";
  //echo "------------- new size = $thumb_w, $thumb_h  \n<br/>";

  
  // create the image thumbnail
  $dst_img=ImageCreateTrueColor($thumb_w,$thumb_h);
	imagecopyresampled($dst_img,$src_img,0,0,$src_x,$src_y,$thumb_w,$thumb_h,$old_x,$old_y); 

  //create the PNG image
    if (preg_match("/png/",$ext))
    {
  	 $result = imagepng($dst_img,$filename); 
    } 
    if (preg_match("/jpg/",$ext)){
     $result = imagejpeg($dst_img,$filename); 
    }
    else {
  	 $result = imagegif($dst_img,$filename); 
    }
      
    imagedestroy($dst_img); 
  //imagedestroy($src_img); 
  return $result; 
}




/*
        Function directory($directory,$filters)
        reads the content of $directory, takes the files that apply to $filter 
		and returns an array of the filenames.
        You can specify which files to read, for example
        $files = directory(".","jpg,gif");
                gets all jpg and gif files in this directory.
        $files = directory(".","all");
                gets all files.
*/
function directory($dir,$filters)
{
	$handle=opendir($dir);
	$files=array();
	if ($filters == "all"){while(($file = readdir($handle))!==false){$files[] = $file;}}
	if ($filters != "all")
	{
		$filters=explode(",",$filters);
		while (($file = readdir($handle))!==false)
		{
			for ($f=0;$f<sizeof($filters);$f++):
				$system=explode(".",$file);
				if ($system[1] == $filters[$f]){$files[] = $file;}
			endfor;
		}
	}
	closedir($handle);
	return $files;
}

// ----------------------------------------------------------------------------
// manage error messages when uploading files 
// ----------------------------------------------------------------------------
function file_upload_error_message($error_code) {
    switch ($error_code) { 
        case UPLOAD_ERR_INI_SIZE: 
            return 'The uploaded file exceeds the upload_max_filesize directive in php.ini'; 
        case UPLOAD_ERR_FORM_SIZE: 
            return 'The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form'; 
        case UPLOAD_ERR_PARTIAL: 
            return 'The uploaded file was only partially uploaded'; 
        case UPLOAD_ERR_NO_FILE: 
            return 'No file was uploaded'; 
        case UPLOAD_ERR_NO_TMP_DIR: 
            return 'Missing a temporary folder'; 
        case UPLOAD_ERR_CANT_WRITE: 
            return 'Failed to write file to disk'; 
        case UPLOAD_ERR_EXTENSION: 
            return 'File upload stopped by extension'; 
        default: 
            return 'Unknown upload error'; 
    } 
} 

// ----------------------------------------------------------------------------
// deleteFiles
// ----------------------------------------------------------------------------
function deleteFiles($dossier_traite , $extension_choisie, $age_requis)
{
  //on ouvre le dossier
  $repertoire = opendir($dossier_traite);
  
  //on lance notre boucle qui lira les fichiers un par un
  while(false !== ($fichier = readdir($repertoire)))
  {
  //on met le chemin du fichier dans une variable simple
  $chemin = $dossier_traite."/".$fichier;
          
  //les variables qui contiennent toutes les infos n�cessaires
  $infos = pathinfo($chemin);
  $extension = $infos['extension'];

  $age_fichier = time() - filemtime($chemin);
          
  //on n'oublie pas LA condition sous peine d'avoir quelques surprises :p
          //if($fichier!="." AND $fichier!=".." AND !is_dir($fichier) AND $extension == $extension_choisie AND $age_fichier > $age_requis)
          if($fichier!="." AND $fichier!=".." AND !is_dir($fichier)  AND $age_fichier > $age_requis)          {
          unlink($chemin);
          }
  }
  closedir($repertoire); //on ferme !
}


?>

