<?php

// ----------------------------------------------------------------------------
// Server Side Script for location (query on departments / regions / ...)
// ZADS version 7.0.0 or Higher 
// version  : 1.0 
// ----------------------------------------------------------------------------

// API call through url ?
// init 
// region=*&dept=init >>all departmenst with region displayed 
// region=*&dept=* >> all the departments for all regions
// region=* >> all regions 
// region=alsace >> result for a region 
// region=alsace&dept=* >> result for all departments inside a region 

// ==== RETURNED results =======
// POST :  region=*&dept=*
// "id": 8,
// "loc": "Ardennes",
// "type": "locdept",
// "adsnb": 0
// ------------------------------
// POST :  region=*&dept=init
// "id": 1,
// "locdept": "Ain",
// "locregion": "Rhône-Alpes",
// "adsnb": 0


require_once("multitenants_settings.php"); 
require_once($SETTINGS_PATH."db_settings.php");  
require_once($SETTINGS_PATH."settings.php");  
require_once("localization.php");
require_once("functions.php"); 

// set default timezone 
date_default_timezone_set('Europe/Paris');
header('Content-Type: application/json');

$debug ="";$debug_tmp = 0 ; // 0= server 1=local
if (( $_SERVER['SERVER_ADDR'] != "127.0.0.1") || ( !$_SERVER['SERVER_ADDR'] ))  $debug_tmp=0; else $debug_tmp=1; 
$nomessage = 0;  // 0= flag to indicate wether to end a message or not

// force the debug mode : 
//force a debug based on settings file Zads5.0
if ($ENABLE_DEBUG_MODE) $debug_tmp=1; 

if ($debug_tmp==1) {
  $_METHOD  = $_GET ; 
  $debugoutputfile = "debugoutput.htm"; // only if save=1
  $debugfile = fopen($debugoutputfile,"a"); if(!$debugfile) { echo "Error writing to the output file.\n";}
  logfile('', '[admin] --------------------------------------'); // start a new call of file 
  // Report all errors except E_NOTICE  and WARNINGS
  error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);
} 
else {
  // Report simple running errors
  error_reporting(E_ERROR |  E_PARSE);
}

error_reporting(E_ALL ^ (E_NOTICE | E_WARNING | E_DEPRECATED));

$databasehost = $DB_HOST;
$databaseusername =$DB_USERNAME;  
$databasepassword =$DB_PASSWORD;  

$databasename = $DB_NAME;  //cads = classified adds. 

$dbItemsTable = $DB_PREFIX.$DB_TABLE_ITEMS ; 
$dbCatsTable = $DB_PREFIX.$DB_TABLE_CATS; 
$dbUsersTable = $DB_PREFIX.$DB_TABLE_USERS; 
$dbStatsTable = $DB_PREFIX.$DB_TABLE_STATS; 
$dbLogsTable = $DB_PREFIX.$DB_TABLE_LOGS; 

$fullfqdn = $DOMAIN_FQDN; 

// initialize datas 
$curuser_is_admin=false; // global var to indicate it a user is logged and if he is admin 
$curuser_id=""; 
$curuser_type=0; 
$curuser_xtra_type="";

//  --- open socket to MySQL database
$con = mysql_connect ($databasehost,$databaseusername, $databasepassword);
if (!$con) { $status="ko"; $msg= _('Impossible to connect to MySQL  : ').mysql_error(); } 
else {$status="ok";$msg= _("MySQL : Correct connection to host");}

$dbcon = mysql_select_db ( $databasename );
if (!$dbcon) { $status="ko"; $msg= _('Impossible to connect to MySQL  : ').mysql_error(); }
else { $status="ok";$msg= _("MySQL : Correct connection to database :"). $databasename;}


// get some global date & time variables 
$todayweeknbr = date("W") ; 
$todaymonthnbr = date("m") ; // with 0
$todayyearnbr=date("Y"); // 4 char year
$stamp= date( 'Y-m-d H:i:s', time());


// ---- process the real requests
// set the default location
$LOCATIONS_PATH = "locations/" ; 


// $json = array( 'success' => $_POST); 
// echo json_encode($json); die;



// default variables 
$success=false; 
$source=""; 
$mode=$LOCALE_LOCATION_LIST_MODE ; 

$t0=microtime(true); 


// -------------- SERVLET FOR SETTINGS   ----------------------
if(isset($_POST["region"])) {
	
  $origaction="location"; 
  $action = $_POST["region"]; 
  $region=$action; 
  $dept = $_POST["dept"]; 
  $f_locfield=''; $f_locval=''; $loclevel=''; 
  $sort_by_id=false; 
  $sort_by_adsnb=false;

  // get all the list
  if ($action) {

    if ($mode=="jsonplussql" || $mode=="json"){

      if ($LOCALE_DEFAULT_SUB_CODE!=''){
        $countryList = str_split($LOCALE_DEFAULT_SUB_CODE, 2); // split country codes 
      } else {
        $countryList[0] = $LOCALE_DEFAULT_COUNTRY_CODE; 
      }

      $locationsFileList=[]; 
      foreach ($countryList as $i => $country) {
        # code...
        $source =  $LOCATIONS_PATH.$country.".json"; 
        $jsonsource=$source; // for debug 
        $source= strtolower($source);
        $filehandler = file_get_contents( $source); 
        if ($filehandler===false) $success=false; else $success=true ;
        if (count($countryList)>1) $locationsFileList = array_merge($locationsFileList, array("100"=> array( "name" => "--country=$country","code"=>"A")));
        // if ($i==1) $locationsFileList = array_merge($locationsFileList, array("$i00"=> array( "name" => "--separator-$country","code"=>"A")));

        $locationsFileList = array_merge($locationsFileList, json_decode($filehandler, true));
      }
    }
    
    // perform the SQL querries 
    if ($mode=="sql" || $mode=="jsonplussql"){
      $sort_by_id=true; 
      // make an SQL query
      if ($region) {
        if (!$dept) {
          $loclevel=0; // get regions
          if ($region!="*") { $f_locfield="locregion"; $f_locval=$region; }
        }
        else {
          $loclevel=1; // get departments
          if ($dept!="*" ) { $f_locfield="locdept"; $f_locval=$dept;}
          else {$f_locfield="locregion"; $f_locval=$region;}
        }
      } else {$f_locfield="locregion"; $f_locval=$region;$loclevel=0;}


      // make the query 
      $locationsSqlList = sql_get_loc_list2('ad', '', '',  $loclevel, $dbItemsTable, 'ext','',  $f_locfield, $f_locval);
      $success=true; 
      $source=$mode; 
    } 
     
    // filter only region names 
    if ($mode=="jsonplussql" || $mode=="json") {
      if ($region) {
        $data=array();
        foreach ($locationsFileList as $key => $value){
          // get only regions
          if ($region=="*" || strtolower($region)==strtolower($value['name'])) {
            if ($dept) {
               foreach ($value["depts"] as $keyDept => $valueDept) {
                
                $xid = array_keys($valueDept)[0] ;
                $xvalue=array_values($valueDept)[0]; 
                
                if ($dept=="*")
                  $data[] = array("id"=>$xid, "loc"=>$xvalue, "type" => "locdept", "adsnb"=>(int)$keySql);    
                else if ($dept=="init")
                  $data[] = array("id"=>$xid, "locdept"=>$xvalue, "locregion" =>$value['name'], "adsnb"=>(int)$keySql);    
                else if (strtolower($region)==strtolower($xvalue))
                  $data[] = array("id"=>$xid, "locdept"=>$xvalue, "locregion" =>$value['name'], "adsnb"=>(int)$keySql);    
               } // end for each
            } else {
              // all regions
              $data[] = array("id"=>"$key", "loc"=>$value["name"], "type" => "locregion", "adsnb"=>(int)$keySql);    
            }
          }
        } // end loop LocationsFileList
      }
    }  
    else
      // just send the SQL result 
      $data= $locationsSqlList['data']; 

    // add content from SQL list 
    if ($locationsSqlList['data']) {
       foreach ($data as $keyData => $valueData) {
         $keySql=false;
         foreach ($locationsSqlList['data'] as $key2 => $value2) {
            if ($value2['loc']==$valueData['loc']) $keySql = $value2['adsnb'] ; 
         }
         $data[$keyData]['adsnb'] = (int)$keySql ;
      }
      // $sort_by_adsnb= true; 
    }

    // sort by ID the aray before 
    if ($sort_by_id) {
      array_sort_by_column($data, 'id');
    }

    if ($sort_by_adsnb) {
       array_sort_by_column($data, 'adsnb', SORT_DESC);
    }

  } 
} // en region 


  // output the results 
  $json = array(
                'success' => $success
                ,'region'=>$region
                ,'dept'=>$dept
                ,'source'=>$source
                ,'data' => $data
  );
  if ($debug_tmp){
    $json['debug'] = $locationsSqlList;
    $json['debug_source']= $jsonsource ; 
    $json['debug_locationfile']=$locationsFileList;
    $json['debug_countryList']=$countryList;
  }


  if ($ENABLE_TRACE_LOG) {
    logtime('end'); 
    $json['time_log']= $timing_trace; 
  }
  encode_json_and_send_with_compression($json); 

/**-----------------------------------------------------------------------------
* This function sort an array by a given key 
*-----------------------------------------------------------------------------*/
  function array_sort_by_column(&$arr, $col, $dir = SORT_ASC) {
    $sort_col = array();
    foreach ($arr as $key=> $row) {
        $sort_col[$key] = $row[$col];
    }

    array_multisort($sort_col, $dir, $arr);
}







/**-----------------------------------------------------------------------------
* This function get the list of locations  for a given condition 
* $what : user |  ad | cat
* $type  : restric to the given type  seel | buy | custom
* $search  : search condition 
$ $loclevel : the current level of search
* $dbThisTable : the relatd table of SQLDB
* $mode can be 'null' {catid, qty} or 'ext' {catid, type, title, qty} or 'ext2'= list of all categories
*-----------------------------------------------------------------------------*/
function sql_get_loc_list2($what, $type, $search, $loclevel, $dbThisTable, $mode, $f_catid, $f_locfield, $f_locval){
   

  // at initialization phase  INIT : 
  // ad, user -> EXT -- cat --> EXT2 mode
  // at run time  : mode=""; 

  global $dbCatsTable; 
  global $dbItemsTable;
  global $dbUsersTable;
  global $querycatfull;
  global $debug_tmp; 
  global $debugfile;
  global $dest_path_from_root_cat;
  global $BROWSEBYLOC_FIELDS_ORDER;
  
  $sql_where = ""; 
  $sql_limit = "LIMIT 0 , 15 "; 
  $sql_limit = "LIMIT 0 , 40 "; // 40 regions or departments for the initial map !  

  // default loc field 
  if (!$loclevel) $loclevel=0; 
  else $loclevel=(int)$loclevel;

  $locfieldAr =  explode("|", $BROWSEBYLOC_FIELDS_ORDER);
  $locfieldnumber =  count($locfieldAr);
  if (($loclevel+1) > $locfieldnumber) $loclevel = $locfieldnumber-1; // if above the max then display the last level 
  $locfield = $locfieldAr[$loclevel];

  //filter per location  (ad and users) and modify field to display
  if (($f_locfield &&  $f_locval!="*" )){
    // where filter 
      $f_stub = " i.`$f_locfield` =  '$f_locval' ";
      $sql_where.=($sql_where=="") ? " WHERE $f_stub " : " AND $f_stub "; 
    

    // find position of this field into FIELD ORDERs
    $i=0; 
    foreach($locfieldAr  as $locfieldItem) {
      if ($locfieldItem == $f_locfield) {
        $loclevel = $i+1; // take the next one  ! 
        if (($loclevel+1) > $locfieldnumber) $loclevel = $locfieldnumber-1;
        break; // quit the foreach 
      } 
      $i+=1;
    }; 

    // finalize new field 
    //$locfield = $locfieldAr[$loclevel];
  } 

  // category filter 
   if (($f_catid)){
    // where filter   
    $f_stub = " i.`catid` =  '$f_catid' ";
    $sql_where.=($sql_where=="") ? " WHERE $f_stub " : " AND $f_stub "; 
  }

  //patch to force the mode when What=USER 
  //if (($what=="user") || ($what=="users")) {$mode="ext"; $what="user";$type=false;}
    
  // filter conditions 
  if ($type) {
     $f_stub ="  i.`type` =  '".$type."' ";   
     $sql_where.=($sql_where=="") ? " WHERE $f_stub " : " AND $f_stub "; 
  }
  else 
  {
    // not type defined, remove the ZETVU
    if (($what=="ad") ||  ($what=="item") || ($what=="items")) {
       $f_stub = "   i.`type` NOT LIKE  'zetvu'";
       $sql_where.=($sql_where=="") ? " WHERE $f_stub " : " AND $f_stub "; 
    }
    
    // if list only the public and pro profils
    if (($what=="user") || ($what=="users")){
      $f_stub = " i.`indir` = 'yes'";
      $sql_where.=($sql_where=="") ? " WHERE $f_stub " : " AND $f_stub "; 
    }
  }

  // STATUS conditions   
  if ($sql_where=="") $sql_where.="  WHERE i.`status` IN ('40','45') "; else $sql_where.="  AND i.`status` IN ('40','45')  ";

  // SEARCH conditions 
  if ($search)  
    if ($sql_where=="")  $sql_where.="  WHERE ((i.`title` like  '%".$search."%') OR (i.`description` like  '%".$search."%')) "; 
    else  $sql_where.="  AND ((i.`title` like  '%".$search."%') OR (i.`description` like  '%".$search."%')) ";
    
  // --- Advanced  query -> EXT mode ---- 
  if (($mode) && ($mode=="ext")){
      // case of AD
      $sql_group ="  GROUP BY `loc` "; 
      // $sql_sort =" ORDER BY `adsnb` DESC , `loc` ASC "; 
      $sql_sort =" ORDER BY `loc` ASC "; 
      $querylocfull = "SELECT i.`$locfield` as `loc`,   COUNT(i.id) AS `adsnb`
            FROM `$dbThisTable` i 
            ".$sql_where." ". $sql_group." ". $sql_sort ." ". $sql_limit;
  }

  // ---- theSQL query  ! 
  $resultlocfull = mysql_query($querylocfull);
  // return $querylocfull ; 

  
  // logfile('debug','{sql_get_loc_list} : QUERY = '.$querylocfull);
  if (!$resultlocfull) logfile('error','{sql_get_loc_list} : SQL ERROR ='. mysql_error());
  $totnbrofresultsloc = mysql_num_rows($resultlocfull);
    
    if (($totnbrofresultsloc) && ($totnbrofresultsloc !=0)){
      $idx=0;
      $outdata=""; 

      while ($row = mysql_fetch_object($resultlocfull)) {     
        if (($mode) && ($mode=="ext")){
          if ($row->loc!='') { // protection against zero values
            $outdata = Array (
              'loc' => $row->loc ,
              'adsnb' => $row->adsnb, 
              'type'=> $locfield
            );
            $out[$idx] = $outdata; 
            $idx+=1; 
          }
        } 

      }
    } 
  return Array ('data' =>$out, 'debug'=>$querylocfull, 'where'=>$sql_where, 'filter'=>$f_locfield, 'filtervalue'=>$f_locval) ; 
}






?>