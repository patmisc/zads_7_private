<?php

error_reporting(E_ALL ^ (E_NOTICE | E_WARNING | E_DEPRECATED));

// ----------------------------------------------------------------------------
// Server Side Script for installation
//
// ----------------------------------------------------------------------------
// load libraries 
require_once("multitenants_settings.php"); 
require_once($SETTINGS_PATH."db_settings.php");  
require_once($SETTINGS_PATH."settings.php");
require_once("localization.php");  
require_once($SETTINGS_PATH."home_settings_".$cust_lang_long.".php");  

  


// set default timezone 
date_default_timezone_set('Europe/Paris');

$debug ="";
$debug_tmp = 0 ; // 0= server 1=local
if (( $_SERVER['SERVER_ADDR'] != "127.0.0.1") ||( !$_SERVER['SERVER_ADDR'] ))  $debug_tmp=0; else $debug_tmp=1; 
$nomessage = 0;  // 0= flag to indicate wether to end a message or not


if ($debug_tmp==1) {
  $debugoutputfile = "debugoutput.htm"; // only if save=1
  $debugfile = fopen($debugoutputfile,"a"); if(!$debugfile) { echo "Error writing to the output file.\n";}
  $debugoutputfilehtml = "debugoutput.html"; // only if save=1
  $debugfilehtml = fopen($debugoutputfilehtml,"a");if(!$debugfilehtml) { echo "Error writing to the output file.\n";}
  // Report all errors except E_NOTICE  and WARNINGS
  error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);
} 
else {
  // Report simple running errors
  error_reporting(E_ERROR |  E_PARSE);
}


$databasehost = $DB_HOST;
$databaseusername =$DB_USERNAME;  
$databasepassword =$DB_PASSWORD;  

$databasename = $DB_NAME;  //cads = classified adds. 

$dbItemsTable = $DB_PREFIX.$DB_TABLE_ITEMS ; 
$dbCatsTable = $DB_PREFIX.$DB_TABLE_CATS; 
$dbUsersTable = $DB_PREFIX.$DB_TABLE_USERS; 
$dbStatsTable = $DB_PREFIX.$DB_TABLE_STATS; 
$dbLogsTable = $DB_PREFIX.$DB_TABLE_LOGS; 

$fullfqdn = $DOMAIN_FQDN; 

// initialize datas 
$curuser_is_admin=false; // global var to indicate it a user is logged and if he is admin 
$curuser_id=""; 
$curuser_type=0; 


//  --- open socket to MySQL database

$con = mysql_connect ($databasehost,$databaseusername, $databasepassword);
if (!$con) { $status="ko"; $msg= _('Impossible to connect to MySQL  : ').mysql_error(); } 
else {$status="ok";$msg= _("MySQL : Correct connection to host");}

$dbcon = mysql_select_db ( $databasename );
if (!$dbcon) { $status="ko"; $msg= _('Impossible to connect to MySQL  : ').mysql_error(); }
else { $status="ok";$msg= _("MySQL : Correct connection to database :"). $databasename;}


// get some global date & time variables 
$todayweeknbr = date("W") ; 
$todaymonthnbr = date("m") ; // with 0
$todayyearnbr=date("Y"); // 4 char year
$stamp= date( 'Y-m-d H:i:s', time());

// ---- process the real requests

// ############# SERVLET FOR STATS ###########################
if (isset($_POST["stats"]) ) {

  $userid=$_POST["userid"]*1; // SECURITY
  // check if right to access this
  if (isset($_POST["userid"])) {
     check_userRights("stats", "my"); 
   }
   else { 
     check_userRights("stats", "all"); 
   }
  
  $success=true;
  $message="received initialized"; 
  $action="stats"; 
  $filter=""; 
  $sql_sort="";
  $stattype=$_POST["stats"]; 
  $timeperiod = $_POST["p"]; // time period {all|yhisyear|yhisquarter|thismonth]
  $inistattype = $stattype; 

  // decode type of request What_yaxix_per_xaxis
  $stattypeArr = explode("_", $stattype); 
  $statwhat=$stattypeArr[0];  
  
    if ($stattype=="top_dashboard") {
    
    $thisTable=  $dbItemsTable; $typefield='type'; 
    
    // get TOTAL list of categories with number of items 
    if ($curuser_is_admin){
      $sql_sort  =" ORDER BY `nb` DESC ";
      $sql_group ="  GROUP BY `$typefield`";  
      $filter    ="  WHERE status IN ('40','45') "; 
      $query = "SELECT COUNT(id) as `nb`, $typefield as `type` FROM `$thisTable` ".$filter." ". $sql_group." ". $sql_sort ;
      $result = mysql_query($query);
      $totnbrofresults = mysql_num_rows($result);
      
      if (($totnbrofresults) && ($totnbrofresults !=0)){
        $idx=0;
        $outdata=""; 
        $finaloutput=array();
        while ($row = mysql_fetch_object($result)) { 
          $outdata = Array (
              'adsnb' => $row->nb ,
              'type'=> $row->type 
              );
         $finaloutput[$idx] = $outdata; 
         $idx+=1; 
        }
      }
    }
    
    // get total number of articles with status     
      $sql_sort="";  
      $filter="";
      if ($userid) $filter .=" WHERE userid=$userid"; 
      $queryadfull = "SELECT COUNT(`id`) as `nbads`, `status` FROM `$dbItemsTable`" .$filter." GROUP BY `status` ". $sql_sort ; 
      $resultads = @mysql_query($queryadfull);
      $outdata2=""; 
       while ($row = mysql_fetch_object($resultads)) { 
       $outdata2['a'.$row->status] = $row->nbads; 
      }

      // get total number of articles
      $sql_sort="";  
      $filter="  WHERE `status` IN ('40', '45') ";
      if ($userid) $filter .=" AND userid=$userid"; 
      $queryadfull = "SELECT COUNT(`id`) as `nbads` FROM `$dbItemsTable`" .$filter." ". $sql_sort ; 
      $resultads = mysql_query($queryadfull);
      $row_ads = mysql_fetch_object($resultads); 
    
    if ($curuser_is_admin){
      // get total number of users
      $sql_sort="";  
      $filter="  WHERE `status` IN ('40', '45') ";
      $queryusersfull = "SELECT COUNT(`id`) as `nbusers` FROM `$dbUsersTable`" .$filter." ". $sql_sort ; 
      $resultusers = mysql_query($queryusersfull);
      $row_users = mysql_fetch_object($resultusers); 
      
      
      // get total number of cat
      $sql_sort="";  
      $filter="  WHERE `status` IN ('40', '45') ";
      $querycatsfull = "SELECT COUNT(`id`) as `nbcats` FROM `$dbCatsTable`" .$filter." ". $sql_sort ; 
      $result = mysql_query($querycatsfull);
      $row_cats = mysql_fetch_object($result); 
    }
    
  }

  if ($stattype=="ad_vol_per_cat") {
     // get list of categories with number of items 
    $sql_sort  =" ORDER BY `adsnb` DESC ";
    $sql_group ="  GROUP BY `catid`";  
    $filter    ="  WHERE   i.catid = c.id AND i.status IN ('40','45') "; 
    
    if ($userid) $filter .=" AND i.userid=$userid"; 
    
    $querynbpercatfull = "SELECT i.catid, COUNT(i.id) as `adsnb`, i.type, c.title FROM `$dbItemsTable` i, `$dbCatsTable` c".$filter." ". $sql_group." ". $sql_sort ;
    $result = mysql_query($querynbpercatfull);
    $totnbrofresults = mysql_num_rows($result);
  
    if (($totnbrofresults) && ($totnbrofresults !=0)){
      $idx=0;
      $outdata=""; 
      $finaloutput=array();
      while ($row = mysql_fetch_object($result)) { 
        $outdata = Array (
            'catid' => $row->catid ,
            'cattitle' => $row->title ,
            'adsnb' => $row->adsnb ,
            'type'=> $row->type 
            );
       $finaloutput[$idx] = $outdata; 
       $idx+=1; 
      }
    }

  }
  
  if (    ($stattype=="ad_vol_per_user")
     )  
  {
  
    if ($statwhat=="ad")  { $thisTable=  $dbItemsTable; $typefield='type'; }
    if ($statwhat=="user"){ $thisTable=  $dbUsersTable; $typefield='auth';}
    
    $sql_sort  =" ORDER BY `nb` DESC ";
    $sql_group ="  GROUP BY `userid`";  
    //$filter    ="  WHERE status IN ('40','45') "; 
    $filter="";
    $query = "SELECT COUNT(id) as `nb`, userid  FROM `$thisTable` ".$filter." ". $sql_group." ". $sql_sort ;
    $result = mysql_query($query);
    $totnbrofresults = mysql_num_rows($result);
  
    if (($totnbrofresults) && ($totnbrofresults !=0)){
     
      $outdata=array(0,0,0,0,0,0); // from 1 to 5 and more than 5
      $finaloutput=array(); 
      while ($row = mysql_fetch_object($result)) { 
        $range=min($row->nb,6); 
        $range=$range-1;
        $outdata[$range] = $outdata[$range]+1;  
      }
      // process the array 
      $idx=0;
      $idy=0;
      foreach($outdata as $outdatai) {
       if ($outdatai>0){
        $finaloutput[$idy] = Array (
            'nb' => $idx+1 ,
            'nbusers'=> $outdatai 
            );
        $idy+=1;
       }
       $idx+=1;
      }
    }
  }
  
  if (     
            ($stattype=="user_vol_per_type")
        ||  ($stattype=="user_vol_per_protype")
        ||  ($stattype=="ad_vol_per_type")
        ||  ($stattype=="ad_vol_per_delete")
     )  
  {
  
    if ($statwhat=="ad")  { $thisTable=  $dbItemsTable; $typefield='type'; }
    if ($statwhat=="user"){ $thisTable=  $dbUsersTable; $typefield='auth';}
    if ($stattype=="user_vol_per_protype"){ $thisTable=  $dbUsersTable; $typefield='protype';}
    if ($stattype=="ad_vol_per_delete") { $thisTable=  $dbLogsTable; $typefield='desc'; }
    
    $sql_sort  =" ORDER BY `nb` DESC ";
    $sql_group ="  GROUP BY `$typefield`";  
    $filter    ="  WHERE status IN ('40','45') ";
    if ($stattype=="ad_vol_per_delete")  $filter    ="  WHERE `desc` like '80%' AND  `what` = 'ad'"; 
    
    if ($statwhat=="ad" && $userid) $filter .=" AND userid=$userid"; 
    
    $query = "SELECT COUNT(id) as `nb`, `$typefield` as `type` FROM `$thisTable` ".$filter." ". $sql_group." ". $sql_sort ;
    $result = mysql_query($query);
    $totnbrofresults = mysql_num_rows($result);
  
    if (($totnbrofresults) && ($totnbrofresults !=0)){
      $idx=0;
      $outdata=array();
      $finaloutput=array();
      while ($row = mysql_fetch_object($result)) { 
        // slit and replace null values 
         if ($stattype=="ad_vol_per_delete"){
          $typeAr = explode("|", $row->type ); 
          if (count($typeAr)>1) $thetype=$typeAr[1]; 
          else $thetype = "auto"; 
         } else $thetype = $row->type; 
        
        $outdata = Array (
            'metrics' => $row->nb ,
            'type'=> $thetype 
            );
       $finaloutput[$idx] = $outdata; 
       $idx+=1; 
      }
    }
  }
  
  if (($stattype=="ad_vol_per_time") || ($stattype=="ad_vol_per_status") || ($stattype=="user_vol_per_time")){
    // data format  =  {what=value|} where u=user; a=add; a00= adds with status =0
    // example : u=55&a=3&a00=1&a10=13&a40=53&a60=1&a80=5
        
      $filter=" WHERE `type`='count' ";
      
      // time filter 
      if ($timeperiod){
        if ($timeperiod=="thismonth") $filter .= " AND date like '%-$todaymonthnbr-%' "; 
        if ($timeperiod=="thisyear") $filter .= " AND date like '$todayyearnbr-%' ";
        if ($timeperiod=="thisquarter")  {
          $curq= ceil(($todaymonthnbr*1)/3); 
          $filter .= " AND ( "; 
          for($q = 1; $q < 4; $q++) {
           $tq=  ($curq-1)*3+$q; if ($tq<10) $tq="0".$tq;     
           $filter .= " date like '%-$tq-%' ";
           if ($q!=3) $filter .= " OR "; 
          }
          $filter .= " ) "; 
        }
      }

      $sql_group ="  GROUP BY `date`";  
      $sql_sort=" ORDER BY `date` ASC ";
      $query = "SELECT * FROM $dbStatsTable " .$filter." ". $sql_group ." ". $sql_sort;
      $result = @mysql_query($query);
      $totnbrofresults = mysql_num_rows($result);
      
      if (($totnbrofresults) && ($totnbrofresults !=0)){
        $idx=0;
        $outdata=""; 
        $finaloutput=array();
        $outputArr=array();
        while ($row = mysql_fetch_object($result)) { 
          // parse the array
          parse_str($row->data, $outputArr);
          $outdata = Array (
            'date' => $row->date ,
            'datestamp' => strtotime($row->date)*1000,
            'metrics' =>  $outputArr 
            );
            $finaloutput[$idx] = $outdata; 
          $idx+=1; 
        }
      } 
    }
    
    if (      ($stattype=="ad_vol_per_age")
          ||  ($stattype=="user_vol_per_age")
        )
    {
      
      if ($statwhat=="ad")  { $thisTable=  $dbItemsTable; $datefield='moddate'; }
      if ($statwhat=="user"){ $thisTable=  $dbUsersTable; $datefield='registerdate'; }
      
      //SELECT COUNT(`id`), CAST(`moddate` AS DATE) as ddate FROM `items` GROUP BY `ddate` WHERE `status` IN ('40', '45')   
      $filter=" WHERE `status` IN ('40', '45') ";
      
      if ($statwhat=="ad" && $userid) $filter .=" AND userid=$userid "; 
      
      // time filter 
      if ($timeperiod){
        if ($timeperiod=="thismonth") $filter .= " AND $datefield like '%-$todaymonthnbr-%' "; 
        if ($timeperiod=="thisyear") $filter .= " AND $datefield like '$todayyearnbr-%' ";
        if ($timeperiod=="thisquarter")  {
          $curq= ceil(($todaymonthnbr*1)/3); 
          $filter .= " AND ( "; 
          for($q = 1; $q < 4; $q++) {
           $tq=  ($curq-1)*3+$q; if ($tq<10) $tq="0".$tq;          
           $filter .= " $datefield like '%-$tq-%' ";
           if ($q!=3) $filter .= " OR "; 
          }
          $filter .= " ) "; 
        }
      }
      
      $sql_group =" GROUP BY `ddate` ";  
      $sql_sort="";
      $query = "SELECT  COUNT(`id`) AS nbitem, CAST(`$datefield` AS DATE) AS ddate FROM $thisTable " .$filter." ". $sql_group ." ". $sql_sort;
      $result = @mysql_query($query);
      $totnbrofresults = mysql_num_rows($result);
      
      if (($totnbrofresults) && ($totnbrofresults !=0)){
        $idx=0;
        $outdata=""; 
        $finaloutput=array();
        $outputArr=array();
        while ($row = mysql_fetch_object($result)) { 
          // parse the array
          parse_str($row->data, $outputArr);
          $outdata = Array (
            'date' => $row->ddate ,
            'datestamp' => strtotime($row->ddate)*1000,
            'metrics' =>  $row->nbitem 
            );
            $finaloutput[$idx] = $outdata; 
          $idx+=1; 
        }
      } 
    }
    
  
  // -----------------   output results -------------------------------------
  $what=$inistattype;
  $json = array(
                  'success' => $success,
                  'message' => $message,
                  'what' => $what,
                  'action' => $action, 
                  'userid' =>$userid
              );
              
  // send DATA in format depending on type of request            
  if ( ($stattype=="top_dashboard") )
  {
    $json["data"] = array(
                  'serie1' => $finaloutput,
                  'serie2'=>$outdata2,
                  'totnb_ads'=>$row_ads->nbads,
                  'totnb_users'=>$row_users->nbusers,
                  'totnb_cats'=>$row_cats->nbcats
            ); 
  }
  
  if (    ($stattype=="ad_vol_per_time")
      ||  ($stattype=="ad_vol_per_status") 
      ||  ($stattype=="user_vol_per_time")
      ||  ($stattype=="ad_vol_per_age")
      ||  ($stattype=="user_vol_per_age")
      ||  ($stattype=="user_vol_per_type")
      ||  ($stattype=="user_vol_per_protype")
      ||  ($stattype=="ad_vol_per_type")
      ||  ($stattype=="ad_vol_per_user")
      ||  ($stattype=="ad_vol_per_cat")
      ||  ($stattype=="ad_vol_per_delete")
     ){
    $json["data"] = array(
                  'serie1' => $finaloutput
            ); 
  }
  
    
                      
  if ($debug_tmp==1){ // add debug info into the stream when working local
    $json["xdebug"]= array(
            'sqldebug'=> $querynbpercatfull,
            'sqldebug2'=> $querynbpercatfull,
            'sqldebug3'=> $querycatsfull,
            'sqldebug'=> $query,
            'timeperiod'=>$timeperiod,
            'curuser_type'=>$curuser_type,
            'curuser_is_admin'=>$curuser_is_admin, 
            'curuser_id'=>$curuser_id,
            'month'=>$todaymonthnbr 
            );  
 }

  echo json_encode($json); // realy send the datas 
}


/* allow access only to admin users  */ 
function check_userRights($what2, $action2){

  global $debugfile; 
  global $debug_tmp; 
  global $curuser_is_admin;
  global $curuser_id; 
  global $curuser_type;
  $output=false;  
  
    // check session to give general info 
    session_name("ZADSSESID"); 
    if ($_COOKIE["ZADSSESID"] !="") { // detect if a session is set . session_id does not give the result
      session_start();
      if (isset($_SESSION['user_id'])) $curuser_id = $_SESSION['user_id'];  
      if (isset($_SESSION['user_type'])) {
        $curuser_type = $_SESSION['user_type']+0; 
        if ($action2=="all" && $curuser_type>=8) {
          $curuser_is_admin=true;  
          $output=true;
        }
        if ($action2=="my" && isset($curuser_id)) {
          $output=true;
        }
        }
    } 
  
  // output the error and content. 
  if ($output) return  $output; // display nothing and continue processing
  else  {
      // prepare the output code 
     $message = "This operation is not authorized !";             
     $json = array(
                  'success' => false,
                  'message' => $message,
                  'what' => $what2,
                  'action' => $action2
              );      
      echo json_encode($json); 
      exit();       
  }
}; 
  
/*
$ret=array();   
$retx=array(); 
$rety=array(); 

// Set the JSON header
header("Content-type: text/json");

for ($i = 0; $i < 20; $i++) {
  // The x value is the current JavaScript time, which is the Unix time multiplied by 1000.
  $x = time() * 1000+($i*3600*10);
  // The y value is a random number
  $y = rand(0, 100);
  $ret[] = array($x, $y);
  $retx[]=$x; 
  $rety[]=$y; 
}
$ret2=array($x, $y);
$ret3=array($retx, $rety);
$ret4=array($ret);
// Create a PHP array and echo it as JSON
echo json_encode($ret);
*/

?>
