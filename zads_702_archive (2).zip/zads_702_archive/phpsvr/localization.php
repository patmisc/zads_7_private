<?php

// // detect language to be used on PHP side 
// if (isset($_COOKIE['ZADS_LOCAL']))
//     $cookietext  =  ($_COOKIE['ZADS_LOCAL']!='' ? $_COOKIE['ZADS_LOCAL'] : ''); // set default language
//   else $cookietext=""; 

//   if ($cookietext) 
//     $langcode= explode("lang=", $cookietext); 
//   else {
//     $lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
//     // example of output of  HTTP_ACCEPT_LANGUAGE en-US,en;q=0.8,fr-FR;q=0.6,fr;q=0.4
//     $suplang = array("en", "fr", "nl");
//     if (in_array($lang, $suplang)) {
//        $localeMap = array( 'en' => 'en_US', 'fr' => 'fr_FR', 'nl'=>'nl_NL' );
//        $langcode[1] = $localeMap[$lang]; 
//       }  
//       else 
//         $langcode[1] ="fr_FR"; // default 
//   }

      /* step 0, construct the supported_languages_short and long lists  */
      $supported_lang_short = array();
      $supported_lang_long = '';
        foreach( $AUTHORIZED_LANGUAGES as $key => $value ){
          $supported_lang_short[] = $key; 
          $supported_lang_long .= $value.';' ; 
        } 

      // priority 1 =  COOKIES 
      if (isset($_COOKIE['ZADS_LOCAL'])){
        $cookietext  =  ($_COOKIE['ZADS_LOCAL']!='' ? $_COOKIE['ZADS_LOCAL'] : ''); // set default language
        $langcodeext= explode("lang=", $cookietext); 
        $longlangcode =$langcodeext[1];
        $shortlangcode= substr($longlangcode, 0, 2);
      }
      else { 
        // priority 2 =  BROWSER language detection 
        // example of output of  HTTP_ACCEPT_LANGUAGE en-US,en;q=0.8,fr-FR;q=0.6,fr;q=0.4
        if (isset($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
          $browserfirstlang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
        } else  $browserfirstlang ="fr"; 


        //$suplang = array("en", "fr", "nl");
        if (in_array($browserfirstlang, $supported_lang_short)) {
          $shortlangcode = $browserfirstlang; 
        } else $shortlangcode=$supported_lang_short[0]; 

        // final assigment  
        $longlangcode= $AUTHORIZED_LANGUAGES[$shortlangcode]; // default  =  first entry of the list ! 
      }


      // load the right file and set the variables : 
      $cust_lang_short = $shortlangcode;  
      $cust_lang = $cust_lang_short; 
      $cust_lang_long = $longlangcode; 
      $cust_dir = ($shortlangcode=="ar") ? 'rtl' :'ltr';  
      $cust_lang_support =  $supported_lang_long;
      $locale = $cust_lang_long; 

//$locale = "fr_FR";
//if (isSet($_GET["locale"])) $locale = $_GET["locale"];

putenv("LC_ALL=$locale");
setlocale(LC_ALL, $locale);
bindtextdomain("messages", "./locale");
textdomain("messages");

// warning:  GETTEXT is performing 
// gettext not only looks up a translation in a message catalog. It also converts the translation on the fly to the desired output character set. This is useful if the user is working in a different character set than the translator who created the message catalog, because it avoids distributing variants of message catalogs which differ only in the character set.
// The output character set is, by default, the value of nl_langinfo (CODESET), which depends on the LC_CTYPE part of the current locale. But programs which store strings in a locale independent way (e.g. UTF-8) can request that gettext and related functions return the translations in that encoding, by use of the bind_textdomain_codeset function.
bind_textdomain_codeset("messages", 'UTF-8'); // force UTF8 for all !




?>
