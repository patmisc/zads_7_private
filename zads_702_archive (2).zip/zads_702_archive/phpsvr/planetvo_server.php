<?php
/******************************************************************************
 * ZADS ALERT SERVER
 * 
 * Note :  works bootstrap0.php
 *
 * @category   CorePackage
 * @package    ZADS
 * @author     Patrice COHAUT <patrice.cohaut@gmail.com>
 * @copyright  2017 PATMISC
 * @version    7.5.0
 ******************************************************************************/

define('DB_MODE', 'both'); // both =  create two db accesses (one with old mode and one with new mode)
require_once("bootstrap0.php"); 

// ############# SERVLET FOR BANNERS REQUESTS  ###########################
define('WHATS', 'planetvo'); 

if (isset($_POST[WHATS]) ) {

  // general variables
  $now= date( 'Y-m-d H:i:s', time());
  $dest_path_from_root_user ='./uploads/user/';

  $alerts = $_POST[WHATS] ;
  $action = $alerts; 

  $dbThisTable = $dbAlertsTable; 

  $type = secure_var($_POST["type"]) ; if (!isset($_POST["type"])) $type="review"; 
  $status = secure_var($_POST["forceflag"]) ;
  
  /* check if user has the right to do so if ok , continue ,  else, page is exited with a special message*/
  $user_details = check_userRights("alerts", $action); 
  
  // identify selector
  $what = secure_var($_POST["what"]) ;            // SECURITY 
  $laction = secure_var($_POST["laction"]) ;      // SECURITY 
  $id = $_POST["id"]+0 ; 

  // content
  // TYPE : can be "REVIEW || COMMENT || CONVERSATION || QUESTION "

  $title = secure_var($_POST["title"]) ; 
  $description = secure_var($_POST["description"]) ; 
  $adid = $_POST["adid"]+0 ;
  $fromid = $_POST["fromid"]+0 ; 

  // to id can be an integer of a 
  $toid = (isset($_POST["toid"])) ?  $_POST["toid"] : '0' ;
  

  $metas = secure_var($_POST["metas"]) ; 

  // IP address are stored as INTEGERS for a better performance and check 
  // var_dump(ip2long('209.85.227.147'));
  // var_dump(long2ip(3512066963));
  $fromip =ip2long($_SERVER['REMOTE_ADDR']);
  $toip=0; // we don't know it  ! 

  $nav=$_POST["nav"];  
  $sort=$_POST["sort"];
  $sortoriginal = $sort;
  $sort=explode("_",$sort); 
  $sort_dir = $sort[1];
  $sort_by = $sort[0];
  

  //common
  $curuserid = $_POST["curuserid"]+0 ; // SECURED 
  $userid = $_POST["userid"]+0 ; // SECURED 

  // filter
  $faction = $_POST["faction"] ;
  $fseverity = $_POST["fseverity"] ;
  $fwhat = trim(secure_var($_POST["fwhat"]));
  $search=trim(secure_var($_POST["search"])); // SECURITY 
  $ftime=trim(secure_var($_POST["ftime"])); // SECURED 
  $fuserid = $_POST["fuserid"]+0 ; // SECURED 
  $fadid = $_POST["fadid"]+0 ; // SECURED 
  $fstatus = secure_var($_POST["fstatus"]) ; 
  $ftype = secure_var($_POST["ftype"]) ; 

  $fdir=secure_var($_POST["fdir"]) ; // direction

  $fcomid = secure_var($_POST["fcomid"]) ; 
  $focusid = secure_var($_POST["focusid"]) ; 

  // indicate this is an inline display area for a given ID   
  $inlinefor =  $_POST["inlinefor"]+0 ; // SECURED 
  if ($action=="load" && $fadid) $inlinefor=$fadid; 

  $msg=""; 
  $filter=""; 
  $sql_sort="";
  $sql_group="";
  $success=true; 
  $view_mode ='';

  $maxresults=1; 


  $noQuery= false; 
  $trace=''; 

  $datas_for_email=array(); // will save all datas for email sending


  define('PVO_FTP_SERVER', 'ftp.publicationvo.com'); 
  define('PVO_FTP_LOGIN', 'passerelletest');
  define('PVO_FTP_PASSWORD', '47tymoKSro');
  define('PVO_FTP_DATAS_DIR', 'datas');
  define('PVO_FTP_PHOTOS_DIR', 'photos');

  //----- TEST the FTP connection -----------------------------
  if ($action=="testftp")
  {



    //     Serveur : ftp.publicationvo.com
    // Login : passerelletest
    // Password : 47tymoKSro

    $ftp = ftp_connect(PVO_FTP_SERVER, 21) or exit_with_error('Erreur planetvo : connexion au serveur FTP impossible.');
    $login_result =ftp_login($ftp, PVO_FTP_LOGIN, PVO_FTP_PASSWORD) or exit_with_error('Erreur planetvo : login impossible.');
    ftp_pasv($ftp, true); // VERY IMPORTANT !!! 

    // by changing directory before, the ftp_nlist return the file names only  ! 
    ftp_chdir($ftp, '/'.PVO_FTP_DATAS_DIR.'/');
    $buff_files = ftp_nlist($ftp, ''); // ça marche ! 

    // $buff_files = ftp_nlist($ftp,'/'.PVO_FTP_DATAS_DIR.'/'); // ça marche ! >> retuen the filename wit the path
    // $buff_files = ftp_rawlist($ftp, '/'.PVO_FTP_DATAS_DIR.'/'); // ça marche ! 
    $loglist = $buff_files;


    // -- read the XML file 
    $pvo_filename_xml = 'tt4.xml';
    $found=false; 
    foreach($buff_files as $file) { if ($file== $pvo_filename_xml) { $found=true; break;}  }
    if (!$found) exit_with_error('file '.$pvo_filename_xml.' does not exist!', '404'); 

    // -- read the file and copy it ino TMP directory 
    $pvo_local_file_xml = './tmp/'.$pvo_filename_xml;
    ftp_get($ftp, $pvo_local_file_xml, $pvo_filename_xml, FTP_BINARY);


    // // -- parse the file 
    // $xml=simplexml_load_file($pvo_local_file_xml) or exit_with_error("Error: Cannot create object");
    // $loglist = $xml; 
    // $loglist = $xml->stock->vehicule;


    // -- read the ZIp photo files 
    $pvo_filename_zip = 'photos.txt.zip';
    $found=false; 
    foreach($buff_files as $file) { if ($file== $pvo_filename_zip) { $found=true; break;}  }
    if (!$found) exit_with_error('file '.$pvo_filename_zip.' does not exist!', '404'); 

    // -- read the file and copy it ino TMP directory 
    $pvo_local_file_zip = './tmp/'.$pvo_filename_zip;
    ftp_get($ftp, $pvo_local_file_zip, $pvo_filename_zip, FTP_BINARY);

    // unzip the file
    $zipArchive = new ZipArchive();
    $resultZip = $zipArchive->open($pvo_local_file_zip);
    if ($resultZip === TRUE) {
        $zipArchive ->extractTo("./tmp/");
        $zipArchive ->close();
        // Do something else on success
    } else {
        // Do something on error
      exit_with_error('Erreur planetvo : unzip impossible');
    }

    ftp_close($ftp);
    

  }

  // <CodePvo>tt4</CodePvo>
  // <SocieteNom>GARAGE CITROEN CHASTEL NOUVEL</SocieteNom>
  // <SocieteMarque>CITROEN</SocieteMarque>
  // <SocieteAdresse>RUE DES FRERES AMIEUX</SocieteAdresse>
  // <SocieteAdresseSuite/>
  // <SocieteCodePostal>48000</SocieteCodePostal>
  // <SocieteVille>CHASTEL NOUVEL</SocieteVille>
  // <ContactsNoms>Patrick MEUNIER</ContactsNoms>
  // <ContactsTelephones>02.55.05.74.37</ContactsTelephones>
  // <ContactsTelephones2>02.93.16.35.57</ContactsTelephones2>
  // <ContactsEmails>patrick-meunier@garage-citroen-chastel-nouvel.fr</ContactsEmails>
  // <IdentifiantVehicule>31057544020</IdentifiantVehicule>
  // <ReferenceVehicule>116GT0X3</ReferenceVehicule>
  // <NumeroPolice>3105754</NumeroPolice>
  // <StatutStock>ST</StatutStock>
  // <Annee>2010</Annee>
  // <Date1Mec>14-07-2010</Date1Mec>
  // <GenreLibelle>Voitures</GenreLibelle>
  // <Marque>RENAULT</Marque>
  // <Famille>Clio</Famille>
  // <Version>Campus 1.2 GPL 60ch Campus Authentique 3p</Version>
  // <Modele>Clio Campus 1.2 GPL 60ch Campus Authentique 3p</Modele>
  // <TypeMine/>
  // <EnergieLibelle>GPL</EnergieLibelle>
  // <PuissanceFiscale>4</PuissanceFiscale>
  // <PuissanceReelle>60</PuissanceReelle>
  // <Cylindree>1149</Cylindree>
  // <NbPlaces>5</NbPlaces>
  // <NbPortes>3</NbPortes>
  // <Kilometrage>20450</Kilometrage>
  // <KmGaranti>Non garanti</KmGaranti>
  // <Couleur>Gris Clair Métal</Couleur>
  // <BoiteLibelle>Manuelle</BoiteLibelle>
  // <NbRapports>5</NbRapports>
  // <PrixVenteTTC>11310</PrixVenteTTC>
  // <PremiereMain>FAUX</PremiereMain>
  // <GarantieLibelle/>
  // <DestinationLibelle>Particulier</DestinationLibelle>
  // <CategorieLibelle>Berline</CategorieLibelle>
  // <EquipementsSerieEtOption>ABS|Aide au freinage d'urgence|Airbags latéraux avant|Phares antibrouillard|Direction assistée|Fixations Isofix aux places arrières|Vitres avant électriques|Pack électrique|Prise auxiliaire de connexion audio|Radio CD|Siège conducteur réglable en hauteur|Verrouillage auto. des portes en roulant|Verrouillage centralisé des portes|Verrouillage centralisé à distance|Volant réglable en hauteur</EquipementsSerieEtOption>
  // <SiteLibelle>CHASTEL NOUVEL</SiteLibelle>
  // <LieuLibelle>DAMMARTIN EN GOELE</LieuLibelle>
  // <Photos></Photos>
  // <Co2>143</Co2>
  // <CommentairePublic/>
  // <Poids>975</Poids>
  // <PTAC>1520</PTAC>
  // <PTRA>2250</PTRA>
  // <ChargeUtile>465</ChargeUtile>
  // <Longueur>0</Longueur>
  // <Largeur>0</Largeur>
  // <Empattement>2472</Empattement>
  // <Hauteur>0</Hauteur>
  // <Volume>0</Volume>
  // <Silhouette/>
  // <DerniereVisiteTechnique/>
  // <DateControlographe/>


  if ($action=="parsexml")
  {
    $pvo_filename_xml = 'tt4.xml';
    $pvo_local_file_xml = './tmp/'.$pvo_filename_xml;

    // -- parse the file 
    $xml=simplexml_load_file($pvo_local_file_xml) or exit_with_error("Error: Cannot create object");
    // $loglist = $xml; 
    // $loglist = $xml->Vehicule[0];
    $total = count($xml->Vehicule);

    $parsedXml=array(); // will save all datas for email sending
    $i=0;
    $tagsToMap = [ 
                   'ReferenceVehicule', 'IdentifiantVehicule', 'StatutStock', 'Annee'
                  ,'Marque', 'Famille', 'Version', 'EnergieLibelle','BoiteLibelle','CategorieLibelle'
                  ,'PrixVenteTTC'
                  ,'Photos'
                ]; 

    // example for field photos
    // 31058944020_01_hd.jpg|31058944020_02_hd.jpg|31058944020_03_hd.jpg|31058944020_04_hd.jpg|31058944020_05_hd.jpg|31058944020_06_hd.jpg|31058944020_07_hd.jpg|31058944020_08_hd.jpg|31058944020_09_hd.jpg|31058944020_10_hd.jpg

    foreach ($xml->Vehicule as $xml_vehicule):
      $xml_vehicule = (array)$xml_vehicule;

      $parsedXml[$i]['id']= $i+1;
      // $parsedXml[$i]['tagsnbr']= count($xml_vehicule);

      foreach($xml_vehicule as $key => $value)
      {
        if (in_array($key, $tagsToMap)) 
        $parsedXml[$i][$key] = $value; 
      }

      // $parsedXml[]=array(
      //   'Id'=>$i
      //   ,'TagsNb'=>count($xml_vehicule)
      //   ,"ReferenceVehicule" => $xml_vehicule['ReferenceVehicule']
      //   ,"IdentifiantVehicule" => $xml_vehicule['IdentifiantVehicule']
      // );
      // $parsedXml[$i]= $xml_vehicule->IdentifiantVehicule; 
      $i+=1;
    endforeach;
    $loglist= array('nbr'=>$total, 'vehicules'=>$parsedXml); 
    // var_dump($parsedXml);
    // die(); 

  }





  // /photos/pvo/jupiter/photos/tt4/1809504_hd.jpg
  if ($action=="getphotos")
  {
    $pvo_archive_photos = "./tmp/photos.txt"; 
    
    // -- read the file (txt) and parse it 
    $photosList = array(); 
    // $txt_file = file_get_contents($pvo_archive_photos);
    // $rows        = explode("\n", $txt_file);
    // foreach($rows as $row => $data)
    // {
    //   //get row data
    //   $row_data = explode('^', $data);

    //   $info[$row]['id']           = $row_data[0];
    //   $info[$row]['name']         = $row_data[1];
    //   $info[$row]['description']  = $row_data[2];
    //   $info[$row]['images']       = $row_data[3];

    // }

    $fp = fopen($pvo_archive_photos, 'r');
    $delimiter="\t";
    $i=0; 
    while ( !feof($fp) )
    {
        
        $line = fgets($fp, 2048);
        $data = str_getcsv($line, $delimiter);
        if ($data[0]){
          $photosList[] = array('id'=>$i, 'name'=> $data[0], 'path'=> $data[1], 'md5'=> $data[2]); 
          $i++;
        }
    }                              
    fclose($fp);

    $total=$i; 
    $loglist= array('nbr'=>$total, 'photos'=>$photosList); 

    // -- get the first file 
    $photo_progess_log = array();

    $photoId = 0; 
    $photo=$photosList[$photoId];
    $pvo_filename_photo =  $photo['path'];
    $pvo_local_file_photo = './tmp/photos/'.$photo['name'];


    // ftp connection
    $ftp = ftp_connect(PVO_FTP_SERVER, 21) or exit_with_error('Erreur planetvo : connexion au serveur FTP impossible.');
    $login_result =ftp_login($ftp, PVO_FTP_LOGIN, PVO_FTP_PASSWORD) or exit_with_error('Erreur planetvo : login impossible.');
    ftp_pasv($ftp, true); // VERY IMPORTANT !!! 

    // get file 
    $time = microtime(true);
    ftp_get($ftp, $pvo_local_file_photo, $pvo_filename_photo, FTP_BINARY) or exit_with_error('Erreur planetvo : impossible to get file ' .$pvo_filename_photo);

    $deltaTime =  number_format((microtime(true) - $time), 3);

    // check MD5 status   
    $md5_local = md5_file($pvo_local_file_photo); 
    $status = ($md5_local==$photo['md5']) ? true : false; 
    
    $filesize = filesize($pvo_local_file_photo);
    $photo_progess_log[] = array(
        'id'=>$photoId 
        , 'success'=> '$status'
        , 'time'=> $deltaTime
        , 'filesize'=> $filesize
        , 'name'=>$photo['name']
        , 'path'=> $pvo_local_file_photo
        , 'md5'=> $md5_local, 'md5_src'=> $photo['md5']
    ); 
    $loglist = $photo_progess_log;






  }



  //----- LIST action -----------------------------
  if ($action=="list" || $action=="load"){

    // other filter / sort and actions
    if (isset($_POST["page"]))$paged = $_POST["page"]+0; else  $paged =1;  
    if (isset($_POST["eppage"])) $eppage =$_POST["eppage"]*1; else  {
      if ($action=="load") $eppage=COMS_MAX_DISPLAYED; 
      else $eppage=50;
    } 

    // sorting option 
    if ($sort_by) {
      if ($sort_by=="date") $xsort_by="moddate"; else $xsort_by=$sort_by ;   
      $sql_sort ="  ORDER BY `$dbThisTable`.`".$xsort_by."` ".$sort_dir;
    } else $sql_sort.=" ORDER BY `$dbThisTable`.`moddate` DESC ";  
    
    if ($id && $id>0) {
      $filter.="  WHERE `$dbThisTable`.`id` = '$id' ";
      $limit=" LIMIT 0, 30 "; // no limit on the request
    } else {
      $itemstart = ((int)$paged -1) * $eppage; 
      if ($eppage) $limit = "LIMIT ".$itemstart.", $eppage"; // set a limit if different from zero 
    } 
    
    // search condition
    if ($search)  {
      $f_stub =" ( (`$dbThisTable`.`whatid` = '".$search."') OR (`$dbThisTable`.`description` like  '%".$search."%') ) ";
      $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
    }

    // filter per AD ID 
    // if (($fadid)) {
    //   $f_stub = " `$dbThisTable`.`whatid` =  '$fadid' AND `$dbThisTable`.`what` =  '$what'";
    //   $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
    // }

    // // filter per type
    // if ($ftype){
    //   $f_stub = " `$dbThisTable`.`type` =  '$ftype' ";
    //   $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
    // }

    // view mode 
    if ($curuser_is_admin || $curuser_is_owner) {
      $view_mode = 'extended';
    }  

    if ($action=="load"){
      $f_stub = " `$dbThisTable`.`userid` =  '$curuserid' ";
      $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
    }

    // limite to current user id if not administrator
    // if (!$curuser_is_admin && $curuserid){
    //   $f_stub = " `$dbThisTable`.`userid` =  '$curuserid' ";
    //   $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
    // }

    // status filter   
    // apply a filter on status (only publiched is not admin or owner)  
    if ($view_mode!='extended' && !$ftype=="conv"){
      $f_stub = " `$dbThisTable`.`status` =  '40' ";
      $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
    } else {
      $f_stub=""; 
      if ($fstatus=="20")  $f_stub = " `$dbThisTable`.`status` =  '20' ";
      if ($f_stub) $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
    }

    // multiple join elements from AD + USER + CATS
    $join = " LEFT OUTER JOIN `$dbUsersTable` ON `$dbThisTable`.`userid`= `$dbUsersTable`.`id` ";
    // $join .= " LEFT OUTER JOIN `$dbItemsTable` ON `$dbThisTable`.`whatid`= `$dbItemsTable`.`id` ";
    
    // make a pre-query to get total list of results 
    // get prequery for ratings
    $xtraFields="";

    // extra filtering to get only approved values 
    if ( $action=="load"){
      $f_stub = " `$dbThisTable`.`status` IN ('40','45','46')  ";
      if ($f_stub) $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
    }
    $filterfull = $filter;

    // if ($f_stub) $filterfull =($filter=="") ? $filter." WHERE $f_stub " : $filter." AND $f_stub "; 

    
    // --- make the FULL PREQUERY  query 
    $resultfull = $dbb->count(DB_TABLE_ALERTS, str_replace('WHERE', '', $filterfull)); 
    $maxresults = $resultfull; // save for logging
    
    //-- make the FINAL  query
    $queryItem = "SELECT `$dbThisTable`.* ,`$dbUsersTable`.`username`,  `$dbUsersTable`.`protype`, `$dbUsersTable`.`avatarimg`, `$dbUsersTable`.`gender` FROM `$dbThisTable` ".$join .$filter." ". $sql_group. " ". $sql_sort . " " . $limit ; 
    // $result = mysql_query($query);
    // $totnbrofresults = mysql_num_rows($result);
    $idx=0;
    $resultItem = $dbb->fetchAll($queryItem); 

    if ($resultItem){
      $totnbrofresults = $resultItem['nb']; 
      $loglist = $resultItem['data']; 
      if ($action=="load" && !$curuser_is_admin && !$curuser_is_owner)  $view_mode = 'short';
    } 
    $success=true;

  }

 // ----------- LOG DELETION ----------------------
  else if ($action=='purgedeleted') 
  {
    // must be adminonly
    // delete all elements with status = 80  
    $result = $dbb->delete(DB_TABLE_ALERTS,   "  `status` = '80' "); 
    if ($result){
      $message="Yay! Everything went well!";
    }else {
      $message="nothing to delete";
    }
  }

  // ----------- LOG DELETION ----------------------
  else if ($action=='delete') 
  {

    // make the delete action either on whole conversastion on on single id
    if (!$ftype) $ftype=$type; // done for response in JSON

      // manage dates : 
      if ($ftype=="conv") $xfield=""; 
      else $xfield= " `moddate` = '".$now."' , ";

      if (isset($_POST["id"])) {

        $result = $dbb->update(DB_TABLE_ALERTS,  ["status"=>'80', "moddate"=>$now ] , " `id` = $id"); 
        
        if (!$result)  { 
          $msg = "Doh! Something happened : ";
          $success=false;
        } else {
          $msg = "Yay! Everything went well!";
        }
      }

  } 

  else if ($action=='trash') 
  {
    // delete definitively the element 
    if (!$ftype) $ftype=$type; // done for response in JSON
    // $result = $dbb->delete(DB_TABLE_ALERTS,   "  `id` = $id AND `status` = '80' "); 
    $result = $dbb->delete(DB_TABLE_ALERTS,   "  `id` = $id "); 
    $success= true;
    if ($result){
      $message="Yay! Everything went well!";
    }else {
      $message="nothing to delete";
    }

  } 
  //----- CREATE/MODIFY/DELETE action -----------------------------
  else if (($action=="create") || ($action=="publish")|| ($action=="unpublish")

    )
  {

    if (!$ftype) $ftype=$type; // done for response in JSON

    // -- BUILD THE QUERY 
    //---- CREATE action ----------------

    if (($action=="create") ) { 

      
      // extra filtering to get only approved values 
      $filterfull=""; 
      $f_stub = " `$dbThisTable`.`status` IN ('40','45','46')  ";
      $filterfull.=($filterfull=="") ? " WHERE $f_stub " : " AND $f_stub ";       
      $f_stub = " `$dbThisTable`.`userid` =  '$curuserid' ";
      $filterfull.=($filterfull=="") ? " WHERE $f_stub " : " AND $f_stub "; 
      
      $resultfull = $dbb->count(DB_TABLE_ALERTS, str_replace('WHERE', '', $filterfull)); 
      if ($resultfull>= ALERT_MAX_PER_USER) {
        $success=false ; 
        $msg ="exceeding max number of alerts per user"; 
      } else {

        // protection 
        if ($title=="") { $noQuery=true;  $success=false ; $msg="missing title or parameters"; }
        else {
          $filterparams = process_params($_POST); 
          $filterparams = json_encode($filterparams);
          $expiredate = date( 'Y-m-d H:i:s',  time() + (ALERT_EXPIRE_AFTER_DAYS*24*60*60) );
          $result = $dbb->insert(DB_TABLE_ALERTS,  ["createdate"=>$now, "moddate"=>$now,  "expiredate"=>$expiredate, "title"=>$title, "description"=>$description, "userid"=>$curuserid, "status"=>'40',"filterparams"=>$filterparams, "type"=>'']);
          $ftype=$type;
          $fadid =$adid;
          // $id= mysql_insert_id(); 
          $trace.='| Getting ID';
        }
      }
    }


    // publish and unset ABUSE 
    if ($action =="publish"){
      $result = $dbb->update(DB_TABLE_ALERTS,  ["status"=>'40', "moddate"=>$now ] , " `id` = $id"); 
    }


    // remove from publishing 
    if ($action =="unpublish"){
      $result = $dbb->update(DB_TABLE_ALERTS,  ["status"=>'60', "moddate"=>$now ] , " `id` = $id"); 
    }

    // -- OUTPUT RESULTS 
    
    
  } // end of ALL 

    


    // -- output result ------------- 
    $json = array(
        'success' => $success,
        'totnb' =>$maxresults,
        'message'=> $msg,
        'action' => WHATS,
        'subaction' => $action,
        'what' => $what,
        'nav'=>$nav,
        'sort'=>$sortoriginal,
        'paged' => $paged,
        'eppage'=>$eppage,
        'search'=>$search,
        'faction'=>$faction,
        'ftype'=>$ftype,
        'focusid'=>$focusid,
        'id' => $id,
        'comid' => $comid,
        'toid'=>$toid,
        'inlinefor'=>$inlinefor,
        'fadid' => $fadid,
        'counters'=>$counters,
        'sendmode'=>$_POST["sendmode"],
        'data' => $loglist
    );

 if ($debug_tmp==1){ // add debug info into the stream when working local

  $query = $dbb->get_log();
  $trace .= $dbb->get_logtime();

     $json["xdebug"]= array(
              'lastquery'=> $query,
              'filterparams'=>$filterparams,
              'filter'=>$filter,
              'filterfull'=>$filterfull,
              'curuserid'=>$curuserid,
              'curuser_id'=>$curuser_id,
              'curuser_type'=>$curuser_type,
              'curuser_is_admin'=>$curuser_is_admin, 
              'curuser_is_owner'=>$curuser_is_owner, 
              'id'=>$id, 
              'cookietxt'=>$cookietxt,
              'cokVal'=>$cokVal,
              'userdetails'=>$user_details,
              'trace'=>$trace,
              'datas_for_email'=>$datas_for_email,
              '$_SESSION'=>$_SESSION,
              // '$result'=>$result,
              '$result4'=>$result4,
              'resultItem'=>$resultItem
              );  
   }
  encode_json_and_send_with_compression($json);   
}
else {
  exit ('hi from '.basename($_SERVER["SCRIPT_FILENAME"]));
}


function process_params($post) {
  $paramsAr=array();

  foreach( $post as $stuff => $val ) {

    if ((strpos($stuff, "f") === 0) || (strpos($stuff, "q") === 0)) $paramsAr[$stuff]=$val; 
    // if( is_array( $stuff ) ) {
    //     foreach( $stuff as $thing) {
    //         echo $thing;
    //     }
    // } else {
    //     echo $stuff;
    //     echo $val;
    // }
    

  }
  return $paramsAr; 

} 


function exit_with_error($error_msg, $error_code=0){
  $json = array(
    'success' => false,
    'code'=>$error_code, 
    'message'=>$error_msg
  );
  encode_json_and_send_with_compression($json);  
  exit(); 
}

?>