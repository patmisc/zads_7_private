<?php

/******************************************************************************
 * ZADS PRELOADING CODE to be used for all services 
 * @category   Class
 * @package    ZADS
 * @author     Patrice COHAUT <patrice.cohaut@gmail.com>
 * @copyright  2016 PATMISC
 * @version    7.5
 * @link       https://www.zads.fr
 * @notes      
 ******************************************************************************/

// global variables
$t0=microtime(true); 
$timing_trace= ""; 

// PATHs
require_once("multitenants_settings.php");
define("DIR_LIBS", 'inc/');
define("DIR_SETTINGS", $SETTINGS_PATH);

// set default timezone 
date_default_timezone_set('Europe/Paris');

// shared functions 
require_once('functions.php');

// set general actions / security
unregisterGlobals(); 

// configuration loading in VAR and CONST mode 
require_once(DIR_SETTINGS."db_settings.php");  
require_once(DIR_SETTINGS."settings.php");
file_convert_var_2_const(DIR_SETTINGS."db_settings.php");  
file_convert_var_2_const(DIR_SETTINGS."settings.php"); 

// load LOCALE elements 
require_once("localization.php");   
require_once(DIR_SETTINGS."home_settings_".$cust_lang_long.".php");

// Local essential classes for debug and DB managemen
require_once(DIR_LIBS.'db_class.php'); 
require_once(DIR_LIBS.'debug_logs_class.php'); 

// set custom errors and execution handlers
// ERROR reporting level 
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING | E_DEPRECATED));	
set_error_handler('zads_error_handler');
set_exception_handler('zads_uncatched_exception_handler'); //only for uncatched exceptions


// initialize default OBJECTS 
$debug = new debugClass([
		  'debug_level' => DEBUG_LEVEL
	    , 'enable_debug_mode' => ENABLE_DEBUG_MODE
	    , 'html_mode'=>true
]); 


$dbb = new dbClass([
	    'database_type' => 'mysql'
	    ,'database_name' => DB_NAME
	    ,'server' => DB_HOST
	    ,'username' => DB_USERNAME
	    ,'password' => DB_PASSWORD
	    ,'prefix' => DB_PREFIX
	    ,'charset' => 'utf8'
	    ,'option' => [
			PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
			PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
		]
]);


// http://be2.php.net/manual/fr/errorfunc.constants.php
function zads_error_handler($no, $str, $file, $line){

	$h=''; $h1='';$h2=''; $status="ERROR"; 

    switch($no){
        // Erreur fatale
        case E_USER_ERROR:
            $h1.= '<strong>USER fatal error</strong> : ';           
            break;

        // Erreur fatale
        case E_ERROR:
            $h1.= '<strong>PHP fatal error</strong> : '; 
            die;            
            break;

        // Erreur fatale
        case E_PARSE:
            $h1.= '<strong>PHP PARSE error</strong> : '; 
            die;            
            break;
        
        // Avertissement
        case E_USER_WARNING:
            $h1.= '<strong>USER warning</strong> : ';
            $status="WARNING"; 
            break;
        
        // Note
        case E_USER_NOTICE:
            $h1.= '<strong>USER NOTICE</strong> : ';
            $status="NOTICE"; 
            break;

        // Avertissement
        case E_WARNING:
            $h1.= '<strong>PHP WARNING</strong> : ';
            $status="WARNING"; 
            break;
        
        case E_NOTICE:
            $h1.= '<strong>PHP NOTICE</strong> : ';
            $status="NOTICE"; 
            break;
        // Erreur générée par PHP
        default:
            $h1.= '<strong>ther error or notice </strong> [code='.$no.']';
            break;
    }

	$h2 = 'in file : "'.$file.'", line '.$line;

    $h = $h1.$str.'</br>'; 
    $h .= $h2.'</br></br>';
    echo $h; 

    $debug2 = new debugClass([
		  'debug_level' => 7
	    , 'enable_debug_mode' => true
	    , 'debugoutputfile'=> 'logs/errors.html'
	]); 
    $debug2->log($status, $h1.' ' .$str. ' '.$h2);
    $debug2->close();

}

function zads_uncatched_exception_handler(Exception $e){
    echo "!!!! Got an exception !!!";
    echo $e->getMessage(); // just the message
    echo '<table>'.$e->xdebug_message.'</table>' ; 
    // script is stopped here 
}
