<?php
/******************************************************************************
 * ZADS PAYPAL process using CLASSICAL API
 * 
 * Note :  works with SETTINGS.PHP file & LOCALIZATION.PHP
 *  
 * @category   CorePackage
 * @package    ZADS
 * @author     Patrice COHAUT <patrice.cohaut@gmail.com>
 * @copyright  2013-2014 PATMISC
 * @version    6.0
 ******************************************************************************/


/* Disable direct access.*/
// if(!strcasecmp(basename($_SERVER['SCRIPT_NAME']),basename(__FILE__))) 
// die('ZADS- Direct Access to this file not allowed!');

// load libraries 
require_once("multitenants_settings.php"); 
require_once($SETTINGS_PATH."db_settings.php");  
require_once($SETTINGS_PATH."settings.php");
require_once("localization.php");  


// set default timezone 
date_default_timezone_set('Europe/Paris');

$fullfqdn = $DOMAIN_FQDN; 

/*
	GOOD EXPLANATION OF THE PAYPAL EXPRESS CHECKOUT FLOW :   
	https://developer.paypal.com/webapps/developer/docs/classic/express-checkout/integration-guide/ECGettingStarted/
	https://developer.paypal.com/docs/classic/express-checkout/integration-guide/ECGettingStarted/

	GO LIVE MECANISM 
	https://developer.paypal.com/webapps/developer/docs/classic/lifecycle/goingLive/
*/


if ($PAYPAL_SANDBOX) {
	$paypal_environment = 'sandbox';	// or 'sandbox' or 'live'

	//--- PAYPAL SANDBOX CREDENTIALS - CLASSICAL API  / SANDBOX > Accounts > Profils > API credentials  
	$paypal_user= ""; 
	$paypal_password= ""; 
	$paypal_signature= ""; 

}
else {
	$paypal_environment = 'live';	// or 'sandbox' or 'live'
	//--- PAYPAL SANDBOX CREDENTIALS - CLASSICAL API  / SANDBOX > Accounts > Profils > API credentials  
	$paypal_user= $PAYPAL_USER; 
	$paypal_password= $PAYPAL_PASSWORD; 
	$paypal_signature= $PAYPAL_SIGNATURE; 


}
	

$fullfqdn2 = $fullfqdn; 

$paypal_url_success =$fullfqdn2."#/?paypal=success";
$paypal_url_cancel = $fullfqdn2."#/?paypal=cancel";

// example of type of return 
//http://www.zads.fr/ce-alu/#/?action=list&type=sell
// http://www.zads.fr/ce-alu//?#sucess/&token=EC-162960599H047222T&PayerID=3W4V956LY7VC2

//--- CURL SETTINGS 
$curl_timeout = 10; // CURL timeout in seconds
//$proxy_host = 'emea-proxy-pool.eu.alcatel-lucent.com:3128'; // host:port 
$proxy_host = ''; // use this for Home conbnection
$proxy_ident = ''; // username:password 

//--- General triage
$API_method=false; 
if (isset($_GET["method"])) $API_method = $_GET["method"];



function paypal_get_transaction_details($in_details){
	// DOC below :  
	//https://developer.paypal.com/webapps/developer/docs/classic/api/merchant/GetTransactionDetails_API_Operation_NVP/
	$paypal_request_ar= Array(
		'TRANSACTIONID'	=> $in_details["transactionid"]
	); 

	// Add request-specific fields to the request string.
	$nvpStr  =''; 
	foreach ($paypal_request_ar as $key => $value) {
	 $nvpStr  .="&$key=".urlencode($value); 
	}

	// Execute the API operation; see the PPHttpPost function above.
	$httpParsedResponseAr = PayPalHTTPPost('GetTransactionDetails', $nvpStr);
	//var_dump($httpParsedResponseAr);

	return $httpParsedResponseAr; 
}; 


function paypal_get_recuring_payment_details($in_details){
	// DOC below :  
	//https://developer.paypal.com/webapps/developer/docs/classic/api/merchant/GetTransactionDetails_API_Operation_NVP/
	$paypal_request_ar= Array(
		'PROFILEID'	=> $in_details["profileid"]
	); 

	// Add request-specific fields to the request string.
	$nvpStr  =''; 
	foreach ($paypal_request_ar as $key => $value) {
	 $nvpStr  .="&$key=".urlencode($value); 
	}

	// Execute the API operation; see the PPHttpPost function above.
	$httpParsedResponseAr = PayPalHTTPPost('GetRecurringPaymentsProfileDetails', $nvpStr);
	//var_dump($httpParsedResponseAr);

	return $httpParsedResponseAr; 
}; 


function paypal_call_checkout($in_checkout_details){

	global $paypal_url_success, $paypal_url_cancel; 
	global $paypal_environment; 
	global $LOGO_PAYPAL_FQDN; 
	global $SITE_NAME; 
	global $SITE_MOTTO; 
	global $lcur_user; // local current user type
	global $PAYPAL_FORCED_LOCALECODE ; // force the 5 chars local code for paypal 


	global $LOCALE_DEFAULT_CURRENCY; 
	global $LOCALE_DEFAULT_COUNTRY_CODE;
	// set protections
	if ($LOCALE_DEFAULT_CURRENCY) $paypalcurrencycode=$LOCALE_DEFAULT_CURRENCY; else $paypalcurrencycode="EUR"; // default


 	if ($PAYPAL_FORCED_LOCALECODE) $paypallocalecode=$PAYPAL_FORCED_LOCALECODE; 
 	else if ($LOCALE_DEFAULT_COUNTRY_CODE) $paypallocalecode=$LOCALE_DEFAULT_COUNTRY_CODE; else $paypallocalecode="FR"; // default


/* ---------------------------------- SETEXPRESS CHECKOUT -------------------*/				
	$paypal_request_ar= Array(
		'PAYMENTREQUEST_0_PAYMENTACTION'	=> 'Sale',  // or ' Authoriztion' or Sale' or 'Order'
		'PAYMENTREQUEST_0_CURRENCYCODE'	=> $paypalcurrencycode, 
		'PAYMENTREQUEST_0_DESC' => $in_checkout_details["gendesc"],
		'PAYMENTREQUEST_0_INVNUM' => $in_checkout_details["invnum"], 
		// 'HDRIMG' => $LOGO_PAYPAL_FQDN,  // logo to be displayed for the transaction
		'LOGOIMG' => $LOGO_PAYPAL_FQDN,  // logo to be displayed for the transaction
		'BRANDNAME'=> $SITE_NAME.' - '.$SITE_MOTTO,
		'LOCALECODE' => $paypallocalecode,		// optional default paypal country site 
		'ALLOWNOTE' => "1" 
		// 'EMAIL'=> 'seller.email@gmail.com', // email of the BUYER for pre-fill
	); 

	// create the BOM  : 
	$i=0; $cumulamt=0; $cumultaxamt=0;
	// logfile('notice', '{paypal_call_checkout} lcuruser= '.print_r($lcur_user, true));


	if (($lcur_user && $lcur_user['protype']=="pro") || ($in_checkout_details['protype']=="pro")) $posttxt = " (HT) "; else $posttxt=" (TTC) "; 

	foreach ($in_checkout_details["bom"] as $key => $bomitem) { 

		if ($bomitem['isrecurrent']=="yes") {
			logfile('debug', '{paypal_call_checkout} : RECURRENT PAYMENTS detected : isrecurrent= '.$bomitem['isrecurrent'].' description='.$bomitem['name']); 
			// recurrent payments detected 
			// make the special call to PAYPAL			
			$paypal_request_ar["L_BILLINGTYPE0"] = "RecurringPayments";
			$paypal_request_ar["L_BILLINGAGREEMENTDESCRIPTION0"] = $bomitem["name"];
			$paypal_request_ar["MAXAMT"] = $bomitem["999"];
			// set the price of this first transaction 
			//$cumulamt += floatval($bomitem["price"]);
			//$cumultaxamt += floatval('0');
			$cumulamt=0; 

		} else {
			// one shot payments 
			$paypal_request_ar["L_PAYMENTREQUEST_0_NAME".$i] = $bomitem["name"].$posttxt;
			$paypal_request_ar["L_PAYMENTREQUEST_0_NUMBER".$i] = $bomitem["oi"];
			$paypal_request_ar["L_PAYMENTREQUEST_0_DESC".$i] =  substr($bomitem["desc"],0,126);    
			$paypal_request_ar["L_PAYMENTREQUEST_0_QTY".$i] = $bomitem["qty"]; 

			// normalize prices in US format 
			$itemprice = strval($bomitem["price"]);
	    	$itemprice = str_replace(',', '.', $itemprice);
			$paypal_request_ar["L_PAYMENTREQUEST_0_AMT".$i] = $itemprice; 
			//$paypal_request_ar["L_PAYMENTREQUEST_0_ITEMCATEGORY".$i] = "Digital";
			// $paypal_request_ar["L_PAYMENTREQUEST_0_TAXAMT".$i] = '0'; 

			$i+=1; 
			$cumulamt += floatval($bomitem["price"]);
			$cumultaxamt += floatval('0');
			// for debug purpose  : 
			//$cumulamt=0;
		}
	}

	$cumulallamt = $cumulamt+$cumultaxamt; 
	$cumulallamt = strval($cumulallamt);
    $cumulallamt = str_replace(',', '.', $cumulallamt);
	$paypal_request_ar["PAYMENTREQUEST_0_AMT"] = $cumulallamt; 
	logfile('info', '{paypal_call_checkout} : PAYMENTREQUEST_0_AMT = '.$cumulallamt); 

	// // convert the amount to a correct string '.' separator 
	//    $cumulamt = strval($cumulamt);
	//    $cumulamt = str_replace(',', '.', $cumulamt);	  
	// // $paypal_request_ar["PAYMENTREQUEST_0_AMT"] = $cumulamt; 
	// $paypal_request_ar["PAYMENTREQUEST_0_ITEMAMT"] =  $cumulamt;  
	// logfile('notice', 'PAYMENTREQUEST_0_ITEMAMT = '.$cumulamt);

	// update the VAT 
	$cumultaxamt = strval($cumultaxamt);
    $cumultaxamt = str_replace(',', '.', $cumultaxamt);	  
    // send this only if need to specify a tax ! 
	// $paypal_request_ar["PAYMENTREQUEST_0_TAXAMT"] = $cumultaxamt; 

	// update all cumults


	//var_dump($paypal_request_ar); 

	$returnURL = urlencode($paypal_url_success);
	$cancelURL = urlencode($paypal_url_cancel);

	// Add request-specific fields to the request string.
	$nvpStr  =''; 
	foreach ($paypal_request_ar as $key => $value) {
	 $nvpStr  .="&$key=".urlencode($value); 
	}

	$nvpStr .= "&ReturnUrl=$returnURL&CANCELURL=$cancelURL";
	//echo $nvpStr; 
	logfile('', '{paypal_call_checkout} : PARAMS = '.$nvpStr); 
	// Execute the API operation; see the PPHttpPost function above.
	$httpParsedResponseAr = PayPalHTTPPost('SetExpressCheckout', $nvpStr);
	//var_dump($httpParsedResponseAr);

	// when sucess, return the following code 
	// array (size=6)
	//   'TOKEN' => string '
	//   'TIMESTAMP' => string '2013%2d05%2d05T12%3a37%3a23Z' (length=28)
	//   'CORRELATIONID' => string '497027d9a61d6' (length=13)
	//   'ACK' => string 'Success' (length=7)
	//   'VERSION' => string '98%2e0' (length=6)
	//   'BUILD' => string '5817241' (length=7)
	//

	if("SUCCESS" == strtoupper($httpParsedResponseAr["ACK"]) || "SUCCESSWITHWARNING" == strtoupper($httpParsedResponseAr["ACK"])) {
		// Redirect to paypal.com.
		$token = urldecode($httpParsedResponseAr["TOKEN"]);
		$payPalURL = "https://www.paypal.com/webscr&cmd=_express-checkout&token=$token";
		if("sandbox" === $paypal_environment || "beta-sandbox" === $paypal_environment) {
			$payPalURL = "https://www.$paypal_environment.paypal.com/webscr&cmd=_express-checkout&token=$token";
		}
		
		//header("Location: $payPalURL"); // redirect to the right location 
		//exit("Location: $payPalURL");
		$httpParsedResponseAr["CUSTO_REDIRECT_LOCATION"] = $payPalURL; 
		$httpParsedResponseAr["CUSTO_SUCCESS"] = true; 
		$httpParsedResponseAr["CUSTO_TOKEN"] = $token; 
		logfile('', '{paypal_call_checkout} : SUCCESS  / TOKEN = '. $token . ' / REDIRECT URL = '.$payPalURL);

		
	} else  {
		//exit('SetExpressCheckout failed: ' . print_r($httpParsedResponseAr, true));
		$httpParsedResponseAr["REDIRECT_LOCATION"] = false; 
		$httpParsedResponseAr["CUSTO_SUCCESS"] = false; 
		logfile('ERROR', '{paypal_call_checkout} : ERROR PAYPAL when calling with PARAMS = '.$nvpStr); 
	}
	return $httpParsedResponseAr; 


}


function  paypal_do_checkout($in_checkout_details){
	// global $lcur_user; // local current user type

	/* ---------------------------------- SETEXPRESS CHECKOUT -------------------*/

		/*
	METHOD : DoExpressCheckoutPayment 
	MANDARIRY fields : 
	TOKEN : // payment amount
	PAYMENTREQUEST_0_PAYMENTACTION : // payment action 
	'PAYMENTREQUEST_0_CURRENCYCODE'	=> 'EUR', 
	'PAYMENTREQUEST_0_AMT' =>'4.00'
	PAYERID :3W4V956LY7VC2 // can be taken from the HTTP GET PARAMTERS
	*/
				
	// request_array 
	//https://developer.paypal.com/webapps/developer/docs/classic/api/merchant/DoExpressCheckoutPayment_API_Operation_NVP/	// compatible for version 99 (feb 2013)

	global $LOCALE_DEFAULT_CURRENCY; 
	// set protections
	if ($LOCALE_DEFAULT_CURRENCY) $paypalcurrencycode=$LOCALE_DEFAULT_CURRENCY; else $paypalcurrencycode="EUR"; // default


	// convert , in. for amounts in case of...
	$in_checkout_details['amt'] = strval($in_checkout_details['amt']);
    $in_checkout_details['amt'] = str_replace(',', '.', $in_checkout_details['amt']);


    // ::'USESESSIONPAYMENTDETAILS' => "1" 

	$paypal_request_ar= Array(
		'PAYMENTREQUEST_0_PAYMENTACTION'	=> 'Sale',
		'PAYMENTREQUEST_0_CURRENCYCODE'	=> $paypalcurrencycode, 
		'TOKEN'	=> $in_checkout_details['token'],
		'PAYERID'=> $in_checkout_details['PayerID'],
		'PAYMENTREQUEST_0_AMT' =>$in_checkout_details['amt'],
		'USESESSIONPAYMENTDETAILS'=>1
		
	);

	logfile('info', '{paypal_do_checkout} : TOKEN = '.$in_checkout_details['token'].' , AMOUNT='.$in_checkout_details['amt']); 

	// add the datails if ITEMS if indicated

	if ($in_checkout_details['protype']=="pro") $posttxt = " (HT) "; else $posttxt=" (TTC) "; 

	if ($in_checkout_details['bom']){
		// extart STR to Array 
		$bomAr = parseStrToArr($in_checkout_details['bom']);	
		$i=0; 	
		foreach ($in_checkout_details["bom"] as $key => $bomitem) { 
			$paypal_request_ar["L_PAYMENTREQUEST_0_NAME".$i] = $bomitem["name"].$posttxt;
			$paypal_request_ar["L_PAYMENTREQUEST_0_NUMBER".$i] = $bomitem["oi"];
			$paypal_request_ar["L_PAYMENTREQUEST_0_DESC".$i] = substr($bomitem["desc"],0,126); 
			$paypal_request_ar["L_PAYMENTREQUEST_0_QTY".$i] = $bomitem["qty"]; 

			// normalize prices in US format 
			$itemprice = strval($bomitem["price"]);
	    	$itemprice = str_replace(',', '.', $itemprice);
	    	
			$paypal_request_ar["L_PAYMENTREQUEST_0_AMT".$i] = $itemprice; 
			$i+=1; 
		}	
	}

	// Add request-specific fields to the request string.
	$nvpStr  =''; 
	foreach ($paypal_request_ar as $key => $value) {
	 $nvpStr  .="&$key=".urlencode($value); 
	}

	logfile('', '{paypal_do_checkout} : PARAMS = '.$nvpStr); 

	// Execute the API operation; see the PPHttpPost function above.
	$httpParsedResponseAr = PayPalHTTPPost('DoExpressCheckoutPayment', $nvpStr);

	// ineresting fields: 
	// PAYMENTREQUEST_0_TRANSACTIONID  : get the transaction id 
	// ACK  : Success or SucessWithWarning
	// PAYMENTINFO_0_ACK : 0 f ok

	return $httpParsedResponseAr; 

}


// $testAr= Array('token'	=> "EC-83T19524DA671751V"); 
// var_dump(paypal_get_checkoutdetails($testAr)); 
// paypal_create_recurring_payment_profile(1); 


function  paypal_create_recurring_payment_profile($in_checkout_details){


	// // debug 


	global $LOCALE_DEFAULT_CURRENCY; 
	// set protections
	if ($LOCALE_DEFAULT_CURRENCY) $paypalcurrencycode=$LOCALE_DEFAULT_CURRENCY; else $paypalcurrencycode="EUR"; // default


	/* ---------------------------------- SETEXPRESS CHECKOUT -------------------*/
	// https://developer.paypal.com/docs/classic/api/merchant/CreateRecurringPaymentsProfile_API_Operation_NVP/
	// convert , in. for amounts in case of...
	logfile('info', '{paypal_create_recurring_payment_profile} : TOKEN = '.$in_checkout_details['token']); 

	// return false; // exit for tests

	$in_checkout_details['amt'] = strval($in_checkout_details['amt']);
    $in_checkout_details['amt'] = str_replace(',', '.', $in_checkout_details['amt']);

    // call teh checkout details to get details on PAYERID 
    $checkoutdetailsAr = paypal_get_checkoutdetails($in_checkout_details); 
    // var_dump($checkoutdetailsAr); 
    // logfile('info', '{paypal_create_recurring_payment_profile} : Result from checkdetails  : ACK / PAYERID  = '.$checkoutdetailsAr['ACK'].' | PAYERID='.$checkoutdetailsAr['PAYERID']); 

    // start date of the subscription 
    $DaysTimestamp = strtotime('now');
	$Mo = date('m', $DaysTimestamp);
	$Day = date('d', $DaysTimestamp);
	$Year = date('Y', $DaysTimestamp);
	$StartDateGMT = $Year . '-' . $Mo . '-' . $Day . 'T23:59:59\Z';

    // ::'USESESSIONPAYMENTDETAILS' => "1" 
	$paypal_request_ar= Array(
		'CURRENCYCODE'	=> $paypalcurrencycode, 
		'TOKEN'	=> $in_checkout_details['token'],
		'PAYERID'	=> $checkoutdetailsAr['PAYERID'],
		'MAXFAILEDPAYMENTS'	=> '3', 
		'AUTOBILLOUTAMT'=>'AddToNextBilling' 
	); 


	// add the datails if ITEMS if indicated

	if ($lcur_user && $lcur_user['protype']=="pro") $posttxt = " (HT) "; else $posttxt=" (TTC) "; 

	if ($in_checkout_details['bom']){
		// extart STR to Array 
		$bomAr = parseStrToArr($in_checkout_details['bom']);	
		$i=0; 	
		$bomitem = $in_checkout_details["bom"][$i]; // just take the first item 

		// $paypal_request_ar["L_PAYMENTREQUEST_0_NAME".$i] = $bomitem["name"].$posttxt;
		// $paypal_request_ar["L_PAYMENTREQUEST_0_NUMBER".$i] = $bomitem["oi"];
		// $paypal_request_ar["L_PAYMENTREQUEST_0_DESC".$i] = $bomitem["desc"];    
		// $paypal_request_ar["L_PAYMENTREQUEST_0_QTY".$i] = $bomitem["qty"];
		// $paypal_request_ar["L_PAYMENTREQUEST_0_ITEMCATEGORY".$i] = 'Digital';

		// normalize prices in US format 
		$itemprice = strval($bomitem["price"]);
    	$itemprice = str_replace(',', '.', $itemprice);
		// $paypal_request_ar["L_PAYMENTREQUEST_0_AMT".$i] = $itemprice; 


		// general parameters
		$paypal_request_ar["DESC"] = $bomitem["name"];
		$paypal_request_ar["BILLINGPERIOD"] = $bomitem["billingperiod"];
		$paypal_request_ar["BILLINGFREQUENCY"] = $bomitem["billingfrequency"];
		// &PROFILESTARTDATE:20XX-03-05T03:00:00
		$paypal_request_ar["PROFILESTARTDATE"] = $StartDateGMT;
		$paypal_request_ar["AMT"] = $itemprice; 

	}

	// Add request-specific fields to the request string.
	$nvpStr  =''; 
	foreach ($paypal_request_ar as $key => $value) {
	 $nvpStr  .="&$key=".urlencode($value); 
	}

	logfile('', '{paypal_create_recurring_payment_profile} : NVP parameters = '.$nvpStr); 

	// Execute the API operation; see the PPHttpPost function above.
	$httpParsedResponseAr = PayPalHTTPPost('CreateRecurringPaymentsProfile', $nvpStr);

	// complement with DESC which should be used later
	$httpParsedResponseAr['DESC'] = $paypal_request_ar["DESC"] ;
	$httpParsedResponseAr['AMT'] = $paypal_request_ar["AMT"] ; 
	$httpParsedResponseAr['CURRENCYCODE'] = $paypal_request_ar["CURRENCYCODE"] ; 


	// Response
	// --------
	// PROFILEID=I%2d6D5UGCVX1234
	// &PROFILESTATUS=ActiveProfile
	// &ACK=Success

	return $httpParsedResponseAr; 

}



function paypal_get_checkoutdetails($in) {

	$paypal_request_ar= Array(
			'TOKEN'	=> $in['token']
		); 
	// logfile('info', '{paypal_get_checkoutdetails} : TOKEN = '.$in['token']); 

	// Add request-specific fields to the request string.
	$nvpStr  =''; 
	foreach ($paypal_request_ar as $key => $value) {
	 $nvpStr  .="&$key=".urlencode($value); 
	}

	// Execute the API operation; see the PPHttpPost function above.
	$httpParsedResponseAr = PayPalHTTPPost('GetExpressCheckoutDetails', $nvpStr);

	// ineresting fields: 
	// Response
	// --------
	// TOKEN=token_value
	// &BILLINGAGREEMENTACCEPTEDSTATUS=1
	// &ACK=Success
	// &PAYERID=3TXTXECKF1234
	return $httpParsedResponseAr; 

}; 


function PayPalHTTPPost($methodName_, $nvpStr_) {
	global $paypal_environment;
	global $paypal_user; 
	global $paypal_password; 
	global $paypal_signature;
	global $curl_timeout; 
	global $proxy_host; 
	global $proxy_ident; 


	// Set up your API credentials, PayPal end point, and API version.
	$API_UserName = urlencode($paypal_user);
	$API_Password = urlencode($paypal_password);
	$API_Signature = urlencode($paypal_signature);
	$API_Endpoint = "https://api-3t.paypal.com/nvp";

	/*
	https://api-3t.paypal.com/nvp 
	https://api-3t.sandbox.paypal.com/nvp
	*/

	if("sandbox" === $paypal_environment || "beta-sandbox" === $paypal_environment) {
		$API_Endpoint = "https://api-3t.$paypal_environment.paypal.com/nvp";
	}
	$version = urlencode('98.0');

	// Set the curl parameters.
	$ch = curl_init();

	curl_setopt($ch, CURLOPT_URL, $API_Endpoint);
	curl_setopt($ch, CURLOPT_VERBOSE, 1);


	if ($curl_timeout){
	curl_setopt($ch, CURLOPT_FRESH_CONNECT, true); 
	curl_setopt($ch, CURLOPT_TIMEOUT, $curl_timeout); 
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $curl_timeout); 
	}

	// Activation de l'utilisation d'un serveur proxy // Définition de l'adresse du proxy 
	if ($proxy_host){
	curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, true); 
	curl_setopt($ch, CURLOPT_PROXY, $proxy_host); 
	if ($proxy_ident)  curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxy_ident); 
	}


	// Turn off the server and peer verification (TrustManager Concept).
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POST, 1);

	// Set the API operation, version, and API signature in the request.
	$nvpreq = "METHOD=$methodName_&VERSION=$version&PWD=$API_Password&USER=$API_UserName&SIGNATURE=$API_Signature$nvpStr_";

	// Set the request as a POST FIELD for curl.
	curl_setopt($ch, CURLOPT_POSTFIELDS, $nvpreq);

	// Get response from the server.
	$httpResponse = curl_exec($ch);

	if(!$httpResponse) {
		exit("$methodName_ failed: ".curl_error($ch).'('.curl_errno($ch).')');
	}

	logfile('', '{PayPalHTTPPost} : response from paypal method =  '.$httpResponse); 

	// Extract the response details.
	$httpResponseAr = explode("&", $httpResponse);

	$httpParsedResponseAr = array();
	foreach ($httpResponseAr as $i => $value) {
		
		// logfile('', '{PayPalHTTPPost} : explodedvalue =  '.$value); 
		// special patch for bloody PAYPAL return value ! 
		if (strpos($value,'TOKEN') !== false) $value= substr($value,strpos($value,'TOKEN')); 
		// logfile('', '{PayPalHTTPPost} : explodedvalue =  '.$value); 
		$tmpAr = explode("=", $value);
		if(sizeof($tmpAr) > 1) {
			// special patch for blooding PAYPAL API ! 
			$httpParsedResponseAr[$tmpAr[0]] = $tmpAr[1];
		}
	}

	if((0 == sizeof($httpParsedResponseAr)) || !array_key_exists('ACK', $httpParsedResponseAr)) {
		exit("Invalid HTTP Response for POST request($nvpreq) to $API_Endpoint.");
	}

	return $httpParsedResponseAr;
}






?>