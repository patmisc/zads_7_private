<?php

/******************************************************************************
 * ZADS CLASS for managing debug and logs  
 * @category   Class
 * @package    ZADS
 * @author     Patrice COHAUT <patrice.cohaut@gmail.com>
 * @copyright  2016 PATMISC
 * @version    1.0
 * @link       https://www.zads.fr
 * @notes      
 ******************************************************************************/

/*** HOW TO USE IT *************************************************************
	require_once(DIR_LIBS.'debug_logs_class.php'); 
	
	$debug = new debugClass([
		  'debug_level' => DEBUG_LEVEL (optional)
	    , 'enable_debug_mode' => ENABLE_DEBUG_MODE (optional)
	    , 'html_mode'=>true (optional)
	    , 'debugoutputfile'=> 'logs/xxx.xxx' (optional)
	]); 

	$debug->log("coucou"); // default mesage set as DEBUG  
	$debug->log('INFO', 'info message');
	$debug->log('PANIC', 'panic message'); 
	$debug->log('WARNING', 'warning message');
	
	$debug->cleardebugfile();

	>> for tracking time   
	$debug->logtime('message');
	$debug->get_logtime();
	$debug->reset_logtime()

	var_dump($debug->info());
 ******************************************************************************/

class debugClass 
{

	// General
	protected $debug_level=  0 ;
	protected $debugoutputfile= "logs/logs.html";
	protected $enable_debug_mode=true; // true to enable 
	protected $html_mode=true; // html of plain text 
	protected $separator=' - '; // separator 

	protected $debugfileHandler=false; 

	// for time logs
	protected $timing_trace = ''; 
	protected $t0; 

	public function __construct($options = null)
	{

		if (defined('DEBUG_LEVEL')) $debug_level= DEBUG_LEVEL;
		if (defined('ENABLE_DEBUG_MODE')) $enable_debug_mode= ENABLE_DEBUG_MODE;

		if (is_array($options)) {
			foreach ($options as $option => $value){
					$this->$option = $value;
			}
		}
		else { return false; }
		
		if ($this->debugoutputfile) {
		  // debug output file 
			if ( !file_exists($this->debugoutputfile) ) {
        		trigger_error( "File not found : ".$this->debugoutputfile, E_USER_ERROR);
      		} 
		    $this->debugfileHandler = fopen($this->debugoutputfile,"a"); 
			if(! $this->debugfileHandler) { 
				trigger_error( "Error opening to the output file :".$this->debugoutputfile, E_USER_ERROR);
			}
		}
	}
	// -- end construct 

	public function log($status, $msg=null)
	{
	  	// status per SYSLOG definition 
	  	// PANIC (0) | ALERT (1) | CRTI (2) | ERROR (3) | WARNING (4) | NOTICE (5) | INFO (6) | DEBUG (7)
	  	$debug_matrix =  array (
	      "PANIC" => 0, "ALERT" => 1, "CRTI" => 2, "ERROR" => 3, "WARNING" => 4, "NOTICE" => 5, "INFO" => 6, "DEBUG" => 7
	      );
	  	$style =""; $disp_status=""; 
	  	$_SEPARATOR=$this->separator; // separator 
		if (is_null($msg)) { $msg=$status ;$status="DEBUG" ; }


		if ($this->enable_debug_mode) {

		    if ($status=="") $status="DEBUG"; 

		    if (in_array(strtolower($status), array('panic', 'alert', 'crti', 'error')))  $style="color:red;";
		    if (in_array(strtolower($status), array('warning', 'notice')))  $style="color:orange;";
			if (in_array(strtolower($status), array('info')))  $style="color:blue;";

		    if ($this->html_mode) $hm = '<div style="'.$style.'">'; 
		    if ($this->html_mode) $hm .= "<span class='date' style='font-size:0.8em;'>".date('Y-m-d H:i:s',time()).'</span>'; 
		    else $hm .= date('Y-m-d H:i:s',time()); 

		    $hm .= $_SEPARATOR; 
		    $hm .=  strtoupper($status); 
		    $hm .= $_SEPARATOR; 
		    $hm .= $msg;
		    if ($this->html_mode) $hm .= "</div>";
		    $hm .= "\n"; 


		    // final write to file if level if higher
		    if ( $debug_matrix[strtoupper($status)]  <= intval($this->debug_level)) { 
		      fwrite($this->debugfileHandler,$hm);
		    }
	  	}
	  return true; 
	}

	public  function cleardebugfile() 
	{
		// close the file if open	
		if ($this->debugfileHandler) fclose($this->debugfileHandler); 
        
		// open it in write mode
       	$this->debugfileHandler = fopen($this->debugoutputfile,"w"); 
        if(! $this->debugfileHandler) { 
        	trigger_error( "Error opening to the output file :".$this->debugoutputfile, E_USER_ERROR);
        }
        else {
          $this->log('INFO', 'File clearer upon request');
        }
        fclose($this->debugfileHandler); 
        // reopen it in append mode 
        $this->debugfileHandler = fopen($this->debugoutputfile,"a"); 
		if(! $this->debugfileHandler) { 
        	trigger_error( "Error opening to the output file :".$this->debugoutputfile, E_USER_ERROR);
        }
    }



    public function close(){
    	fclose($this->debugfileHandler); 
    }

	public function info()
	{
		$output = array(
			'enable_debug_mode' => $this->enable_debug_mode
			,'debug_level' => $this->debug_level
			,'html_mode' => $this->html_mode
			,'separator'=>$this->separator
			,'debugoutputfile' => $this->debugoutputfile
			,'debug_file_size'=> human_filesize(filesize($this->debugoutputfile))
			,'timing_trace'=>$this->timing_trace
		);

		return $output;
	}

	public function logtime($msg){
	  $deltatime= (microtime(true)-$this->t0); 
	  $this->timing_trace.= "|$msg ".sprintf("%01.3f", $deltatime). "s "; 
	  $this->t0=microtime(true); 
	  return true;
	}

	public function get_logtime()
	{
		return $this->timing_trace;
	}

	public function reset_logtime()
	{
		return $this->timing_trace=''; 
	}





} // -- end class


?>