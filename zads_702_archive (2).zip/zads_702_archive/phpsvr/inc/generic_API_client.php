<?php
/******************************************************************************
 * GENERIC API client PHP for accessing APIs of third parties 
 * 
 *  
 * @category   CorePackage
 * @package    GENERIC FUNCTION PATMIC
 * @author     Patrice COHAUT <patrice.cohaut@gmail.com>
 * @copyright  2014 PATMISC
 * @version    1.0.0
 ******************************************************************************/

define("ENABLE_DEBUG_INFO", true); 

/**
 * Different AUTH method
 */
define("AUTH_TYPE_URI", 0);
define("AUTH_TYPE_AUTHORIZATION_BASIC", 1);
define("AUTH_TYPE_FORM", 2);

/**
 * Different Access token type
 */
define("ACCESS_TOKEN_URI",  0);   
define("ACCESS_TOKEN_BEARER",  1);
define("ACCESS_TOKEN_OAUTH", 2);
define("ACCESS_TOKEN_MAC", 3);

/**
* Different Grant types
*/
define("GRANT_TYPE_AUTH_CODE", 'authorization_code');
define("GRANT_TYPE_PASSWORD", 'password');
define("GRANT_TYPE_CLIENT_CREDENTIALS", 'client_credentials');
define("GRANT_TYPE_REFRESH_TOKEN", 'refresh_token');

/**
 * HTTP Methods
 */
define("HTTP_METHOD_GET", 'GET');
define("HTTP_METHOD_POST", 'POST');
define("HTTP_METHOD_PUT", 'PUT');
define("HTTP_METHOD_DELETE", 'DELETE');
define("HTTP_METHOD_HEAD", 'HEAD');

/**
 * HTTP Form content types
 */
define("HTTP_FORM_CONTENT_TYPE_APPLICATION", 0);
define("HTTP_FORM_CONTENT_TYPE_MULTIPART", 1);

$certificate_file = null;


if (isset($_GET["test"])){
    $access_token = $_GET["test"]; 
    $go_url = "https://www.googleapis.com/oauth2/v1/userinfo" ; 
    // $go_url = "https://www.googleapis.com/plus/v1/people/me"; // only of google+ API has been accepted into the console
    $go_params = array(
            'alt' => 'json',
            'access_token'     => $access_token
        );
    $r= gen_api_executeRequest($go_url, $go_params);
    var_dump($r); 
} 



// ##### test of PLIVO API

if (isset($_GET["plivo_send_sms"])){


    $auth_id = "MAMDFMYWQWMGRLNDM3NG";
    $auth_token =  $_GET["plivo_send_sms"];
    
    // https://www.plivo.com/docs/getting-started/send-a-single-sms/
    // The Message API also automatically splits long messages at 160 characters and concatenates them into a single SMS on the receiver’s end. 
    // Delivery reports are also automatically supported in networks where they are provided by the operator.
    $plivo_sms_url = "https://api.plivo.com/v1/Account/$auth_id/Message/" ; 



    $plivo_sms_params = array(
        'src' => '33388642390', // Sender's phone number with country code
        'dst' => '33676928622', // Receiver's phone number with country code
        'text' => 'Votre code de confirmation ZADS est le 1234567' // Your SMS text message
        // To send Unicode text
    );


    $r= simple_rest_client($plivo_sms_url, 'POST', $plivo_sms_params, array( $auth_id => $auth_token));
    var_dump($r); 

    /*
    PLIVO Sample output
    Response : Array
    (
        [api_id] => 6debfaec-a25e-11e4-96e3-22000abcb9af
        [message] => message(s) queued
        [message_uuid] => Array ( [0] => 6dffe3ea-a25e-11e4-a6e4-22000afa12b0 )
    )
    Api ID : 6debfaec-a25e-11e4-96e3-22000abcb9af
    Message UUID : 6dffe3ea-a25e-11e4-a6e4-22000afa12b0
    */


} 


if (isset($_GET["plivo_make_call"])){


    $auth_id = "MAMDFMYWQWMGRLNDM3NG";
    $auth_token =  $_GET["plivo_make_call"];
    

    $plivo_url = "https://api.plivo.com/v1/Account/$auth_id/Call/" ; 


    $plivo_params = array(
        'to' => '33676928622',   # The phone numer to which the call will be placed
        'from' => '33388642390', # The phone number to be used as the caller id

        # answer_url is the URL invoked by Plivo when the outbound call is answered
        # and contains instructions telling Plivo what to do with the call
        'answer_url' => "https://s3.amazonaws.com/static.plivo.com/answer.xml",
        'answer_method' => "GET", # The method used to call the answer_url

        # Example for asynchronous request
        # callback_url is the URL to which the API response is sent.
        #'callback_url' => "http://myvoiceapp.com/callback/",
        #'callback_method' => "GET" # The method used to notify the callback_url.
    );


    $r= simple_rest_client($plivo_url, 'POST', $plivo_params, array( $auth_id => $auth_token));
    var_dump($r); 

    /*
    PLIVO Sample output
    Response : Array
    (
        [api_id] => 6debfaec-a25e-11e4-96e3-22000abcb9af
        [message] => message(s) queued
        [message_uuid] => Array ( [0] => 6dffe3ea-a25e-11e4-a6e4-22000afa12b0 )
    )
    Api ID : 6debfaec-a25e-11e4-96e3-22000abcb9af
    Message UUID : 6dffe3ea-a25e-11e4-a6e4-22000afa12b0
    */


} 



if (isset($_GET["plivo_getdetails_sms"])){


    $auth_id = "MAMDFMYWQWMGRLNDM3NG";
    $auth_token =  $_GET["plivo_getdetails_sms"];
    $message_uuid =  $_GET["id"];
    
    // https://www.plivo.com/docs/getting-started/send-a-single-sms/
    // The Message API also automatically splits long messages at 160 characters and concatenates them into a single SMS on the receiver’s end. 
    // Delivery reports are also automatically supported in networks where they are provided by the operator.
    $plivo_sms_url = "https://api.plivo.com/v1/Account/$auth_id/Message/$message_uuid/" ; 

    $r= simple_rest_client($plivo_sms_url, 'GET', '', array( $auth_id => $auth_token));
    var_dump($r); 

    /*
    PLIVO Sample output
    Response : Array
        array (size=12)
      'api_id' => string 'c2291b1b-25dc-11e6-bcdd-22000ae40186' (length=36)
      'from_number' => string '33388642390' (length=11)
      'message_direction' => string 'outbound' (length=8)
      'message_state' => string 'delivered' (length=9)
      'message_time' => string '2016-05-29 22:32:26+02:00' (length=25)
      'message_type' => string 'sms' (length=3)
      'message_uuid' => string '74f24b4a-d10c-4dca-9e31-af30c98fc5ac' (length=36)
      'resource_uri' => string '/v1/Account/MAMDFMYWQWMGRLNDM3NG/Message/74f24b4a-d10c-4dca-9e31-af30c98fc5ac/' (length=78)
      'to_number' => string '33676928622' (length=11)
      'total_amount' => string '0.04200' (length=7)
      'total_rate' => string '0.04200' (length=7)
      'units' => int 1
    */

} 


// ipinfo.io/8.8.8.8
// const BASE_URL = "http://ipinfo.io/";
if (isset($_GET["checkip"])){
    $thisip =  $_GET["checkip"];
    $url = "http://ipinfo.io/$thisip" ; 
    $r= simple_rest_client($url, 'GET');
    var_dump($r); 


    // extract the good elements 
    // response = 
      // "ip": "8.8.8.8",
      // "hostname": "google-public-dns-a.google.com",
      // "city": "Mountain View",
      // "region": "California",
      // "country": "US",
      // "loc": "37.3860,-122.0838",
      // "org": "AS15169 Google Inc.",
      // "postal": "94040"


} 









// DEBUG PURPOSE ONLY 
// https://www.googleapis.com/oauth2/v1/userinfo?alt=json&access_token=ya29.SABrFe5oTW33AB0AAADCJz3mf49t6FrQQ-qk3J0E6QOObCUa2zz1ZYl1UbraRA
// $go_url = "https://www.googleapis.com/oauth2/v1/userinfo" ; 
// // $go_url = "https://www.googleapis.com/plus/v1/people/me"; // only of google+ API has been accepted into the console
// $go_params = array(
//             'alt' => 'json',
//             'access_token'     => "ya29.SABWmNP4sT1fzh0AAAAhml_1OAf5jZ33ei8PU6XGoCoWuAnoIFfoog1kzIVi6Q"
//         );
// $r= gen_api_executeRequest($go_url, $go_params);
// var_dump($r); 

// when OK
// array (size=3)
//   'result' => 
//     array (size=10)
//       'id' => string '118072644165107613328' (length=21)
//       'email' => string 'patrice.cohaut@gmail.com' (length=24)
//       'verified_email' => boolean true
//       'name' => string 'patrice cohaut' (length=14)
//       'given_name' => string 'patrice' (length=7)
//       'family_name' => string 'cohaut' (length=6)
//       'link' => string 'https://plus.google.com/+patricecohaut' (length=38)
//       'picture' => string 'https://lh4.googleusercontent.com/-vcu9G4xZ4JA/AAAAAAAAAAI/AAAAAAAAAVk/T1GWG0e_5nA/photo.jpg' (length=92)
//       'gender' => string 'male' (length=4)
//       'locale' => string 'fr' (length=2)
//   'code' => int 200
//   'content_type' => string 'application/json; charset=UTF-8' (length=31)


// when KO 
// array (size=3)
//   'result' => 
//     array (size=1)
//       'error' => 
//         array (size=3)
//           'errors' => 
//             array (size=1)
//               ...
//           'code' => int 401
//           'message' => string 'Invalid Credentials' (length=19)
//   'code' => int 401
//   'content_type' => string 'application/json; charset=UTF-8' (length=31)



function simple_rest_client($url, $method=HTTP_METHOD_GET, $parameters = array(), $basicAuth  = array())
{

    
    
    // $curl_log = fopen("curl.txt", 'w');

    $curl_options = array(
        CURLOPT_RETURNTRANSFER => true, //  Return response instead of printing.
        // CURLOPT_CUSTOMREQUEST  => $http_method,

        // CURLOPT_VERBOSE => true,        // Logs verbose output to STDERR
        // CURLOPT_STDERR  => $curl_log,   // Output STDERR log to file
        
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false, 

    );


    // set the URL 
    $orig_url=$url; // save original url
    $curl_options[CURLOPT_URL] = $url;

   
    switch($method) {
        case HTTP_METHOD_POST:
            $curl_options[CURLOPT_POST] = true;
            if (!empty($parameters)) {
                $parameters = json_encode($parameters);
                $curl_options[CURLOPT_POSTFIELDS]= $parameters ;
                $curl_options[CURLOPT_HTTPHEADER] = array('Content-Type: application/json'  ); 
            }
            break;
        case HTTP_METHOD_GET:
            if (!empty($parameters)) {
                $url .= '?' . http_build_query($parameters, null, '&');
            } 
            break;
        default:
            break;
    }

    // force autentification
    // curl_setopt($process, CURLOPT_USERPWD, $username . ":" . $password);
    if (!empty($basicAuth)) {
        foreach($basicAuth as $username => $password) {
            $basicAuthStr = "$username:$password";
        }
        $curl_options[CURLOPT_USERPWD] = $basicAuthStr;
    }

    // -- launched th curl init 
    $ch = curl_init();
    curl_setopt_array($ch, $curl_options);

     
    // -- make the query 
    $t0=microtime(true); 
    $result = curl_exec($ch);
    // $result=true;


    // -- get the answer 
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $content_type = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    $outauth = curl_getinfo($ch, CURLOPT_POST);


    if (ENABLE_DEBUG_INFO){
        $debug = array(
            'code' => $http_code,
            'url'=>$curl_options[CURLOPT_URL], 
            'options' => $curl_options,
            'exec_time'=>sprintf("%01.3f", (microtime(true)-$t0)). "s "
        ); 
    }

    if ($curl_error = curl_error($ch)) {
        return array(
            'success' => false,
            'error' => curl_error($ch).'('.curl_errno($ch).')',
            'debug'=> $debug
        );
    } else if ($http_code>=400){
        return array(
            'success' => false,
            'error' => $result,
            'debug'=> $debug
        );
    } else { 
        $json_decode = json_decode($result, true);
    }

    curl_close($ch);
    // fclose($curl_log);
    
    return array(
        'success' => true,
        'response' => (null === $json_decode) ? $result : $json_decode,
        'debug'=> $debug
    );
}



function gen_api_executeRequest($url, $parameters = array(), 
                                $http_method = HTTP_METHOD_GET, 
                                $usesignature=false, 
                                $api_secret=null,
                                $token_secret=null, 
                                array $http_headers = null, 
                                $form_content_type = HTTP_FORM_CONTENT_TYPE_MULTIPART
                                )
{
        $curl_options = array(
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_CUSTOMREQUEST  => $http_method
        );

        $orig_url=$url; // save original url

        switch($http_method) {
            case HTTP_METHOD_POST:
                $curl_options[CURLOPT_POST] = true;
                /* No break */
            case HTTP_METHOD_PUT:
                
                /**
                 * Passing an array to CURLOPT_POSTFIELDS will encode the data as multipart/form-data, 
                 * while passing a URL-encoded string will encode the data as application/x-www-form-urlencoded.
                 * http://php.net/manual/en/function.curl-setopt.php
                 */
                if(is_array($parameters) && HTTP_FORM_CONTENT_TYPE_APPLICATION === $form_content_type) {
                    $parameters = http_build_query($parameters);
                }
                $curl_options[CURLOPT_POSTFIELDS] = $parameters;
                break;
            case HTTP_METHOD_HEAD:
                $curl_options[CURLOPT_NOBODY] = true;
                /* No break */
            case HTTP_METHOD_DELETE:
            case HTTP_METHOD_GET:
                if (is_array($parameters)) {
                    $url .= '?' . http_build_query($parameters, null, '&');
                } elseif ($parameters) {
                    $url .= '?' . $parameters;
                }
                break;
            default:
                break;
        }

        //--- add signature if necessary oauth1
        if ($usesignature){
            
            // calculate the signature 
            $r_sign=  api_generate_signature($http_method, $orig_url, $parameters,$api_secret,$token_secret); 
            $url .='&oauth_signature='.rawurlencode($r_sign['signature']);
            
            // update the header 
            $oauth = array();
            $oauth = $parameters; // take intitial parameters 
            $oauth['oauth_signature'] = $r_sign['signature']; 
            $header_txt = array(api_build_authorization_header($oauth), 'Expect:');
        
            // final set HEADER
            $curl_options[CURLOPT_HTTPHEADER] = $header_txt;
            $curl_options[CURLOPT_HEADER]=false; 
        }


        // -- assign the url to Curl 
        if ($usesignature){
            $curl_options[CURLOPT_URL] = $orig_url.'?q=';
        } else $curl_options[CURLOPT_URL] = $url;


        // force optionnal headers 
        if (is_array($http_headers)) {
            $header = array();
            foreach($http_headers as $key => $parsed_urlvalue) {
                $header[] = "$key: $parsed_urlvalue";
            }
            $curl_options[CURLOPT_HTTPHEADER] = $header;
        }

        // -- launched th curl init 
        $ch = curl_init();
        curl_setopt_array($ch, $curl_options);
        // https handling
        if (!empty($certificate_file)) {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
            curl_setopt($ch, CURLOPT_CAINFO, $certificate_file);
        } else {
            // bypass ssl verification
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        }
        $result = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $content_type = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
        if ($curl_error = curl_error($ch)) {
            return array(
                'result' => false,
                'error' => $curl_error
            );
        } else { 
            $json_decode = json_decode($result, true);
        }
        curl_close($ch);
        
        return array(
            'result' => (null === $json_decode) ? $result : $json_decode,
            'code' => $http_code,
            'url'=>$curl_options[CURLOPT_URL], 
            'content_type' => $content_type,
            'header'=>$curl_options[CURLOPT_HTTPHEADER],
            'r_sign'=>$r_sign
        );
 }


   /**
   * Signs the request and adds the OAuth signature. This runs all the request
   * parameter preparation methods.
   * more details here : https://dev.twitter.com/docs/auth/creating-signature
   */
   function api_generate_signature($i_method, $i_url, $i_params,$i_api_secret,$i_token_secret) {

        // base string 
        $o_params = array();
        ksort($i_params);   
        foreach($i_params as $key=>$value) { $o_params[] = "$key=" . $value; }
        $base_string = strtoupper($i_method) . "&" . rawurlencode($i_url) . '&' . rawurlencode(implode('&', $o_params)); 

        // siging key 
        $signing_key = rawurlencode($i_api_secret).'&'.rawurlencode($i_token_secret);

        // signture 
        $oauth_signature=base64_encode( hash_hmac( 'sha1', $base_string, $signing_key, true));

        // output the results 
        return array(
            'signature' => $oauth_signature,
            'base_string' => $base_string,
            'method'=>$i_method
        );
    }


    function api_build_authorization_header($oauth) 
    {
        $return = 'Authorization: OAuth ';
        $values = array();
        
        foreach($oauth as $key => $value)
        {
            $values[] = "$key=\"" . rawurlencode($value) . "\"";
        }
        
        $return .= implode(', ', $values);
        return $return;
    }



function api_safe_encode($data) {
        if (is_scalar($data)) {
          return str_ireplace(
            array('+', '%7E'),
            array(' ', '~'),
            rawurlencode($data)
          );
        } else {
          return '';
        }
}

function api_create_nonce($length=12, $include_time=true) {
    $sequence = array_merge(range(0,9), range('A','Z'), range('a','z'));
    $length = $length > count($sequence) ? count($sequence) : $length;
    shuffle($sequence);
    return md5(substr(microtime() . implode($sequence), 0, $length));    
}


// :/--- CODE SAMPLEfromLINKEDIN ---/

//  <?php
// // Change these
// define('API_KEY',      'YOUR_API_KEY_HERE'                                          );
// define('API_SECRET',   'YOUR_API_SECRET_HERE'                                       );
// define('REDIRECT_URI', 'http://' . $_SERVER['SERVER_NAME'] . $_SERVER['SCRIPT_NAME']);
// define('SCOPE',        'r_fullprofile r_emailaddress rw_nus'                        );
 
// // You'll probably use a database
// session_name('linkedin');
// session_start();
 
// // OAuth 2 Control Flow
// if (isset($_GET['error'])) {
//     // LinkedIn returned an error
//     print $_GET['error'] . ': ' . $_GET['error_description'];
//     exit;
// } elseif (isset($_GET['code'])) {
//     // User authorized your application
//     if ($_SESSION['state'] == $_GET['state']) {
//         // Get token so you can make API calls
//         getAccessToken();
//     } else {
//         // CSRF attack? Or did you mix up your states?
//         exit;
//     }
// } else { 
//     if ((empty($_SESSION['expires_at'])) || (time() > $_SESSION['expires_at'])) {
//         // Token has expired, clear the state
//         $_SESSION = array();
//     }
//     if (empty($_SESSION['access_token'])) {
//         // Start authorization process
//         getAuthorizationCode();
//     }
// }
 
// // Congratulations! You have a valid token. Now fetch your profile 
// $user = fetch('GET', '/v1/people/~:(firstName,lastName)');
// print "Hello $user->firstName $user->lastName.";
// exit;
 
// function getAuthorizationCode() {
//     $params = array('response_type' => 'code',
//                     'client_id' => API_KEY,
//                     'scope' => SCOPE,
//                     'state' => uniqid('', true), // unique long string
//                     'redirect_uri' => REDIRECT_URI,
//               );
 
//     // Authentication request
//     $url = 'https://www.linkedin.com/uas/oauth2/authorization?' . http_build_query($params);
     
//     // Needed to identify request when it returns to us
//     $_SESSION['state'] = $params['state'];
 
//     // Redirect user to authenticate
//     header("Location: $url");
//     exit;
// }
     
// function getAccessToken() {
//     $params = array('grant_type' => 'authorization_code',
//                     'client_id' => API_KEY,
//                     'client_secret' => API_SECRET,
//                     'code' => $_GET['code'],
//                     'redirect_uri' => REDIRECT_URI,
//               );
     
//     // Access Token request
//     $url = 'https://www.linkedin.com/uas/oauth2/accessToken?' . http_build_query($params);
     
//     // Tell streams to make a POST request
//     $context = stream_context_create(
//                     array('http' => 
//                         array('method' => 'POST',
//                         )
//                     )
//                 );
 
//     // Retrieve access token information
//     $response = file_get_contents($url, false, $context);
 
//     // Native PHP object, please
//     $token = json_decode($response);
 
//     // Store access token and expiration time
//     $_SESSION['access_token'] = $token->access_token; // guard this! 
//     $_SESSION['expires_in']   = $token->expires_in; // relative time (in seconds)
//     $_SESSION['expires_at']   = time() + $_SESSION['expires_in']; // absolute time
     
//     return true;
// }
 
// function fetch($method, $resource, $body = '') {
//     $params = array('oauth2_access_token' => $_SESSION['access_token'],
//                     'format' => 'json',
//               );
     
//     // Need to use HTTPS
//     $url = 'https://api.linkedin.com' . $resource . '?' . http_build_query($params);
//     // Tell streams to make a (GET, POST, PUT, or DELETE) request
//     $context = stream_context_create(
//                     array('http' => 
//                         array('method' => $method,
//                         )
//                     )
//                 );
 
 
//     // Hocus Pocus
//     $response = file_get_contents($url, false, $context);
 
//     // Native PHP object, please
//     return json_decode($response);
// }



?>