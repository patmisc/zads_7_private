<?php

/******************************************************************************
 * ZADS CLASS for managing database accesses 
 * @category   Class
 * @package    ZADS
 * @author     Patrice COHAUT <patrice.cohaut@gmail.com>
 * @copyright  2016 PATMISC
 * @version    1.0
 * @link       https://www.zads.fr
 * @notes      inspired by http://medoo.in/
 ******************************************************************************/

	// // make a simple call 
	// // $result = $dbb->fetchAll("SELECT * FROM ".DB_PREFIX.DB_TABLE_ITEMS." LIMIT 0, 2"); 
	// // $result2 = $dbb->fetchAll("SELECT * FROM ".DB_PREFIX.DB_TABLE_ITEMS." LIMIT 0, 1"); 

	// // get number of items 
	// $result = $dbb->count(DB_TABLE_ITEMS); 
	// $result = $dbb->max(DB_TABLE_ITEMS, 'price');
	// $result = $dbb->has(DB_TABLE_USERS, " `username`='admin' "); 
	// // $result = $dbb->get(DB_TABLE_USERS, ["firstname(pat)", "lastname(virg)"] , " `username`='admin' "); 
	// $result = $dbb->select(DB_TABLE_USERS, ["firstname(pat)", "lastname(virg)", "protype"] , " protype='pro' "); 
	// $result = $dbb->select(DB_TABLE_USERS, '*' , " protype='pro' LIMIT 0, 10"); 
	// $result = $dbb->update(DB_TABLE_USERS,  ["firstname"=>"patrice", "lastname"=>"cohaut"] , " username='admin' "); 

	// // insert element 
	// $result = $dbb->insert(DB_TABLE_USERS,  ["firstname"=>"patrice", "lastname"=>"cohaut"]);
	// $result = $dbb->get(DB_TABLE_USERS, '*' , " id=".$result); 

	// // $result = $dbb->get(DB_TABLE_USERS, '*' , " `username`='admin' ");  

	// var_dump($dbb->get_log());
	// var_dump($dbb->get_logtime());

class dbClass 
{

	// General
	protected $database_type;
	protected $charset;
	protected $database_name;
	// For MySQL, MariaDB, MSSQL, Sybase, PostgreSQL, Oracle
	protected $server;
	protected $username;
	protected $password;

	// For SQLite
	protected $database_file;

	// For MySQL or MariaDB with unix_socket
	protected $socket;

	// Optional
	protected $port;
	protected $prefix;
	protected $option = array();

	// Variable
	protected $logs = array();
	protected $debug_mode = false;
	protected $timing_trace = ''; 
	protected $t0; 

	public function __construct($options = null)
	{

		// initialisation	
		$this->t0=microtime(true); 
		try {
			$commands = array();
			$dsn = '';

			// options mapping	
			if (is_array($options)) {
				foreach ($options as $option => $value){
					$this->$option = $value;
				}
			}
			else { return false; }


			if ( isset($this->port) && is_int($this->port * 1) ) {
				$port = $this->port;
			}

			$type = strtolower($this->database_type);
			$is_port = isset($port);

			if (isset($options[ 'prefix' ])){
				$this->prefix = $options[ 'prefix' ];
			}

						switch ($type)
			{
				case 'mariadb':
					$type = 'mysql';

				case 'mysql':
					if ($this->socket)
					{
						$dsn = $type . ':unix_socket=' . $this->socket . ';dbname=' . $this->database_name;
					}
					else
					{
						$dsn = $type . ':host=' . $this->server . ($is_port ? ';port=' . $port : '') . ';dbname=' . $this->database_name;
					}

					// Make MySQL using standard quoted identifier
					$commands[] = 'SET SQL_MODE=ANSI_QUOTES';
					break;

				case 'pgsql':
					$dsn = $type . ':host=' . $this->server . ($is_port ? ';port=' . $port : '') . ';dbname=' . $this->database_name;
					break;

				case 'sybase':
					$dsn = 'dblib:host=' . $this->server . ($is_port ? ':' . $port : '') . ';dbname=' . $this->database_name;
					break;

				case 'oracle':
					$dbname = $this->server ?
						'//' . $this->server . ($is_port ? ':' . $port : ':1521') . '/' . $this->database_name :
						$this->database_name;

					$dsn = 'oci:dbname=' . $dbname . ($this->charset ? ';charset=' . $this->charset : '');
					break;

				case 'mssql':
					$dsn = strstr(PHP_OS, 'WIN') ?
						'sqlsrv:server=' . $this->server . ($is_port ? ',' . $port : '') . ';database=' . $this->database_name :
						'dblib:host=' . $this->server . ($is_port ? ':' . $port : '') . ';dbname=' . $this->database_name;

					// Keep MSSQL QUOTED_IDENTIFIER is ON for standard quoting
					$commands[] = 'SET QUOTED_IDENTIFIER ON';
					break;

				case 'sqlite':
					$dsn = $type . ':' . $this->database_file;
					$this->username = null;
					$this->password = null;
					break;
			}

			if ( in_array($type, array('mariadb', 'mysql', 'pgsql', 'sybase', 'mssql')) && $this->charset )
			{
				$commands[] = "SET NAMES '" . $this->charset . "'";
				// $commands[] = " SET collation_connection = 'utf8_general_ci'";
			}
			$this->pdo = new PDO(
				$dsn,
				$this->username,
				$this->password,
				$this->option
			);

			foreach ($commands as $value)
			{
				$this->pdo->exec($value);
			}
		}
		catch (PDOException $e) {
			// throw new Exception($e->getMessage());
			trigger_error($e->getMessage(), E_USER_ERROR);
		}
	}
	// -- end construct 

	public function exec($query)
	{
		if ($this->debug_mode)
		{
			echo $query;

			$this->debug_mode = false;

			return false;
		}

		$this->logs[] = $query;
		$this->logtime('exec start'); 

		try 
		{
			$q = $this->pdo->exec($query);
			return $q ; 
		} 
		catch (PDOException $e)
		{
			trigger_error($e->getMessage().' query='. $query, E_USER_ERROR);
		}		
	}

	//-- essential functions 
	public function query($query)
	{
		if ($this->debug_mode)
		{
			echo $query;
			$this->debug_mode = false;
			return false;
		}

		$this->logs[] = $query;
		$this->logtime('query start'); 

		try 
		{
			$q = $this->pdo->query($query);
			return $q ; 
		} 
		catch (PDOException $e)
		{
			trigger_error($e->getMessage().' query='. $query, E_USER_ERROR);
		}

	}

	public function fetchAll($query) {
		$data=array(); $count=0; $xdata=0;  


		$this->logs[] = $query;
		$sth = $this->pdo->prepare($query);
		$sth->execute(); 
		$count = $sth->rowCount();

		if ($count){
			$xdata =$sth->fetchAll(); 
		}

		$data['nb'] = $count ;
		$data['data']=$xdata ; 

		$data = $this->logAndTrace($data,array($query)); // add logs and trace to this 

		return $data ; // TRUE if ok.
	}

	public function fetch($query) {
		$data=array(); $count=0; $xdata=0;  


		$this->logs[] = $query;
		$sth = $this->pdo->prepare($query);
		$sth->execute(); 
		$count = $sth->rowCount();

		if ($count){
			$xdata =$sth->fetch(); 
		}

		$data['nb'] = $count ;
		$data['data']=$xdata ; 

		$data = $this->logAndTrace($data,array($query)); // add logs and trace to this 

		return $data ; // TRUE if ok.
	}

	

	public function select($table,  $columns = null, $where = null)
	{

		$out=''; 
		$where_clause=''; 
		if ($where != null) $where_clause .= ' WHERE ' . $where;

		$is_single_column = (is_string($columns) && $columns !== '*');
		
		// $query = $this->query($this->select_context($table, $join, $columns, $where));
		$query = $this->query(' SELECT '. $this->column_push($columns).' FROM ' . $this->table_quote($table).$where_clause);

		$stack = array();

		$index = 0;

		if (!$query)
		{
			$out= false;
			$this->logtime('end'); 
			return $out ;
		}

		if ($columns === '*')
		{
			$out= $query->fetchAll(PDO::FETCH_ASSOC);
			$this->logtime('end'); 
			return $out ;
		}

		if ($is_single_column)
		{
			$out= $query->fetchAll(PDO::FETCH_COLUMN);
			$this->logtime('end'); 
			return $out ;
		}

		while ($row = $query->fetch(PDO::FETCH_ASSOC))
		{
			foreach ($columns as $key => $value)
			{
				if (is_array($value))
				{
					$this->data_map($index, $key, $value, $row, $stack);
				}
				else
				{
					$this->data_map($index, $key, preg_replace('/^[\w]*\./i', "", $value), $row, $stack);
				}
			}

			$index++;
		}

		$out= $stack;
		$this->logtime('end'); 
		return $out ;
	}



	public function get($table,  $columns = null, $where = null)
	{

		$out=''; 
		$where_clause=''; 
		if ($where != null) $where_clause .= ' WHERE ' . $where;

		$is_single_column = (is_string($columns) && $columns !== '*');
		
		$query = $this->query(' SELECT '. $this->column_push($columns).' FROM ' . $this->table_quote($table).$where_clause. ' LIMIT 1');


		if ($query)
		{
			$data = $query->fetchAll(PDO::FETCH_ASSOC);

			if (isset($data[ 0 ]))
			{
				if ($is_single_column)
				{
					$out= $data[ 0 ][ preg_replace('/^[\w]*\./i', "", $column) ];
					$this->logtime('end'); 
					return $out ;
				}
				
				if ($columns === '*')
				{
					$out= $data[ 0 ];
					$this->logtime('end'); 
					return $out ;
				}

				$stack = array();

				foreach ($columns as $key => $value)
				{
					if (is_array($value))
					{
						$this->data_map(0, $key, $value, $data[ 0 ], $stack);
					}
					else
					{
						$this->data_map(0, $key, preg_replace('/^[\w]*\./i', "", $value), $data[ 0 ], $stack);
					}
				}

				$out= $stack[ 0 ];
			}
			else
			{
				$out= false;
			}
		}
		else
		{
			$out= false;
		}

		$this->logtime('end'); 
		return $out ;
	}

	public function insert($table, $datas)
	{
		$out=false; 
		$lastId = array();

		// Check indexed or associative array
		if (!isset($datas[ 0 ])){

			$datas = array($datas);
		}

		foreach ($datas as $data){

			$values = array();
			$columns = array();

			foreach ($data as $key => $value){

				$columns[] = preg_replace("/^(\(JSON\)\s*|#)/i", "", $key);

				switch (gettype($value))
				{
					case 'NULL':
						$values[] = 'NULL';
						break;

					case 'array':
						preg_match("/\(JSON\)\s*([\w]+)/i", $key, $column_match);

						$values[] = isset($column_match[ 0 ]) ?
							$this->quote(json_encode($value)) :
							$this->quote(serialize($value));
						break;

					case 'boolean':
						$values[] = ($value ? '1' : '0');
						break;

					case 'integer':
					case 'double':
					case 'string':
						$values[] = $this->fn_quote($key, $value);
						break;
				}
			}

			$this->exec('INSERT INTO ' . $this->table_quote($table) . ' (`' . implode('`, `', $columns) . '`) VALUES (' . implode($values, ', ') . ')');

			$lastId[] = $this->pdo->lastInsertId();
		}

		$out = count($lastId) > 1 ? $lastId : $lastId[ 0 ];
		return $out ;
	}


	public function update($table, $data, $where = null)
	{
		$out=false; 
		$where_clause=''; 
		if ($where != null) $where_clause .= ' WHERE ' . $where;

		$fields = array();

		foreach ($data as $key => $value)
		{
			preg_match('/([\w]+)(\[(\+|\-|\*|\/)\])?/i', $key, $match);

			// with numeric expressions 
			if (isset($match[ 3 ]))
			{
				if (is_numeric($value))
				{
					$fields[] = $this->column_quote($match[ 1 ]) . ' = ' . $this->column_quote($match[ 1 ]) . ' ' . $match[ 3 ] . ' ' . $value;
				}
			}
			else
			{
				$column = $this->column_quote(preg_replace("/^(\(JSON\)\s*|#)/i", "", $key));

				switch (gettype($value))
				{
					case 'NULL':
						$fields[] = $column . ' = NULL';
						break;

					case 'array':
						preg_match("/\(JSON\)\s*([\w]+)/i", $key, $column_match);

						$fields[] = $column . ' = ' . $this->quote(
								isset($column_match[ 0 ]) ? json_encode($value) : serialize($value)
							);
						break;

					case 'boolean':
						$fields[] = $column . ' = ' . ($value ? '1' : '0');
						break;

					case 'integer':
					case 'double':
					case 'string':
						$fields[] = $column . ' = ' . $this->fn_quote($key, $value);
						break;
				}
			}
		}

		$out= $this->exec('UPDATE ' . $this->table_quote($table) . ' SET ' . implode(', ', $fields) . $where_clause);
		return $out ;
	}


	public function delete($table, $where)
	{
		$out=false; 
		$where_clause=''; 
		if ($where != null) $where_clause .= ' WHERE ' . $where;
		
		$out= $this->exec('DELETE FROM ' . $this->table_quote($table) . $where_clause);

		$this->logtime('end'); 
		return $out ;
	}

	public function count($table, $where = null)
	{
		$out=''; 

		$where_clause=''; 
		if ($where != null) $where_clause .= ' WHERE ' . $where;

		// notice : we use 'id' instead of '*' as deived the spped by 10 ! 
		$query = $this->query(' SELECT COUNT(id) FROM ' . $this->table_quote($table).$where_clause);
		
		$out= $query ? 0 + $query->fetchColumn() : false;
		$this->logtime('end'); 
		return $out ; 
	}


	public function max($table, $column = null, $where = null)
	{
		$out=''; 

		$where_clause=''; 
		if ($where != null) $where_clause .= ' WHERE ' . $where;

		if (is_null($column)) $column='id'; 

		// notice : we use 'id' instead of '*' as deived the spped by 10 ! 
		$query = $this->query(' SELECT MAX('.$column.') FROM ' . $this->table_quote($table).$where_clause);
		
		if ($query) {
			$max = $query->fetchColumn();
			$out= is_numeric($max) ? $max + 0 : $max;
		} else $out=false;
		 	
		$this->logtime('end'); 
		return $out ; 
	}


	public function min($table, $column = null, $where = null)
	{
		$out=''; 

		$where_clause=''; 
		if ($where != null) $where_clause .= ' WHERE ' . $where;

		if (is_null($column)) $column='id'; 

		// notice : we use 'id' instead of '*' as deived the spped by 10 ! 
		$query = $this->query(' SELECT MIN('.$column.') FROM ' . $this->table_quote($table).$where_clause);
		
		if ($query) {
			$max = $query->fetchColumn();
			$out= is_numeric($max) ? $max + 0 : $max;
		} else $out=false;
		 	
		$this->logtime('end'); 
		return $out ; 
	}


	public function has($table,  $where = null)
	{
		$out=''; 
		$where_clause=''; 
		if ($where != null) $where_clause .= ' WHERE ' . $where;

		$query = $this->query('SELECT EXISTS(SELECT * FROM ' . $this->table_quote($table).$where_clause.')');

		if ($query) $out= $query->fetchColumn() === '1';
		else $out= false;
		
		$this->logtime('end'); 
		return $out ; 
	}

	



	protected function column_push(&$columns)
	{
		if ($columns == '*')
		{
			return $columns;
		}

		if (is_string($columns))
		{
			$columns = array($columns);
		}

		$stack = array();

		foreach ($columns as $key => $value)
		{
			if (is_array($value))
			{
				$stack[] = $this->column_push($value);
			}
			else
			{
				preg_match('/([a-zA-Z0-9_\-\.]*)\s*\(([a-zA-Z0-9_\-]*)\)/i', $value, $match);

				if (isset($match[ 1 ], $match[ 2 ]))
				{
					$stack[] = $this->column_quote( $match[ 1 ] ) . ' AS ' . $this->column_quote( $match[ 2 ] );

					$columns[ $key ] = $match[ 2 ];
				}
				else
				{
					$stack[] = $this->column_quote( $value );
				}
			}
		}

		return implode($stack, ',');
	}


	protected function data_map($index, $key, $value, $data, &$stack)
	{
		if (is_array($value))
		{
			$sub_stack = array();

			foreach ($value as $sub_key => $sub_value)
			{
				if (is_array($sub_value))
				{
					$current_stack = $stack[ $index ][ $key ];

					$this->data_map(false, $sub_key, $sub_value, $data, $current_stack);

					$stack[ $index ][ $key ][ $sub_key ] = $current_stack[ 0 ][ $sub_key ];
				}
				else
				{
					$this->data_map(false, preg_replace('/^[\w]*\./i', "", $sub_value), $sub_key, $data, $sub_stack);

					$stack[ $index ][ $key ] = $sub_stack;
				}
			}
		}
		else
		{
			if ($index !== false)
			{
				$stack[ $index ][ $value ] = $data[ $value ];
			}
			else
			{
				$stack[ $key ] = $data[ $key ];
			}
		}
	}

	protected function column_quote($string)
	{
		preg_match('/(\(JSON\)\s*|^#)?([a-zA-Z0-9_]*)\.([a-zA-Z0-9_]*)/', $string, $column_match);

		if (isset($column_match[ 2 ], $column_match[ 3 ]))
		{
			return '"' . $this->prefix . $column_match[ 2 ] . '"."' . $column_match[ 3 ] . '"';
		}

		return '"' . $string . '"';
	}


	//-- tools


	protected function fn_quote($column, $string)
	{
		return (strpos($column, '#') === 0 && preg_match('/^[A-Z0-9\_]*\([^)]*\)$/', $string)) ?
			$string :
			$this->quote($string);
	}

	protected function table_quote($table)
	{
		return '"' . $this->prefix . $table . '"';
	}

	public function quote($string)
	{
		return $this->pdo->quote($string);
	}

	public function error()
	{
		return $this->pdo->errorInfo();
	}

	public function last_query()
	{
		return end($this->logs);
	}

	public function get_log()
	{
		return $this->logs;
	}

	protected function logtime($msg){
	  $deltatime= (microtime(true)-$this->t0); 
	  $this->timing_trace.= "|$msg ".sprintf("%01.3f", $deltatime). "s "; 
	  $this->t0=microtime(true); 
	  return true;
	}

	public function get_logtime()
	{
		return $this->timing_trace;
	}

	public function reset_logtime()
	{
		return $this->timing_trace=''; 
	}

	private function logAndTrace($in, $valuesAr)
	{
		$debugdatas  = array(); $i=0;
		if (ENABLE_DEBUG_MODE){
			foreach ($valuesAr as $value){
				$debugdatas[$i] =$value ; $i++;  
			}
			$in['debug']=$debugdatas;
			return $in ;  
		} else return $in; 
	}


	public function info()
	{
		$output = array(
			'server' => 'SERVER_INFO'
			,'driver' => 'DRIVER_NAME'
			,'client' => 'CLIENT_VERSION'
			,'version' => 'SERVER_VERSION'
			,'connection' => 'CONNECTION_STATUS'
			,'errmode' => 'ERRMODE'
		);

		foreach ($output as $key => $value)
		{
			$output[ $key ] = $this->pdo->getAttribute(constant('PDO::ATTR_' . $value));
		}

		return $output;
	}

} // -- end class


?>