<?php
require_once 'TwitterAPIExchance.php';
$settings = array(
    'oauth_access_token' => "232795503-nvrasC8l9zen9P40NgqwAaUaWTCoqtLuo0bNOoDr",
    'oauth_access_token_secret' => "AeazkDJ02oAPRmR5fkY3euw8XCK1tHL28AhYZy2jkpbYF",
    'consumer_key' => "iThKV5ZTn4CUc443H0NMzDfOG",
    'consumer_secret' => "34RRo9yni0LDhMBjURsht7BliBWlBydaSem5tk1u1PvlpnIhNu"
);
$url = 'https://api.twitter.com/1.1/search/tweets.json';
$url = 'https://api.twitter.com/1.1/account/verify_credentials.json';
$requestMethod = 'GET';
$getfields = '?q=';
$twitter = new TwitterAPIExchange($settings);

// Get tweets
$data = $twitter->setGetfield($getfields)
            ->buildOauth($url, $requestMethod)
            ->performRequest();

var_dump($data);


// require_once ("TwitterAPIExchance.php");

// $settings = array(
// 'oauth_access_token' => "232795503-nvrasC8l9zen9P40NgqwAaUaWTCoqtLuo0bNOoDr",
// 'oauth_access_token_secret' => "AeazkDJ02oAPRmR5fkY3euw8XCK1tHL28AhYZy2jkpbYF",
// 'consumer_key' => "iThKV5ZTn4CUc443H0NMzDfOG",
// 'consumer_secret' => "34RRo9yni0LDhMBjURsht7BliBWlBydaSem5tk1u1PvlpnIhNu"
// );
// //$url = 'https://api.twitter.com/1.1/search/tweets.json';
// $url = 'https://api.twitter.com/1.1/account/verify_credentials.json';
// $requestMethod = 'GET';
// $getfields = '';
// $twitter = new TwitterAPIExchange($settings);

// // Get tweets
// $r = $twitter->setGetfield($getfields)
//         ->buildOauth($url, $requestMethod)
//         ->performRequest();
// var_dump($r); die ; 



?>
