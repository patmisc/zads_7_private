<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING | E_DEPRECATED));

$out=""; 
$tlp_inh_fqdn= "admin_core_header.html"; 
$fc=file_get_contents($tlp_inh_fqdn);
$out .= $fc;

$tlp_inh_fqdn= "admin_core_test.html"; 
$fc=file_get_contents($tlp_inh_fqdn);
$out .= get_innert_html_from_str($fc, 'body');

$tlp_inh_fqdn= "admin_core_footer.html"; 
$fc=file_get_contents($tlp_inh_fqdn);
$out .= $fc;

echo $out ; 



function get_innert_html_from_str($tpl_content, $tagName){

    // $DOM = new DOMDocument;
    $DOM = new DOMDocument('1.0', 'UTF-8');
    // mandatory to forcethis to understand that this is UTF8 document 
    $tpl_content= '<meta http-equiv="Content-Type" content="text/html; charset=utf-8">'.$tpl_content;
    $DOM->loadHTML($tpl_content);
    $items = $DOM->getElementsByTagName($tagName);
    for ($i = 0; $i < $items->length; $i++){
      $result = get_inner_html($items->item($i)) ;
      return $result; 
    }
}


function get_inner_html( $node ) {
    $innerHTML= '';
    $children = $node->childNodes;
    foreach ($children as $child) {
        $innerHTML .= $child->ownerDocument->saveXML( $child );
    }
    return $innerHTML;
}


?>

