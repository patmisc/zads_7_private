<?php
/******************************************************************************
 * ZADS INSTALL script
 * 
 * Note :  works with SETTINGS.PHP file
 *  
 * @category   InstallationPackage
 * @package    ZADS
 * @author     Patrice COHAUT <patrice.cohaut@gmail.com>
 * @copyright  2016 PATMISC
 * @version    7.0.5
 ******************************************************************************/


// if (function_exists("gettext")){
//     echo 'Gettext is working';
// }
// else{
//      echo 'Gettext is not working';
//      ini_set("upload_max_filesize","10M");
//      phpinfo();
// }


// load libraries 
// require_once("settings/db_settings.php");  
require_once("multitenants_settings.php"); 
require_once($SETTINGS_PATH."settings.php");
require_once("localization.php");
require_once("functions.php"); // added to update settings elements 



 // $settingsurl = $SETTINGS_PATH."settings.php";
 // $test="www.mytest.com";
 // $rest = file_update_one_elem("DOMAIN_FQDN", $test, $settingsurl); 
 // var_dump($rest); 
 // die; 


// set default timezone 
date_default_timezone_set('Europe/Paris');
ini_set( 'default_charset', 'UTF-8' );

// Report all PHP errors
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING | E_DEPRECATED));

$debug ="";
$debug_tmp = 0 ; // 0= server 1=local
if (( $_SERVER['SERVER_ADDR'] != "127.0.0.1") ||( !$_SERVER['SERVER_ADDR'] ))  $debug_tmp=0; else $debug_tmp=1; 
$nomessage = 0;  // 0= flag to indicate wether to end a message or not

// debug output file 
$debugoutputfile = "debugoutput.htm"; // only if save=1
 

// ---- send header ----------//
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>ZADS Installer</title>

  <base href="<?php echo $_SERVER['SCRIPT_URI'];?>" />

  <meta http-equiv="Content-Language" content="French" />
  <!-- <meta http-equiv="content-type" content="text/html; charset=iso-8859-15"/> -->
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />    
  <link rel="stylesheet" type="text/css" href="css/install_style.css" media="all"/>
  <link rel="stylesheet" media="all" type="text/css" href="css/font-awesome.css">

</head>
<body id="install_page">
  <div id="">

    <div class="header-notif">
      <div class="warning_notif">
        <span class="motto"><i class="icon-fa-warning-sign mr6 fs13"></i>
          <strong> <?php echo _('*** DELETE THIS FILE FROM SERVER ONCE INSTALLATION IS DONE ****') ; ?> </strong></span>
      </div>
    </div>

    <div class="header">
      <h1> <?php echo "ZADS  : "._('ZADS DIAG + INSTALL') ; ?> </h1>
    </div>
    <div id="site">
      <div id="content">
<?php

set_error_handler("warning_handler", E_WARNING);

$step=''; 
if (isset($_GET["step"])) $step = $_GET["step"]; 

if  ($step!="postinstall") {
  // --- make a precheck of bd config file existance ---- //
  define('CONFIGFILE',$SETTINGS_PATH.'db_settings.php');
  define('CONFIGFILE_TEMPLATE',$SETTINGS_PATH.'db_settings.sample.php');
  ob_start();
  if(!file_exists(CONFIGFILE)) {
    echo_flush('ko', _('DB Config file does not exist, we will create one from default template'),'');
    if (!copy(CONFIGFILE_TEMPLATE,CONFIGFILE )) {
      echo_flush('ko', sprintf(_('failed to copy %s...'), $file),'');
      exit ; 
    } else {
      display_dbsetupform(); 
    }
    exit ;
  } else {
      $configfile=file_get_contents(CONFIGFILE); //Get the goodies...peek and tell.
      if (isset($_POST["action"])  && 
              $_POST["action"]=="updatemysqlsettings"
          ||  $_POST["action"]=="finalizedemoreset"
          ) 
      {

        if ( $_POST["action"]=="updatemysqlsettings"){
          // replace and save 
          if (!($fp = @fopen(CONFIGFILE,'r+'))) {
            $msg=_('Unable to open config file for writing. Permission denied!');
            echo_flush('ko', $msg,'');
          } else {
            $configfile= str_replace("define('ZADSINSTALLED',FALSE);","define('ZADSINSTALLED',TRUE);",$configfile);
            $configfile= str_replace('%CONFIG-DBHOST',$_POST['dbhost'],$configfile);
            $configfile= str_replace('%CONFIG-DBNAME',$_POST['dbname'],$configfile);
            $configfile= str_replace('%CONFIG-DBUSER',$_POST['dbuser'],$configfile);
            $configfile= str_replace('%CONFIG-DBPASS',$_POST['dbpass'],$configfile);
            $configfile= str_replace('%CONFIG-DBPREFIX',$_POST['prefix'],$configfile);
          
            if ($configfile){
              @fclose($fp);
              $fp = @fopen(CONFIGFILE,'w'); // position cursor at the beg 
               if (fwrite($fp,$configfile)){ 
                  echo_flush('ok', _('DB Config file updated'),'');
                  require_once($SETTINGS_PATH."db_settings.php");
                  echo_flush('ok', _('DB Config file exists, default DB Prefix is :').'<b>'. $DB_PREFIX.'</b>','');
              }
              else { 
                echo_flush('ok', _('error in writting config file'),'');
              }
            }
          }
          @fclose($fp);
        }


        // empty Ad table
        if ($_POST["action"]=="finalizedemoreset"){


          echo str_pad('<h1 class="start">'._('Emptying ads table ...').'</h1>',4096)."\n";  
          $stamp= date( 'Y-m-d H:i:s', time());  

          $status="ok";
          $thistable = $dbItemsTable; 
          $query = "TRUNCATE TABLE  `".$thistable."`"; 
          $result = mysql_query($query);
          if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
          else $msg =  _("MySQL : Table $thistable emptied sucessfuly ").'\n\r';
          echo_flush($status, $msg,''); 


        }


        //add FQDN and ADMIN_EMAIL details
        // function file_update_one_elem($elemname, $elemvalue, $fileurl, $filetype='json-txt', $elemtype="string"){
        $settingsurl = $SETTINGS_PATH."settings.php";
        $settingsurl_cust = $SETTINGS_PATH."home_settings_fr_FR.php";


        if ($_POST['fqdn']){
          file_update_one_elem("DOMAIN_FQDN", trim($_POST['fqdn']), $settingsurl); 
          file_update_one_elem("DOMAIN_FQDN_SHORT", trim($_POST['fqdn']), $settingsurl); 
        }


        if ($_POST['site_name']){
          file_update_one_elem("SITE_NAME", trim($_POST['site_name']), $settingsurl); 
          file_update_one_elem("SITE_CUSTOMER", trim($_POST['site_name']), $settingsurl);
          file_update_one_elem("cust_site_name", strtoupper(trim($_POST['site_name'])), $settingsurl_cust);  
        }

        if ($_POST['site_motto']){
          file_update_one_elem("SITE_MOTTO", trim($_POST['site_motto']), $settingsurl); 
          file_update_one_elem("cust_site_motto", strtoupper(trim($_POST['site_motto'])), $settingsurl_cust); 
        }

        if ($_POST['admin_email']){
          file_update_one_elem("USER_ADMIN_EMAIL", trim($_POST['admin_email']), $settingsurl); 
        }

        if ($_POST['general_domain']){

          $domain_only = get_domain(trim($_POST['general_domain']));

          file_update_one_elem("EMAIL_FROMADMIN", "demo - no reply <noreply@$domain_only>", $settingsurl); 
          file_update_one_elem("EMAIL_ADMIN_REPORTS", "report - no reply <noreply@$domain_only>", $settingsurl); 
          file_update_one_elem("EMAIL_SUPPORT", "suport - no reply <noreply@$domain_only>", $settingsurl); 
          file_update_one_elem("EMAIL_SALES", "sales - no reply <noreply@$domain_only>", $settingsurl); 

          file_update_one_elem("WATERMARK_FREE_TEXT", strtoupper(trim($_POST['general_domain']))." COPYRIGHT", $settingsurl); 
          file_update_one_elem("cust_site_copyright", strtoupper(trim($_POST['general_domain'])), $settingsurl_cust); 
          
        }

        // set some default values 
        file_update_one_elem("INVOICE_COMPANYNAME", "Company name", $settingsurl); 
        file_update_one_elem("INVOICE_COMPANY_ADDRESS", "Company address", $settingsurl); 
        file_update_one_elem("INVOICE_FOOTERTEXT", "Invoice footer test", $settingsurl); 

        file_update_one_elem("FB_SECRET", "** your secret key **", $settingsurl); 

    
        file_update_one_elem("PAYPAL_USER", "", $settingsurl); 
        file_update_one_elem("PAYPAL_PASSWORD", "", $settingsurl); 

        file_update_one_elem("ROBOT_NAME", "robot", $settingsurl); 

        // set trial mode - limited to 5 days - 30 ads 
        $trialtill = time() + (6 * 24 * 60 * 60);
        $stamptrial = date( 'Y-m-d', $trialtill);
        file_update_one_elem("TBYB_END_DATE", $stamptrial, $settingsurl); 

        file_update_one_elem("MAX_TOT_ADS", 30, $settingsurl); 
        file_update_one_elem("MAX_PIC_SIZE", 20000000, $settingsurl); 
        file_update_one_elem("MAX_PIC_NB", 3, $settingsurl); 

        file_update_one_elem("ENABLE_VISITORS_LOGS", false, $settingsurl); 

        // disable debug mode and visitor logs 
        file_update_one_elem("ENABLE_DEBUG_MODE", false, $settingsurl); 
        file_update_one_elem("ENABLE_DEBUG_JSTOOLS", false, $settingsurl); 
        file_update_one_elem("GOOGLE_ANALYTICS_ACCOUNT", "", $settingsurl); 
        file_update_one_elem("GOOGLE_SITE_VERIFICATION", "", $settingsurl); 
        file_update_one_elem("ENABLE_VISITORS_LOGS", false, $settingsurl); 


        echo_flush('ok', _('Setting file initialized:'),'');

      } else {
        // main cases
        if(preg_match("/define\('OSTINSTALLED',FALSE\)\;/i",$configfile) || strpos($configfile,'%CONFIG-DBHOST')){
          $msg=_('Configuration file not correctly defined !');
          echo_flush('ko', $msg,'');
          display_dbsetupform();
          exit; 
        } else {
          require_once($SETTINGS_PATH."db_settings.php");
          echo_flush('ok', _('DB Config file exists, default DB Prefix is :').'<b>'. $DB_PREFIX.'</b>','');
        }
      }
      echo '</br>';
  }
}





// --- display menu if not in a step process -----//
$chain=false; 
if (isset($_GET["step"])) {
  $step = $_GET["step"]; 
  
  if ($step=='full') {$step='check'; $chain=true;} else  {$chain=false;}
  echo str_pad(_('Starting processing ...'),4096)."<br />\n"; 
  if (ob_get_level() == 0) { // 0 if buffer is disabled . then enable it
      ob_start();
  }
}

else { 
// display the menu 

$tmphtml = ""; 
$tmphtml .='<div class="main_menu">';
// $tmphtml .= '<div class="title">'._('MENU').'</div>'; 


// header menu 
?>
<div class="row featured_menu">

  <div class="col1">
    <a href="?step=full">
      <i class="icon featured full-install icon-fa-play"></i>
      <h2><?php echo _('Launches Full Install') ?></h2>
    </a>
  </div>

  <div class="col1">
    <a href="?step=check">
      <i class="icon featured check icon-fa-stethoscope"></i>
      <h2><?php echo _('Check environment') ?></h2>
    </a>
    <p></p>
  </div>

</div>

<?php

$tmphtml .= '<div class="title">'._('MENU : A LA CARTE').'</div>'; 
$tmphtml .='<ul class="ul_nemu">';
// $tmphtml .= '<li></i><a href="?step=check">'._('Check environment').'</a><br></li>';
// $tmphtml .= '<br>';
// $tmphtml .= '<li><a href="?step=full">'._('Launches Full Install').'</a><br></li>';
// $tmphtml .= '<br>';
// $tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=createtables">'._('Create default DB tables (v4.0)').'</a><br></li>';
// $tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=createlogtable">'._('Create LOG DB table (v4.0)').'</a><br></li>';
// $tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=createvisitorstable">'._('Create VISITORS DB table (v4.9)').'</a><br></li>';
// $tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=updatezads40">'._('Update Table 3.x to  4.0 compatibility').'</a><br></li>';
// $tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=updatezads45">'._('Update Table 4.0 to  4.7 compatibility').'</a><br></li>';
// $tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=updatezads48">'._('Update Table 4.7 to  4.8 compatibility').'</a><br></li>';
// $tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=updatezads50">'._('Update Table 4.8 to  5.0 compatibility').'</a><br></li>';
// $tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=updatezads55">'._('Update Table 5.0 to  5.5 compatibility').'</a><br></li>';
// $tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=updatezads551">'._('Update Table 5.5 to  5.5.1 compatibility').'</a><br></li>';
// $tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=updatezads600">'._('Update Table 5.5.x to  6.0.0 compatibility').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=updatezads61">'._('Update Table 6.0 to  6.1 compatibility').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=updatezads62">'._('Update Table 6.1 to  6.2 compatibility').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=updatezads64">'._('Update Table 6.2 to  6.4 compatibility').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=updatezads65">'._('Update Table 6.4 to  6.5 compatibility').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=updatezads67">'._('Update Table 6.5 to  6.7 compatibility').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=updatezads68">'._('Update Table 6.7 to  6.8 compatibility').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=updatezads69">'._('Update Table 6.8 to  6.9 compatibility').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=updatezads70">'._('Update Table 6.9 to  7.0 compatibility').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=updatezads71">'._('Update Table 7.0 to  7.1 compatibility').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=updatezads73">'._('Update Table 7.1 to  7.3 compatibility').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=updatezads74">'._('Update Table 7.3 to  7.4 compatibility').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=updatezads745">'._('Update Table 7.4 to  7.4.5 compatibility').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=updatezads750">'._('Update Table 7.4.5 to  7.5.0 compatibility').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=updatezads755">'._('Update Table 7.5.0 to  7.5.5 compatibility').'</a><br></li>';


$tmphtml .= '<br>';
$tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=createindex">'._('Update INDEX on tables (zads 6.1)').'</a><br></li>';
$tmphtml .= '<br>';
$tmphtml .= '<li><i class="icon-fa-user mr6 sf13 icon-all-menu"></i><a href="?step=createadmin">'._('Create default ADMIN user').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-user mr6 sf13 icon-all-menu"></i><a href="?step=changeAdminPassword">'._('Change Admin Password').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-user mr6 sf13 icon-all-menu"></i><a href="?step=createuser">'._('Create a user').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-tag mr6 sf13 icon-all-menu"></i><a href="?step=createcatdef">'._('Create ONE default CATEGORY').'</a><br></li>';
$tmphtml .= '<br>';
$tmphtml .='</ul>';

// second part 

$tmphtml .='<ul class="nemu">';
$tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=postinstall">'._('FIRST_TIME : POST-INSTALL INIT').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=resetdemo">'._('Reset the demo').'</a><br></li>';
$tmphtml .= '<br>';
// $tmphtml .= '<li><i class="icon-fa-trash mr6 sf13 icon-all-menu"></i><a href="?step=cleandebugfile">'._('Clean Debug file').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-envelope mr6 sf13 icon-all-menu"></i><a href="?step=testemailparams">'._('Test email with real parameters').'</a><br></li>';
$tmphtml .= '<br>';
// $tmphtml .= '<li><i class="icon-fa-tags mr6 sf13 icon-all-menu"></i><a href="?step=createcats">'._('TEMPLATE - create set of categories').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-tags mr6 sf13 icon-all-menu"></i><a href="?step=createvfields_sample">'._('TEMPLATE - create VFIELDS samples').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-tags mr6 sf13 icon-all-menu"></i><a href="?step=createcats_sample">'._('TEMPLATE - create CATS samples').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-tags mr6 sf13 icon-all-menu"></i><a href="?step=createlists_sample">'._('TEMPLATE - create LISTS samples').'</a><br></li>';

$tmphtml .= '<li><i class="icon-fa-tags mr6 sf13 icon-all-menu"></i><a href="?step=createcat9999">'._('TEMPLATE - create the 9999 category').'</a><br></li>';
// $tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=createads_rnd">'._('TEMPLATE - populate ad with 10 random ads ').'</a><br></li>';
$tmphtml .= '<br>';
$tmphtml .= '<li><i class="icon-fa-trash mr6 sf13 icon-all-menu"></i><a href="?step=deletefiles">'._('Delete unnecessay files').'</a><br></li>';
$tmphtml .= '<br>';
$tmphtml .= '<li><i class="icon-fa-cogs mr6 sf13 icon-all-menu"></i><a href="?step=enablecache">'._('Enable .htaccess file caching').'</a><br></li>';
$tmphtml .= '<br>';
// $tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=patchddates">'._('PATCH Dates fomr 6.0 compatibility').'</a><br></li>';
// $tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=patchprotype">'._('PATCH INDIR for 6.0 compatibility').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-trash mr6 sf13 icon-all-menu"></i><a href="?step=deletedbfile">'._('Reset DB config file').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-trash mr6 sf13 icon-all-menu"></i><a href="?step=droptables">'._('DROP TABLE - drop/delete all tables').'</a><br></li>';
$tmphtml .= '<br>';
$tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=emptytables">'._('EMPTY ALL TABLE - empty all tables').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=emptytablecats">'._('EMPTY CATS TABLE ').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=emptytablevfields">'._('EMPTY VFIELDS TABLE ').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=emptytablelists">'._('EMPTY LISTS TABLE ').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=execquery">'._('DB - Execute MYSQL query (general.sql)').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=alterutf8">'._('ALTER ALL TABLE TO UTF8').'</a><br></li>';
$tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=alterlatam">'._('ALTER ALL TABLE TO LATAM').'</a><br></li>';

// $tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=exporttable">'._('EXPORT A TABLE to Backup directory ').'</a><br></li>';
// $tmphtml .= '<br>';
// $tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=updategeocoderads">'._('UPDATE GEODODER on ADS').'</a><br></li>';
// $tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=special">'._('special').'</a><br></li>';
// $tmphtml .= '<li><i class="icon-fa-cog mr6 sf13 icon-all-menu"></i><a href="?step=extendbanner1500">'._('extend banners.htmlcode to 1500 chars').'</a><br></li>';


$tmphtml .='</ul>';
$tmphtml .='</div>';
echo $tmphtml; 
exit; 
}

if  ($step!="postinstall" && $step!="deletedbfile") {
// DB connection
  $databasehost = $DB_HOST;
  $databaseusername =$DB_USERNAME;  
  $databasepassword =$DB_PASSWORD;  
  
  $databasename = $DB_NAME;  //cads = classified adds. 
  
  $dbItemsTable = $DB_PREFIX.$DB_TABLE_ITEMS ; 
  $dbCatsTable = $DB_PREFIX.$DB_TABLE_CATS; 
  $dbUsersTable = $DB_PREFIX.$DB_TABLE_USERS; 
  $dbStatsTable = $DB_PREFIX.$DB_TABLE_STATS; 
  $dbLogsTable = $DB_PREFIX.$DB_TABLE_LOGS; 
  $dbPaymentsTable = $DB_PREFIX.$DB_TABLE_PAYMENTS;
  $dbBannersTable = $DB_PREFIX.$DB_TABLE_BANNERS;
  $dbVisitorsTable = $DB_PREFIX.$DB_TABLE_VISITORS;
  $dbServicesTable = $DB_PREFIX.$DB_TABLE_SERVICES;

  // @Z5.5
  $dbSubscribersTable = $DB_PREFIX.$DB_TABLE_SUBSCRIBERS;
  $dbVFieldsTable = $DB_PREFIX.$DB_TABLE_VFIELDS;
  
  //@Z6.2.0
  $dbBookingsTable = $DB_PREFIX.$DB_TABLE_BOOKINGS;
  $dbPricingsTable = $DB_PREFIX.$DB_TABLE_PRICINGS;

  //@Z6.7
  $dbKeysTable = $DB_PREFIX.$DB_TABLE_KEYS;


  //@Z6.8.3
  $dbComsTable = $DB_PREFIX.$DB_TABLE_COMS;


  // Z7.4
  $dbAlertsTable = $DB_PREFIX.$DB_TABLE_ALERTS;
  $dbListsTable = $DB_PREFIX.$DB_TABLE_LISTS;


  $fullfqdn = $DOMAIN_FQDN; 
}





// ------------- Connection to database ------------- 

if (($step!="check" && $step!="postinstall"  && $step!="deletedbfile")){  
  // connect to database whatever the menu is 
  //  --- open socket to MySQL database
  $con = mysql_connect ($databasehost,$databaseusername, $databasepassword) or die();
  //set desired encoding just in case mysql charset is not UTF-8 - Thanks to FreshMedia
  if ($con) {  
    @mysql_query('SET NAMES "UTF8"');
    @mysql_query('SET COLLATION_CONNECTION=utf8_general_ci');
  }
  mysql_select_db ( $databasename ) or die();
}



if (($step=='resetdemo')) {
  display_dbfactoryresetForm();
  exit; 
}



// ------------- Testing Emails with real parameters -------------    
if (($step=='testemailparams')) { 
  // test of email feature
  test_email('realparams');
}

// ------------- Compatibility check of environment -------------    
if (($step=='check')) { 

  echo str_pad('<h1>'._('Checking for compatibility...'),4096)."</h1>\n"; 
  $cstat=true; // global Variable


  echo_flush('notice', sprintf(_("PHP version is : <b>%s</b>"),phpversion()),''); 
  
  //print_r(get_loaded_extensions());
  check_php_compatibility('gd');
  check_php_compatibility('curl');
  check_php_compatibility('json');
  check_php_compatibility('gettext');
  check_php_compatibility('session');
  check_php_compatibility('hash');
  check_php_compatibility('zlib');
  check_php_compatibility('PDO');
  
  //print_r(apache_get_modules());
  
  //check_apache_compatibility('mod_rewrite');
  //check_apache_compatibility('mod_php5');
  
  // test of email feature
  test_email('');
  
  // final conclusion on compatibility 
  if ($cstat) echo str_pad('<h2 class="ok">'._('... your environment IS compatible with ZADS').'</h2>',4096)."\n"; 
  else echo str_pad('<h2 class="ok">'._('... your environment IS NOT compatible with ZADS').'</h2>',4096)."\n";
  
  if ($debug_tmp) if (!$cstat) die(); // quit if not compatible and we are in production site. 
  
  // ------------- Compatibility check DATABASE accesses and first DATAs-------------
  
  echo str_pad('<h1 class="start">'._('Checking access to DB...').'</h1>',4096)."\n"; 

  echo_flush('notice', sprintf(_("The MYQSL table prefix is : <b>%s</b>"),$DB_PREFIX),''); 
  
  //  --- open socket to MySQL database
  $status="ok";
  $con = mysql_connect ($databasehost,$databaseusername, $databasepassword);
  if (!$con) { $status="ko"; $msg= _('Impossible to connect to MySQL  : ').mysql_error(); } 
  else {
    $msg= _("MySQL : Correct connection to host"). ": <b>".$databasehost."</b>";
    @mysql_query('SET NAMES "UTF8"');
    @mysql_query('SET COLLATION_CONNECTION=utf8_general_ci');
  }
  echo_flush($status, $msg, "die"); 
  
  $status="ok";
  $dbcon = mysql_select_db ( $databasename );
  if (!$dbcon) { $status="ko"; $msg= _('Impossible to connect to MySQL  : ').mysql_error(); }
  else $msg= _("MySQL : Correct connection to database :"). "<b>".$databasename."</b>";
  echo_flush($status, $msg, "die"); 


  // get myqsl version
  $version=0;
  $matches = array();
  $result = @mysql_query('SELECT VERSION()');
  $item = mysql_fetch_array ( $result );
  if(preg_match('/(\d{1,2}\.\d{1,2}\.\d{1,2})/',$item[0],$matches))
  $mysqlversion=$matches[1];

  echo_flush('notice', sprintf(_(" MYQSL version is : <b>%s</b>"),$mysqlversion),''); 

  
  if ($chain) $step = "createtables"; 
  else $step="end"; 


}

if ($step=='special') { 
 $status="ok";
 $query = "  
      UPDATE  `".$dbUsersTable."` SET  `usertype` =  '9', `assocprojects`='10' WHERE  `".$dbUsersTable."`.`id` =251;
      "; 
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : special action done  : ");
  echo_flush($status, $msg,''); 
    
} 

// ------------------- CREATE BASIC TABLES ---------------------------------
if (($step=='createtables')) {  
  echo str_pad('<h1  class="start">'._('Creating default Tables in DB...').'</h1>',4096)."\n"; 
  $stamp= date( 'Y-m-d H:i:s', time());
  // ------------------- CATS ---------------------------------
  $status="ok";
  $query = " CREATE TABLE IF NOT EXISTS `".$dbCatsTable."` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `moddate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
    `title` varchar(255) DEFAULT NULL,
    `description` varchar(1000) DEFAULT NULL,
    `catid` int(3) NOT NULL,
    `type` varchar(10) NOT NULL DEFAULT 'sell',
    `priority` varchar(10) NOT NULL,
    `price` float DEFAULT NULL,
    `imgname` varchar(255) DEFAULT NULL,
    `dirurl` varchar(60) DEFAULT NULL,
    `location` varchar(100) NOT NULL,
    `userid` int(11) NOT NULL DEFAULT '0',
    `username` varchar(30) NOT NULL,
    `phone` varchar(20) NOT NULL,
    `email` varchar(40) NOT NULL,
    `status` varchar(2) NOT NULL,
    `logs` varchar(1000) NOT NULL,
    `hits` int(10) NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`)
  ) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10037 ;
  ";
    
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : creation of table sucessful : ").$dbCatsTable;
  echo_flush($status, $msg,''); 
  
  //------------------- ITEMS ---------------------------------
  $status="ok";
  $query = " CREATE TABLE IF NOT EXISTS `".$dbItemsTable."` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `moddate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
    `title` varchar(255) DEFAULT NULL,
    `description` varchar(1000) DEFAULT NULL,
    `catid` int(3) NOT NULL,
    `type` varchar(10) NOT NULL DEFAULT 'sell',
    `priority` varchar(10) NOT NULL,
    `price` float DEFAULT NULL,
    `imgname` varchar(255) DEFAULT NULL,
    `dirurl` varchar(60) DEFAULT NULL,
    `location` varchar(100) NOT NULL,
    `loclatlng` varchar(40) NOT NULL,
    `loczipcode` varchar(10) NOT NULL,
    `loccity` varchar(100) NOT NULL,
    `locdept` varchar(40) NOT NULL,
    `locregion` varchar(40) NOT NULL,
    `loccountrycode` varchar(2) NOT NULL,
    `lochash` varchar(300) NOT NULL,
    `lochashregion` varchar(200) NOT NULL,
    `userid` int(11) NOT NULL DEFAULT '0',
    `username` varchar(30) NOT NULL,
    `phone` varchar(20) NOT NULL,
    `email` varchar(40) NOT NULL,
    `status` varchar(2) NOT NULL,
    `logs` varchar(1000) NOT NULL,
    `hits` int(10) NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`)
  ) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=625 ;
  ";
  
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : creation of table sucessful : ").$dbItemsTable;
  echo_flush($status, $msg,''); 
  
  // ------------------- USERS ---------------------------------
  $status="ok";
  $query = "  
      CREATE TABLE IF NOT EXISTS `".$dbUsersTable."` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `gender` varchar(6) NOT NULL,
      `firstname` varchar(50) NOT NULL DEFAULT '',
      `lastname` varchar(50) NOT NULL DEFAULT '',
      `username` varchar(25) NOT NULL DEFAULT '',
      `accronym` varchar(10) NOT NULL DEFAULT '',
      `avatarimg` varchar(255) NOT NULL,
      `probannerimg` varchar(200) NOT NULL,
      `folioimg` varchar(200) NOT NULL,
      `skills` varchar(100) NOT NULL,
      `priority` varchar(10) NOT NULL,
      `expiredate` datetime NOT NULL,
      `protype` varchar(3) NOT NULL,
      `procpny` varchar(50) NOT NULL,
      `prosiret` varchar(20) NOT NULL,
      `prowebsite` varchar(100) NOT NULL,
      `email` varchar(100) NOT NULL DEFAULT '',
      `social` varchar(200) NOT NULL,
      `phone` varchar(20) NOT NULL,
      `location` varchar(100) NOT NULL,
      `loclatlng` varchar(40) NOT NULL,
      `loczipcode` varchar(10) NOT NULL,
      `loccity` varchar(100) NOT NULL,
      `locdept` varchar(40) NOT NULL,
      `locregion` varchar(40) NOT NULL,
      `loccountrycode` varchar(2) NOT NULL,
      `lochash` varchar(300) NOT NULL,
      `lochashregion` varchar(200) NOT NULL,
      `locale` varchar(6) NOT NULL,
      `password` varchar(100) NOT NULL DEFAULT '',
      `auth` varchar(2) NOT NULL,
      `usertype` tinyint(25) unsigned NOT NULL DEFAULT '0',
      `status` varchar(2) NOT NULL,
      `sendEmail` tinyint(4) DEFAULT '0',
      `gid` tinyint(3) unsigned NOT NULL DEFAULT '1',
      `bio` varchar(400) NOT NULL,
      `registerdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
      `moddate` datetime NOT NULL,
      `lastvisitdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
      `lastemaildate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
      `activation` varchar(100) NOT NULL DEFAULT '',
      `preferences` text NOT NULL,
      `assocprojects` text NOT NULL,
      `imgurl` varchar(255) DEFAULT NULL,
      `userid` int(11) NOT NULL,
      `favads` varchar(100) NOT NULL,
      PRIMARY KEY (`id`),
      KEY `usertype` (`usertype`),
      KEY `idx_name` (`lastname`)
    ) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=86 ;
  ";
  
    
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg =  _("MySQL : creation of table sucessful : ").$dbUsersTable;
  echo_flush($status, $msg,''); 
  
  // ------------------- STATS ---------------------------------
  $status="ok";
  $query = "
  CREATE TABLE IF NOT EXISTS `".$dbStatsTable."` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `date` date NOT NULL,
    `type` varchar(10) NOT NULL,
    `data` varchar(100) NOT NULL,
    KEY `id` (`id`)
  ) ENGINE=MyISAM DEFAULT CHARSET=latin1;
  ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg =  _("MySQL : creation of table sucessful : ").$dbStatsTable;
  echo_flush($status, $msg,''); 
  
  if ($chain) $step = "createlogtable"; 
  else $step="end"; 
}


// ------------------- LOGS ---------------------------------
if (($step=='createlogtable')) {  
  echo str_pad('<h1  class="start">'._('Creating LOG Table in DB...').'</h1>',4096)."\n"; 
  $stamp= date( 'Y-m-d H:i:s', time());
  
  $status="ok";

  $query = " CREATE TABLE IF NOT EXISTS `".$dbLogsTable."` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `date` datetime NOT NULL,
    `action` varchar(20) NOT NULL,
    `what` varchar(5) NOT NULL,
    `whatid` int(11) NOT NULL,
    `userid` int(11) NOT NULL,
    `desc` varchar(100) NOT NULL,
    `severity` int(11) NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`)
  ) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=118 ;
  ";

  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : creation of table sucessful : ").$dbLogsTable;
  echo_flush($status, $msg,''); 
  
  if ($chain) $step = "createvisitorstable"; 
  else $step="end";  
}


// ------------------- VISITORS ---------------------------------
if (($step=='createvisitorstable')) {  
  echo str_pad('<h1  class="start">'._('Creating VISITOR Table in DB...').'</h1>',4096)."\n"; 
  $stamp= date( 'Y-m-d H:i:s', time());
  
  $status="ok";

  $query = " CREATE TABLE IF NOT EXISTS `".$dbVisitorsTable."` (
    `id` int(11) NOT NULL,
    `date` datetime NOT NULL,
    `ip` varchar(40) NOT NULL,
    `ua` varchar(200) NOT NULL,
    `uri` varchar(255) NOT NULL,
    `ssid` varchar(100) NOT NULL,
     KEY (`id`)
  ) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;
  ";

  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : creation of table sucessful : ").$dbVisitorsTable;
  echo_flush($status, $msg,''); 
  
  if ($chain) $step = "updatezads45"; 
  else $step="end";  
}

// ------------------- update 4.0 ---------------------------------
if (($step=='updatezads40')) {  
  echo str_pad('<h1  class="start">'._('Updating SQL table for 4.0 compatibilty...').'</h1>',4096)."\n"; 
  $stamp= date( 'Y-m-d H:i:s', time());
  
  
  $status="ok";
  $query = "
          ALTER TABLE `$dbItemsTable` 
            ADD `loclatlng` VARCHAR(40) NOT NULL AFTER `location`,
            ADD `loczipcode` VARCHAR(10) NOT NULL AFTER `loclatlng`, 
            ADD `loccity` VARCHAR(100) NOT NULL AFTER `loczipcode`, 
            ADD `locdept` VARCHAR(40) NOT NULL AFTER `loccity`, 
            ADD `locregion` VARCHAR(40) NOT NULL AFTER `locdept`, 
            ADD `loccountrycode` VARCHAR(2) NOT NULL AFTER `locregion`, 
            ADD `lochash` VARCHAR(300) NOT NULL AFTER `loccountrycode`, 
            ADD `lochashregion` VARCHAR(200) NOT NULL AFTER `lochash`
          ";
          
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : ALTER of table sucessful : ").$dbUsersTable;
  echo_flush($status, $msg,''); 
  
  if ($chain) $step = "createadmin"; 
  else $step="end";  
}


// ------------------- update 4.5 ---------------------------------
if (($step=='updatezads45')) {  
  echo str_pad('<h1  class="start">'._('Updating and creating SQL table for 4.5 compatibilty...').'</h1>',4096)."\n"; 
  $stamp= date( 'Y-m-d H:i:s', time());
  
  // update existing table 
  
  $status="ok";
  $query = "
          ALTER TABLE `$dbItemsTable` 
            ADD `videoembed` VARCHAR(1000) NOT NULL AFTER `imgname`,
            ADD `paidoptions` VARCHAR(255) NOT NULL AFTER `priority`,
            ADD `payment` VARCHAR(255) NOT NULL AFTER `status`,
            ADD `loclat` DOUBLE NOT NULL AFTER `loclatlng`,
            ADD `loclng` DOUBLE NOT NULL AFTER `loclatlng`
            
          ";
          
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : ALTER/CREATION of table sucessful : ").$dbItemsTable;
  echo_flush($status, $msg,''); 



  // update existing table 
  $status="ok";
  $query = "
          ALTER TABLE `$dbUsersTable` 
            ADD `videoembed` VARCHAR(1000) NOT NULL AFTER `folioimg`,
            ADD `paidoptions` VARCHAR(255) NOT NULL AFTER `priority`,
            ADD `payment` VARCHAR(255) NOT NULL AFTER `status`,
            ADD `loclat` DOUBLE NOT NULL AFTER `loclatlng`,
            ADD `loclng` DOUBLE NOT NULL AFTER `loclatlng`
          ";
          
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : ALTER/CREATION of table sucessful : ").$dbUsersTable;
  echo_flush($status, $msg,''); 

  // create new table for storing  paypal content 

  $status="ok";
   $query = " CREATE TABLE IF NOT EXISTS `".$dbPaymentsTable."` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `paymentdate` datetime NOT NULL,
      `transactionid` varchar(20) NOT NULL,
      `paymentstatus` varchar(10) NOT NULL,
      `payerid` varchar(20) NOT NULL,
      `userid` int(11) NOT NULL,
      `amt` varchar(20) NOT NULL,
      `currencycode` varchar(3) NOT NULL,
      `token` varchar(20) NOT NULL,
      `what` varchar(5) NOT NULL,
      `whatid` int(11) NOT NULL,
      `note` varchar(255) NOT NULL,
      PRIMARY KEY (`id`)
    ) ENGINE=MyISAM  DEFAULT CHARSET=latin1;
    ";

  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : creation of table PAYMENT sucessful : ").$dbPaymentsTable;
  echo_flush($status, $msg,''); 

    // create new table for banner management

  $status="ok";
   $query = " CREATE TABLE IF NOT EXISTS `".$dbBannersTable."` (
     `id` int(11) NOT NULL AUTO_INCREMENT,
      `moddate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
      `title` varchar(255) DEFAULT NULL,
      `htmlcode` varchar(1500) DEFAULT NULL,
      `type` varchar(10) NOT NULL DEFAULT 'sell',
      `priority` varchar(10) NOT NULL,
      `imgname` varchar(255) DEFAULT NULL,
      `location` varchar(100) NOT NULL,
      `loclat` double NOT NULL,
      `userid` int(11) NOT NULL DEFAULT '0',
      `status` varchar(2) NOT NULL,
      `logs` varchar(1000) NOT NULL,
      `clicks` int(10) NOT NULL DEFAULT '0',
      `impressions` int(10) NOT NULL DEFAULT '0',
      `startdate` datetime NOT NULL,
      `enddate` datetime NOT NULL,
      `clicktrackingurl` varchar(200) NOT NULL,
      `maxclick` int(11) NOT NULL,
      `maxshown` int(11) NOT NULL,
      `position` varchar(100) NOT NULL,
      `weight` int(11) NOT NULL,
      PRIMARY KEY (`id`)
    ) ENGINE=MyISAM  DEFAULT CHARSET=latin1;
    ";

  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : creation of table BANNER sucessful : ").$dbBannersTable;
  echo_flush($status, $msg,''); 

  if ($chain) $step = "updatezads48"; 
  else $step="end";  
}


// ------------------- update 4.8 ---------------------------------
if (($step=='updatezads48')) {  
  echo str_pad('<h1  class="start">'._('Updating and Creating SQL table for 4.9 compatibilty...').'</h1>',4096)."\n"; 
  $stamp= date( 'Y-m-d H:i:s', time());
  
  // update existing table 
  $status="ok";
  $query = "
          ALTER TABLE `$dbCatsTable`  
            ADD `pid` VARCHAR(10) DEFAULT NULL, 
            ADD `order` INT(11) NOT NULL, 
            ADD `fieldset` VARCHAR(255) NOT NULL, 
            ADD `iconname` VARCHAR(255) NOT NULL,
            ADD `t_title` VARCHAR(1000) DEFAULT NULL, 
            ADD `t_meta` VARCHAR(1000) DEFAULT NULL 
          ";
          
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : ALTER/CREATION of table sucessful : ").$dbCatsTable;
  echo_flush($status, $msg,''); 

  $status="ok";
  $query = "ALTER TABLE `$dbUsersTable` 
            CHANGE `prowebsite` `prowebsite` VARCHAR(200) CHARACTER  
            SET latin1 COLLATE latin1_swedish_ci NOT NULL
          ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : ALTER/CREATION of table sucessful : ").$dbUsersTable;
  echo_flush($status, $msg,''); 

  $status="ok";
  $query = "ALTER TABLE `$dbItemsTable` 
            CHANGE `imgname` `imgname` VARCHAR(1000) CHARACTER  
            SET latin1 COLLATE latin1_swedish_ci NOT NULL
          ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : ALTER/CREATION of table sucessful : ").$dbItemsTable;
  echo_flush($status, $msg,''); 
  

  // zads 4.9 (+ plan management)
  $status="ok";
  $query = "
          ALTER TABLE `$dbUsersTable`  
            ADD `plan` VARCHAR(10) DEFAULT NULL,
            ADD `plan_details` VARCHAR(255) DEFAULT NULL,  
            ADD `longdesc` VARCHAR(1000) NOT NULL DEFAULT '',
            ADD  `openhours` VARCHAR(100) NOT NULL DEFAULT '',
            ADD  `useragent` VARCHAR(200) NOT NULL DEFAULT  '',
            ADD  `ip` VARCHAR(40) NOT NULL DEFAULT  ''
          ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : ALTER/CREATION of table sucessful : ").$dbUsersTable;
  echo_flush($status, $msg,''); 


  // zads 4.9.1 (bug corrections
  $status="ok";
  $query = "
          ALTER TABLE `$dbUsersTable`  
            ADD  `hits` int(10) NOT NULL DEFAULT '0'
          ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : ALTER/CREATION of table sucessful : ").$dbUsersTable;
  echo_flush($status, $msg,''); 


  // zads 4.9, add price type qualifier 
  $status="ok";
  $query = " 
          ALTER TABLE  `$dbItemsTable` 
            ADD  `pricetype` VARCHAR( 4 ) NOT NULL DEFAULT  '' AFTER  `price`,
            ADD  `expiredate` DATETIME NULL
          ";


  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : ALTER/CREATION of table sucessful : ").$dbItemsTable;
  echo_flush($status, $msg,''); 


  
  if ($chain) $step = "updatezads50"; 
  else $step="end";  
}

// ------------------- update 5.0 ---------------------------------
if (($step=='updatezads50')) {  
  echo str_pad('<h1  class="start">'._('Updating and Creating SQL table for 5.0 compatibilty...').'</h1>',4096)."\n"; 
  $stamp= date( 'Y-m-d H:i:s', time());
  
  // update existing table 
  $status="ok";
  $query = "
          ALTER TABLE `$dbUsersTable` 
          ADD `desc2` VARCHAR(2000) NOT NULL, 
          ADD `desc3` VARCHAR(2000) NOT NULL, 
          ADD `links` VARCHAR(1000) NOT NULL, 
          ADD `email2` VARCHAR(200) NOT NULL, 
          ADD `phone2` VARCHAR(30) NOT NULL, 
          ADD `address2` VARCHAR(200) NOT NULL, 
          ADD `cat2` VARCHAR(100) NOT NULL,
          ADD `cat3` VARCHAR(100) NOT NULL, 
          ADD `date2` DATE NOT NULL
        ";

          
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : ALTER/CREATION of table sucessful : ").$dbUsersTable;
  echo_flush($status, $msg,''); 


  if ($chain) $step = "updatezads55"; 
  else $step="end";  
}


// ------------------- update 5.5 ---------------------------------
if (($step=='updatezads55')) {  
  echo str_pad('<h1  class="start">'._('Updating and Creating SQL table for 5.1 compatibilty...').'</h1>',4096)."\n"; 
  $stamp= date( 'Y-m-d H:i:s', time());


  // create  V-FIELDS TABLE // 
  $status="ok";

   $query = " CREATE TABLE IF NOT EXISTS `".$dbVFieldsTable."` (
     `id` int(11) NOT NULL AUTO_INCREMENT,
      `moddate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
      `int_label` varchar(255) DEFAULT NULL,
      `disp_label` varchar(255) DEFAULT NULL,
      `domtype` varchar(10) NOT NULL DEFAULT 'input',
      `domsubtype` varchar(10) DEFAULT NULL ,
      `unit` varchar(100) DEFAULT NULL ,
      `values` varchar(1000) DEFAULT NULL,
      `default` varchar(10) DEFAULT NULL,
      `userid` varchar(10) DEFAULT NULL,
      `forwhat` varchar(10) DEFAULT NULL,
      `scope` varchar(10) NOT NULL DEFAULT 'cat',
      `linkedvfield` varchar(10) NOT NULL DEFAULT '',
      `status` varchar(2) NOT NULL,
      PRIMARY KEY (`id`)
    ) ENGINE=MyISAM  DEFAULT CHARSET=latin1;
    ";

  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : CREATION of table sucessful : ").$dbVFieldsTable;
  echo_flush($status, $msg,''); 


  // create  SUBSCRIBERS TABLE  // 
  $status="ok";

  // ------------------- USERS ---------------------------------
  $status="ok";
  $query = "  
      CREATE TABLE IF NOT EXISTS `".$dbSubscribersTable."` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `gender` varchar(6) NOT NULL,
      `firstname` varchar(50) NOT NULL DEFAULT '',
      `lastname` varchar(50) NOT NULL DEFAULT '',
      `username` varchar(25) NOT NULL DEFAULT '',
      `avatarimg` varchar(255) NOT NULL,
      `priority` varchar(10) NOT NULL,
      `expiredate` datetime NOT NULL,
      `email` varchar(100) NOT NULL DEFAULT '',
      `location` varchar(100) NOT NULL,
      `locale` varchar(6) NOT NULL,
      `password` varchar(100) NOT NULL DEFAULT '',
      `auth` varchar(2) NOT NULL,
      `usertype` tinyint(25) unsigned NOT NULL DEFAULT '0',
      `status` varchar(2) NOT NULL,
      `registerdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
      `moddate` datetime NOT NULL,
      `lastvisitdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
      `lastemaildate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
      `activation` varchar(100) NOT NULL DEFAULT '',
      `subfeeds` varchar(100) NOT NULL DEFAULT '',
      `preferences` text NOT NULL,
      `os` varchar(40) NOT NULL DEFAULT '',
      `browser` varchar(40) NOT NULL DEFAULT '',
      `version` varchar(40) NOT NULL DEFAULT '',
      PRIMARY KEY (`id`)
    ) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=86 ;
  ";
  
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : CREATION of table sucessful : ").$dbSubscribersTable;
  echo_flush($status, $msg,''); 




  // ------------------- CATEGORIES TABLE UPDATE for VFIELDS and MORE  ---------------------------------
  $status="ok";
  $query = "
          ALTER TABLE `$dbCatsTable` 
          ADD `links` VARCHAR(1000) NOT NULL, 
          ADD `catlvfields` VARCHAR(200) NOT NULL, 
          ADD `acl` VARCHAR(10) NOT NULL, 
          ADD `password` VARCHAR(10) NOT NULL,
          ADD `audiourl` VARCHAR(200) NOT NULL,
          ADD `videourl` VARCHAR(200) NOT NULL
        ";

          
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbCatsTable;
  echo_flush($status, $msg,''); 



  // ------------------- ITEM/AD TABLE UPDATE for VFIELDS and MORE  ---------------------------------
  $status="ok";
  $query = "
          ALTER TABLE `$dbItemsTable` 
          ADD `vfields` VARCHAR(200) NOT NULL
        ";

          
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbItemsTable;
  echo_flush($status, $msg,''); 




  if ($chain) $step = "updatezads551"; 
  else $step="end";  
}

// ------------------- update 5.5.1 ---------------------------------
if (($step=='updatezads551')) {  
  echo str_pad('<h1  class="start">'._('Updating and Creating SQL table for 5.5.1 compatibilty...').'</h1>',4096)."\n"; 
  $stamp= date( 'Y-m-d H:i:s', time());


  // ------------------- USER TABLE UPDATE for VFIELDS and MORE  ---------------------------------
  $status="ok";
  $query = "
          ALTER TABLE `$dbUsersTable` 
          ADD `vfields` VARCHAR(200) NOT NULL
        ";

          
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbItemsTable;
  echo_flush($status, $msg,''); 



  // ------------------- VFIELDS category update 5.5.1 ---------------------------------
  $status="ok";
  $query = "
          ALTER TABLE `$dbVFieldsTable` 
          ADD `stype` VARCHAR(10) NOT NULL DEFAULT '' AFTER `domsubtype`, 
          ADD `xmandatory` VARCHAR(10) NOT NULL  ,
          ADD `xmin` VARCHAR(10) NOT NULL  ,
          ADD `xmax` VARCHAR(10) NOT NULL ,
          ADD `xregx` VARCHAR(10) NOT NULL ,
          ADD `xvisible` VARCHAR(10) NOT NULL ,
          ADD `forprofile` VARCHAR(10) NOT NULL  
        ";

          
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbVFieldsTable;
  echo_flush($status, $msg,''); 

    // ------------------- SUBSCRIBERS  category update 5.5.1 ---------------------------------
  $status="ok";
  $query = "
          ALTER TABLE `$dbSubscribersTable` 
          ADD `hashid` VARCHAR(40) NOT NULL  AFTER `id`, 
          ADD `phone` VARCHAR(20) NOT NULL
        ";

          
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbSubscribersTable;
  echo_flush($status, $msg,''); 


  if ($chain) $step = "updatezads600"; 
  else $step="end";  
}


// ------------------- update 6.0.0 ---------------------------------
if (($step=='updatezads600')) {  
  echo str_pad('<h1  class="start">'._('Updating and Creating SQL table for 6.0.0 compatibilty...').'</h1>',4096)."\n"; 
  $stamp= date( 'Y-m-d H:i:s', time());


  // ------------------- USER TABLE UPDATE  ---------------------------------
  $status="ok";
  $query = "
          ALTER TABLE `$dbUsersTable` 
          ADD `video2` VARCHAR(1000) NOT NULL, 
          ADD `audiourl` VARCHAR(200) NOT NULL,
          ADD `banclicks` int(10) NOT NULL DEFAULT '0'
        ";
         
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbUsersTable;
  echo_flush($status, $msg,''); 


  // ------------------- ITEM TABLE UPDATE  ---------------------------------
  $status="ok";
  $query = "
          ALTER TABLE `$dbItemsTable` 
          ADD `video2` VARCHAR(1000) NOT NULL, 
          ADD `audiourl` VARCHAR(200) NOT NULL
        ";

          
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbItemsTable;
  echo_flush($status, $msg,''); 

  // ------------------- AD TABLE UPDATE  ---------------------------------
  $status="ok";
  $query = "
          ALTER TABLE `$dbItemsTable` 
          ADD  `createdate` datetime NOT NULL ,
          ADD  `firstpublisheddate` datetime NOT NULL ,
          ADD  `crondate` datetime NOT NULL ,
          ADD  `urgent` varchar(10) NOT NULL
        ";

          
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbItemsTable;
  echo_flush($status, $msg,''); 


  // ------------------- USER TABLE UPDATE  ---------------------------------
  $status="ok";
  $query = "
          ALTER TABLE `$dbUsersTable` 
          ADD  `indir` varchar(10) NOT NULL
        ";

          
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbUsersTable;
  echo_flush($status, $msg,''); 

  // ------------------- CREATE SERVICES TABLE ---------------------------------

  $status="ok";
  $query = " CREATE TABLE IF NOT EXISTS `".$dbServicesTable."` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `moddate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
    `createdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
    `firstpublisheddate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
    `startdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
    `enddate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
    `status` varchar(4) DEFAULT NULL,
    `name` varchar(255) DEFAULT NULL,
    `sid` varchar(10) DEFAULT NULL,
    `sdesc` varchar(200) DEFAULT NULL,
    `ldesc` varchar(1000) DEFAULT NULL,
    `type` varchar(10) NOT NULL DEFAULT 'sell',
    `priority` varchar(10) NOT NULL,
    `userid` int(11) NOT NULL DEFAULT '0',
    `payment` varchar(255) NOT NULL,
    `paidoptions` varchar(255) NOT NULL,
    `paymentdate` datetime NOT NULL,
    `transactionid` varchar(20) NOT NULL,
    `paymentstatus` varchar(10) NOT NULL,
    `priceid` varchar(10) DEFAULT NULL,
    `pricevat` varchar(10) DEFAULT NULL,
    `price` varchar(20) DEFAULT '0',
    `options` varchar(200) DEFAULT NULL,
    `remain` varchar(200)  DEFAULT NULL,
    
      PRIMARY KEY (`id`)
  ) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=625 ;
  ";
  
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : CREATION of table sucessful : ").$dbServicesTable;
  echo_flush($status, $msg,''); 


  if ($chain) $step = "updatezads61"; 
  else $step="end";  
}


// ------------------- update 6.1.0 ---------------------------------
if (($step=='updatezads61')) {  
  echo str_pad('<h1  class="start">'._('Updating and Creating SQL table for 6.1.x compatibilty...').'</h1>',4096)."\n"; 
  $stamp= date( 'Y-m-d H:i:s', time());


  // ------------------- CATEGORIES TABLE ADD : ADULT TAG  --------------------------------
  $status="ok";
  $query = "
          ALTER TABLE `$dbCatsTable` 
          ADD `adultflag` VARCHAR(4) NOT NULL, 
          ADD `adulttext` VARCHAR(1000) NOT NULL
        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbCatsTable;
  echo_flush($status, $msg,''); 




  // ------------------- ITEM TABLE UPDATE : add LINKS  ---------------------------------
  $status="ok";
  $query = "
          ALTER TABLE `$dbItemsTable` 
          ADD `links` VARCHAR(1000) NOT NULL
        ";

  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbItemsTable;
  echo_flush($status, $msg,''); 


  // ------------------- ITEM TABLE UPDATE : add VTAGS  ---------------------------------
  $status="ok";
  $query = "
          ALTER TABLE `$dbItemsTable` 
          ADD `vtag1` VARCHAR(10) NOT NULL,
          ADD `vtag2` VARCHAR(10) NOT NULL,
          ADD `vtag3` VARCHAR(10) NOT NULL,
          ADD `vtag4` VARCHAR(10) NOT NULL,
          ADD `vtag5` VARCHAR(10) NOT NULL
        ";

  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbItemsTable;
  echo_flush($status, $msg,''); 


   // ------------------- PAYMENTS TABLE UPDATE : addDOM CONTENT   ---------------------------------
  $status="ok";
  $query = "
          ALTER TABLE `$dbPaymentsTable` 
          ADD `bom` VARCHAR(255) NOT NULL,
          ADD `vat` VARCHAR(4) NOT NULL, 
          ADD `recurrent` VARCHAR(4) NOT NULL
        ";

  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbPaymentsTable;
  echo_flush($status, $msg,''); 


  $status="ok";
  $query = "
          ALTER TABLE  `$dbPaymentsTable` 
          CHANGE  `paymentstatus`  `paymentstatus` VARCHAR( 14 )
          ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbPaymentsTable;
  echo_flush($status, $msg,''); 





    // ------------------- USER  TABLE UPDATE : add NEWSLETTER  ---------------------------------
  $status="ok";
  $query = "
          ALTER TABLE `$dbUsersTable` 
          ADD `newsletter` VARCHAR(10) NOT NULL
        ";

  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbUsersTable;
  echo_flush($status, $msg,''); 

  // ------------------- USER  TABLE UPDATE : change type of   ---------------------------------

  $status="ok";
  $query = "
          ALTER TABLE  `$dbServicesTable` 
          CHANGE  `price`  `price` VARCHAR(20) NULL DEFAULT '0'
          ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbServicesTable;
  echo_flush($status, $msg,''); 


  // ------------------- CREATE the default ZETEVU categorie  ---------------------------------

  $status="ok";
  $query = " INSERT INTO `$dbCatsTable`  (`id`, `catid`, `moddate`, `title`, `description`, `status`) 
                  VALUES ('9999', '0', $stamp', 'ZETEVU**DONOTDELETE', 'ZETEVU**DONOTDELETE', '40')"; 


  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : Creation of default ZETEVU categorie : ").$dbCatsTable;
  echo_flush($status, $msg,''); 


  // ZADS 6.1.5 
  // ------------------- update    ---------------------------------

  $status="ok";
  $query = "
          ALTER TABLE `$dbUsersTable` 
          ADD `probannerurl` VARCHAR(200) NOT NULL
        ";

  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : update of table done : ").$dbUsersTable;
  echo_flush($status, $msg,''); 


  if ($chain) $step = "updatezads62"; 
  else $step="end";  


}


// ------------------- update 6.2.0 ---------------------------------
if (($step=='updatezads62')) {  
  echo str_pad('<h1  class="start">'._('Updating and Creating SQL table for 6.2 compatibilty...').'</h1>',4096)."\n"; 
  $stamp= date( 'Y-m-d H:i:s', time());


  // ------------------- CREATE THE BOOKING TABLE  --------------------------------
  $status="ok";
 
  $status="ok";
  $query = " CREATE TABLE IF NOT EXISTS `".$dbBookingsTable."` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `bo_moddate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
    `bo_createdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
    `status` varchar(4) DEFAULT NULL,
    `bo_title` varchar(255) DEFAULT NULL,
    `bo_name2` varchar(255) DEFAULT NULL,
    `userid` int(11) NOT NULL DEFAULT '0',
    `bo_ad_id` int(11) NOT NULL DEFAULT '0',
    `bo_start_date` DATE NOT NULL,
    `bo_end_date` DATE NOT NULL,
    `type` varchar(10) NOT NULL,
    `bo_gender` varchar(6) NOT NULL,
    `bo_firstname` varchar(50) NOT NULL DEFAULT '',
    `bo_lastname` varchar(50) NOT NULL DEFAULT '',
    `bo_email` varchar(100) NOT NULL DEFAULT '',
    `social` varchar(200) NOT NULL,
    `bo_phone` varchar(20) NOT NULL,
    `bo_location` varchar(100) NOT NULL,
    `bo_nbadults` varchar(10) NOT NULL,
    `bo_nbchild` varchar(10) NOT NULL,
    `bo_comments` varchar(255) NOT NULL, 
      PRIMARY KEY (`id`)
  ) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=625 ;
  ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : Creation of  table<b> $dbBookingsTable </b>sucessfull : ");
  echo_flush($status, $msg,''); 

    $query = "
          ALTER TABLE `$dbBookingsTable` 
          ADD INDEX ( `bo_ad_id` ),
          ADD INDEX ( `bo_start_date`),
          ADD INDEX ( `bo_end_date` )
        ";
  $result = mysql_query($query);

  
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : INDEX update for table<b> $dbBookingsTable </b>sucessfull : ");
  echo_flush($status, $msg,''); 

  if ($chain) $step = "updatezads64"; 
  else $step="end";  

}


// ------------------- update 6.4.0 ---------------------------------
if (($step=='updatezads64')) {  
  echo str_pad('<h1  class="start">'._('Updating and Creating SQL table for 6.4 compatibilty...').'</h1>',4096)."\n"; 
  $stamp= date( 'Y-m-d H:i:s', time());


  // ------------------- UPDATE  CATS TABLE --------------------------------
  // add the CALENDAR option 
  $status="ok";
   $query = "
          ALTER TABLE `$dbCatsTable` 
          ADD `hascalendar` VARCHAR(4) NOT NULL, 
          ADD `calendartype` VARCHAR(100) NOT NULL

        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbCatsTable;
  echo_flush($status, $msg,''); 



  // ------------------- UPDATE  USER TABLE  --------------------------------
  // add the refered string 
  $status="ok";
   $query = "
          ALTER TABLE `$dbUsersTable` 
          
          ADD `imgpath` VARCHAR(200) NOT NULL
        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbUsersTable;
  echo_flush($status, $msg,''); 


  // ------------------- INCREASE SIZE of ITEM TABLE  --------------------------------
  // add the CALENDAR option 
  $status="ok";
   $query = "
          ALTER TABLE `$dbItemsTable` 
          CHANGE `description` `description` VARCHAR(1500)          
        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbItemsTable;
  echo_flush($status, $msg,''); 
 



  if ($chain) $step = "updatezads65"; 
  else $step="end";  

}

// ------------------- update 6.5.0 ---------------------------------
if (($step=='updatezads65')) {  
  echo str_pad('<h1  class="start">'._('Updating and Creating SQL table for 6.5 compatibilty...').'</h1>',4096)."\n"; 
  $stamp= date( 'Y-m-d H:i:s', time());


  // ------------------- UPDATE  USER TABLE  --------------------------------
  // add Video url field 
  $status="ok";
   $query = "
          ALTER TABLE `$dbUsersTable` 
          ADD `videourl` VARCHAR(200) NOT NULL
        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbUsersTable;
  echo_flush($status, $msg,''); 


  // ------------------- UPDATE  AD TABLE   --------------------------------
  // add Video url field 
  $status="ok";
   $query = "
          ALTER TABLE `$dbItemsTable` 
          ADD `videourl` VARCHAR(200) NOT NULL          
        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbItemsTable;
  echo_flush($status, $msg,''); 

    // ------------------- UPDATE  USER TABLE  --------------------------------
  // add Video url field 
  $status="ok";
   $query = "
          ALTER TABLE `$dbUsersTable` 
          ADD `likes` int(10) NOT NULL DEFAULT '0'
        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbUsersTable;
  echo_flush($status, $msg,''); 


  // ------------------- UPDATE  AD TABLE   --------------------------------
  // add Video url field 
  $status="ok";
   $query = "
          ALTER TABLE `$dbItemsTable` 
          ADD `likes` int(10) NOT NULL DEFAULT '0'          
        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbItemsTable;
  echo_flush($status, $msg,''); 
 

    // ------------------- UPDATE  USER TABLE  --------------------------------
  // incease size of IMGPORTFOLIO
  $status="ok";
   $query = "
          ALTER TABLE `$dbUsersTable` 
          CHANGE `folioimg` `folioimg` VARCHAR(1000)  
        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table with FOLIOIMG sucessfull : ").$dbUsersTable;
  echo_flush($status, $msg,''); 


  // ------------------- UPDATE  AD TABLE  --------------------------------
  // incease size of IMGPORTFOLIO
  $status="ok";
   $query = "
          ALTER TABLE `$dbItemsTable` 
          CHANGE `imgname` `imgname` VARCHAR(1000)  
        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table with IMGNAME sucessfull : ").$dbItemsTable;
  echo_flush($status, $msg,''); 


    // ------------------- UPDATE  USER TABLE  --------------------------------
  // incease size of IMGPORTFOLIO
  $status="ok";
   $query = "
          ALTER TABLE `$dbUsersTable` 
          CHANGE `longdesc` `longdesc` VARCHAR(1500)  
        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table with LONGDESC sucessfull : ").$dbUsersTable;
  echo_flush($status, $msg,''); 


// ------------------- CATEGORIES TABLE ADD : Apricetype  --------------------------------
  $status="ok";
  $query = "
          ALTER TABLE `$dbCatsTable` 
          ADD `pricetype` VARCHAR(4) NOT NULL DEFAULT ''
        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbCatsTable;
  echo_flush($status, $msg,''); 


  // ---- end of processing -------
  if ($chain) $step = "updatezads67"; 
  else $step="end";  

}




// ------------------- update 6.7.0 ---------------------------------
if (($step=='updatezads67')) {  
  echo str_pad('<h1  class="start">'._('Updating and Creating SQL table for 6.7 compatibilty...').'</h1>',4096)."\n"; 
  $stamp= date( 'Y-m-d H:i:s', time());


  // ------------------- CATEGORIES TABLE ADD : META-TITLE  --------------------------------
  $status="ok";
  $query = "
          ALTER TABLE `$dbCatsTable` 
          ADD `metatitle` VARCHAR(70) NOT NULL DEFAULT ''
          ,ADD `metadesc` VARCHAR(200) NOT NULL DEFAULT ''
          ,ADD `metakey` VARCHAR(200) NOT NULL DEFAULT ''
        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbCatsTable;
  echo_flush($status, $msg,'');


  // ------------------- UPDATE  AD TABLE   --------------------------------
  // add Video url field 
  $status="ok";
   $query = "
          ALTER TABLE `$dbItemsTable` 
          ADD `price2` float DEFAULT NULL, 
          ADD `pricetype2` VARCHAR( 4 ) NOT NULL DEFAULT  '',
          ADD `docurl` VARCHAR(400) NOT NULL
        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbItemsTable;
  echo_flush($status, $msg,''); 
 

  // ------------------- CREATE A NEW TABLE for PASSWORD RECOVERY --------------------------------
  $status="ok";
   $query = "
      CREATE TABLE IF NOT EXISTS `$dbKeysTable` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `userid` int(10) NOT NULL,
        `key` varchar(32) NOT NULL,
        `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `status` varchar(7) NOT NULL,
        UNIQUE KEY `id_2` (`id`),
        KEY `id` (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=latin1;
    "; 

     $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : Creation of table sucessfull : ").$dbKeysTable;
  echo_flush($status, $msg,'');



  // ---- end of processing -------
  if ($chain) $step = "updatezads68"; 
  else $step="end";  

}


// ------------------- update 6.8.0 ---------------------------------
if (($step=='updatezads68')) {  
  echo str_pad('<h1  class="start">'._('Updating and Creating SQL table for 6.8 compatibilty...').'</h1>',4096)."\n"; 
  $stamp= date( 'Y-m-d H:i:s', time());


 // ------------------- UPDATE  AD TABLE   --------------------------------
  // vcounters stored various counters linked to ad. No SORT possible on them as they are stored as JSON string key=value;key=value; ...
  $status="ok";
   $query = "
          ALTER TABLE `$dbItemsTable` 
          ADD `vcounters` VARCHAR( 40 ) NOT NULL DEFAULT  ''
        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbItemsTable;
  echo_flush($status, $msg,''); 
 
  // ---- end of processing -------
  if ($chain) $step = "updatezads69"; 
  else $step="end";  

}



// ------------------- update 6.9.0 ---------------------------------
if (($step=='updatezads69')) {  
  echo str_pad('<h1  class="start">'._('Updating and Creating SQL table for 6.9 compatibilty...').'</h1>',4096)."\n"; 
  $stamp= date( 'Y-m-d H:i:s', time());


 // ------------------- CREATE A NEW TABLE FOR COMunincations (review / messages/ ...)  --------------------------------
  $status="ok";
   $query = "
      CREATE TABLE IF NOT EXISTS `$dbComsTable` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `moddate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
        `createdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',

        `type` varchar(10) NOT NULL DEFAULT 'review',
        `status` varchar(2) NOT NULL,
        `hits` int(10) NOT NULL DEFAULT '0',
        `likes` int(10) NOT NULL DEFAULT '0',
        `title` varchar(255) DEFAULT NULL,
        `description` varchar(1000) DEFAULT NULL,


        `comid` varchar(32) NOT NULL,  
        `fromid` int(11) NOT NULL DEFAULT '0',
        `toid` int(11) NOT NULL DEFAULT '0',
        `replyid` int(11) NOT NULL DEFAULT '0',
        `fromusername` varchar(30) NOT NULL,
        `fromemail` varchar(40) NOT NULL,
        `whatid` int(11) NOT NULL DEFAULT '0',

        `fromip` INT(11) UNSIGNED,
        `toip` INT(11) UNSIGNED,

        `abuse` varchar(2) NOT NULL,

        `rating1` FLOAT default 0,
        `rating2` FLOAT default 0,
        `rating3` FLOAT default 0,

        UNIQUE KEY `id_3` (`id`),
        KEY `id` (`id`)
    ) ENGINE=InnoDB CHARACTER SET=utf8;
    "; 

     $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : Creation of table sucessfull : ").$dbComsTable;
  echo_flush($status, $msg,'');


  // change format of toid 
  $status="ok";
   $query = "
          ALTER TABLE `$dbComsTable` 
          CHANGE `toip` `toip` VARCHAR(32)  
        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table  : ").$dbComsTable;
  echo_flush($status, $msg,''); 


 // ------------------- UPDATE  TABLE   --------------------------------
  //add the wat parameter  
  $status="ok";
   $query = "
          ALTER TABLE `$dbComsTable` 
          ADD `what` VARCHAR(10) NOT NULL DEFAULT  ''
        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbComsTable;
  echo_flush($status, $msg,''); 

 
  // ---- end of processing -------
  if ($chain) $step = "updatezads70"; 
  else $step="end";  

}

// ------------------- update 7.0.0 ---------------------------------
if (($step=='updatezads70')) {  
  echo str_pad('<h1  class="start">'._('Updating and Creating SQL table for 7.0 compatibilty...').'</h1>',4096)."\n"; 
  $stamp= date( 'Y-m-d H:i:s', time());


 // ------------------- UPDATE  TABLE CATEGORIES    --------------------------------
  $status="ok";
   $query = "
          ALTER TABLE `$dbCatsTable` 
           ADD `protype` VARCHAR(4) NOT NULL DEFAULT  ''
          ,ADD `specialterms` VARCHAR(20) NOT NULL DEFAULT  ''

        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbCatsTable;
  echo_flush($status, $msg,''); 

 
  // ---- end of processing -------
  if ($chain) $step = "updatezads71"; 
  else $step="end";  

}

// ------------------- update 7.0.0 ---------------------------------
if (($step=='updatezads71')) {  
  echo str_pad('<h1  class="start">'._('Updating and Creating SQL table for 7.1 compatibilty...').'</h1>',4096)."\n"; 
  $stamp= date( 'Y-m-d H:i:s', time());


 // ------------------- UPDATE  TABLE USER    --------------------------------
  $status="ok";
   $query = "
          ALTER TABLE `$dbUsersTable` 
           ADD `verify` VARCHAR(200) NOT NULL DEFAULT  ''
          ,ADD `verify2` VARCHAR(10) NOT NULL DEFAULT  ''
          ,ADD `verify3` VARCHAR(10) NOT NULL DEFAULT  ''
        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbUsersTable;
  echo_flush($status, $msg,''); 

 $status="ok";
   $query = "
          ALTER TABLE `$dbUsersTable` 
           ADD `dob` date NOT NULL,
           ADD `xplevel` VARCHAR(10) NOT NULL DEFAULT  '',
           ADD `mynotif` VARCHAR(200) NOT NULL DEFAULT  '',
           ADD `optin` VARCHAR(200) NOT NULL DEFAULT  ''
        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbUsersTable;
  echo_flush($status, $msg,''); 



  // ------------------- UPDATE  TABLE KEYS    --------------------------------
  $status="ok";
   $query = "
          ALTER TABLE `$dbKeysTable` 
           ADD `type` VARCHAR(10) NOT NULL DEFAULT  'email'
        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbKeysTable;
  echo_flush($status, $msg,''); 

 
  // ---- end of processing -------
  if ($chain) $step = "updatezads73"; 
  else $step="end";  

}



// ------------------- update 7.3.0 ---------------------------------
if (($step=='updatezads73')) {  
  echo str_pad('<h1  class="start">'._('Updating and Creating SQL table for 7.3 compatibilty...').'</h1>',4096)."\n"; 
  $stamp= date( 'Y-m-d H:i:s', time());


  // ------------------- CREATE A NEW TABLE FOR ALERTS  --------------------------------
  $status="ok";
   $query = "
      CREATE TABLE IF NOT EXISTS `$dbAlertsTable` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `moddate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
        `createdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',

        `expiredate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
        `lastrundate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
        `lastemaildate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
        `lastcount` int(11) NOT NULL DEFAULT '0',

        `type` varchar(10) NOT NULL DEFAULT '',
        `status` varchar(2) NOT NULL DEFAULT '40',

        `title` varchar(255) DEFAULT NULL,
        `description` varchar(1000) DEFAULT NULL,

        `userid` int(11) NOT NULL DEFAULT '0',
        `useremail` varchar(40) NOT NULL,

        `filterparams` varchar(1000) DEFAULT NULL,


        UNIQUE KEY `id_3` (`id`),
        KEY `id` (`id`),
        KEY `userid` (`userid`)
    ) ENGINE=InnoDB CHARACTER SET=utf8;
    "; 

     $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : Creation of table sucessfull : ").$dbAlertsTable;
  echo_flush($status, $msg,'');



  // ---- end of processing -------
  if ($chain) $step = "updatezads74"; 
  else $step="end";  

}

// ------------------- update 7.4.0 ---------------------------------
if (($step=='updatezads74')) {  
  echo str_pad('<h1  class="start">'._('Updating and Creating SQL table for 7.4 compatibilty...').'</h1>',4096)."\n"; 
  $stamp= date( 'Y-m-d H:i:s', time());


  // ------------------- CREATE A NEW TABLE FOR ALERTS  --------------------------------
  $status="ok";
   $query = "
      CREATE TABLE IF NOT EXISTS `$dbListsTable` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `type` varchar(10) NOT NULL DEFAULT '',
        `key` varchar(40) NOT NULL DEFAULT '',
        `value` varchar(100) NOT NULL DEFAULT '',

        UNIQUE KEY `id_3` (`id`),
        KEY `id` (`id`),
        KEY `key` (`key`)
    ) ENGINE=InnoDB CHARACTER SET=utf8;
    "; 

  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : Creation of table sucessfull : ").$dbListsTable;
  echo_flush($status, $msg,'');


  // ------------------- UPDATE  VFIELD TAVLE   --------------------------------
  $status="ok";
   $query = "
          ALTER TABLE `$dbVFieldsTable` 
           ADD `linkedvar` VARCHAR(100) DEFAULT '',
           ADD `slaveid` int(10) NOT NULL DEFAULT '0'
        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbVFieldsTable;
  echo_flush($status, $msg,''); 


  // ---- end of processing -------
  if ($chain) $step = "alterutf8"; 
  else $step="end";  
}

// ------------------- changing to UTF8 and COLLATION existing DBs ---------------------------------
if (($step=='alterutf8')) {  
  // $query = "SET collation_connection = 'utf8_general_ci'"; 
  echo str_pad('<h1  class="start">'._('changing CHRARACTER SET and COLLATE to UTF8 ...').'</h1>',4096)."\n"; 

  // database 
  $query = "ALTER DATABASE `".$databasename."` CHARACTER SET utf8 COLLATE utf8_general_ci"; 
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : INDEX creation of table sucessfull : ").$dbItemsTable;
  echo_flush($status, $msg,''); 

  // tables     
  $dbtablelist = array($dbItemsTable, $dbCatsTable, $dbUsersTable, $dbStatsTable, $dbLogsTable,$dbPaymentsTable,$dbBannersTable, $dbComsTable, $dbKeysTable); 
  foreach ($dbtablelist as $thistable) {
    $status="ok";
    $query = "ALTER TABLE `".$thistable."` CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci"; 
    $result = mysql_query($query);
    if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
    else $msg =  _("MySQL : Table $thistable converted to UTF8  sucessfuly ").'\n\r';
    echo_flush($status, $msg,''); 
  }

    // ---- end of processing -------
  if ($chain) $step = "updatezads745"; 
  else $step="end"; 

}


// ------------------- update 7.4.5 ---------------------------------
if (($step=='updatezads745')) {  
  echo str_pad('<h1  class="start">'._('Updating and Creating SQL table for 7.4.5 compatibilty...').'</h1>',4096)."\n"; 
  $stamp= date( 'Y-m-d H:i:s', time());

  // ------------------- UPDATE  VFIELD TAVLE   --------------------------------
  $status="ok";
   $query = "
          ALTER TABLE `$dbUsersTable` 
           CHANGE `userid` `userid` BIGINT(20) NOT NULL
        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbUsersTable;
  echo_flush($status, $msg,''); 



  // ---- end of processing -------
  if ($chain) $step = "updatezads750"; 
  else $step="end";  
}

// ------------------- update 7.5.0 ---------------------------------
if (($step=='updatezads750')) {  
  echo str_pad('<h1  class="start">'._('Updating and Creating SQL table for 7.5.0 compatibilty...').'</h1>',4096)."\n"; 
  $stamp= date( 'Y-m-d H:i:s', time());

  // ------------------- UPDATE  VFIELD TAVLE   --------------------------------
  $status="ok";
  $query = "
          ALTER TABLE `$dbUsersTable` 
           ADD `createdby` VARCHAR(10) NOT NULL DEFAULT  ''
        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbUsersTable;
  echo_flush($status, $msg,''); 



  // ---- end of processing -------
  if ($chain) $step = "updatezads755"; 
  else $step="end";  
}


// ------------------- update 7.5.0 ---------------------------------
if (($step=='updatezads755')) {  
  echo str_pad('<h1  class="start">'._('Updating and Creating SQL table for 7.5.5 compatibilty...').'</h1>',4096)."\n"; 
  $stamp= date( 'Y-m-d H:i:s', time());

  // ------------------- UPDATE  VFIELD TAVLE   --------------------------------
  $status="ok";
  $query = "
          ALTER TABLE `$dbItemsTable` 
           CHANGE `description` `description` VARCHAR(5000) 
        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : UPdate of table sucessfull : ").$dbItemsTable;
  echo_flush($status, $msg,''); 


  // ---- end of processing -------
  if ($chain) $step = "createadmin"; 
  else $step="end";  
}




// ------------------- creating INDEXES in TABLES ---------------------------------
if (($step=='createindex')) {  
  echo str_pad('<h1  class="start">'._('Creating indexes...').'</h1>',4096)."\n"; 
  $stamp= date( 'Y-m-d H:i:s', time());

  $status="ok";
  $query = "
          ALTER TABLE `$dbItemsTable` 
          ADD INDEX (  `userid` ),
          ADD UNIQUE (`id`),
          ADD INDEX (  `catid` )
        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : INDEX creation of table sucessfull : ").$dbItemsTable;
  echo_flush($status, $msg,''); 


  $status="ok";
  $query = "
          ALTER TABLE `$dbUsersTable` 
          ADD INDEX ( `id` ),
          ADD UNIQUE (`id`)
        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : INDEX creation of table sucessfull : ").$dbUsersTable;
  echo_flush($status, $msg,''); 


  $status="ok";
  $query = "
          ALTER TABLE `$dbPaymentsTable` 
          ADD INDEX ( `whatid` ),
          ADD INDEX (`transactionid`)
        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : INDEX creation of table sucessfull : ").$dbPaymentsTable;
  echo_flush($status, $msg,''); 

  if ($chain) $step = "createadmin"; 
  else $step="end";  
}


// ------------------- CREATE DEFAULT USER/CAT/... etc ---------------------------------
if (($step=='createadmin')) {
  echo str_pad('<h1  class="start">'._('Creating default ADMIN user in DB...').'</h1>',4096)."\n"; 
  $stamp= date( 'Y-m-d H:i:s', time());  
  
  $status="ok";
  $query = "
  INSERT INTO `".$dbUsersTable."` ( `gender`, `firstname`, `lastname`, `username`, `accronym`, `email`, `phone`, `location`, `locale`, `password`, `auth`, `usertype`, `status`, `sendEmail`, `gid`, `registerdate`, `lastvisitdate`, `lastemaildate`, `activation`, `preferences`, `assocprojects`, `imgurl`, `userid`, `favads`, `protype`) VALUES
    ( '', '', '', '".trim($USER_ADMIN_LOGIN)."', '', '".$USER_ADMIN_EMAIL."', '', '', '', '".md5(trim($USER_ADMIN_PASSWORD))."', '', 9, '40', 0, 1, '".$stamp."', '".$stamp."', '', '', '', '10', '', 0, '', 'pri');
  "; 
  $result = mysql_query($query);
  $admin_id = mysql_insert_id(); 
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg =  _("MySQL : creation of ADMIN USER sucessful : ") . $admin_id;
  echo_flush($status, $msg,''); 
  
  if ($chain) $step = "createcatdef"; 
  else $step="end";
}



// ------------------- RESETADMIN PASSWORD  ---------------------------------
if (($step=='changeAdminPassword')) {

  if (!isset($_GET["newpassword"])) display_user_form($step); 
  else {

    echo str_pad('<h1  class="start">'._('Change ADMIN Password...').'</h1>',4096)."\n"; 
    $stamp= date( 'Y-m-d H:i:s', time());  
    $newPassword =  md5(trim( $_GET["newpassword"]));

    $status="ok";
    $query = "UPDATE `".$dbUsersTable."` SET   
            `password` = '".$newPassword."'
            WHERE ((`username` = 'admin')) ";
    $result = mysql_query($query);
    // $admin_id = mysql_insert_id(); 
    if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
    else $msg =  _("MySQL : update of ADMIN USER sucessful : ") . $admin_id;
    echo_flush($status, $msg,''); 

    $step="end";
  }

}


// ------------------- CREATE a USER  ---------------------------------
if (($step=='createuser')) {
  //launch the  form 
  display_userCreateForm(); 
}




if (($step=='createcatdef')) {
  if (!$chain) $admin_id = 0; 
  echo str_pad('<h1 class="start">'._('Creating default Category in DB...').'</h1>',4096)."\n";   
  $stamp= date( 'Y-m-d H:i:s', time());  
  $status="ok";
  $query = "
  INSERT INTO `".$dbCatsTable."` ( `moddate`, `title`, `description`, `catid`, `type`, `priority`, `price`, `imgname`, `dirurl`, `location`, `userid`, `username`, `phone`, `email`, `status`, `logs`, `hits`) VALUES
  ( '".$stamp."', 'default', 'default', 0 , '', '', 0, '', NULL, '', $admin_id, '', '', '', '40', '', 0);
  ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg =  _("MySQL : creation of DEFAULT CATEGORY sucessful ! \n\r");
  echo_flush($status, $msg,''); 
  
  if ($chain) $step="end"; 
  else $step="end";
  
}




// ------------------- CREATE SAMPLE of VFIELDS ---------------------------------
if (($step=='createvfields_sample')) { 
  echo str_pad('<h1 class="start">'._('Importing VFIELDS Samples ...').'</h1>',4096)."\n";  
  $stamp= date( 'Y-m-d H:i:s', time());  
  $status="ok";

  $dbtable = $dbVFieldsTable;
  $sql_file = "./sql_samples/vfields_sample.sql";
  $ret = import_content_in_dbtable_from_sql_dump($databasehost,$databaseusername,$databasepassword,$databasename,$dbtable, $sql_file,  false ) ; 

  $msg =  _("MySQL : creation of DEFAULT VFIELDS sucessful from SQL file : $sql_file !").'\n\r';
  if ($ret) echo_flush($status, $msg,''); 
  $step="end"; 
}

// ------------------- CREATE SAMPLE of CATEGORIES  ---------------------------------
if (($step=='createcats_sample')) { 
  echo str_pad('<h1 class="start">'._('Importing CATEGORIES Samples ...').'</h1>',4096)."\n";  
  $stamp= date( 'Y-m-d H:i:s', time());  
  $status="ok";

  $dbtable = $dbCatsTable;
  $sql_file = "./sql_samples/cats_sample.sql";
  $ret = import_content_in_dbtable_from_sql_dump($databasehost,$databaseusername,$databasepassword,$databasename,$dbtable, $sql_file,  false ) ; 

  $msg =  _("MySQL : creation of DEFAULT CATEGORIES sucessful from SQL file : $sql_file !").'\n\r';
  if ($ret) echo_flush($status, $msg,''); 
  $step="end"; 
}


// ------------------- CREATE SAMPLE of LISTS  ---------------------------------
if (($step=='createlists_sample')) { 
  echo str_pad('<h1 class="start">'._('Importing LISTS Samples ...').'</h1>',4096)."\n";  
  $stamp= date( 'Y-m-d H:i:s', time());  
  $status="ok";

  $dbtable = $dbListsTable;
  $sql_file = "./sql_samples/lists_sample.sql";
  $ret = import_content_in_dbtable_from_sql_dump($databasehost,$databaseusername,$databasepassword,$databasename,$dbtable, $sql_file,  false ) ; 

  $msg =  _("MySQL : creation of DEFAULT LISTS sucessful from SQL file : $sql_file !").'\n\r';
  if ($ret) echo_flush($status, $msg,''); 
  $step="end"; 
}




// ------------------- execute a SQL auery from file general.sql  ---------------------------------
if (($step=='execquery')) { 
  echo str_pad('<h1 class="start">'._('Executing SQL query in file GENERAL.SQL ...').'</h1>',4096)."\n";  
  $stamp= date( 'Y-m-d H:i:s', time());  
  $status="ok";

  $dbtable = $dbCatsTable;
  $sql_file = "./sql_samples/general.sql";
  $ret = direct_import_content_in_dbtable_from_sql_dump($databasehost,$databaseusername,$databasepassword,$databasename,$dbtable, $sql_file,  false ) ; 
 
  $msg =  _("MySQL : creation of CATEGORIES sucessful from SQL file : $sql_file !").'\n\r';
  if ($ret) echo_flush($status, $msg,''); 
  $step="end"; 
}




// ------------------- CREATE SAMPLE of CATAEGORIES ---------------------------------
if (($step=='createcats')) { 
  echo str_pad('<h1 class="start">'._('Creating Template Categories ...').'</h1>',4096)."\n";  
  $stamp= date( 'Y-m-d H:i:s', time());  
  $status="ok";
  if (!$chain) $admin_id = "";
  $query = "
  INSERT INTO `".$dbCatsTable."` (`id`, `moddate`, `title`, `description`, `catid`, `type`, `priority`, `price`, `imgname`, `dirurl`, `location`, `userid`, `username`, `phone`, `email`, `status`, `logs`, `hits`) VALUES
  ('', '".$stamp."', 'Co-voiturage', 'co-voiturage', 0, '', '', 0, 'file_20101209-214929.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'PuÃ©riculture', 'Tout pour bÃ©bÃ©.', 0, '', '', 0, 'file_20101209-213701.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Automobile', 'Tout sur l''automobile et piÃ©ces dÃ©tachÃ©es', 0, '', '', 0, 'file_20101209-215826.JPG', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Deux roues', 'Deux roues', 0, '', '', 0, 'file_20101209-213635.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Garde d''enfants', 'Garde d''enfants', 0, '', '', 0, 'file_20101209-214910.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Immobilier', 'Immobilier', 0, '', '', 0, 'file_20101209-220051.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'VillÃ©giature / tourisme', 'VillÃ©giature / tourisme', 0, '', '', 0, 'file_20101209-220155.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Informatique', 'Informatique', 0, '', '', 0, 'file_20101209-214845.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'TV / Hi-Fi / Photo', 'TV / Hi-Fi / Photo', 0, '', '', 0, 'file_20101209-213512.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'ElectromÃ©nager', 'ElectromÃ©nager', 0, '', '', 0, 'file_20101209-213604.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Sports', 'Sports', 0, '', '', 0, 'file_20101209-214722.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Animaux', 'Animaux', 0, '', '', 0, 'file_20101209-213531.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Emploi / Cours', 'Emploi / Cours', 0, '', '', 0, 'file_20101209-213153.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Mode / BeautÃ©', 'Mode / BeautÃ©', 0, '', '', 0, 'file_20101209-213031.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Loisirs', 'Loisirs', 0, '', '', 0, 'file_20101209-220026.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Rencontres2', 'Rencontres', 0, '', '', 0, 'file_20101209-214552.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Meubles/Mobi', 'Meubles/Mobilier', 0, '', '', 0, 'file_20101209-212903.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Jeux / Jouets', 'Jeux / Jouets', 0, '', '', 0, 'file_20101209-214656.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Divers', 'divers', '', '', '', 0, '', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Spectacles', 'Spectacles', 0, '', '', 0, 'file_20101209-212805.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0);
  "; 
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg =  _("MySQL : creation of DEFAULT CATEGORIES sucessful !").'\n\r';
  echo_flush($status, $msg,''); 
  
  $step="end"; 
}


// ------------------- CREATE the 999 categorie ---------------------------------
if (($step=='createcat9999')) { 
  echo str_pad('<h1 class="start">'._('Creating 9999 Category...').'</h1>',4096)."\n";  
  $stamp= date( 'Y-m-d H:i:s', time());  
  $status="ok";

  $status="ok";
  $query = " INSERT INTO `$dbCatsTable`  (`id`, `moddate`, `title`, `description`, `status`) 
                  VALUES ('9999', '$stamp', 'ZETEVU**DONOTDELETE', 'ZETEVU**DONOTDELETE', '40')"; 

  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : Creation of default ZETEVU categorie : ").$dbCatsTable;
  echo_flush($status, $msg,''); 

  
  $step="end"; 
}


// ------------------- CREATE RANDOM ADDS ---------------------------------
if (($step=='createads_rnd')) { 
  echo str_pad('<h1 class="start">'._('Creating Random Ads ...').'</h1>',4096)."\n";  
  $stamp= date( 'Y-m-d H:i:s', time());  
  
  $status="ok";
  $admin_id = "45";
  $cat_id = "0";
  
  $random_text = array("Lorem ipsum", " dolor sit amet", " consectetuer ullamcorper", "tempus tristique lorem vel","Aenean eu Nulla");
  $random_type = array("sell", "buy"); 
  //$random_status = array("20", " 30", "40", "45", "80", "90"); 
  $random_status = array( "40", "45");
  
  $maxidx= 10; // tot number of add to ad
  for ($i = 1; $i <= $maxidx; $i++) {
  

    $rnd_cat = rand(64,72);
    $rnd_price = rand(0,10000);
    
    $rnd_stamp = date( 'Y-m-d H:i:s',(rand(time()-4*30*24*3600, time()))); // between now and 4 months later


    $rnd_title = array_random($random_text, 3); 
    $rnd_title = array_random($random_text, 3);
    
    $rnd_desc = array_random($random_text, 5); 
    $rnd_type = array_random($random_type, 1);
    $rnd_status = array_random($random_status, 1);

    $query = "
    INSERT INTO `".$dbItemsTable."` (`id`, `moddate`, `title`, `description`, `catid`, `type`, `priority`, `price`, `imgname`, `dirurl`, `location`, `userid`, `username`, `phone`, `email`, `status`, `logs`, `hits`) VALUES
    ('', '".$rnd_stamp."', '".$rnd_title."', '".$rnd_desc."', '".$rnd_cat."', '".$rnd_type."', '', '".$rnd_price."', '', NULL, 'random', $admin_id, '', '', '', '".$rnd_status."', '', '0');
    "; 
 
    $result = mysql_query($query);
     
    if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
    else $msg =  _("MySQL : creation of random item  sucessful !").'\n\r';
    echo_flush($status, $msg,''); 
   }
   
  $step="end"; 
}




// -------------------PATCH DATES  ---------------------------------
if (($step=='patchddates')) { 
  echo str_pad('<h1 class="start">'._('Patching the dates  ...').'</h1>',4096)."\n";  
  $stamp= date( 'Y-m-d H:i:s', time());  

  $limit=""; 
  $filter=" WHERE `createdate` is null "; 
  $group =""; 
  $query = "SELECT  id, moddate FROM `$dbItemsTable`" .$filter." ". $group." ". $limit ; 
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; echo_flush('ko', $msg,''); }
  else {

    $nbrows = mysql_num_rows($result); 
  
    $msg= "Found $nbrows ads without a creation date <br>\n";
    echo_flush('ok', $msg,''); 
    $cnt=0; 
    while ($row = mysql_fetch_array($result)) {
      $cnt+=1; 
      // update the dates by copying MODDATE to createdate & first published dates 
      $idtmpx = $row['id']; 
      $newdate =  $row['moddate']; 
      $limit2="";
      $filter2="WHERE (`id` = '".$row['id']."') ";     
      $query2 = "UPDATE `".$dbItemsTable."` SET   
           `createdate`= '".$newdate."', 
           `firstpublisheddate`= '".$newdate."',
           `crondate`= '".$newdate."'
           ".$filter2. " ". $limit2;
      $result2 = mysql_query($query2);
      if ($result2){
        $nbrows2 = mysql_affected_rows();
        if ($nbrows2 > 0) {
          $msg= "$cnt - AD ".$row['id']." updated with date= $newdate <br>\n";
          echo_flush('ok', $msg,''); 
        }
      } else  {  $msg = "Invalid SQL request : $query2  /  " . mysql_error(); echo_flush('ko', $msg,'');}
    } // end while 
  } // end -if 

  $step="end"; // forward to menu end 
}


// -------------------PATCH PROTYPE  ---------------------------------
if (($step=='patchprotype')) { 
  echo str_pad('<h1 class="start">'._('Patching the PROTYPE->INDIR  ...').'</h1>',4096)."\n";  
  $stamp= date( 'Y-m-d H:i:s', time());  

  $limit=""; 
  $filter=" WHERE `protype` IN ('pub','pro') AND `indir` = '' "; 
  $group =""; 
  $query = "SELECT  id, moddate FROM `$dbUsersTable`" .$filter." ". $group." ". $limit ; 
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; echo_flush('ko', $msg,''); }
  else {

    $nbrows = mysql_num_rows($result); 
  
    $msg= "Found $nbrows users to patch <br>\n";
    echo_flush('ok', $msg,''); 
    $cnt=0; 
    while ($row = mysql_fetch_array($result)) {
      $cnt+=1; 
      // update the dates by copying MODDATE to createdate & first published dates 
      $limit2="";
      $filter2="WHERE (`id` = '".$row['id']."') ";     
      $query2 = "UPDATE `".$dbUsersTable."` SET   
           `indir`= 'yes'
           ".$filter2. " ". $limit2;
      $result2 = mysql_query($query2);
      if ($result2){
        $nbrows2 = mysql_affected_rows();
        if ($nbrows2 > 0) {
          $msg= "$cnt - AD ".$row['id']." updated with indir= yes <br>\n";
          echo_flush('ok', $msg,''); 
        }
      } else  {  $msg = "Invalid SQL request : $query2  /  " . mysql_error(); echo_flush('ko', $msg,'');}
    } // end while 
  } // end -if 

  $step="end"; // forward to menu end 
}

// ------------------- DROP ALL TABLES ---------------------------------
if (($step=='droptables')) { 
  echo str_pad('<h1 class="start">'._('Droping all table ...').'</h1>',4096)."\n";  
  $stamp= date( 'Y-m-d H:i:s', time());  

  $dbtablelist = array($dbItemsTable, $dbCatsTable, $dbUsersTable, $dbStatsTable, $dbLogsTable,$dbPaymentsTable,$dbBannersTable, $dbComsTable, $dbKeysTable); 
  
  foreach ($dbtablelist as $thistable) {
    $status="ok";
    $query = "DROP TABLE  `".$thistable."`"; 
    $result = mysql_query($query);
    if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
    else $msg =  _("MySQL : Table $thistable dropped sucessfuly ").'\n\r';
    echo_flush($status, $msg,''); 
  }
  $step="end"; 
}



// ------------------- changing to UTF8 and COLLATION existing DBs ---------------------------------
if (($step=='alterlatam')) {  
  // $query = "SET collation_connection = 'utf8_general_ci'"; 

  // database 
  $query = "ALTER DATABASE `".$databasename."` CHARACTER SET latin1 COLLATE latin1_swedish_ci"; 
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : INDEX creation of table sucessfull : ").$dbItemsTable;
  echo_flush($status, $msg,''); 

  // tables     
  $dbtablelist = array($dbItemsTable, $dbCatsTable, $dbUsersTable, $dbStatsTable, $dbLogsTable,$dbPaymentsTable,$dbBannersTable, $dbComsTable, $dbKeysTable); 
  foreach ($dbtablelist as $thistable) {
    $status="ok";
    $query = "ALTER TABLE `".$thistable."` CONVERT TO CHARACTER SET latin1 COLLATE latin1_swedish_ci"; 
    $result = mysql_query($query);
    if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
    else $msg =  _("MySQL : Table $thistable converted to latin1  sucessfuly ").'\n\r';
    echo_flush($status, $msg,''); 
  }
  $step="end"; 


  // $query = "ALTER TABLE your_table_name CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci"; 

}


// ------------------- EMPTY ALL TABLES ---------------------------------
if (($step=='emptytables')) { 
  echo str_pad('<h1 class="start">'._('Emptying all tables ...').'</h1>',4096)."\n";  
  $stamp= date( 'Y-m-d H:i:s', time());  

  $dbtablelist = array($dbItemsTable, $dbCatsTable, $dbUsersTable, $dbStatsTable, $dbLogsTable,$dbServicesTable,$dbSubscribersTable,$dbVFieldsTable); 
  
  foreach ($dbtablelist as $thistable) {
    $status="ok";
    $query = "TRUNCATE TABLE  `".$thistable."`"; 
    $result = mysql_query($query);
    if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
    else $msg =  _("MySQL : Table $thistable emptied sucessfuly ").'\n\r';
    echo_flush($status, $msg,''); 
  }
  $step="end"; 
}


// ------------------- EXTEND BANNERS TO 1500 CHARD ---------------------------------
if (($step=='extendbanner1500')) { 
  $status="ok";
  $query = "
          ALTER TABLE `$dbBannersTable` CHANGE `htmlcode` `htmlcode` VARCHAR(1500)
        ";
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg= _("MySQL : htmlcode field extended to 1500 chars").$dbBannersTable;
  echo_flush($status, $msg,''); 
  $step="end";
}  




// ------------------- EMPTY CATS---------------------------------
if (($step=='emptytablecats')) { 
  echo str_pad('<h1 class="start">'._('Emptying cats table ...').'</h1>',4096)."\n";  
  $stamp= date( 'Y-m-d H:i:s', time());  

    $status="ok";
    $thistable = $dbCatsTable; 
    $query = "TRUNCATE TABLE  `".$thistable."`"; 
    $result = mysql_query($query);
    if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
    else $msg =  _("MySQL : Table $thistable emptied sucessfuly ").'\n\r';
    echo_flush($status, $msg,''); 

  $step="end"; 
}
// ------------------- EMPTY VFIELDS  ---------------------------------
if (($step=='emptytablevfields')) { 
  echo str_pad('<h1 class="start">'._('Emptying vfields tables ...').'</h1>',4096)."\n";  
  $stamp= date( 'Y-m-d H:i:s', time());  

    $status="ok";
    $thistable = $dbVFieldsTable; 
    $query = "TRUNCATE TABLE  `".$thistable."`"; 
    $result = mysql_query($query);
    if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
    else $msg =  _("MySQL : Table $thistable emptied sucessfuly ").'\n\r';
    echo_flush($status, $msg,''); 

  $step="end"; 
}



// ------------------- EMPTY VFIELDS  ---------------------------------
if (($step=='emptytablelists')) { 
  echo str_pad('<h1 class="start">'._('Emptying lists table ...').'</h1>',4096)."\n";  
  $stamp= date( 'Y-m-d H:i:s', time());  

    $status="ok";
    $thistable = $dbListsTable; 
    $query = "TRUNCATE TABLE  `".$thistable."`"; 
    $result = mysql_query($query);
    if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
    else $msg =  _("MySQL : Table $thistable emptied sucessfuly ").'\n\r';
    echo_flush($status, $msg,''); 

  $step="end"; 
}


// ------------------- EXPORT A TABLE  ---------------------------------
if (($step=='exporttable')) { 
  echo str_pad('<h1 class="start">'._('Emptying all tables ...').'</h1>',4096)."\n";  
  $stamp= date( 'Y-m-d H:i:s', time());  

  $file = 'backup/vfields.sql';
  $result = mysql_query("SELECT * INTO OUTFILE '$file' FROM $dbVFieldsTable");

  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(); }
  else $msg =  _("MySQL : Table $dbVFieldsTable exported  sucessfuly ").'\n\r';
  echo_flush($status, $msg,''); 


  $step="end"; 
}



// ------------------- POST_INSTALL   ---------------------------------
if (($step=='postinstall')) { 
  $status="ok";
  echo str_pad('<h1 class="start">'._('Cleaning install for post-install ready  ...').'</h1>',4096)."\n";  

  //rename upload_tmp in
  $target_path = "../"; 
  $dest_path= $target_path; 
  $target_filename =  "uploads_model";
  $dest_filename =  "uploads";  

  $successx = rrmdir($target_path."".$dest_filename);  // delete the UPLOADS directory if exists 

  // copy the directory 
  $result =  recurse_copy($target_path."".$target_filename, $dest_path."".$dest_filename);

  // rename 
  // $result = rename($target_path."".$target_filename, $dest_path."".$dest_filename);


  if (!$result)  { $status="ko"; $msg= _("Cannot rename  $target_filename directory "); }
  else $msg =  _("FILES : $target_filename directory renamed sucessfuly ").'\n\r';
  echo_flush($status, $msg,''); 

  // delete all setting_custom files
  $directory = './'; // this directory 
  $files = array();

  foreach (scandir($directory) as $file) {
    $status="ok";
    // echo  $file.'<br>'; 
      if ('.' === $file) continue;
      if ('..' === $file) continue;
      if (! is_dir($file))  continue; 
      // this is adirectory check that it's matching settings_xxxxx
      if (strpos($file,'settings_') !== false){
        $delres = rrmdir($directory."".$file);  // delete
        if (!$delres)  { $status="ko"; $msg= _("Cannot delete :  $file "); }
        else $msg =  _("FILES : directory : $file deleted ").'\n\r';
        echo_flush($status, $msg,''); 
      }
  }

  // delete the DB settings de

    $directory = 'settings/'; // this directory 
    $file = "db_settings.php"; 
    
    if (file_exists($directory."".$file)) {
      $result = unlink($directory."".$file);  // delete the UPLOADS directory if exists 
      if (!$result)  { $status="ko"; $msg= _("Cannot delete :  $file ").mysql_error(); }
      else $msg =  _("FILES : $file deleted ").'\n\r';
    }
    echo_flush($status, $msg,''); 

  // next step is to clean up the debug file 
  $step="cleandebugfile"; 
}

// ------------------- CLEAN DEBUG FILE  ---------------------------------
if (($step=='deletedbfile')) {  
   $status="ok";
    $directory = 'settings/'; // this directory 
    $file = "db_settings.php"; 
    $result = unlink($directory."".$file);  // delete the UPLOADS directory if exists 
    if (!$result)  { $status="ko"; $msg= _("Cannot delete :  $file ").mysql_error(); }
    else $msg =  _("FILES : $file deleted ").'\n\r';
    echo_flush($status, $msg,''); 
    $step="end"; 
}



// ------------------- CLEAN DEBUG FILE  ---------------------------------
if (($step=='cleandebugfile')) { 
  
  echo str_pad('<h1 class="start">'._('Cleaning the debug file ...').'</h1>',4096)."\n";  
  $debugfile = fopen($debugoutputfile,"w"); if(!$debugfile) { echo "Error writing to the output file.\n";}
  else fwrite($debugfile,'file cleaned upon request<br>');
  fclose($debugfile);

  $step="end"; 
}


// ------------------- EMPTY ALL TABLES ---------------------------------
if (($step=='updategeocoderads')) { 

  class geocoder{
      static private $url = "http://maps.google.com/maps/api/geocode/json?sensor=false&address=";

      static public function getLocation($address){
          $url = self::$url.urlencode($address);
          
          $resp_json = self::curl_file_get_contents($url);
          $resp = json_decode($resp_json, true);

          if($resp['status']='OK'){
              //return $resp['results'][0]['geometry']['location'];
              return $resp;
          }else{
              return false;
          }
      }


      static private function curl_file_get_contents($URL){
          $c = curl_init();
          curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
          curl_setopt($c, CURLOPT_URL, $URL);
          $contents = curl_exec($c);
          curl_close($c);

          if ($contents) return $contents;
              else return FALSE;
      }
  }


  $status="ok";

  $query = "SELECT * FROM `$dbItemsTable` WHERE `lochash` = '' LIMIT 0, 2  ";  
  //echo $query;       
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; echo $msg; }
  else {
     //$msg= _("MySQL : ALTER/CREATION of table sucessful : ").$dbUsersTable;
    while ($row = mysql_fetch_object($result)) { 

      $xid= $row->id; 


      if ($row->location){
        $address=urlencode($row->location);
       
        echo '<br>';
        echo "--$xid--"; echo "--$row->location--"; echo "-- existinghash=$row->lochash --- "; 

        $loc = geocoder::getLocation($address);
        var_dump($loc);

        break; 


        //print_r($loc);
        $loclatlng = $loc['results'][0]['geometry']['location'];
        $xloclng=$loclatlng['lng'];
        $xloclat=$loclatlng['lat'];
        $xloclatlng =  $xloclat.'|'.$xloclng;

        // reinitialize variable 
        $xlocdept=''; $xlocdept_code=''; $xlocregion=''; $xlocregion_code='';
        $xloczipcode='';$xloccity='';$xloczipcode='';$xloccountrycode='';$xloccountry='';
        $xstreet='';$xroute='';

        $locdetails = $loc['results'][0]['address_components'];
        
        //var_dump($loc['results'][0]['address_components']);
        foreach ($locdetails as $key => $locelem){
           //var_dump($locelem);
           $loctype= $locelem['types'][0];
           $locval = $locelem['long_name'];
           $locval_short = $locelem['short_name'];

           if ($loctype =="administrative_area_level_2") { $xlocdept=$locval;$xlocdept_code= $locval_short;}
           if ($loctype =="administrative_area_level_1") { $xlocregion=$locval;$xlocregion_code= $locval_short;}
           if ($loctype =="locality") { $xloczipcode=$locval_short; $xloccity = $locval;}
           if ($loctype =="postal_code") $xloczipcode=$locval;
           if ($loctype =="country") { $xloccountrycode=$locval_short;$xloccountry = $locval;}
           if ($loctype =="street_number") { $xstreet=$locval_short;}
           if ($loctype =="route") { $xroute=$locval_short;}

        } // end FOR

        $xlochashregion="&dept=$xlocdept&deptcode=$xlocdept_code&region=$xlocregion&regioncode=$xlocregion_code&country=$xloccountry&countrycode=$xloccountrycode";
        $xlochash = "&street\_number=$xstreet&route=$xroute&locality=$xloccity$xlochashregion";     
 
        if ($xlochash){
          //UPDATE `zads5_items` SET `lochash`='' WHERE 1
          $query2 = "UPDATE `".$dbItemsTable."` SET   
              `lochash` = '".$xlochash."', 
              `lochashregion` = '".$xlochashregion."', 
              `loczipcode` = '".$xloczipcode."', 
              `loccity` = '".$xloccity."', 
              `locregion` = '".$xlocregion."', 
              `locdept` = '".$xlocdept."', 
              `loccountrycode` = '".$xloccountrycode."', 
              `loclng` = '".$xloclng."',
              `loclat` = '".$xloclat."', 
              `loclatlng` = '".$xloclatlng."' 
              
              WHERE ((`id` = '".$xid."')) ";
          $result2 = mysql_query($query2);
           
          if (!$result2)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query2; }
          else $msg =  _("MySQL : update of location for $xid done !").'\n\r';
          echo_flush($status, $msg,''); 

        }
      } // test if address exist
      else { $status="ko"; $msg= _("No address for ID = $xid"); echo_flush($status, $msg,''); }
    } // end while
  } // end loop 

  $step="end"; 
}





if (($step=='end')) {  
  // ------------------- End of INSTALL Process --------------------------------- 
  ob_end_flush();
  echo str_pad('<h1 class="end">'._('... end of processing.').'</h1>',4096)."\n"; 
  echo '<a href="?">'._('Go back to main menu').'</a><br>';
}


/*------------------------------------------------------------------------------*/
?>
 

<div>
  <!-- end content -->
  
  </div>
   <!-- end site -->


    </div>
  </body>
</html>
<?php


/*------------------------------------------------------------------------------
* this function copy a directory 
-----------------------------------------------------------------------------*/
function recurse_copy($src,$dst) { 
    $dir = opendir($src); 
    @mkdir($dst); 
    while(false !== ( $file = readdir($dir)) ) { 
        if (( $file != '.' ) && ( $file != '..' )) { 
            if ( is_dir($src . '/' . $file) ) { 
                recurse_copy($src . '/' . $file,$dst . '/' . $file); 
            } 
            else { 
                copy($src . '/' . $file,$dst . '/' . $file); 
            } 
        } 
    } 
    closedir($dir); 
    return true; 
} 



/*------------------------------------------------------------------------------
* this function import tablesfrom an SQL file  
-----------------------------------------------------------------------------*/
function import_content_in_dbtable_from_sql_dump($host,$user,$pass,$dbname,$dbtable, $sql_file,  $clear_or_not=false )
{
    if (!file_exists($sql_file)) {die('Input the SQL filename correctly! <button onclick="window.history.back();">Click Back</button>');}

    // Connect to MySQL server
        //$link = mysqli_connect($host,$user,$pass,$name);
        //mysqli_select_db($link,$mysqli);
    $mysqli = new mysqli($host, $user, $pass, $dbname);
    // Check connection
    if (mysqli_connect_errno())   {   echo "Failed to connect to MySQL: " . mysqli_connect_error();   }

    // if($clear_or_not) 
    // {
    //     $zzzzzz = $mysqli->query('SET foreign_key_checks = 0');
    //     if ($result = $mysqli->query("SHOW TABLES"))
    //     {
    //         while($row = $result->fetch_array(MYSQLI_NUM))
    //         {
    //             $mysqli->query('DROP TABLE IF EXISTS '.$row[0]);
    //         }
    //     }
    //     $zzzzzz = $mysqli->query('SET foreign_key_checks = 1');
    // }

    // clear the content
    if($clear_or_not) 
    {
      // $zzzzzz = $mysqli->query('SET foreign_key_checks = 0');
      $mysqli->query('TRUNCATE '.$dbtable);
      // $zzzzzz = $mysqli->query('SET foreign_key_checks = 1');
    }

    $mysqli->query("SET NAMES 'utf8'");
    // Temporary variable, used to store current query
    $templine = '';
    // Read in entire file
    $lines = file($sql_file);
    // Loop through each line
    // echo "db table is = $dbtable <br>"; // debug 

    foreach ($lines as $line)
    {
        // Skip it if it's a comment
        if (substr($line, 0, 2) == '--' || $line == '')
            continue;

        // detect the  INSERT INTO `test45vfields` to replace it with the right table name `test45vfields` 
        if (strpos($line,'INSERT INTO') !== false){
          // $line = preg_replace('/^(INSERT INTO)\\s+.*?\\s+(` )$/s', '$1 `$dbtable` $2', $line);
          $line = preg_replace('/^(INSERT INTO).*?(\(.*?)$/s', '$1 `'.$dbtable.'` $2', $line);
          // echo "*** line changed  ! *** <br>"; // debug 
        } 
          
        // Add this line to the current segment
        $templine .= $line;
        // If it has a semicolon at the end, it's the end of the query
        if (substr(trim($line), -1, 1) == ';')
        {
            // Perform the query
            $mysqli->query($templine) or print('Error performing query \'<strong>' . $templine . '\': ' . $mysqli->error . '<br /><br />');
            // echo $templine;
            // Reset temp variable to empty
            $templine = '';
        }
    }
    return true; 
}


/*------------------------------------------------------------------------------
* this function import tablesfrom an SQL file  
-----------------------------------------------------------------------------*/
function direct_import_content_in_dbtable_from_sql_dump($host,$user,$pass,$dbname,$dbtable, $sql_file,  $clear_or_not=false )
{
    if (!file_exists($sql_file)) {die('This file '.$sql_file.' does not exist ! <button onclick="window.history.back();">Click Back</button><br>');}

    $mysqli = new mysqli($host, $user, $pass, $dbname);
    // Check connection
    if (mysqli_connect_errno())   {   echo "Failed to connect to MySQL: " . mysqli_connect_error();   }
    // clear the content
    if($clear_or_not) 
    {
      // $zzzzzz = $mysqli->query('SET foreign_key_checks = 0');
      $mysqli->query('TRUNCATE '.$dbtable);
      // $zzzzzz = $mysqli->query('SET foreign_key_checks = 1');
    }

    $mysqli->query("SET NAMES 'utf8'");
    // Temporary variable, used to store current query
    $templine = '';
    // Read in entire file
    $lines = file($sql_file);
    // Loop through each line
    // echo "db table is = $dbtable <br>"; // debug 
    // echo "detected lines = $lines for file : $sql_file <br>"; // debug 

    foreach ($lines as $line)
    {
        // Skip it if it's a comment
        if (substr($line, 0, 2) == '--' || $line == '')
            continue;
  
        // Add this line to the current segment
        $templine .= $line;
        // If it has a semicolon at the end, it's the end of the query

        // echo 'before  line :'.$templine;

        if (substr(trim($line), -1, 1) == ';')
        {
          // echo 'executing line :'.$templine;
          // echo '<br>';

            // Perform the query
            $mysqli->query($templine) or print('Error performing query \'<strong>' . $templine . '\': ' . $mysqli->error . '<br /><br />');
            // echo $templine;
            // Reset temp variable to empty
            $templine = '';
        }
    }
    return true; 
}



/*------------------------------------------------------------------------------
* create a random array of string and ouput the result in a consolidated string
-----------------------------------------------------------------------------*/

function array_random($ar, $nb){
  $tmpstr="";
  
  if (!$nb) $nb=1; 
  for ($j=0;$j<$nb;$j++) {
    $i = rand(0, count($ar)-1);
    $tmpstr.=$ar[$i]; 
  }
  return  $tmpstr;
  
};



function display_user_form($context){
  if ($context=="changeAdminPassword"){


      ?>
        <div style="padding:3px; padding-top:1px; padding-bottom:5px;">

      <!--
      <?php  echo _('All fields are required.'); ?>
      -->

      <form action=install.php method="get" name=setup>
      <table width="100%" cellspacing="0" cellpadding="2" class="setup">
          <tr class="title"><td colspan=2><h1><?php  echo _('ZADS USER CREATION'); ?> </h1></td></tr>
          <input type=hidden name="step" value="changeAdminPassword" >

          <tr class="title"><td colspan=2>ADMIN USER</td></tr>
          <tr>
              <td colspan=2><span class="error"><b></b></span>
               <table cellspacing=1 cellpadding=2 border=0>
                  <tr><td>New password :</td><td><input type="text" name="newpassword" size="20" value="" >
                          <font class="error"></font></td></tr>
               </table>
              </td>
          </tr>
      </table>
      <div align="">
          <input class="button" type=submit value="<?php  echo _('Apply'); ?>">
      </div>
      </form>
      </div>

      <?php 
  }
}



function display_dbsetupform(){

?>
  <div style="padding:3px; padding-top:1px; padding-bottom:5px;">

<?php  echo _('All fields are required.'); ?>

<form action=install.php method=post name=setup>
<table width="100%" cellspacing="0" cellpadding="2" class="setup">
    <tr class="title"><td colspan=2><h1><?php  echo _('ZADS MYSQL DB SETTINGS'); ?> </h1></td></tr>
    <input type=hidden name=action size=20 value="updatemysqlsettings" >

    <tr class="title"><td colspan=2>Database</td></tr>
    <tr>
        <td colspan=2><span class="error"><b></b></span>
         <table cellspacing=1 cellpadding=2 border=0>
            <tr><td>MySQL Hostname:</td><td><input type=text name=dbhost size=20 value="" >
                    <font class="error"></font></td></tr>
            <tr><td>MySQL Database:</td><td><input type=text name=dbname size=20 value="">
                    <font class="error"></font></td></tr>
            <tr><td>MySQL Username:</td><td><input type=text name=dbuser size=20 value="">
                    <font class="error"></font></td></tr>
            <tr><td>MySQL Password:</td><td><input type=password name=dbpass size=20 value="">
                    <font class="error"></font></td></tr>
            <tr><td width=150>MySQL Table Prefix:</td><td><input type=text name=prefix size=20 value="" >
                    <font class="error"></font></td></tr>

            <tr><td></td><td></td></tr>
 
            <tr><td width=150>Site Name :</td><td><input type="text" name="site_name" size="40" value="" >
              <font class="error"></font></td></tr>

            <tr><td width=150>SITE_MOTTO:</td><td><input type="text" name="site_motto" size="100" value="" >
              <font class="error"></font></td></tr>
           
            <tr><td width=150>FQDN :</td><td><input type="text" name="fqdn" size="40" value="" >
              <font class="error"></font></td></tr>
            <tr><td width=150>DOMAINE :</td><td><input type="text" name="general_domain" size="40" value="" >
              <font class="error"></font></td></tr>
            <tr><td width=150>Admin_email :</td><td><input type="text" name="admin_email" size=40 value="" >
              <font class="error"></font></td></tr>

         </table>
        </td>
    </tr>
</table>
<div align="">
    <input class="button" type=submit value="<?php  echo _('Save these parameters'); ?>">
    <input class="button" type=reset name=reset value="<?php  echo _('Reset the form'); ?>">
</div>
</form>
</div>

<?php  

};


function display_dbfactoryresetForm(){

?>
  <div style="padding:3px; padding-top:1px; padding-bottom:5px;">

<?php  echo _('All fields are required.'); ?>

<form action=install.php method=post name=setup>
<table width="100%" cellspacing="0" cellpadding="2" class="setup">
    <tr class="title"><td colspan=2><h1><?php  echo _('ZADS DEMO RESET - INPUTS'); ?> </h1></td></tr>
    <input type=hidden name=action size=20 value="finalizedemoreset" >
    <tr>
        <td colspan=2><span class="error"><b></b></span>
         <table cellspacing=1 cellpadding=2 border=0>
 
            <tr><td width=150>Site Name :</td><td><input type="text" name="site_name" size="40" value="" >
              <font class="error"></font></td></tr>

            <tr><td width=150>SITE_MOTTO:</td><td><input type="text" name="site_motto" size="100" value="" >
              <font class="error"></font></td></tr>
           
            <tr><td width=150>FQDN :</td><td><input type="text" name="fqdn" size="40" value="" >
              <font class="error"></font></td></tr>
            <tr><td width=150>DOMAINE :</td><td><input type="text" name="general_domain" size="40" value="" >
              <font class="error"></font></td></tr>
            <tr><td width=150>Admin_email :</td><td><input type="text" name="admin_email" size=40 value="" >
              <font class="error"></font></td></tr>

         </table>
        </td>
    </tr>
</table>
<div align="">
    <input class="button" type=submit value="<?php  echo _('Save these parameters'); ?>">
    <input class="button" type=reset name=reset value="<?php  echo _('Reset the form'); ?>">
</div>
</form>
</div>

<?php  

};



function display_userCreateForm(){

?>
  <div style="padding:3px; padding-top:1px; padding-bottom:5px;">

<?php  echo _('All fields are required.'); ?>

<form action=install.php method=post name=setup>
<table width="100%" cellspacing="0" cellpadding="2" class="setup">
    <tr class="title"><td colspan=2><h1><?php  echo _('ZADS MYSQL DB SETTINGS'); ?> </h1></td></tr>
    <input type=hidden name=action size=20 value="createUser" >

    <tr class="title"><td colspan=2>User details</td></tr>
    <tr>
        <td colspan=2><span class="error"><b></b></span>
         <table cellspacing=1 cellpadding=2 border=0>
            <tr><td>First name</td><td><input type=text name=firstname size=20 value="" >
                    <font class="error"></font></td></tr>
            <tr><td>Last name</td><td><input type=text name=lastname size=20 value="">
                    <font class="error"></font></td></tr>
            <tr><td>email</td><td><input type=text name=email size=20 value="">
                    <font class="error"></font></td></tr>
            <tr><td>Password</td><td><input type=password name=password size=20 value="">
                    <font class="error"></font></td></tr>
         </table>
        </td>
    </tr>
</table>
<div align="">
    <input class="button" type=submit value="<?php  echo _('Create this user'); ?>">
    <input class="button" type=reset name=reset value="<?php  echo _('Reset the form'); ?>">
</div>
</form>
</div>

<?php  

};
 
/*------------------------------------------------------------------------------
* $sstatus : status {'ok', 'ko'}
* $mmsg : STRING message to be displayed 
* $what2do : STRING -{'Die' or ''} . If 'die', do a PHP EXIT
-----------------------------------------------------------------------------*/
function echo_flush($sstatus, $mmsg, $what2do){

  if ((!$what2do)|| ($what2do=='')) $what2do="echo"; 
   
    $stamp= date( 'Y-m-d H:i:s', time());
    // $tmpstr = '<div class="item"><div class="icon '.$sstatus.'"></div><div class="time">'.$stamp.'</div><div class="spacer">:</div><div class="status '.$sstatus.'">'.$sstatus.'</div><div class="spacer">:</div><div class="msg">'.$mmsg.'</div></div>'; 
    
    if ($sstatus=="ok") $xicon = "icon-fa-check-sign" ;
    else if ($sstatus=="ko") $xicon = "icon-fa-frown" ;
    else $xicon = "icon-fa-info" ;
    $tmpstr = '<div class="item"><div class=" '.$xicon.' mr6 icon-color-'.$sstatus.'"></div><div class="time">'.$stamp.'</div><div class="spacer">:</div><div class="status '.$sstatus.'">'.$sstatus.'</div><div class="spacer">:</div><div class="msg">'.$mmsg.'</div></div>'; 

    if (($what2do=="die") && ($sstatus=="ko")) {
      ob_end_flush(); 
      die ($tmpstr . str_pad(_('... end of processing.'),4096)."<br />\n"); 
    }
    else {
      echo $tmpstr;
      flush();
      ob_flush();
      // usleep(500000);
      // usleep(100000);
    } 
};

function warning_handler($errno, $errstr){
   $stamp= date( 'Y-m-d H:i:s', time());
   $tmpstr = '<div class="php_error php_warning "><div class="icon WARNING"></div><div class="time">'.$stamp.'</div><div class="spacer">:</div><div class="status WARNING">WARN</div><div class="spacer">:</div><div class="msg">'.$errstr.'</div>'; 

   $tmpstr .= '</div>';
   echo $tmpstr;
   flush();ob_flush();
   return true; 
}

function check_php_compatibility($ext){
  global $cstat; 
  if (!extension_loaded($ext)) {
    $st="ko";$cstat=false;
  }  else $st="ok";  
  echo_flush($st,_('compatibility with PHP_').$ext,'');
};


function check_apache_compatibility($ext){
   global $cstat;   
   foreach (apache_get_modules() as $module){
    if ($module==$ext) {
      echo_flush('ok',_('compatibility with APACHE_').$ext,'');
      return true;
      } 
   }
   echo_flush('ko',_('compatibility with APACHE_').$ext,'');
   $cstat=false;
   return false;
};



function test_email($context){
  global $EMAIL_FROMADMIN;
  global $EMAIL_ADMIN; 
  $_nl = "\r\n<br>"; 

  $serverx =  "- Addr =".$_SERVER["SERVER_ADDR"].$_nl; 
  $serverx .= "- Name =".$_SERVER['SERVER_NAME'].$_nl;
  $serverx .= "- Software=".$_SERVER['SERVER_SOFTWARE'].$_nl;
  $serverx .= "- Protocol=".$_SERVER['SERVER_PROTOCOL'].$_nl;
  $servernamex = $_SERVER['SERVER_NAME']; 
  
  $misc =  "- doc root=".$_SERVER["DOCUMENT_ROOT"].$_nl;
  $misc .=  "- user agent=".$_SERVER["HTTP_USER_AGENT"].$_nl;
  $misc .=  "- request uri=".$_SERVER["REQUEST_URI"].$_nl;
  
  $serverremotehostx =  "- addr=".$_SERVER['REMOTE_ADDR'].$_nl;
  $serverremotehostx .= "- port=". $_SERVER['REMOTE_PORT'].$_nl;    
  
  // consolidate all the line 
  $debug = "SERVEUR : $_nl $serverx $_nl $_nl REMOTE HOST:  $_nl $serverremotehostx $_nl $_nl OTHERS : $_nl $misc"; 
  
  // test to send a Mail 
  $recipient ="sales@zads.fr";
  $sujet =  "Test email from ZADS AUTOTEST";    
  $message= " Bienvenue à ZADS sur ce nouvel  hébergement :<br>\n "; 
  $message.= "$debug \n";


  // add HTML message 
  $htmlmessage = ""; 
  $htmlmessage .= "<img src=\"\"</a>";
  $htmlmessage .= "<h1>Title H1</h1> ";
  $htmlmessage .= "<h2>Title H2</h2> ";
  $htmlmessage .= "<h3>Title H3</h3> ";
  $htmlmessage .= "<a href=\"www.zads.fr\">Link to ZADS web site</a> ";
  $htmlmessage .="<p> description longue <p><div style=\"color:#000000; border:1px solid #000000; padding:10px; margin:0px auto;\">mise en forme avec du div</div><br><b>c'est en gras<b>"; 
  $message.=$htmlmessage;



  // encode all in LATIN-1 format 
  $message = utf8_decode($message); 

  $email="noreply@".$servernamex; 
  $emailname="ZADS - no reply";        
  // Pour envoyer un mail HTML, l'en-tête Content-type doit être défini
  $headers  = 'MIME-Version: 1.0' . "\r\n";
  $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; // for HTML documents
  
  // En-têtes additionnels
  /*
  $headers .= "To: Mary <mary@example.com>, Kelly <kelly@example.com>" . "\r\n";
  $headers .= "From: $emailname <$email>" . "\r\n";
  $headers .= "Cc: patrice.cohaut@alcatel-lucent.com" . "\r\n";
  $headers .= "Bcc: patrice.cohaut@alcatel-lucent.com, patrice.cohaut@gmail.com" . "\r\n";
  */
  
  // to define priority 
  $headers .= "X-Priority: 1 (Higuest)\n"; 
  $headers .= "X-MSMail-Priority: High\n"; 
  $headers .= "Importance: High\n"; 

  // match this if context is set 
  if ($context=="realparams"){
    $sujet =  "Test email from ZADS with REAL PARAMS";    
    $headers .= "From: $EMAIL_FROMADMIN <$email>" . "\r\n";
    $recipient =$EMAIL_ADMIN;
  }

  
  if (mail ("$recipient", "$sujet", "$message", "$headers"))
    echo_flush('ok',_('text MAIL function'),''); 
  else  
    echo_flush('ko',_('text MAIL function'),''); 
};


// # recursively remove a directory
// function rrmdir($dir) {
//     foreach(glob($dir . '/*') as $file) {
//         if(is_dir($file))
//             rrmdir($file);
//         else
//             unlink($file);
//     }
//     rmdir($dir);
// }

function rrmdir($dir) {
   $out=false; 
   if (is_dir($dir)) {
     $objects = scandir($dir);
     foreach ($objects as $object) {
       if ($object != "." && $object != "..") {
         if (filetype($dir."/".$object) == "dir") rrmdir($dir."/".$object); else unlink($dir."/".$object);
       }
     }
     reset($objects);
     rmdir($dir);
     $out=true; 
   }
   return $out; 
 }



?>
