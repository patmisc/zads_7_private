<?php
/******************************************************************************
 * ZADS Main Server Script
 * 
 * Note :  works with DB_SETTINGS.PHP &  SETTINGS.PHP file & LOCALIZATION.PHP
 * LINKED LIB: facebook.php ; paypal.php
 *  
 * @category   CorePackage
 * @package    ZADS
 * @author     Patrice COHAUT <patrice.cohaut@gmail.com>
 * @copyright  2012-2017 PATMISC
 * @version    7.4.0
 ******************************************************************************/

// header('Content-Type: application/json');
header('Content-Type: application/json;charset=utf-8');
define('SENTINEL', 1); // used for includes files

if (!defined("CACHE_PATH")) define('CACHE_PATH', 'cache/');

// just some comments 

$timing_trace=''; $t0=microtime(true);  

/* detect the PHP version */ 
if(function_exists('phpversion')) $v = phpversion();
elseif(PHP_VERSION) $v = PHP_VERSION; else $v =  'Impossible de détecter la version PHP';
$phpVersion = intval(str_replace('.','',$v));

// load libraries & settings 
require_once("multitenants_settings.php"); 
require_once($SETTINGS_PATH."db_settings.php");  
require_once($SETTINGS_PATH."settings.php");
require_once("localization.php");   
require_once($SETTINGS_PATH."home_settings_".$cust_lang_long.".php");

// get catalogue elements  
$general_settings = json_decode(file_get_contents($SETTINGS_PATH."general.json"),true);
$general_catalogue = json_decode(file_get_contents($SETTINGS_PATH."catalogue.json"),true);

// set default timezone 
date_default_timezone_set('Europe/Paris');

//add facebook SDK for autentification via Facebook
if ($FB_AUTH) require_once ("fb_sdk/src/facebook.php");

$debug ="";
$debug_tmp = 0 ; // 0= server 1=local
if (( $_SERVER['SERVER_ADDR'] != "127.0.0.1") ||( !$_SERVER['SERVER_ADDR'] ))  $debug_tmp=0; else $debug_tmp=1; 
$nomessage = 0;  // 0= flag to indicate wether to end a message or not

$serverremotehostx ='unknown';
$serverremoteaddr = $_SERVER['REMOTE_ADDR'];  
$debughostinfo = "remote host=".$serverremotehostx ." | remote ip= ". $serverremoteaddr;
$uagent = $_SERVER['HTTP_USER_AGENT'];
$useragent = $_SERVER['HTTP_USER_AGENT'];

// // UserAgent informations for statistics 
// $uagentArr = UserAgentParser($_SERVER['HTTP_USER_AGENT']);
// //$uagent = strtolower($uagent);
// $uagent_os = $uagentArr['platform']; 
// $uagent_version =$uagentArr['version'];
// $uagent_browser =$uagentArr['browser']; 

$databasehost = $DB_HOST;
$databaseusername =$DB_USERNAME;  
$databasepassword =$DB_PASSWORD;  

$databasename = $DB_NAME;  //cads = classified adds. 
$dbItemsTable = $DB_PREFIX.$DB_TABLE_ITEMS ; 
$dbCatsTable = $DB_PREFIX.$DB_TABLE_CATS; 
$dbUsersTable = $DB_PREFIX.$DB_TABLE_USERS; 
$dbStatsTable = $DB_PREFIX.$DB_TABLE_STATS; 
$dbLogsTable = $DB_PREFIX.$DB_TABLE_LOGS; 
$dbPaymentsTable = $DB_PREFIX.$DB_TABLE_PAYMENTS;
$dbBannersTable = $DB_PREFIX.$DB_TABLE_BANNERS;

$dbBookingsTable = $DB_PREFIX.$DB_TABLE_BOOKINGS;
$dbPricingsTable = $DB_PREFIX.$DB_TABLE_PRICINGS;
$dbVisitorsTable= $DB_PREFIX.$DB_TABLE_VISITORS; 



// @Z5.5
$dbSubscribersTable = $DB_PREFIX.$DB_TABLE_SUBSCRIBERS;
$dbVFieldsTable = $DB_PREFIX.$DB_TABLE_VFIELDS;
//@Z6.0
$dbServicesTable= $DB_PREFIX.$DB_TABLE_SERVICES;
// @6.7
$dbKeysTable = $DB_PREFIX.$DB_TABLE_KEYS;

//@Z6.8.3
$dbComsTable = $DB_PREFIX.$DB_TABLE_COMS;


$fullfqdn = $DOMAIN_FQDN; 

$dbThisTable=""; 
$debugoutputfile = "debugoutput.htm"; // only if save=1

//force a debug based on settings file Zads5.0
if ($ENABLE_DEBUG_MODE) $debug_tmp=1; 
$debug_level = ($DEBUG_LEVEL) ? $DEBUG_LEVEL : 7 ;


if ($debug_tmp==1) {
// debug output file 
  $debugfile = fopen($debugoutputfile,"a"); if(!$debugfile) { echo "Error writing to the output file.\n";}
  logfile('', '[core 1] --------------------------------------', __LINE__); // start a new call of file 
  
  // $post_dump = print_r($_POST, true);
  // logfile('debug', "[core 1] POST = : $post_dump"); 

  // Report all errors except E_NOTICE  and WARNINGS
  error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);
} 
else {
  // Report simple running errors
  error_reporting(E_ERROR |  E_PARSE);
}
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING | E_DEPRECATED));

// --- BAN IP Users ---- 
if ($serverremoteaddr){
  if (file_get_contents('vars/ban_IPs.txt')) {
    // get the list and check if within the list
    $ban_ip_list = file_get_contents('vars/ban_IPs.txt');
    if (strpos($ban_ip_list,$serverremoteaddr)!== false) {
      die ("IP address $serverremoteaddr is not authorized");  
    } // else OK ! 
  }
}

// today week number in "string format" 08W21 eg
$todayyw=date("y")."w".date("W") ; 
$todayweeknbr = intval(date("W")) ; 
$todaymonthnbr = intval(date("m")) ; 
$todayyearnbr=intval(date("y"));
$stamp= date( 'Y-m-d H:i:s', time());

// calculate first publication date
if (isset($ARCHIVE_DURATION)) $delteafter = $ARCHIVE_DURATION; 
else $delteafter=60; // default 

if (isset($NOTIFICATIONBEFORE_DURATION)) $notbefore = $NOTIFICATIONBEFORE_DURATION; 
else $notbefore=7; // default 

$origPub = time() - ($PUBLISHING_DURATION * 24 * 60 * 60);
$origDel = time() - ($delteafter * 24 * 60 * 60);

$stamppast7days = date( 'Y-m-d H:i:s',  time() - ($notbefore*24*60*60) );
$stamppast = date( 'Y-m-d H:i:s', $origDel);
$stampwillexpire = date( 'Y-m-d H:i:s', $origPub+($notbefore*24*60*60));


// zads 6.1.2  - special user archive time 
if (isset($USER_MAXARCHIVE_DURATION)) $user_delete_after = $USER_MAXARCHIVE_DURATION; 
else $user_delete_after=60; // default 
$stamppast_user_delete = date( 'Y-m-d H:i:s',time() - ($user_delete_after * 24 * 60 * 60));



$origDraft =  time() - ($DRAFT_PURGE_DURATION * 24 * 60 * 60);
$stamppastdraft =  date( 'Y-m-d H:i:s', $origDraft);

// -- stamps for Users
$origLastVisit = time() - ($USER_MAXINACTIVE_DURATION * 24 * 60 * 60);
$stampUserwillexpire = date( 'Y-m-d H:i:s', $origLastVisit+($notbefore*24*60*60));
$stampShouldExpire= date( 'Y-m-d H:i:s', (time()+$notbefore*24*60*60));

// -- stamp for logs
if ($LOGS_DURATION){
  $logmaxdate =  time() -  ($LOGS_DURATION * 24 * 60 * 60);
  $logmaxdate = date( 'Y-m-d H:i:s', $logmaxdate);
}

// -- stamp for payment logs 
if ($PAYMENT_LOGS_DURATION && ($PAYMENT_LOGS_DURATION>0)) {
  $paymentlogmaxdate =  time() -  ($PAYMENT_LOGS_DURATION * 24 * 60 * 60);
  $paymentlogmaxdate = date( 'Y-m-d H:i:s', $paymentlogmaxdate);
}

if ($ENABLE_VISITORS_LOGS  && $VISITORS_LOGS_DURATION && ($VISITORS_LOGS_DURATION>0) ) {
  $visitorslogmaxdate =  time() -  ($VISITORS_LOGS_DURATION * 24 * 60 * 60);
  $visitorslogmaxdate = date( 'Y-m-d H:i:s', $visitorslogmaxdate);
}

//  --- open socket to MySQL database
$con = mysql_connect ($databasehost,$databaseusername, $databasepassword); 
if (!$con) {
  logfile('error', "{main} : mysql_connect : ". mysql_error(), __LINE__); 
  die();
}
$dbcon = mysql_select_db ( $databasename ); 
if (!$dbcon) {
  logfile('error', "{main} : mysql_select_db : ". mysql_error(), __LINE__); 
  die();
}

mysql_query("SET NAMES 'utf8'") ;

$message = "";
$success=false; 
$what = ""; 

$curuser_is_superadmin=false; // global var to indicate it a user is logged and if he is admin 

//  ---- Site admin Settings  --------------------------

$rss_title=_("title of rss feed from zads"); 
$rss_desc=_("descritpion of rss feed from zads"); 
$rss_link= $fullfqdn."rss?rss="; 
$rss_site_url= $fullfqdn; 
$rss_img_fullurl= $fullfqdn."uploads/img/"; 

// logic table for ADMIN  people 
$status_logic_admin =  array (
      "00" => array("10","40"),
      "10" => array("10","20","40","80"),
      "15" => array("20","40","80"),
      "17" => array("20","40","80"),
      "20" => array("40","80","90"),
      "40" => array("40","45","60","80"),
      "45" => array("40","80"),
      "60" => array("40","60", "80"),
      "80" => array("10","20","40","80"),
      "90" => array("10","20","40","80")
);
// logic table for REGISTERED / GUEST poeple with NO AUTO APPROVAL of assds 

$status_logic_registered =  array (
      "00" => array("10","20"),
      "10" => array("10","20","80"),
      "15" => array("15","80"),
      "17" => array("80"),
      "20" => array("20","80"),
      "40" => array("40","60","80"),
      "45" => array("40","80"),
      "60" => array("40","60", "80"),
      "80" => array("10"),
      "90" => array("20","10","80")
);

if ($AD_AUTO_APPROVAL){
  // logic table for REGISTERED / GUEST poeple WITH AUTO-APPROVAL  
  $status_logic_registered  =  array (
        "00" => array("10","40"),
        "10" => array("40","80"),
        "15" => array("15", "80"),
        "20" => array("20","80"),
        "40" => array("40","60","80"),
        "45" => array("40","80"),
        "60" => array("40","60", "80"),
        "80" => array("10"),
        "90" => array("20","80")
    );
  }

  // Z6.1.2 ( accepte reactivation into only status DRAFT to reinitiate all dates)
  if ($AD_NOMODS_AFTEREXPIRATION){
    $status_logic_registered["80"] = array(); 
  }  

// account creattion without control
$status_logic_user_registered =  array (
      "00" => array("40"),
      "10" => array("40"),
      "40" => array("40")
);
// account creation with approval 
if (!$USER_AUTO_APPROVAL){
  $status_logic_user_registered =  array (
        "00" => array("40"),
        "10" => array("20"),
        "15" => array("20"),
        "20" => array("20"),
        "40" => array("40")
  );
}


/*
// account creation with approval 
$status_logic_user_registered =  array (
      "00" => array("20"),
      "10" => array("20","80"),
      "15" => array("20","80"),
      "20" => array("20","80"),
      "40" => array("40","60","80"),
      "45" => array("40","80"),
      "60" => array("40","60", "80"),
      "80" => array("10","20"),
      "90" => array("20","10","80")
);
*/


$status_name =  array (
      "00" => "NOT CREATED",
      "10" => "DRAFT",
      "15" => "DRAFT PENDING PAYMENT",
      "16" => "DRAFT PAYMENT OK",
      "17" => "DRAFT PAYMENT CANCEL",
      "20" => "UNDER REVIEW",
      "40" => "PUBLISHED",
      "45" => "WILLEXPIRE",
      "46" => "SOLD",
      "60" => "UNPUBLISHED",
      "80" => "DELETED",
      "90" => "REJECTED"
);

// translation for GETTEXT 
$status_name_translation =  array (
      "00" => _("NOT CREATED"),
      "10" => _("DRAFT"),
      "15" => _("DRAFT PENDING PAYMENT"),
      "16" => _("DRAFT PAYMENT OK"),
      "17" => _("DRAFT PAYMENT CANCEL"),
      "20" => _("UNDER REVIEW"),
      "40" => _("PUBLISHED"),
      "45" => _("WILLEXPIRE"),
      "46" => _("SOLD"),
      "60" => _("UNPUBLISHED"),
      "80" => _("DELETED"),
      "90" => _("REJECTED")
);


$supportfeedback_name_translation= array (
      "fraud" => _("fraud"),
      "wrong category" => _("wrong category"),
      "expired ad" => _("expired ad"),
      "other" => _("other"),
      "support" => _("support"),
      "advertising" => _("advertising"),
      "information" => _("information"),
      "subscription" => _("subscription")
);



// translation for GETTEXT 
$status_icon =  array (
      "00" => "flask",
      "10" => "floppy-o",
      "15" => "shopping-cart",
      "16" => "",
      "17" => "",
      "20" => "check",
      "40" => "check",
      "45" => "clock-o",
      "46" => "clock-o",
      "60" => "minus-square-o",
      "80" => "trash-o",
      "90" => "exclamation-circle"
);


$usertype_name =  array (
      "1" => "REGISTERED",
      "5" => "EDITOR",
      "9" => "SUPER-ADMIN"
);


$usertype_name_long=array(
  array("id" => "1", "value" => "1", "name"=>"REGISTERED"), 
  // array("id" => "5", "value" => "5", "name"=>"EDITOR"), 
  array("id" => "9", "value" => "9", "name"=>"ADMIN") 
); 

// navigation manu in addition to existing one 
$extra_mainnav=''; 
if ($EXTRA_MAIN_NAV_LINK1_TITLE){
  $extra_mainnav= array();
  $extra_mainnav[] = array ("title"=>$EXTRA_MAIN_NAV_LINK1_TITLE,"url"=>$EXTRA_MAIN_NAV_LINK1_URL ); 
  $extra_mainnav[] = array ("title"=>$EXTRA_MAIN_NAV_LINK2_TITLE,"url"=>$EXTRA_MAIN_NAV_LINK2_URL ); 
  $extra_mainnav[] = array ("title"=>$EXTRA_MAIN_NAV_LINK3_TITLE,"url"=>$EXTRA_MAIN_NAV_LINK3_URL ); 
}

$display_settings =  array (
  "max_pages_to_show" => $MAX_PAGES_TO_SHOW,
  "max_items_per_page" => $MAX_ITEMS_PER_PAGE, 
  "max_items_per_mod" => $MAX_ITEMS_PER_MOD,
  "nb_items_per_vmod" => $NB_ITEMS_PER_VMOD,
  "max_cat_per_column" =>  $MAX_CAT_PER_COLUMN,
  "max_cat_on_sidebar"=>$MAX_CAT_ON_SIDEBAR,
  "show_empty_cat" => $SHOW_EMPTY_CAT, 
  "hide_empty_buy_ad"=>$HIDE_EMPTY_BUY_AD,
  "hide_empty_cat_users"=>$HIDE_EMPTY_CAT_USERS,
  "split_desc_ad_details"=> $SPLIT_DESC_AD_DETAILS,
  "desc_ad_details_all_bottom"=>$DESC_AD_DETAILS_ALL_BOTTOM,
  "display_more_cat_link" => $DISPLAY_MORE_CAT_LINK,
  "max_pics_nb"=>$MAX_PIC_NB, 
  "max_skills_nb"=>$MAX_SKILLS_NB,
  "enable_country_map"=>$ENABLE_COUNTRY_MAP,   
  "zetvu_as_news"=> $ZETVU_AS_NEWS,
  "zetvu_as_video_tuto"=>$ZETVU_AS_VIDEO_TUTO, 
  "zetvu_visible_acl"=>$ZETVU_VISIBLE_ACL, 
  "zetvu_create_by_admin_only"=> $ZETVU_CREATE_BY_ADMIN_ONLY,
  "widgets_based_on_what" =>$WIDGETS_BASED_ON_WHAT,
  "homepage_display_what" =>$HOMEPAGE_DISPLAY_WHAT,
  "enable_debug_mode"=>$ENABLE_DEBUG_MODE, 
  "enable_debug_jstools"=>$ENABLE_DEBUG_JSTOOLS,
  "enable_files_manager"=>$ENABLE_FILES_MANAGER,
  "files_manager_max_nbr"=>$FILES_MANAGER_MAX_NBR,
  "header_show_nb_ads"=>$HEADER_SHOW_NB_ADS,
  "enable_vfields"=> $ENABLE_VFIELDS,
  "vfields_search"=> $VFIELDS_SEARCH,
  "adv_search_startup"=> $ADV_SEARCH_STARTUP ,
  "adv_search_autosuggest"=>$ADV_SEARCH_AUTOSUGGEST,
  "advs_forced_vfields"=>$ADVS_FORCED_VFIELDS,
  "adv_search_location"=>$ADV_SEARCH_LOCATION, 
  "seo_forced_vfields"=>$SEO_FORCED_VFIELDS,
  "seo_add_fields"=>$SEO_ADD_FIELDS,
  "seo_add_fields_pos"=>$SEO_ADD_FIELDS_POS,
  "seo_add_fields_sep"=>$SEO_ADD_FIELDS_SEP,
  "seo_display_fqdn"=>$SEO_DISPLAY_FQDN,
  "advs_no_freetext"=>$ADVS_NO_FREETEXT,
  "nav_no_bar"=>$NAV_NO_BAR,
  "urgent_ads_en"=>$URGENT_ADS_EN, 
  "enable_img_autoswipe"=>$ENABLE_IMG_AUTOSWIPE,
  "enable_contactthru_when_phone"=>$ENABLE_CONTACTTHRU_WHEN_PHONE, 
  "dpe_img_vfield_id"=>$DPE_IMG_VFIELD_ID, 
  "ges_img_vfield_id"=>$GES_IMG_VFIELD_ID,
  "new_sincelastvisit_en" =>$NEW_SINCELASTVISIT_EN,
  "ad_paid_nomods_aftercreation"=>$AD_PAID_NOMODS_AFTERCREATION,
  "urgent_ads_en"=>$URGENT_ADS_EN,
  "siret_control_url"=>$SIRET_CONTROL_URL,
  "extra_mainnav"=> $extra_mainnav,
  "indir_pro_only"=>$INDIR_PRO_ONLY,
  "indir_yes_default" =>$INDIR_YES_DEFAULT,
  "location_retricted_disp" =>$LOCATION_RETRICTED_DISP,
  "login_form_inpage"=>$LOGIN_FORM_INPAGE,
  "admin_simplelist_mode"=>$ADMIN_SIMPLELIST_MODE,
  "logo_fqdn"=>$LOGO_FQDN,
  "location_restricted_disp" =>$LOCATION_RESTRICTED_DISP,
  "links_on_ad"=>$LINKS_ON_AD,
  "links_on_user"=>$LINKS_ON_USER,
  'user_enable_newsletter'=>$USER_ENABLE_NEWSLETTER,
  'img_zoom_en'=>$IMG_ZOOM_EN,
  'vfields_display_hide_zerovalue'=>$VFIELDS_DISPLAY_HIDE_ZEROVALUE,
  'price_field_disable'=>$PRICE_FIELD_DISABLE,
  'price_field_expression'=>$PRICE_FIELD_EXPRESSION,
  'price_field_second'=>$PRICE_FIELD_SECOND,
  'main_content_width_short_en'=>$MAIN_CONTENT_WIDTH_SHORT_EN,
  'adlist_custom_fields_col_d'=>$ADLIST_CUSTOM_FIELDS_COL_D,
  "activate_text_scroll"=>$ACTIVATE_TEXT_SCROLL,
  "account_reactivate_en"=>$ACCOUNT_REACTIVATE_EN,
  "robot_name"=>$ROBOT_NAME,
  "simple_list_view_en"=>$SIMPLE_LIST_VIEW_EN,
  "video_list_view_en"=>$VIDEO_LIST_VIEW_EN,
  "audio_list_view_en"=>$AUDIO_LIST_VIEW_EN, 
  "gmap_list_view_en"=>$GMAP_LIST_VIEW_EN, 
  "gallery_list_view_en"=>$GALLERY_LIST_VIEW_EN,

  //Z6.2.0 renting mode and calendar options
  "rental_mode_en"=>$RENTAL_MODE_EN,
  "rental_mode_all_cat"=>$RENTAL_MODE_ALL_CAT,
  "calendar_auto_load"=>$CALENDAR_AUTO_LOAD,
  "calendar_rolling_months"=>$CALENDAR_ROLLING_MONTHS,
  "calendar_week_start_day"=>$CALENDAR_WEEK_START_DAY,
  "calendar_disable_before"=>$CALENDAR_DISABLE_BEFORE,
  "cookie_save_calendar_nav"=>$COOKIE_SAVE_CALENDAR_NAV, 
  "admin_acl_only_admin"=>$ADMIN_ACL_ONLY_ADMIN, 

  //Z6.2.
  "scroll_top_px"=>$SCROLL_TOP_PX, 

  //Z6.4.0. 
  "desc_max_char"=>$DESC_MAX_CHAR, 
  "user_refered"=>$USER_REFERED, 

  //Z6.5.2 
  "list_default_view"=>$LIST_DEFAULT_VIEW, 

    //Z6.5.1 
  "en_ad_hits"=>$EN_AD_HITS,
  "en_user_hits"=>$EN_USER_HITS,
  "en_ad_likes"=>$EN_AD_LIKES,
  "en_user_likes"=>$EN_USER_LIKES,
  // Z6.5.3 

  "maincat_user_pid"=>$MAINCAT_USER_PID, 

  "no_mobile_css"=>$NO_MOBILE_CSS, 

  //6.5.5 - load PHP pages (get it fromcustomized language page)
  "page_home_is_php"=>$page_home_is_php, 

  //6.5.6 - online rec of pictures
  "picture_rec_online"=>$PICTURE_REC_ONLINE,  

  "cust_logo_uri"=>$cust_logo_uri,  

  //6.5.9 
  "hide_nb_ads"=>$HIDE_NB_ADS, 

  "lostpassword_link"=>$LOSTPASSWORD_LINK,

  //7.0.0
  "cat_filter_protype"=>$CAT_FILTER_PROTYPE, 
  "userdetails_only_for"=>$USERDETAILS_ONLY_FOR, 

  //7.0.1
  "userdetails_contact_thru_site"=>$USERDETAILS_CONTACT_THRU_SITE,
  'en_richeditor'=>$EN_RICHEDITOR, 
  
  //7.0.2
  'medias_drop_zone_en'=>$MEDIAS_DROP_ZONE_EN,

  //7.0.3 
  "search_vfield_select_multi"=>$SEARCH_VFIELD_SELECT_MULTI, 

  "advs_in_title_only"=>$ADVS_IN_TITLE_ONLY,
  "advs_with_photo"=>$ADVS_WITH_PHOTO,
  "advs_with_video"=>$ADVS_WITH_VIDEO, 
  "advs_with_audio"=>$ADVS_WITH_AUDIO,

  "list_nav_pro_par"=>$LIST_NAV_PRO_PAR, 
  "mob_menu_style"=>$MOB_MENU_STYLE, 

  "calendar_for_protype"=>$CALENDAR_FOR_PROTYPE,

  //7.1.0 + 7.3.
  "advs_cityzip"=>$ADVS_CITYZIP,
  "advs_cityzip_mode"=>$ADVS_CITYZIP_MODE,
  "advs_cityzip_country_restriction"=>$ADVS_CITYZIP_COUNTRY_RESTRICTION,

  "advs_type_mode"=>$ADVS_TYPE_MODE,

  "advs_protype"=>$ADVS_PROTYPE,

  "vfields_mandatory"=>$VFIELDS_MANDATORY,

  "user_create_with_ad"=>$USER_CREATE_WITH_AD,

  // 7.5.1 
  "ad_expiration_for"=>$AD_EXPIRATION_FOR,

  "adv_search_startup_mobile"=>$ADV_SEARCH_STARTUP_MOBILE,

  "pics_slideshow"=>$PICS_SLIDESHOW,


  'd'=>'end'
);

 //Z6.5.0 - audio ads 
 if ($AUDIO_AD_EN || $AUDIO_USER_EN ) {
    $display_settings['audio'] = array(
    "audio_ad_en"=>$AUDIO_AD_EN,
    "audio_user_en"=>$AUDIO_USER_EN,
    "audio_file_max_size"=>$AUDIO_FILE_MAX_SIZE,
    "audio_file_max_nbr"=>$AUDIO_FILE_MAX_NBR,
    "audio_file_ext"=>$AUDIO_FILE_EXT,
    "audio_file_download"=>$AUDIO_FILE_DOWNLOAD,
    "audio_autoplay"=>$AUDIO_AUTOPLAY  ,
    "audio_rec_online"=>$AUDIO_REC_ONLINE,
    "audio_rec_max_duration"=>$AUDIO_REC_MAX_DURATION,
    "audio_rec_ext"=>$AUDIO_REC_EXT,
  );
 } else {
    $display_settings['audio'] = array(
      "audio_ad_en"=>$AUDIO_AD_EN,
      "audio_user_en"=>$AUDIO_USER_EN
    );
 }


 // 7.1.0  - verify context
 if ($VERIFY_EN){
  $display_settings['verify'] = array(
    "verify_en"=>$VERIFY_EN,
    "verify_status_vemail"=>$VERIFY_STATUS_VEMAIL,
    "verify_status_vmobilephone"=>$VERIFY_STATUS_VMOBILEPHONE,
    "verify_publish_rule"=>$VERIFY_PUBLISH_RULE,
    "verify_status_social"=>$VERIFY_STATUS_SOCIAL,
    "verify_status_ip"=>$VERIFY_STATUS_IP,
    "verify_status_email"=>$VERIFY_STATUS_EMAIL,
    "verify_status_mob"=>$VERIFY_STATUS_MOB,
    "verify_status_location"=>$VERIFY_STATUS_LOCATION  ,
    "verify_status_photo"=>$VERIFY_STATUS_PHOTO,
    "verify_status_siret"=>$VERIFY_STATUS_SIRET,
    "verify_status_review"=>$VERIFY_STATUS_REVIEW
   );
  }else {
    $display_settings['verify'] = array(
      "verify_en"=>$VERIFY_EN)
    ; 
  }


  //Z6.5.2 - video ads 
 if ($VIDEO_AD_EN || $VIDEO_USER_EN ) {
    $display_settings['video'] = array(
    "video_ad_en"=>$VIDEO_AD_EN,
    "video_user_en"=>$VIDEO_USER_EN,
    "video_file_max_size"=>$VIDEO_FILE_MAX_SIZE,
    "video_file_max_nbr"=>$VIDEO_FILE_MAX_NBR,
    "video_file_ext"=>$VIDEO_FILE_EXT,
    "video_file_download"=>$VIDEO_FILE_DOWNLOAD,
    "video_autoplay"=>$VIDEO_AUTOPLAY  ,
    "video_rec_online"=>$VIDEO_REC_ONLINE,
    "video_rec_max_duration"=>$VIDEO_REC_MAX_DURATION,
    "video_rec_ext"=>$VIDEO_REC_EXT,
  );
 } else {
    $display_settings['video'] = array(
      "video_ad_en"=>$VIDEO_AD_EN,
      "video_user_en"=>$VIDEO_USER_EN
    );
 }


  //Z6.7.0 - docs ads 
 if ($DOC_AD_EN || $DOC_USER_EN ) {
    $display_settings['doc'] = array(
    "doc_ad_en"=>$DOC_AD_EN,
    "doc_user_en"=>$DOC_USER_EN,
    "doc_file_max_size"=>$DOC_FILE_MAX_SIZE,
    "doc_file_max_nbr"=>$DOC_FILE_MAX_NBR,
    "doc_file_ext"=>$DOC_FILE_EXT,
    "doc_file_download"=>$DOC_FILE_DOWNLOAD
  );
 } else {
    $display_settings['doc'] = array(
      "doc_ad_en"=>$DOC_AD_EN,
      "doc_user_en"=>$DOC_USER_EN
    );
 }


  //Z730 - alert 
  if ($ALERT_EN  ) {
    $display_settings['alert'] = array(
    "alert_en"=>$ALERT_EN,
    "alert_acl"=>$ALERT_ACL,
    "alert_max_per_user"=>$ALERT_MAX_PER_USER,
    "alert_pooling_period_hours"=>$ALERT_POOLING_PERIOD_HOURS,
    "alert_expire_after_days"=>$ALERT_EXPIRE_AFTER_DAYS
    );
  } else {
    $display_settings['alert'] = array(
      "alert_en"=>$ALERT_EN
    );
  }



$modules_settings = array (
  "nb_items_per_vmod" => $NB_ITEMS_PER_VMOD,
  "enable_browsebyloc_mod"  => $ENABLE_BROWSEBYLOC_MOD,
  "browsebyloc_first_field" =>$BROWSEBYLOC_FIELDS_ORDER, 
  "enable_mostviewed_mod"  => $ENABLE_MOSTVIEWED_MOD,
  "enable_top_mod"        => $ENABLE_TOP_MOD,  
  "max_items_per_mod"   =>$MAX_ITEMS_PER_MOD,
  "enable_topgallery_mod" => $ENABLE_TOPGALLERY_MOD,
  "enable_latest_mod"=>$ENABLE_LATEST_MOD, 
  "enable_urgent_mod"=>$ENABLE_URGENT_MOD,
  "enable_social_widget"=>$ENABLE_SOCIAL_WIDGET,
  "social_widget_list"=>$SOCIAL_WIDGET_LIST,
  "enable_newsletter_widget"=>$ENABLE_NEWSLETTER_WIDGET,
  "layout_gallerie_widgets_forced_fullwidth"=>$LAYOUT_GALLERIE_WIDGETS_FORCED_FULLWIDTH,
  "sidebar_widgets_order_list" =>$SIDEBAR_WIDGETS_ORDER_LIST,
  "dynamic_update_widgets"=>$DYNAMIC_UPDATE_WIDGETS, 
  
  //7.0.3 
  "widget_fullwidth"=>$WIDGET_FULLWIDTH, 
  "userrelads_fullwidth"=>$USERRELADS_FULLWIDTH,


  'd'=>'end'
);

$user_profiles_settings = array (
  "user_profile_par_en"  => $USER_PROFILE_PAR_EN,
  "user_profile_pro_en"  => $USER_PROFILE_PRO_EN,
  'd'=>'end'
);

$locale_settings = array (
   'default_lat' =>$LOCALE_DEFAULT_LAT,
    'default_lng'=>$LOCALE_DEFAULT_LNG,
    'default_language'=>$LOCALE_DEFAULT_LANGUAGE,
    'default_timezone' =>$LOCALE_DEFAULT_TIMEZONE,
    'default_currency' =>$LOCALE_DEFAULT_CURRENCY,
    'default_unit' =>$LOCALE_DEFAULT_UNIT,
    'default_country_code' => $LOCALE_DEFAULT_COUNTRY_CODE,
    'default_sub_code' =>$LOCALE_DEFAULT_SUB_CODE,
    'invoice_companyname'=> $INVOICE_COMPANYNAME,
    'invoice_vat'=> $INVOICE_VAT,
    'invoice_company_address'=> $INVOICE_COMPANY_ADDRESS,
    'invoice_footertext'=> $INVOICE_FOOTERTEXT, 
    'cookie_duration_adult_disclamer'=>$COOKIE_DURATION_ADULT_DISCLAMER,
    'cookieprefix'=>$COOKIENAME,
    'cookie_display_cookies_disclamer'=>$COOKIE_DISPLAY_COOKIES_DISCLAMER,
    'disable_localization_validation'=>$DISABLE_LOCALIZATION_VALIDATION,
    'dis_ad_loc'=>$DIS_AD_LOC,
    'dis_user_loc'=>$DIS_USER_LOC, 
    'en_streetview'=>$EN_STREETVIEW, 
    'gmap_zoom'=>$LOCALE_GMAP_ZOOM,
    'gmap_custom_marker_url'=>$GMAP_CUSTOM_MARKER_URL,
    'en_gmap_in_display'=>$EN_GMAP_IN_DISPLAY, 
    'locale_location_restrictfield'=>$LOCALE_LOCATION_RESTRICTFIELD,
    'locale_location_restrictvalues'=>$LOCALE_LOCATION_RESTRICTVALUES,
    'locale_new_regions_fr'=>$LOCALE_NEW_REGIONS_FR, 
    'locale_disp_mode'=>$LOCALE_DISP_MODE, 

    'locale_ad_for'=>$LOCALE_AD_FOR,
    
    'd'=>'end'
); 

$social_settings = array(
  "oauth_sso_en"=>$OAUTH_SSO_EN,
  "facebook" => array(
    'fb_auth'=>$FB_AUTH,  
    'fb_integration' =>$FB_INTEGRATION, 
    'fb_url' =>$FB_URL,
    'fb_appid'=>$FB_APPID
    ), 
  "google" => array(
    'go_auth'=>$GO_AUTH, 
    'go_client_id'=>$GO_CLIENT_ID,
    'go_api_key'=>$GO_API_KEY,
    ), 
  "twitter" => array( 
    'tw_auth'=>$TW_AUTH, 
    'tw_appid'=>$TW_APPID),
  "linkedin" => array( 
    'lk_auth'=>$LK_AUTH, 
    'lk_appid'=>$LK_APPID)
);

$vtags_settings = array (
   'vtag1_en' =>$VTAG1_EN,
   'vtag1_url' =>$VTAG1_URL,
   'vtag1_boolean'=>$VTAG1_BOOLEAN,
   'vtag2_en' =>$VTAG2_EN,
   'vtag2_url' =>$VTAG2_URL,
   'vtag3_en' =>$VTAG3_EN,
   'vtag3_url' =>$VTAG3_URL,
   'vtag4_en' =>$VTAG4_EN,
   'vtag4_url' =>$VTAG4_URL,
   'vtag5_en' =>$VTAG5_EN,
   'vtag5_url' =>$VTAG5_URL,

    'd'=>'end'
); 

// Z6.0 services 
$services_settings = array (
  'services_version' =>$SERVICES_VERSION,
  'services_force_default_at_start'=>$SERVICES_FORCE_DEFAULT_AT_START, 
  'services_multi_en'=>$SERVICES_MULTI_EN, 
  'services_notif_before_days'=>$SERVICES_NOTIF_BEFORE_DAYS, 
  'services_deleteall_after_days'=>$SERVICES_DELETEALL_AFTER_DAYS, 
  'services_notify_en'=>$SERVICES_NOTIFY_EN, 
  'services_ad_threshold_notif'=>$SERVICES_AD_THRESHOLD_NOTIF,
  'services_price_free_during_trial'=>$SERVICES_PRICE_FREE_DURING_TRIAL, 
  'services_pro_free_options_list'=>$SERVICES_PRO_FREE_OPTIONS_LIST,
  'paid_options_price_free'=>$PAID_OPTIONS_PRICE_FREE,
  'all_price_freeofcharge'=>$ALL_PRICE_FREEOFCHARGE,
  'd'=>'end'
); 

// Z6.8 Communications 
$coms_settings = array (
  'coms_user_type' =>$COMS_USER_TYPE,
  'coms_ad_type' =>$COMS_AD_TYPE,
  'coms_rating_anonymous'=>$COMS_RATING_ANONYMOUS, 
  'coms_rating_nbr'=>$COMS_RATING_NBR, 
  'coms_rating_maxvalue'=>$COMS_RATING_MAXVALUE, 
  'coms_desc_max_char'=>$COMS_DESC_MAX_CHAR, 
  'coms_comment_likes_en'=>$COMS_COMMENT_LIKES_EN, 
  'coms_comment_dislike_en'=>$COMS_COMMENT_DISLIKE_EN, 
  'coms_max_displayed'=>$COMS_MAX_DISPLAYED,
  'coms_comment_reply_en'=>$COMS_COMMENT_REPLY_EN,
  'coms_rating_reply_en'=>$COMS_RATING_REPLY_EN,
  'coms_rating_multivotes_en'=>$COMS_RATING_MULTIVOTES_EN,
  'coms_rating_visual'=>$COMS_RATING_VISUAL,
  'coms_rating_self'=>$COMS_RATING_SELF,
  'coms_edit_en'=>$COMS_EDIT_EN,
  'd'=>'end'
); 

//Z6.5.0
$security_settings=
 array (
  'email_as_image_en' =>$EMAIL_AS_IMAGE_EN,
  'phone_as_image_en'=>$PHONE_AS_IMAGE_EN,
  'd'=>'e'
); 




/* message retruned in AJAX */
$returned_msg=array(
  "ad" => array( 
    "20"=> "ok ad under review",
    "80"=> "ok ad deleted",
    "40"=> "ok ad published"  
  ), 
  "item" => array( 
    "20"=> "ok ad under review",
    "80"=> "ok ad deleted",
    "40"=> "ok ad published"    
  ),
  "user" => array( 
    "40"=> "ok user registered"
  ) 
);  

/* 
userRights policy to ensure avery one authorized to do right things 
Array : WHAT {ad,item,user,cat} / ACTION => Min Right per type {1, owner, 9}
*/

$userRights =array (
  "ad" => array( 
     "create"=> "1", 
     "update" => array("status" => "owner", "filter" => "owner"),
     "updatestatus" => array("status" => "owner", "filter" => "owner"),
     "delete"=> "owner"
    ), 
   "ads" => array(  
     "delete"=> "9",
     "list"=> "9",
     "publish"=> "9",
     "unpublish"=> "9"
    ),
  "zetvu" => array( 
     "create"=> $ZETVU_CREATE_BY_ADMIN_ONLY ? "9" : "1", 
     "update" => array("status" => "owner", "filter" => "owner"),
     "updatestatus" => array("status" => "owner", "filter" => "owner"),
     "delete"=> "owner"
     ), 
     
  "item" => array( 
     "create"=> "1", 
     "update" => array("status" => "owner", "filter" => "owner"),
     "updatestatus" => array("status" => "owner", "filter" => "owner"),
     "delete"=> "owner"
     ), 
  "user" => array(  
     "update"=> "owner",
     "delete"=> "owner",
     "list" => array("status" => "owner", "filter" => "owner")
  ),
  "users" => array(  
     "update"=> "owner",
     "delete"=> "owner",
     "list" => array("status" => "owner", "filter" => "owner")
  ),
  "settings" => array( 
     "create"=> "9"
  ),
  "visitors" => array(  
     "delete"=> "9",
     "list"=> "9"
  ),
  "coms" => array(
     "create"=> "1",  
     "list"=> "9",
     'trashdeleted'=>"9", 
     "update" => array("status" => "owner", "filter" => "owner"),
     "updatestatus" => array("status" => "owner", "filter" => "owner"),
  )
  ,
  "cat" => array( 
     "create"=> "9", 
     "update"=> "9",
     "delete"=> "9",
     "list"=>"9"
  ),
  "cats" => array( 
     "create"=> "9", 
     "update"=> "9",
     "delete"=> "9",
     "list"=>"9"
  ),
  // "logs" => array( 
  //    "create"=> "9", 
  //    "update"=> "9",
  //    "delete"=> "9",
  //    "list"=>"9",
  //    "stats"=> "owner"
  // ),
  // "banners" => array( 
  //    "create"=> "9", 
  //    "update"=> "9",
  //    "resetclicks"=> "9",
  //    "list"=>"9"
  // )

);

if ($USER_CREATE_WITH_AD) $userRights['ad']['create'] = "0"; 


/* 
$salesRights policy to control the Commercial package and levels  
Array : WHAT {ad,item,user,cat} / ACTION => MAX rights (if blank=unlinited)
*/

$salesRights =array (
  "ad" => array( 
     "create"=> $MAX_TOT_ADS
     ), 
   
  "item" => array( 
     "create"=> $MAX_TOT_ADS
     ), 
);  



// ---- email routing policy and settings 

$email_fromadmin  = $EMAIL_FROMADMIN;   // admin email address. 
$email_admin      = $EMAIL_ADMIN;       // admin email address.
$email_superadmin      = $EMAIL_SUPERADMIN;       // admin email address.
$email_admin_reports=  ($EMAIL_ADMIN_REPORTS) ?  $EMAIL_ADMIN_REPORTS :  $EMAIL_ADMIN;       // email list for sending dayly reports
$email_support      = $EMAIL_SUPPORT;       // admin email address. 
$email_sales     = $EMAIL_SALES;       // admin email address. 
$email_header="";
$email_footer="";
 
$emailRoutingTable=array(
  "ad" => array( 

    "15"=> array(
      array ("title"=> _("Your Ad is pending payment"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" ),
      array ("title"=> _("A new Ad is pending payment "), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"ADMIN", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    ),

    "20"=> array(
      array ("title"=> _("Your Article is under review"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" ),
      array ("title"=> _("A new article must be approved"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"ADMIN", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    ), 
    
    "40"=> array(
      array ("title"=>  _("Your Article is published/modified"), "msgheader"=>$email_header, "msginner"=> _("Help on Article is published/modified"), "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" ),
      array ("title"=>  _("One Article has been published / modified"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"ADMIN", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    ), 
    
    "45"=> array(
      array ("title"=>  _("Your Article will expire"), "msgheader"=>$email_header, "msginner"=> _("Help on Article will expire"), "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    ), 
        
    "90"=> array(
      array ("title"=>  _("Your Article has been rejected"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    ),
        
    "80"=> array(
      array ("title"=>  _("Your Article has been deleted"), "msgheader"=>$email_header, "msginner"=>_("Help on Article has been deleted"), "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    )
),
  "user" => array( 

    "15"=> array(
      array ("title"=> _("Your access is pending payment"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" ),
      array ("title"=> _("A new user is pending payment "), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"ADMIN", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    ),

    "20"=> array(
      array ("title"=> _("Your access is under review"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" ),
      array ("title"=> _("A new user must be approved"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"ADMIN", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    ),

    "40"=> array(
      array ("title"=>  _("Your access is created/modified"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" ),
      array ("title"=>  _("A new user is registered/modified"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"ADMIN", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    ),
    
     "45"=> array(
      array ("title"=>  _("Your account will expire"), "msgheader"=>$email_header, "msginner"=> _("Help on account will expire"), "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    ), 
    
    "60"=> array(
      array ("title"=>  _("Your account is blocked"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    ),
    
    "80"=> array(
      array ("title"=>  _("Your Account has been deleted"), "msgheader"=>$email_header, "msginner"=>_("Help on account has been deleted"), "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    )
      
  ),

  "service" => array( 

    "15"=> array(
      array ("title"=> _("Your service is pending payment"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" ),
      array ("title"=> _("A new service is pending payment "), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"ADMIN", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    ),

    "40"=> array(
      array ("title"=>  _("Your service is activated"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" ),
      array ("title"=>  _("A new service is activated"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"ADMIN", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    ),
    
     "45"=> array(
      array ("title"=>  _("Your service will expire"), "msgheader"=>$email_header, "msginner"=> _("Help on account will expire"), "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    ), 
     
    "80"=> array(
      array ("title"=>  _("Your service is expired"), "msgheader"=>$email_header, "msginner"=>_("Help on account has been deleted"), "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    )
      
  ),
  
  "curuser" => array( 
    "40"=> array(
      array ("title"=>  _("Your profil has been modified"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    ),
    "60"=> array(
      array ("title"=>  _("Your account is blocked"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    )  
  ),
  // notify an Abuse to the ADMIN person.
  "abuse" => array( 
    "00"=> array(
      array ("title"=>  _("An article has been flaged :"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"ADMIN", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" ),
      array ("title"=>  _("You have flaged an article :"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    ) 
  ),
  // request a support / question to site admin 
  "support" => array( 
    "00"=> array(
      array ("title"=>  _("A user requests support"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"SALES", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" ),
      array ("title"=>  _("Your request for support"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    ),
  ),
  
  // request a technical support / question to site admin 
  "feedback" => array( 
    "00"=> array(
      array ("title"=>  _("A user requests support"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"SUPPORT", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" ),
      array ("title"=>  _("Your request for support"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    ),
  ),
  // a user want to get in contact with another user RETATED to an article ! 
  "contact" => array( 
    "00"=> array(
      array ("title"=>  _("A user is contacting you"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"OWNER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" ),
      array ("title"=>  _("Your message has been sent"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    ),
  ),
  
  // a user want to get in contact with another user based on the user profil only
  "contactuser" => array( 
    "00"=> array(
      array ("title"=>  _("A user is contacting you"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"OWNER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" ),
      array ("title"=>  _("Your message has been sent"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    ),
  ),
  
  
  "remind" => array( 
    "00"=> array(
      array ("title"=>  _("An article i like"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    )
  ),
  
  "lost" => array( 
    "00"=> array(
      array ("title"=>  _("Your new password"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    )
  ),

  "lost-link" => array( 
    "00"=> array(
      array ("title"=>  _("Reset Password"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    )
  ),

  "reactivateaccount" => array( 
    "00"=> array(
      array ("title"=>  _("Your account access"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    )
  ),
  
  "cron" => array( 
    "daily"=> array(
      array ("title"=>  _("Your daily info"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"ADMIN_REPORTS", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    ), 
    "hourly"=> array(
        array ("title"=>  _("Your hourly  info"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"ADMIN_REPORTS", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    ), 
    "weekly"=> array(
      array ("title"=>  _("Your weekly info"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"ADMIN_REPORTS", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    ) 
  ),
  "notif" => array( 
    "orange"=> array(
      array ("title"=>  _("Orange notification"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"SUPERADMIN", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    ), 
    "red"=> array(
        array ("title"=>  _("Red notification"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"SUPERADMIN", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
    ) 
  )
  
); 

// new option zads 4.9.4 -> send email to user only, not admin 
if ($EMAILS_ADMIN_ESSENTIAL_MODE==true){
  $emailRoutingTable=array(
    "ad" => array( 

      "15"=> array(
        array ("title"=> _("Your Ad is pending payment"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" ),
        array ("title"=> _("A new Ad is pending payment "), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"ADMIN", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
      ),

      "20"=> array(
        array ("title"=> _("Your Article is under review"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" ),
        array ("title"=> _("A new article must be approved"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"ADMIN", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
      ), 
      
      "40"=> array(
        array ("title"=>  _("Your Article is published/modified"), "msgheader"=>$email_header, "msginner"=> _("Help on Article is published/modified"), "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
      ), 
      
      "45"=> array(
        array ("title"=>  _("Your Article will expire"), "msgheader"=>$email_header, "msginner"=> _("Help on Article will expire"), "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
      ), 
          
      "90"=> array(
        array ("title"=>  _("Your Article has been rejected"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
      ),
          
      "80"=> array(
        array ("title"=>  _("Your Article has been deleted"), "msgheader"=>$email_header, "msginner"=>_("Help on Article has been deleted"), "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
      )
    ),
    "user" => array( 

      "15"=> array(
        array ("title"=> _("Your access is pending payment"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" ),
        array ("title"=> _("A new user is pending payment "), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"ADMIN", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
      ),

      "20"=> array(
        array ("title"=> _("Your access is under review"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" ),
        array ("title"=> _("A new user must be approved"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"ADMIN", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
      ),

      "40"=> array(
        array ("title"=>  _("Your access is created/modified"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
      ),
      
       "45"=> array(
        array ("title"=>  _("Your account will expire"), "msgheader"=>$email_header, "msginner"=> _("Help on account will expire"), "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
      ), 
      
      "60"=> array(
        array ("title"=>  _("Your account is blocked"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
      ),
      
      "80"=> array(
        array ("title"=>  _("Your Account has been deleted"), "msgheader"=>$email_header, "msginner"=>_("Help on account has been deleted"), "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
      )
        
    ),
    
    "curuser" => array( 
      "40"=> array(
        array ("title"=>  _("Your profil has been modified"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
      ),
      "60"=> array(
        array ("title"=>  _("Your account is blocked"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
      )  
    ),
    // notify an Abuse to the ADMIN person.
    "abuse" => array( 
      "00"=> array(
        array ("title"=>  _("An article has been flaged :"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"ADMIN", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" ),
        array ("title"=>  _("You have flaged an article :"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
      ) 
    ),
    // request a support / question to site admin 
    "support" => array( 
      "00"=> array(
        array ("title"=>  _("A user requests support"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"SALES", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" ),
        array ("title"=>  _("Your request for support"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
      ),
    ),
    
    // request a technical support / question to site admin 
    "feedback" => array( 
      "00"=> array(
        array ("title"=>  _("A user requests support"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"SUPPORT", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" ),
        array ("title"=>  _("Your request for support"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
      ),
    ),
    // a user want to get in contact with another user RETATED to an article ! 
    "contact" => array( 
      "00"=> array(
        array ("title"=>  _("A user is contacting you"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"OWNER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" ),
        array ("title"=>  _("Your message has been sent"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
      ),
    ),
    
    // a user want to get in contact with another user based on the user profil only
    "contactuser" => array( 
      "00"=> array(
        array ("title"=>  _("A user is contacting you"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"OWNER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" ),
        array ("title"=>  _("Your message has been sent"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
      ),
    ),
    
    
    "remind" => array( 
      "00"=> array(
        array ("title"=>  _("An article i like"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
      )
    ),
    
    "lost" => array( 
      "00"=> array(
        array ("title"=>  _("Your new password"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
      )
    ),

    "lost-link" => array( 
      "00"=> array(
        array ("title"=>  _("Reset Password"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"USER", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
      )
    ),
    
    "cron" => array( 
      "hourly"=> array(
        array ("title"=>  _("Your hourly  info"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"ADMIN_REPORTS", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
      ), 
      "daily"=> array(
        array ("title"=>  _("Your daily info"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"ADMIN_REPORTS", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
      ), 
      "weekly"=> array(
        array ("title"=>  _("Your weekly info"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"ADMIN_REPORTS", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
      ) 
    ),

    "notif" => array( 
      "orange"=> array(
      array ("title"=>  _("Orange notification"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"SUPERADMIN", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
      ), 
      "red"=> array(
        array ("title"=>  _("Red notification"), "msgheader"=>$email_header, "msginner"=>"", "msgfooter"=>$email_footer, "to"=>"SUPERADMIN", "cc"=>"", "bcc"=>"", "priority"=>"", "format"=>"" )
      )
    )
    
  );
} 

//patch this 
if ($EMAILS_TEMPLATES_ENH){
  // we use the JSON file for the templating mecanism 
  $emailcfg = file_get_contents($SETTINGS_PATH."emailroutes.json");
  $emailRoutingTable = json_decode($emailcfg, true); // decode the JSON into an associative array
}


//  ---- processing part --------------------------

$target_path = '../uploads/'; 
// where the official files (initial image + thumbnail)
$dest_path_ad = '../uploads/img/'; 
$dest_path_from_root_ad ="./uploads/img/"; 
// for Categories images 
$dest_path_cat = '../uploads/cat/'; 
$dest_path_from_root_cat ='./uploads/cat/';
// for user avatars images 
$dest_path_user = '../uploads/user/'; 
$dest_path_from_root_user ='./uploads/user/';


// ############# SERVLET FOR FILEACTONS ###########################  
if (isset($_POST["fileaction"]) ) {
  $action = $_POST["fileaction"] ;
  $filename = $_POST["filename"] ;
  
  if (($action == "save")) {
      $success = rename($target_path."".$filename, $dest_path."".$filename);
      if ($success) $message = "file storage successfull"; 
      else $message = "error during the file renaming process"; 
  }
    
  $json = array(
                  'success' => $success,
                  'message' => $message,
                  'what' => $what,
                  'action' => $action
              );
    echo json_encode($json);   
}





// ############# SERVLET FOR RSS  ###########################
if (isset($_GET["rss"]) ) {
  $filter="";
  $sqlerror="";
  
  $type=$_GET["rss"] ;
  
  $dbThisTable = $dbItemsTable; 
  $sql_sort=" ORDER BY `moddate` DESC ";
  // patch the sell type to get all rss feeds because RSS flow is already regsitered to feedburner.
  if ($type=="sell") {
      if ($filter=="") $filter.="  WHERE ((`type` =  'sell') OR  (`type` =  'buy'))"; else $filter.="  AND ((`type` =  'sell') OR  (`type` =  'buy'))";
  }
  else{ 
    if ($filter=="") $filter.="  WHERE `type` =  '".$type."' "; else $filter.="  AND `type` =  '".$type."' ";
  }
  
  
  if ($filter=="") $filter.="  WHERE `status` IN ('40', '45', '46') "; else $filter.="  AND `status` IN ('40', '45', '46')  ";
  $limit = "LIMIT 0, 10"; 
  $query = "SELECT * FROM `$dbThisTable`" .$filter." ". $sql_sort .  $limit ; 
  $result = mysql_query($query);
  
   if (!$result) $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
   else {
    $rss = RSS_header($type); 

    while ( $item = mysql_fetch_object ( $result ) ) {
        // Récupère la date de publication de la news
        $date_news= date ( "D, d M Y H:i:s" , strtotime( $item->moddate ) );
        // get first image
        $imgarray = explode(";", $item->imgname); 
        //$itemimg=$imgarray[0];
        $itemimg = explode("|", $imgarray[0]);       

        // On crée l'item avec ces données
        $rss .= "<item>" ;
        $rss .= "<title><![CDATA[".stripslashes($item->title)."]]></title>";
        //$rss .= "<title><".$item->title."></title>";
        $rss .= "<link>".$rss_site_url."#item-".$item->id."</link>" ;
        $rss .= "<description><![CDATA[";
        if ($item->imgname && $itemimg && ($itemimg!="")) 
          $rss .=	"<img height='50' width='50' src='".$rss_img_fullurl.$itemimg[0]."'>";
        $rss .= stripslashes($item->description)."]]></description>";
        $rss .= "<pubDate>".$date_news." GMT</pubDate>" ;
        $rss .= "</item>" ;
    }
    
    $rss .= "</channel>" ;
    $rss .= "</rss>" ;
  }
  if ($sqlerror=="") {
    //header ( "Content-type: text/xml;charset=utf-8" ) ;
    //header ( "Content-type: text/xml;charset=ISO-8859-1" );
    header ( "Content-type: text/xml" ) ;
    //header ( "Vary:Accept-Encoding");
    echo $rss;
    die;
  } else echo $sqlerror; 
}


// ############# SERVLET FOR TESTING PURPOSE ###########################
if (isset($_POST["test_badwords"]) ) {
    $in=$_POST["in"];
    $inAr=array($in);
  
    // call it 
    $res = check_for_badwords($inAr); 
    echo json_encode($res);   
}

// ############# SERVLET FOR INIT ###########################
if (isset($_POST["init"]) ) {

  $success=true;
  $message="received initialized"; 
  $action="init"; 
  $filter=""; 
  $sql_sort="";
  
  // get list of categories for initilalization of select box
  $itemcatlist = sql_get_cat_list('cat', '', '', $dbCatsTable, 'ext2');

  // get list of categories with number of items 
  $itemnbpercatsell = sql_get_cat_list('ad', 'sell', '', $dbItemsTable, 'ext');
  $itemnbpercatbuy = sql_get_cat_list('ad', 'buy', '', $dbItemsTable, 'ext');

  $itemnbpercatothers = array(); 
  foreach ($MAINCAT_LIST as $key => $value) {
    if (in_array($key, ['user', 'sell', 'buy'])) $toto=1; 
    else $itemnbpercatothers[$key] = sql_get_cat_list('ad', $key, '', $dbItemsTable, 'ext');
  }

  //  @zads4.0 ****
  // get list of categories with number of items / USER type ** @ZADS4.0 ...
  $usrnbpercat = sql_get_cat_list('user', '', '', $dbUsersTable, 'ext'); 
  

  // new zads 4.9 -> browse per location module 
  if ($ENABLE_BROWSEBYLOC_MOD) {
    if ($HOMEPAGE_DISPLAY_WHAT=="user")
      $itemloclist = sql_get_loc_list('user', '', '','', $dbUsersTable, 'ext');
    else 
      $itemloclist = sql_get_loc_list('ad', '', '','', $dbItemsTable, 'ext');
  }

  //manage fields from configuration 
  $fields_selection=false; 
  if ($EN_FIELDS_SELECTION){
    // we use the JSON file for the templating mecanism 
    $fields = file_get_contents($SETTINGS_PATH."fields.json");
    $fields_selection = json_decode($fields, true); // decode the JSON into an associative array
  }  

  // get total number of articles
  $sql_sort="";  
  $filter="  WHERE `status` IN ('40','45') ";
  $queryadfull = "SELECT COUNT(`id`) as `nbads` FROM `$dbItemsTable`" .$filter." ". $sql_sort ; 
  $resultads = mysql_query($queryadfull);
  $row_ads = mysql_fetch_object($resultads); 
  
  // get total number of users
  $sql_sort="";  
  $sql_group=" GROUP BY `protype` ";  
  //$filter="  WHERE `status` IN ('40', '45', '46') AND `protype` IN ('pub','pro') ";
  $filter="  WHERE `status` IN ('40', '45', '46')";
  $queryusersfull = "SELECT COUNT(`id`) as `nbusers`, `protype` FROM `$dbUsersTable`" .$filter." ".$sql_group.$sql_sort ; 
  $resultusers = mysql_query($queryusersfull);
  //$row_users = mysql_fetch_object($resultusers); 

  $usersnb = Array ();
  $strx='';
  if ($resultusers){
    $idx=0; $outdata="";  
    while ($row_user = mysql_fetch_object($resultusers)) { 
     // $usersnb[$idx] = Array (
     //        'protype' => $row_user->protype,
     //        'nb'=>$row_user->nbusers
     //      );
     // $idx+=1; 
     if ($strx!='') $strx.=','; // ad separator 
     $strx.= '"'. $row_user->protype.'" : "'.$row_user->nbusers . '"'; 
    }
    //$strx = '{ "pri" : "7","pro" : "9","pub" : "1" }';
    //$usersnb[0] = "{ $strx }";
    //$strx = '"pri" : "7","pro" : "9"'; // DEBUG TEST
    $strx='{'.$strx.'}'; 
    $strx= json_decode($strx);
    //$usersnb[0] = json_decode("{$strx}"); 
    $usersnb =$strx;
  }

  // get main cat list
  $main_cat='';
  if ($MAINCAT_LIST) $main_cat=$MAINCAT_LIST; 

  // get the banners @zads4.1
  if ($ENABLE_BANNER_ADSENSE){
    
    // construct the banner specific query
    // query all banners list which are ACTIVE (status=40) & curent-date is valid 
    // return the content + url + id + position 
    $dbThisTable = $dbBannersTable; 
    $join=""; 
    $filter = " WHERE `$dbThisTable`.`status` IN ('40','45')"; // publicehd
    $filter .= " AND   ( ( `$dbThisTable`.`position` LIKE  'news_%' ) "; // not a news
    $filter .= " OR   ( `$dbThisTable`.`position` LIKE  'alert_%' )) "; // not a news
    $filter .= " AND   ( NOW() BETWEEN `$dbThisTable`.`startdate` AND  `$dbThisTable`.`enddate` )  "; // publicehd

    $sql_sort=" ORDER BY `$dbThisTable`.`moddate` DESC ";
    $sql_limit =" LIMIT 0, 1 "; 
    $sql_group ="";

    $queryban = "SELECT `$dbThisTable`.`id`,`$dbThisTable`.`htmlcode`,`$dbThisTable`.`position`,`$dbThisTable`.`clicktrackingurl` FROM `$dbThisTable` ".$join .$filter." ". $sql_sort . " " . $sql_group . " " .$sql_limit  ; 
    $result = @mysql_query($queryban);

    $totnbrofresults = @mysql_num_rows($result);
    if (($totnbrofresults) && ($totnbrofresults !=0)){
      $idx=0;
      $outdata=""; 
      // first item is generic
      $newslist = Array ();
      $idx=0;
      while ($row = mysql_fetch_object($result)) { 
        $thistate= explode("|",$row->desc); 
        $thistate = $thistate[0]; 
        $outdata = Array (
              'htmlcode' => stripslashes($row->htmlcode),
              'clicktrackingurl'=>$row->clicktrackingurl,
              'id'=> $row->id,
              'position'=> $row->position 
            );
       $newslist[$idx] = $outdata; 
       $idx+=1; 
      }
     } else {
     $newslist = Array ();
    }
  }

  // add Vfields list into settings 
  if ($ENABLE_VFIELDS){
    $dbThisTable = $dbVFieldsTable; 
    // build the query 
    $filter = " WHERE `$dbThisTable`.`status` IN ('40','45')"; // publicehd
    $sql_sort=" ORDER BY `$dbThisTable`.`int_label` ASC ";
    $sql_limit =""; 
    $sql_group ="";

    $queryvfields = "SELECT `$dbThisTable`.* FROM `$dbThisTable` ".$join .$filter." ". $sql_sort . " " . $sql_group . " " .$sql_limit  ; 
    $result = @mysql_query($queryvfields);
    $totnbrofresults = @mysql_num_rows($result);
    if (($totnbrofresults) && ($totnbrofresults !=0)){
      $idx=0; $outdata=""; $vfields_list = Array ();      
      while ($row = mysql_fetch_object($result)) { 
        $outdata = Array (
              'id' => $row->id,
              'name'=>stripslashes($row->int_label), 
              'value'=>$row->id, 
              'int_label'=>stripslashes($row->int_label),
              'disp_label'=>stripslashes($row->disp_label),
              'forwhat'=> $row->forwhat,
              'domtype'=>$row->domtype,
              'subdomtype'=>$row->subdomtype,
              'stype'=>$row->stype,
              'unit'=>$row->unit,
              'values'=>$row->values,
              'scope'=> $row->scope, 
              'xmandatory' => $row->xmandatory,
              'xmin' => $row->xmin,
              'xmax' => $row->xmax,
              'xvisible' => $row->xvisible,
              'forprofile' => $row->forprofile,
              'xregx' => $row->xregx,
              'linkedvfield'=> $row->linkedvfield,
              'linkedvar'=> $row->linkedvar,
              'slaveid'=> $row->slaveid
            );
       $vfields_list[$idx] = $outdata; 
       $idx+=1; 
      }
     } else {
     $vfields_list = Array ();
    } // end IF results 
  }

  // test of expiration date : 
  $tbybend=false; 
  if ($TBYB_END_DATE) {
    if (time()>strtotime($TBYB_END_DATE))  $tbybend=true;
  }


  // output results
  $what="vars"; 
  $json = array(
                  'a_v'=>ZADS_VERSION,
                  'success' => $success,
                  'message' => $message,
                  'what' => $what,
                  'action' => $action,
                  'fullfqdn'=> $fullfqdn,
                  'shortfqdn'=>$DOMAIN_FQDN_SHORT,
                  'tandcfqdn'=>$TANDC_FQDN,
                  'ad_status_logic_registered' => $status_logic_registered,
                  'ad_status_logic_user_registered' =>$status_logic_user_registered,
                  'ad_status_logic_admin' => $status_logic_admin,
                  'ad_status_name' => $status_name,
                  'user_type_name' =>$usertype_name,
                  'user_type_name_long'=>$usertype_name_long,
                  'status_icon' => $status_icon,
                  'maincat'=>$main_cat,
                  'file_manager_mode'=>$FILE_MANAGEMENT, 
                  'allowed_file_extension'=>$FILE_ALLOWED_EXT, 
                  'social_sharing'=>$SOCIAL_SHARING,
                  'tw_integration'=>$TW_INTEGRATION,
                  'fb_integration'=>$FB_INTEGRATION,
                  'tw_auth'=>$TW_AUTH,
                  'fb_auth'=>$FB_AUTH,
                  'days_pub'=>$PUBLISHING_DURATION,
                  'days_archive'=>$ARCHIVE_DURATION,
                  'days_notif'=>$NOTIFICATIONBEFORE_DURATION, 
                  'feedburner_uri'=>$FEEDBURN_URI,
                  'layout_bg_pattern'=>$LAYOUT_BG_PATTERN,
                  'disable_zetvu'=>$DISABLE_ZETVU,
                  'enable_mostviewed_mod'=>$ENABLE_MOSTVIEWED_MOD,
                  'enable_top_mod'=>$ENABLE_TOP_MOD,
                  'enable_topgallery_mod'=>$ENABLE_TOPGALLERY_MOD, 
                  'enable_infinite_nav'=>$ENABLE_INFINITE_NAV,
                  'enable_infinite_scroll'=>$ENABLE_INFINITE_SCROLL,
                  'enable_elem_logs'=>$ENABLE_ELEM_LOGS,
                  'enable_user_logs'=>$ENABLE_USER_LOGS, 
                  'enable_banner_adsense'=>$ENABLE_BANNER_ADSENSE, 
                  'banner_adsense_pos_1'=>$banner_adsense_pos_1, 
                  'banner_adsense_src_1'=>$banner_adsense_src_1, 
                  'banner_adsense_pos_2'=>$banner_adsense_pos_2, 
                  'banner_adsense_src_2'=>$banner_adsense_src_2, 
                  'ad_preview_before' =>$AD_PREVIEW_BEFORE,
                  'user_preview_before' =>$USER_PREVIEW_BEFORE,
                  'debug'=>$querynbpercatfull, 
                  'debug2'=>$queryusrnbpercatfull,
                  'totnb_ads'=>$row_ads->nbads,
                  'totnb_users'=>$usersnb,
                  'display_settings' =>$display_settings, 
                  'vtags_settings'=>$vtags_settings, 
                  'home_msg'=>$HOME_MSG,
                  'catlist' =>$itemcatlist,
                  'itnbpcatsell' => $itemnbpercatsell,
                  'itnbpcatbuy' => $itemnbpercatbuy,
                  'itnbpcatothers'=>$itemnbpercatothers, 
                  'usrnbpcat' => $usrnbpercat, 
                  'tbybend' =>  $tbybend,
                  'pay_options' =>$general_catalogue['payoptions'],
                  'pricing_plan'=>$general_catalogue['pricing_plan'],

                  'locale_settings' => $locale_settings,
                  'modules_settings' => $modules_settings,
                  'social_settings'=>$social_settings,
                  'authorized_languages'=>$AUTHORIZED_LANGUAGES,
                  'dayskeepasnew'=>$DAYSKEEPASNEW,
                  'newslist' => $newslist,

                  // new zads 4.9 -> browse per location module 
                  'loclist' => $itemloclist, 

                  // new zads 5.5 -> Virtual field list  
                  'vfields_list' => $vfields_list,

                  // new zads 5.5 -> user profiles management
                  'user_profiles_settings' => $user_profiles_settings,

                  // new zads 6.0 - services 
                  'services_settings'=>$services_settings,

                  // new zads 6.8 - communications 
                  'coms_settings'=>$coms_settings,

                  // Z6.5.0
                  'security_settings'=>$security_settings,

                  // Z7.2.0  
                  'fields_selection'=>$fields_selection,

                  'end' => true
                  
              );

     if ($debug_tmp==1){ // add debug info into the stream when working local
       $json["xdebug"]= array(
                'queryban'=>$queryban,
                'sql' =>$queryusersfull,
                '_post_max_size'=> ini_get('post_max_size') 
                );  
     }
              
    // ob_start('ob_gzhandler');    
    // echo json_encode($json); 
    encode_json_and_send_with_compression($json); 
      
}

// ############# SERVLET FOR LOGIN  ###########################
if(isset($_POST["login"])) {

    
    //$tableName = "users"; 
    $action = $_POST["login"];
    $action2 = "";
    $action_pre="";  

    $tid = 0; 
    $taskid = 0 ;   
    $outData =""; 
    $outCode = 0; 
    $query = "" ; 
    
    $newuser = 0; 
    $sessionset=false; $must_reload=false;
    $specialdebug="";
    $specialdebugsession="-- in Login action -- ";

    $useraction =  $_POST["useraction"]; // set to 1 to indicate a user press  a button to get here 

    
    $authtype="lo"; // authentification type ("lo=local", "fb=facebook", ...)
    
    if (isset($_POST["loginname"])){
      $loginname =  trim(secure_var($_POST["loginname"])) ; 
      $loginpassword=  trim(secure_var($_POST["password"])) ;
    }
    
    if ($action == "init") {
      $specialdebugArr =""; 
      $specialdebugsession.="-- in Init -- ";
      // *** IMPORTANT : force all apps to use this session name insted of the default one.
      session_name("ZADSSESID"); // indicate which kind of session name to use.
      session_start(); // start the session
      
      /* --------- FACEBOOK AUtenth (new generation) -------------*/
      $tcookiename=trim($COOKIENAME."_OAUTH_facebook_".str_replace('.','_', $FB_APPID));
      if ($FB_AUTH && $_COOKIE[$tcookiename] !="") {
        $me = null;
        $specialdebugsession.=" / facebook VALID COOKIE, checking OAuth -";
        
        // get TOKEN 
        $access_token = trim($_COOKIE[$tcookiename]); 
        if ($access_token){

          // load the library 
          require_once ("inc/generic_API_client.php");
          
          // get the ME informations
          $api_url = "https://graph.facebook.com/v2.1/me" ; 
          $api_network="facebook";
          $api_params = array('alt' => 'json', 'access_token' => $access_token);
          $r= gen_api_executeRequest($api_url, $api_params);

          // process response 
          if ($r["code"]==200){
            $specialdebugsession.=" OAuth OK - ";
            $me=$r['result']; 
            $me = social_formatUser($me,$api_network); 
            //$logoutUrl = $facebook->getLogoutUrl();
            if ($me['email']) $loginname =  $me['email']; 
            else  $loginname =  $me['name'];

            $social_userid = $me['id']; 
            $authtype="fa"; 
            $action = "submit" ; $action_pre="init"; $sessionset=true;
          } else {
            logfile("notice", "OAuth ($api_network) error : ".$r['code'].' - '.$r['result']['error']['message']); 
            // delete the cookie to avoid further checks
            setcookie($tcookiename, "", time()-3600, '/');  
          }
        }
        $specialdebugArr = $me; 
        $specialdebug.="OAuth=$api_network / code=".$r['code']; 
      }// end GOOGLE autehtification 


      /* --------- GOOGLE AUtenth -------------*/
      $tcookiename=trim($COOKIENAME."_OAUTH_google_".str_replace('.','_', $GO_CLIENT_ID));
      if ($GO_AUTH && $_COOKIE[$tcookiename] !="") {
        $me = null;
        $specialdebugsession.=" / Google VALID COOKIE, checking OAuth -";
        
        // get TOKEN 
        $access_token = trim($_COOKIE[$tcookiename]); 
        if ($access_token){

          // load the library 
          require_once ("inc/generic_API_client.php");
          
          // get the ME informations
          $api_url = "https://www.googleapis.com/oauth2/v1/userinfo" ; 
          $api_network="google";
          $api_params = array('alt' => 'json', 'access_token' => $access_token);
          $r= gen_api_executeRequest($api_url, $api_params);

          // process response 
          if ($r["code"]==200){
            $specialdebugsession.=" OAuth OK - ";
            $me=$r['result']; 
            //$logoutUrl = $facebook->getLogoutUrl();
            $loginname =  $me['email']; 
            $authtype="go"; 
            $action = "submit" ; $action_pre="init"; $sessionset=true;
          } else {
            logfile("notice", "OAuth ($api_network) error : ".$r['code'].' - '.$r['result']['error']['message']); 
            // delete the cookie to avoid further checks
            setcookie($tcookiename, "", time()-3600, '/');  
          }
        }
        $specialdebugArr = $me; 
        $specialdebug.="OAuth=$api_network / code=".$r['code']; 
      }// end GOOGLE autehtification 


      /* --------- TWITTER  AUtenth -------------*/
      $tcookiename=trim($COOKIENAME."_OAUTH_twitter_".str_replace('.','_', $TW_APPID));
      if ($GO_AUTH && $_COOKIE[$tcookiename] !="") {
        $me = null;
        $specialdebugsession.=" / twitter VALID COOKIE, checking OAuth -";
        
        // get TOKEN and SECRET for this user, this is very specific to TWITTER 
        $cc= explode(':',trim($_COOKIE[$tcookiename])); 

        $access_token = $cc[0]; 
        $access_secret_arr =  explode('@',$cc[1]);  
        $access_secret = $access_secret_arr[0]; 
        if ($access_token){
          $api_network="twitter";

          // // load the library 
          // require_once ("inc/generic_API_client.php");
          
          // // get the ME informations
          // $api_url = "https://api.twitter.com/1.1/account/verify_credentials.json" ; 
          // $api_network="twitter";
          // $api_params  = array( 
          //   'oauth_consumer_key' =>  $TW_APPID,
          //   'oauth_nonce' => time(),
          //   'oauth_signature_method' => 'HMAC-SHA1',
          //   'oauth_token' => $access_token,
          //   'oauth_timestamp' => time(),
          //   'oauth_version' => '1.0'
          // );
          
          // $r= gen_api_executeRequest($api_url, $api_params, HTTP_METHOD_GET, true, $TW_SECRET, $access_secret);

          // logfile("debug", "OAuth people result: ".var_export($r,true)); 

          require_once ("inc/TwitterAPIExchance.php");
          $settings = array(
            'oauth_access_token' => $access_token,
            'oauth_access_token_secret' => $access_secret,
            'consumer_key' => $TW_APPID,
            'consumer_secret' => $TW_SECRET
          );

          // $url = 'https://api.twitter.com/1.1/search/tweets.json';
          $url = 'https://api.twitter.com/1.1/account/verify_credentials.json';
          $requestMethod = 'GET';
          $getfields = '?q='; // MANDATORY OTHERWISE DOES NOT WORK ! 
          $twitter = new TwitterAPIExchange($settings);

          // Get tweets
          $r = $twitter->setGetfield($getfields)
                    ->buildOauth($url, $requestMethod)
                    ->performRequest();


          // process response 
          if ($r["code"]==200) {
            $specialdebugsession.=" OAuth OK - ";
            $me=$r['result']; 
            //$logoutUrl = $facebook->getLogoutUrl();
            $loginname =  $me['screen_name'];  // twitter does not send back EMAIL address !!
            $me = social_formatUser($me,$api_network); 
            $authtype="tw"; 
            $action = "submit" ; $action_pre="init"; $sessionset=true;
          } else {
            // logfile("notice", "OAuth ($api_network) error : ".$r['code'].' - '.$r['result']['error']['message']); 
            // delete the cookie to avoid further checks
            setcookie($tcookiename, "", time()-3600, '/');  
          }
        }
        $specialdebugArr = $me; 
        $specialdebug.="OAuth=$api_network / code=".$r['code']; 
      }// end TWITTER  autehtification 

      /* --------- LINKEDIN  AUtenth -------------*/
      $tcookiename=trim($COOKIENAME."_OAUTH_linkedin_".str_replace('.','_', $LK_APPID));
      if ($GO_AUTH && $_COOKIE[$tcookiename] !="") {
        $me = null;
        $specialdebugsession.=" / linkedin VALID COOKIE, checking OAuth -";
        
        // get TOKEN 
        $access_token = trim($_COOKIE[$tcookiename]); 
        if ($access_token){

          // load the library 
          require_once ("inc/generic_API_client.php");
          
          // get the ME informations
          $api_url = "https://api.linkedin.com/v1/people/~:(picture-url,first-name,last-name,id,formatted-name,email-address)" ; 
          $api_network="linkedin";
          $api_params = array('format' => 'json', 'oauth2_access_token' => $access_token);
          $r= gen_api_executeRequest($api_url, $api_params);

          // logfile("debug", "OAuth people result: ".var_export($r,true)); 

          // process response 
          if ($r["code"]==200){
            $specialdebugsession.=" OAuth OK - ";
            $me=$r['result']; 
            //$logoutUrl = $facebook->getLogoutUrl();
            $loginname =  $me['emailAddress']; 
            $me = social_formatUser($me,$api_network); 
            $authtype="li"; 
            $action = "submit" ; $action_pre="init"; $sessionset=true;
          } else {
            logfile("notice", "OAuth ($api_network) error : ".$r['code'].' - '.$r['result']['error']['message']); 
            // delete the cookie to avoid further checks
            setcookie($tcookiename, "", time()-3600, '/');  
          }
        }
        $specialdebugArr = $me; 
        $specialdebug.="OAuth=$api_network / code=".$r['code']; 
      }// end LINKEDIN  autehtification 


      /* --------- SESSION AUtenth -------------*/
      if (!$sessionset && ($_COOKIE["ZADSSESID"] !="")) { // detect if a session is set . session_id does not give the result               
         $specialdebugsession.="/ COOKIE ZADSSEID detected -- ";

        if ($_SESSION["authtype"]=='fa'){
          $sessionset=false;
          $specialdebugsession.="-- ignoring ZADSSEID as is a FACECOOK AUTH ! ";
        }
        else {
          if (isset($_SESSION['user'])){
            // double security 
            if ($_SERVER["HTTP_USER_AGENT"] == $_SESSION['user_agent']){
            
              $loginname = $_SESSION['user'];
              $loginpassword = $_SESSION['user_passwd'];
              $action = "submit" ; // continue processing
              $action_pre="init"; // indicate the source of the action to change displaying
              $sessionset=true; 
              
              $specialdebugsession .="session is detected"; 
              $specialdebugsession .="- user is $loginname"; 
              $specialdebugsession .="- session name is ".session_name();
              $specialdebugsession .="- session duration (in min) is ".session_cache_expire();
            } else {
              $specialdebugsession.="-- failed : Users agent is different from cookie -- ";
            }
          } else {
            $specialdebugsession.="-- failed : no USER info in session matching  this one  -- ";
          }
       }
      }
    
      /* --------- COOKIE REMEMBER ME AUtenth -------------*/
      if (!$sessionset && isset($_COOKIE[$COOKIENAME."_REMEMBER_ME" ]))
      {
        //if ($debug_tmp==1){ fwrite($debugfile,"imin session4");  fwrite($debugfile,"\n");}
        $cookierxtext = $_COOKIE[$COOKIENAME."_REMEMBER_ME" ]; 
        $cookierxarray = explode("&", $cookierxtext);       
        $cookierxarraysub = explode("=", $cookierxarray[0]);
        $loginname = $cookierxarraysub[1]; 
        $cookierxarraysub = explode("=", $cookierxarray[1]);
        $loginpassword = $cookierxarraysub[1]; 

        $specialdebugsession .=" -- Login using COOKIE name=$COOKIENAME_REMEMBER_ME  / text = $cookierxtext";

        $action = "submit" ; // continue processing
        $action_pre="init"; // indicate the source of the action to change displaying
        $sessionset=true; 

      }
    }
  
    if ($action == "submit") {
      $outCode = 0;
      $newuser = 0;   
        
        
          // check in database if user exists
          $sqllimit= ' LIMIT 1 '; // security mecanism to  limit SQL INJECTION impacts
          //@zads4.9.2 : extra protection to prevent access from users which are not approved
          //@Z6.1  : add search to 80 (deleted items) in order to display a specifi message 
          $extrawhere = " AND  `$dbUsersTable`.`status` IN ('20', '40','45','46', '80') ";
          if ($authtype=="fa"){
            if ($loginname!=''){
              $query = "SELECT * FROM $dbUsersTable WHERE ( username = '".$loginname."' OR email = '".$loginname."')  ". $extrawhere ." ". $sqllimit ;
            }
            $query = "SELECT * FROM $dbUsersTable WHERE ( userid = '".$social_userid."')  ". $extrawhere ." ". $sqllimit ;
          } else if ($loginname!='') {
            $query = "SELECT * FROM $dbUsersTable WHERE ( username = '".$loginname."' OR email = '".$loginname."')  ". $extrawhere ." ". $sqllimit ;
          } 
          $result = @mysql_query($query);
          $totnbrow = mysql_num_rows($result);
        
         if (mysql_num_rows($result)) {
              $row = mysql_fetch_object ($result) ; 
              $numberfields = mysql_num_fields($result);
              if (   in_array($authtype,array('fa','go','tw','li'))
                   || (($authtype=="lo") && ($row->password == $loginpassword))
                 ){

                // -- csea of Login & password OK but status is 80 
                if ($row->status=="80") {
                  $message =  "account expired" ; 
                  $outCode=0; 
                  $outCode2 = 99997;
                  delete_all_cookies(); // delete cookies to avoid issue when changing passwords

                } 
                else  if ($row->status=="20") {
                  $message =  "account under review" ; 
                  $outCode=0; 
                  $outCode2 = 99997;
                } 
                // -- normal case = LOgin + passwword + status is OK 
                else {

                // retrive data from pricing plan 
                // variables which can be managed through the plan : 
                // STEP 1 = 
                // ... nb of ads , nbr of pictures, videoembedd, nbr of words, restricted cat-ids, subscription duration
                // STEP 2 = 
                // ... nbr of days , features, highlighted
               
                // long description 
                if ($general_catalogue['pricing_plan']['enable']){
                   if ($row->plan){
                    //retieve the associated plan : 
                    $idplan =  stripslashes($row->plan);
                    $plan_details =  $general_catalogue['pricing_plan']['user'][$idplan];
                    if ($plan_details==NULL) $plan_details=''; // set e uniform response ''  = nothing
                   }
                   else 
                      $plan_details ='';
                }

                // get the list of adds in case we use the plan or services section 
                $this_user_id=$row->id; 
                $totnbads_thisuser=0; $adlist_thisuser=''; 
                $hasplan =  ($row->plan) ? true :  false; 
                if ($this_user_id &&  ($hasplan || $SERVICES_MULTI_EN)) 
                {
                  // -- get the total number of PUBLISHED adds from this user  !
                  $querynbads = "SELECT `$dbItemsTable`.`id`  
                                    FROM `$dbItemsTable` 
                                    WHERE  `$dbItemsTable`.`userid` = '".$this_user_id."'
                                            AND `$dbItemsTable`.`status` IN ('15', '20', '40','45','46', '60', '80') 
                                  "; 
                  $resultnbads = mysql_query($querynbads);
                  if ($resultnbads) {
                    $thistotnbrow = mysql_num_rows($resultnbads);
                    if ($thistotnbrow==0) $adlist_thisuser=";";
                    else {
                      $adlist_thisuser=";";
                      while ($rowy = mysql_fetch_object($resultnbads)) { 
                        $adlist_thisuser .=  $rowy->id .";";
                        $totnbads_thisuser+=1;
                      }
                    }
                  }
                }


                // new zads6.0 , get total nbr of addds for plan based on categories & also "paiement waiting items"
                $this_user_id=$row->id; 
                $adlist_thisuserwithcat=''; 
                $hasplan =  ($row->plan) ? true :  false; 
                if ($SERVICES_MULTI_EN)
                {
                  // -- get the total number of PUBLISHED adds from this user  !
                  $querynbadswithcat = "SELECT  COUNT(i.`id`) AS 'nbads' , c.`pid` AS 'pid'
                                    FROM `$dbItemsTable` i
                                    LEFT JOIN `$dbCatsTable` c ON i.`catid`= c.`id`
                                    WHERE  i.`userid` = '".$this_user_id."'
                                      AND i.`status` IN ('15', '20', '40','45','46', '60', '80') 
                                    GROUP BY c.`pid`
                                  "; 
                  $resultnbadswithcat = mysql_query($querynbadswithcat);

                  if ($resultnbadswithcat) {
                    $adlist_thisuserwithcat=array();
                    while ($rowt = mysql_fetch_assoc($resultnbadswithcat)) { 
                      $adlist_thisuserwithcat[] = $rowt;
                    }
                  } else {
                    echo  "Could not successfully run query from DB: " . mysql_error(). "--".$querynbadswithcat;
                    die;

                  }
                }


                // get list of services 
                $this_user_id=$row->id; 
                if ($SERVICES_MULTI_EN)
                {
                  // -- get the total number of PUBLISHED SERVICES from this user  !
                  $querymyservices = "SELECT *  FROM `$dbServicesTable` WHERE `userid` = '".$this_user_id."' ORDER BY `createdate` ASC "; 
                  $resultmyservices = mysql_query($querymyservices);
                  if ($resultmyservices) {
                    $myservices=array();
                    while ($rowz = mysql_fetch_assoc($resultmyservices)) { 
                      $myservices[] = $rowz;
                    }
                  }
                }

                // output the datas 
                $outCode = 0; // 
                $outData = Array (
                    'id'=> $row->id,
                    'firstname' => stripslashes($row->firstname),
                    'lastname'=> stripslashes($row->lastname),
                    'username'=> stripslashes($row->username), 
                    'accronym'=> $row->accronym,
                    'email'=> stripslashes($row->email),
                    'phone'=> $row->phone,
                    'location'=> stripslashes($row->location),
                    'usertype'=> $row->usertype,
                    'userid'=> $row->userid,
                    'status'=> $row->status,
                    'sendEmail'=> $row->sendEmail,
                    'gid'=> $row->gid,
                    'registerdate'=> $row->registerdate,
                    'lastvisitdate'=> $row->lastvisitdate,
                    'lastvisitstamp'=> strtotime($row->lastvisitdate)*1000, 
                    'lastmaildate'=> $row->lastmaildate,
                    'activation'=> $row->activation,
                    'preferences'=>  $row->preferences,
                    'favads'=> $row->favads,
                    'imgurl'=> $row->imgurl,
                    'imgpath'=> $dest_path_from_root_user,
                    'assocprojects'=> $row->assocprojects,
                    'gender' => $row->gender,
                    'auth'=> $row->auth,
                    'locale'=> stripslashes($row->locale),
                    
                    // ZADS4.0 addition 
                    'avatarimg'=> $row->avatarimg,
                    'probannerimg'=> $row->probannerimg,
                    'probannerurl'=> $row->probannerurl,
                    'folioimg'=> $row->folioimg,
                    'skills'=> $row->skills,
                    'priority'=> $row->priority,
                    'expiredate'=> $row->expiredate,
                    'expiredatestamp'=>  strtotime($row->expiredate)*1000,
                    'protype'=> $row->protype,
                    'procpny'=>stripslashes($row->procpny),             
                    'prosiret'=> $row->prosiret,
                    'prowebsite'=> stripslashes($row->prowebsite),
                    'social'=> $row->social,
                    'loclatlng'=> $row->loclatlng,
                    'loczipcode'=> $row->loczipcode,        
                    'loccity'=> stripslashes($row->loccity),
                    'locdept'=> stripslashes($row->locdept),
                    'locregion' => stripslashes($row->locregion),
                    'loccountrycode'=> $row->loccountrycode,
                    'lochash'=> stripslashes($row->lochash),
                    'lochashregion' => $row->lochashregion,
                    'bio' => stripslashes($row->bio),
                    'moddate' => $row->moddate,
                    'moddatestamp'=>  strtotime($row->moddate)*1000,

                     // ZADS4.9 addition 
                    'plan'=> stripslashes($row->plan),
                    'videoembed'=> $row->videoembed,
                    'longdesc'=> stripslashes($row->longdesc),
                    'plan_details'=> $plan_details,
                    'openhours' => $row->openhours,
                    'adlist'=>$adlist_thisuser,
                    'totnbads' => $totnbads_thisuser,

                    // ZADS5.0 addition 
                    'desc2'=> stripslashes($row->desc2),
                    'desc3'=> stripslashes($row->desc3),
                    'links'=> $row->links,
                    'email2'=> stripslashes($row->email2),
                    'phone2'=> $row->phone2,
                    'address2'=> stripslashes($row->address2),
                    'cat2'=> $row->cat2,
                    'cat3'=> $row->cat3,
                    'date2'=> $row->date2, 

                     //zads6.0 additions 
                    'indir'=> $row->indir,
                    'banclicks'=>$row->banclicks,
                    'myservices'=> $myservices,
                    'adlist_thisuserwithcat'=>$adlist_thisuserwithcat,

                    //zads5.5 additions 
                    'vfields'=> $row->vfields,

                    //@Z6.5.0 addition
                    'audiourl'=> $row->audiourl,
                    'videourl'=> $row->videourl,

                    //zads 6.1 newsletter
                    'newsletter'=> $row->newsletter,
                    
                    //@Z7.1.0
                    'verify'=>$row->verify,

                    //Z1.5
                    'dob'=>reformatDate($row->dob, 'Y-m-d','d/m/Y')  

                    );

                // patch IMAGE when using the social network image and no change after
                if ( in_array($authtype,array('fa','go','tw','li')) && $outData['avatarimg']=='' ){
                    $outData['imgurl']= ''; 
                    $outData['imgpath']= $me['picture']; 
                }


                $message = "Access granted , welcome !" ; 
                $xusertype= $row->usertype;
                $xuserid= $row->id;
                $xuserloclatlng = $row->loclatlng;
                $xassocprojects =  $row->assocprojects;
                                    
                // patch last visit timestamp and ip address 
                $stamp2= date( 'Y-m-d H:i:s', time());
                $query2 = "UPDATE $dbUsersTable SET 
                              `lastvisitdate` = '".$stamp2."' 
                            , `ip` = '".$serverremoteaddr."' 
                            , `useragent`='".$useragent."'
                            WHERE `id` = '".$row->id."'";
                $result2 = @mysql_query($query2);
                

                // get more info on ITEMS from THIS USER
                $item2=array();
                $item2_users=array();
                $query_gi = "SELECT COUNT(`id`) as `nbads`, `status` FROM $dbItemsTable WHERE (`userid` = '".$row->id."') GROUP BY `status`";
                $result_gi = @mysql_query($query_gi);
                if (mysql_num_rows($result_gi)){
                  //$numberfields = mysql_num_fields($result_gi); 
                  while ($row_gi = mysql_fetch_array($result_gi)) { 
                      $item2[]  = array("name" =>$row_gi["status"], "val"  => $row_gi["nbads"]); 
                    }
                } 
                
                 // get more info on ITEMS for ADMIN display 
                if ($row->usertype==9){
                  $query_giad = "SELECT COUNT(`id`) as `nbads`, `status` FROM $dbItemsTable GROUP BY `status`";
                  $result_giad = @mysql_query($query_giad);
                  if (mysql_num_rows($result_giad)){
                    while ($row_gi = mysql_fetch_array($result_giad)) { 
                        $item2[]  = array("name" =>"admin_".$row_gi["status"], "val"  => $row_gi["nbads"]); 
                      }
                  }

                  $query_giuser = "SELECT COUNT(`id`) as `nbusers`, `status` FROM $dbUsersTable GROUP BY `status`";
                  $result_giuser = @mysql_query($query_giuser);
                  if (mysql_num_rows($result_giuser)){
                    while ($row_gi = mysql_fetch_array($result_giuser)) { 
                        $item2_users[]  = array("name" =>"admin_".$row_gi["status"], "val"  => $row_gi["nbusers"]); 
                      }
                  }

                }
               }
              } 
              // case of incorrect password 
              else {
                  $message =  "incorrect LOCAL  password  - please check" ; 
                  $outCode=0; 
                  $outCode2 = 99998;
                  if ( $action_pre=="init") delete_all_cookies(); // delete cookies to avoid issue when changing passwords
              }
         } 
         else {
         // case of NO result found (no login match) but this is a VALID social connection
         if ( $OAUTH_SSO_EN && in_array($authtype,array('fa','go','tw','li')) ) {
          if ($OAUTH_AUTO_CREATE_USER){

            // create the user in the case of a loggin without prior registration
            $dbThisTable = $dbUsersTable; 
            $auth_default_usertype=1;
            $auth_default_protype="pri";  

            if ($authtype=="go") {
              $me["last_name"]=$me["family_name"]; // force this ! 
              $me["first_name"]=$me["given_name"]; // force this ! 
            }


            // modified in 7.0.1 to support default plan
            $xplan=''; 
            if ($OAUTH_AUTO_CREATE_USER_DEFAULT_PLANID) $xplan=$OAUTH_AUTO_CREATE_USER_DEFAULT_PLANID;
            $query_forcedcreate = "INSERT INTO `".$dbThisTable."` (`plan`,`username`,  `auth`, `gender`,`usertype`, `protype`, `firstname`, `lastname`, `email`, `moddate`,`registerdate`,`lastvisitdate`,`status`, `imgurl`,`userid`,`location`, `locale`) ";
            $query_forcedcreate .= "VALUES ('".$xplan."', '".$me["name"]."', '".$authtype."', '".$me["gender"]."', '$auth_default_usertype', '$auth_default_protype','".$me["first_name"]."', '".$me["last_name"]."','".$me["email"]."',  '$stamp','$stamp','$stamp','40','', '".$me["id"]."','".$me["location"]["name"]."', '".$me["locale"]."');";


            $result = mysql_query($query_forcedcreate);  
            $sqlerror=""; 
            if (!$result) {
              $message =  "Could not successfully run query from DB: " . mysql_error(). "--".$query_forcedcreate;
              $outCode=99999;$success=false;
            }
            else {
              $outCode=0;
              $must_reload=true; // indicat that user must reload 
            }

          } // social auth is OK but no AUTO CREATION of user 
          else {
              $outCode=0; 
              $message =  "social login auth ok but need to register ";
              $outCode2 = 99990;
          }

         } 
         else{
          $message =  "incorrect Login name" ; //no user found
          $outCode=0; 
          $outCode2 = 99999;
          if ( $action_pre=="init") delete_all_cookies(); // delete cookies to avoid issue when changing passwords

         }
        }
        if ($outCode==0 ) $success=true; 
        
        // Save the session  and add a cookie if necessary 
        if (($outCode==0) && ($outCode2!=99999) && ($outCode2!=99998)&& ($outCode2!=99997)&& ($outCode2!=99990)) {  
          // set session variable
          if (session_id()=="") { 
            session_name("ZADSSESID");  
            $ret =  session_start();
            $specialdebugsession.="-- restarting a SESSION : result = ".$ret."-- ";
            logfile('', "[core1] : SUBMIT - session re-started"); 

          }  // start the session if not set
    
          $specialdebugsession.="-- saving data in session ".session_id()." -- ";

          logfile('', "[core1] : SUBMIT- saving data under session =".session_id()); 
          
          $_SESSION['user']= $loginname; 
          $_SESSION['user_passwd'] = $loginpassword;  
          $_SESSION['user_agent']=$_SERVER["HTTP_USER_AGENT"]; // SECURITY - Session hack 
          $_SESSION['user_type']= $xusertype;
          //$_SESSION['usertype']= $xusertype;
          $_SESSION['authtype']= $authtype; 
          $_SESSION['user_id']= $xuserid; 
          $_SESSION['user_loclatlng']= $xuserloclatlng;
          $_SESSION['assocprojects']=$xassocprojects; // used for identification of SUPERADMIN 
          $msgtext="Isavecall";


          $xmaxsessiontime =  isset($MAX_SESSION_DURATION) ?  (int)$MAX_SESSION_DURATION : 60*60*24*30 ; 
          
          if ($_POST["rememberme"]=="yes"){
            // construct the cookie text 
            $cookietxt = "login=".$loginname."&password=".$loginpassword."&usertype=".$xusertype."&lastconnection=".$stamp;
            // add the cookie if requested
            setcookie($COOKIENAME."_REMEMBER_ME" ,$cookietxt , (time() + $xmaxsessiontime), '/');

            $specialdebugsession .="setting COOKIE name=$COOKIENAME_REMEMBER_ME / text = $cookietxt";
          }
        } 
    } 


    // reactivate an account which is on 80 status 
    if ($action == "reactivate" && $ACCOUNT_REACTIVATE_EN) {
        $sendemailflag=false;
        $success=true;
        // check in database if user exists
        $sqllimit= ' LIMIT 1 '; // security mecanism to  limit SQL INJECTION impacts
        $extrawhere = " AND  `$dbUsersTable`.`status` IN ('80') ";
        $query = "SELECT * FROM $dbUsersTable WHERE ( username = '".$loginname."' OR email = '".$loginname."' )  ". $extrawhere ." ". $sqllimit ;
        $result = @mysql_query($query);
        if (mysql_num_rows($result)) {
          $row = mysql_fetch_object ($result) ; 

          // security = recheck for password
          // loginpassword
          if ( $row->password == $loginpassword)
          {
            // generate a new password and reactivate the account
            $passx = trim(generatePassword());
            $password= md5($passx) ;
            $query2 = "UPDATE `".$dbUsersTable."` SET   
                    `password`='".$password."',
                    `status`='40',
                    `moddate` = '".$stamp."',
                    `expiredate` = '0'
                  WHERE ((`id` = '".$row->id."')) ";
            if ( mysql_query($query2) ) {
              if ( mysql_affected_rows()!=0)  {
                $item[0] = Array ('email'=> $row->email, 'password'=> $passx);  
                $sendemailflag=true; 
                $outCode=0 ; 
                $message = "account reactivated" ; 
                $specialdebugsession .="-- Reactivate action executed  -- "; 
                logfile('', "login=reactivate - account reactivated"); 
              } else {
                $success=false; 
                logfile('error', 'login=reactivate - Account not known or in bad status' );              
              } 
            }    
            else { 
              $success=false; 
              logfile('error', 'login=reactivate - SQL ERROR - '.mysql_error());             
            }
          } 
          // case of not matching password 
          else {
              $message =  "incorrect LOCAL  password  - please check" ; 
              $outCode=0; 
              $outCode2 = 99998;
              $action="submit"; // force action to display the correct screen
          }   

        } 
        else {
          $message =  "incorrect Login name" ; //no user found
          $outCode=0; 
          $outCode2 = 99999;
          $action="submit"; // force action to display the correct screen
        }

        // send email and save log 
        if ($sendemailflag) {
          $type="reactivateaccount";
          // function mySendEmail($emailRT, $what, $state, $dataobj, $useremail){
          $emailresult = mySendEmail($emailRoutingTable, $type,  "00", $item[0], $row->email);   

          // log file 
          // function log_event($action,$what, $whatid, $userid, $eventdesc, $severity){
          if ($ENABLE_ELEM_LOGS){
            log_event("reactivate","user", $row->id, $row->id, "40", 0);
          }
        }
      
    }

    if ($action == "logout") {
          // kill current session and all variables
          session_name("ZADSSESID");
          session_start(); 
          
          $_SESSION['user']= $loginname; 
          $_SESSION = array();  
          session_unset();
          
          $params = session_get_cookie_params();
          setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
          );
          
          session_destroy();
        
          
          // kill the cookies 
          $pastToKill = time() - 3600;
          setcookie($COOKIENAME, "", $pastToKill, '/');  
          setcookie($COOKIENAME."_REMEMBER_ME", "", $pastToKill , '/');


          // kill the Social OAUTH cookies
          foreach ( $_COOKIE as $key => $value )
          {
            if (strpos($key, $COOKIENAME."_OAUTH_") !== false) {
              setcookie($key, "", $pastToKill, '/');  
            }
          }

          $outCode=0 ; 
          $message = "Correctly logout and cookies deleted" ; 
          $success=true; 
          $specialdebugsession .="-- Logout action executed  -- "; 
    }
      
     // *** output the result ****/
     $what = "login";
     if ($outCode==0) $success=true;  // force success 
     if ((!$outCode2) && ($outcode==0)) $outCode2=0; 
     if ($action_pre=="init") {
      $actionsav=$action; 
      $action="init"; // set up rx action to prevent display of message
    }

    // recap of OUTCODES  : 
    //  99999 =  "incorrect Password  - please check" ; 
    //  99998 =  "incorrect Login name" ;
    //  99997 =  "account expired" ; 
    //  99990 =  "social login auth ok but need to register "

    // ---- general notifications --------------------------------------------
    if ($action=='init' || $action=='login'){
      

      // -- check passwords on admin accounts 
      $stub_password=  md5('admin') ;
      $array_bad_passwords = explode("\n", file_get_contents('vars/worst-passwords.txt'));
      $array_bad_passwords[]='admin'; 

      $wherePasswords = ''; 
      foreach ($array_bad_passwords as $key => $stub_password) {
        $stub_password=  md5($stub_password);
        $wherePasswords .= "OR `password` = '$stub_password' ";
      }
      $wherePasswords = substr($wherePasswords, 2);

      // $wherePasswords= " `password` = '$stub_password' "; 
      $queryCheckPassword= "SELECT id  FROM `$dbUsersTable` WHERE `usertype` > '1' AND ($wherePasswords)  "; 
      $resultCheckPassword = mysql_query($queryCheckPassword);


      if (mysql_num_rows($resultCheckPassword)) {
        $sysnotice='Security - You have some ('.mysql_num_rows($resultCheckPassword).') users (editors, admin) with a weak password';
        $notifArr[] = Array (
                    'page'=> 'admin',
                    'message'=>$sysnotice, 
                    'type'=>'danger'); 
      }  

      if(file_exists('install.php')) {
        $sysnotice='SYS - delete install.php';
        $notifArr[] = Array (
                    'page'=> 'admin',
                    'message'=>$sysnotice, 
                    'type'=>'danger'); 
      }

      // debug set
      if ($ENABLE_DEBUG_MODE && $DEBUG_LEVEL>3 ){
        $sysnotice='SYS - debug mode and level > 3 if active';
        $notifArr[] = Array (
                    'page'=> 'admin',
                    'message'=>$sysnotice, 
                    'type'=>'notice'); 
      }


      // check if subscription will expire 
      if ($TBYB_END_DATE){
            $tbdateAr=explode('-', $TBYB_END_DATE);
            $tbdateTime = mktime(0, 0, 0, $tbdateAr[1], $tbdateAr[2], $tbdateAr[0]);
            $not1_period = $tbdateTime - (7 * 24 * 60 * 60);
            $notifmessage ="";

            // if within the notificatuion period 
            if (( time() > $not1_period) && (time() < $tbdateTime)) {
              // send a will expire message
              $deltatime= $tbdateTime-time();
              $deltadays = ceil($deltatime / (60*60 *24));
              $sysnotice = _("This site will expire shortly in ").$deltadays." "._("day(s)") . " ($TBYB_END_DATE)";  
              $notifArr[] = Array (
                          'page'=> 'admin',
                          'message'=>$sysnotice, 
                          'type'=>'danger'); 
            }
      }
    }
    
     // $notifArr[] = Array (
     //                'page'=> '',
     //                'message'=>'coucou les amis message 2', 
     //                'type'=>'notice'); 

     $json = array(
              'success' => $success,
              'outcode' => $outCode2,
              'message' => $message,
              'action' => $action,
              'useraction'=>$useraction,
              'must_reload'=>$must_reload, 
              'what' => $what,
              'nav'=>$nav,
              'item0' => $outData,
              'relads' => $item2,
              'relusers' => $item2_users,
              'authtype'=>$authtype,
              'notifs'=>$notifArr
          );    

      //Z6.4.0 - output $me info if valid social login
      if ($outCode2==99990) {
        $json['social_me'] = $me; 
      }

      if ($ENABLE_TRACE_LOG) {
        logtime('end');
        $json['time_log']= $timing_trace; 
      }
  

     if ($debug_tmp==1){ // add debug info into the stream when working local
       $json["xdebug"]= array(
                'specialdebug'=>$specialdebug, 
                'querymyservices'=>$querymyservices,
                'queryCheckPassword'=>$queryCheckPassword,
                'array_bad_passwords'=>$array_bad_passwords,
                'query_social'=>$query_forcedcreate, 
                'access_token'=>$access_token, 
                'access_secret'=>$access_secret,
                //'outcode'=>$outCode,
                'sqldebug'=> $query,
                //'sqldebug2'=> $query2,
                //'sqlnbrowdebug'=>$totnbrow, 
                'specialdebugArr'=>$specialdebugArr, 
                'specialdebugsession'=> $specialdebugsession,
                'tcookiename'=>$tcookiename,
                //'msgtext'=>$msgtext, 
                'oAuthRes'=>$r,
                'allsession'=>$_SESSION,
                'session_id'=>session_id(), 
                'sessionset'=>$sessionset,
                'querynbads'=>$querynbads,
                'host'=>$_SERVER['HTTP_HOST'],
                'server_name'=>$_SERVER['SERVER_NAME'], 
                'social_me'=>$me
                );  
     }


    // ob_start('ob_gzhandler');
    // echo json_encode($json); 
    encode_json_and_send_with_compression($json); 
    
    // ----------------- SAVE TO LOG FILE ----------------------------
    if ($ENABLE_USER_LOGS && $success 
          && ($action!="logout") 
          && !($action=="init"  && !$sessionset) 
          && !($action=="init" && $sessionset) 
    ){

       $laction="auth";$lwhat = "user";
       if ($outCode2==0) { // no issue 
        $luserid=$outData[id];
        $ldesc = $message .'|'. $serverremoteaddr;
        $lseverity = 0; 
       } else {
        $luserid="";
        $ldesc = $message .'|'. $serverremoteaddr;
        $lseverity = 1; // severity set to 1 = medium
       }
      log_event($laction,$lwhat, $row->id, $luserid, $ldesc, $lseverity);
    
    }
}

  function delete_all_cookies(){

    global $specialdebugsession;
    global $COOKIENAME;

    $specialdebugsession .=" -- deleting all cookies - ";

    // session_name("ZADSSESID");
    // session_start(); 
    session_unset();
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
      $params["path"], $params["domain"],
      $params["secure"], $params["httponly"]
    );
    session_destroy();

    // kill the cookies 
    setcookie($COOKIENAME, "", time()-3600, '/');
    setcookie($COOKIENAME."_REMEMBER_ME" , "", time()-3600, '/');

  }

// ############# SERVLET FOR change password  ###########################
if (isset($_POST["pwdctrl"]) ) {
  $success=false;
  $message=""; 
  $action=$_POST["pwdctrl"]; 
  $what='pwdctrl';

  if (!$LOSTPASSWORD_LINK) {$actionsav="nope"; $message="action forebidden : wrong settings"; }else $actionsav=$action;


  // possible ACTIONS 
  // sendemail = send the email with the reset link 
  // checktoken = check if the token is valid (exist and not expired)
  // updatepassword = change the password on this user 

  // ---- send email with encrypted code 
  if ($actionsav=="sendemail") {
    $email = trim(secure_var($_POST["email"])) ;  // SECURITY - strip undesired text
    if (!$email) { 
        $message="email is empty";
    } else {
      $query =  "SELECT email,id FROM $dbUsersTable WHERE $dbUsersTable.email = '$email'"; 
      $result = @mysql_query($query);
      if ($result) { 
        if (mysql_num_rows($result)) {
            $row = mysql_fetch_object ($result) ;
            $temail =  $row->email; 
            $tuserid =  $row->id; 

            /// check if activation is pending /////
            $tm=time() - 86400; // Time in last 24 hours
            $stamp= date( 'Y-m-d H:i:s', $tm);
            $query =  "SELECT userid FROM $dbKeysTable WHERE userid = '$tuserid' AND time > '$stamp' AND status='pending'";
            $query2 =   $query;
            $result = mysql_query($query);
            if ($result) { 
              if (mysql_num_rows($result)){
                // email already sent  
                $message="Your password activation Key is already posted to your email address, please check your Email address & Junk mail folder.";
              }else{
                // nothing found so we can create the token ! 
                $key=random_generator(10);
                $key=md5($key);
                $tm=time();
                $stamp= date( 'Y-m-d H:i:s', $tm);
                $query =  "INSERT INTO $dbKeysTable (`userid`, `key`,`time`,`status`) VALUES ('$tuserid','$key','$stamp','pending')"; 
                $result = mysql_query($query);
                if ($result) { 
                    // send the email 
                    $site_url="passwordreset=$key&u=$tuserid";

                    // send the email
                    $item[0] = Array ('email'=> $email, 'reseturl' =>  $site_url);
                    $emailresult = mySendEmail($emailRoutingTable, 'lost-link',  "00", $item[0], $email);   

                    $success=true; // finaly we made it ! 
                    $message="We sent you an email to reset your password.";
                } else {
                  logfile('error', '[pwdctrl]'.mysql_error());
                  $message='[pwdctrl]'.mysql_error(); 
                }
              }
            } else {
                logfile('error', '[pwdctrl]'.mysql_error());
                $message='[pwdctrl]'.mysql_error(); 
              }
        } else {
          // not email found with this  !
          $message="Your email address is not correct"; 
        }
      } else {
        logfile('error', '[pwdctrl]'.mysql_error());
        $message='[pwdctrl]'.mysql_error(); 
      }
    }
  } // ---  end action send email 


  // --- checktoken code 
  if ($actionsav=="checktoken") {
    $k=$_POST['t'];
    $userid=$_POST['u'];
    $tm=time()-86400; // Durationg within which the key is valid is 86400 sec. 
    $stamp= date( 'Y-m-d H:i:s', $tm);

    $query =  "SELECT userid  FROM $dbKeysTable WHERE `key`='$k' and userid='$userid' and `time` > '$stamp' and `status`='pending'";
    $result = @mysql_query($query);
    if ($result) { 
       if (mysql_num_rows($result)) {
          $success= true;
          $message="Correct activation conditions";
          session_start(); 
          $_SESSION['userid'] = $userid;  // save it 
       } else $message="Wrong activation conditions";
    } else {
      logfile('error', '[pwdctrl]'.mysql_error());
      $message='[pwdctrl]'.mysql_error();
    }
  }
  // ---  end checktoken  


  // --- updatepassword code 
  if ($actionsav=="updatepassword") {

    $k=$_POST['t'];
    $password= trim(secure_var($_POST["password"])) ;
    $password2= trim(secure_var($_POST["confirmpassword"])) ;

    // security for the usersid 
    $postuserid=$_POST['userid'];
    session_start(); 
    $userid=$_SESSION['user_id'];
    if ($postuserid != $userid) {logfile('alert', '[pwdctrl] - possible hacking userid different from session'); die; }

    $tm=time()-86400; // Durationg within which the key is valid is 86400 sec. 
    $stamp= date( 'Y-m-d H:i:s', $tm);
    $query =  "SELECT userid  FROM $dbKeysTable WHERE `key`='$k' and userid='$userid' and time > '$stamp' and status='pending'";
    $result = @mysql_query($query);
    if ($result) { 
       if (mysql_num_rows($result)) {
          
          if ( $password <> $password2 ){
            $message="Both passwords are not matching";
          }else {
            $password = md5($password) ; 
            $stamp= date( 'Y-m-d H:i:s', time());
            $query =  "UPDATE $dbUsersTable SET `password`='$password', `moddate`= '$stamp' WHERE `id`='$userid'"; 
            $result = @mysql_query($query);
            $query2 = $query;

            if ($result) {
              $success=true; 
              $message="Password updated successfully.";

              // delete the token 
              $query = "DELETE FROM `$dbKeysTable` WHERE `key`='$k' ";
              $result = @mysql_query($query);

            } else{
              logfile('error', '[pwdctrl]'.mysql_error());
              $message="Password update problem at final stage.";
            }
          }
       } else $message="Wrong activation conditions for updatepassword";
    } else logfile('error', '[pwdctrl]'.mysql_error());
  }
  // ---  end updatepassword  

  $json = array(
                'action' => $action,
                'success' => $success,
                'message' => $message,
                'userid'=>$userid,
                'what'=>$what, 
                'email'=>$temail, 
                'token'=>$k,
                'nav'=>$nav,
                'data'=>$data_out,
                'data_in'=>$data_in,
            );

   if ($debug_tmp==1){ // add debug info into the stream when working local
       $json["xdebug"]= array(
                'lastquery'=>$query,
                'query2'=>$query2
                );  
     }
  echo json_encode($json);

}

// ############# SERVLET FOR SENDEMAIL ###########################
if (isset($_POST["sendmail"]) ) {

  $action = secure_var($_POST["action"]);       // SECURED
  $type = secure_var($_POST["type"]);           // SECURED
  $email = secure_var($_POST["email"]);         // SECURED
  $emailtitle = $_POST["emailtitle"] ;
  $emaildesc = secure_var($_POST["emaildesc"]); // SECURED
  $emaildesc =  $_POST["emaildesc"]; // SECURED
  $userenv = secure_var($_POST["userenv"]); // SECURED
 
  $what = secure_var($_POST["what"]) ;          // SECURED
  $elemid = $_POST["elemid"]+0 ;                // SECURITY - convert to int
  
  $success=true; 
  $message="Message sucessufully sent !";
  $sendemailflag=false; 
  

  // extended info 
  $firstname = secure_var($_POST["firstname"]);       // SECURED
  $lastname = secure_var($_POST["lastname"]);           // SECURED
  $phone = secure_var($_POST["phone"]);           // SECURED
  $procpny = secure_var($_POST["procpny"]);           // SECURED
  $contactreason = secure_var($_POST["contactreason"]);           // SECURED

  $stamp= date( 'Y-m-d H:i:s', time());
  
  // case of LOST email , create a new one, save it SQL and send it
  if ($type=="lost") {
    $passx = trim(generatePassword());
    $password= md5($passx) ;
    $query = "UPDATE `".$dbUsersTable."` SET   
            `password`='".$password."'
            WHERE ((`email` = '".$email."')) ";
    if ( mysql_query($query) ) {
      if ( mysql_affected_rows()!=0)  {
        $item[0] = Array ('email'=> $email, 'password'=> $passx);  
        $sendemailflag=true; 
      } else {$success=false; $message = 'email address not known';} 
    }    
    else { $success=false; $message = 'invalid request : ' . mysql_error();  }  
  } 
  // modified Z6.2.0
  else if ($type=="support" || $type=="feedback" ){
        $item[0] = Array (
            'emailtitle'=> $emailtitle, 
            'emaildesc'=> $emaildesc, 
            'emailfrom'=> $email,
            'emailstamp'=> $stamp,
            'firstname'=> $firstname,
            'lastname'=> $lastname,
            'phone'=> $phone,
            'procpny'=> $procpny,
            'contactreason'=> $contactreason,
            'userenv'=> $userenv
         );
        $sendemailflag=true; 
  }
  else if (($type=="remind") || ($type=="abuse")) {
        if ($what=="ad") $dbThisTable = $dbItemsTable; 
        if ($what=="user") $dbThisTable = $dbUsersTable; 
        
        $filterx="WHERE `id`='".$elemid."'"; 
        $queryx = "SELECT * FROM `$dbThisTable` " .$filterx; 
        $resultx = mysql_query($queryx);
        $rowx = mysql_fetch_object($resultx);
        
        $item[0] = Array ('title'=> $rowx->title ,'id'=> $rowx->id ,  'emailtitle'=> $emailtitle, 'emaildesc'=> $emaildesc, 'id'=> $elemid, 'emailfrom'=> $email,'emailstamp'=> $stamp);  
        $sendemailflag=true; 
  }
  else if (($type=="contact")|| ($type=="contactuser")){
        if ($what=="ad") $dbThisTable = $dbItemsTable; 
        if ($what=="user") $dbThisTable = $dbUsersTable; 
        
        $filterx="WHERE `id`='".$elemid."'"; 
        $queryx = "SELECT * FROM `$dbThisTable` " .$filterx; 
        $resultx = mysql_query($queryx);
        $rowx = mysql_fetch_object($resultx);
        if ($debug_tmp==1){ fwrite($debugfile,$queryx);}
        
        if  ($what=="ad"){ // if adn get the user details.
          // get details on user owner. 
          $dbThisTable= $dbUsersTable; // force to get user table.
          $filteru="WHERE `id`='".$rowx->userid."'"; 
          $queryu = "SELECT * FROM `$dbThisTable` " .$filteru; 
          $resultu = mysql_query($queryu);
          $rowu = mysql_fetch_object($resultu);
          if ($debug_tmp==1){ fwrite($debugfile,$queryu);}
          // $item[0] = Array ('title'=> $rowx->title ,'id'=> $rowx->id ,  'emailtitle'=> $emailtitle, 'emaildesc'=> $emaildesc, 'id'=> $elemid, 'emailfrom'=> $email,'emailstamp'=> $stamp, 'emailto'=> $rowu->email);  
        

          $item[0] = Array (
              'title'=> $rowx->title ,'id'=> $rowx->id ,  
              'emailtitle'=> $emailtitle, 'emaildesc'=> $emaildesc, 
              'id'=> $elemid, 
              'emailfrom'=> $email, 'firstname'=>$firstname,'lastname'=>$lastname, 'phone'=>$phone, 'procpny'=>$procpny, 
              'emailstamp'=> $stamp, 
              'emailto'=> $rowu->email
          );  

        }
        
        if  ($what=="user"){ // if adn get the user details.
          $item[0] = Array ('title'=> $rowx->lastname ,'id'=> $rowx->id ,  'emailtitle'=> $emailtitle, 'emaildesc'=> $emaildesc, 'id'=> $elemid, 'emailfrom'=> $email,'emailstamp'=> $stamp, 'emailto'=> $rowx->email);  
        }

        $sendemailflag=true; 
  }
  
  // send the email using the emailrouting table. 
  if ($sendemailflag) $emailresult = mySendEmail($emailRoutingTable, $type,  "00", $item[0], $email);   

  $json = array(
                'success' => $success,
                'outcode' => $outCode2,
                'message' => $message,
                'action' => $action,
                'what' => $what,
                'nav'=>$nav,
                'item0' => $outData
            );
            
    if ($debug_tmp==1){ // add debug info into the stream when working local
       $json["xdebug"]= array(
                'sqldebug'=> $query,
                'sqldebug2'=> $queryx
                );  
     }
  
  echo json_encode($json);
}

// ############# SERVLET FOR SPECIAL ACTIONS ###########################
if (isset($_POST["specialaction"]) ) {

  $success=true;
  $message=""; 
  $action=$_POST["specialaction"]; 
  $nav="admin"; 

  check_userRights($action); // just to unitialize the curuser_is_admin
  if (!$curuser_is_admin) { $success=false; $message=  "Not authorized";} 

  if ($success) {
    if  ($action =="cleardebugfile") {
        $debugfile = fopen($debugoutputfile,"w"); 
        if(!$debugfile) { $success=false; $message=  "Error writing to the debug file";}
        else {
          fwrite($debugfile,'file cleaned upon request<br>');
          $success=true; $message=  "File cleaned successfully";
        }
        fclose($debugfile);
    }

    if  ($action =="forcesitemapgeneration") {
        require_once ("sitemap_lib.php");
        $debug_trail = generate_sitemap(); // this generate and publish the sitemap to all crawlers if option is set
        $success=true; $message=  "Sitemap generated successfully";
    }

    // disable the ROBOT.TXT file content
    if  ($action =="disablerobots" || $action =="enablerobots") {
        require_once ("sitemap_lib.php");
        $debug_trail = update_robot($action); // this generate and publish the sitemap to all crawlers if option is set
        $taction= ($action =="disablerobots") ? "disabled" : "enabled"; 
        $success=true; $message=  "ROBOTS.TXT file $taction";
    }

     // enable CACHING on certain directories 
    if  ($action =="enablecache" || $action =="disablecache") {
        require_once ("sitemap_lib.php");
        $debug_trail = update_cache($action); // this generate and publish the sitemap to all crawlers if option is set
        $taction= ($action =="disablecache") ? "disabled" : "enabled"; 
        $success=true; $message=  "CACHE $taction";
    }


    // RESET all likes
    if  ($action =="resetalllikes") {
        if ($_POST["what"]=="ad") $dbThisTable=$dbItemsTable ; 
        else if ($_POST["what"]=="user") $dbThisTable=$dbUsersTable ;
        else $success=false; 

        if ($success) {
          $query = "UPDATE `".$dbThisTable."` SET `likes` = 0 ";
          $result = @mysql_query($query);
          if (!$result) { $success=false; $message=  "Error writing to the debug file";  
                          $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
                          logfile('error', $sqlerror); 
                        }
          else {$success=true;  $message=  "all likes cleaned successfully";}
        }
    } // end if resetalllikes

    if  ($action =="testtmp2") {
      $SECRETPASS="b3bcffd15748055a"; 
      // $success=false; 
      // $message=  "not yet implemented";
      $callurl = $DOMAIN_FQDN.'/phpsvr/tmp2.php'; 
      $ch = curl_init($callurl);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_POST, 1);
      $fpost="testtmp2=watermark&secret=".$SECRETPASS; 
      curl_setopt($ch, CURLOPT_POSTFIELDS,$fpost);
      $data_in = curl_exec($ch);
      curl_close($ch);

      // process the received datas
      // $data = preg_replace ('/(?<!")(?<!\w)(\w+)(?!")(?!\w)/u', '"$1"', $data); 
      $data_out = json_decode($data_in);

    }

    if ($action=="forcedcronhourly" || $action=="forcedcrondaily"  || $action=="forcedcronweekly" ){

      if ($action=="forcedcrondaily" ) $callstr = $DOMAIN_FQDN.'phpsvr/cron/zadsdailyscript.php'; 
      if ($action=="forcedcronhourly" ) $callstr = $DOMAIN_FQDN.'phpsvr/cron/zadshourlyscript.php'; 
      if ($action=="forcedcronweekly" ) $callstr = $DOMAIN_FQDN.'phpsvr/cron/zadssunscript.php'; 

      logfile('debug', "{forcedcron} : calling $callstr ..."); 

      $ch = curl_init($callstr);      
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      $ref_url = $DOMAIN_FQDN;    
      curl_setopt($ch, CURLOPT_REFERER, $ref_url);
      $apiresponse = curl_exec($ch);
      curl_close($ch);
      $success=true; $message=  "Con excecuted successfully";

      logfile('debug', "{forcedcron} : ... response = ". $apiresponse); 
    }

     // install file management 
     if ($action=="enableinstallfile" || $action=="disableinstallfile"   ){
        if ($action=="enableinstallfile") $st = rename("install.php.bak", "install.php");
        if ($action=="disableinstallfile") $st = rename("install.php", "install.php.bak");
        $success=$st; 
        $message=  "install enable/disable excecuted, please refresh browser.";
     }

     // token generation
     if ($action=="generatetoken"){
      $xwhat=$_POST["what"]; 
      $token  = bin2hex(openssl_random_pseudo_bytes(16)); 
      $data_out =$token; 
      $data_in=$xwhat; 
     }


  } // end if ACL 

  $what=$action; 
  $action="specialaction"; 
 
  $json = array(
                'action' => $action,
                'success' => $success,
                'message' => $message,
                'what'=>$what, 
                'nav'=>$nav,
                'data'=>$data_out,
                'data_in'=>$data_in,
                'file'=>$debugoutputfile
            );

  if ($debug_tmp==1){ // add debug info into the stream when working local
       $json["xdebug"]= array(
                'debugtrail'=> $debug_trail,
                );  
     }
  echo json_encode($json);
}

// ############# SERVLET FOR BATCH / CRON ###########################
if (isset($_POST["batch"]) ) {
  $batch = $_POST["batch"] ;
  $msg=""; 
  $outdata=""; $outtext=""; $outtextda=''; // DA=Daily Actionsd
  
  $sapi = php_sapi_name(); // identify how this is called
  $rip = $_SERVER['REMOTE_ADDR']; 
  $sip=$_SERVER['SERVER_ADDR'];
  logfile('debug', "[core1] : CRON call  : $batch | from $sapi | with remote-ip  = $rip | with serverip = $sip"); 

  // cron job protection 
  // $token = bin2hex(openssl_random_pseudo_bytes(16));


  // --------------- HOURLY BATCH  -------------------------------------------------------
  // new = hourly batch to implement the "move up" based on date 
  if ($batch=="hourly"){

    // calculate all the variables of time 
    $origPub = time() - ($PUBLISHING_DURATION * 24 * 60 * 60);
    $origDel2 = time() - ( ($PUBLISHING_DURATION+$delteafter) * 24 * 60 * 60 );

    $stamp2willexpire = date( 'Y-m-d H:i:s', $origPub+($notbefore*24*60*60));
    $stamp2expired = date( 'Y-m-d H:i:s', $origPub);
    $stamp2delete = date( 'Y-m-d H:i:s', $origDel);
    $stampcrondelay=  date( 'Y-m-d H:i:s', (time() - 24 * 60 * 60)); // current time minus 1 DAY .


    $outtext .= '<h3 style="font-size:16px;font-weight:bold; padding: 0; margin: 5px 0 2px;">'._("Hourly  data processing").'</h3>';
    $outtext .= '<div style="border-top: 1px solid #069; line-height:3px;margin:4px 0 4px;">&nbsp;</div>';

    $sqlerror=''; 
  
    // ------ part 1  -- check for EXPIRED ADS  ----------------------------------
    if ($PUBLISHING_DURATION!='') {
      $dbThisTable = $dbItemsTable;
      $filter="  WHERE `$dbThisTable`.`priority` != 'PERM' AND `$dbThisTable`.`status` IN ('40')  "; 
      $filter.="  AND `$dbThisTable`.`firstpublisheddate` < '".$stamp2willexpire."'";
      $filter.="  AND `$dbThisTable`.`crondate`<= '".$stampcrondelay."'";

      $sql_sort="";  
      $querywillexpire = "SELECT `$dbThisTable`.*, `$dbUsersTable`.`firstname`, `$dbUsersTable`.`lastname`, `$dbUsersTable`.`email` AS `uemail`  FROM `$dbThisTable` LEFT OUTER JOIN `$dbUsersTable` ON `$dbThisTable`.`userid`= `$dbUsersTable`.`id`  ".$filter."  ". $sql_sort ; 
      $resultwillexpireads = @mysql_query($querywillexpire);

      logfile('', $querywillexpire); 
      
      if (!$resultwillexpireads) $sqlerror .=  "Could not successfully run query from DB: " . mysql_error(). "--".$querywillexpire;
      else {      
        $cntx=0;
        while ($row = mysql_fetch_object($resultwillexpireads)) { 

          logfile('', "found".$row->id); 

          // take each one and change the status and notify that to user
          $query = "UPDATE `".$dbItemsTable."` SET   
              `logs` = '".$stamp."', 
              `crondate` = '".$stamp."', 
              `status`='45'
              WHERE ((`id` = '".$row->id."')) ";
          $result = @mysql_query($query);       
          $cntx+=1;
          
          // ----------------- SAVE TO LOG FILE ----------------------------
          if ($result && ($ENABLE_ELEM_LOGS)){
            $laction="update";$lwhat = "ad";$lstatus = "45";$luserid=0;
            log_event($laction,$lwhat, $row->id, $luserid, $lstatus, 0);
          }
          
          // notifiy user by email
          $xitem = Array (
                              'title'=> stripslashes($row->title), 
                              'desc' => stripslashes($row->description),
                              'catid'=> $row->catid,
                              'type'=> $row->type, 
                              'priority'=> $row->priority,
                              'price'=> $row->price,
                              'id'=> $row->id,
                              'status'=> $row->status,
                              'logs'=> $row->logs,
                              'hits'=> $row->hits,
                              'userid'=> $row->userid,
                              'username'=> stripslashes($row->username),
                              'firstname'=>$row->firstname,
                              'lastname'=>$row->lastname,
                              'uemail'=>stripslashes($row->uemail),
                              'phone'=> $row->phone,
                              'email'=> stripslashes($row->email),
                              'location'=> stripslashes($row->location),
                              'moddate'=> $row->moddate,
                              'moddatestamp'=>  strtotime( $row->moddate)*1000, 
                              'imgpath'=> $dest_path_from_root,
                              'imgurl'=> $row->imgname
                              );
          mySendEmail($emailRoutingTable, 'ad', '45', $xitem, $row->uemail);  
        }
        if ($cntx>0) $outtextda .= '<br>'._("AD FORCED TO WILLEXPIRED =").$cntx;  // log this and report it.
      }
    }



    // ------ part 1B  -- check for FORCED EXPIRE AD  ----------------------------------
    if ($AD_EXPIRATION_FOR!='none') {

      $stampnow = $stamp; 
      $dbThisTable = $dbItemsTable;
      $filter='';
      $filter.="  WHERE `$dbThisTable`.`priority` != 'PERM' AND `$dbThisTable`.`status` IN ('40')  "; 
      $filter.="  AND `$dbThisTable`.`expiredate` < '".$stampnow."' ";
      $filter.="  AND `$dbThisTable`.`expiredate` != '0000-00-00 00:00:00' "; // remove the empty value
      $filter.="  AND `$dbThisTable`.`crondate`<= '".$stampcrondelay."' ";

      $sql_sort="";  
      $queryforcedexpire = "SELECT `$dbThisTable`.*, `$dbUsersTable`.`firstname`, `$dbUsersTable`.`lastname`, `$dbUsersTable`.`email` AS `uemail`  FROM `$dbThisTable` LEFT OUTER JOIN `$dbUsersTable` ON `$dbThisTable`.`userid`= `$dbUsersTable`.`id`  ".$filter."  ". $sql_sort ; 
      $resultforcedexpiredads = @mysql_query($queryforcedexpire);

      logfile('', $queryforcedexpire); 
      
      if (!$resultforcedexpiredads) {
        $sqlerror .=  "Could not successfully run query from DB: " . mysql_error(). "--".$queryforcedexpire;
        logfile('error', $sqlerror); 
      }
      else {      
        $cntx=0;
        while ($row = mysql_fetch_object($resultforcedexpiredads)) { 

          logfile('', "found".$row->id); 

          // take each one and change the status and notify that to user
          $query = "UPDATE `".$dbItemsTable."` SET   
              `logs` = '".$stamp."', 
              `crondate` = '".$stamp."', 
              `status`='80'
              WHERE ((`id` = '".$row->id."')) ";
          $result = @mysql_query($query);       
          $cntx+=1;
          
          // ----------------- SAVE TO LOG FILE ----------------------------
          if ($result && ($ENABLE_ELEM_LOGS)){
            $laction="update";$lwhat = "ad";$lstatus = "80";$luserid=0;
            log_event($laction,$lwhat, $row->id, $luserid, $lstatus, 0);
          }
          
          // notifiy user by email
          $xitem = Array (
                              'title'=> stripslashes($row->title), 
                              'desc' => stripslashes($row->description),
                              'catid'=> $row->catid,
                              'type'=> $row->type, 
                              'priority'=> $row->priority,
                              'price'=> $row->price,
                              'id'=> $row->id,
                              'status'=> $row->status,
                              'logs'=> $row->logs,
                              'hits'=> $row->hits,
                              'userid'=> $row->userid,
                              'username'=> stripslashes($row->username),
                              'firstname'=>$row->firstname,
                              'lastname'=>$row->lastname,
                              'uemail'=>stripslashes($row->uemail),
                              'phone'=> $row->phone,
                              'email'=> stripslashes($row->email),
                              'location'=> stripslashes($row->location),
                              'moddate'=> $row->moddate,
                              'moddatestamp'=>  strtotime( $row->moddate)*1000, 
                              'imgpath'=> $dest_path_from_root,
                              'imgurl'=> $row->imgname
                              );
          mySendEmail($emailRoutingTable, 'ad', '80', $xitem, $row->uemail);  
        }
        if ($cntx>0) $outtextda .= '<br>'._("AD FORCEDEXPIRED  =").$cntx;  // log this and report it.
      }
    }


    // ------ part 2  -- check for "WILLEXPIRE" ADDS FOR MORE Than 7 DAYS  --/
    $filter="  WHERE `$dbItemsTable`.`priority` != 'PERM' AND `$dbItemsTable`.`status` IN ('45')  AND `$dbItemsTable`.`firstpublisheddate` < '".$stamp2expired."'";
    $filter.="  AND `$dbItemsTable`.`crondate`<= '".$stampcrondelay."'";
    $sql_sort="";  
    $queryisexpired = "SELECT `$dbItemsTable`.*, `$dbUsersTable`.`firstname`, `$dbUsersTable`.`lastname`, `$dbUsersTable`.`email` AS `uemail`  FROM `$dbItemsTable` LEFT OUTER JOIN `$dbUsersTable` ON `$dbItemsTable`.`userid`= `$dbUsersTable`.`id`  ".$filter."  ". $sql_sort ; 
    $resultisexpired = @mysql_query($queryisexpired); 

    logfile('', $queryisexpired); 
  

    if (!$resultisexpired) $sqlerror .=  "Could not successfully run query from DB: " . mysql_error(). "--".$queryisexpired;
    else {     
      $cntx=0;
      while ($row = mysql_fetch_object($resultisexpired)) { 
        // take each one and change the status and notify that to user
        $query = "UPDATE `".$dbItemsTable."` SET   
            `moddate` = '".$stamp."',
            `crondate` = '".$stamp."', 
            `priority` = '',
            `urgent` = '',
            `paidoptions` = '',
            `status`='80'
            WHERE ((`id` = '".$row->id."')) ";
        $result = @mysql_query($query);     
        $cntx+=1;
        if ($query && ($ENABLE_ELEM_LOGS)){
         $laction="update";$lwhat = "ad";$lstatus = "80";$luserid=0;
         log_event($laction,$lwhat, $row->id, $luserid, $lstatus, 0);
        }
        
        // notifiy user by email
        $xitem = Array (
                            'title'=> stripslashes($row->title), 
                            'desc' => stripslashes($row->description),
                            'catid'=> $row->catid,
                            'type'=> $row->type, 
                            'priority'=> $row->priority,
                            'price'=> $row->price,
                            'id'=> $row->id,
                            'status'=> $row->status,
                            'logs'=> $row->logs,
                            'hits'=> $row->hits,
                            'userid'=> $row->userid,
                            'username'=> stripslashes($row->username),
                            'phone'=> $row->phone,
                            'email'=> stripslashes($row->email),
                            'location'=> stripslashes($row->location),
                            'moddate'=> $stamp,
                            'moddatestamp'=>  strtotime($stamp)*1000, 
                            'imgpath'=> $dest_path_from_root,
                            'imgurl'=> $row->imgname
                            );
        mySendEmail($emailRoutingTable, 'ad', '80', $xitem, $row->uemail);  
      } // end while 
      if ($cntx>0) $outtextda .= '<br>'._("FORCED TO EXPIRED =").$cntx; 
      //$outtext .= '<br>'.$queryisexpired; 
    }


    // ------ part 3  --  DELETE  old items  ---/
    $filter="  WHERE `$dbItemsTable`.`priority` != 'PERM' AND `$dbItemsTable`.`status` IN ('80','17')  AND `$dbItemsTable`.`firstpublisheddate` < '".$stamp2delete."'";
    $filter.="  AND `$dbItemsTable`.`crondate`<= '".$stampcrondelay."'";
    $sql_sort="";  
    $querytodelete = "SELECT `$dbItemsTable`.*, `$dbUsersTable`.`firstname`, `$dbUsersTable`.`lastname`, `$dbUsersTable`.`email` AS `uemail`  FROM `$dbItemsTable` LEFT OUTER JOIN `$dbUsersTable` ON `$dbItemsTable`.`userid`= `$dbUsersTable`.`id`  ".$filter."  ". $sql_sort ; 
    $resulttodelete = @mysql_query($querytodelete); 

    logfile('debug', $querytodelete); 
       
    $cntx=0;
    while ($row = mysql_fetch_object($resulttodelete)) { 
      // take each one and change the status and notify that to user
        $imgname = $row->imgname;
        if ($imgname && ($imgname!="")){
          foreach(explode(";",$imgname) as $imgnameItem) { 
              $successx = unlink($dest_path."".$imgnameItem);  // delete main file 
              $successx = unlink($dest_path."tn_".$imgnameItem); // delete tn file
          }
        } 

        // make the delete action 
        delete_files("ad", $row->id);
        sql_delete_item("ad", $row->id); // delete all from an item incuding logs and associated pictures
        
        $cntx+=1;
    } // end while
    if ($cntx>0) $outtextda .= '<br>'._("DEFINITIVELY DELETED =").$cntx; 

    
    // ------ part 4  --  delete DRAFT ITEMS when in preview mode  ---/
    if ($AD_PREVIEW_BEFORE) {
      $filter="  WHERE `$dbItemsTable`.`priority` != 'PERM' AND `$dbItemsTable`.`status` IN ('10','15')  AND `$dbItemsTable`.`moddate` < '".$stamppastdraft."'";
      $sql_sort="";  
      $querytodelete = "SELECT `$dbItemsTable`.*, `$dbUsersTable`.`firstname`, `$dbUsersTable`.`lastname`, `$dbUsersTable`.`email` AS `uemail`  FROM `$dbItemsTable` LEFT OUTER JOIN `$dbUsersTable` ON `$dbItemsTable`.`userid`= `$dbUsersTable`.`id`  ".$filter."  ". $sql_sort ; 
      $resulttodelete = @mysql_query($querytodelete);  

      logfile('', $querytodelete); 

      $cntx=0;
      while ($row = mysql_fetch_object($resulttodelete)) { 
        // take each one and change the status and notify that to user
          $imgname = $row->imgname;
          if ($imgname && ($imgname!="")){
            foreach(explode(";",$imgname) as $imgnameItem) { 
                $successx = unlink($dest_path."".$imgnameItem);  // delete main file 
                $successx = unlink($dest_path."tn_".$imgnameItem); // delete tn file
            }
          }    
          // make the delete action 
          delete_files("ad", $row->id);
          sql_delete_item("ad", $row->id); // delete all from an item incuding logs and associated pictures
          
          $cntx+=1;
      }
      if ($cntx>0) $outtextda .= '<br>'._("DRAFT (PREVIEW) ELEMENTS DELETED =").$cntx; 
      //$outtext .= '<br>'.$querytodelete; 
    } // end AD PREVIEW

    // ------ part 5  --  push ads of they have the paid options and are already published  !   ---/
      $filter="  WHERE `$dbItemsTable`.`paidoptions` != '' AND `$dbItemsTable`.`status` IN ('40','45') " ;
      $filter.="  AND `$dbItemsTable`.`crondate`<= '".$stampcrondelay."'";
      $sql_sort="";  
      $querypaidoptions = "SELECT `$dbItemsTable`.*, `$dbUsersTable`.`firstname`, `$dbUsersTable`.`lastname`, `$dbUsersTable`.`email` AS `uemail`  FROM `$dbItemsTable` LEFT OUTER JOIN `$dbUsersTable` ON `$dbItemsTable`.`userid`= `$dbUsersTable`.`id`  ".$filter."  ". $sql_sort ; 
      
      logfile('', '- checking PAIOPTIONS'. $querypaidoptions); 


      $resultpaidoptions = @mysql_query($querypaidoptions);  
      //$outtext .=   $querypaidoptions ;  
      $cntx_ptu=0;$cntx_ptg=0;$cntx_ptt=0;
      $thisstamp = time(); 
       //$outtext .= "<br>this stamp =$thisstamp";   

      while ($row = mysql_fetch_object($resultpaidoptions)) { 
          // decode the paid options 
          logfile('', '-- found 1 item ('.$row->id. ') with option= '.$row->paidoptions); 
          $rdata = parseStrToArr($row->paidoptions); 
          

          foreach ($rdata as $paidoption => $pvalue) {
             $query=''; 

            if (
                 ( $paidoption=="pushtotop7days") 
              || ( $paidoption=="pushtotop15days") 
              || ( $paidoption=="pushtotop30days")
              || ( $paidoption=="pushtotoponceaweek")  
              || ( $paidoption=="putontopgallery7days") 
              || ( $paidoption=="putontopgallery15days") 
              || ( $paidoption=="putontopgallery30days") 
              || ( $paidoption=="urgentad7days") 
              || ( $paidoption=="urgentad15days") 
              || ( $paidoption=="urgentad30days") 
              )
            {

              logfile('', '--- decoding key='.$paidoption. ' | val= '.$pvalue.' |stamp='.$thisstamp); 

                // case of TOP GALLERIE 
              if (strrpos($paidoption, "putontopgallery")!== false)  { 
                 logfile('', '---- found putontopgallery ! ' ); 
                  $priorityvalue = ($pvalue >= $thisstamp) ? "TOP" : ""; 
                  if ($priorityvalue!='') $cntx_ptg +=1; 
                  $query = "UPDATE `".$dbItemsTable."` SET   
                    `priority` = 'TOP',
                    `crondate` = '".$stamp."'
                    WHERE ((`id` = '".$row->id."')) ";
                } else if (strrpos($paidoption, "urgentad")!== false)  {
                   logfile('', '---- found urgentad ! ' ); 
                   $urgentvalue = ($pvalue >= $thisstamp) ? "yes" : ""; 
                   if ($urgentvalue!='') $cntx_ptu +=1;
                   $query = "UPDATE `".$dbItemsTable."` SET   
                    `urgent` = '".$urgentvalue."',
                    `crondate` = '".$stamp."' 
                    WHERE ((`id` = '".$row->id."')) ";
                }
                else if (strrpos($paidoption, "pushtotop")!== false)  {
                  logfile('', '---- found pushtotop ! ' ); 
                  // case of pushtotop --> just change the publication date 

                  $doitnow=false;
                  if ($paidoption=="pushtotoponceaweek"){
                    // detect same day of the week
                    if (are_dates_samedayoftheweek($row->firstpublisheddate)) $doitnow=true; 
                  } else if ($pvalue > $thisstamp){$doitnow=true; }

                  if ($doitnow){ 
                    $cntx_ptt +=1;
                    $query = "UPDATE `".$dbItemsTable."` SET   
                      `moddate` = '".$stamp."',
                      `crondate` = '".$stamp."'
                      WHERE ((`id` = '".$row->id."')) ";
                   }
                }

                if ($query) {
                  $result = @mysql_query($query); 
                  if (!$result) {
                    $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
                    logfile('error', $sqlerror); 
                  }
                  else {
                    logfile('', "making query = ".$query); 

                    if (($ENABLE_ELEM_LOGS)){
                      $logaction ='';
                      if (strrpos($paidoption, "putontopgallery") !== false) $logaction = "putontopgallery"; 
                      if (strrpos($paidoption, "urgentad")!== false) $logaction = "urgentad"; 
                      if (strrpos($paidoption, "pushtotop")!== false) $logaction = "pushtotop"; 
                      $laction="update";$lwhat = "ad";$lstatus = "40|".$logaction;$luserid=0;
                      log_event($laction,$lwhat, $row->id, $luserid, $lstatus, 0);
                    }  
                    if ($EMAIL_ON_PUSH_TOP_GAL){
                      $toto=1; // will code it later 
                    }
                  }
                } 

              } // end IF 
          } // end for each 
      } // end while 
      if ($cntx_ptt>0) $outtextda .= '<br>'._("PAID ELEMENTS PUSHED TO TOP  =").$cntx_ptt; 
      if ($cntx_ptg>0) $outtextda .= '<br>'._("PAID ELEMENTS PUSHED TO GALLERY  =").$cntx_ptg; 
      if ($cntx_ptu>0) $outtextda .= '<br>'._("PAID ELEMENTS PUSHED TO URGENT  =").$cntx_ptu; 
      //$outtext .= '<br>'.$querytodelete; 

      //concat Dataswith text headers 
      if ($outtextda=='') $outtextda="<br> no items modified "; // reset and default display
      else { 
          $outtext .=$outtextda;
          // send a recap email to admin 
          if ( !isset($EMAILS_ADMIN_HOURLY_SEND) || $EMAILS_ADMIN_HOURLY_SEND ) 
            mySendEmail($emailRoutingTable,'cron','hourly', $outtext, '');
      }
    
 
    // ----------------- SAVE TO LOG FILE ----------------------------
    if ($ENABLE_USER_LOGS){
       $laction="cron";$lwhat = "hourly";
       $luserid='';
       $ldesc = 'Hourly batch executed'.'|'. $serverremoteaddr;
       $lseverity = 0; 
       log_event($laction,$lwhat, $row->id, $luserid, $ldesc, $lseverity);
    }   
  }

  // --------------- DAILY BATCH  -------------------------------------------------------
  // send a simple email 
  if ($batch == "daily"){
    // store into Stats file elements 
    // u=users a=ad a40=ad with status '40'
    // grab the date first and store this into a rotary log file
    
    $outdata="";
    $outtext="";
    $outtextda=''; // DA=Daily Actionsd
    
    $outtext .= '<h3 style="font-size:16px;font-weight:bold; padding: 0; margin: 5px 0 2px;">'._("Daily data processing").'</h3>';
    $outtext .= '<div style="border-top: 1px solid #069; line-height:3px;margin:4px 0 4px;">&nbsp;</div>';

    $stamp= date( 'Y-m-d H:i:s', time());
    $stampservicewillexpire =   date( 'Y-m-d H:i:s',  time() + ($SERVICES_NOTIF_BEFORE_DAYS*24*60*60) );
    $stampserviceisexpired =   date( 'Y-m-d H:i:s',  time() - ($SERVICES_DELETEALL_AFTER_DAYS_EXPIRATION*24*60*60) );
    $stampservicegarbagecollection =   date( 'Y-m-d H:i:s',  time() - ($DRAFT_PURGE_DURATION*24*60*60) );


    //----------- SERVICES  MANAGEMENT -------------------//
    // ------ part S1 = notify "will soon expire services for TIRAL cases" ---- 
    $outtextda .= check_and_notify_services('trial-willexpire', $stampservicewillexpire, true, true);

    // ------ part S1 = notify "will soon expire services for NORMAL Conditions " ---- 
    $outtextda .= check_and_notify_services('willexpire', $stampservicewillexpire, true, true);

    // ------- part S2 =  notify "expired services" ---- // 
    $outtextda .= check_and_notify_services('expired', $stamp, true, true);


    // ------- part S3 =  notify "deleted services" ---- //
    $outtextda .= check_and_notify_services('expiredtodelete', $stampserviceisexpired, false, false);


    // ------- part S4 =  clean elements in draft, 10, 15 status for more than  X days ---- //
    $outtextda .= check_and_notify_services('garbagecollection', $stampservicegarbagecollection, false, false);  

    // ------- part S4 =  clean trial element not confirmed and lead to destruction of all adds 
    $outtextda .= check_and_notify_services('expiredtodelete_trialnotconfirmed', $stampserviceisexpired, false, false);  


    //----------- USERS  MANAGEMENT -------------------//
    
    // ------ part 2B  -- check for expired USERS only if expiration is set 
    if ($USER_MAXINACTIVE_DURATION!=''){

      //Z6.4.0 - exclude ADMIN users from autodeletion of accounts 
      if ($USER_NO_EXPIRATION_FOR_ADMIN)  $wherestub = " AND `$dbUsersTable`.`usertype` != 9 "; else $wherestub ="";

      $filter ="  WHERE  `$dbUsersTable`.`status` IN ('40') $wherestub AND `$dbUsersTable`.`lastvisitdate` < '".$stampUserwillexpire."'";
      $sql_sort="";  
      $queryUserwillexpire = "SELECT `$dbUsersTable`.* FROM `$dbUsersTable` ".$filter."  ". $sql_sort ; 
      $resultwillexpireusers = @mysql_query($queryUserwillexpire);        
      $cntx=0;
      while ($row = mysql_fetch_object($resultwillexpireusers)) { 
      
        // take each one and change the status and notify that to user
        $query = "UPDATE `".$dbUsersTable."` SET   
            `expiredate` = '".$stampShouldExpire."', 
            `moddate` = '".$stamp."',
            `status`='45'
            WHERE ((`id` = '".$row->id."')) ";
        $result = @mysql_query($query);       
        $cntx+=1;
        
        // ----------------- SAVE TO LOG FILE ----------------------------
        if ($result && ($ENABLE_ELEM_LOGS)){
               $laction="update";$lwhat = "user";$lstatus = "45";$luserid=0;
              log_event($laction,$lwhat, $row->id, $luserid, $lstatus, 0);
        }
        // notifiy user by email        
        $xitem = Array (
                          'id'=> $row->id, 
                          'firstname' => $row->firstname,
                          'lastname'=> $row->lastname,
                          'username'=> stripslashes($row->username),
                          'email'=> stripslashes($row->email), 
                          'imgpath'=> $dest_path_from_root,
                          'imgurl'=> $row->imgurl,
                          'gender' => $row->gender,                         
                          'avatarimg'=> $row->avatarimg,
                          'probannerimg'=> $row->probannerimg,
                          'expiredate'=> $row->expiredate,
                          'protype'=> $row->protype,
                          'procpny'=> $row->procpny,      
                          'prosiret'=> $row->prosiret
                          );
           
        mySendEmail($emailRoutingTable, 'user', '45', $xitem, $row->email);  
      }
      if ($cntx>0) $outtextda .= '<br>'._("USER FORCED TO WILLEXPIRED =").$cntx;  // log this and report it.
      // $outtextda .= '<br> into will expire loop</br>';  // log this and report it.
      //$outtext .= '<br>'.$queryUserwillexpire;
    }
    
    
     // ------ part 3B  -- check for expired USERS only if expiration is set 
      $filter ="  WHERE  `$dbUsersTable`.`status` IN ('45') AND `$dbUsersTable`.`expiredate` < '".$stamp."'";
      $sql_sort="";  
      $queryUserwillexpire = "SELECT `$dbUsersTable`.* FROM `$dbUsersTable` ".$filter."  ". $sql_sort ; 
      $resultwillexpireusers = @mysql_query($queryUserwillexpire);        
      $cntx=0;
      while ($row = mysql_fetch_object($resultwillexpireusers)) { 
      
        // take each one and change the status and notify that to user
        $query = "UPDATE `".$dbUsersTable."` SET   
            `expiredate` = '".$stamp."',
            `moddate` = '".$stamp."', 
            `status`='80'
            WHERE ((`id` = '".$row->id."')) ";
        $result = @mysql_query($query);       
        $cntx+=1;
        
        // ----------------- SAVE TO LOG FILE ----------------------------
        if ($result && ($ENABLE_ELEM_LOGS)){
               $laction="update";$lwhat = "user";$lstatus = "80";$luserid=0;
              log_event($laction,$lwhat, $row->id, $luserid, $lstatus, 0);
        }
        // notifiy user by email        
        $xitem = Array (
                          'id'=> $row->id, 
                          'firstname' => $row->firstname,
                          'lastname'=> $row->lastname,
                          'username'=> stripslashes($row->username),
                          'email'=> stripslashes($row->email), 
                          'imgpath'=> $dest_path_from_root,
                          'imgurl'=> $row->imgurl,
                          'gender' => $row->gender,                         
                          'avatarimg'=> $row->avatarimg,
                          'probannerimg'=> $row->probannerimg,
                          'expiredate'=> $row->expiredate,
                          'protype'=> $row->protype,
                          'procpny'=> $row->procpny,      
                          'prosiret'=> $row->prosiret
                          );
           
        mySendEmail($emailRoutingTable, 'user', '80', $xitem, $row->email);  
      }
      if ($cntx>0) $outtextda .= '<br>'._("USER FORCED TO EXPIRED =").$cntx;  // log this and report it.
      //$outtext .= '<br>'.$queryUserwillexpire;
    

   // ------ part 4b  --  delete DRAFT USERS  when in preview mode  ---/
      if ($USER_PREVIEW_BEFORE){
        $filter="  WHERE `$dbUsersTable`.`priority` != 'PERM' AND `$dbUsersTable`.`status` IN ('10','15')  AND `$dbUsersTable`.`moddate` < '".$stamppastdraft."'";
        $sql_sort="";  
        $querytodelete = "SELECT `$dbUsersTable`.*, `$dbUsersTable`.`email` AS `uemail`  FROM `$dbUsersTable`  ".$filter."  ". $sql_sort ; 
        $resulttodelete = @mysql_query($querytodelete);        
        $cntx=0;
        while ($row = mysql_fetch_object($resulttodelete)) { 
          // take each one and change the status and notify that to user
            // make the delete action 
            delete_files("user", $row->id);
            sql_delete_item("user", $row->id); // delete all from an item incuding logs and associated pictures
            $cntx+=1;
        }
        if ($cntx>0) $outtextda .= '<br>'._("DRAFT (PREVIEW) USERS DELETED =").$cntx; 
        //$outtext .= '<br>'.$querytodelete; 
      }

    // ------ part 4b  --  delete old users   ---/

        $filter ="  WHERE  `$dbUsersTable`.`status` IN ('80') AND `$dbUsersTable`.`moddate` < '".$stamppast_user_delete."'";
        $sql_sort="";  
        $querytodelete = "SELECT `$dbUsersTable`.*  FROM `$dbUsersTable`  ".$filter."  ". $sql_sort ; 
        $resulttodelete = @mysql_query($querytodelete);        
        $cntx=0;
        while ($row = mysql_fetch_object($resulttodelete)) { 
          
          $a = array($row->imgname, $row->avatarimg, $row->probannerimg, $row->folioimg );
          foreach ($a as $imgname) {
            if ($imgname && ($imgname!="")){
              foreach(explode(";",$imgname) as $imgnameItem) { 
                $successx = unlink($dest_path."".$imgnameItem);  // delete main file 
                $successx = unlink($dest_path."tn_".$imgnameItem); // delete tn file
              } 
            } 
          }
          // make the delete action 
          delete_files("user", $row->id);
          sql_delete_item("user", $row->id); // delete all from an item incuding logs and associated pictures

          $cntx+=1;
        }
        if ($cntx>0) $outtext .= '<br>'._("USER DEFINITIVELY DELETED =").$cntx; 

      // ------ part 4c  --  delete old LOGS   ---/
       if (($ENABLE_ELEM_LOGS || $ENABLE_ELEM_LOGS) && $LOGS_DURATION) {
        $filter ="  WHERE `$dbLogsTable`.`date` < '".$logmaxdate."'";
        $querylog = "DELETE FROM `".$dbLogsTable."`  $filter ";
        $resultlog = @mysql_query($querylog);
        $cntx= mysql_affected_rows(); 
        if ($cntx) $outtextda .= '<br>'._("LOGS DELETED =").$cntx; 
      }


      // ------ part 4d  --  delete old PAYMENT TRANSACTIONS   ---/
       if ($PAYMENT_LOGS_DURATION  && ($PAYMENT_LOGS_DURATION >0)) {
        $filter ="  WHERE `$dbPaymentsTable`.`paymentdate` < '".$paymentlogmaxdate."'";
        $queryplog = "DELETE FROM `".$dbPaymentsTable."`  $filter ";
        $resultplog = @mysql_query($queryplog);
        $cntx= mysql_affected_rows(); 
        if ($cntx) $outtextda .= '<br>'._("PAYMEMENT TRANSACTIONS DELETED =").$cntx; 
      }

      // ------ part 4e  --  delete old VISITORS LOGS  ---/
       if ($ENABLE_VISITORS_LOGS  && $VISITORS_LOGS_DURATION ) {
        $filter ="  WHERE `$dbVisitorsTable`.`date` < '".$visitorslogmaxdate."'";
        $queryplog = "DELETE FROM `".$dbVisitorsTable."`  $filter ";
        $resultplog = @mysql_query($queryplog);
        $cntx= mysql_affected_rows(); 
        if ($cntx) $outtextda .= '<br>'._("VISITORS LOGS DELETED =").$cntx; 
      }


    if ($ENABLE_AUTO_SITEMAP==true) {
      if ($SITEMAP_PUBLISHING_EN)
        $outtextda .= '<br>'._("SITEMAP.XML file will generated and published to crawlers."); 
      else
        $outtextda .= '<br>'._("SITEMAP.XML file will generated."); 
    }

    // output the result of the first and display a dummy item when no results  
    if ($outtextda=="") $outtextda =  _("NO ACTION TODAY"); 
    $outtext .=$outtextda;

     // case of nothing displayed
     // ... TBD ...   
        
    //---------- SECOND PART OF THE DASHOBARD --> SEND STATUS  --------------------//
    $outtext .= '<h3 style="font-size:16px;font-weight:bold; padding: 0; margin: 5px 0 2px;">'._("Dashboard").'</h3>';
    $outtext .= '<div style="border-top: 1px solid #069; line-height:3px;margin:4px 0 4px;">&nbsp;</div>';
  
     // get total number of users in active mode
    $sql_sort="";  
    $filter="  WHERE `status` IN ('40','45') ";
    $queryusersfull = "SELECT COUNT(`id`) as `nbusers` FROM `$dbUsersTable`" .$filter." ". $sql_sort ; 
    $resultusers = mysql_query($queryusersfull);
    $row = mysql_fetch_object($resultusers);
    if ($row) {
      $outdata .="u=".$row->nbusers; 
      //$outtext .= ''. _("Users #"). ' : ' . $row->nbusers. '<br>';   
    }
 
    // get total number of articles with status 
    $sql_sort="";  
    $filter="";  //$filter="  WHERE `status` IN ('40') "; 
    $queryadfull = "SELECT COUNT(`id`) as `nbads`, `status` FROM `$dbItemsTable`" .$filter." GROUP BY `status` ". $sql_sort ; 
    $resultads = @mysql_query($queryadfull);
    
     while ($row = mysql_fetch_object($resultads)) { 
      $outdata .="&a".$row->status."=".$row->nbads; 
      $outtext .= _("Ads").' '.$status_name_translation[$row->status] . ' : ' . $row->nbads.'<br>'; 
     }
    // data format  =  {what=value|} where u=user; a=add; a00= adds with status =0
    // example : u=55&a=3&a00=1&a10=13&a40=53&a60=1&a80=5

    $outtext .= '<br>';
    
    // get total number of articles with status 
    $sql_sort="";  
    $filter="";  //$filter="  WHERE `status` IN ('40') "; 
    $queryadfull = "SELECT COUNT(`id`) as `nbusers`, `status` FROM `$dbUsersTable`" .$filter." GROUP BY `status` ". $sql_sort ; 
    $resultads = @mysql_query($queryadfull);
    
     while ($row = mysql_fetch_object($resultads)) { 
      $outdata .="&us".$row->status."=".$row->nbusers; 
      $outtext .= _("Users").' '.$status_name_translation[$row->status] . ' : ' . $row->nbusers.'<br>'; 
     }
    // data format  =  {what=value|} where u=user; a=add; a00= adds with status =0
    // example : u=55&a=3&a00=1&a10=13&a40=53&a60=1&a80=5
    
    // save date to STATS table
    if ($outdata!=""){
      $thisdate= date( 'Y-m-d', time()); 
      $query = "SELECT * FROM $dbStatsTable WHERE date = '".$thisdate."'";
      $result = @mysql_query($query);
      
      if (mysql_num_rows($result)==0){
        $query = "INSERT INTO `".$dbStatsTable."` (`date`,  `type`, `data`) ";
        $query .= "VALUES ('".$thisdate."', 'count', '".$outdata."');";
        $result = @mysql_query($query);  
      }  
    }

    // send a global email to admin 
    mySendEmail($emailRoutingTable,'cron','daily', $outtext, '');


   // ----------------- CHECK for expiration of the site   ----------------------------
    //$TBYB_END_DATE='2013-03-31';
   if ($TBYB_END_DATE){
      $tbdateAr=explode('-', $TBYB_END_DATE);
      $tbdateTime = mktime(0, 0, 0, $tbdateAr[1], $tbdateAr[2], $tbdateAr[0]);
      $not1_period = $tbdateTime - (7 * 24 * 60 * 60);
      $notifmessage ="";
      // $notifmessage .="debug : $TBYB_END_DATE - $tbdateTime - $not1_period - ".time();

      // if within the notificatuion period 
      if (( time() > $not1_period) && (time() < $tbdateTime)) {
        // send a will expire message
        $deltatime= $tbdateTime-time();
        $deltadays = ceil($deltatime / (60*60 *24));
        $notifmessage .= _("This site will expire shortly in ").$deltadays." "._("day(s)") . " ($TBYB_END_DATE)";  
        mySendEmail($emailRoutingTable,'notif','orange', $notifmessage, '');
      } else if (time() >= $tbdateTime){
        // send an expiration message 
        $notifmessage .= _("This site is expired as of ") .  $TBYB_END_DATE;  
        mySendEmail($emailRoutingTable,'notif','red', $notifmessage, '');
      }
   }

    // ----------------- SAVE TO LOG FILE ----------------------------
    if ($ENABLE_USER_LOGS){
       $laction="cron";$lwhat = "daily";
       $luserid='';
       $ldesc = 'Daily batch executed'.'|'. $serverremoteaddr;
       $lseverity = 0; 
       log_event($laction,$lwhat, $row->id, $luserid, $ldesc, $lseverity);
    }  

    // IMPORTANT - this can take a long time and thus delayed to end of the process  
    // --- 
    // ------ part 5  --  generate sitemap   ---/
    if ($ENABLE_AUTO_SITEMAP==true) {
        require_once ("sitemap_lib.php");
        generate_sitemap(); // this generate and publish the sitemap to all crawlers 
    } 
  }

  // ----------------- WEEKLY BATCH OR FORCED BACKUP ----------------------------
  if ($batch == "weekly" || $batch=="forcedbackup") {

    check_userRights($action); // just to unitialize the curuser_is_admin
    if ($batch=="forcedbackup" && !$curuser_is_admin) { die;} // die if not admin ! 

    $sqlerror=""; 
    if ($BACKUP_SQLTABLE){ 

      $t0=microtime(true); // counter 
      require_once("backup.php");
      require_once("emails_functions.php"); // for multi-attached emails     
      //Back-up all data in a file 
      // delete all files before 
      if ($BACKUP_DELETEALL) {
        deleteFilesInDir( "./backup/", "" , "1" ); // 1 seconde
        logfile('debug', "{cron=weekly} : All BACK-UP files deleted "); 
      }

      $resfile= dump($DB_PREFIX);
      $deltatime= (microtime(true)-$t0);
      $deltatime = sprintf("%01.3f", $deltatime);
        
      // send this file by email
      if ($resfile) {

        $filesx[0]="./backup/".$resfile;
        $filesx[1]= $SETTINGS_PATH."settings.php";
        $filesx[2]= $SETTINGS_PATH."home_settings_fr_FR.php";
        $filesx[3]= $SETTINGS_PATH."general.json";
        $filesx[4]= $SETTINGS_PATH."catalogue.json";
        $filesx[5]= $SETTINGS_PATH."emailroutes.json";

        // dump the files  
        $filesx_dump = print_r($filesx, true);
        logfile('debug', "{cron=weekly} : $filesx_dump"); 

        $themail = multi_attach_mail2($email_admin,$email_fromadmin, _("Back-up of ZADS tables  : ").$DB_PREFIX, _("Back-up of ZADS tables  : ").$DB_PREFIX._(" into file : ").$resfile." in ".$deltatime."sec", $filesx); 
        $msg = "{cron=weekly} : Back-up done and sent by email to  $email_admin";
        logfile('debug', $msg); 

        // Z6.5.8 - send second email to super admin for cloud type of environments 
        if ($EMAIL_SUPERADMIN){  
          $themail = multi_attach_mail2($EMAIL_SUPERADMIN,$email_fromadmin, _("Back-up of site : ").$DOMAIN_FQDN, _("Back-up of ZADS tables  : ").$DB_PREFIX._(" into file : ").$resfile." in ".$deltatime."sec", $filesx); 
          $msg2 = "{cron=weekly} : Back-up (2) done and sent by email to  $EMAIL_SUPERADMIN from $email_fromadmin by" .date('Y-m-d H:i:s',time());
          logfile('debug', $msg2); 
        }

        // path the message used in JSON response 
        $msg = "Back-up done and sent by email"; 
      }
      else {
        // error, no ressources file 
        $msg = "{cron=weekly} : Back-up FAILED : no valid Archive created "; 
        logfile('error', $msg); 
      }

        // send a regular weekly email
        $emailmsg = ''; 
        $emailmsg .= sprintf(_('Backup of <b>%s</b> tables done.<br>File : <b>%s</b> sent to : %s'), $DB_PREFIX, $resfile,$email_admin);
        mySendEmail($emailRoutingTable,'cron','weekly',  $emailmsg, '');  
      
      }

      
    // ----------------- SAVE TO LOG FILE ----------------------------
    if ($ENABLE_USER_LOGS){
       $laction="cron";$lwhat = "weekly";
       $luserid='';
       $ldesc = 'Weekly batch executed'.'|'. $serverremoteaddr;
       $lseverity = 0; 
       log_event($laction,$lwhat, '', $luserid, $ldesc, $lseverity);
    }    
  }


  // ----------------- FINALIZE the RESPONSE in JSON (only for debug mode a others are through CRONS  ----------------------------
  $success=true;
  $json = array(
      'success' => $success,
      'message'=> $msg,
      'action' => "batch",
      'what' => $batch,
      'data' => $outdata,
      'sqlerror'=>$sqlerror
  );
  echo json_encode($json);
}

// ############# SERVLET FOR LOGS REQUESTS  ###########################
if (isset($_POST["logs"]) ) {

  $logs = $_POST["logs"] ;
  $action = "list"; // default action
  $action = $logs; 
  
  /* check if user has the right to do so if ok , continue ,  else, page is exited with a special message*/
  check_userRights("logs", $action); 
  
  // correction past the ckeck 
  if ($logs=="stats") $action="list"; 

  // identify selector
  $what = secure_var($_POST["what"]) ;            // SECURITY 
  $laction = secure_var($_POST["laction"]) ;            // SECURITY 
  $id = $_POST["id"]+0 ;                          // SECURITY - convert to int 
  if ($what=="curuser") $what="user"; // patch for current user 
  
  $maxresults=1; 
  

  
  // other filter / sort and actions
  if (isset($_POST["page"]))$paged = $_POST["page"]+0; else  $paged =1;  
  $nav=$_POST["nav"];
  
  $sort=$_POST["sort"];
  $sortoriginal = $sort;
  $sort=explode("_",$sort); 
  $sort_dir = $sort[1];
  $sort_by = $sort[0];
  
  // filter
  $faction = $_POST["faction"] ;
  $fseverity = $_POST["fseverity"] ;
  
  $search=trim(secure_var($_POST["search"])); // SECURITY 
    
  $msg=""; 
  $filter=""; 
  $sql_sort="";
  
  // security check on action 
  $laction_authorized_values = array("auth", "sec", "cron");
  
  //----- LIST action -----------------------------
  if ($action=="list"){
    // sorting option 
    if ($sort_by) $sql_sort ="  ORDER BY `$dbLogsTable`.`".$sort_by."` ".$sort_dir;
    else 
    $sql_sort.=" ORDER BY `date` DESC ";  
    
    if ($id) {
      $filter.="  WHERE `what` IN ('$what') AND `action` NOT IN ('auth','msg','sec','cron','error') AND `whatid` = '$id' ";
      $limit=" LIMIT 0, 30 "; // no limit on the request
    } else {
      // filter
      if ($what) $filter.="  WHERE `what` IN ('$what')"; 
      $itemstart = ((int)$paged -1) * 50; 
      $limit = "LIMIT ".$itemstart.", 50"; 
    } 
    
    // search condition
    if ($search)  
      if ($filter=="")  $filter.="  WHERE ((`whatid` =  '".$search."') OR (`$dbItemsTable`.`title` like  '%".$search."%') OR (`$dbCatsTable`.`title` like  '%".$search."%') OR (`$dbUsersTable`.`username` like  '%".$search."%'))  "; 
      else  $filter.="  AND ((`whatid` = '".$search."') OR (`$dbItemsTable`.`title` like  '%".$search."%') OR (`$dbCatsTable`.`title` like  '%".$search."%') OR (`$dbUsersTable`.`username` like  '%".$search."%')) ";


    // other filters conditions : 
    if ($faction || $fseverity){
      if ($faction){
        if ($faction=="lc") {
            $tmpstr=""; 
            foreach ($laction_authorized_values as $value) {
              $tmpstr .= " '".$value."',"; 
            } $tmpstr = substr($tmpstr, 0,strlen($tmpstr)-1); //remove the last ','
             $corefilter= " `action` NOT IN ( $tmpstr ) "; 
        } else $corefilter = "((`action` =  '".$faction."'))"; 
        if ($filter=="")  $filter.="  WHERE $corefilter "; else $filter.="  AND $corefilter "; 
         
      }      
      if ($fseverity){
        $corefilter = "((`severity` =  '".substr($fseverity,1)."'))"; 
        if ($filter=="")  $filter.="  WHERE $corefilter "; else $filter.="  AND $corefilter ";         
      }
    }

    // multiple join elements from AD + USER + CATS
    $join = " LEFT OUTER JOIN `$dbUsersTable` ON `$dbLogsTable`.`userid`= `$dbUsersTable`.`id` ";
    $join .= " LEFT OUTER JOIN `$dbItemsTable` ON `$dbLogsTable`.`whatid`= `$dbItemsTable`.`id` ";
    $join .= " LEFT OUTER JOIN `$dbCatsTable` ON `$dbLogsTable`.`whatid`= `$dbCatsTable`.`id` ";
    
    // make a pre-query to get total list of results 
    $queryfull = "SELECT `$dbLogsTable`.`id`, `$dbUsersTable`.`username`, `$dbItemsTable`.`title` as adtitle, `$dbCatsTable`.`title` as cattitle FROM `$dbLogsTable` " .$join .$filter." ". $sql_sort;
    $resultfull = @mysql_query($queryfull);
    $maxresults = mysql_num_rows($resultfull);
    

    //-- make the full query
    $query = "SELECT `$dbLogsTable`.*,`$dbUsersTable`.`username`,  `$dbUsersTable`.`avatarimg`, `$dbItemsTable`.`title` as adtitle, `$dbCatsTable`.`title` as cattitle FROM `$dbLogsTable` ".$join .$filter." ". $sql_sort . " " . $limit ; 
    $result = @mysql_query($query);
    $totnbrofresults = @mysql_num_rows($result);
     
    $idx=0;
    
    if (($totnbrofresults) && ($totnbrofresults !=0)){
      $idx=0;
      $outdata=""; 
      // first item is generic
      $loglist = Array ();
      $idx=0;
      while ($row = mysql_fetch_object($result)) { 
        $thistate= explode("|",$row->desc); 
        $thistate = $thistate[0]; 
        $outdata = Array (
            'id' => $row->id ,
            'date' => $row->date ,
            'action'=> $row->action,
            'what'=> $row->what, 
            'whatid'=> $row->whatid,
            'userid'=> $row->userid,
            'username'=> stripslashes($row->username),
            'imgurl'=> $row->avatarimg,
            'imgpath'=> $dest_path_from_root_user,
            'adtitle'=>stripslashes($row->adtitle),
            'cattitle'=>stripslashes($row->cattitle),
            'desc'=> $row->desc,
            'state'=> $thistate, // sent twice to help publication status
            'severity'=> $row->severity  
            );
       $loglist[$idx] = $outdata; 
       $idx+=1; 
      }
     } else {
     $loglist = Array ();
     }
    $success=true;
  }
  // ----------- LOG DELETION ----------------------
  else if ($action=='delete') {

      if (in_array($laction, $laction_authorized_values)) {
        // make the delete action 
        $query = "DELETE FROM `".$dbLogsTable."`  WHERE ((`action` = '".$laction."')) ";
        $result = @mysql_query($query);
        if (!$result) $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
      } else $sqlerror="unknown value for filed to be deleted"; 
      
      if (!$sqlerror) {
        $msg = "Yay! Everything went well!";
        $success=true;
      }
      else {
        $msg = "Doh! Something happened : ".$sqlerror;
        $success=false;
        }
  }
  
  // -- output result ------------- 
  $json = array(
      'success' => $success,
      'totnb' =>$maxresults,
      'message'=> $msg,
      'action' => "logs",
      'subaction' => $action,
      'what' => $what,
      'nav'=>$nav,
      'sort'=>$sortoriginal,
      'paged' => $paged,
      'eppage'=>$eppage,
      'search'=>$search,
      'fseverity'=>$fseverity,
      'faction'=>$faction,
      'id' => $id,
      'data' => $loglist
  );
 if ($debug_tmp==1){ // add debug info into the stream when working local
     $json["xdebug"]= array(
              'sqldebug'=> $query,
              'sqlfulldebug'=>$queryfull,
              'filter'=>$filter,
              'laction'=>$laction,
              'corefilter'=>$corefilter
              );  
   }

  // ob_start('ob_gzhandler');
  // echo json_encode($json);
  encode_json_and_send_with_compression($json); 
}


// ############# SERVLET FOR VISITORS  ###########################
if (isset($_POST["visitors"]) ) {

  $visitors = $_POST["visitors"] ;
  $action = "list"; // default action
  $action = $visitors; 
  
  /* check if user has the right to do so if ok , continue ,  else, page is exited with a special message*/
  check_userRights("visitors", $action); 
  
  // identify selector
  $what = secure_var($_POST["what"]) ;            // SECURITY 
  $laction = secure_var($_POST["laction"]) ;            // SECURITY 
  $id = $_POST["id"]+0 ;                          // SECURITY - convert to int 
  if ($what=="curuser") $what="user"; // patch for current user 
  
  $maxresults=1; 
  

  
  // other filter / sort and actions
  if (isset($_POST["page"]))$paged = $_POST["page"]+0; else  $paged =1;  
  if (isset($_POST["eppage"])) $eppage =$_POST["eppage"]*1; else  $eppage=50; 

  $nav=$_POST["nav"];
  
  $sort=$_POST["sort"];
  $sortoriginal = $sort;
  $sort=explode("_",$sort); 
  $sort_dir = $sort[1];
  $sort_by = $sort[0];
  
  // filter
  $fbot = $_POST["fbot"] ;$fgoogbot = $_POST["fgoogbot"] ;$fbingbot = $_POST["fbingbot"] ;

  // search  
  $search=trim(secure_var($_POST["search"])); // SECURITY 
  $fsearch=trim(secure_var($_POST["fsearch"])); // SECURITY 
    
  $msg=""; 
  $filter=""; 
  $sql_sort="";

  // general user Agent for bot detection
  $googlobot="googlebot"; 
  $bingbot="bingbot"; 
  
  //----- LIST action -----------------------------
  if ($action=="list"){
    // sorting option 
    if ($sort_by) $sql_sort ="  ORDER BY `$dbVisitorsTable`.`".$sort_by."` ".$sort_dir;
    else $sql_sort.=" ORDER BY `date` DESC ";  
        
    // search condition
    if ($fsearch) {
      $fstub =   " ((`ip` =  '".$fsearch."') OR (`uri` like  '%".$fsearch."%') OR (`ua` like  '%".$fsearch."%')) ";
      $filter.= ($filter=="") ?  "  WHERE  " : "  AND  "; 
      $filter.= $fstub; 
    }

    if ($fbot=='yes') {
      $fstub =   " (`ua` like  '%".$googlobot."%') OR  (`ua` like  '%".$bingbot."%') ";
      $filter.= ($filter=="") ?  "  WHERE  " : "  AND  "; 
      $filter.= "( $fstub )"; 
    }

    if ($fbingbot=='yes') {
      $fstub =   " (`ua` like  '%".$bingbot."%') ";
      $filter.= ($filter=="") ?  "  WHERE  " : "  AND  "; 
      $filter.= "( $fstub )"; 
    }

    if ($fgoogbot=='yes') {
      $fstub =   " (`ua` like  '%".$googlobot."%')  ";
      $filter.= ($filter=="") ?  "  WHERE  " : "  AND  "; 
      $filter.= "( $fstub )"; 
    }



    // other filters conditions : 
    // multiple join elements from AD + USER + CATS
    // $join = " LEFT OUTER JOIN `$dbUsersTable` ON `$dbLogsTable`.`userid`= `$dbUsersTable`.`id` ";
    // $join .= " LEFT OUTER JOIN `$dbItemsTable` ON `$dbLogsTable`.`whatid`= `$dbItemsTable`.`id` ";
    // $join .= " LEFT OUTER JOIN `$dbCatsTable` ON `$dbLogsTable`.`whatid`= `$dbCatsTable`.`id` ";
    $join =''; 
    
    // make a pre-query to get total list of results 
    // $queryfull = "SELECT `$dbVisitorsTable`.`id`, `$dbUsersTable`.`username`, `$dbItemsTable`.`title` as adtitle, `$dbCatsTable`.`title` as cattitle FROM `$dbLogsTable` " .$join .$filter." ". $sql_sort;
    $queryfull = "SELECT `$dbVisitorsTable`.`id` FROM `$dbVisitorsTable` " .$join .$filter." ". $sql_sort;

    $resultfull = @mysql_query($queryfull);
    $maxresults = mysql_num_rows($resultfull);
    

    //-- make the full query
    // $query = "SELECT `$dbLogsTable`.*,`$dbUsersTable`.`username`,  `$dbUsersTable`.`avatarimg`, `$dbItemsTable`.`title` as adtitle, `$dbCatsTable`.`title` as cattitle FROM `$dbLogsTable` ".$join .$filter." ". $sql_sort . " " . $limit ; 
    $query = "SELECT `$dbVisitorsTable`.* FROM `$dbVisitorsTable` " .$join .$filter." ". $sql_sort. " " . $limit ; 
    $result = @mysql_query($query);
    $totnbrofresults = @mysql_num_rows($result);
    $idx=0;
    
    if (($totnbrofresults) && ($totnbrofresults !=0)){
      $idx=0;
      $outdata=""; 
      // first item is generic
      $loglist = Array ();
      $idx=0;
      while ($row = mysql_fetch_object($result)) { 
        $thistate= explode("|",$row->desc); 
        $thistate = $thistate[0]; 
        $outdata = Array (
            'id' => $row->id ,
            'date' => $row->date ,
            'ip'=> $row->ip,
            'uri'=> $row->uri, 
            'ua'=> $row->ua  
            );
       $loglist[$idx] = $outdata; 
       $idx+=1; 
      }
     } else {
     $loglist = Array ();
     }
    $success=true;
  }
  // ----------- LOG DELETION ----------------------
  else if ($action=='delete') {

      $filter="";

      // security check on action 
      $laction_authorized_values = array("allbutbot", "allall", "allfilter");

      if (in_array($laction, $laction_authorized_values)) {

        if ($laction=="allall") $filter=""; // delete all 
        if ($laction=="allbutbot") {
          $fstub =   " (`ua` NOT LIKE '%".$googlobot."%')  ";
          $filter=" WHERE $fstub"; // delete all 
        }
        if ($laction=="allfilter"){
         if ($fsearch) {
            $fstub =   " ((`ip` =  '".$fsearch."') OR (`uri` like  '%".$fsearch."%') OR (`ua` like  '%".$fsearch."%')) ";
            $filter.= ($filter=="") ?  "  WHERE  " : "  AND  "; 
            $filter.= $fstub; 
          }
        }

        // make the delete action 
        $query = "DELETE FROM $dbVisitorsTable $filter ";
        // $result=true; 
        $result = @mysql_query($query);
        if (!$result) $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
      } else $sqlerror="unknown value for filed to be deleted"; 
      
      if (!$sqlerror) {
        $msg = "Yay! Everything went well!";
        $success=true;
      }
      else {
        $msg = "Doh! Something happened : ".$sqlerror;
        $success=false;
        }
  }
  
  // -- output result ------------- 
  $json = array(
      'success' => $success,
      'totnb' =>$maxresults,
      'message'=> $msg,
      'action' => "visitors",
      'subaction' => $action,
      'what' => $what,
      'nav'=>$nav,
      'sort'=>$sortoriginal,
      'paged' => $paged,
      'eppage'=>$eppage,
      'search'=>$search,
      'fsearch'=>$fsearch,
      'fbot'=>$fbot,
      'fgoogbot'=>$fgoogbot,
      'fbingbot'=>$fbingbot,
      'id' => $id,
      'data' => $loglist
  );
 if ($debug_tmp==1){ // add debug info into the stream when working local
     $json["xdebug"]= array(
              'sqldebug'=> $query,
              'sqlfulldebug'=>$queryfull,
              'filter'=>$filter,
              'laction'=>$laction,
              'corefilter'=>$corefilter
              );  
   }

  // ob_start('ob_gzhandler');
  // echo json_encode($json);
  encode_json_and_send_with_compression($json); 
}

// ############# SERVLET FOR COMS REQUESTS   ###########################
if ($COMS_AD_TYPE || $COMS_USER_TYPE) {
  require_once('inc_coms_controller.php'); 
}


// ############# SERVLET FOR BANNERS REQUESTS  ###########################
if (isset($_POST["banners"]) ) {
  $noresulttosend =false;
  
  $dbThisTable = $dbBannersTable;

  $banners = $_POST["banners"] ;
  $action = "list"; // default action
  $action = $banners; 
  
  /* check if user has the right to do so if ok , continue ,  else, page is exited with a special message*/
  check_userRights("banners", $action); 
  
  // identify selector
  $what = secure_var($_POST["what"]) ;            // SECURITY 
  $laction = secure_var($_POST["laction"]) ;            // SECURITY 
  $id = $_POST["id"]+0 ;                          // SECURITY - convert to int 
  if ($what=="curuser") $what="user"; // patch for current user 
  

  // load variables
  $id = $_POST["id"]+0 ;                          // SECURITY - convert to int 
  $ad_id=$id;                                     // backward compatibility
  $userid = $_POST["userid"]+0 ;                  // SECURITY - convert to int 
  $curuserid = $_POST["curuserid"]+0 ;            // SECURITY - convert to int 
  $title = secure_var($_POST["title"]);           // SECURED
  $htmlcode = $_POST["htmlcode"] ;     
  $type = secure_var($_POST["type"]);             // SECURITY - strip undesired text
  $priority = secure_var($_POST["priority"]);             // SECURITY - strip undesired text
  $status = secure_var($_POST["forceflag"]) ;     // SECURITY - strip undesired text
  $moddate= $_POST["moddate"] ;
  $location = secure_var($_POST["location"]) ;            // SECURED

  $startdate= secure_var($_POST["startdate"]) ;
  $enddate= secure_var($_POST["enddate"]) ;
  $position= $_POST["position"] ;                     // SECURED
  $clicktrackingurl = secure_var($_POST["clicktrackingurl"]) ;    // SECURED
  $filter=isset($_POST["filter"] ) ?  secure_var($_POST["filter"]) : "";

 
  $nav=$_POST["nav"];
 
  // images variable (updated @zads4.0)
  $imgnameArray = $_POST["filename"] ;
  $imgname=""; 

  // IMORTANT !  encode HTML CODE
  if (get_magic_quotes_gpc())
    $htmlcode =  stripcslashes($htmlcode); // remove the / added by magic quote option
  $htmlcode = base64_encode($htmlcode);

  // multipurpose variables  
  $msg=""; 
  $filter=""; 
  $sql_sort="";
  $sqlerror='';
  $datalist = Array ();
  
  // security check on action 
  //$laction_authorized_values = array("auth", "sec", "cron");

  //----- UPDATE CLICK -----------------------------
   if (($action=="click")){
      $query = "UPDATE `".$dbThisTable."` SET   
          `clicks` = `clicks`+1
          WHERE ((`id` = '".$id."')) ";
      $result = @mysql_query($query);  
      $noresulttosend=true; 
   } 


    //----- UPDATE CLICK on USER DISPLAYE BANNER -----------------------------
   if (($action=="clickuserbanner")){
      $query = "UPDATE `".$dbUsersTable."` SET   
          `banclicks` = `banclicks`+1
          WHERE ((`id` = '".$id."')) ";
      $result = @mysql_query($query);  
      $noresulttosend=true; 
      $action="click";
   } 


    //----- UPDATE IMPRESSIONS -----------------------------
   if (($action=="impression")){
      $query = "UPDATE `".$dbThisTable."` SET   
          `impressions` = `impressions`+1
          WHERE ((`id` = '".$id."')) ";
      $result = @mysql_query($query);  
      $noresulttosend=true; 
   }

   //----- REST CLICKS et IMPRESSIONS -----------------------------
   if (($action=="resetclicks")){
      $query = "UPDATE `".$dbThisTable."` SET   
          `impressions` = 0, 
          `clicks` = 0
          WHERE ((`id` = '".$id."')) ";
      $result = @mysql_query($query);
        $action='list'; 
      $nav="admin";  
      
   }


  //----- CREATE/MODIFY/DELETE action -----------------------------
  if (($action=="create") || ($action =="update")){

    // -- BUILD THE QUERY 
    if (($action=="create")){ 
      $query = "INSERT INTO `".$dbThisTable."` 
        ( `userid`, `moddate`, `title`, `htmlcode`, `clicktrackingurl`, `type`,`priority`,`imgname`, `status`, `startdate`, `enddate`, `position` ) ";
      $query .= "VALUES ( '$userid', '$stamp', '$title', '$htmlcode',  '$clicktrackingurl', '$type','$priority', '$imgname','$status','$startdate','$enddate','$position');";       
    }

    if ($action =="update"){
      $query = "UPDATE `".$dbThisTable."` SET   
        `moddate` = '".$stamp."', 
        `title`='".$title."',
        `htmlcode`= '".$htmlcode."',
        `clicktrackingurl`='".$clicktrackingurl."',
        `type`='".$type."',
        `priority`='".$priority."',
        `imgname`='".$imgname."',
        `status`='".$status."',
        `userid`='".$userid."',
        `location`='".$location."',
        `startdate`='".$startdate."',
        `enddate`='".$enddate."',
        `position`='".$position."'
        WHERE ((`id` = '".$id."')) ";
      }

    // -- MAKE THE QUERY
    $result = mysql_query($query);  
          
    
    // -- OUTPUT RESULTS 
    $sqlerror=""; 
    if (!$result) $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
    else {
      $action='list'; 
      $nav="admin";
    }

    $sqlerror = refreshCache("banners"); 
    
  } // end of CREATE


  // ------ DELETION action ----------------------
   if ($action=='delete') {

      // make the delete action 
      $query = "DELETE FROM `".$dbThisTable."`  WHERE ((`id` = '".$id."')) ";
      $result = mysql_query($query);
      if (!$result) $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
      else{ 
        $action='list'; 
        $nav="admin";
      }

      $sqlerror = refreshCache("banners"); 
  }



  //----- REFRESH cache -----------------------------
  // in ZADS 4.9, we use native PHP to do that (to support adsense)
  if (($action=="refreshcache"))
  {

    $sqlerror = refreshCache("banners"); 

  }

  //----- LIST action -----------------------------
  // in ZADS 4.9, we use native PHP to do that (to support adsense)
  if (($action=="list")){
    
    $maxresults=1; 
      
    // other filter / sort and actions
    if (isset($_POST["page"]))$paged = $_POST["page"]+0; else  $paged =1;  
    if (isset($_POST["eppage"])) $eppage =$_POST["eppage"]*1; else  $eppage=50; 
    
    $sort=$_POST["sort"];
    $sortoriginal = $sort;
    $sort=explode("_",$sort); 
    $sort_dir = $sort[1];
    $sort_by = $sort[0];
    
    // filter
    $faction = $_POST["faction"] ;
    $fseverity = $_POST["fseverity"] ;
    $fposition = $_POST["fposition"] ;
    
    $search=trim(secure_var($_POST["search"])); // SECURITY 

    // sorting option 
    if ($sort_by) $sql_sort ="  ORDER BY `$dbThisTable`.`".$sort_by."` ".$sort_dir;
    else 
    $sql_sort.=" ORDER BY `$dbThisTable`.`moddate` DESC ";  

     if ($id) {
        //$filter.="  WHERE `what` IN ('$what') AND `action` NOT IN ('auth','msg','sec','cron','error') AND `whatid` = '$id' ";
        $limit=" LIMIT 0, 30 "; // no limit on the request
      } else {
        // filter
        //if ($what) $filter.="  WHERE `what` IN ('$what')"; 
        $itemstart = ((int)$paged -1) * 50; 
        $limit = "LIMIT ".$itemstart.", 50"; 
      } 
    
    
   if ($eppage) {
          $itemstart = ((int)$paged -1) * $eppage; 
          $limit = "LIMIT ".$itemstart.", $eppage"; 
    } else $limit=" LIMIT 0, 10"; // default limit to protect ! 
    
    
    // other filters conditions : 
    if ($search) {
      $fstub =   " (`title` like  '%".$search."%') ";
      $filter.= ($filter=="") ?  "  WHERE  " : "  AND  "; 
      $filter.= $fstub; 
    }

    if ($fposition) {
      $fstub =   " (`position` =  '".$fposition."') ";
      $filter.= ($filter=="") ?  "  WHERE  " : "  AND  "; 
      $filter.= $fstub; 
    }


  
    // multiple join elements from AD + USER + CATS
    $join = " LEFT OUTER JOIN `$dbUsersTable` ON `$dbThisTable`.`userid`= `$dbUsersTable`.`id` ";
    //$join .= " LEFT OUTER JOIN `$dbItemsTable` ON `$dbLogsTable`.`whatid`= `$dbItemsTable`.`id` ";
    //$join .= " LEFT OUTER JOIN `$dbCatsTable` ON `$dbLogsTable`.`whatid`= `$dbCatsTable`.`id` ";
    
    // make a pre-query to get total list of results 
    $queryfull = "SELECT `$dbThisTable`.`id` FROM `$dbThisTable` " .$filter." ". $sql_sort;
    $resultfull = @mysql_query($queryfull);
    $maxresults = mysql_num_rows($resultfull);
    
    //-- make the full query
    $query = "SELECT `$dbThisTable`.*,`$dbUsersTable`.`username`,  `$dbUsersTable`.`avatarimg` FROM `$dbThisTable` ".$join .$filter." ". $sql_sort . " " . $limit ; 
    $result = @mysql_query($query);
    $totnbrofresults = @mysql_num_rows($result);
     
    $idx=0;
    
    if (($totnbrofresults) && ($totnbrofresults !=0)){
      $idx=0;
      $outdata=""; 
      // first item is generic
      $idx=0;
      while ($row = mysql_fetch_object($result)) { 
        $thistate= explode("|",$row->desc); 
        $thistate = $thistate[0]; 

        $outdata= Array (
              'title'=> stripslashes($row->title), 
              'htmlcode' => stripslashes($row->htmlcode),
              'clicktrackingurl'=>$row->clicktrackingurl,
              'type'=> $row->type, 
              'priority'=> $row->priority,
              'id'=> $row->id,
              'status'=> $row->status,
              'logs'=> $row->logs,
              'clicks'=> $row->clicks,
              'impressions'=> $row->impressions,
              'userid'=> $row->userid,
              'location'=> $row->location,
              'moddate'=> $row->moddate,
              'moddatestamp'=>  strtotime( $row->moddate)*1000, 
              'startdate'=> $row->startdate,
              'startdatestamp'=>  strtotime( $row->startdate)*1000, 
              'enddate'=> $row->enddate,
              'enddatestamp'=>  strtotime( $row->enddate)*1000, 
              'imgpath'=> $dest_path_from_root,
              'imgurl'=> $row->imgname, 
              'position'=> $row->position 
              );

       $datalist[$idx] = $outdata; 
       $idx+=1; 
      }
     } else {
     $datalist = Array ();
     }
    $success=true;
  }

  
  // -- output result ------------- 

  if (!$sqlerror) {
    $msg = "Yay! Everything went well!";
    $success=true;
  }
  else {
    $msg = "Doh! Something happened : ".$sqlerror;
    $success=false;
  }

  $json = array(
      'success' => $success,
      'totnb' =>$maxresults,
      'message'=> $msg,
      'submessage'=> $submessage,
      'action' => "banners",
      'subaction' => $action,
      'what' => $what,
      'nav'=>$nav,
      'sort'=>$sortoriginal,
      'paged' => $paged,
      'eppage'=>$eppage,
      'search'=>$search,
      'fposition'=>$fposition,
      'id' => $id,
      'data' => $datalist
  );
 if ($debug_tmp==1){ // add debug info into the stream when working local
     $json["xdebug"]= array(
              'sqldebug'=> $query,
              'sqlfulldebug'=>$queryfull,
              'filter'=>$filter,
              'laction'=>$laction,
              'corefilter'=>$corefilter
              );  
   }

   if (!$noresulttosend)
      // echo json_encode($json);
      encode_json_and_send_with_compression($json); 
}

// ############# SERVLET FOR USERS and ADS REQUESTS  (ONLY ADMIN for Special cases) ###########################
if (!isset($_POST["action"]) && (isset($_POST["users"]) || isset($_POST["ads"]) || isset($_POST["cats"])) ) {

  if (isset($_POST["users"])) { $inaction="users"; $thewhat="user"; $action=$_POST["users"]; $dbThisTable = $dbUsersTable;}
  if (isset($_POST["ads"])) { $inaction="ads"; $thewhat="ad";  $action=$_POST["ads"];  $dbThisTable = $dbItemsTable;}
  if (isset($_POST["cats"])) { $inaction="cats"; $thewhat="cat";  $action=$_POST["cats"];  $dbThisTable = $dbCatsTable;}
  /* check if user has the right to do so if ok , continue ,  else, page is exited with a special message*/
  check_userRights($inaction, $action); 
  
  // load variables
  $id = $_POST["id"]+0 ;                          // SECURITY - convert to int 
  $ad_id=$id;                                     // backward compatibility
  $userid = $_POST["userid"]+0 ;                  // SECURITY - convert to int 
  $curuserid = $_POST["curuserid"]+0 ;            // SECURITY - convert to int 
  $nav=$_POST["nav"];
  $nav='admin';
 
  // multipurpose variables  
  $msg=""; 
  $filter=""; 
  $sql_sort="";
  $sqlerror='';
  $datalist = Array ();
  
  // ------ DELETION action ----------------------
  if ($action=='delete') {
      // make the delete action 
      delete_files($thewhat, $id);
      sql_delete_item($thewhat, $id); // delete all from an item incuding logs and associated pictures
      $nav='admin';
  }

  // ------ PUBLISH action ----------------------

  if  ($action=="unpublish") {
    $query = "UPDATE `".$dbThisTable."` SET   `status` = '60', `moddate` = '$stamp' WHERE ((`hashid` = '".$hid."')) ";
    $result = @mysql_query($query);
    if (!$result) {$sqlerror=mysql_error();  logfile('error', 'unpublish - '.mysql_error()); }
    else {$toto=1;}
    $status="60";
  }

  if  ($action=="publish") {
    $query = "UPDATE `".$dbThisTable."` SET   `status` = '40', `moddate` = '$stamp' WHERE ((`hashid` = '".$hid."')) ";
    $result = @mysql_query($query);
    if (!$result) logfile('error', 'publish - '.mysql_error());
    else {$toto=1;}
    $status="40";
  }

  // -- output result ------------- 
  if (!$sqlerror) {
    $msg = "Yay! Everything went well!";
    $success=true;
  }
  else {
    $msg = "Doh! Something happened : ".$sqlerror;
    $success=false;
  }

  $json = array(
      'success' => $success,
      'totnb' =>$maxresults,
      'message'=> $msg,
      'action' => $inaction,
      'subaction' => $action,
      'what' => $what,
      'thewhat'=>$thewhat,
      'nav'=>$nav,
      'sort'=>$sortoriginal,
      'paged' => $paged,
      'eppage'=>$eppage,
      'search'=>$search,
      'id' => $id,
      'data' => $datalist
  );
 if ($debug_tmp==1){ // add debug info into the stream when working local
     $json["xdebug"]= array(
              'sqldebug'=> $query,
              'sqlfulldebug'=>$queryfull,
              'filter'=>$filter,
              'laction'=>$laction,
              'corefilter'=>$corefilter
              );  
   }

   if (!$noresulttosend)
      // echo json_encode($json);
      encode_json_and_send_with_compression($json); 
}


// ############# SERVLET FOR VIRTUAL FIELDS  REQUESTS  ###########################
if (isset($_POST["vfields"]) ) {
  $noresulttosend =false;
  
  $dbThisTable = $dbVFieldsTable;

  $vfields = $_POST["vfields"] ;
  $action = "list"; // default action
  $action = $vfields; 

  /* check if user has the right to do so if ok , continue ,  else, page is exited with a special message*/
  check_userRights("vfields", $action); 
  
  // identify selector
  $what = secure_var($_POST["what"]) ;            // SECURITY 
  $laction = secure_var($_POST["laction"]) ;      // SECURITY 
  $id = $_POST["id"]+0 ;                          // SECURITY - convert to int 
  if ($what=="curuser") $what="user";             // patch for current user 
  
  // load variables
  $id = $_POST["id"]+0 ;                          // SECURITY - convert to int 
  $ad_id=$id;                                     // backward compatibility
  $linkedvfield = $_POST["linkedvfield"] ;        // lined vfield
  $userid = $_POST["userid"]+0 ;                  // SECURITY - convert to int 
  $curuserid = $_POST["curuserid"]+0 ;            // SECURITY - convert to int 
  $int_label = secure_var($_POST["int_label"]);           // SECURED
  $disp_label = secure_var($_POST["disp_label"]);           // SECURED
  $values = secure_var($_POST["values"]);           // SECURED
  $unit = secure_var($_POST["unit"]);           // SECURED
  $domtype = secure_var($_POST["domtype"]);             // SECURITY - strip undesired text
  $domsubtype = secure_var($_POST["domsubtype"]);             // SECURITY - strip undesired text
  $stype = secure_var($_POST["stype"]);             // SECURITY - strip undesired text
  $status = secure_var($_POST["forceflag"]) ;     // SECURITY - strip undesired text
  $moddate= $_POST["moddate"] ;
  $scope = secure_var($_POST["scope"]);  
  $forwhat = secure_var($_POST["forwhat"]);  
  $linkedvar = $_POST["linkedvar"] ;        // lined variable
  $slaveid = $_POST["slaveid"]+0 ;        // lined variable

  // Z5.5.1  : extra vfields 
  $xmandatory = secure_var($_POST["xmandatory"]);  
  $xmin = secure_var($_POST["xmin"]);  
  $xmax = secure_var($_POST["xmax"]);  
  $xregx = secure_var($_POST["xregx"]); 
  $xvisible = secure_var($_POST["xvisible"]); 
  $forprofile = secure_var($_POST["forprofile"]);

  // filters 
  $fscope = trim(secure_var($_POST["fscope"])); // SECURITY 
  $fforwhat = trim(secure_var($_POST["fforwhat"])); // SECURITY 

 
  if (isset($_POST["nav"])) $nav=$_POST["nav"]; else $nav='admin'; 


  // multipurpose variables  
  $msg=""; 
  $filter=""; 
  $sql_sort="";
  $sqlerror='';
  $datalist = Array ();
  
  // security check on action 
  //$laction_authorized_values = array("auth", "sec", "cron");


    //----- CREATE/MODIFY/DELETE action -----------------------------
  if (($action=="create") || ($action =="update")){

    // -- BUILD THE QUERY 
    if (($action=="create")){ 
      $query = "INSERT INTO `".$dbThisTable."` 
        ( `userid`, `moddate`, `int_label`, `disp_label`, `values`,`unit`, `domtype`,`domsubtype`,`stype`,`status`,`scope`, `forwhat`, `linkedvfield`,`linkedvar`,`slaveid`,`xmandatory`,`xmin`,`xmax`,`xregx`,`xvisible`,`forprofile`) ";
      $query .= "VALUES ( '$userid', '$stamp', '$int_label', '$disp_label',  '$values','$unit', '$domtype','$domsubtype','$stype','$status', '$scope','$forwhat', '$linkedvfield','$linkedvar','$slaveid','$xmandatory','$xmin', '$xmax',  '$xregx','$xvisible', '$forprofile');";       
    }


    if ($action =="update"){
      $query = "UPDATE `".$dbThisTable."` SET   
        `moddate` = '".$stamp."', 
        `int_label`='".$int_label."',
        `disp_label`= '".$disp_label."',
        `values`='".$values."',
        `unit`='".$unit."',
        `domtype`='".$domtype."',
        `domsubtype`='".$domsubtype."',
         `stype`='".$stype."',
        `status`='".$status."',
        `scope`='".$scope."',
        `forwhat`='".$forwhat."',
        `linkedvfield`='".$linkedvfield."',
        `linkedvar`='".$linkedvar."',
        `slaveid`='".$slaveid."',
        `userid`='".$userid."',
        `xmandatory`='".$xmandatory."',
        `xmin`='".$xmax."',
        `xmax`='".$xmax."',
        `xregx`='".$xregx."',
        `xvisible`='".$xvisible."',
        `forprofile`='".$forprofile."'

        WHERE ((`id` = '".$id."')) ";
      }

    // -- MAKE THE QUERY
    $result = mysql_query($query);  
          
    
    // -- OUTPUT RESULTS 
    $sqlerror=""; 
    if (!$result) $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
    else {
      $action='list'; 
      $nav="admin";
    }
  } // end of CREATE



    //----- ACTION = CLONE -----------------------------
  if ($action=="clone"){

    // -- BUILD THE QUERY 
      $query = "INSERT INTO `".$dbThisTable."` 
        ( `userid`, `moddate`, `int_label`, `disp_label`, `values`,`unit`, `domtype`,`domsubtype`,`stype`,`status`,`scope`, `forwhat`, `linkedvfield`,`linkedvar`,`slaveid`,`xmandatory`,`xmin`,`xmax`,`xregx`,`xvisible`,`forprofile`) ";
      $query .= "SELECT  `userid`, `moddate`, `int_label`, `disp_label`, `values`,`unit`, `domtype`,`domsubtype`,`stype`,`status`,`scope`, `forwhat`, `linkedvfield`,`linkedvar`,`slaveid`,`xmandatory`,`xmin`,`xmax`,`xregx`,`xvisible`,`forprofile` FROM  `".$dbThisTable."`  WHERE ((`id` = '".$id."'));";       
    
      //- MAKE THE QUERY
      $result = mysql_query($query);  
          
    
      // -- OUTPUT RESULTS 
      $sqlerror=""; 
      if (!$result) $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
      else {
        $action='list'; 
        $nav="admin";
      }
  } // end of CLONE







  // ------ DELETION action ----------------------
   if ($action=='delete') {

      // make the delete action 
      $query = "DELETE FROM `".$dbThisTable."`  WHERE ((`id` = '".$id."')) ";
      $result = mysql_query($query);
      if (!$result) $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
      else{ 
        $action='list'; 
        $nav="admin";
      }
  }

  //----- LIST action -----------------------------
  // in ZADS 4.9, we use native PHP to do that (to support adsense)
  if (($action=="list")){
    
    $maxresults=1; 
      
    // other filter / sort and actions
    if (isset($_POST["page"]))$paged = $_POST["page"]+0; else  $paged =1;  
    if (isset($_POST["eppage"])) $eppage =$_POST["eppage"]*1; else  $eppage=300; 
    
    $sort=$_POST["sort"];
    $sortoriginal = $sort;
    $sort=explode("_",$sort); 
    $sort_dir = $sort[1];
    $sort_by = $sort[0];
    
    // filter
    $faction = $_POST["faction"] ;
    $fseverity = $_POST["fseverity"] ;
    
    $search=trim(secure_var($_POST["search"])); // SECURITY 


    // add the search caracteristics 
    // filter for the SEARCH
      if ($search)  {
          $search = trim($search); // delete surrounding spaces
          $searcha = explode(" ", $search); // make array of individual words
          $sfilterAr=array();
  
          //Cycle through the words-array if there are word(s) filled in
          if (isset($searcha)) {

            $sfilterAr[] = " ((lower(`$dbThisTable`.`int_label`) like ";
            $sfilterAr[] = "   ) OR (lower(`$dbThisTable`.`disp_label`) like ";
            $sfilterAr[] = "   ) OR (lower(`$dbThisTable`.`id`) like ";
            
            $searchfilter=""; 
              for($i = 0; $i < count($searcha); $i++) 
              {
                for($j = 0; $j < count($sfilterAr); $j++) {
                  $searchfilter .= $sfilterAr[$j]." '%" . $searcha[$i] . "%' " ;
                }
                $searchfilter .= "))";
                if ($i < count($searcha)-1) $searchfilter.= " AND ";
              }
            if ($filter=="") 
              $filter.="  WHERE (".$searchfilter.") "; 
            else 
              $filter.="  AND (".$searchfilter.") "; 
          }
        }


    // sorting option 
    if ($sort_by) $sql_sort ="  ORDER BY `$dbThisTable`.`".$sort_by."` ".$sort_dir;
    else 
    $sql_sort.=" ORDER BY `$dbThisTable`.`moddate` DESC ";  
    
    if ($eppage) {
          $itemstart = ((int)$paged -1) * $eppage; 
          $limit = "LIMIT ".$itemstart.", $eppage"; 
    } else $limit=" LIMIT 0, 10"; // default limit to protect ! 
    
  
    // add others filters 
    if ($fscope){
      $f_stub = " `$dbThisTable`.`scope` =  '$fscope' ";
      $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
    }

    if ($fforwhat){
      $f_stub = " `$dbThisTable`.`forwhat` =  '$fforwhat' ";
      $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
    }

    
    // multiple join elements from AD + USER + CATS
    $join = " LEFT OUTER JOIN `$dbUsersTable` ON `$dbThisTable`.`userid`= `$dbUsersTable`.`id` ";
    //$join .= " LEFT OUTER JOIN `$dbItemsTable` ON `$dbLogsTable`.`whatid`= `$dbItemsTable`.`id` ";
    //$join .= " LEFT OUTER JOIN `$dbCatsTable` ON `$dbLogsTable`.`whatid`= `$dbCatsTable`.`id` ";
    
    // make a pre-query to get total list of results 
    $queryfull = "SELECT `$dbThisTable`.`id` FROM `$dbThisTable` " .$filter." ". $sql_sort;
    $resultfull = @mysql_query($queryfull);
    $maxresults = mysql_num_rows($resultfull);
    
    //-- make the full query
    $query = "SELECT `$dbThisTable`.*,`$dbUsersTable`.`username`,  `$dbUsersTable`.`avatarimg` FROM `$dbThisTable` ".$join .$filter." ". $sql_sort . " " . $limit ; 
    $result = @mysql_query($query);
    $totnbrofresults = @mysql_num_rows($result);
     
    $idx=0;
    
    if (($totnbrofresults) && ($totnbrofresults !=0)){
      $idx=0;
      $outdata=""; 
      // first item is generic
      $idx=0;
      while ($row = mysql_fetch_object($result)) { 
        $thistate= explode("|",$row->desc); 
        $thistate = $thistate[0]; 

        $outdata= Array (
              'int_label'=> stripslashes($row->int_label), 
              'name'=>stripslashes($row->int_label),  // double naming to simplify 
              'disp_label' => stripslashes($row->disp_label),
              'domtype'=> $row->domtype, 
              'domsubtype'=> $row->domsubtype,
              'stype'=> $row->stype,
              'values'=> $row->values,
              'unit'=> $row->unit,
              'id'=> $row->id,
              'status'=> $row->status,
              'scope'=> $row->scope,
              'forwhat'=> $row->forwhat,
              'linkedvfield'=> $row->linkedvfield,
              'linkedvar'=> $row->linkedvar,
              'slaveid'=> $row->slaveid,
              'xmin'=> $row->xmin,
              'xmax'=> $row->xmax,
              'xvisible'=> $row->xvisible,
              'forprofile'=> $row->forprofile,
              'xmandatory'=> $row->xmandatory,
              'xregx'=> $row->xregx,
              'moddate'=> $row->moddate,
              'moddatestamp'=>  strtotime( $row->moddate)*1000
              
              );
        
        
       $datalist[$idx] = $outdata; 
       $idx+=1; 
      }
     } else {
     $datalist = Array ();
     }
    $success=true;
  }

  // -- output result ------------- 

  if (!$sqlerror) {
    $msg = "Yay! Everything went well!";
    $success=true;
  }
  else {
    $msg = "Doh! Something happened : ".$sqlerror;
    $success=false;
    logfile('error', 'error vfields action '.$sqlerror);
  }

  $json = array(
      'success' => $success,
      'totnb' =>$maxresults,
      'message'=> $msg,
      'action' => "vfields",
      'subaction' => $action,
      'what' => $what,
      'nav'=>$nav,
      'sort'=>$sortoriginal,
      'fscope'=>$fscope,
      'fforwhat'=>$fforwhat,
      'paged' => $paged,
      'search'=>$search,
      'id' => $id,
      'eppage'=>$eppage,
      'data' => $datalist
  );
 if ($debug_tmp==1){ // add debug info into the stream when working local
     $json["xdebug"]= array(
              'sqldebug'=> $query,
              'sqlfulldebug'=>$queryfull,
              'filter'=>$filter,
              'laction'=>$laction,
              'corefilter'=>$corefilter
              );  
   }

   if (!$noresulttosend)
      // echo json_encode($json);
      encode_json_and_send_with_compression($json); 
}


// ############# SERVLET FOR SERVICES ###########################
if (isset($_POST["services"]) ) {
  $noresulttosend =false;
  
  $dbThisTable = $dbServicesTable;

  $services = $_POST["services"] ;
  $action = "list"; // default action
  $action = $services; 
  $what="service";

  /* check if user has the right to do so if ok , continue ,  else, page is exited with a special message*/
  check_userRights("services", $action); 
  

  // specific vars 
  $curuserid = $_POST["curuserid"]+0 ;                  // SECURITY - convert to int
  $pkid=secure_var($_POST["pkid"]) ;// SECURITY - convert to int
  $plid=secure_var($_POST["plid"]) ; // SECURITY - convert to int
  $id = $_POST["id"]+0 ;                  // SECURITY - convert to int


  $nav=$_POST["nav"];

  // multipurpose variables  
  $msg=""; 
  $filter=""; 
  $sql_sort="";
  $sqlerror='';
  $datalist = Array ();
  
  // security check on action 
  //$laction_authorized_values = array("auth", "sec", "cron");


  // get user details
  $lcur_user = get_user_details($curuserid); 

  //----- CREATE/MODIFY/DELETE action -----------------------------
  if (($action=="create") || ($action =="update")  || ($action =="pay")){


    // -- CREATE THE PACK THE first TIME 
    if (($action=="create")) { 

      // check if some trial account are active to transform them to normal services 
      $datalist = db_list_services($curuserid, 'activeorexpiredtrial');
      if (count($datalist)>0) {
        if ($datalist[0]['status']=="80" && $datalist[0]['priority']=="confirmed") $toto=1; 
        else {
          db_setexpiredtrial_services($datalist[0]['id']); 
          // add the NORMAL service item 
          $r=db_services_action('create', $curuserid, 'base-pro', 'basepack'); // add the service
          // attach the new plan to the user
          db_update_field_user('plan', 'base-pro', $curuserid) ; 
        }
      }
      
      // insert into database the services whatever happens 
      $thisusertype="pro"; 
      $r=db_services_action('create', $curuserid, $pkid, $plid, $thisusertype); // add the service
      if (!$r['result']) {$sqlerror =$r["xdebug"]['sqlerror'] ; } 
      else $query = $r["xdebug"]['querydbservices']; // save for the logs 

    }

    // -- CREATE THE PACK THE FISRT TIME 
    if (($action=="pay")) { 
      // insert into database the services
      $thisusertype="pro"; 
      $r=db_list_services_w_paypalinfo($curuserid, $id); // list the service details
      if (!$r['result']) {$sqlerror =$r["xdebug"]['sqlerror'] ; } 
      else $query = $r["xdebug"]['querydbservices']; // save for the logs 

    }

    // -- in call cases, if need to pay -> process to the payment mecanism 
    if ($r['status']==15) {
     
      // launch the do checkput mechanism
      if ($r['p_bom']) {    
        // call the ckechout process
        require_once("paypal.php"); 
        
        // create the invoice tracking number
        $r['p_bom']['gendesc'] = "Your order by ".date( 'Y-m-d', time()); 
        $r['p_bom']['invnum'] = format_invoice_number($what, $curuserid); 

        //var_dump($r); // debug purpose
        $r_checkout = paypal_call_checkout($r['p_bom']);

        // send email to warn everybody and indicate the payment link
        $r['paymenturl'] = $r["CUSTO_REDIRECT_LOCATION"]; 

        // function mySendEmail($emailRT, $what, $state, $dataobj, $useremail){
        $dataobj = db_list_services($curuserid,'', $r['id'],'withuserdetails');
        mySendEmail($emailRoutingTable, $what, $r['status'], $dataobj[0], $lcur_user['email']); 

        // save the token for future use
        if ($r_checkout["CUSTO_SUCCESS"]){
          if ($r['id'] ) // secure 
           db_gen_update_field($dbServicesTable, "payment", "TOKEN=".$r_checkout['CUSTO_TOKEN']." ",$r['id'] );  
        }


        if (!$r_checkout["CUSTO_SUCCESS"]) {
          $msg =  "PAYPAL message : <br>". urldecode($r_checkout['L_LONGMESSAGE0']) . "<br>". urldecode($r_checkout['L_LONGMESSAGE1']);
        } else $msg = $r_checkout["CUSTO_SUCCESS"];

        $json = array(
            'success' => $r_checkout["CUSTO_SUCCESS"] ,
            'message'=>$msg,
            'token'=> $r_checkout["CUSTO_TOKEN"],
            'action' => "paypal-checkout",
            'location' => $r_checkout["CUSTO_REDIRECT_LOCATION"],
            'what' => $what,
            'nav'=>$nav,
            'id' => $ad_id
        );

       if ($debug_tmp==1){ // add debug info into the stream when working local
           $json["xdebug"]= array(
              'sqldebug3' => $queryx,
              'sqldebug2' => $queryy,
              'sqldebug' => $query,
              'r' => $r,
              'paidoptions' =>$rowx->paidoptions,
              'checkoutin'=>$paid_checkout_details_array

            );  
         }
        echo json_encode($json);
        exit ; // action is finished !    
        // exit the function
      } // end check pbom array
    } // end of status 15 


    // update list of services for this user 
    // -- get the total number of PUBLISHED adds from this user  !
    $this_user_id = $curuserid; 
    $datalist = db_list_services($this_user_id); 
              
  } // end of CREATE || UPDATE 


  //----- CONFIRM the subscription  -----------------------------
  if (($action=="confirm")){
      $datalist = db_list_services($curuserid, 'extratrial');
      if (count($datalist)>0) {
        db_setexpiredtrial_services($datalist[0]['id']); // expire the fisrt and only one ! 

        // add the NORMAL service item 
        $r=db_services_action('create', $curuserid, 'base-par', 'basepack'); // add the service

        // attach the new plan to the user
        db_update_field_user('plan', 'base-par', $curuserid) ; 

      // update list of services for this user 
      // -- get the total number of PUBLISHED adds from this user  !
      $this_user_id = $curuserid; 
      $datalist = db_list_services($this_user_id); 

      }

  }

  // ------ DELETION action ----------------------
  if ($action=='delete') {
      // make the delete action 
      $query = "DELETE FROM `".$dbThisTable."`  WHERE ((`id` = '".$id."')) ";
      $result = mysql_query($query);
      if (!$result) $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
      else{ 
        $action='list'; 
        $nav="admin";
      }
  }

  // ------ CANCEL action (can only be done by owner SQL filter on it ! ) ----------------------
  if ($action=='cancel') {
      // make the delete action 
      $query = "DELETE FROM `".$dbThisTable."`  WHERE ((`id` = '".$id."') AND (`userid` = '".$curuserid."')) ";
      $result = mysql_query($query);
      if (!$result) $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
      else {
        // // check if need to go back to initial TRIAL STATUS. 
        $datalist = db_list_services($curuserid,'servicesonly'); // get only services 
        if (count($datalist)>0) {$donothing=1;}
        else {
          // not services ! -> we delete the base and reactivate trial
          $query2 = "DELETE FROM `".$dbThisTable."`  WHERE ((`type` = 'base') AND (`userid` = '".$curuserid."')) ";
          $result2 = mysql_query($query2);
          if (!$result2) {
              $sqlerror2 =  "Could not successfully run query from DB: " . mysql_error(). "--".$query2;
              logfile("error", $sqlerror2 ); 
          }
          else {
            // base deleted, we reactivate the trial pack 
            $datalist = db_list_services($curuserid, 'activeorexpiredtrial');
            db_setexpiredtrial_services($datalist[0]['id'], '40',''); 
          }
        }

        // rsend the output 
        $nav='myservices'; 
        $datalist = db_list_services($curuserid); 
      }
  }

  // ------ UN PUBLISH  action ----------------------
  if  ($action=="unpublish") {
      $query = "UPDATE `".$dbThisTable."` SET   
        `status` = '60',
        `moddate` = '$stamp' 
         WHERE ((`id` = '".$id."'))  ";
     

      $result = mysql_query($query);
      if (!$result) $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
      else{ 
        $action='list'; 
        $nav="admin";
        $status="60";
      }
  }

   // ------ PUBLISH  action ----------------------
  if  ($action=="publish") {
      $query = "UPDATE `".$dbThisTable."` SET   
        `status` = '40',
        `moddate` = '$stamp' 
         WHERE ((`id` = '".$id."'))  ";
     
      $result = mysql_query($query);
      if (!$result) $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
      else{ 
        $action='list'; 
        $nav="admin";
        $status="40";
      }
  }



  //----- LIST action -----------------------------
  // in ZADS 4.9, we use native PHP to do that (to support adsense)
  if (($action=="list")){
    
    $maxresults=1; 
      
    // other filter / sort and actions
    if (isset($_POST["page"]))$paged = $_POST["page"]+0; else  $paged =1;  
    $nav=$_POST["nav"];

    if (isset($_POST["eppage"])) $eppage =$_POST["eppage"]*1;
    else  $eppage=50; 


    $sort=$_POST["sort"];
    $fstatus=$_POST["fstatus"];
    $fuserid=$_POST["fuserid"];

    $sortoriginal = $sort;
    $sort=explode("_",$sort); 
    $sort_dir = $sort[1];
    $sort_by = $sort[0];

    if ($sort_by=="date") $sort_by="startdate"; // patch to adapt to start date  ! 
        
    $search=trim(secure_var($_POST["search"])); // SECURITY 

    // sorting option 
    if ($sort_by) $sql_sort ="  ORDER BY `$dbThisTable`.`".$sort_by."` ".$sort_dir;
    else  $sql_sort.=" ORDER BY `$dbThisTable`.`moddate` DESC ";  
    
    if ($id) {
      $limit=" LIMIT 0, 30 "; // no limit on the request
    } else {
      if ($eppage) {
            $itemstart = ((int)$paged -1) * $eppage; 
            $limit = "LIMIT ".$itemstart.", $eppage"; 
      } else $limit=""; 
    } 

    // case of status filter
    if ($fstatus){
         $f_stub = "((`$dbThisTable`.`status` =  '".$fstatus."'))"; 
         $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub ";    
    }

    // case of USERID filter
    if ($fuserid){
         $f_stub = "((`$dbThisTable`.`userid` =  '".$fuserid."'))"; 
         $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub ";    
    }
    
    // multiple join elements from AD + USER + CATS
    $join = " LEFT OUTER JOIN `$dbUsersTable` ON `$dbThisTable`.`userid`= `$dbUsersTable`.`id` ";
    //$join .= " LEFT OUTER JOIN `$dbItemsTable` ON `$dbLogsTable`.`whatid`= `$dbItemsTable`.`id` ";
    //$join .= " LEFT OUTER JOIN `$dbCatsTable` ON `$dbLogsTable`.`whatid`= `$dbCatsTable`.`id` ";
    
    // make a pre-query to get total list of results 
    $queryfull = "SELECT `$dbThisTable`.`id` FROM `$dbThisTable` " .$join .$filter." ". $sql_sort;
    $resultfull = @mysql_query($queryfull);
    $maxresults = mysql_num_rows($resultfull);
    
    //-- make the full query
    $query = "SELECT `$dbThisTable`.*,`$dbUsersTable`.`username`,  `$dbUsersTable`.`avatarimg` FROM `$dbThisTable` ".$join .$filter." ". $sql_sort . " " . $limit ; 
    $result = @mysql_query($query);
    $totnbrofresults = @mysql_num_rows($result);
     
    $idx=0;
    
    if (($totnbrofresults) && ($totnbrofresults !=0)){
      $idx=0;
      $outdata=""; 
      // first item is generic
      $idx=0;
      while ($row = mysql_fetch_object($result)) { 
        $thistate= explode("|",$row->desc); 
        $thistate = $thistate[0]; 

        $outdata= Array (
            
              'name'=>stripslashes($row->int_label),  // double naming to simplify 
              'sdesc' => stripslashes($row->sdesc),
              'type'=> $row->type,
              'id'=> $row->id,
              'userid'=>$row->userid,
              'username'=>$row->username,
              'avatarimg'=>$row->avatarimg,
              'sid'=> $row->sid,
              'status'=> $row->status,
              'price'=> $row->price,
              'priceid'=> $row->priceid,
              'pricevat'=> $row->pricevat,
              'options'=> $row->options,
              'remain'=> $row->remain,
              'moddate'=> $row->moddate,
              'moddatestamp'=>  strtotime( $row->moddate)*1000,
              'createdate'=> $row->createdate,
              'createdatestamp'=>  strtotime( $row->createdate)*1000,
              'firstpublisheddate'=> $row->firstpublisheddate,
              'firstpublisheddatestamp'=>  strtotime( $row->firstpublisheddate)*1000,
              'startdate'=> $row->startdate,
              'startdatestamp'=>  strtotime( $row->startdate)*1000,
              'enddate'=> $row->enddate,
              'enddatestamp'=>  strtotime( $row->enddate)*1000
              
              );
        
        
       $datalist[$idx] = $outdata; 
       $idx+=1; 
      }
     } else {
     $datalist = Array ();
     }
    $success=true;
  }

  

  // -- output result ------------- 
  if (!$sqlerror) {
    $msg = "Yay! Everything went well!";
    $success=true;
  }
  else {
    $msg = "Doh! Something happened : ".$sqlerror;
    $success=false;
  }

  $json = array(
      'success' => $success,
      'totnb' =>$maxresults,
      'message'=> $msg,
      'action' => "services",
      'subaction' => $action,
      'userid'=>$curuserid,
      'what' => $what,
      'view'=>$vieworiginal,
      'nav'=>$nav,
      'sort'=>$sortoriginal,
      'fscope'=>$fscope,
      'fstatus'=>$fstatus,
      'fuserid'=>$fuserid,
      'search'=>$search,
      'paged' => $paged,
      'eppage'=>$eppage,
      'search'=>$search,
      'thisnb'=>$totnbrofresults,
      'id' => $id,
      'data' => $datalist

  );
 if ($debug_tmp==1){ // add debug info into the stream when working local
     $json["xdebug"]= array(
              'sqldebug'=> $query,
              'sqlfulldebug'=>$queryfull,
              'filter'=>$filter,
              'laction'=>$laction,
              'corefilter'=>$corefilter

              );  
   }

   if (!$noresulttosend)
      echo json_encode($json);
}

// ############# SERVLET FOR PAYMENTS  REQUESTS  ###########################
if (isset($_POST["payments"]) ) {

  $payments = $_POST["payments"] ;
  $action = "list"; // default action
  $action = $payments; 
  
  /* check if user has the right to do so if ok , continue ,  else, page is exited with a special message*/
  check_userRights("payments", $action); 
  
  // correction past the ckeck 
  if ($payments=="stats") $action="list"; 

  // identify selector
  $what = secure_var($_POST["what"]) ;            // SECURITY 
  $laction = secure_var($_POST["laction"]) ;      // SECURITY 
  $id = $_POST["id"]+0 ; 
  $tid = secure_var($_POST["tid"]) ;              // SECURITY 
  if ($what=="curuser") $what="user"; // patch for current user 
  
  $maxresults=1; 

  if (isset($_POST["page"]))$paged = $_POST["page"]+0; else  $paged =1;  
  if (isset($_POST["eppage"])) $eppage =$_POST["eppage"]*1; else  $eppage=50; 

  $nav=$_POST["nav"];
  
  $sort=$_POST["sort"];
  $sortoriginal = $sort;
  $sort=explode("_",$sort); 
  $sort_dir = $sort[1];
  $sort_by = $sort[0];
  
  // filter
  $faction = $_POST["faction"] ;
  $fseverity = $_POST["fseverity"] ;
  $fwhat = trim(secure_var($_POST["fwhat"]));
  $search=trim(secure_var($_POST["search"])); // SECURITY 
  $ftime=trim(secure_var($_POST["ftime"])); // SECURED 
  $fuserid = $_POST["fuserid"]+0 ; // SECURED 
  $forceduserid =  trim(secure_var($_POST["forceduserid"]));
  $curuserid = $_POST["curuserid"]+0 ; // SECURED 
  $frecurrent=trim(secure_var($_POST["frecurrent"])); // SECURED 
    
  $msg=""; 
  $filter=""; 
  $sql_sort="";

  $isrecurrent=false; 
  
  // security check on action 
  $laction_authorized_values = array("auth", "sec", "cron");

  // extra elements to display them into the invoice 
  if (isset($_POST["inwhat"])) $inwhat = $_POST["inwhat"]; else  $inwhat ='';
  if (isset($_POST["inid"])) $inid = $_POST["inid"]; else  $inid ='';  
  if (isset($_POST["inuserid"])) $inuserid = $_POST["inuserid"]; else  $inuserid ='';    

  //----- DETAILS  action -----------------------------
  if ($action=="details" || $action=="detailsinvoice"){
    $in_array= Array ();
    $out_array=Array(); 
    // get TRANSACTIONNIDID and 
    // TODO  = CHECK THAT YOU ARE OWNER OF THIS TRANSACTION ! 
   
    if ($tid && $curuserid ){
      // requery to get the WHAT
      $filter = " WHERE `$dbPaymentsTable`.`transactionid` =  '$tid' ";
      $limit = ' LIMIT 0 , 1 ';
      $query0 = "SELECT `$dbPaymentsTable`.`what` FROM `$dbPaymentsTable` " .$filter." " . $limit ; 
      $result0= mysql_query($query0);
      if (!$result0)logfile('error', 'error in payment pre-search '.mysql_error());
      else { 
        $row0 = mysql_fetch_object($result0);
        $thiswhat=$row0->what; 
      }

      // retrieve from the transvtion who the owner is and add more infos to it 
      // multiple join elements from AD + USER + CATS
      if ($thiswhat=="user") {
        $join = " LEFT OUTER JOIN `$dbUsersTable` ON `$dbPaymentsTable`.`whatid`= `$dbUsersTable`.`id` ";
      } else {
        $join = " LEFT OUTER JOIN `$dbUsersTable` ON `$dbPaymentsTable`.`userid`= `$dbUsersTable`.`id` ";
      }
      $join .= " LEFT OUTER JOIN `$dbItemsTable` ON `$dbPaymentsTable`.`whatid`= `$dbItemsTable`.`id` ";
      $join .= " LEFT OUTER JOIN `$dbCatsTable` ON `$dbPaymentsTable`.`whatid`= `$dbCatsTable`.`id` ";
      $sql_sort=' ';
      $limit = ' LIMIT 0 , 1 '; 
      $filter = " WHERE `$dbPaymentsTable`.`transactionid` =  '$tid' ";
      $query = "SELECT `$dbPaymentsTable`.*, `$dbUsersTable`.`username`, `$dbUsersTable`.`firstname`, `$dbUsersTable`.`lastname`, `$dbUsersTable`.`protype`,`$dbUsersTable`.`location`, `$dbUsersTable`.`procpny`, `$dbUsersTable`.`email`,`$dbUsersTable`.`avatarimg`, `$dbItemsTable`.`title` as adtitle, `$dbCatsTable`.`title` as cattitle FROM `$dbPaymentsTable` ".$join .$filter." ". $sql_sort . " " . $limit ; 
      $result = mysql_query($query);
      if (!$result )logfile('error', 'error in payment identification '.mysql_error());
      else {

        // get complementary elements from first sql query
        $row = mysql_fetch_object($result);
        $orig_obj=$row;

        require_once("paypal.php"); 
        if ($row->recurrent=="yes"){
          $in_array["profileid"] = $tid;
          $out_array = paypal_get_recuring_payment_details($in_array); 
          $isrecurrent=true; 


        } else {
          $in_array["transactionid"] = $tid; 
          $out_array = paypal_get_transaction_details($in_array); 
        }
        $loglist = $out_array; // allocate array to output
        $success=true;

        
       } 
     } else {
          $success=false; 
          $msg = "invalid TRANSACTION request"; 
     }
  }


  
  //----- LIST action -----------------------------
  if ($action=="list"){

    // other filter / sort and actions
    if (isset($_POST["page"]))$paged = $_POST["page"]+0; else  $paged =1;  
    if (isset($_POST["eppage"])) $eppage =$_POST["eppage"]*1; else  $eppage=20; 

    // sorting option 
    if ($sort_by) $sql_sort ="  ORDER BY `$dbPaymentsTable`.`$dbPaymentsTable`.`".$sort_by."` ".$sort_dir;
    else 
    $sql_sort.=" ORDER BY `$dbPaymentsTable`.`paymentdate` DESC ";  
    
    if ($id && $id>0) {
      $filter.="  WHERE `$dbPaymentsTable`.`what` IN ('$what') AND `$dbPaymentsTable`.`action` NOT IN ('auth','msg','sec','cron','error') AND `whatid` = '$id' ";
      $limit=" LIMIT 0, 30 "; // no limit on the request
    } else {
      // filter
      if ($fwhat) $filter.="  WHERE `$dbPaymentsTable`.`what` IN ('$fwhat')"; 
      $itemstart = ((int)$paged -1) * $eppage; 
      $limit = "LIMIT ".$itemstart.", $eppage"; 

    } 
    
    // search condition
    if ($search)  
      if ($filter=="")  $filter.="  WHERE ((`$dbPaymentsTable`.`transactionid` =  '".$search."') OR (`$dbPaymentsTable`.`whatid` =  '".$search."') OR (`$dbItemsTable`.`title` like  '%".$search."%') OR (`$dbCatsTable`.`title` like  '%".$search."%') OR (`$dbUsersTable`.`username` like  '%".$search."%'))  "; 
      else  $filter.="  AND ((`$dbPaymentsTable`.`transactionid` =  '".$search."') OR (`$dbPaymentsTable`.`whatid` = '".$search."') OR (`$dbItemsTable`.`title` like  '%".$search."%') OR (`$dbCatsTable`.`title` like  '%".$search."%') OR (`$dbUsersTable`.`username` like  '%".$search."%')) ";

    // time filter 
    if ($ftime && ($ftime!="all")) {
      // get some global date & time variables 
      $todayweeknbr = date("W") ; 
      $todaymonthnbr = date("m") ; // with 0
      $todayyearnbr=date("Y"); // 4 char year
      $stamp= date( 'Y-m-d H:i:s', time());

      $datefield = "paymentdate"; 

      if ($ftime=="thismonth") $fstub .= "  $datefield like '%-$todaymonthnbr-%' "; 
      if ($ftime=="thisyear") $fstub .= "  $datefield like '$todayyearnbr-%' ";
      if ($ftime=="thisquarter")  {
        $curq= ceil(($todaymonthnbr*1)/3); 
        $fstub .= "  ( "; 
        for($q = 1; $q < 4; $q++) {
         $tq=  ($curq-1)*3+$q; if ($tq<10) $tq="0".$tq;          
         $fstub .= " $datefield like '%-$tq-%' ";
         if ($q!=3) $fstub .= " OR "; 
        }
        $fstub .= " ) "; 
      }
      if ($filter=="")  $filter.="  WHERE $fstub "; else $filter.="  AND $fstub "; 

    }

    // other filters conditions : 
    if ($faction || $fseverity){
      if ($faction){
        if ($faction=="lc") {
            $tmpstr=""; 
            foreach ($laction_authorized_values as $value) {
              $tmpstr .= " '".$value."',"; 
            } $tmpstr = substr($tmpstr, 0,strlen($tmpstr)-1); //remove the last ','
             $corefilter= " `action` NOT IN ( $tmpstr ) "; 
        } else $corefilter = "((`action` =  '".$faction."'))"; 
        if ($filter=="")  $filter.="  WHERE $corefilter "; else $filter.="  AND $corefilter "; 
         
      }      
      if ($fseverity){
        $corefilter = "((`severity` =  '".substr($fseverity,1)."'))"; 
        if ($filter=="")  $filter.="  WHERE $corefilter "; else $filter.="  AND $corefilter ";         
      }
    }

    // filter per user id
    if ($fuserid || $forceduserid=="self" || !$curuser_is_admin){
      $tuserid = ($fuserid)? $fuserid : $curuserid;
      $f_stub = " `$dbPaymentsTable`.`userid` =  '$tuserid' OR `$dbPaymentsTable`.`whatid` =  '$tuserid' ";
      $filter.=($filter=="") ? " WHERE ( $f_stub ) " : " AND ( $f_stub ) "; 
    }

    // filter per recurrent
    if ($frecurrent){
      $f_stub = " `$dbPaymentsTable`.`recurrent` =  '$frecurrent' ";
      $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
    }


    // multiple join elements from AD + USER + CATS
    $join = " LEFT OUTER JOIN `$dbUsersTable` ON `$dbPaymentsTable`.`userid`= `$dbUsersTable`.`id` ";
    $join .= " LEFT OUTER JOIN `$dbItemsTable` ON `$dbPaymentsTable`.`whatid`= `$dbItemsTable`.`id` ";
    $join .= " LEFT OUTER JOIN `$dbCatsTable` ON `$dbPaymentsTable`.`whatid`= `$dbCatsTable`.`id` ";
    
    // make a pre-query to get total list of results 
    $queryfull = "SELECT `$dbPaymentsTable`.`id` FROM `$dbPaymentsTable` "  .$filter." ". $sql_sort;
    $resultfull = mysql_query($queryfull);
    $maxresults = mysql_num_rows($resultfull);
    if (!$resultfull )logfile('error', 'error in payments/list - tot results '.mysql_error());
    

    //-- make the full query
    $query = "SELECT `$dbPaymentsTable`.*,`$dbUsersTable`.`username`,  `$dbUsersTable`.`avatarimg`, `$dbItemsTable`.`title` as adtitle, `$dbCatsTable`.`title` as cattitle FROM `$dbPaymentsTable` ".$join .$filter." ". $sql_sort . " " . $limit ; 
    $result = mysql_query($query);
    $totnbrofresults = mysql_num_rows($result);
    if ($result )logfile('error', 'error in payments/list '.mysql_error());

     
    $idx=0;
    
    if (($totnbrofresults) && ($totnbrofresults !=0)){
      $idx=0;
      $outdata=""; 
      // first item is generic
      $loglist = Array ();
      $idx=0;
      while ($row = mysql_fetch_object($result)) { 
        $thistate= explode("|",$row->desc); 
        $thistate = $thistate[0]; 
        $outdata = Array (
            'id' => $row->id ,
            'paymentdate' => $row->paymentdate ,
            'transactionid'=> $row->transactionid,
            'paymentstatus'=> $row->paymentstatus,
            'what'=> $row->what, 
            'whatid'=> $row->whatid,
            'userid'=> $row->userid,
            'username'=> stripslashes($row->username),
            'imgurl'=> $row->avatarimg,
            'imgpath'=> $dest_path_from_root_user,
            'adtitle'=>stripslashes($row->adtitle),
            'cattitle'=>stripslashes($row->cattitle),
            'desc'=> $row->desc,
            'state'=> $thistate, // sent twice to help publication status
            'payerid'=> $row->payerid,
            'amt'=> $row->amt,
            'currencycode'=> $row->currencycode,
            'vat'=> $row->vat,
            'recurrent'=> $row->recurrent,
            'bom'=> $row->bom,
            'token'=> $row->token,
            'note'=> $row->note
            );
       $loglist[$idx] = $outdata; 
       $idx+=1; 
      }
     } else {

      $loglist = Array ();
     }
    $success=true;
  }
  // ----------- LOG DELETION ----------------------
  else if ($action=='delete') {

      if (in_array($laction, $laction_authorized_values)) {
        // make the delete action 
        $query = "DELETE FROM `".$dbLogsTable."`  WHERE ((`action` = '".$laction."')) ";
        $result = @mysql_query($query);
        if (!$result) $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
      } else $sqlerror="unknown value for filed to be deleted"; 
      
      if (!$sqlerror) {
        $msg = "Yay! Everything went well!";
        $success=true;
      }
      else {
        $msg = "Doh! Something happened : ".$sqlerror;
        $success=false;
        }
  }
  
  // -- output result ------------- 
  $json = array(
      'success' => $success,
      'totnb' =>$maxresults,
      'message'=> $msg,
      'action' => "payments",
      'subaction' => $action,
      'what' => $what,
      'nav'=>$nav,
      'sort'=>$sortoriginal,
      'paged' => $paged,
      'eppage'=>$eppage,
      'search'=>$search,
      'fseverity'=>$fseverity,
      'faction'=>$faction,
      'fwhat'=>$fwhat,
      'ftime'=>$ftime,
      'frecurrent'=>$frecurrent,
      'isrecurrent'=>$isrecurrent,
      'id' => $id,
      'data' => $loglist,
      'orig_obj'=>$orig_obj
  );
 if ($debug_tmp==1){ // add debug info into the stream when working local
     $json["xdebug"]= array(
              'sqldebug'=> $query,
              'sqlfulldebug'=>$queryfull,
              'filter'=>$filter,
              'laction'=>$laction,
              'corefilter'=>$corefilter,
              'forceduserid'=>$forceduserid,
              'curuserid'=>$curuserid,
              'id'=>$id
              );  
   }
 
  // echo json_encode($json);
  encode_json_and_send_with_compression($json); 
}

function updateStrAsJson($initValueStr, $key, $whatToDo){
  
  //find back the key
  // $json = '{"a":1,"b":2,"c":3,"d":4,"e":5}';
  $initValueArr = json_decode(stripslashes($initValueStr)) ;
  // var_dump($initValueArr);
  if (array_key_exists($key, $initValueArr)){
    if ($whatToDo=='+1') $initValueArr->$key +=1 ; 
    else if ($whatToDo=='-1') $initValueArr->$key -=1 ; 
    else  $initValueArr->$key = $whatToDo; 
  } else {
    $initValueArr->$key = (int) $whatToDo ;
  }
  return json_encode( $initValueArr); 
}



// ############# SERVLET FOR SECURED FIELD GET ###########################
if (isset($_POST["secureget"]) ) {
  $success=false; 

  $field=secure_var($_POST["secureget"]) ;  
  $what = secure_var($_POST["what"]) ;            // SECURITY 
  $id = $_POST["id"]+0 ; 
  $dbThisTable = ($what=="ad" ? $dbItemsTable : $dbUsersTable ); 

  if (in_array($field,array('email','phone'))){
    if ($id && $id>0) {
      $filter.="  WHERE `$dbThisTable`.`id` = '$id' ";
      $limit=" LIMIT 0, 1 "; // no limit on the request
    
      //-- make the full query
      $query = " SELECT `$dbThisTable`.`$field` as fieldvalue, `$dbThisTable`.`vcounters` as vcounters  FROM `$dbThisTable` $filter $limit " ; 
      $result = mysql_query($query);
      $totnbrofresults = mysql_num_rows($result);
      if (!$result)logfile('error', 'error in securet '.mysql_error());
      else {
        // create the email image and retun it 
        $row = mysql_fetch_object($result) ; 
        // echo $row->fieldvalue; 
        $imgData = base64_encode(text_2_image(stripslashes($row->fieldvalue))); 
        $success=true; 

        //Z6.8 is some counters are activated, update them
        $newvalue= updateStrAsJson($row->vcounters, $field, '+1'); 
        $query2 = "UPDATE `$dbThisTable` SET  
          `$dbThisTable`.`vcounters` = '$newvalue' $filter "; 
        $result2 = mysql_query($query2);
        if (!$result2) logfile('error', 'error in secureget - update vcounters '.mysql_error());
      }
    } // end id is defined

  } else {
    // case of error
    $s=false; 
  }

  // send the result
  $json = array(
        'action'=> 'secureget', 
        'field'=>$field,
        'success' => $success,
        'id'=>$id, 
        'imgdata'=>$imgData
    );

  // if ($debug_tmp==1){ // add debug info into the stream when working local
  //   }
  // echo json_encode($json);
  encode_json_and_send_with_compression($json); 

}

// ############# SERVLET FOR BOOKINGS ###########################
if (isset($_POST["bookings"]) ) {

  $bookings = $_POST["bookings"] ;
  $action = "list"; // default action
  $action = $bookings; 
  $dbThisTable = $dbBookingsTable; 
  
  /* check if user has the right to do so if ok , continue ,  else, page is exited with a special message*/
  check_userRights("bookings", $action); 
  
  // identify selector
  $what = secure_var($_POST["what"]) ;            // SECURITY 
  $laction = secure_var($_POST["laction"]) ;      // SECURITY 
  $id = $_POST["id"]+0 ; 

  // content
  $bo_start_date = secure_var($_POST["bo_start_date"]) ; 
  $bo_end_date = secure_var($_POST["bo_end_date"]) ; 
  $type = secure_var($_POST["type"]) ; 
  $status = secure_var($_POST["forceflag"]) ; 
  $bo_ad_id = secure_var($_POST["bo_ad_id"]) ; 
  $bo_gender = secure_var($_POST["bo_gender"]) ; 
  $bo_firstname = secure_var($_POST["bo_firstname"]) ; 
  $bo_lastname = secure_var($_POST["bo_lastname"]) ; 
  $bo_email = secure_var($_POST["bo_email"]) ; 
  $bo_location = secure_var($_POST["bo_location"]) ; 
  $bo_phone = secure_var($_POST["bo_phone"]) ;
  $bo_nbadults = secure_var($_POST["bo_nbadults"]) ; 
  $bo_comments = secure_var($_POST["bo_comments"]) ; 
  $bo_title = secure_var($_POST["bo_title"]) ; 
  $bo_name2 = secure_var($_POST["bo_name2"]) ; 


  $nav=$_POST["nav"];
  
  $sort=$_POST["sort"];
  $sortoriginal = $sort;
  $sort=explode("_",$sort); 
  $sort_dir = $sort[1];
  $sort_by = $sort[0];
  

  //common
  $curuserid = $_POST["curuserid"]+0 ; // SECURED 
  $userid = $_POST["userid"]+0 ; // SECURED 

  // filter
  $faction = $_POST["faction"] ;
  $fseverity = $_POST["fseverity"] ;
  $fwhat = trim(secure_var($_POST["fwhat"]));
  $search=trim(secure_var($_POST["search"])); // SECURITY 
  $ftime=trim(secure_var($_POST["ftime"])); // SECURED 
  $fuserid = $_POST["fuserid"]+0 ; // SECURED 
  $fadid = $_POST["fadid"]+0 ; // SECURED 
  $fstatus = secure_var($_POST["fstatus"]) ; 

  // indicate this is an inline display area for a given ID   
  $inlinefor =  $_POST["inlinefor"]+0 ; // SECURED 
  if ($action=="load" && $fadid) $inlinefor=$fadid; 

  $msg=""; 
  $filter=""; 
  $sql_sort="";
  $success=false; 
  $view_mode ='';

  $maxresults=1; 

  if (isset($_POST["page"]))$paged = $_POST["page"]+0; else  $paged =1;  
  if (isset($_POST["eppage"])) $eppage =$_POST["eppage"]*1; else  $eppage=50; 

  //----- LIST action -----------------------------
  if ($action=="list" || $action=="load"){



    // other filter / sort and actions
    if (isset($_POST["page"]))$paged = $_POST["page"]+0; else  $paged =1;  
    if (isset($_POST["eppage"])) $eppage =$_POST["eppage"]*1; else  $eppage=50; 

    // sorting option 
    if ($sort_by) $sql_sort ="  ORDER BY `$dbThisTable`.".$sort_by."` ".$sort_dir;
    else $sql_sort.=" ORDER BY `$dbThisTable`.`bo_moddate` DESC ";  
    
    if ($id && $id>0) {
      $filter.="  WHERE `$dbThisTable`.`id` = '$id' ";
      $limit=" LIMIT 0, 30 "; // no limit on the request
    } else {
      $itemstart = ((int)$paged -1) * $eppage; 
      $limit = "LIMIT ".$itemstart.", $eppage"; 
    } 
    
    // search condition
    // if ($search)  
    //   if ($filter=="")  $filter.="  WHERE ((`$dbThisTable`.`transactionid` =  '".$search."') OR (`$dbThisTable`.`whatid` =  '".$search."') OR (`$dbThisTable`.`title` like  '%".$search."%') OR (`$dbCatsTable`.`title` like  '%".$search."%') OR (`$dbUsersTable`.`username` like  '%".$search."%'))  "; 
    //   else  $filter.="  AND ((`$dbThisTable`.`transactionid` =  '".$search."') OR (`$dbThisTable`.`whatid` = '".$search."') OR (`$dbThisTable`.`title` like  '%".$search."%') OR (`$dbCatsTable`.`title` like  '%".$search."%') OR (`$dbUsersTable`.`username` like  '%".$search."%')) ";

    // filter per AD ID 
    if (($fadid)) {
      $f_stub = " `$dbThisTable`.`bo_ad_id` =  '$fadid' ";
      $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
    
      // check is owner   
      if (!$curuser_is_admin) {
        $query_owner = "SELECT `userid` FROM `$dbItemsTable` WHERE `id`='$fadid' AND `userid`='$curuserid' "; 
        $result_owner = @mysql_query($query_owner);
        if ($result_owner && mysql_num_rows($result_owner)) 
          { $curuser_is_owner=true; } 
        else logfile('error', 'error in bookings/list/wheck owver  '.mysql_error());
      }
    }

    // view mode 
    if ($curuser_is_admin || $curuser_is_owner) {
      $view_mode = 'extended';
    }  

    // limite to current user id if not administrator
    if (!$curuser_is_admin && $curuserid){
      $f_stub = " `$dbThisTable`.`userid` =  '$curuserid' ";
      $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
    }

    // status filter   
    // apply a filter on status (only publiched is not admin or owner)  
    if ($view_mode!='extended'){
      $f_stub = " `$dbThisTable`.`status` =  '40' ";
      $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
    } else {
      $f_stub=""; 
      if ($fstatus=="pending")  $f_stub = " `$dbThisTable`.`status` =  '20' ";
      if ($f_stub) $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
    }

   
    // multiple join elements from AD + USER + CATS
    $join = " LEFT OUTER JOIN `$dbUsersTable` ON `$dbThisTable`.`userid`= `$dbUsersTable`.`id` ";
    $join .= " LEFT OUTER JOIN `$dbItemsTable` ON `$dbThisTable`.`bo_ad_id`= `$dbItemsTable`.`id` ";
    
    // make a pre-query to get total list of results 
    $queryfull = "SELECT `$dbThisTable`.`id` FROM `$dbThisTable` "  .$filter." ". $sql_sort;
    $resultfull = mysql_query($queryfull);
    $maxresults = mysql_num_rows($resultfull);
    if (!$resultfull ) logfile('error', 'error in bookings/list - tot results '.mysql_error());
    
    //-- make the full query
    $query = "SELECT `$dbThisTable`.*,`$dbUsersTable`.`username`,  `$dbUsersTable`.`avatarimg`, `$dbItemsTable`.`title` as adtitle FROM `$dbThisTable` ".$join .$filter." ". $sql_sort . " " . $limit ; 
    $result = mysql_query($query);
    $totnbrofresults = mysql_num_rows($result);
    if (!$result )logfile('error', 'error in bookings/list '.mysql_error());

    $idx=0;



    if ($action=="load" && !$curuser_is_admin && !$curuser_is_owner)  $view_mode = 'short';


    if (($totnbrofresults) && ($totnbrofresults !=0)){
      $idx=0;
      $outdata=""; 
      // first item is generic
      $loglist = Array ();
      $idx=0; $lastupdate=''; 
      while ($row = mysql_fetch_object($result)) { 
        $thistate= explode("|",$row->desc); 
        $thistate = $thistate[0]; 
        $outdata = Array (
            'id' => $row->id ,
            'bo_start_date' => $row->bo_start_date ,
            'bo_end_date'=> $row->bo_end_date,
            'type'=> $row->type,
            'status'=> $row->status,
            );
        // keep track of last update date
        if ($row->bo_moddate >  $lastupdate) $lastupdate=$row->bo_moddate;

         // extended mode  
        if ($view_mode=="extended"){
            $outdata['bo_ad_id']=$row->bo_ad_id;
            $outdata['bo_moddate']=$row->bo_moddate;
            $outdata['adtitle']=$row->adtitle;
            $outdata['username']=$row->username;
            $outdata['bo_gender']=$row->bo_gender;
            $outdata['bo_firstname']=stripslashes($row->bo_firstname);
            $outdata['bo_lastname']=stripslashes($row->bo_lastname);
            $outdata['bo_email']=stripslashes($row->bo_email);
            $outdata['bo_phone']=stripslashes($row->bo_phone);
            $outdata['bo_location']=stripslashes($row->bo_phone);
            $outdata['bo_nbadults']=$row->bo_nbadults;
            $outdata['bo_comments']=stripslashes($row->bo_comments);
            $outdata['userid']=$row->userid;
            $outdata['bo_title']=stripslashes($row->bo_title);
            $outdata['bo_createdate']=$row->bo_createdate ;
        }

       $loglist[$idx] = $outdata; 
       $idx+=1; 
      }
     } else {
      $loglist = Array ();
     }
    $success=true;
  }
  // ----------- LOG DELETION ----------------------
  else if ($action=='delete') {

      // make the delete action 
      $query = "DELETE FROM `".$dbThisTable."`  WHERE ((`id` = '".$id."')) ";
      $result = @mysql_query($query);
      if (!$result)  { 
        $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
        logfile('error',$sqlerror);
        $msg = "Doh! Something happened : ".$sqlerror;
        $success=false;
      } else {
        $msg = "Yay! Everything went well!";
        $success=true;
      }
    
  } else 
  //----- CREATE/MODIFY/DELETE action -----------------------------
  if (($action=="create") || ($action =="update")){

    // -- BUILD THE QUERY 
    if (($action=="create")){ 
      $query = "INSERT INTO `".$dbThisTable."` 
        ( `userid`, `bo_createdate`, `bo_moddate`,  `bo_title`,`bo_name2`,`bo_start_date`, `bo_end_date`, `type`,`status`,`bo_ad_id`, `bo_gender`, `bo_firstname`, `bo_lastname`,`bo_email`,`bo_location`,`bo_phone`,`bo_comments`,`bo_nbadults`) ";
      $query .= "VALUES ( '$userid', '$stamp', '$stamp', '$bo_title', '$bo_name2', '$bo_start_date', '$bo_end_date',  '$type','$status', '$bo_ad_id','$bo_gender','$bo_firstname','$bo_lastname','$bo_email', '$bo_location','$bo_phone', '$bo_comments','$bo_nbadults');";       
    }


    if ($action =="update"){
      $query = "UPDATE `".$dbThisTable."` SET   
        `bo_moddate` = '".$stamp."', 
        `bo_start_date` = '".$bo_start_date."',
        `bo_end_date` = '".$bo_end_date."',
        `type` = '".$type."',
        `status` = '".$status."',
        `bo_ad_id` = '".$bo_ad_id."',
        `bo_gender` = '".$bo_gender."',
        `bo_firstname` = '".$bo_firstname."',
        `bo_lastname` = '".$bo_lastname."',
        `bo_email` = '".$bo_email."',
        `bo_location` = '".$bo_location."',
        `bo_phone` = '".$bo_phone."',
        `bo_comments` = '".$bo_comments."',
        `bo_nbadults` = '".$bo_nbadults."',
        `bo_title` = '".$bo_title."',
        `bo_name2` = '".$bo_name2."'        
        WHERE ((`id` = '".$id."')) ";
      }

    // -- MAKE THE QUERY
    $result = mysql_query($query);  
          
    
    // -- OUTPUT RESULTS 
    $sqlerror=""; 
    if (!$result) {
      $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
      logfile('error',$sqlerror); 
    } else {
      $success=true; 
    }
  } // end of CREATE


  if ($view_mode=='short'){
      $json = array(
        'success' => $success,
        'action' => "bookings",
        'subaction' => $action,
        'data' => $loglist,
        'fadid' => $fadid,
        'lastupdate'=>$lastupdate
      );
  } else {
    // -- output result ------------- 
    $json = array(
        'success' => $success,
        'totnb' =>$maxresults,
        'message'=> $msg,
        'action' => "bookings",
        'subaction' => $action,
        'what' => $what,
        'nav'=>$nav,
        'sort'=>$sortoriginal,
        'paged' => $paged,
        'eppage'=>$eppage,
        'search'=>$search,
        'fseverity'=>$fseverity,
        'faction'=>$faction,
        'fwhat'=>$fwhat,
        'ftime'=>$ftime,
        'id' => $id,
        'fadid' => $fadid,
        'data' => $loglist,
        'inlinefor'=>$inlinefor,
        'orig_obj'=>$orig_obj,
        'lastupdate'=>$lastupdate, 
        'isowner'=>$curuser_is_owner
    );
  }

 if ($debug_tmp==1){ // add debug info into the stream when working local
     $json["xdebug"]= array(
              'sqldebug'=> $query,
              'sqlfulldebug'=>$queryfull,
              'filter'=>$filter,
              'laction'=>$laction,
              'corefilter'=>$corefilter,
              'forceduserid'=>$forceduserid,
              'curuserid'=>$curuserid,
              'id'=>$id
              );  
   }

  // ob_start('ob_gzhandler');
  // echo json_encode($json);
  encode_json_and_send_with_compression($json); 
}


// ############# SERVLET FOR PAYPAL  REQUESTS  ###########################
if (isset($_POST["paypal"]) ) {

  // var declartion
  $sqlerror=""; $paid_checkout_details_array= Array ();
  $success=false; 

  $what="ad"; 
  $what2='';
  $nav="home"; 
  $found=false; 

  $xprotype=''; 

  // load the library 
  require_once("paypal.php"); 

  $paypalaction = $_POST["paypal"] ;



  // this is called when CHECKOUT HAS BEEN DONE PROPELY done  
  if ($paypalaction=="success"){
    $action= "paypal-success";  

    //paypal:success
    //token:EC-9D252918TC738063U
    //PayerID:3W4V956LY7VC2
    //curuserid:21 // added from ZADS site 

    $token = $_POST["token"] ;
    $PayerID = $_POST["PayerID"] ;
    $curuserID = $_POST["curuserid"];

    // get detail on current user
    // if (isset($_POST["curuserid"])) $lcur_user = get_user_details($curuserID); 

    // retrieve the article in order to find the correct  amount to be 
    $filter="WHERE i.`payment`='TOKEN=".$token."'"; 
    $query = "  SELECT i.`id`, i.`paidoptions`, i.`userid`, c.`pid`, u.`protype`  FROM `$dbItemsTable` i   
                LEFT JOIN `$dbCatsTable` c ON i.`catid`= c.`id` 
                LEFT JOIN `$dbUsersTable` u ON i.`userid`= u.`id`
              " .$filter; 
    $result = mysql_query($query);

    if (!$result) {
        $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
        logfile('error',$sqlerror, __LINE__); 
    }
    else {
      $maxresults = mysql_num_rows($result);
       if ($maxresults==1){
          // found one reference , this is an AD ! 
          $what2="ad"; 
          $found=true; 
          $dbThisTable2=$dbItemsTable; 
       } else {
          // make the query on the user table 
          $query = "SELECT i.`id`, i.`paidoptions`, i.`protype`, i.`id` AS `userid` FROM `$dbUsersTable` i " .$filter; 
           $result = mysql_query($query);
            if (!$result) {
                $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
                logfile('error',$sqlerror); 
            } else {
            $maxresults = mysql_num_rows($result);
             if ($maxresults==1){
               
                // found one reference ! ths is a USER 
                $what2="user"; 
                $found=true; 
                $dbThisTable2=$dbUsersTable; 
                
              }
              else {
              // make the query on the SERVICE table 
                 $query = "SELECT i.`id`, i.`name`, i.`sid`, i.`sdesc`,i.`priceid`,i.`price`, i.`paidoptions`, u.`protype`, i.`userid` FROM `$dbServicesTable` i 
                          LEFT JOIN `$dbUsersTable` u ON i.`userid`= u.`id`
                          " .$filter; 

                 $result = mysql_query($query);
                  if (!$result) {
                      $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
                      logfile('error',$sqlerror); 
                  } else {
                  $maxresults = mysql_num_rows($result);
                   if ($maxresults==1){
                      // found one reference ! ths is a USER 
                      $what2="service"; 
                      $found=true; 
                      $dbThisTable2=$dbServicesTable; 
                    }
                }
              }
            }
       }

       if ($found){
        $row = mysql_fetch_object($result); // get the elements from USER or AD or SERVICE table 
        if ($what2=="user" || $what2=="ad" || $what2=="service") $xprotype=$row->protype; // save the protype as user if not logged in ! 

        $rdata = parseStrToArr($row->paidoptions); 

        // make the do-checkout request to finalize the order and save this to the paypal log file
        $paid_checkout_details_array['amt']  = $rdata['amount'];  
        $paid_checkout_details_array['token']  = $token;  
        $paid_checkout_details_array['PayerID']  = $PayerID;
        $paid_checkout_details_array['protype']  =  $xprotype;

        // get the user details for HT vs TTC payments



        //convert the paidoptions into a BOM LIST 
        // paidoptions contain the list of items in format : &vtag2=yes&putontopgallery7days=1400064216&pushtotoponceaweek=1&amount=10.6
        if ($what2=="service"){
          $theprice= $row->price; 
          $paid_checkout_details_array['bom'][0]=array("name"=>$row->name.'-'.$row->priceid , "oi"=>$row->sid.'-'.$row->priceid, "desc"=>$row->sdesc,"qty"=>1, "price"=>$theprice);
        }
        else
          $paid_checkout_details_array['bom']  = parseStrToArr($row->paidoptions, "paypalbom",'', $xprotype); 
  
        // call the DO checkout process 
        if ($paid_checkout_details_array['bom'][0]['isrecurrent']=="yes"){
          $is_recurring_payment_profile=true; 
          //this is a recurrent profile, then create the profile (one per Service or subscription)
          $r = paypal_create_recurring_payment_profile($paid_checkout_details_array); 
          // will return ACK, PROFILEID,  PROFILESTATUS, DESC 

        } else {
          $is_recurring_payment_profile=false; 
          // this is a regular payment one-shot *
          $r = paypal_do_checkout($paid_checkout_details_array); 

        }
        $success=true;


        if ($r['ACK']=="Success" || $r['ACK']=="SuccessWithWarning"){
          // bug correction PAYAPL merde ! 
          if (strpos($r['PAYMENTINFO_0_ACK'],'Success') !== false || $is_recurring_payment_profile) {
            $success=true;
            $message="paypal payment sucessfull"; 

            // log the payment status 
            if ($ENABLE_ELEM_LOGS){
              $laction="payment";$lwhat =$what2 ; $luserid=$curuserID;
              if ($is_recurring_payment_profile) $lstatus = "16|".urldecode($r["PROFILEID"])."|".urldecode($r["PROFILESTATUS"]);
              else $lstatus = "16|".$r["PAYMENTINFO_0_TRANSACTIONID"]."|".urldecode($r["PAYMENTINFO_0_ORDERTIME"]);
              log_event($laction,$lwhat, $row->id, $luserid, $lstatus, 0);
            } 


            // update status of the item to pending notification
            if ($is_recurring_payment_profile) 
              $paymentsaveddetails = "PROFILEID=".urldecode($r["PROFILEID"])."&DESC=".urldecode($r["DESC"]); 
            else
              $paymentsaveddetails = "TID=".$r["PAYMENTINFO_0_TRANSACTIONID"]."&DATE=".urldecode($r["PAYMENTINFO_0_ORDERTIME"]); 



            // determine the right status depending on policy
            if ((($USER_AUTO_APPROVAL) && ($what2=="user")) || $what2=="service" || (($AD_AUTO_APPROVAL) && ($what2=="ad"))){
              $nextstatus="40"; 
            } else $nextstatus="20"; 


            // ZADS 5.5.0 if ad and publish it directly, than force the URGENT and TOP options before batch do it !  
            $xtraparam =''; 
            if ($what2=="ad" &&  $nextstatus=="40") {
              //$row->id
              $stamp_update2= date( 'Y-m-d H:i:s', time());
              $cur_paidoptions= $row->paidoptions;
              $xtraparam .=  " , `firstpublisheddate` = '".$stamp_update2."' " ; 
              $xtraparam .=  " , `crondate` = '".$stamp_update2."' " ; 
 
              if  (has_valid_paidoption($cur_paidoptions, "urgent"))
                $xtraparam .=  " , `urgent` = 'yes' " ; 
              if  (has_valid_paidoption($cur_paidoptions, "putontopgallery"))
                $xtraparam .=  " , `priority` = 'TOP' " ; 

              // patch the date on paid options to align with good dates   
              if ($cur_paidoptions) {
                $cur_paidoptions = update_dates_on_paidoptions($cur_paidoptions); 
                if ($cur_paidoptions) {
                  $xtraparam .=  " , `paidoptions` = '".$cur_paidoptions."' " ; 
                }
              }

              // Z6.0 : if SERVICES, increase the conso 
              if ($SERVICES_MULTI_EN){              
                $rr= db_update_services('remain','-1', $row->userid,$row->pid);
                if (!$rr['result']) { var_dump($rr); die;}
                else {
                  notify_service_state_change($rr['id'], $rr['newstatus']); 
                  $refresh_myservices=true;
                } // ask to refresh my services ! 
              }
            }

            // make the final query 
            $filter2="WHERE `id`='".$row->id."'";
            $query2 = "UPDATE `".$dbThisTable2."` SET   `status` = '".$nextstatus."' , `payment` = '".$paymentsaveddetails."' ".$xtraparam."  " .$filter2; 
            $result2 = @mysql_query($query2);
            $query2_saved = $query2; 
   
            // log the fact that status changed in the history 
            if ($result2 && ($ENABLE_ELEM_LOGS)){
              $laction="update";$lwhat = $what2;$lstatus = $nextstatus;
              $luserid=$curuserID;
              log_event($laction,$lwhat, $row->id, $luserid, $lstatus, 0);
            }   

            //store the transaction details into special payment table 
            // set up the VAT(YES if AMOUNT includes VAT other wise nothing )
            $xvat=''; 
            if ($lcur_user) {if ($lcur_user['protype']!="pro") $xvat="yes";}
            else if ($xprotype!="pro") $xvat="yes";
            logfile('', "Vat calculation : lcur_user=$lcur_user; xprotype=$xprotype ==> xvat=$xvat ",  __LINE__);

            $stamp_order= date( 'Y-m-d H:i:s', time());
            $query2 = "INSERT INTO `".$dbPaymentsTable."` 
              (`paymentdate`, `transactionid`, `paymentstatus`, `payerid`,  `userid`, `amt`, `currencycode`,  `token`, `what`, `whatid`, `note`,`bom`,`vat`,`recurrent`)"; 
            
            if ($is_recurring_payment_profile) 
              $query2 .= "VALUES 
              ('$stamp_order', '".urldecode($r["PROFILEID"])."', '".$r["PROFILESTATUS"]."', '$PayerID', '$curuserID', '".urldecode($r["AMT"])."', '".$r["CURRENCYCODE"]."','$token', '".$what2."', '$row->id','', '".urldecode($r["DESC"])."', '".$xvat."', 'yes');";
            else   
              $query2 .= "VALUES 
              ('$stamp_order', '".$r["PAYMENTINFO_0_TRANSACTIONID"]."', '".$r["PAYMENTINFO_0_PAYMENTSTATUS"]."', '$PayerID', '$curuserID', '".urldecode($r["PAYMENTINFO_0_AMT"])."', '".$r["PAYMENTINFO_0_CURRENCYCODE"]."','$token', '".$what2."', '$row->id','".urldecode($r["NOTE"])."', '".$row->paidoptions."','".$xvat."', '');";
            
            // make the query   
            $result2 = mysql_query($query2);
            if ($result2){
              logfile('', "{main} : Transaction stored into PAYMENTS table = ".$paymentsaveddetails , __LINE__);              
            } else  logfile('error', "{main} : Storing payment transaction  : ".mysql_error() . ' : QUERY='.$query2,__LINE__);

            // send an email to all parties
            // get all datas for the email 
            $filterx="WHERE `$dbThisTable2`.`id`='".$row->id."'";
            if ($what2=="user") $queryx = "SELECT `$dbThisTable2`.* FROM `$dbThisTable2` " .$filterx; 
            else if ($what2=="service") $queryx = "SELECT `$dbThisTable2`.*, `$dbUsersTable`.`firstname`, `$dbUsersTable`.`lastname`, `$dbUsersTable`.`email` AS `uemail`  FROM `$dbThisTable2` LEFT OUTER JOIN `$dbUsersTable` ON `$dbThisTable2`.`userid`= `$dbUsersTable`.`id`  ".$filterx; 
            else $queryx = "SELECT `$dbThisTable2`.*, `$dbUsersTable`.`firstname`, `$dbUsersTable`.`lastname`, `$dbUsersTable`.`email` AS `uemail`  FROM `$dbThisTable2` LEFT OUTER JOIN `$dbUsersTable` ON `$dbThisTable2`.`userid`= `$dbUsersTable`.`id`  ".$filterx; 
            $resultx = mysql_query($queryx);

            if ($resultx) {
              $rowx = mysql_fetch_array($resultx);
              if ($what2=="user"){ 
                  $user_email =    $rowx['email'];
                  // patch password in order to avoid sending the MD5 password
                  $rowx['password']='';
              } else $user_email =  $rowx['uemail'];

              mySendEmail($emailRoutingTable, $what2, $rowx['status'], $rowx, $user_email); 
            } else  logfile('error', mysql_error(), __LINE__);

            // for services, launch an update of the service context
            //if ($what2=="service"){
            $this_user_id = $curuserID; 
            $datalist = db_list_services($this_user_id);

            // update nbr of ads for this user
            $re_totnbads = db_list_ads_nbr($this_user_id); 

            //} 
           
          }
        } else{
          $success=false; 
          $message = urldecode($r["L_LONGMESSAGE0"]); 
        }
      } else {
        // no order found of more than 1 --> This is a bug in that case 
        $success=false; 
        $message = "paypal - This transaction does not exist or has already been processed"; 
      } 
    }

    // normalize the what 
    if ($what2!='') $what=$what2; 
  

  } // END SUCCESS

   if ($paypalaction=="cancel"){
      // do nothing special  
      $action= "paypal-cancel";
      $success=true;  

   }


  // -- output result ------------- 
    $json = array(
        'success' => $success,
        'message'=> $message,
        'action' => "paypal",
        'subaction' => $action,
        'transactionid'=>$r["PAYMENTINFO_0_TRANSACTIONID"], 
        'what' => $what,
        'id'=>$row->id, 
        'status' => $nextstatus,
        'nav'=>$nav,
        'data'=>$datalist,
        'userid'=>$curuserID,
        'totnbads'=>$totnbads
    );
   if ($debug_tmp==1){ // add debug info into the stream when working local
       $json["xdebug"]= array(
          'sqldebug_RETRIEVE'=> $query,
          'sqldebug_PAY'=> $query2,
          'sqldebud_AD'=>$query2_saved, 
          'inquery'=>$paid_checkout_details_array, 
          'paypalresponse'=> $r
        );  
     }
   
    // echo json_encode($json);
    encode_json_and_send_with_compression($json); 


}


// ############# SERVLET FIVE CHECK  ###########################
if (isset($_POST["livecheck"]) ) {

  $t0=microtime(true); // counter 
    
  $what = secure_var($_POST["what"]) ;            // SECURITY 
  $field = stripslashes(secure_var($_POST["field"])) ;            // SECURITY 
  $invalue = stripslashes(trim(secure_var($_POST["value"]))) ;            // SECURITY 
  $dbThisTable=''; $success=true; $message=''; // default to OK
  
  //patch on fields 
  $dbfield =$field; 
  if ($field=="u_username") { $dbfield="username"; $what="user"; }
  if ($field=="u_email") { $dbfield="email";$what="user"; }

  if ($what=="ad") $dbThisTable=$dbItemsTable; 
  if ($what=="user") $dbThisTable=$dbUsersTable; 

  if ($dbThisTable && $dbfield) {
    $query = "SELECT `$dbfield` FROM `$dbThisTable` WHERE `$dbfield`='$invalue'"; 
    $result = @mysql_query($query);
    if (mysql_num_rows($result)) 
      { $success=false; $message="already exist";} 
  }
  $json = array(
                  'ok'=>$success,
                  'wa'=>$what,
                  'iv'=>$invalue,
                  'fi'=>$field,
                  'mg'=>$message,
                  'd'=>$query
              );
  if ($ENABLE_TRACE_LOG) {
    $deltatime= (microtime(true)-$t0);$deltatime = sprintf("%01.3f", $deltatime);
    $json['time_log']= $deltatime; 
  }

  // echo json_encode($json);
  encode_json_and_send_with_compression($json); 
  exit ; // action is finished !  

}

// ## MAIN PART ###################################################
// ############# SERVLET FOR ACTIONS ###########################
if (isset($_POST["action"]) ) {
  $TAG_ACTION=1; // for inline text tagging 

  $make_pre_query=false;
  $success=true;
  // global var for check if session is set or not 
  $curuser_is_admin=false; // global var to indicate it a user is logged and if he is admin 
  $curuser_is_owner=false;  // global to indicate the cur_user = userid in searches 
  $curuser_id=""; $curuserid="";
  $curuser_type=0; 
  $curuser_loclatlng=''; // current location (will be set by CheckUserRight)
  
  $totnbrofresults = 1; 
  $action = $_POST["action"];
  
  if ($action=="") die('action NULL received - cheating ?'); // SECURITY protection
  $what = $_POST["what"] ;
  if (!$what) $what="item";
  $genuinewhat=$what ; 
  if ($what=="zetvu") $what="ad"; // a zetvu is in fact a restrited add.

  // set some global variables 
  $isAd = ($what=="ad" || $what=="ads" || $what=="item" || $what=="items") ? true:  false; 
  $isUser = ($what=="user" || $what=="users") ? true:  false; 
  $isCat = ($what=="cat" || $what=="cats") ? true:  false; 

  $status = secure_var($_POST["forceflag"]) ;
  $statusfilter=secure_var($_POST["status"]);     // SECURED 
   
  /* check if user has the right to do so if ok , continue ,  else, page is exited with a special message*/
  $res =  check_userRights($genuinewhat, $action, $status ,$statusfilter );   
  if ( $res ) {$toto=1;}
  else die ($res['message'].'-'. $res['message_extended']); 
  

  $id = $_POST["id"]+0 ;                          // SECURITY - convert to int 
  $adid = $_POST["adid"]+0 ;                      // SECURITY - convert to int 
  // only for update : 
  $ad_id=$_POST["ad_id"]+0 ;
  
  $userid = $_POST["userid"]+0 ;                  // SECURITY - convert to int 
  $curuserid = $_POST["curuserid"]+0 ;            // SECURITY - convert to int 

  if( isset($_POST['userid']) ){
    if ($userid==$curuser_id) $curuser_is_owner=true; // note  :  curuser_id is set by CHECK USER RIGHT function  
  }

  //Z.7.0.0
  // curuserid:275
  if ($USERDETAILS_ONLY_FOR=="registered" && $action=="display" && $what=="user" && !$curuserid ){
    $msg_extended ="---> ERROR - need to have a valid session to access this ressource";
    die ($msg_extended); 
  }


  $title = secure_var($_POST["title"]);           // SECURED
  $description = $_POST["desc"] ;     
  $catid = $_POST["catid"]+0 ;                    // SECURITY - convert to int 
  $ispid = secure_var($_POST["ispid"]);           // SECURED
  $catidoriginal = $_POST["catid"]+0 ;            // SECURITY - convert to int 
  $type = secure_var($_POST["type"]);             // SECURITY - strip undesired text
  $priority = secure_var($_POST["priority"]);             // SECURITY - strip undesired text
  $urgent = secure_var($_POST["urgent"]);             // SECURITY - strip undesired text
  $typeoriginal = $type;                          // SECURED
  $price = $_POST["price"];
  // new zads@4.9
  $pricetype = secure_var($_POST["pricetype"]); // SECURED
  $hits = secure_var($_POST["hits"]); // SECURED

  //@z6.7
  $newprice = $_POST["newprice"];
  $newpricetype = secure_var($_POST["newpricetype"]); // SECURED
  $haspricechange=false; 
  // patch the prices values here
  if (isset($_POST["newprice"])){
    // logfile('', "** price= $newpricetype | $newprice");
    if ($newpricetype || $newprice){
      $price2 = $price ; //save previous value 
      $price = $newprice ; 
      $pricetype2 = $pricetype ; //save previous value 
      $pricetype = $newpricetype ; 
      $haspricechange=true;   
      // logfile('', "** changing prices price= $newpricetype | $newprice");
    } 
  }


  $metadesc = secure_var($_POST["metadesc"]);           // SECURED
  $metatitle = secure_var($_POST["metatitle"]);           // SECURED
  $metakey = secure_var($_POST["metakey"]);           // SECURED

  //Z6.5.2
  $likes = secure_var($_POST["likes"]); // SECURED

  //Z6.8 - Versatilse counters
  $vcounters = secure_var($_POST["vcounters"]); // SECURED
  
  $status = secure_var($_POST["forceflag"]) ;     // SECURITY - strip undesired text
  $moddate= $_POST["moddate"] ;
  $vieworiginal = $_POST["view"] ;
  $statusfilter=secure_var($_POST["status"]);     // SECURED
  $priority=secure_var($_POST["priority"]);     // SECURED
  $prevstatus=secure_var($_POST["prevstatus"]);     // SECURED

  $nav=$_POST["nav"];
  $modid = $_POST["modid"];

  // Z6.0 protection = case of status="all" and not in navigato=ion bar ! 
  if ($statusfilter=="all" && ($nav!="admin" || !$curuserid )){
    $statusfilter=''; 
  }
  

  // images variable (updated @zads4.0)
  $imgnameArray = $_POST["filename"] ;
  $imgname=""; 
  $imgname2Array = $_POST["filename_2"] ;
  if ($_POST["addpics"]=="yes" && $_POST["filename_2"] ) {
    // warning, if filename_2 is empty > all the array is empty !   
    $imgnameArray = array_merge($imgnameArray, $imgname2Array) ;  
  }

  $picsnameArray = $_POST["pics"] ; 
  $picsname=""; 
  $avatarimgnameArray = $_POST["avatarimg"] ;         // Avatar image 
  $avatarimgname=""; 
  $avatarimg_social = $_POST["avatarimg_social"] ; // Z6.4.0 
  $imgpath = $_POST["imgpath"] ; 

  //Z6.7.0 d patchi case of social to change the avatarimg
  $auth=  secure_var($_POST["auth"]) ;        // SECURED 
  if ($auth !='lo' && $auth !=''  && $avatarimgnameArray) {
    $avatarimg_social='';// reset it
    $imgpath=''; 
  }

  $probannerurl= secure_var($_POST["probannerurl"]) ;  
  $probannerimgnameArray = $_POST["probannerimg"] ;      // banner imgage 
  $probannerimgname=""; 
  $folioimgnameArray = $_POST["folioimg"] ;           // portfolio image
  $folioimgname=""; 
  // iconname for Categories @zads4.8
  $iconnameArray = $_POST["iconimg"] ;           // portfolio image
  $iconname=""; 

  //@Z6.5.0 - audio
  $audiourlArray = $_POST["audiourl"] ;           // audio urls 
  $audiourlname=""; 

  //@Z6.5.2 - video
  $videourlArray = $_POST["videourl"] ;           // video urls 
  $videourlname=""; 

    //@Z6.7.0 - video
  $docurlArray = $_POST["docurl"] ;           // video urls 
  $docurlname=""; 

  //@Z6.5.2 - likes
  $likes =$_POST["likes"]+0 ;

  // video @zads4.1
  $videoembed =  isset($_POST["videoembed"]) ? formatSizeVideo(stripcslashes($_POST["videoembed"]), $what) : "" ;
  $video2 =  (isset($_POST["video2"])) ? formatSizeVideo(stripcslashes($_POST["video2"]), $what) : "" ;


  // location variable (update@zads4.0)
  $location = secure_var($_POST["location"]) ;            // SECURED
  $loczipcode = $_POST["loczipcode"]+0 ;                  // SECURITY - convert to int 
  $loccity = secure_var($_POST["loccity"]) ;              // SECURED
  $locdept = secure_var($_POST["locdept"]) ;              // SECURED
  $locregion = secure_var($_POST["locregion"]) ;          // SECURED
  $loccountrycode = secure_var($_POST["loccountrycode"]) ; // SECURED
  $loclatlng = secure_var($_POST["loclatlng"]) ;          // SECURED
  $lochash = secure_var($_POST["lochash"]) ;              // SECURED
  $lochashregion = secure_var($_POST["lochashregion"]) ;  // SECURED
  
  // pro version of user  (created@zads4.0)
  $protype =  secure_var($_POST["protype"]) ;             // SECURED
  $procpny = secure_var($_POST["procpny"]) ;              // SECURED
  $prosiret = secure_var($_POST["prosiret"]) ; 
  $prowebsite = secure_var($_POST["prowebsite"]) ;        // SECURED

  // created@zads6.0
  $indir =  secure_var($_POST["indir"]) ;             // SECURED
  $banclicks =  secure_var($_POST["banclicks"]) ;             // SECURED

  // created@zads4.8
  $utype =  secure_var($_POST["utype"]) ;                   // SECURED

 // created@zads4.9
  //$plan =  secure_var($_POST["plan"]) ;                     // SECURED
  $plan =  isset($_POST["plan"]) ? secure_var($_POST["plan"]) : "";             // SECURED
  $longdesc =  isset($_POST["longdesc"]) ? secure_var($_POST["longdesc"]) : "";             // SECURED

  //@Z4.9 (filter per Location)
  $locval = secure_var($_POST["locval"]) ;                   // SECURED
  $locfield = secure_var($_POST["locfield"]) ;                // SECURED


  //@Z7.0.0 location fields
  $flocregion = secure_var($_POST["flocregion"]) ;                // SECURED
  $flocdept = secure_var($_POST["flocdept"]) ;                // SECURED
  $floccity = secure_var($_POST["floccity"]) ;                // SECURED
  $floczipcode = secure_var($_POST["floczipcode"]) ;                // SECURED

  //Z7.4.0 - force a country search 
  $fforcedlocountry = secure_var($_POST["fforcedlocountry"]) ;                // SECURED

  $f_flocregion = secure_var($_POST["f_flocregion"]) ;                // SECURED
  $f_flocdept = secure_var($_POST["f_flocdept"]) ;                // SECURED
  $f_floccity = secure_var($_POST["f_floccity"]) ;                // SECURED
  $f_floczipcode = secure_var($_POST["f_floczipcode"]) ;                // SECURED
 
  
  // created@zads4.0
  $social="";  // reserved for future use
  
  // pro version of user  (created@zads4.0)
  $bio =  secure_var($_POST["bio"]) ;                     // SECURED
  $skills =  secure_var($_POST["skills"]) ;               // SECURED

  // new @zads4.8 
  $parentid =   secure_var($_POST["parentid"]) ;          // SECURED
  if (($parentid==0) || ($parentid=="0") || ($parentid=='')) $parentid=NULL;
  $catorder =   $_POST["order"]+0 ;                // SECURED


  // new Z7.1.0 verify fields
  $verify =  isset($_POST["verify"]) ? secure_var($_POST["verify"])  : "";                     // SECURED
  $verify2 =  isset($_POST["verify2"]) ? secure_var($_POST["verify2"])  : "";                     // SECURED
  $verify3 =  isset($_POST["verify3"]) ? secure_var($_POST["verify3"])  : "";                     // SECURED

  // new fields for POLITICS (created@zads5.0)
  $desc2 =  isset($_POST["desc2"]) ? secure_var($_POST["desc2"]) : "";             // SECURED
  $desc3 =  isset($_POST["desc3"]) ? secure_var($_POST["desc3"]) : "";             // SECURED
  $address2 =  isset($_POST["address2"]) ? secure_var($_POST["address2"]) : "";    // SECURED
  $email2 = trim(secure_var($_POST["email2"])) ;  // SECURITY - strip undesired text
  $phone2 = trim(secure_var($_POST["phone2"].' ')) ;        // SECURED
  $cat2 = trim(secure_var($_POST["cat2"]));
  $cat3 = trim(secure_var($_POST["cat3"]));
  $links = secure_var($_POST["links"]);
  $date2= $_POST["date2"] ;

  // Z5.5 
  $catlvfields =   $_POST["catlvfields"] ;
  $cat_vfields =  $_POST["cat_vfields"] ;
  if ($cat_vfields) $cat_vfields_str = parse2DimsArrToStr($cat_vfields); 
  else $cat_vfields_str=""; 

  // var_dump($cat_vfields); 
  // die; 

  $user_vfields =  $_POST["user_vfields"] ;
  if ($user_vfields) $user_vfields_str = parse2DimsArrToStr($user_vfields); 
  else $user_vfields_str=""; 


  // case of search on vfields 
  $f_vfields = isset($_POST["f_vfields"]) ? $_POST["f_vfields"] : ""; 

    
  // ----  @zads4.5 payment options only for creation and update
  // ----  @zads4.7 modified with payment options for users 
  $hasPaidOptions=false; $paid_amount=0;  $paid_param=""; 
  $paid_bom_str=""; $paid_checkout_details_array= Array ();

  if (
        $general_catalogue 
        && ( ($action=="create") || ($action=="update") || ($action=="updatestatus") )
        && ( ($what=="ad") || ($what=="item") || ($what=="user") )    
      )
  {

    // get user details
    $lcur_user = get_user_details($curuserid); 
    $thetrace=""; 

    if (isset($general_catalogue['payoptions'])) {
      if ($general_catalogue['payoptions']['enable']){      
        // we accept payment then we loop though variable to check if theyr are present 
        // and build the payment Serial string 
        foreach ($general_catalogue['payoptions']['options'] as  $elem) {
             if (isset($_POST[$elem["name"]]) && (secure_var($_POST[$elem["name"]])=="yes")){
                $hasPaidOptions=true; 
                if ($elem["unit"]=="days") $paid_thevalue = time() + $elem["value"]*24*3600; 
                else  $paid_thevalue=$elem["value"]; 

                // set output variable  
                $paid_param .= "&".$elem["name"]."=".$paid_thevalue;

                // get the price depending on type of users (PRO or PAR). 
                if  ($lcur_user) {
                  $lprice= ($lcur_user['protype']=="pro") ?   1*$elem["price_pro_ht"] : 1*$elem["price"]; 
                  $thetrace.=" -- in lcuruser price = $lprice"; 
                }else {
                  // case of  users 
                  if ($what=="user") {
                     $lprice= ($protype=="pro") ?   1*$elem["price_pro_ht"] : 1*$elem["price"];
                      $thetrace.=" -- in what==user price = $lprice"; 

                  } else {
                  // other cases 
                    $lprice= 1*$elem["price"];  
                    $thetrace.=" -- in default, price = $lprice"; 

                  }
                }
                // patch price and set it to zero for special cases  : 
                // logfile('', "pos for ".$elem["name"]." in ".$SERVICES_PRO_FREE_OPTIONS_LIST." = ".strrpos($elem["name"], "xx,".$SERVICES_PRO_FREE_OPTIONS_LIST)); 
                // if  (strrpos($elem["name"], ";".$SERVICES_PRO_FREE_OPTIONS_LIST))
                if ($lcur_user['protype']=="pro" && in_array($elem["name"], explode('+', $SERVICES_PRO_FREE_OPTIONS_LIST)))
                  $lprice=0; 

                $paid_amount +=$lprice; 
                logfile('info', "{main } : the tracepaypal tmp =$thetrace", __LINE__); 


                // oi - designation - quantity - unit price d
                // take the description as the main element to display on the invoice 
                $xname=($elem["desc"] =="*" || $elem["desc"] =="" ) ? $elem["name"] : $elem["desc"] ;
                $paid_bom_str .= "|".$elem["oi"]. "|".$elem["name"]. "|"."1"."|".$lprice; 
                $paid_checkout_details_array["bom"] = array("oi" =>$elem["oi"], "name"  => $xname, "qty" => 1, "price" =>$lprice, "isrecurrent"=>$elem["isrecurrent"], "billingperiod"=>$elem["billingperiod"],"billingfrequency"=>$elem["billingfrequency"]); 

            }   
        }
        if ($paid_param) {
          // convert float to string and add the '.' separator 
          $paid_amount = strval($paid_amount);
          $paid_amount = str_replace(',', '.', $paid_amount);
          $paid_param .="&amount=".$paid_amount;  // add the total amount
        }

        // zads 5.5.1 completely bypass this if NO MODS POSSIBLE AFTER CREATION ! 
        if (
                  (($what=="ad") || ($what=="item")) 
              &&  (($action=="update") || ($action=="updatestatus"))
              &&  $AD_PAID_NOMODS_AFTERCREATION && !($status=="00" || $status=="10")
              &&  !$curuser_is_admin
            ){
           $paid_param = $_POST["paidoptions"]; 
        }

        // debug case      
        logfile('info', "{main} : [$action $what] : paidoptions from POST infos : param=$paid_param | bom =$paid_bom_str", __LINE__); 
      }
    }
  } // end of check fro all update/create 

  // launch paypal payment if status is set to 15 
  if (  
            ( ($what=="ad") || ($what=="item") || ($what=="user") ) 
        &&    ($status=="15") 
        &&  ( ($action=="create") || ($action=="update") || ($action=="updatestatus") )
      )
  {
    // launch paypal payment en exit this
    require_once("paypal.php"); 
    
    if (($what=="item") || ($what=="ad")) { $dbThisTable2 = $dbItemsTable; $what2="ad";};
    if (($what=="users")|| ($what=="user"))  { $dbThisTable2 = $dbUsersTable; $what2="user";};

    // build the BOM from what's inside the database and not what imported  
    if ($action=="updatestatus") {

      // set the status to 15 (=pending payment)
      $stamp_update2= date( 'Y-m-d H:i:s', time());
      $query = "UPDATE `".$dbThisTable2."` SET   
        `moddate` = '".$stamp_update2."', 
        `status`='".$status."'
        WHERE ((`id` = '".$ad_id."')) ";
      $result = mysql_query($query);

      // update the log file
      if ($result && ($ENABLE_ELEM_LOGS)) {
        $luserid=$curuser_id;
        $laction="update";$lwhat = $what2; $lstatus = "15";
        log_event($laction,$lwhat, $ad_id, $luserid, $lstatus, 0); 
      }

      // warn by email on what's happening 
      $filterx="WHERE `$dbThisTable2`.`id`='".$ad_id."'"; 
      if ($what2=="user") 
        $queryx = "SELECT * FROM `$dbUsersTable` " .$filterx; 
      else 
        $queryx = "SELECT `$dbItemsTable`.*, `$dbUsersTable`.`firstname`, `$dbUsersTable`.`lastname`, `$dbUsersTable`.`email` AS `uemail`  FROM `$dbItemsTable` LEFT OUTER JOIN `$dbUsersTable` ON `$dbItemsTable`.`userid`= `$dbUsersTable`.`id`  ".$filterx; 
      $resultx = mysql_query($queryx);
      $rowx = mysql_fetch_array($resultx);
      if ($what2=="user")  { $user_email = $rowx['email']; $user_protype=$rowx['protype'] ;} else $user_email =  $rowx['uemail'];

      // debug
      logfile('info', "{main} : [$action $what] : preparing payment for : ".$rowx['paidoptions']); 

      // special case for ads to force the priority 
      $rdata = parseStrToArr($rowx['paidoptions']); 
       if ($what2=="user") $toto=1; 
       else 
        if ( $rdata['putontopgallery']) {
          $query = "UPDATE `".$dbItemsTable."` SET   
                `priority` = 'TOP'
                WHERE ((`id` = '".$ad_id."')) ";
          $result = @mysql_query($query);
          if ($debug_tmp==1) { fwrite($debugfile,"<br>--> SQL PREQUERY =  ".$query);  fwrite($debugfile,"\n");}
        }
        // end special case 

        // save the payment options, if user, we must indicate the protye for TTC vs HT prices  
        if ($what2=="user") $paid_checkout_details_array['bom']  = parseStrToArr($rowx['paidoptions'], "paypalbom", '', $user_protype);
        else $paid_checkout_details_array['bom']  = parseStrToArr($rowx['paidoptions'], "paypalbom"); 

        // this is to indicate to paypal that this is a pro price
        if ($what2=="user" && $user_protype) $paid_checkout_details_array['protype']=$user_protype; 
        else $paid_checkout_details_array['protype']='';

        // create the invoice tracking number
        $paid_checkout_details_array['gendesc'] = "your order by ".date( 'Y-m-d', time()); 
        $paid_checkout_details_array['invnum'] =  format_invoice_number($what2,$rowx['id']); 
        //$paid_checkout_details_array['invnum'] = date( 'Ymdhis', time()).'-'.$what2.'-'.$rowx['id']; 
     } // end ACTIOn = updatestatus

    // ------- call the ckechout process ------- 
    $r = paypal_call_checkout($paid_checkout_details_array); 

    // if OK ! 
    if ($r["CUSTO_SUCCESS"]){
      // send email to warn everybody and indicate the payment link
      $rowx['paymenturl'] = $r["CUSTO_REDIRECT_LOCATION"]; 
      mySendEmail($emailRoutingTable, $what2, $rowx['status'], $rowx, $user_email); 
      
      // save the token for future use or send an error message 
      $queryy = "UPDATE `".$dbThisTable2."` SET   `payment` = 'TOKEN=".$r["CUSTO_TOKEN"]."' " .$filterx; 
      $resulty = @mysql_query($queryy);

      // create an entry into the payment DB to strore the details of the transaction for future use 

      // $stamp_order= date( 'Y-m-d H:i:s', time());
      // $token=$r["CUSTO_TOKEN"]; 
      // $queryz = "INSERT INTO `".$dbPaymentsTable."` 
      //   (`paymentdate`, `transactionid`, `paymentstatus`, `payerid`,  `userid`, `amt`, `currencycode`,  `token`, `what`, `whatid`, `note`,`bom`)"; 
      // $queryz .= "VALUES 
      //   ('$stamp_order', '', '10', '', '', '', '','".$token."', '".$what2."', '".$ad_id."','', '".$rowx['paidoptions']."');";
      // $resultz = @mysql_query($queryz);
      // if ($resultz) logfile('', "{main} - This PAYPAL transaction : $token :  has been stored into PAYMENT table "); 
      // else  logfile('error', mysql_error());

      $msg = $r["CUSTO_SUCCESS"];

    } 
    // NOT OK -> display the error message
    else { 
      $msg =  "PAYPAL message : <br>". urldecode($r['L_LONGMESSAGE0']) . "<br>". urldecode($r['L_LONGMESSAGE1']);
    }  

    $json = array(
        'success' => $r["CUSTO_SUCCESS"] ,
        'message'=>$msg,
        'token'=> $r["CUSTO_TOKEN"],
        'action' => "paypal-checkout",
        'location' => $r["CUSTO_REDIRECT_LOCATION"],
        'what' => $what2,
        'nav'=>$nav,
        'id' => $ad_id
    );

   if ($debug_tmp==1){ // add debug info into the stream when working local
       $json["xdebug"]= array(
          'sqldebug3' => $queryx,
          'sqldebug2' => $queryy,
          'sqldebug' => $query,
          'r' => $r,
          'paidoptions' =>$rowx->paidoptions,
          'checkoutin'=>$paid_checkout_details_array

        );  
     }
    // echo json_encode($json);
    encode_json_and_send_with_compression($json); 
    exit ; // action is finished !  
  } // end IF loop on so paypal only if status == 15 



  /*---------------------------------------------------------*/

  if ($nav=="admin"){
    if (isset($_POST["userid"])) $instatus=$statusfilter; else $instatus="admin_".$statusfilter;
  }else $instatus='';
  
  $msg=$_POST["msg"]; // message
  
  // global variable storing some messages elements 
  $messagef = "";
  
  $newfav=$_POST["newfav"];
  $action2=$_POST["action2"];
  
  if ($action=="display") {
    $nav=$action;
    $in_action=$action; 
    $action="list"; 
  } else $in_action=""; 
  

  // search for PARAMETERS  
  $search=trim(secure_var($_POST["search"])); // SECURITY 
  if (isset($_POST["q"])) $search=trim(secure_var($_POST["q"]));  // SECURITY 
  // $q = trim(secure_var($_POST["q"])); // SECURITY 
  // $search = $search.$q; 
  // $search=strtolower($search); // !!!!!!!!!!!!!!!! NE PAS METTRE CAR CA PEUT FAIRE PLANTER !  !!!!!!

  $fcat = trim(secure_var($_POST["fcat"])); // SECURITY  
  $fispid = trim(secure_var($_POST["fispid"])); // SECURITY  
  $fwhat = trim(secure_var($_POST["fwhat"])); // SECURITY 
  $ftype = trim(secure_var($_POST["ftype"])); // SECURITY 
  $furgent = trim(secure_var($_POST["furgent"])); // SECURITY 

  // 7.0.4 
  $ftitleonly = trim(secure_var($_POST["ftitleonly"])); // SECURITY 
  $fwithvideo = trim(secure_var($_POST["fwithvideo"])); // SECURITY 
  $fwithaudio = trim(secure_var($_POST["fwithaudio"])); // SECURITY 
  $fwithphoto = trim(secure_var($_POST["fwithphoto"])); // SECURITY 
  
  // elements for user initialization
  $username=  secure_var(trim($_POST["username"])) ;    // SECURED
  $password=  md5(trim($_POST["password"])) ;
  $thisdeclaredpassword = trim($_POST["password"]) ;  // save declared password this call to send it by email         
  $firstname= secure_var($_POST["firstname"]) ;         // SECURED
  $lastname=  secure_var($_POST["lastname"]) ;          // SECURED
  $locale=  secure_var($_POST["locale"]) ;    // SECURED    
  $gender=  secure_var($_POST["gender"]) ;    // SECURED
  $auth=  secure_var($_POST["auth"]) ;        // SECURED      
  if (isset($_POST["usertype"])) $usertype=$_POST["usertype"] ; else $usertype=1;   // default set to registered
  if (isset($_POST["page"]))$paged = $_POST["page"]+0; else  $paged =1; 
  $xmaxitems= (int)$display_settings["max_items_per_page"];  
  if (isset($_POST["eppage"])) $eppage =$_POST["eppage"]*1; else  {
    if ($what=="users" || $what=="ads" || $what=="cats") $eppage=20;
    else    $eppage=$xmaxitems;
  }
   
  // elements linked to list and search 
  $sort=$_POST["sort"] ;
  // conditional inputs : 
  $enphone = $_POST["enphone"] ;
  $enemail = $_POST["enemail"] ;
  $enusername = $_POST["enusername"] ;
  
  $email = trim(secure_var($_POST["email"])) ;  // SECURITY - strip undesired text
  $phone = trim(secure_var($_POST["phone"].' ')) ;        // SECURED


  // dother elemnts ZADS 4.9 
  $openhours = trim(secure_var($_POST["optnhours"])) ;

  // zads 5.1  - default value for badwords 
  $badwords_res=array('success' => false);

  // zads 5.6.0 - current status for ads to decide on what to do ! 
  $curstatus=trim(secure_var($_POST["curstatus"])) ;

  // zads 6.1 
  $in_newletter=trim(secure_var($_POST["newsletter"])) ;
  $action_newsletter='';

  // Zads 6.1 
  $adultflag=trim(secure_var($_POST["adultflag"])) ;
  $adulttext=trim(secure_var($_POST["adulttext"])) ;
  if ($adultflag) $adulttext="ADULT-CATEGORY-DISCLAMER";  // force it by default value
  $acl=trim(secure_var($_POST["acl"])) ;


  //Z6.4.0 
  $hascalendar=trim(secure_var($_POST["hascalendar"])) ;
  $calendartype=''; // TO BE USED LATER 

  //zads 6.1.1 - vtag fields
  $vtag1=(isset($_POST["vtag1"])) ? trim(secure_var($_POST["vtag1"])) : '';
  $vtag2=(isset($_POST["vtag2"])) ? trim(secure_var($_POST["vtag2"])) : '';
  $vtag3=(isset($_POST["vtag3"])) ? trim(secure_var($_POST["vtag3"])) : '';
  $vtag4=(isset($_POST["vtag4"])) ? trim(secure_var($_POST["vtag4"])) : '';
  $vtag5=(isset($_POST["vtag5"])) ? trim(secure_var($_POST["vtag5"])) : '';

  $refresh_myservices=false; 

  if (($what!="users")&& ($what!="user") && ($what != "curuser")){
    // preprocessing of variables
    $title = addslashes($title);
    $description = addslashes($description);
    if ($enphone=="yes") $phone = $phone; else $phone=""; 
    if ($enemail=="yes") $email = $email; else $email=""; 
    if ($enusername=="yes") $username = $username; else $username=""; 
  }
  
  // format the path destinations for saving images
  if (($what=="users")|| ($what=="user") || ($what == "curuser")){
    $dest_path = $dest_path_user; 
    $dest_path_from_root =$dest_path_from_root_user; 
  }else  if (($what=="cats") || ($what=="cat")){
    $dest_path = $dest_path_cat; 
    $dest_path_from_root =$dest_path_from_root_cat; 
  } else { // default 
    $dest_path = $dest_path_ad; 
    $dest_path_from_root =$dest_path_from_root_ad; 
  }
  
  // format for the stamp
  if (($what=="user") || ($what=="curuser")) $stamp_update = $stamp;
  else 
    if (($status=="40") || ($status=="10" ) || ($status=="80" )) $stamp_update = $stamp; 
    else $stamp_update = $moddate; // keep the original posted date.
  
  /// format of the sort value are XXX_YYY where XXX=chat and YYYY=direction
  if($sort) {
    $sortoriginal = $sort;
    $sort=explode("_",$sort); 
    $sort_dir = $sort[1];
    $sort_by = $sort[0];
    if ($sort_by=="date") 
        if (($what=="users")||($what=="user"))  $sort_by="moddate";  
        else $sort_by="moddate";
        
    if ($sort_by=="name")
       if (($what=="users")||($what=="user"))  $sort_by="lastname";  
        else $sort_by="title";
  };

  // dirt per distance
  if  (isset($_POST["sortbydist"])) { 
      $sortdist =$_POST["sortbydist"];
      $sortdistoriginal = $sortdist ;
  } else {
    $sortdist=false;
    $sortdistoriginal = $sortdist ;
  } 


  // Z7.1.5 - date of birth
  $dob='';
  if (isset($_POST['dob'])) 
  { 
    $dob = secure_var($_POST["dob"]); $dob_in= $dob ;
    $dob = reformatDate($dob, 'd/m/Y','Y-m-d' ); 
  } 


  //Z7.5.1 - expiration date
  if ($AD_EXPIRATION_FOR!="none"){
    $ad_expiredate =  secure_var($_POST["expiredate"]);
    $ad_expiredate = reformatDate($ad_expiredate, 'd/m/Y','Y-m-d' ); 
  }else $ad_expiredate=''; 


  // if ($debug_tmp==1){  foreach ($imgnameArray as $value) {fwrite($debugfile,$value);  fwrite($debugfile,"\n");} }
  
  // select the right SWL table depending on WHAT value
  if (($what=="item") || ($what=="ad")) $dbThisTable = $dbItemsTable; 
  if (($what=="cats")|| ($what=="cat")) $dbThisTable = $dbCatsTable; 
  if (($what=="users")|| ($what=="user") || ($what=="curuser") ) $dbThisTable = $dbUsersTable; 


  //-------------------- CREATE and UPDATE -------------------------------------/
    if (($action == "create") || ($action == "update") || ($action == "updatestatus") ) {
    
      // serialize the Image Names if multple images and move the images to the right folder. 
      if (($imgnameArray) && (count($imgnameArray)>0)) 
        $imgname = imgFileUpdate($imgnameArray); 
      if (($picsnameArray) && (count($picsnameArray)>0)) 
        $picsname = imgFileUpdate($picsnameArray); 
      if (($avatarimgnameArray) && (count($avatarimgnameArray)>0)) 
        $avatarimgname = imgFileUpdate($avatarimgnameArray); 
      if (($probannerimgnameArray) && (count($probannerimgnameArray)>0)) 
        $probannerimgname = imgFileUpdate($probannerimgnameArray); 
      if (($folioimgnameArray) && (count($folioimgnameArray)>0)) 
        $folioimgname = imgFileUpdate($folioimgnameArray); 
      //@Z6.5.0 
      if (($audiourlArray) && (count($audiourlArray)>0)) 
        $audiourlname = imgFileUpdate($audiourlArray); 

      //@Z6.5.2
      if (($videourlArray) && (count($videourlArray)>0)) 
        $videourlname = imgFileUpdate($videourlArray); 

      //@Z6.7.

      if (($docurlArray) && (count($docurlArray)>0)) 
        $docurlname = imgFileUpdate($docurlArray); 



      if ($loclatlng) {          
        $theloc =explode("|", $loclatlng);  
        $theloclat =  $theloc[0]; 
        $theloclng = $theloc[1]; 
      }
      else { $theloclat=''; $theloclng=''; }


      // ---------- QUERY for CREATE --------------------
      if (($action == "create")) {

        if (($what=="cats") || ($what=="cat")) {          
          $query = "INSERT INTO `".$dbThisTable."` (`userid`, `moddate`, `title`, `description`, `catid`, `type`,`price`,`imgname`, `status`,`username`,`phone`, `email`,`location`, `pid`,`order`,`iconname`, `catlvfields`,`adultflag`, `adulttext`, `acl`,`hascalendar`, `calendartype` ,`pricetype`,`metadesc`,`metatitle`,`metakey`,`protype`)";
          $query .= "VALUES ('$userid', '$stamp', '$title', '$description', '$catid', '$type','$price','$imgname','$status','$username','$phone','$email','$location','$parentid','$order','$iconname' , '$catlvfields', '$adultflag', '$adulttext', '$acl', '$hascalendar', '$calendartype', '$pricetype','$metadesc','$metatitle','$metakey', '$protype');";       
        }
        
        if ( ($what=="item") || ($what=="ad") ){

          if ($USER_CREATE_WITH_AD && $userid=='0' && isset($_POST['u_create_with_ad']) ){
              
              $u_username=  secure_var(trim($_POST["u_username"])) ;    // SECURED
              $u_password=  md5(trim($_POST["u_password"])) ;
              $u_protype=  secure_var(trim($_POST["u_protype"])) ; 
              $u_email=  secure_var(trim($_POST["u_email"])) ; 
              $u_status='40';

              // check if user already exist 
              $pre_filter_u = "WHERE ((`email` = '".$u_email."')) OR ((`username` = '".$u_username."')) ";
              $pre_query_u = "SELECT email, username FROM `$dbUsersTable`" .$pre_filter_u; 
              $pre_result_u = mysql_query($pre_query_u);
              if (mysql_num_rows($pre_result_u)!=0){
                // die ('autouser already exist - stopped'.$pre_query_u);
                $message= 'auto-user already exist'; 
                $json = array('success' => false,'message' => $message,'what' => $what,'action' => 'earlyexit');      
                echo json_encode($json); die; 
              } 


              // set an expiration date 
              $stampShouldExpire= date( 'Y-m-d H:i:s', (time()+$USER_CREATE_WITH_AD_EXPIRATION_DAYS*24*60*60));

              $query_u = "INSERT INTO `".$dbUsersTable."` 
                (`username`, `auth`, `createdby`, `usertype`,  `expiredate`,   `password`,  `email`,  `registerdate`, `moddate`, `lastvisitdate`, `status`,  `protype` )"; 
              $query_u .= "VALUES 
                ('$u_username', 'lo', 'auto', 1, '$stampShouldExpire', '$u_password',  '$u_email', '$stamp','$stamp','$stamp','$u_status', '$u_protype');";
              $result_u = mysql_query($query_u);
              if ($result_u){
                $new_user_id = mysql_insert_id(); 

                // send an email 
                // todo later 



              } else {
                logfile('error', 'auto create user SQL error = '. mysql_error()); 
                die ('sql error'); 
              }  

              $userid =   $new_user_id; 
              
          }

          $query = "INSERT INTO `".$dbThisTable."` 
            (`userid`, `moddate`,`createdate`,`firstpublisheddate`, `expiredate`,`crondate`, `title`, `description`,  `priority`,`urgent`,`catid`, `vfields`, `type`,`price`,`pricetype`,`paidoptions`,`imgname`, `videoembed`, `video2`, `audiourl`,`videourl`,`status`,`username`,`phone`, `email`,`location`,`loclatlng`, `loclat`,  `loclng`,  `loczipcode`, `loccity`, `locdept`, `locregion`, `loccountrycode`, `lochash`, `lochashregion`,`links`,`vtag1`,`vtag2`,`vtag3`,`vtag4`,`vtag5`,`price2`,`pricetype2`,`docurl`) ";
          $query .= "VALUES ('$userid', '$stamp', '$stamp','$stamp','$ad_expiredate','$stamp', '$title', '$description',  '$priority','$urgent','$catid', '$cat_vfields_str', '$type','$price','$pricetype', '$paid_param', '$imgname','$videoembed','$video2','$audiourlname','$videourlname','$status','$username','$phone','$email','$location','$loclatlng','$theloclat','$theloclng','$loczipcode','$loccity','$locdept','$locregion','$loccountrycode','$lochash','$lochashregion','$links', '$vtag1', '$vtag2','$vtag3', '$vtag4', '$vtag5', '$price2','$pricetype2','$docurlname' );";       
        
          // small patch for badwords detection 
          $inAr = array($title, $description); 
          $badwords_res = check_for_badwords($inAr);   
        } 
        
      // modified @zads5.0 to support politics fields 
       if (($what=="user") || ($what=="users") || ($what=="curuser") ){
          if ($avatarimg_social) $imgpath = $avatarimg_social; else  $imgpath=''; 
          $query = "INSERT INTO `".$dbThisTable."` 
              (`username`, `auth`, `gender`, `password`,  `usertype`, `firstname`, `lastname`,  `verify`, `email`, `phone`, `registerdate`, `moddate`, `lastvisitdate`, `status`, `imgpath`, `avatarimg`,`folioimg`, `audiourl`,`videourl`,`userid`, `locale`,`location`,`loclatlng`, `loclat`,  `loclng`, `loczipcode`, `loccity`, `locdept`, `locregion`, `loccountrycode`, `lochash`, `lochashregion`, `probannerimg`, `probannerurl`,`skills`, `priority`, `protype`, `indir`,  `banclicks`, `procpny`, `prosiret`, `prowebsite`,  `social`,  `bio`, `paidoptions`,`plan`, `longdesc`,`videoembed`,`openhours`, `ip`,`useragent`,`desc2` , `desc3`, `phone2`, `email2`, `cat2`, `cat3`, `links`, `address2`, `date2`,`vfields`,`newsletter`, `dob`  )"; 
          $query .= "VALUES 
              ('$username', '$auth', '$gender', '$password', '$usertype', '$firstname', '$lastname','$verify', '$email', '$phone', '$stamp','$stamp','$stamp','$status','$imgpath','$avatarimgname','$folioimgname', '$audiourlname', '$videourlname', '$userid', '$locale', '$location','$loclatlng','$theloclat','$theloclng','$loczipcode','$loccity','$locdept','$locregion','$loccountrycode','$lochash','$lochashregion','$probannerimgname','$probannerurl','$skills','$priority','$protype','$indir',  '0', '$procpny', '$prosiret', '$prowebsite', '$social', '$bio', '$paid_param','$plan','$longdesc' ,'$videoembed','$openhours','$serverremoteaddr','$uagent', '$desc2','$desc3','$phone2','$email2','$cat2','$cat3','$links','$address2', '$date2', '$user_vfields_str', '$in_newletter', '$dob' );";
        
          // small patch for badwords detection 
          $inAr = array($bio, $longdesc); 
          $badwords_res = check_for_badwords($inAr);   

          // pre-query for checking if declared email or username already exits
          $pre_filter = "WHERE ((`email` = '".$email."')) OR ((`username` = '".$username."')) ";
          $pre_query = "SELECT email, username FROM `$dbThisTable`" .$pre_filter; 
          $make_pre_query=true;  

          // newsletter management
          if ($in_newletter=="yes") $action_newsletter="subscribe";

        }        
      } // end of create
      
       // ---------- QUERY for UPDATE  --------------------
      if (($action == "update")) 
      {
        // ---- CAT --------------
        if (($what=="cats") || ($what=="cat"))
          $query = "UPDATE `".$dbThisTable."` SET   
            `moddate` = '".$stamp_update."', 
            `title`='".$title."',
            `description`= '".$description."',
            `catid`='".$catid."',
            `type`='".$type."',
            `priority`='".$priority."',
            `price`='".$price."',
            `imgname`='".$imgname."',
            `status`='".$status."',
            `userid`='".$userid."',
            `username`='".$username."',
            `phone`='".$phone."',
            `email`='".$email."',
            `location`='".$location."',
            `pid`='".$parentid."',
            `order`='".$order."',
            `iconname`='".$iconname."',
            `catlvfields`='".$catlvfields."',
            `adultflag`='".$adultflag."', 
            `adulttext`='".$adulttext."',
            `acl`='".$acl."',
            `hascalendar`='".$hascalendar."',
            `calendartype`='".$calendartype."',
            `pricetype`='".$pricetype."',

            `metadesc`='".$metadesc."',
            `metatitle`='".$metatitle."',
            `metakey`='".$metakey."',
            `protype`='".$protype."'

            WHERE ((`id` = '".$ad_id."')) ";

                
        // ---- AD --------------
        if (($what=="item") || ($what=="ad")) 
        {
          $xtraparam=''; 

          // small patch for badwords detection 
          $inAr = array($title, $description); 
          $badwords_res = check_for_badwords($inAr);  
          if  ( ($badwords_res['success']) && ($status!="40" || $status=="45" || $status="15") ){
            $status="20"; // force status to be "in validation"
            // add a message into the message zone of the email
            $msg = '<span style="color:red;">'.utf8_decode(_("This element as been forced to Validation because it contains BAD WORDS which are no compliant with terms and conditions")).'</span><br>'.$msg; 

          }

          // make a pre-query to get some info on pricing and others 
            $queryx = "SELECT i.`id`, i.`status`, i.`paidoptions`, i.`userid`, c.`pid` FROM `$dbThisTable` i 
              LEFT JOIN `$dbCatsTable` c ON i.`catid`= c.`id`
              WHERE ((i.`id` = '".$ad_id."'))"; 
            $resultx = mysql_query($queryx); $rowx = mysql_fetch_object($resultx);
            $cur_status =  $rowx->status; 


          // adapt pricing options  if this is done by admin user
          if ($curuser_is_admin){

            logfile('', '{main} : update | ad | isadmin | starting with cur_status = '.$cur_status. '- status= '.$status); 
            // check the two specifi options to be paid:
            if ($paid_param) {
              logfile('', '{main} : update | ad | isadmin | paid_param = '.$paid_param); 

                if  (has_valid_paidoption($paid_param, "urgent"))
                  $xtraparam .=  " `urgent` = 'yes'," ; else  $xtraparam .=  " `urgent` = '".$urgent."',";
                if  (has_valid_paidoption($paid_param, "putontopgallery"))
                  $xtraparam .=  " `priority` = 'TOP'," ; else  $xtraparam .=  " `priority` = '".$priority."',";

                // vtag parameters
                if  (has_valid_paidoption($paid_param, "vtag1"))
                  $xtraparam .=  " `vtag1` = 'yes'," ; else  $xtraparam .=  " `vtag1` = '".$vtag1."',";
                if  (has_valid_paidoption($paid_param, "vtag2"))
                  $xtraparam .=  " `vtag2` = 'yes'," ; else  $xtraparam .=  " `vtag2` = '".$vtag2."',";
                if  (has_valid_paidoption($paid_param, "vtag3"))
                  $xtraparam .=  " `vtag3` = 'yes'," ; else  $xtraparam .=  " `vtag3` = '".$vtag3."',";
                if  (has_valid_paidoption($paid_param, "vtag4"))
                  $xtraparam .=  " `vtag4` = 'yes'," ; else  $xtraparam .=  " `vtag4` = '".$vtag4."',";
                if  (has_valid_paidoption($paid_param, "vtag5"))
                  $xtraparam .=  " `vtag5` = 'yes'," ; else  $xtraparam .=  " `vtag5` = '".$vtag5."',";

                  logfile('', '{main} : update | ad | isadmin | has found paid options and updating = '.$xtraparam); 
            } else {
              
              $xtraparam .=  " `priority` = '".$priority."', `urgent` = '".$urgent."'," ; // reset it  ! 
              $xtraparam .=  " `vtag1` = '".$vtag1."',";
              $xtraparam .=  " `vtag2` = '".$vtag2."',";
              $xtraparam .=  " `vtag3` = '".$vtag3."',";
              $xtraparam .=  " `vtag4` = '".$vtag4."',";
              $xtraparam .=  " `vtag5` = '".$vtag5."',";

              logfile('', '{main} : update | ad | isadmin | resetting the options = '.$xtraparam); 
            }

            // modify the first publiching date if its a move from 20 to 40  or 80 to 40
            if ($cur_status=="20" && $status=="40") {
                $xtraparam .=  " `firstpublisheddate` = '".$stamp_update."'," ; 
                $xtraparam .=  " `crondate` = '".$stamp_update."'," ; 

                logfile('', '{main} : update | ad | isadmin | setting thepublishing date  =  '.$xtraparam); 

              //  update the date on the options 
              if ($paid_param) {
                $paid_param = update_dates_on_paidoptions($paid_param); 
              }

              // Z6.0 : if SERVICES, increase the conso 
              if ($SERVICES_MULTI_EN){              
                //$rr= db_update_services('remain','-1', $userid,$ad_id);
                $rr= db_update_services('remain','-1', $rowx->userid,stripslashes($rowx->pid));
                if (!$rr['result']) { 
                    logfile('error', '{main} :  update | ad | isadmin | db_update_services  =  '.$rr['sqlerror']); 
                    die; 
                }
                else {
                  if ($rr['hasRemainToken']) {
                    notify_service_state_change($rr['id'], $rr['newsstatus']); 
                    $refresh_myservices=true;
                  } else {

                    $trigger_no_token_left=true; 

                    // 2 cases  : no services but some ads are available in the current plan (= free ads) or  no at all  ! 
                    // -- check on current plan: 
                    $lcur_user = $rr['cur_user']; 
                    $lcur_user_plan= stripslashes($lcur_user['plan']); 
                    logfile('debug', '{main} :  detected plan : '.$lcur_user_plan, __LINE__); 

                    // get the plan details
                    $plan_details = $general_catalogue['pricing_plan']['user'][$lcur_user_plan]['details']; 
                    foreach ($plan_details as $key => $record) {
                      if ($record['n']=="ad_nb"){
                        $ads_quota=  $record['val']; 
                        logfile('debug', '{main} :  details for plan on ad_nb  = '.$ads_quota, __LINE__); 
                        break; 
                      }
                    }

                    // check QUOTA vs CONSUMPTION 
                    if ((int)$ads_quota > 0){
                       $toto=1; // do nothing  
                       logfile('debug', '{main} :  detected ads quota  = '.$ads_quota, __LINE__); 
                       
                       $rrr = get_nb_ads_this_user($rowx->userid); 
                       $ads_conso = (int)$rrr['totadsnb']; 

                       logfile('debug', '{main} :  consumed ads  = '.$ads_conso, __LINE__); 

                       if ($ads_conso < (int)$ads_quota) $trigger_no_token_left=false;
                       else logfile('notice', '{main} :  NO TKEN on PLAN ! consumed ads  = '.$ads_conso, __LINE__); 

                    } 

                    // -- generate the final error if necessary and EARLY EXIT
                    if ($trigger_no_token_left){
                      // quit and inform that no token left to create any ads 
                      logfile('notice', '{main} :  update | ad | isadmin | db_update_services  =  NO ACTIVE TOKEN LEFT'); 
                      $message = "no tokens left on your subscribed services !";             
                      $json = array('success' => false,'message' => $message,'what' => $what,'action' => 'earlyexit','service_userid'=>$rowx->userid, 'service_planid'=>$rowx->pid);      
                      echo json_encode($json); die; 
                    }


                  }
                } // ask to refresh my services ! 
              }
            }
          }

          // case of deletion , remove  all payment options 
          if ($cur_status!="80" && $status=="80"){
             $xtraparam .=  " `priority` = '', `urgent` = ''," ; // reset it  !
             $paid_param=''; // force it to empty everything  ! 
             logfile('', '{main} : update | ad | isadmin | deleting all paid options '); 
          } 


          //Z7.0.0 special mode for vtag1
          if ($VTAG1_BOOLEAN && !$curuser_is_admin)  
            $xtraparam .=  " `vtag1` = '".$vtag1."',";

          // case of price change 
          if ($haspricechange){
            $xtraparam .=  "  
              `price2`='".$price2."',
              `pricetype2`='".$pricetype2."',
            "; 
            logfile('', '{main} : update | ad | price change detected'); 
          }

          $query = "UPDATE `".$dbThisTable."` SET   
            `moddate` = '".$stamp_update."', 
            `title`='".$title."',
            `description`= '".$description."',
            `hits`= '".$hits."',
            `likes`= '".$likes."',
            `catid`='".$catid."',
            `vfields`='".$cat_vfields_str."',
            `type`='".$type."',
            `paidoptions`='".$paid_param."',
            `priority`='".$priority."',
            `urgent`='".$urgent."',
            `price`='".$price."',
            `pricetype`='".$pricetype."',
            `imgname`='".$imgname."',
            `videoembed`='".$videoembed."',
            `video2`='".$video2."',
            `audiourl`='".$audiourlname."',
            `videourl`='".$videourlname."',
            `status`='".$status."',
            `userid`='".$userid."',
            `username`='".$username."',
            `phone`='".$phone."',
            `email`='".$email."',
            `location`='".$location."',
            `loclatlng`='".$loclatlng."',
            `loclat`='".$theloclat."',
            `loclng`='".$theloclng."',
            `loczipcode`='".$loczipcode."',          
            `loccity`='".$loccity."',
            `locdept`='".$locdept."',
            `locregion` ='".$locregion."',
            `loccountrycode`='".$loccountrycode."',
            `lochash`='".$lochash."',
            `links`='".$links."',
            `docurl`='".$docurlname."',
            `expiredate`='".$ad_expiredate."',

            ".$xtraparam. "
            `lochashregion` ='".$lochashregion."'
            
            WHERE ((`id` = '".$ad_id."')) ";
        } // end of AD

       // ---- USER --------------
       if (($what=="user") || ($what=="users") || ($what=="curuser")){
         
         $xtraparam=""; 
         if ( isset($_POST["password"]))  $xtraparam .=  "  `password`='".$password."'," ; 


         //Z720 - update IP only if not admin user
         if (!$curuser_is_admin) $xtraparam .=  "  `ip`='".$serverremoteaddr."',  " ; 

         // assocprojects=10 means that userwill become super admin . and can only be done by a super admin level right 
         if ( isset($_POST["assocprojects"]) && $curuser_is_superadmin)  $xtraparam .=  "  `assocprojects`='10'," ;
         else $xtraparam .=  "  `assocprojects`=''," ; 

          $query = "UPDATE `".$dbThisTable."` SET   
            `username` = '".$username."', 
            ".$xtraparam."
            `usertype`= '".$usertype."',
            `userid`= '".$userid."',
            `firstname`='".$firstname."',
            `lastname`='".$lastname."',
            `email`='".$email."',
            `phone`='".$phone."',
            `status`='".$status."',
            `userid`='".$userid."',
            `lastvisitdate`='".$stamp_update."',
            `imgurl`='".$imgname."',
            `imgpath`='".$imgpath."',
            `location`='".$location."',
            `gender`='".$gender."',
            `locale`='".$locale."',
            `auth`='".$auth."', 
            `avatarimg`='".$avatarimgname."',
            `probannerimg`='".$probannerimgname."',
            `probannerurl`='".$probannerurl."',
            `audiourl`='".$audiourlname."',
            `videourl`='".$videourlname."',
            `folioimg`='".$folioimgname."',
            `skills`='".$skills."', 
            `priority`='".$priority."',
            `expiredate`='".$stamp_update."',
            `protype`='".$protype."',
            `indir`='".$indir."',
            `banclicks`='".$banclicks."',
            `procpny`='".$procpny."',        
            `prosiret`='".$prosiret."',
            `prowebsite`='".$prowebsite."',
            `social`='".$social."',
            `loclatlng`='".$loclatlng."',
            `loclat`='".$theloclat."',
            `loclng`='".$theloclng."',
            `loczipcode`='".$loczipcode."',          
            `loccity`='".$loccity."',
            `locdept`='".$locdept."',
            `locregion` ='".$locregion."',
            `loccountrycode`='".$loccountrycode."',
            `lochash`='".$lochash."',
            `lochashregion` ='".$lochashregion."',
            `bio` ='".$bio."',
            `paidoptions`='".$paid_param."',
            `moddate` ='".$stamp_update."',
            `videoembed`='".$videoembed."',
            `plan`='".$plan."',
            `longdesc`='".$longdesc."',
            `openhours`='".$openhours."',
            
            `useragent`='".$useragent."',
            `desc2`='".$desc2."',
            `desc3`='".$desc3."',
            `cat2`='".$cat2."',
            `cat3`='".$cat3."',
            `links`='".$links."',
            `email2`='".$email2."',
            `phone2`='".$phone2."',
            `address2`='".$address2."',
            `date2`='".$date2."',
            `vfields`='".$user_vfields_str."',
            `newsletter`='".$in_newletter."',
            `verify`='".$verify."', 
            `dob`='".$dob."' 

            WHERE ((`id` = '".$ad_id."')) "; 

          // newsletter management
          if ($in_newletter=="yes") $action_newsletter="subscribe";
          else $action_newsletter="unsubscribe";

        }        
      }
      

      //-------------------- UPDATESTATUS -------------------------------------/ 
      if (($action == "updatestatus" )){
        //----- CATS -----  
        if (($what=="cats") || ($what=="cat")){
          $stamp_update2= date( 'Y-m-d H:i:s', time());
          $query = "UPDATE `".$dbThisTable."` SET   
            `moddate` = '".$stamp_update2."', 
            `status`='".$status."'
            WHERE ((`id` = '".$ad_id."')) ";
        }

        //----- AD -----  
        if (($what=="item") || ($what=="ad"))
        {
          $stamp_update2= date( 'Y-m-d H:i:s', time());
          $xtraparam =''; 

          // make a pre-query to get some info on pricing and others 
          $queryx = "SELECT i.`id`, i.`status`, i.`paidoptions`, i.`userid`, c.`pid` FROM `$dbThisTable` i 
            LEFT JOIN `$dbCatsTable` c ON i.`catid`= c.`id`
            WHERE ((i.`id` = '".$ad_id."'))"; 
          $resultx = mysql_query($queryx); $rowx = mysql_fetch_object($resultx);
          $cur_status =  $rowx->status; $cur_paidoptions= $rowx->paidoptions;
         
          if (($cur_status=="10" || $cur_status=="20") && $status=="40") {
            $xtraparam .=  " `firstpublisheddate` = '".$stamp_update2."'," ; 
            $xtraparam .=  " `crondate` = '".$stamp_update2."'," ; 

            //  update the date on the options 
            if ($cur_paidoptions) {
              $cur_paidoptions = update_dates_on_paidoptions($cur_paidoptions); 
            }

            // Z6.0 : if SERVICES, increase the conso 
            if ($SERVICES_MULTI_EN){              
              $rr= db_update_services('remain','-1', $rowx->userid,$rowx->pid);
              if (!$rr['result']) {
                logfile('error', 'updatestatus | ad |  db_update_services  =  '.$rr['sqlerror']); 
                var_dump($rr); die;
              }
              else {
                notify_service_state_change($rr['id'], $rr['newsstatus']); 
                $refresh_myservices=true;
              } // ask to refresh my services ! 
            }

            // Z6.0 : update nbr of ads 
            $re_totnbads = db_list_ads_nbr($rowx->userid); 

          }

          // check for PAIDoptions for force variables for URGENT and PUTONTOPGALLERY
          if ($cur_paidoptions) {
            if  (has_valid_paidoption($cur_paidoptions, "urgent"))
              $xtraparam .=  " `urgent` = 'yes'," ; 
            if  (has_valid_paidoption($cur_paidoptions, "putontopgallery"))
              $xtraparam .=  " `priority` = 'TOP'," ; 
          } 

          $query = "UPDATE `".$dbThisTable."` SET   
            `moddate` = '".$stamp_update2."', 
             ".$xtraparam."
            `status`='".$status."'
            WHERE ((`id` = '".$ad_id."')) ";
        }
       
        //----- USER -----  
        if (($what=="user") || ($what=="users") || ($what=="curuser")) 
        {
         
          // make a pre-query to get some info on pricing and others 
          $queryx = "SELECT `id`, `status`, `plan` FROM `$dbThisTable` WHERE ((`id` = '".$ad_id."'))"; 
          $resultx = mysql_query($queryx); $rowx = mysql_fetch_object($resultx);
          $cur_status =  $rowx->status; $cur_plan= $rowx->plan;

          // whatever happens, make the query 
          $query = "UPDATE `".$dbThisTable."` SET   
            `status`='".$status."'
            WHERE ((`id` = '".$ad_id."')) ";  


            // complement with Services if enabled 
            if ($SERVICES_MULTI_EN){
              if (($cur_status=="10" || $cur_status=="20") && $status=="40") {
                $r=db_services_action('create', $ad_id, $cur_plan); // add the service
                if (!$r['result']) {var_dump($r); die;}
              } 
            }
        }

      } // end updatestatus 

     } // enc global IF on create, update and updatestatu

    //-------------------- DELETE -------------------------------------/
    if (($action == "delete")) {
        // get images and delete images 
        $filterx="WHERE `id`='".$ad_id."'"; 
        $queryx = "SELECT * FROM `$dbThisTable` " .$filterx; 
        $resultx = mysql_query($queryx);
        $rowx = mysql_fetch_object($resultx);
        
        if ($what=="user") $imgname = $rowx->imgurl;
        else $imgname = $rowx->imgname;
        
        if ($imgname && ($imgname!="")){
          foreach(explode(";",$imgname) as $imgnameItem) { 
              $successx = unlink($dest_path."".$imgnameItem);  // delete main file 
              $successx = unlink($dest_path."tn_".$imgnameItem); // delete tn file
          }
        } 
        // make the delete action 
        delete_files($what, $ad_id); // delete files 
        sql_delete_item($what, $ad_id); // delete all from an item incuding logs and associated pictures
    }
    
    //-------------------- UPDATE fav -------------------------------------/
    if (($action == "updatefav")) {
      if (($what=="ad")){
        $upvalue="";
        // get the existing value
        $filterx="WHERE `id`='".$userid."'"; 
        $queryx = "SELECT `favads` FROM `$dbUsersTable` " .$filterx;     
        $resultx = mysql_query($queryx);
        if ($resultx) {
          $rowx = mysql_fetch_array($resultx);
          if ($action2=="add"){
            $upvalue= $rowx["favads"].";".$newfav;
          } else {
            //$pattern = '/;'+$newfav+'/';
            $pattern = ';'.$newfav; 
            $upvalue = $rowx["favads"];
            $upvalue = str_replace($pattern, "", $upvalue, $count);  
          }
          $query = "UPDATE `".$dbUsersTable."` SET   
            `favads` = '".$upvalue."'
            WHERE ((`id` = '".$userid."')) ";
        }
        $item=Array ('favs'=> $upvalue); // retun the date 
       }
    }
    
    //-------------------- UPDATE hitcounter -------------------------------------/
    if (($action == "updatehit") ) {
        $query = "UPDATE `".$dbThisTable."` SET   
          `hits` = `hits`+1
          WHERE ((`id` = '".$id."')) ";
    }

    //-------------------- RESET hitcounter -------------------------------------/
    if (($action == "resethits")) {
        $query = "UPDATE `".$dbThisTable."` SET   
          `hits` = 0
          WHERE ((`id` = '".$adid."')) ";
    }

    //-------------------- UPDATE hitcounter -------------------------------------/
    if (($action == "updatelikes") ) {
        $query = "UPDATE `".$dbThisTable."` SET   
          `likes` = `likes`+1
          WHERE ((`id` = '".$id."')) ";
    }

    //-------------------- RESET hitcounter -------------------------------------/
    if (($action == "resetlikes")) {
        $query = "UPDATE `".$dbThisTable."` SET   
          `likes` = 0
          WHERE ((`id` = '".$adid."')) ";
    }


     //-------------------- UPDATE Order (case of category) -------------------------------------/
    if (($action == "updateorder") && ($what=="cat" || $what=="cats")) {
        $query = "UPDATE `".$dbThisTable."` SET   
          `order` = ".$catorder."
          WHERE ((`id` = '".$id."')) ";
    }
     
    //-------------------- LIST -------------------------------------/
    if (($action == "list") || ($action == "autosearch")) {
      // initiate the vars
      $filter=""; 
      $onjoint="";
    
      // patch for favorites
      if ($type=="favs"){
        $statusfilter=""; // take all "released articles 
        // get fav list from user profil
        $filterx="WHERE `id`='".$userid."'"; 
        $queryx = "SELECT `favads` FROM `$dbUsersTable` " .$filterx; 
        $resultx = mysql_query($queryx);
        if ($resultx) {
          $rowx = mysql_fetch_array($resultx); // get only the fisrt one 
          $fo = false; 
          $filtery=""; 
          foreach(explode(";",$rowx['favads']) as $favItem) {
            if  ($favItem!="") {
              $filtery .= " '".$favItem."',"; 
              $fo=true; 
            }
          }
          if ($fo) { // build only if one result found
            $filterx=" `$dbThisTable`.`id` IN (".substr($filtery, 0, strlen($filtery)-1).") "; 
             if ($filter=="") $filter.="  WHERE ($filterx)"; else $filter.="  AND ($filterx)";
           } else {
              // Dummy query to return zero value
              $filterx=" `$dbThisTable`.`id` IN ('999999') "; 
              if ($filter=="") $filter.="  WHERE ($filterx)"; else $filter.="  AND ($filterx)";
          }  
        }
      } // end FAVS 

      // ----------------  manage the  ORDER-BY and DIRECTION and default
      // check of unsupported mecanims 
      if (
            (($sort_by=="pid") && !$isCat) // PID only for CATS 
            || ( ($sort_by=="totnbads")  && $isAd )
            || ( ($sort_by=="price")  && !$isAd)
            ) 
      { $sort_by=""; $sort="";  }

      // special case of sort by DISTANCE 
      $sort_stub=""; //
      if ($sortdist){
            $sql_sort2="  ORDER BY  `locdist` ASC,  `".$sort_by."` ".$sort_dir;
            //$sort_stub="  `locdist` ASC,  `".$sort_by."` ".$sort_dir;
      }

      //$sql_sort2="false";
      if (($priority=="top")||($priority=="topgallery")) 
        $sql_sort=" ORDER BY RAND()";// sort by random number for TOP PRIORITIES
      else if ($sort) 
      {         
          if  ( ($sort_by=="totnbads") )
            $sql_sort="  ORDER BY `".$sort_by."` ".$sort_dir;

          else if ( ($sort_by=="pid") )
            $sql_sort="  ORDER BY `$dbThisTable`.`".$sort_by."` ".$sort_dir. ", `$dbThisTable`.`order`, `$dbThisTable`.`title` ";

          else 
            $sql_sort="  ORDER BY `$dbThisTable`.`".$sort_by."` ".$sort_dir;
      } 
      else {
        // case of DEFAULT SORT  MECANISMS 
        if (($what=="cats") ||   ($what=="cat")){
          $sortoriginal="pid_asc"; 
          $sql_sort=" ORDER BY  `$dbThisTable`.`pid` ASC, `$dbThisTable`.`order`  ";  // ----- default Sort mecanism for CAT

        } else if (($what=="users")|| ($what=="user"))  {
          $sql_sort=" ORDER BY  `$dbThisTable`.`moddate` DESC ";  // default Sort mecanism
        }
        else {
          $sql_sort=" ORDER BY  `$dbThisTable`.`moddate` DESC ";  // ----- default Sort mecanism
        }
      }
      if (!$sql_sort2)  $sql_sort2=$sql_sort; 

      //$sql_sort2=$sqlsort; 
      
      // filter per TYPE
      if ((($type) || ($fwhat)) && ($type !="favs"))  {
        if (($fwhat)  &&  ($fwhat != "users")) { $typevalue =  $fwhat; $typeoriginal= $fwhat;}
        else $typevalue= $type; 
        if ($filter=="") $filter.="  WHERE `$dbThisTable`.`type` =  '".$typevalue."' "; else $filter.="  AND `$dbThisTable`.`type` =  '".$typevalue."' ";
      } else // not type defined, filter the ZETVU
        if ((($what=="ad") ||  ($what=="item")) && ($nav!="admin"))
          if ($filter=="") $filter.="  WHERE `$dbThisTable`.`type` NOT LIKE  'zetvu'"; else $filter.="  AND `$dbThisTable`.`type` NOT LIKE  'zetvu' ";


      //filter per protype (User only) 
      $f_protype_stub=''; // this copy of the sub will be used to remove the clause from the filter
      if (($utype) && $isUser) {
        $f_stub = " `$dbThisTable`.`protype` =  '$utype' ";
        $f_protype_stub = $f_stub ; 
        $f_protype_stub = ($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
        $filter.=$f_protype_stub;
      }

      //filter per protype (all cases when FTYPE is used ! ) 
      if ($ftype){
        // do not specify the DB to be used for both ad and users 
        $f_stub = " `$dbUsersTable`.`protype` =  '$ftype' ";
        $f_protype_stub = $f_stub ; 
        $f_protype_stub = ($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
        $filter.=$f_protype_stub;
      }


      //filter per location  (ad and users) 

      //preprocessing

      // if ($flocregion){ $locfield="locregion";  $locval=$flocregion; }
      // if ($flocdept){ $locfield="locdept";  $locval=$flocdept; }


      //filter per location  (ad and users) 
      if ($flocregion){ $locfield="locregion";  $locval=$flocregion; }
      if ($flocdept!=''){ $locfield="locdept";  $locval=$flocdept; }
      if ($floczipcode!=''){ $locfield="loczipcode";  $locval=$floczipcode; }
      if ($floccity!=''){ $locfield="loccity";  $locval=$floccity; }

      // extra forced country
      if ($fforcedlocountry) { $locfield="loccountrycode";  $locval=$fforcedlocountry; }


      // second level of search 
      if ($f_flocregion){ $locfield="locregion";  $locval=$f_flocregion; }
      if ($f_flocdept!=''){ $locfield="locdept";  $locval=$f_flocdept; }
      if ($f_floczipcode!=''){ $locfield="loczipcode";  $locval=$f_floczipcode; }
      if ($f_floccity!=''){ $locfield="loccity";  $locval=$f_floccity; }
     
      if (($locfield) && ($isUser || $isAd)){
        $f_stub = " `$dbThisTable`.`$locfield` =  '$locval' ";
        $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
      }

      //filter per URGENT flag (ads only)
      if (($furgent) && $isAd){
        // $f_stub = " `$dbThisTable`.`paidoptions` like '%urgentad%' ";
        $f_stub = " `$dbThisTable`.`urgent` = 'yes' ";
        $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
      }

      if (($fwithphoto) && $isAd){
        $f_stub = "  ( `$dbThisTable`.`imgname` != '' ) ";
        $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
      }

      if (($fwithaudio) && $isAd){
        $f_stub = "  ( `$dbThisTable`.`audiourl` != '' ) ";
        $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
      }

      if (($fwithvideo) && $isAd){
        $f_stub = "  ( `$dbThisTable`.`videourl` != '' ) ";
        $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
      }


      /// z5.5 - filter per vfields 
      if (count($f_vfields)>0 ) {
        foreach ($f_vfields as $key => $value){
          $keyAr = explode( '-', $key);
          if (count($keyAr) > 1) {
            //we have a special case 
            if (($keyAr[0]=="min") || ($keyAr[0]=="max")){
              $filterpair = $keyAr[1]."="; // just extract the eements with the below field
              
              //$f_stub = " `$dbThisTable`.`vfields` like  '%$filterpair%' ";
              if ($value){
                // treat the value 
                // detect is there is a plus into the text
                $sup=false;
                if (count(explode('+',$value )) > 1){
                  $sup=true; 
                  $valueA_tmp=explode('+',$value ); 
                  $value=$valueA_tmp[0]; $value=$value*1;
                } else {
                  $value= str_replace(" ", "", $value); // remove thousand separator 
                  $value=$value*1; 
                }

                // do depending on the search field
                if ($keyAr[1]=="price") {
                  $value= str_replace(" ", "", $value); // once more ! 
                  // special case for price field 
                   if ($keyAr[0]=="min")
                      $f_stub  = " `$dbThisTable`.`price` >= $value "; 
                    if ($keyAr[0]=="max") {
                      if (!($sup)) $f_stub  = " `$dbThisTable`.`price` <= $value "; 
                      else $f_stub='';
                    }               
                } else {
                  if ($keyAr[0]=="min")
                    $f_stub  = "CONVERT(SUBSTRING_INDEX(SUBSTRING_INDEX(`$dbThisTable`.`vfields`,'$filterpair', -1), '|', 1),UNSIGNED INTEGER) >= $value"; 
                  if ($keyAr[0]=="max")
                    $f_stub  = "CONVERT(SUBSTRING_INDEX(SUBSTRING_INDEX(`$dbThisTable`.`vfields`,'$filterpair', -1), '|', 1),UNSIGNED INTEGER) <= $value"; 
                }

                if ($f_stub) $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
              }
            }
          } else {
            $filterpair ="$key=$value"; 
            if ($value){
              $f_stub = " `$dbThisTable`.`vfields` like  '%$filterpair%' ";
              $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
            }
          }
        }
      }

      // filter per CATID
      if (($catid) || ($fcat)) {
        if ($catid) $catvalue= $catid ; 
        if ($fcat) { $catvalue= $fcat ; $catid = $fcat ; $catidoriginal = $fcat; }

        if ($isUser) {
          if ($ispid == "yes" || $fispid=="yes")
            // $filterx = "`$dbCatsTable`.`pid` =  '".$catvalue."' "; 
            // changed in ZAD6.5.3 -> when 2 levels of CATEGORIES, we use the cat2 element 
            if ($MAINCAT_USER_PID) {
            $filterx = "`$dbThisTable`.`cat2` =  '".$catvalue."' "; 
            } else 
            $filterx = "`$dbCatsTable`.`pid` =  '".$catvalue."' "; 
          else 
            $filterx =  "`skills` like  '%c=".$catvalue."%' ";
        }
        else {
          if ($ispid == "yes" || $fispid=="yes")
            $filterx = "`$dbCatsTable`.`pid` =  '".$catvalue."' "; 
          else     
            $filterx = " `$dbThisTable`.`catid` =  '".$catvalue."' "; 
        }
        $filter .= ($filter=="") ?  "  WHERE ".$filterx :  "  AND ".$filterx; 
      }
       
      // filter per STATUS defined
      if ($statusfilter) {
        // if (($what=="users") || ($what=="user")){
        //   if ($statusfilter=="all") 
        //     $filter.="";
        //  }else{

          //protection againts access withrout authorization to ressources
          if ($statusfilter!="" && !$curuser_is_owner && !$curuser_is_admin && !$curuser_is_superadmin ) $statusfilter="";  

          // status filters for ADS & CATS 
          if (($statusfilter=="not created"))
            if ($filter=="") $filter.="  WHERE `$dbThisTable`.`status` IN ('00') "; else $filter.="  AND `$dbThisTable`.`status` IN ('00')  ";
          if (($statusfilter=="pending") || ($statusfilter=="under review"))
            if ($filter=="") $filter.="  WHERE `$dbThisTable`.`status` IN ('20') "; else $filter.="  AND `$dbThisTable`.`status` IN ('20')  ";
          else if ($statusfilter=="published") 
            if ($filter=="") $filter.="  WHERE `$dbThisTable`.`status` IN ('40','45') "; else $filter.="  AND `$dbThisTable`.`status` IN ('40','45') "; 
          else if ($statusfilter=="unpublished") 
            if ($filter=="") $filter.="  WHERE `$dbThisTable`.`status` IN ('60') "; else $filter.="  AND `$dbThisTable`.`status` IN ('60') ";   
          else if ($statusfilter=="rejected") 
            if ($filter=="") $filter.="  WHERE `$dbThisTable`.`status` IN ('90') "; else $filter.="  AND `$dbThisTable`.`status` IN ('90') ";   
          else if ($statusfilter=="deleted") 
            if ($filter=="") $filter.="  WHERE `$dbThisTable`.`status` IN ('80') "; else $filter.="  AND `$dbThisTable`.`status` IN ('80')  ";
          else if ($statusfilter=="draft") 
            if ($filter=="") $filter.="  WHERE `$dbThisTable`.`status` IN ('10','60','90') "; else $filter.="  AND `$dbThisTable`.`status` IN ('10','60','90')  ";
          else if ($statusfilter=="draft pending payment") 
            if ($filter=="") $filter.="  WHERE `$dbThisTable`.`status` IN ('15','16','17') "; else $filter.="  AND `$dbThisTable`.`status` IN ('15','16','17')  ";
          else if ($statusfilter=="draft payment cancel") 
            if ($filter=="") $filter.="  WHERE `$dbThisTable`.`status` IN ('17') "; else $filter.="  AND `$dbThisTable`.`status` IN ('17')  ";
          else if ($statusfilter=="willexpire") 
            //if ($filter=="") $filter.="  WHERE `status` IN ('40') AND `moddate` < '".$stamppast."'"; else $filter.="  AND `status` IN ('40')  AND `moddate` < '".$stamppast."'";
            if ($filter=="") $filter.="  WHERE `$dbThisTable`.`status` IN ('45') "; else $filter.="  AND `status` IN ('45')";
          else if ($statusfilter=="all") {
            $filter.=""; 
          }

        //}
      }
      else  // in case no filter defined 
        if (($what=="cats")|| ($what=="cat")) $filter.="";
        else if ($in_action=="display") $filter.=""; // we get every status for display elements and then filter it later on.
        else if (($what=="users") || ($what=="user"))  { 
          // fister on public and pro profils (if anonymous) and registered 
          //if ($curuser_is_admin) 
          //  $filter.= ($filter=="") ? "  WHERE `protype` IN ('pri', 'pub','pro') " : "  AND `protype` IN ('pri', pub','pro') "  ; 
          //else 
            $filter.= ($filter=="") ? "  WHERE `indir` IN ('yes') " : "  AND `indir` IN ('yes') "  ; 

          $filter.= ($filter=="") ? "  WHERE `$dbUsersTable`.`status` IN ('40','45')  " : "  AND `$dbUsersTable`.`status` IN ('40','45')  " ;
          // filter on ads which is really published 
          $onjoint .= "  AND `$dbItemsTable`.`status` IN ('40','45')  "  ; 
          //$filter.= ($filter=="") ? "  WHERE `$dbItemsTable`.`status` IN ('40','45')  " : "  AND `$dbItemsTable`.`status` IN ('40','45')  " ;
          
        }
        else if (($what=="curuser")) $filter.= " ";
        else if ($filter=="") $filter.="  WHERE `$dbThisTable`.`status` IN ('40','45') "; else $filter.="  AND `$dbThisTable`.`status` IN ('40','45')  "; 
      
      // filter per USERID 
      if (($userid) && ($type!="favs"))  
        if ($filter=="") $filter.="  WHERE  `$dbThisTable`.`userid` =  '".$userid."' "; 
        else $filter.="  AND  `$dbThisTable`.`userid` =  '".$userid."'  ";
      
      // filter per ID 
      if($id){
        if ($filter=="") $filter.="  WHERE `$dbThisTable`.`id` = '".$id."' "; else $filter.="  AND `$dbThisTable`.`id` = '".$id."'   ";
      }
      
      // filter per PRIORITY 
      if($priority){
        
        if ($priority == "topgallery") $priority="top"; // force for time beeing 

        if ($filter=="") $filter.="  WHERE `$dbThisTable`.`priority` = '".$priority."' "; 
        else $filter.="  AND `$dbThisTable`.`priority` = '".$priority."'   ";
      }
            
      // filter for the SEARCH
      if ($search)  {
          $search = trim($search); // delete surrounding spaces
          $searcha = explode(" ", $search); // make array of individual words
          $sfilterAr=array();
  
          //Cycle through the words-array if there are word(s) filled in
          if (isset($searcha)) {

            if (($what=="users") || ($fwhat=="users")  || ($fwhat=="user")) {
              $sfilterAr[] = " ((lower(`$dbUsersTable`.`firstname`) like ";
              $sfilterAr[] = "   ) OR (lower(`$dbUsersTable`.`lastname`) like ";
              $sfilterAr[] = "   ) OR (lower(`$dbUsersTable`.`location`) like ";
              $sfilterAr[] = "   ) OR (lower(`$dbUsersTable`.`procpny`) like ";

              if ($curuser_is_admin)  $sfilterAr[] = "   ) OR (lower(`$dbUsersTable`.`email`) like ";
              if ($curuser_is_admin)  $sfilterAr[] = "   ) OR (lower(`$dbUsersTable`.`username`) like ";

            }
             else if ($isAd) {
              if ($ftitleonly) {
                $sfilterAr[] = " ((lower(`$dbThisTable`.`title`) like ";
               } else { 
                $sfilterAr[] = " ((lower(`$dbThisTable`.`title`) like ";
                $sfilterAr[] = "   ) OR (lower(`$dbThisTable`.`description`) like ";
                $sfilterAr[] = "   ) OR (lower(`$dbThisTable`.`location`) like ";
                $sfilterAr[] = "   ) OR (lower(`$dbThisTable`.`lochash`) like ";
              }
            } else { // categories 
              $sfilterAr[] = " ((lower(`$dbThisTable`.`title`) like ";
              $sfilterAr[] = "   ) OR (lower(`$dbThisTable`.`description`) like ";
              $sfilterAr[] = "   ) OR (lower(`$dbThisTable`.`id`) like ";
            }


            $searchfilter=""; 
              for($i = 0; $i < count($searcha); $i++) 
              {
                for($j = 0; $j < count($sfilterAr); $j++) {
                  $searchfilter .= $sfilterAr[$j]." '%" . $searcha[$i] . "%' " ;
                }
                $searchfilter .= "))";
                if ($i < count($searcha)-1) $searchfilter.= " AND ";
              }
            if ($filter=="") 
              $filter.="  WHERE (".$searchfilter.") "; 
            else 
              $filter.="  AND (".$searchfilter.") "; 
          }
        }



     // filter for ADULT catagories
     // remove adult categories from filter if no cookie is set 
     // not applicable for CATEGORIES of if the user is admin ! 
      if ($what!="cat" &&  $what!="cats" && $what!="user" && $what!="users" && !$curuser_is_admin){
        if ($FILTER_ADULT_IN_LIST){
          if (isset($_COOKIE[$COOKIENAME."_ADULT_ACCEPT"])){$toto=1;} // do nothing 
          else {
            if (!$curuser_is_owner){
              $f_stub = " ( `$dbCatsTable`.`adultflag` =  '' OR `$dbCatsTable`.`adultflag` IS NULL ) ";
              $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
            }
          }
        }
      }

      // filter for audio/video
      if ($vieworiginal=="videogallery"){
        $f_stub = " `$dbThisTable`.`videoembed` !=  '' ";
        $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
      }

      if ($vieworiginal=="audiogallery"){
        $f_stub = " `$dbThisTable`.`audiourl` !=  '' ";
        $filter.=($filter=="") ? " WHERE $f_stub " : " AND $f_stub "; 
      }

      
      // ---   generate the LIMIT filter
      $xxitems =  ($eppage) ? (int)$eppage:  (int)$xmaxitems;
      // if ($what=="cats") $xxitems = 50;

      $itemstart = ((int)$paged -1) * $xxitems; 
      $limit = "LIMIT ".$itemstart.", ".$xxitems; 


      // if sidebar or module,  change the limit filter to the one defined into the settings
      if (($nav=="sidebar") || ($nav=="topbanner")) {
        $limitend = (int)$display_settings["max_items_per_mod"]; 
        $limit = "LIMIT 0 , ". $limitend; 
      }

      if ($nav=="userrelads"){
        if (isset($USERRELADS_NBR)) $limit = "LIMIT 0 , $USERRELADS_NBR "; 
        else  $limit = "LIMIT 0 , 3 "; 
      }


      $resultAsList=false; 
      if (($what=="users") || ($what=="user") || ($what=="curuser")) {
        
        // for totnbads, precise the filter string 
         if (($nav=="display") && (!$curuser_is_admin) && !($what=="curuser")) {
           $f_stub ="  `$dbItemsTable`.`status` IN ('40','45', '46') ";   
           $filter3=($filter=="") ? " WHERE $f_stub " : " AND $f_stub ";
           $queryfull = "SELECT `$dbThisTable`.`id`, count(`$dbItemsTable`.`id`) as totnbads 
                        FROM `$dbThisTable` 
                        LEFT OUTER JOIN `$dbItemsTable` ON `$dbItemsTable`.`userid`= `$dbThisTable`.`id`  
                        " .$filter3." $filter GROUP BY `$dbThisTable`.`id`  ".$sql_sort;
           $resultAsList =true; 
        } else {
          // $filter3=$filter;
          // remove the pro-filter is exist 
          if ($f_protype_stub)  $filter3 = str_replace($f_protype_stub, " ", $filter);
          else $filter3 = $filter ; 

          $queryfull = "SELECT count(`$dbThisTable`.`id`) as 'totall' ,
                        count(case when `$dbThisTable`.`protype` = 'pro' then 1 else null end) as 'totpro', 
                        count(case when `$dbThisTable`.`protype` = 'par' then 1 else null end) as 'totpar',
                        count(case when `$dbThisTable`.`protype` = '' then 1 else null end) as 'totnull' 
                        FROM `$dbThisTable`   " .$filter3;
        }
      }
      else  {
        if ($isAd){

          // remove the pro-filter is exist 
           if ($f_protype_stub) $filter3 = str_replace($f_protype_stub, " ", $filter);
          else $filter3 = $filter ;


          $queryfull = "SELECT count(`$dbThisTable`.`id`) as 'totall' ,
                          count(case when `".$dbUsersTable."`.`protype` = 'pro' then 1 else null end) as 'totpro', 
                          count(case when `".$dbUsersTable."`.`protype` = 'par' then 1 else null end) as 'totpar',
                          count(case when `".$dbUsersTable."`.`protype` = '' then 1 else null end) as 'totnull'
                          FROM `$dbThisTable`
                          LEFT OUTER JOIN `$dbCatsTable` ON `$dbCatsTable`.`id`= `$dbThisTable`.`catid`  
                          LEFT OUTER JOIN `$dbUsersTable` ON `$dbUsersTable`.`id`= `$dbThisTable`.`userid`   
                          " .$filter3;
        }
        else {
          // categories
          $filter3=$filter; 
          $queryfull = "SELECT count(`$dbThisTable`.`id`) as 'totall' 
                        FROM `$dbThisTable`
                        " .$filter3 ; 
        }
      }
      $t0=microtime(true);         
      $resultfull = mysql_query($queryfull);
      if ($resultAsList)
        $totnbrofresults = mysql_num_rows($resultfull);
      else {
        $resultfullrow = mysql_fetch_object($resultfull); 
        $totnbrofresults = $resultfullrow->totall ; 
      }

    
      $deltatime= (microtime(true)-$t0); 
      $timing_trace.= "|QUERYFULL_in ".sprintf("%01.3f", $deltatime). "sec <br>\n "; 
      $t0=microtime(true); 
      
      // ----  get list of associated categories for the give What & type
      if (($nav!="sidebar") && ($nav!="topbanner")) {
        $itemcat = sql_get_cat_list($what, $type, $search, $dbThisTable, '', $catid, $locfield ,$locval);

       // new zads 4.9 -> browse per location module 
        if ($ENABLE_BROWSEBYLOC_MOD){
          $itemloclist = sql_get_loc_list($what, $type, $search,'', $dbThisTable, 'ext', $catid, $locfield ,$locval);
        }
      }

      // ORDER BY RAND()

      // --- @zads4.6 order by distance
      // - add the distance field into all search
      // Build the spherical geometry SQL string
      if ((($what=="ad") ||  ($what=="item"))){
        if ($LOCALE_DEFAULT_UNIT=='m') $earthRadius = '3963.0'; // In miles
        else $earthRadius = '6366.0'; // in Kms
        // $inlat='48.4887003'; 
        // $inlong='7.711082000000033'; 
        if ($curuser_loclatlng) { 
          $theloc =explode("|", $curuser_loclatlng);  
          $inlat =  $theloc[0]; 
          $inlong = $theloc[1]; 
        // else { $inlat='0'; $inlong='0'; }
        $distanceSQLField = " ROUND( $earthRadius * ACOS(
                              SIN( $inlat*PI()/180 ) * SIN(`$dbThisTable`.`loclat`*PI()/180 )
                              + COS( $inlat*PI()/180 ) * COS(`$dbThisTable`.`loclat`*PI()/180 )  
                              *  COS( (`$dbThisTable`.`loclng`*PI()/180) - ($inlong*PI()/180) ) )
                              , 1) AS locdist"; 
         $extraSQLField =  " , $distanceSQLField  "; 
        }

     }
       else $extraSQLField='';

       // ORDER BY distance ASC
      //$extraSQLField='';

      
      // #############   define the final query whatever the request if  !  ###############
      $query = "SELECT * $extraSQLField FROM `$dbThisTable` " .$filter." ".$sql_sort2." ".$limit; 
     

      // if listing of Users or Cats, add the total number of adds associated with this user 
      if (($what=="cats") || ($what=="cat")) 
        $query = "SELECT `$dbThisTable`.*, count(`$dbItemsTable`.`id`) as totnbads FROM `$dbThisTable` LEFT OUTER JOIN `$dbItemsTable` ON `$dbItemsTable`.`catid`= `$dbThisTable`.`id`  " .$filter." GROUP BY `$dbThisTable`.`id` ".$sql_sort." ".$limit;

      if ( $isUser || ($what=="curuser")) {

        // if ($catid) {
        //   $query = "SELECT `$dbThisTable`.*, 
        //             count(`$dbItemsTable`.`id`) as totnbads 
        //           FROM `$dbThisTable` 
        //           LEFT OUTER JOIN `$dbItemsTable` ON `$dbItemsTable`.`userid`= `$dbThisTable`.`id`
        //           LEFT OUTER JOIN `$dbCatsTable` ON  `$dbThisTable`.`skills` LIKE   '%c=`$dbCatsTable`.`id`%'  
        //           ". $onjoint . " " .$filter." GROUP BY `$dbThisTable`.`id` ".$sql_sort." ".$limit;
        // } else {

          if (($nav=="display") && (!$curuser_is_admin) && !($what=="curuser")) {
             $on_stub ="  AND `$dbItemsTable`.`status` IN ('40','45', '46') ";  

             // add control on privacy and visibility of add
             // $f_stub ="  `$dbThisTable`.`protype` IN ('pro','pub') ";   
             // $f_stub ="  `$dbThisTable`.`indir` IN ('yes') ";   
             // $filter .=($filter=="") ? " WHERE $f_stub " : " AND $f_stub ";

           } else  {
              $on_stub='';
              
              //use this filter to accelerate the search
              // $f_stub ="  `$dbItemsTable`.`userid` = `$dbThisTable`.`id` ";   
              // $filter .=($filter=="") ? " WHERE $f_stub " : " AND $f_stub ";

            }

             $query = "SELECT `$dbThisTable`.*,  
                  count(`$dbItemsTable`.`id`) as totnbads 
                  FROM `$dbThisTable` 
                  LEFT JOIN `$dbItemsTable` ON `$dbThisTable`.`id` = `$dbItemsTable`.`userid` $on_stub 
                  ". $onjoint . " " .$filter." GROUP BY `$dbThisTable`.`id` ".$sql_sort." ".$limit;


    // count(`$dbItemsTable`.`id`) as totnbads 

             // $query = "SELECT `$dbThisTable`.*, 
             //        `$dbThisTable`.`id` as totnbads  
             //      FROM `$dbThisTable` 
             //       " .$filter." ".$sql_sort." ".$limit;

        //}

      }

      // add for Ad the type of User profile (if private, dont display a link !)
      if (($what=="ad") || ($what=="ads") ||  ($what=="items")  || ($what=="item")) {

        //use this filter to accelerate the search
        // $f_stub ="  `$dbThisTable`.`userid` = `$dbUsersTable`.`id` ";   
        // $filter .=($filter=="") ? " WHERE $f_stub " : " AND $f_stub ";

        if ($action=="autosearch") {
          // do a simple query 
          $query = "SELECT `$dbThisTable`.`title`,   
                        `$dbUsersTable`.`protype` as protype 
                  FROM `$dbThisTable` 
                  LEFT OUTER JOIN `$dbUsersTable` ON `$dbUsersTable`.`id`= `$dbThisTable`.`userid`   
                  LEFT OUTER JOIN `$dbCatsTable` ON `$dbCatsTable`.`id`= `$dbThisTable`.`catid`   
                  " .$filter . " ". $sql_sort2." ".$limit;
          } else {   

            if ( $type=="zetvu") $extraSQLField .= " ,`$dbUsersTable`.`username` as username" ;  
            $query = "SELECT `$dbThisTable`.*  
                        $extraSQLField , 
                        `$dbUsersTable`.`protype` as protype 
                  FROM `$dbThisTable` 
                  LEFT OUTER JOIN `$dbUsersTable` ON `$dbUsersTable`.`id`= `$dbThisTable`.`userid`   
                  LEFT OUTER JOIN `$dbCatsTable` ON `$dbCatsTable`.`id`= `$dbThisTable`.`catid`   
                  " .$filter . " ". $sql_sort2." ".$limit;
          }
        }

      }
     
     // ---- START the real Queries  ----- 
     
     // -----check for commercial limits
     $sales_ok=true; 
     $sales_ok = check_salesLimits($what,$action);
     
     // -----do the pre-queries if exists ---
     if ($make_pre_query && $sales_ok) {

      $pre_result = mysql_query($pre_query);
      $deltatime= (microtime(true)-$t0); 
      $timing_trace.= "|PREQUERY_in ".sprintf("%01.3f", $deltatime). " sec \n "; 
      $t0=microtime(true); 

      if (($action == "create")  && ($what=="user") && $pre_result && (mysql_num_rows($pre_result)!=0)){
        $pre_row = mysql_fetch_object($pre_result); 
        if ($pre_row->email==$email) $sqlerror =  "|ERR-UC-EMAIL| A user with this email already exist.";
        if ($pre_row->username==$username) $sqlerror =  "|ERR-UC-USERNAME| This username is not available.";
        $success=false;
        }

      // check if User is in the banned list of not.
      if (($action == "create")  && ($what=="user") && file_get_contents('vars/ban_emails.txt')){
        $ban_email_list = file_get_contents('vars/ban_emails.txt');
        $domain = substr(strrchr($email, "@"), 1);
        if ((strpos($ban_email_list,$email)!== false) || (strpos($ban_email_list,"*@".$domain)!== false)){
            $success=false;
            $sqlerror =  "|ERR-UC-EMAIL| This email is banned !";
         } // else OK ! 
      } // else NO CONTORL TO BE DONE 
        
     } // end PREQUERY 

     if ($success) {
        // ######  Do the FINAL Query if NOT DELETE action (done before !) #######
        if ($action != "delete") $result = mysql_query($query);  
        else $result=true; 

        $deltatime= (microtime(true)-$t0); 
        $timing_trace.= "|FINALQUERY_in ".sprintf("%01.3f", $deltatime). " sec  "; 
        $t0=microtime(true); 


        $sqlerror=""; 
        if (!$result) $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
        else {
          $lastdbinsertid = mysql_insert_id(); 

          // check if NEWSLETTER subscription need to be cancelled of not 
          if ($action_newsletter=="subscribe" || $action_newsletter=="unsubscribe") {
            if ($action_newsletter=="subscribe") {
              // default variables 
               $s_status="40"; // by default the account is AUTO VALIDATED 
               $s_subfeeds='zads';$hashid = $email.strval(time());$hashid = hash('sha1',$hashid);
               $s_query = "INSERT INTO `".$dbSubscribersTable."` 
                    (`hashid`, `activation`,`os`, `browser`, `version`,  `subfeeds`, `username`, `auth`, `gender`, `password`,  `usertype`, `firstname`, `lastname`,  `email`, `phone`, `registerdate`, `lastemaildate`, `moddate`, `lastvisitdate`, `status`, `avatarimg`, `locale`,`location`, `priority`)"; 
               $s_query .= "VALUES 
                    ('$hashid', '0', '','','','$subfeeds', '', '', '', '', '', '', '','$email', '', '$stamp','$stamp','$stamp','$stamp','$s_status','',  '', '','');";
                $s_result = @mysql_query($s_query);
                if (!$s_result) 
                  logfile('error', 'newsletter auto subscribe - SQL error = '. mysql_error()); 
                
              }

            if ($action_newsletter=="unsubscribe") {
              // default variables 
              $s_query = "DELETE FROM `".$dbSubscribersTable."` WHERE ((`email` = '".$email."')) ";
              $s_result = mysql_query($s_query);  
              if (!$s_result) logfile('error', 'newsletter auto delete - SQL error = '. mysql_error()); 
            }
          } // end auto newsletter subscription 


          // update the Session and Cookies if query is on current user
          if (($action == "update") && ($what == "curuser"))  {
            // check session  : 
            if (session_id()=="") session_start();  // start the session if not set 
            if (isset($_SESSION['user'])){
              $_SESSION['user']= $username; 
              if ( isset($_POST["password"])) $_SESSION['user_passwd'] = $password;  
            }          
            // check cookies
            if (isset($_COOKIE[$COOKIENAME."_REMEMBER_ME" ]))
            {
              if ( isset($_POST["password"])) $loginpassword2 = $password; 
              else {
                $cookierxtext = $_COOKIE[$COOKIENAME."_REMEMBER_ME"]; 
                $cookierxarray = explode("&", $cookierxtext);       
                $cookierxarraysub = explode("=", $cookierxarray[0]);
                $cookierxarraysub = explode("=", $cookierxarray[1]);
                $loginpassword2 = $cookierxarraysub[1]; 
              }
              $cookietxt = "login=".$username."&password=".$loginpassword2."&lastconnection=".$stamp;
              // add the cookie if requested
              setcookie($COOKIENAME."_REMEMBER_ME" ,$cookietxt , (time() + 3600*24*5),'/');

            }
          } //end UPDATE VUR USER
       
          if (($action == "create")||($action == "update") ||($action == "updatestatus"))  {


            if ($action == "create") $lastdbinsertid = $lastdbinsertid; else $lastdbinsertid = $ad_id; 

            $query2 = "SELECT * FROM `$dbThisTable` WHERE `id`=$lastdbinsertid";    
            $result2 = mysql_query($query2);

            if (!$result2) $sqlerror =  "Could not successfully run query from DB: " . mysql_error()."--".$query2;
            else {
              $row = mysql_fetch_object($result2); 
              if (($what=="cats") || ($what=="cat")) {
                // retrieve the just created categorie               
                $item[0] = Array (
                          'title'=> stripslashes($row->title), 
                          'desc' => stripslashes($row->description),
                          'catid'=> $row->catid,
                          'type'=> $row->type, 
                          'priority'=> $row->priority,

                          'price'=> $row->price,
                          'id'=> $row->id,
                          'status'=> $row->status,
                          'logs'=> $row->logs,
                          'hits'=> $row->hits,
                          'likes'=> $row->likes,
                          'userid'=> $row->userid,
                          'username'=> stripslashes($row->username),
                          'phone'=> $row->phone,
                          'email'=> stripslashes($row->email),
                          'location'=> stripslashes($row->location),
                          'moddate'=> $row->moddate,
                          'moddatestamp'=>  strtotime( $row->moddate)*1000, 
                          'imgpath'=> $dest_path_from_root,
                          'imgurl'=> $row->imgname,

                          'parentid'=> $row->pid,
                          'order'=> $row->order,
                          'icongpath'=> $dest_path_from_root,
                          'iconurl'=> $row->iconname,

                          //@z5.1
                          'badwords_res'=>$badwords_res,
                          //@Z5.5
                          'catlvfields'=>$row->catlvfields,
                          //@Z6.1  
                          'adultflag'=>$row->adultflag,
                          'adulttext'=>$row->adulttext,
                          'acl'=>$row->acl,

                          //Z6.4.0
                          'hascalendar'=>$row->hascalendar,
                          'calendartype'=>$row->calendartype,

                          // zads 6.5.7 addition 
                          'pricetype'=> $row->pricetype,

                          // zads 6.7 addition 
                          'metadesc'=> $row->metadesc,
                          'metatitle'=> $row->metatitle,
                          'metakey'=> $row->metakey,

                          //zads7.0.0 
                          'protype'=> $row->protype,


                          'e'=>"y" // dummy end 
                                                
                          );

              // update the list of categories 
              $itemcatlist = sql_get_cat_list('cat', '', '', $dbCatsTable, 'ext2');
  
              }
                          
             if (($what=="item") || ($what=="ad")){

               // apply rge badwords filter  
               $inAr = array(stripslashes($row->title),  stripslashes($row->description)) ; 
               $badwords_res = check_for_badwords($inAr);  

                $item[0] = Array (
                          'title'=> stripslashes($row->title), 
                          'desc' => stripslashes($row->description),
                          'catid'=> $row->catid,
                          'type'=> $row->type, 
                          'priority'=> $row->priority,

                           // zads 4.6 addition 
                          'loclat'=> $row->loclat,
                          'loclng'=> $row->loclng,

                          // zads 4.5 addition 
                          'paidoptions'=> $row->paidoptions,

                          'price'=> $row->price,
                          'pricetype'=> $row->pricetype,

                          'price2'=> $row->price2,
                          'pricetype2'=> $row->pricetype2,
                          
                          'id'=> $row->id,
                          'status'=> $row->status,
                          'logs'=> $row->logs,
                          'hits'=> $row->hits,
                          'likes'=> $row->likes,
                          'userid'=> $row->userid,
                          'username'=> stripslashes($row->username),
                          'phone'=> $row->phone,
                          'email'=> stripslashes($row->email),
                          'location'=> stripslashes($row->location),
                          'moddate'=> $row->moddate,
                          'moddatestamp'=>  strtotime( $row->moddate)*1000, 
                          'imgpath'=> $dest_path_from_root,
                          'imgurl'=> $row->imgname,

                          
                          // ZADS4.1 addition
                          'videoembed'=> $row->videoembed,

                          // ZADS4.1 addition
                          'video2'=> $row->video2,

                          //@Z6.5.0 addition
                          'audiourl'=> $row->audiourl,
                          'videourl'=> $row->videourl,
                          'docurl'=> $row->docurl,
                          
                           // ZADS4.0 addition                          
                          'loclatlng'=> $row->loclatlng,
                          'loczipcode'=> $row->loczipcode,        
                          'loccity'=> stripslashes($row->loccity),
                          'locdept'=> stripslashes($row->locdept),
                          'locregion' => stripslashes($row->locregion),
                          'loccountrycode'=> $row->loccountrycode,
                          'lochash'=> stripslashes($row->lochash),
                          'lochashregion' => $row->lochashregion,

                          //@z5.1
                          'badwords_res'=>$badwords_res,

                          //@z5.5
                          'vfields'=> stripslashes($row->vfields),

                          //@z5.6
                          'createdate'=> $row->createdate,
                          'createdatestamp'=>  strtotime( $row->createdate)*1000, 
                          'firstpublisheddate'=> $row->firstpublisheddate,
                          'firstpublisheddatestamp'=>  strtotime( $row->firstpublisheddate)*1000, 
                          'crondate'=> $row->crondate,
                          'crondatestamp'=>  strtotime( $row->crondate)*1000, 
                          'urgent'=> $row->urgent,

                          //@z6.1
                          'links'=> $row->links,

                         

                          //zads6.1.1 - vtags
                          'vtag1'=> $row->vtag1,
                          'vtag2'=> $row->vtag2,
                          'vtag3'=> $row->vtag3,
                          'vtag4'=> $row->vtag4,
                          'vtag5'=> $row->vtag5,

                          

                          'd'=>'' 

                          );


                // Z 7.5.1
                if ($AD_EXPIRATION_FOR !='none'){
                  if ($row->expiredate !='0000-00-00 00:00:00'){
                   $item[0]['expiredate'] = reformatDate($row->expiredate, 'Y-m-d','d/m/Y');
                  $item[0]['expiredatestamp'] =strtotime( $row->expiredate)*1000;
                  } else $item[0]['expiredate'] =''; 
                }

                if ($row->paidoptions !="")
                  $item[0] = parseStrToArr($row->paidoptions,'forcedvar', $item[0]); 



                // add msg the message section
                  $item[0]['msg'] = $msg; 

                  //Z6.8  : add the counters only if admin or owner 
                  if ( $curuser_is_admin || $curuser_is_owner) {
                     $item[0]['vcounters'] = stripslashes($row->vcounters) ;
                  }
              }
                          
              if (($what=="user") || ($what=="users")|| ($what=="curuser") ){

                    // apply rge badwords filter  
                    $inAr = array(stripslashes(stripslashes($row->bio)),  stripslashes(stripslashes($row->longdesc))) ; 
                    $badwords_res = check_for_badwords($inAr);  

                    //Z6.4.0 
                    // special case for path
                    if ($row->imgpath !='') $timgurl = $row->imgpath; else $timgurl = $dest_path_from_root;

                      $item[0] = Array (
                          'id'=> $row->id, 
                          'firstname' => stripslashes($row->firstname),
                          'lastname'=> stripslashes($row->lastname),
                          'username'=> stripslashes($row->username),
                          'accronym'=> $row->accronym,
                          'email'=> stripslashes($row->email),
                          'phone'=> $row->phone,
                          'location'=> stripslashes($row->location),
                          'usertype'=> $row->usertype,
                          'userid'=> $row->userid,
                          'status'=> $row->status,
                          'sendEmail'=> $row->sendEmail,
                          'gid'=> $row->gid,
                          'registerdate'=> $row->registerdate,
                          'lastvisitdate'=> $row->lastvisitdate,
                          'lastemaildate'=> $row->lastemaildate,
                          'registerdatestamp'=>  strtotime( $row->registerdate)*1000,
                          'lastvisitdatestamp'=>  strtotime( $row->lastvisitdate)*1000,
                          'lastemaildatestamp'=>  strtotime( $row->lastemaildate)*1000,
                          'activation'=> $row->activation,
                          'preferences'=>  $row->preferences,
                          'favads'=> $row->favads,
                          'imgpath'=> $timgurl,
                          'imgurl'=> $row->imgurl,
                          'assocprojects'=> $row->assocprojects,
                          'gender' => $row->gender,
                          'auth'=> $row->auth,
                          'locale'=> stripslashes($row->locale),

                          //@Z6.5.0 addition
                          'audiourl'=> $row->audiourl,
                          'videourl'=> $row->videourl,
                                                    
                          // ZADS4.0 addition 
                          'avatarimg'=> $row->avatarimg,
                          'probannerimg'=> $row->probannerimg,
                          'probannerurl'=> $row->probannerurl,

                          'folioimg'=> $row->folioimg,
                          'skills'=> $row->skills,
                          'priority'=> $row->priority,
                          'expiredate'=> $row->expiredate,
                          'protype'=> $row->protype,
                          'procpny'=> stripslashes($row->procpny),      
                          'prosiret'=> $row->prosiret,
                          'prowebsite'=> stripslashes($row->prowebsite),
                          'social'=> $row->social,
                          'loclatlng'=> $row->loclatlng,
                          'loczipcode'=> $row->loczipcode,        
                          'loccity'=> stripslashes($row->loccity),
                          'locdept'=> stripslashes($row->locdept),
                          'locregion' => stripslashes($row->locregion),
                          'loccountrycode'=> $row->loccountrycode,
                          'lochash'=> stripslashes($row->lochash),
                          'lochashregion' => $row->lochashregion,
                          'bio' => stripslashes($row->bio),

                          // zads 4.7 addition 
                          'paidoptions'=> $row->paidoptions,

                           // zads 4.9 addition 
                          'videoembed'=> $row->videoembed,
                          'plan'=> stripslashes($row->plan),
                          'longdesc'=> stripslashes($row->longdesc),

                          // zads 4.9.1 addition 
                          'hits'=> $row->hits,
                          'likes'=> $row->likes,

                            // ZADS5.0 addition 
                          'desc2'=> stripslashes($row->desc2),
                          'desc3'=> stripslashes($row->desc3),
                          'links'=> $row->links,
                          'email2'=> stripslashes($row->email2),
                          'phone2'=> $row->phone2,
                          'address2'=> stripslashes($row->address2),
                          'cat2'=> $row->cat2,
                          'cat3'=> $row->cat3,
                          'date2'=> $row->date2,


                          'moddate' => $row->moddate,
                          'moddatestamp'=>  strtotime( $row->moddate)*1000,

                          //@z5.5
                          'vfields'=> stripslashes($row->vfields),

                          //@z5.1
                          'badwords_res'=>$badwords_res, 

                           //@z6.0
                          'indir'=>$row->indir,
                          'banclicks'=>$row->banclicks,

                          //@Z6.1
                          'newsletter'=>$row->newsletter,

                          //@Z7.1.0
                          'verify'=>$row->verify, 

                          // 7.5 
                          'createdby' => $row->createdby
                       
                          );

                      //6.8 Admin mode, display IP address 
                      if ($curuser_is_admin){
                        $item[0]['ip'] = $row->ip; 
                      }

                      if ($curuser_is_admin || ($what=="curuser")){
                        $item[0]['dob'] = reformatDate($row->dob, 'Y-m-d','d/m/Y' );  
                      }


                      //Z7.0.1 : hide user email 
                      // if ($USERDETAILS_CONTACT_THRU_SITE && !$curuser_is_admin) {
                      //   $item[0]['email']="**secured**";
                      //   $item[0]['email2']="**secured**";  
                      // }


              }


                          
              // end an email if necessary , get User email before
              if (($what=="user")|| ($what=="curuser")){
                $useremailx = $row->email;
              }
              
              else {
                  $filterx="WHERE `id`='".$row->userid."'"; 
                  $queryx = "SELECT * FROM `$dbUsersTable` " .$filterx; 
                  $resultx = mysql_query($queryx);
                  $rowx = mysql_fetch_object($resultx);
                  $useremailx = $rowx->email; 
                  
                  // complement item0 with elements 
                  $item[0]['realfirstname'] = stripslashes($rowx->firstname);
                  $item[0]['firstname'] = stripslashes($rowx->firstname);  
                  $item[0]['reallastname'] = stripslashes($rowx->lastname);
                  $item[0]['lastname'] = $rowx->lastname;  
                  $item[0]['realemail'] = stripslashes($rowx->email);
                  $item[0]['uemail'] = stripslashes($rowx->email);  
                  $item[0]['realuserid'] = $rowx->id; 
                  
                  // add msg for special approvals 
                  $item[0]['msg'] = $msg; 
                  
              }
              // ----------------- SEND EMAIL TRACKER ----------------------------
             
              /*
              if ($what=="item") $whatx="ad"; else  $whatx=$what; 
              mySendEmail($emailRoutingTable, $whatx,  $row->status, $item[0], $useremailx);
              */

              if ($what=="item") $whatx="ad"; else  $whatx=$what; 
              $emaildata= array();
              $emaildata= $item[0]; // allocate the content
              // add password /* new ZADS@4.5 , send password */   
              if ($what=="user"){
                $emaildata['password'] =  $thisdeclaredpassword;

                // resend datas as they could be hidden by previous process
                $emaildata['email'] = stripslashes($row->email);
                $emaildata['email2'] = stripslashes($row->email2);
                $emaildata['ip'] = $row->ip; 

                // new ZADS7.2.0 
                if ($EN_GET_IP_DETAILS && in_array($row->status, ['20','15','40']))
                {
                  logtime('get ip details START');
                  //$theip='82.244.195.171' ; // for debug
                  $theip = $emaildata['ip']; 
                  $r=get_IP_details($theip); 
                  $emaildata['ipdetails']=$r["serialized"]; // get a textual value 
                  logtime('get ip details END');
                  logfile('debug', 'get ip = '.$emaildata['ipdetails']);
                } 

              }
              mySendEmail($emailRoutingTable, $whatx,  $row->status, $emaildata, $useremailx);
              
            }
          } // end CREATE / UPDATE / UPDATESTATUS action 
          
          // ----------------- SAVE TO LOG FILE ----------------------------
          if ($ENABLE_ELEM_LOGS){
              if (($action != "list") && ($action != "updatehit") && ($action != "updatelikes") && ($action != "autosearch")) { // log all actions except when a List is requested
                
                if ($action=="delete") $theid= $ad_id; 
                else if ($action=="resethits" || $action=="resetlikes") $theid=$adid;
                else $theid=$row->id;
                
                if ($what=="curuser") $thewhat = "user"; else $thewhat=$what; 
                if ($what=="item") $thewhat = "ad"; 
                
                // case of delete, add the reason / cause
                if (($status=="80") && ($msg!="")) $status=$status.'|'.$msg;  
                
                log_event($action,$thewhat, $theid, $curuserid, $status, 0);
              }
          } // end IF ENABLE LOGS
          
          if (($action == "list")) {
            $idx=0;
            $outdata=""; 
            $nbresultsthisquery =mysql_num_rows($result); 

            while ($row = mysql_fetch_object($result)) {

              if (($what=="item") || ($what=="ad") || ($what=="cats") || ($what=="cat")) {
                // check if right to display it 
                if ((($row->status!="40") && ($row->status!="45")) && ($in_action=="display") && (!$curuser_is_admin) && ($curuser_id!=$row->userid))
                  $toto=1; // don't DISPLAY if user is not OWNER or ADMIN  ! 
                else  {
                  $badwords_res=array();//reset
                  // check only in status DRAFT or PENDING 
                  if   (($curuser_is_admin || $curuser_id==$row->userid) && ($row->status=="20" || $row->status=="10")){
                    $inAr = array(stripslashes($row->title),  stripslashes($row->description)) ; 
                    $badwords_res = check_for_badwords($inAr);  
                  }

                  $outdata = Array (
                    'title'=> stripslashes($row->title), 
                    //'desc' => nl2br(stripslashes($row->description)),
                    'desc' => stripslashes($row->description),
                    'catid' => $row->catid ,
                    'type'=> $row->type,
                    'priority'=> $row->priority, 
                    'price'=> $row->price,
                    'id'=> $row->id, 
                    'status'=> $row->status,
                    'logs'=> $row->logs,
                    'hits'=> $row->hits,
                    'likes'=> $row->likes,
                    'userid'=> $row->userid,
                    'username'=> stripslashes($row->username),
                    'phone'=> $row->phone,
                    'location'=> stripslashes($row->location),
                    'email'=> stripslashes($row->email),
                    'location'=> $row->location,
                    'moddate'=> $row->moddate,  
                    'moddatestamp'=>  strtotime( $row->moddate)*1000,
                    'imgpath'=> $dest_path_from_root, 
                    'imgurl'=> $row->imgname,
                    //@z5.1
                    'badwords_res'=>$badwords_res,
                    
                    );
                    
                    if ( ($what=="cats") || ($what=="cat")){
                      $outdata['totnbads'] =$row->totnbads; 

                      $outdata['parentid'] =$row->pid; 
                      $outdata['order'] =$row->order; 
                      $outdata['icongpath'] =$dest_path_from_root;
                      $outdata['iconurl'] =$row->iconname; 
                      //@Z5.5
                      $outdata['catlvfields'] =$row->catlvfields; 

                    //@Z6.1
                     $outdata['adultflag'] =$row->adultflag;
                     $outdata['adulttext'] =$row->adulttext;
                     $outdata['acl'] =$row->acl;

                     //Z6.4.0
                     $outdata['hascalendar'] =$row->hascalendar;
                     $outdata['calendartype'] =$row->calendartype;

                     //Z6.5.7 
                     $outdata['pricetype'] =$row->pricetype;

                     //Z6.7
                     $outdata['metatitle'] =$row->metatitle;
                     $outdata['metakey'] =$row->metakey;
                     $outdata['metadesc'] =$row->metadesc;

                     //zads7.0.0 
                     $outdata['protype'] =$row->protype;

                    }
                    
                          
                    if (($what=="item") || ($what=="ad")) {

                      // zads 4.9 additions 
                      $outdata['pricetype'] =$row->pricetype;
                       // zads 4.8 additions 
                      $outdata['protype'] =$row->protype;
                      // zads 6.0 additions 
                      $outdata['indir'] =$row->indir;
                      $outdata['banclicks']=$row->banclicks;
                      // zads 4.6 additions 
                      $outdata['locdist'] =$row->locdist;
                      // ZADS4.15addition
                      $outdata['paidoptions'] =$row->paidoptions;
                      if ($row->paidoptions !="")
                        $outdata = parseStrToArr($row->paidoptions,'forcedvar', $outdata); 
                      $outdata['payment'] =$row->payment;
                      // ZADS4.1 addition
                      $outdata['videoembed'] =$row->videoembed;
                       // ZADS4.0 addition
                      $outdata['loclatlng'] =$row->loclatlng;
                      $outdata['loczipcode'] = $row->loczipcode;        
                      $outdata['loccity'] =stripslashes($row->loccity);
                      $outdata['locdept'] =stripslashes($row->locdept);
                      $outdata['locregion'] =stripslashes($row->locregion);
                      $outdata['loccountrycode'] =$row->loccountrycode;
                      $outdata['lochash'] =stripslashes($row->lochash);
                      $outdata['lochashregion'] =$row->lochashregion;

                      //@z5.5
                      $outdata['vfields'] =stripslashes($row->vfields);

                      //@z5.6
                      $outdata['createdate']= $row->createdate;
                      $outdata['createdatestamp']=  strtotime( $row->createdate)*1000;
                      $outdata['firstpublisheddate']= $row->firstpublisheddate;
                      $outdata['firstpublisheddatestamp']=  strtotime( $row->firstpublisheddate)*1000;
                      $outdata['crondate']= $row->crondate;
                      $outdata['crondatestamp']=  strtotime( $row->crondate)*1000;
                      $outdata['urgent']= $row->urgent;

                      // ZADS5.6 addition
                      $outdata['video2'] =$row->video2;

                      //@Z6.5.0 addition
                      $outdata['audiourl'] = $row->audiourl;
                      $outdata['videourl'] = $row->videourl;
                      $outdata['docurl'] = $row->docurl;


                      // zads 6.7 additions 
                      $outdata['pricetype2'] =$row->pricetype2;
                      $outdata['price2'] =$row->price2;


                      //ZADS6.1 addition 
                      $outdata['links'] =$row->links;

                      //zads6.1.1 - vtags
                      $outdata['vtag1'] =$row->vtag1;
                      $outdata['vtag2'] =$row->vtag2;
                      $outdata['vtag3'] =$row->vtag3;
                      $outdata['vtag4'] =$row->vtag4;
                      $outdata['vtag5'] =$row->vtag5;

                      if ( $curuser_is_admin || $curuser_is_owner) {
                        $outdata['vcounters'] = stripslashes($row->vcounters);
                      }

                      //Z6.5.1 special patch for ACTION=DISPLAY
                      if ($curuser_id && $row->userid==$curuser_id) $cur_user_is_owner_this_elem=true; 
                      else $cur_user_is_owner_this_elem=false; 

                      //Z6.5.0 -- hide secured email and phone and replace them with special images 
                      if ($EMAIL_AS_IMAGE_EN && !$curuser_is_admin && !$curuser_is_owner && !$cur_user_is_owner_this_elem) {
                        if ( $outdata['email'])  $outdata['email'] = '**secured**'; 
                      }
                      if ($PHONE_AS_IMAGE_EN && !$curuser_is_admin && !$curuser_is_owner && !$cur_user_is_owner_this_elem) {
                       if ($outdata['phone'] ) $outdata['phone'] = '**secured**'; 
                      }

                      // Z 7.5.1 - expiration date
                      if ($AD_EXPIRATION_FOR !='none'){
                        if ($row->expiredate !='0000-00-00 00:00:00'){
                         $outdata['expiredate'] = reformatDate($row->expiredate, 'Y-m-d','d/m/Y');
                         $outdata['expiredatestamp'] =strtotime( $row->expiredate)*1000;
                        } else $outdata['expiredate'] =''; 
                      }
                     
                    }                    
                  }
                } // end AD

                if (($what=="user") || ($what=="users")|| ($what=="curuser") ) {
                 // check is the right to get he info 
                                    
                  // if ( $id && !($id==$curuserid) && (($row->protype=="pri") || ($row->protype=="")) && !$curuser_is_admin){
                  // prevent access to people who are not into directory list (indir=yes)
                  if ( $id && !($id==$curuserid) && (($row->indir=="")) && !$curuser_is_admin){
                  //if (!$id || ($what=="curuser" && $id!=$curuserid) || ($row->indir!="")|| !$curuser_is_admin){
                    $success=false; 
                    $message="not authorized"; 
                    $sqlerror="no authorized - private profile";
                    // $sqlerror=" debug = $id | $what | $curuserid | $row->indir | $curuser_is_admin"; 
                    logfile('error', "MAIN 1 | $action | $what | $message $sqlerror ", __LINE__);
                  } else 
                  {  

                    // apply rge badwords filter  
                    $inAr = array(stripslashes(stripslashes($row->bio)),  stripslashes(stripslashes($row->longdesc))) ; 
                    $badwords_res = check_for_badwords($inAr);  
                    $badwords_res=''; 

                    //Z6.4.0 
                    // special case for path
                    if ($row->imgpath !='') $timgurl = $row->imgpath; else $timgurl = $dest_path_from_root;

                    $outdata = Array (
                      'id'=> $row->id,
                      'userid'=> $row->userid, 
                      'firstname' => stripslashes($row->firstname),
                      'lastname'=> stripslashes($row->lastname),
                      'username'=> stripslashes($row->username), 
                      'accronym'=> $row->accronym,
                      'email'=> stripslashes($row->email),
                      'phone'=> $row->phone,
                      'location'=> stripslashes($row->location),
                      'usertype'=> $row->usertype,
                      'status'=> $row->status,
                      'sendEmail'=> $row->sendEmail,
                      'gid'=> $row->gid,
                      'registerdate'=> $row->registerdate,
                      'lastvisitdate'=> $row->lastvisitdate,
                      'lastemaildate'=> $row->lastemaildate,
                      'registerdatestamp'=>  strtotime( $row->registerdate)*1000,
                      'lastvisitdatestamp'=>  strtotime( $row->lastvisitdate)*1000,
                      'lastemaildatestamp'=>  strtotime( $row->lastemaildate)*1000,
                      'activation'=> $row->activation,
                      'preferences'=>  $row->preferences,
                      'favads'=> $row->favads,
                      'imgpath'=> $timgurl,
                      'imgurl'=> $row->imgurl,
                      'assocprojects'=> $row->assocprojects,
                      'gender' => $row->gender,
                      'auth'=> $row->auth,
                      'locale'=> stripslashes($row->locale), 
                      'totnbads'=>$row->totnbads,
                      
                      // ZADS4.0 addition 
                      'avatarimg'=> $row->avatarimg,
                      'probannerimg'=> $row->probannerimg,
                      'probannerurl'=> $row->probannerurl,
                      'folioimg'=> $row->folioimg,
                      'skills'=> $row->skills,
                      'priority'=> $row->priority,
                      'expiredate'=> $row->expiredate,
                      'protype'=> $row->protype, 
                      'procpny'=> stripslashes($row->procpny),       
                      'prosiret'=> $row->prosiret,
                      'prowebsite'=> stripslashes($row->prowebsite),
                      'social'=> $row->social,
                      'loclatlng'=> $row->loclatlng,
                      'loczipcode'=> $row->loczipcode,        
                      'loccity'=> stripslashes($row->loccity),
                      'locdept'=> stripslashes($row->locdept),
                      'locregion' => stripslashes($row->locregion),
                      'loccountrycode'=> $row->loccountrycode,
                      'lochash'=> stripslashes($row->lochash),
                      'lochashregion' => $row->lochashregion,
                      'bio' => stripslashes($row->bio),

                      // zads 4.9 addition 
                      'videoembed'=> $row->videoembed,
                      'plan'=> stripslashes($row->plan),
                      'longdesc'=> stripslashes($row->longdesc),

                      //@Z6.5.0 addition
                      'audiourl'=> $row->audiourl,
                      'videourl'=> $row->videourl,

                      // zads 4.9.1 addition 
                      'hits'=> $row->hits,
                      'likes'=> $row->likes,

                      //@z5.1
                      'badwords_res'=>$badwords_res,

                      //@Z6.0
                      'indir'=>$row->indir,
                      'banclicks'=>$row->banclicks,

                      //@Z6.1
                      'newsletter'=>$row->newsletter,

                      //@Z7.1.0
                      'verify'=>$row->verify,

            
                       // ZADS5.0 addition 
                      'desc2'=> stripslashes($row->desc2),
                      'desc3'=> stripslashes($row->desc3),
                      'links'=> $row->links,
                      'email2'=> stripslashes($row->email2),
                      'phone2'=> $row->phone2,
                      'address2'=> stripslashes($row->address2),
                      'cat2'=> $row->cat2,
                      'cat3'=> $row->cat3,
                      'date2'=> $row->date2,

                      'ip' => '',
                      'ua'=> '',

                      'moddate' => $row->moddate,
                      'moddatestamp'=>  strtotime( $row->moddate)*1000

                  
                      );

                      // ZADS 4.6 addition
                      $outdata['paidoptions'] =$row->paidoptions;
                      if ($row->paidoptions !="")
                        $outdata = parseStrToArr($row->paidoptions,'forcedvar', $outdata); 
                      $outdata['payment'] =$row->payment;

                      //@z5.5
                      $outdata['vfields'] =stripslashes($row->vfields);

                      // 6.8 Admin mode, display IP address 
                      if ($curuser_is_admin){
                         $outdata['ip'] = $row->ip; 
                      }

                      if ($curuser_is_admin || ($what=="curuser")){
                        $outdata['dob'] = reformatDate($row->dob, 'Y-m-d','d/m/Y' );  
                      }

                      //Z7.0.1 : hide user email 
                      if ($USERDETAILS_CONTACT_THRU_SITE && !$curuser_is_admin) {
                        $outdata['email']="**secured**";
                        $outdata['email2']="**secured**";  
                      }

                      // 7.5 
                      $outdata['createdby'] =$row->createdby;



                  } // END ELSE
                } // END IF USER
                     
                  // check and clean the output in case of PRICING PLAN ! 
                  if ($isUser && !$curuser_is_admin){
                    $outdata = check_and_clean_data_per_pricingplan($outdata, $what); 
                  }

                  // final allocation and move 
                  $item[$idx] = $outdata;
                  $idx+=1; 
                   
                } // END WHILE LOOP
                $deltatime= (microtime(true)-$t0); 
                $timing_trace.= "|ENDOFWHILELOOP_in ".sprintf("%01.3f", $deltatime). " sec "; 
                $t0=microtime(true); 
                
                // update the hit counter if ACTION =  DISPLAY a given element
                if (($in_action == "display")) {
                  if ($nbresultsthisquery>0){
                    $queryhit = "UPDATE `".$dbThisTable."` SET `hits` = `hits`+1 WHERE ((`id` = '".$id."')) ";
                    $resulthit = mysql_query($queryhit); 
                  } else {
                    $success=false; $success=true; 
                    $message="not authorized"; 
                    $sqlerror="no authorized - private profile";
                    logfile('error', "MAIN 2 | $action | $what | $message $sqlerror ", __LINE__);
                  }
                }
  
          } // end LIST actions 

          if (($action == "autosearch")) {
            $idx=0;
            $outdata=""; 
            $trace="intoit"; 
            $nbresultsthisquery =mysql_num_rows($result);   
            while ($row = mysql_fetch_object($result)) {

              if (($what=="item") || ($what=="ad") || ($what=="cats") || ($what=="cat")) {
                // check if right to display it 
                if ((($row->status!="40") && ($row->status!="45")) && ($in_action=="display") && (!$curuser_is_admin) && ($curuser_id!=$row->userid))
                  $toto=1; // don't DISPLAY something if user is not OWNER or ADMIN  ! 
                else  {

                  // apply rge badwords filter  
                  $inAr = array(stripslashes($row->title),  stripslashes($row->description)) ; 
                  $badwords_res = check_for_badwords($inAr);  

                 $outdata = Array (
                    'title'=> stripslashes($row->title)
                    );                    
                  }
                } // end AD

                if (($what=="user") || ($what=="users")|| ($what=="curuser") ) {
                 // check is the right to get he info 
                 
                  if ( $id && !($id==$curuserid) && (($row->protype=="pri") || ($row->protype=="")) && !$curuser_is_admin){
                    $success=false; 
                    $message="not authorized"; 
                    $sqlerror="no authorized - private profile";
                    logfile('notice', "MAIN | $action | $what | $message $sqlerror ",__LINE__);
                   
                  } else 
                  {  

                    // apply rge badwords filter  
                    $inAr = array(stripslashes(stripslashes($row->bio)),  stripslashes(stripslashes($row->longdesc))) ; 
                    $badwords_res = check_for_badwords($inAr);  

                    $outdata = Array (                     
                      'firstname' => stripslashes($row->firstname),
                      'lastname'=> stripslashes($row->lastname),
                      'protype'=> $row->protype, 
                      'procpny'=> stripslashes($row->procpny)       
                      );
                  } // END ELSE
                } // END IF USER
                    
                  // final allocation and move 
                  $item[$idx] = $outdata;
                  $idx+=1; 
                } // END WHILE LOOP
          } // end AUTOSEARCH 

          // -----   post query after delete is done 
          if (($action == "delete") || ($action == "update") || ($action == "updatestatus") || ($action == "create")|| ($action == "updatefav")) {
            $item2=array();  
            $query_giad="";      
            // get more info on user items
            $query_gi = "SELECT COUNT(`id`) as `nbads`, `status` FROM $dbItemsTable WHERE (`userid` = '".$curuser_id."') GROUP BY `status`";
            $result_gi = @mysql_query($query_gi);
            
            if (mysql_num_rows($result_gi)){
              while ($row_gi = mysql_fetch_array($result_gi)) { 
                  $item2[]  = array("name" =>$row_gi["status"], "val"  => $row_gi["nbads"]); 
                }
            } 
             // get more info on user items if user is admin. 
            if ($curuser_is_admin){
              $query_giad = "SELECT COUNT(`id`) as `nbads`, `status` FROM $dbItemsTable  GROUP BY `status`";
              $result_giad = @mysql_query($query_giad);
              //if ($debug_tmp==1){ fwrite($debugfile,$query_giad);  fwrite($debugfile,"\n");}
              if (mysql_num_rows($result_giad)){
                while ($row_gi = mysql_fetch_array($result_giad)) { 
                    $item2[]  = array("name" =>"admin_".$row_gi["status"], "val"  => $row_gi["nbads"]); 
                  }
              } 
            }
          }
       }
     }


     // manage the errors and messages
     if (!$sqlerror) {
        // get message template from table for special cases
        if ($returned_msg[$what][$status])
          $message = $returned_msg[$what][$status];           
        else 
          $message = "Yay! Everything went well!";

      }
     else $message = "Doh! Something happened : ".$sqlerror;
     if ($sqlerror=="") $success=true;
     
     
     if ($adid) $rxadid=$adid;
     else if ($ad_id) $rxadid=$adid;
     else if ($id) $rxadid=$adid;
     

     // extra datas for refreshing cur_user datas ! 
     $re_myservices = false;
     if ($refresh_myservices && $curuserid && $SERVICES_MULTI_EN){
      $re_myservices = db_list_services($curuserid);
     }
     $trace.="refresh=$refresh_myservices __ curuse=$curuserid ";



     if ($action == "autosearch"){
        // prepare the output code - SIMPLEERSION             
        $json = array(
                  'q'=>stripslashes($search),
                  'nb'=>$nbresultsthisquery,
                  'data' => array($item) 
              );
     } else {
     // prepare the output code             
     $json = array(
                  'success' => $success,
                  'statuscode'=>$status_code, 
                  'message' => $message,
                  'userid' => $userid,
                  're_myservices'=>$re_myservices,
                  're_totnbads'=>$re_totnbads,
                  'what' => $what,
                  'search'=>stripslashes($search),
                  'action' => $action,
                  'paged' => $paged,
                  'eppage'=>$eppage,
                  'totnb'=>$totnbrofresults,
                  'totnb_xt' =>$resultfullrow,
                  'thisnb'=>$nbresultsthisquery,
                  'sort'=>$sortoriginal,
                  'f_vfields'=>$f_vfields,
                  'sortdist'=>$sortdistoriginal,
                  'view'=>$vieworiginal,
                  'catid'=>$catidoriginal,
                  'type'=>$typeoriginal,
                  'utype'=>$utype,
                  'ftype'=>$ftype,
                  'locfield'=>$locfield,
                  'locval'=>stripslashes($locval),
                  'nav'=>$nav,
                  'status'=>$instatus,
                  'prevstatus'=>($curstatus) ? $curstatus : (($prevstatus ) ? $prevstatus : ''),
                  'adid'=>$rxadid,
                  'item0' => array($item), 
                  'itemcat' => array($itemcat),
                  'itemloclist'=>array($itemloclist),
                  
                  'relads' => $item2
              );
      }

      // add the catlist in case of create or update of a category list 
      if (($what=="cat") && (($action == "create") ||($action == "update") ||($action == "updatestatus")))  {
          $json['catlist'] = $itemcatlist;
      }

              
     // return the DOM ID location to sisplay the elements          
     if (($nav=="sidebar") || ($nav=="topbanner"))  $json["modid"] = $modid;
    
     // Z6.1.2 
     if ($ENABLE_TRACE_LOG){
        $json["time_log"] =$timing_trace;
     }


     if ($debug_tmp==1){ // add debug info into the stream when working local
       $json["xdebug"]= array(
                  'queryfull'=> $queryfull,
                  'query'=> $query,
                  'nbresults'=>$nblistresults,
                  'querycatfull'=> $querycatfull, 
                  'sqlper-query' => $pre_query,
                  'queryhit'=>$queryhit,
                  'loc' =>array($curuser_loclatlng, $locfield, $locval),
                  'sqldebugaduser'=>$query_gi,
                  'sqldebugaduser'=>$query_giad,
                  'imgarray-in'=>$imgnameArray,
                  'imgarray-in2'=>$avatarimgnameArray,
                  'imgarray-in3'=>$probannerimgArray,
                  'imgarray-in4'=>$folioimgArray,
                  'isadminuser'=>$curuser_is_admin,
                  'isowner'=>$curuser_is_owner, 
                  'issuperadmin'=>$curuser_is_superadmin,
                  'qgiad'=>$query_giad,
                  'immsg'=>$messagef,
                  'limitfilter'=>$limit,
                  'trace'=>$trace,
                  'sqlerror'=>$sqlerror,
                  'statusfilter'=>$statusfilter,
                  'filter3'=>$filter3,
                  'f_protype_stub'=>$f_protype_stub
                );  
     }

    // ob_start('ob_gzhandler');        
    // echo json_encode($json); 
    encode_json_and_send_with_compression($json); 
}  
// ---------- end ACTIONS -------------------------------------------------/

if(isset($_REQUEST["rating"])) {
	$rating = $_REQUEST["rating"];
	$storedRatings = unserialize(file_get_contents(STORE));
	$storedRatings[] = $rating;
	put_contents(STORE, serialize($storedRatings));
	$average = round(array_sum($storedRatings) / count($storedRatings), 2);
	$count = count($storedRatings);
	$xml = "<ratings><average>$average</average><count>$count</count></ratings>";
	header('Content-type: text/xml'); 
	echo $xml;
}

define('STORE', 'ratings.dat');
function put_contents($file,$content) {
	$f = fopen($file,"w");
	fwrite($f,$content);
	fclose($f);
}



/**-----------------------------------------------------------------------------
* This function encode and sens a json object with compression or not depending on settings 
*-----------------------------------------------------------------------------*/
function encode_json_and_send_with_compression($json){
  global $EN_GZIP ; 
  
  if ($EN_GZIP) {
    ob_start('ob_gzhandler');
  }
  echo json_encode($json); 
  return true ; 
}

/**-----------------------------------------------------------------------------
* This function delete an item with all coresponding links d 
* 
*-----------------------------------------------------------------------------*/
function sql_delete_item($thewhat,$theid){
  global $dbItemsTable;  
  global $dbCatsTable; 
  global $dbUsersTable; 
  global $dbStatsTable; 
  global $dbLogsTable; 
  
  global $debug_tmp; 
  global $debugfile;
  
  global $ENABLE_ELEM_LOGS ; 
  global $ENABLE_USER_LOGS ; 
  
  $thistable=""; 
  if ($thewhat=="user") $thistable=$dbUsersTable; 
  if ($thewhat=="ad") $thistable=$dbItemsTable; 
  if ($thewhat=="cat") $thistable=$dbCatsTable; 
  

  if ($thistable){
    // make the delete action  of the item
    $query = "DELETE FROM `".$thistable."` 
      WHERE ((`id` = '".$theid."')) ";
    $result = @mysql_query($query);
    
    // delete all logs if exists
    if ($ENABLE_ELEM_LOGS || $ENABLE_ELEM_LOGS){
      $querylog = "DELETE FROM `".$dbLogsTable."` 
      WHERE (`whatid` = '".$theid."') AND (`what` = '".$thewhat."')  ";
      $resultlog = @mysql_query($querylog);
    }    
  }
  return $result; 
}



// ----------------------------------------------------------------------------
// deleteFilesInDir
// this function delete files from a directory ($dossier_traite) with a given extension ($extension_choisie) et supérieur à un age requis 
// ----------------------------------------------------------------------------
function deleteFilesInDir($dossier_traite , $extension_choisie, $age_requis)
{
  //on ouvre le dossier
  $repertoire = opendir($dossier_traite);
  
  //on lance notre boucle qui lira les fichiers un par un
  while(false !== ($fichier = readdir($repertoire)))
  {


  //on met le chemin du fichier dans une variable simple
  $chemin = $dossier_traite."/".$fichier;
          
  //les variables qui contiennent toutes les infos nécessaires
  $infos = pathinfo($chemin);
  $extension = $infos['extension'];

  $age_fichier = time() - filemtime($chemin);
          
  //on n'oublie pas LA condition sous peine d'avoir quelques surprises :p
          //if($fichier!="." AND $fichier!=".." AND !is_dir($fichier) AND $extension == $extension_choisie AND $age_fichier > $age_requis)
          if($fichier!="." AND $fichier!=".." AND $fichier!="index.html" AND !is_dir($fichier)  AND $age_fichier > $age_requis)          {
          unlink($chemin);
          }
  }
  closedir($repertoire); //on ferme !
}



/**
 * undocumented function
 *
 * @return void
 * @author 
 **/
function delete_files($thewhat,$theid)
{

  global $dbItemsTable;  
  global $dbCatsTable; 
  global $dbUsersTable; 
  global $dbStatsTable; 
  global $dbLogsTable; 
  
  global $debug_tmp; 
  global $debugfile;
  
  global $ENABLE_ELEM_LOGS ; 
  global $ENABLE_USER_LOGS ; 

  global $dest_path_ad; 
  global $dest_path_cat;
  global $dest_path_user; 

  logfile('', "{delete_files} -$thewhat  -  $theid");

  
  $thistable=""; 
  if ($thewhat=="user"|| $thewhat=="users") { $thistable=$dbUsersTable; $path = $dest_path_user; }
  if ($thewhat=="ad" || $thewhat=="ads") { $thistable=$dbItemsTable; $path = $dest_path_ad; }
  if ($thewhat=="cat" ||  $thewhat=="cads") { $thistable=$dbCatsTable; $path = $dest_path_cat; }

  if (($thistable) && ($theid)) {
    // make the delete action  of the item
    if ($thewhat=="user") 
        $query= "SELECT  `avatarimg`, `probannerimg`, `folioimg` FROM $thistable  WHERE (`id` = '".$theid."') ";
    else if ($thewhat=="ad")
        $query= "SELECT  `imgname`, `audiourl`, `videourl`, `docurl` FROM $thistable  WHERE (`id` = '".$theid."') ";
    else // case of cat 
        $query= "SELECT  `imgname`  FROM $thistable  WHERE (`id` = '".$theid."') ";

    $result = @mysql_query($query);
    if (!$result) logfile('error','{delete_files} : SQL ERROR ='. mysql_error());

    if (mysql_num_rows($result)){
      while ($row = mysql_fetch_array($result)) { 
        $row_gi["status"];
        if ($thewhat=="user"){

          foreach(explode(";",$row['avatarimg']) as $img) {
            $img= explode("|", $img); 
            if ($img[0]) {
                @unlink($path."".$img[0]);
                @unlink($path."tn_".$img[0]);
                @unlink($path."tn2_".$img[0]);
              }
          }

          foreach(explode(";",$row['probannerimg']) as $img) {
            $img= explode("|", $img); 
              if ($img[0]) {
                @unlink($path."".$img[0]);
                @unlink($path."tn_".$img[0]);
                @unlink($path."tn2_".$img[0]);
              }          }
          
          foreach(explode(";",$row['folioimg']) as $img) {
            $img= explode("|", $img); 
              if ($img[0]) {
                @unlink($path."".$img[0]);
                @unlink($path."tn_".$img[0]);
                @unlink($path."tn2_".$img[0]);
              }          }
        } else 
        {

          foreach(explode(";",$row['imgname']) as $img) {
              $img= explode("|", $img); 
              if ($img[0]) {
                logfile('','{delete_files}deleting '.$path."".$img[0]);
                @unlink($path."".$img[0]);
                @unlink($path."tn_".$img[0]);
                @unlink($path."tn2_".$img[0]);
              }          }

              if ($thewhat=="ad"){

                if ($row['audiourl']){
                foreach(explode(";",$row['audiourl']) as $img) {
                    $img= explode("|", $img); 
                    if ($img[0]) {
                      logfile('','{delete_files}deleting '.$path."".$img[0]);
                      @unlink($path."".$img[0]);
                      @unlink($path."tn_".$img[0]);
                      @unlink($path."tn2_".$img[0]);
                    }          }
                }

                foreach(explode(";",$row['videourl']) as $img) {
                    $img= explode("|", $img); 
                    if ($img[0]) { 
                      logfile('','{delete_files}deleting '.$path."".$img[0]);
                      @unlink($path."".$img[0]);
                      @unlink($path."tn_".$img[0]);
                      @unlink($path."tn2_".$img[0]);
                    }          }
              
                foreach(explode(";",$row['docurl']) as $img) {
                    $img= explode("|", $img); 
                    if ($img[0]) {  
                      logfile('','{delete_files}deleting '.$path."".$img[0]);
                      @unlink($path."".$img[0]);
                      @unlink($path."tn_".$img[0]);
                      @unlink($path."tn2_".$img[0]);
                    }          }

            }


        }
      }
    } 
   
  }
  //if ($debug_tmp==1){  fwrite($debugfile,"\n"); fwrite($debugfile,$query);  fwrite($debugfile,"\n");}
  return $result; 
  
}

/**-----------------------------------------------------------------------------
* This function get the list of categories for a given condition 
* $what : user |  ad | cat
* $type  : restric to the given type 
* $search  : search condition 
* $dbThisTable : the relatd table of SQLDB
* $mode can be 'null' {catid, qty} or 'ext' {catid, type, title, qty} or 'ext2'= list of all categories
*-----------------------------------------------------------------------------*/
function sql_get_cat_list($what, $type, $search, $dbThisTable, $mode, $f_catid, $f_locfield, $f_locval){
   

  // at initialization phase  INIT : 
  // ad, user -> EXT -- cat --> EXT2 mode
  // at run time  : mode=""; 

  global $dbCatsTable; 
  global $dbItemsTable;
  global $dbUsersTable;
  global $querycatfull;
  global $debug_tmp; 
  global $debugfile;
  global $dest_path_from_root_cat;
  global $CAT_FILTER_PROTYPE;
  
  $sql_sort = "ORDER BY `adsnb` DESC ";   
  $sql_group="  GROUP BY i.`catid`";
  $sql_where = ""; 
  
  //patch to force the mode when What=USER 
  //if (($what=="user") || ($what=="users")) {$mode="ext"; $what="user";$type=false;}
    
  // filter conditions 
  if ($type) {
     $f_stub ="  i.`type` =  '".$type."' ";   
     $sql_where.=($sql_where=="") ? " WHERE $f_stub " : " AND $f_stub "; 
  }
  else 
  {
    // not type defined, remove the ZETVU
    if (($what=="ad") ||  ($what=="item") || ($what=="items"))
      if ($sql_where=="") $sql_where.="  WHERE i.`type` NOT LIKE  'zetvu'"; else $sql_where.="  AND i.type` NOT LIKE  'zetvu' ";
    
    // if list only the public and pro profils
    if (($what=="user")|| ($what=="users"))
     
        if ($sql_where=="") $sql_where.="  WHERE i.`indir` IN ('yes') "; else $sql_where.="  AND i.`indir` IN ('yes') ";

  }

  // STATUS conditions   
  if ($sql_where=="") $sql_where.="  WHERE i.`status` IN ('40','45','46') "; else $sql_where.="  AND i.`status` IN ('40','45','46')  ";

  // SEARCH conditions 
  if ($search)  
    if ($sql_where=="")  $sql_where.="  WHERE ((i.`title` like  '%".$search."%') OR (i.`description` like  '%".$search."%')) "; 
    else  $sql_where.="  AND ((i.`title` like  '%".$search."%') OR (i.`description` like  '%".$search."%')) ";


   // location condisions
   //filter per location  (ad and users) 
    if (($f_locfield)){
      $f_stub = " i.`$f_locfield` =  '$f_locval' ";
      $sql_where.=($sql_where=="") ? " WHERE $f_stub " : " AND $f_stub "; 
    } 

  // ----  basic query for AD
  

  // ---- basic query for USER 
  if (($what=="user")|| ($what=="users")){

       // $sql_where_joint = " a.skills LIKE CONCAT('%c=', c1.id,'%')";   // JOIN condition 
       // $sql_group ="  GROUP BY c1.`id` "; 
       // $sql_where =""; 
       // $sql_sort =" ORDER BY adsnb DESC, c1.`order` "; 
       
       // $querycatfull = "SELECT c1.*,  COUNT(a.id) AS `adsnb`
       //            FROM `$dbCatsTable` c1 
       //            LEFT JOIN `$dbUsersTable` a ON ( a.`status` IN ('40','45') AND a.`protype` IN ('pub','pro')  AND $sql_where_joint)
       //            ".$sql_where." ". $sql_group." ". $sql_sort ;

        $sql_group ="  GROUP BY `catid`, i.type "; 
        if ($what=="user" || $what=="users" ){
          $sql_where.= " AND i.skills LIKE CONCAT('%c=', c.id,'%')";   // JOIN condition 
          $sql_group ="  GROUP BY c.id , c.type ";  
          $querycatfull = "SELECT  c.id as `catid`, c.type, c.title, COUNT(i.id) as `adsnb` 
                            FROM `$dbThisTable` i, `$dbCatsTable` c 
                          " .$sql_where." ". $sql_group." ". $sql_sort ;  
        }
  } else  if (($what=="ad") ||  ($what=="item") || ($what=="items") ) {

    $sql_where .=" AND c.`status` IN ('40','45') "; 
    $querycatfull = "SELECT i.`catid`,  COUNT(i.id) as `adsnb` 
                        FROM `$dbThisTable` i  
                        LEFT JOIN `$dbCatsTable` c ON i.`catid`= c.`id`
                    ".$sql_where." ". $sql_group." ". $sql_sort ;
                   
  } else {
       $querycatfull = "SELECT i.`catid`,  COUNT(i.id) as `adsnb` 
                        FROM `$dbThisTable` i  
                    ".$sql_where." ". $sql_group." ". $sql_sort ;
  }

  
  // --- Advanced  query -> EXT mode ---- 
  if (($mode) && ($mode=="ext")){
   
    if ($what=="user"){
       // case of USER  
       $sql_where_joint = " a.skills LIKE CONCAT('%c=', c1.id,'%')";   // JOIN condition 
       $sql_group ="  GROUP BY c1.`id` "; 
            $sql_where =" WHERE c1.`status` IN ('40','45','46') "; 
            $sql_sort =" ORDER BY c2.`order`, c1.`order`, c1.`title`  "; 
            $querycatfull = "SELECT c1.*,  COUNT(a.id) AS `adsnb`
                  FROM `$dbCatsTable` c1 
                  LEFT JOIN `$dbCatsTable` c2 ON c1.`pid`= c2.`id` 
                  LEFT JOIN `$dbUsersTable` a ON ( a.`status` IN ('40','45', '46') AND a.`indir` IN ('yes')  AND $sql_where_joint)
                  ".$sql_where." ". $sql_group." ". $sql_sort ;

                  $debugdisplay  = $querycatfull; 
    }
    else{ 
      // case of AD
      $sql_group ="  GROUP BY c1.`id`, a.`type`  "; 
      $sql_where =" WHERE c1.`status` IN ('40','45','46') "; 
      $sql_sort =" ORDER BY c2.`order`, c1.`order`, c1.`title`  "; 
      $querycatfull = "SELECT c1.*, a.type AS `adstype`, COUNT(a.id) AS `adsnb`
            FROM `$dbCatsTable` c1 
            LEFT JOIN `$dbCatsTable` c2 ON c1.`pid`= c2.`id` 
            LEFT JOIN `$dbItemsTable` a ON ( c1.`id`= a.`catid` AND  a.`status` IN ('40','45','46')  AND a.`type`='$type')
            ".$sql_where." ". $sql_group." ". $sql_sort ;
    
    }
  }

  // --- Advanced  query -> EXT2 mode ---- 
  if (($mode) && ($mode=="ext2")){
    $sql_group=" ";  
    $sql_where_add = " i.`pid`=0 ";    
    $sql_sort =" ORDER BY c2.`order`, i.`order`, i.`title` "; // FORCE this NEW ZADS 4.8
    if ($CAT_FILTER_PROTYPE) $sql_sort =" ORDER BY i.`protype` ASC, c2.`order`, i.`order`, i.`title` "; // change this in ZADS 7.0.0

     $querycatfull = "SELECT 
            i.* 
            FROM `$dbThisTable` i 
            LEFT JOIN `$dbThisTable` c2 ON c2.`id`= i.`pid` ".$sql_where." ". $sql_group." ". $sql_sort ;
  }
  
 
  $resultcatfull = mysql_query($querycatfull);
  $totnbrofresultscat = mysql_num_rows($resultcatfull);
    
    if (($totnbrofresultscat) && ($totnbrofresultscat !=0)){
      $idx=0;
      $outdata=""; 


      // add extra infor for EXT2 mode 
      if (($mode) && ($mode=="ext2")){
        $out[$idx] = Array (
                  'id' => "0" ,
                  'value' => "0" ,
                  'name'=> 'select one categorie',
                  'description'=> 'select one categorie', 
                  'type'=> ''    
                  );
        $idx+=1;
      }


      while ($row = mysql_fetch_object($resultcatfull)) {     
        if (($mode) && ($mode=="ext")){

          $outdata = Array (
            'id' => $row->id ,
            'cattitle' => $row->title,
            'adsnb' => $row->adsnb,
            'cattype'=> $row->type,
            'type'=> $row->adstype,
            'parentid' => $row->pid,
            'order'=> $row->order,
            'imgurl'=> $row->imgname,
            'imgpath'=> $dest_path_from_root_cat,
            'iconurl'=> $row->iconname,
            'iconpath'=> $dest_path_from_root_cat,
            'adultflag'=>$row->adultflag,
            'adulttext'=>  $row->adulttext,
            'pricetype'=>$row->pricetype, 
            'acl'=>  $row->acl,
            'protype'=>$row->protype       
          );

        } else if (($mode) && ($mode=="ext2")){

          // pre-processing
          if (isset($row->c2_id)){
            // LEVEL 2 
            $outdata = Array (
              'level'=>"2",
              'id' => $row->id ,
              'parentid' => $row->pid,
              'order'=> $row->order,
              'value' => $row->id ,
              'name'=> stripslashes($row->title),
              'description'=> stripslashes($row->description), 
              'type'=> $row->type,
              'imgurl'=> $row->imgname,
              'imgpath'=> $dest_path_from_root_cat,
              'iconurl'=> $row->iconname,
              'iconpath'=> $dest_path_from_root_cat, 
              'catlvfields'=>  $row->catlvfields,
              'adultflag'=>$row->adultflag,
              'adulttext'=>  $row->adulttext,
              'hascalendar'=>$row->hascalendar, 
              'pricetype'=>$row->pricetype, 
              'acl'=>  $row->acl, 
              'metatitle'=>$row->metatitle,
              'metadesc'=>$row->metadesc,
              'metakey'=>$row->metakey,
              'protype'=>$row->protype    
            );
          }
          else {
          // this means this is a MASTER or TOP  LEVEL Car -> need to take from regular
              $outdata = Array (
              'level'=>"1",  
              'id' => $row->id ,
              'parentid' => $row->pid,
              'order'=> $row->order,
              'value' => $row->id ,
              'name'=> stripslashes($row->title),
              'description'=> stripslashes($row->description), 
              'type'=> $row->type,
              'imgurl'=> $row->imgname,
              'imgpath'=> $dest_path_from_root_cat,
               'iconurl'=> $row->iconname,
              'iconpath'=> $dest_path_from_root_cat,
              'catlvfields'=>  $row->catlvfields,
              'adultflag'=>$row->adultflag,
              'adulttext'=>  $row->adulttext,
              'hascalendar'=>$row->hascalendar, 
              'pricetype'=>$row->pricetype, 
              'acl'=>  $row->acl,
              'metatitle'=>$row->metatitle,
              'metadesc'=>$row->metadesc,
              'metakey'=>$row->metakey, 
              'protype'=>$row->protype       
            );
          }
        } else 
        {
          // normal reduced mode  
          $outdata = Array (
            'id' => $row->catid ,
            'adsnb'=> $row->adsnb 
            );
        }
       $out[$idx] = $outdata; 
       $idx+=1; 
      }
    }

  //if (($mode) && ($mode=="ext") && ($what=="user")) return $querycatfull;
  //if (($mode) && ($mode=="ext2")) return $querycatfull;
 
 
  return $out; 
}





/**-----------------------------------------------------------------------------
* This function get the list of locations  for a given condition 
* $what : user |  ad | cat
* $type  : restric to the given type  seel | buy | custom
* $search  : search condition 
$ $loclevel : the current level of search
* $dbThisTable : the relatd table of SQLDB
* $mode can be 'null' {catid, qty} or 'ext' {catid, type, title, qty} or 'ext2'= list of all categories
*-----------------------------------------------------------------------------*/
function sql_get_loc_list($what, $type, $search, $loclevel, $dbThisTable, $mode, $f_catid, $f_locfield, $f_locval){
   

  // at initialization phase  INIT : 
  // ad, user -> EXT -- cat --> EXT2 mode
  // at run time  : mode=""; 

  global $dbCatsTable; 
  global $dbItemsTable;
  global $dbUsersTable;
  global $querycatfull;
  global $debug_tmp; 
  global $debugfile;
  global $dest_path_from_root_cat;
  global $BROWSEBYLOC_FIELDS_ORDER;
  
  $sql_where = ""; 
  $sql_limit = "LIMIT 0 , 15 "; 
  $sql_limit = "LIMIT 0 , 40 "; // 40 regions or departments for the initial map !  

  // default loc field 
  if (!$loclevel) $loclevel=0; 
  else $loclevel=(int)$loclevel;

  $locfieldAr =  explode("|", $BROWSEBYLOC_FIELDS_ORDER);
  $locfieldnumber =  count($locfieldAr);
  if (($loclevel+1) > $locfieldnumber) $loclevel = $locfieldnumber-1; // if above the max then display the last level 
  $locfield = $locfieldAr[$loclevel];

  //filter per location  (ad and users) and modify field to display
  if (($f_locfield)){
    // where filter   
    $f_stub = " i.`$f_locfield` =  '$f_locval' ";
    $sql_where.=($sql_where=="") ? " WHERE $f_stub " : " AND $f_stub "; 

    // find position of this field into FIELD ORDERs
    $i=0; 
    foreach($locfieldAr  as $locfieldItem) {
      if ($locfieldItem == $f_locfield) {
        $loclevel = $i+1; // take the next one  ! 
        if (($loclevel+1) > $locfieldnumber) $loclevel = $locfieldnumber-1;
        break; // quit the foreach 
      } 
      $i+=1;
    }; 

    // finalize new field 
     $locfield = $locfieldAr[$loclevel];
  } 

  // category filter 
   if (($f_catid)){
    // where filter   
    $f_stub = " i.`catid` =  '$f_catid' ";
    $sql_where.=($sql_where=="") ? " WHERE $f_stub " : " AND $f_stub "; 
  }

  //patch to force the mode when What=USER 
  //if (($what=="user") || ($what=="users")) {$mode="ext"; $what="user";$type=false;}
    
  // filter conditions 
  if ($type) {
     $f_stub ="  i.`type` =  '".$type."' ";   
     $sql_where.=($sql_where=="") ? " WHERE $f_stub " : " AND $f_stub "; 
  }
  else 
  {
    // not type defined, remove the ZETVU
    if (($what=="ad") ||  ($what=="item") || ($what=="items"))
      if ($sql_where=="") $sql_where.="  WHERE i.`type` NOT LIKE  'zetvu'"; else $sql_where.="  AND i.type` NOT LIKE  'zetvu' ";
    
    // if list only the public and pro profils
    if (($what=="user") || ($what=="users"))
      // if ($sql_where=="") $sql_where.="  WHERE i.`protype` IN ('pub','pro') "; else $filter.="  AND i.`protype` IN ('pub','pro') ";
      if ($sql_where=="") $sql_where.="  WHERE i.`indir` = 'yes' "; else $sql_where.="  AND i.`indir` = 'yes' ";


  }

  // STATUS conditions   
  if ($sql_where=="") $sql_where.="  WHERE i.`status` IN ('40','45') "; else $sql_where.="  AND i.`status` IN ('40','45')  ";

  // SEARCH conditions 
  if ($search)  
    if ($sql_where=="")  $sql_where.="  WHERE ((i.`title` like  '%".$search."%') OR (i.`description` like  '%".$search."%')) "; 
    else  $sql_where.="  AND ((i.`title` like  '%".$search."%') OR (i.`description` like  '%".$search."%')) ";
    
  // --- Advanced  query -> EXT mode ---- 
  if (($mode) && ($mode=="ext")){
      // case of AD
      $sql_group ="  GROUP BY `loc` "; 
      $sql_sort =" ORDER BY `adsnb` DESC , `loc` ASC "; 
      $querylocfull = "SELECT i.`$locfield` as `loc`, COUNT(i.id) AS `adsnb`
            FROM `$dbThisTable` i 
            ".$sql_where." ". $sql_group." ". $sql_sort ." ". $sql_limit;
  }

  // ---- theSQL query  ! 
  $resultlocfull = mysql_query($querylocfull);
  
  // logfile('debug','{sql_get_loc_list} : QUERY = '.$querylocfull);
  if (!$resultlocfull) logfile('error','{sql_get_loc_list} : SQL ERROR ='. mysql_error());
  $totnbrofresultsloc = mysql_num_rows($resultlocfull);
    
    if (($totnbrofresultsloc) && ($totnbrofresultsloc !=0)){
      $idx=0;
      $outdata=""; 

      while ($row = mysql_fetch_object($resultlocfull)) {     
        if (($mode) && ($mode=="ext")){
          if ($row->loc!='') { // protection against zero values
            $outdata = Array (
              'loc' => $row->loc ,
              'adsnb' => $row->adsnb, 
              'type'=> $locfield
            );
            $out[$idx] = $outdata; 
            $idx+=1; 
          }
        } 

      }
    } 
  return $out; 
}

/**-----------------------------------------------------------------------------
* This function get the user details based on indicated id or based on session if no ID indicated 
*-----------------------------------------------------------------------------*/
function  get_user_details($userid){
  global $dbUsersTable;
  $out = false;
  $this_user_id = $userid; 

  $where =''; 
  $query = "SELECT *  FROM `$dbUsersTable` WHERE `id` = '".$this_user_id."' $where"; 
  $result = mysql_query($query);
  logfile('','{get_user_details} : QUERY = '.$query);
  if ($result) {
    while ($row = mysql_fetch_array($result)) { 
      $out = $row;
    }
  } else { logfile('error', '{get_user_details} : SQL ERROR ='. mysql_error()); return false;}
  // send the results
  return $out; 

}




/**-----------------------------------------------------------------------------
* This function get the user details based on indicated id or based on session if no ID indicated 
*-----------------------------------------------------------------------------*/
function  get_nb_ads_this_user($userid){
  global $dbItemsTable;

  $out = false;
  $this_user_id = $userid; 

  $where = "  AND `status` IN ('40','45', '46') "; 
  $query = "SELECT COUNT(`id`) as 'totadsnb'  FROM `$dbItemsTable` WHERE `userid` = '".$this_user_id."' $where"; 
  $result = mysql_query($query);
  logfile('','{get_nb_ads_this_user} : QUERY = '.$query);
  if ($result) {
    while ($row = mysql_fetch_array($result)) { 
      $out = $row;
    }
  } else { logfile('error', '{get_nb_ads_this_user} : SQL ERROR ='. mysql_error()); return false;}
  // send the results
  return $out; 

}



/**-----------------------------------------------------------------------------
* This function update the paidoptions with a new date 
*-----------------------------------------------------------------------------*/
function  json_find_elem_by_name($db, $nametofind){
  $out=false; 
  if (!$nametofind) return false ; // protection

  foreach ($db as  $elem) {
    if ($elem["name"]== $nametofind) return $elem; 
  }
  return $out; 
}

function  json_find_elem_by_n($db, $nametofind){
  $out=false; 
  if (!$nametofind) return false ; // protection

  foreach ($db as  $elem) {
    if ($elem["n"]== $nametofind) return $elem; 
  }
  return $out; 
}


/**-----------------------------------------------------------------------------
* This function update the paidoptions with a new date 
*-----------------------------------------------------------------------------*/
function  json_find_elem_by_id($db, $idtofind){
  $out=false; 
  if (!$idtofind) return false ; // protection

  foreach ($db as  $elem) {
    if ($elem["id"]== $idtofind) return $elem; 
  }
  return $out; 
}



/**-----------------------------------------------------------------------------
* This function update the paidoptions with a new date 
*-----------------------------------------------------------------------------*/
function update_dates_on_paidoptions($paidoptions, $stamp){
  
  global $general_catalogue;
  $out=''; 
  if (!$paidoptions) return '' ; // protection
  
  $rdata = parseStrToArr($paidoptions); 
          
  foreach ($rdata as $paidoption => $pvalue) {
    if ($paidoption){
       $out.= '&'.$paidoption.'=';
       $res= json_find_elem_by_name($general_catalogue['payoptions']['options'],$paidoption ); 
       if ($res){
        if ($res["unit"]=="days") $pvalue = time() + $res["value"]*24*3600; 
        else $pvalue=$res["value"];
       }
       $out.= $pvalue; // save the value chick could bu patched of not 
    }
   }
   return $out;  
}


/**-----------------------------------------------------------------------------
* This function log an event into the LOGS table 
*-----------------------------------------------------------------------------*/
function log_event($action,$what, $whatid, $userid, $eventdesc, $severity){
  global $dbLogsTable;

  $now = date( 'Y-m-d H:i:s', time());
  $query  = "INSERT INTO `".$dbLogsTable."` (`date`, `action`, `what`, `whatid`, `userid`, `desc`, `severity`) ";
  $query .= "VALUES ('".$now."', '".$action."', '".$what."', '".$whatid."', '".$userid."', '".$eventdesc."', '".$severity."');";
  $result = @mysql_query($query);  

  logfile('debug', "{log_event} : event log result  : ". $result); 
  
  return $result ; // TRUE if ok.

}

/**-----------------------------------------------------------------------------
* This function log time int global variable 
*-----------------------------------------------------------------------------*/
function logtime($msg){
  global $t0;
  global $timing_trace;

  $deltatime= (microtime(true)-$t0); 
  $timing_trace.= "|$msg ".sprintf("%01.3f", $deltatime). "s "; 
  $t0=microtime(true); 
  return true;
}


/**-----------------------------------------------------------------------------
* This function log an event into TEXT file(s)
*-----------------------------------------------------------------------------*/
function logfile($status, $msg, $line=null){

  // status per SYSLOG definition 
  // PANIC (0) | ALERT (1) | CRTI (2) | ERROR (3) | WARNING (4) | NOTICE (5) | INFO (6) | DEBUG (7)
  $debug_matrix =  array (
      "PANIC" => 0, "ALERT" => 1, "CRTI" => 2, "ERROR" => 3, "WARNING" => 4, "NOTICE" => 5, "INFO" => 6, "DEBUG" => 7
      );

  global $debug_tmp; 
  global $debug_level;
  global $debugfile; 

  // $debug_level="7";

  $style =""; $disp_status=""; 

  $_SEPARATOR=" - "; // separator 

  if ($debug_tmp==1) {

    if ($status=="") $status="DEBUG"; 
    if (strtolower($status)=="error" || strtolower($status)=="notice" || strtolower($status)=="warning") 
      $style="color:red;";

    $hm = "<div>"; 
    $hm .= "<span class='date' style='font-size:0.8em;'>".date('Y-m-d H:i:s',time()).'</span>'; 
    $hm .= $_SEPARATOR; 
    $hm .= '<span class="" style="'.$style.'">'. strtoupper($status).'</span>'; 
    $hm .= $_SEPARATOR; 
    if ($line) {
      $hm .= '<span class="" style="">'. strtoupper($line).'</span>'; 
      $hm .= $_SEPARATOR; 
    }
    //$hm .= strtolower($msg);
    $hm .= $msg;
    $hm .= "</div>"; 

    // final write to file if level if higher
    if ( $debug_matrix[strtoupper($status)]  <= intval($debug_level)) { 
      fwrite($debugfile,$hm);
    } 
  }
  return true; 
}

/**-----------------------------------------------------------------------------
* This function evaluate for a given trigger if need to send an email or not.
* function fased on mail() function 
* 
* @param  $emailRT {array} the Associative Array containing email policy rules
* @param  $what {string} identify which element trigerred the mail 
* @param  $state {string} identify which state  trigerred the mail 
* @return $dataobj {array} contains the data to be displayed into the message
* @param  $useremail {string} email address of the user triggering this action
* 
*-----------------------------------------------------------------------------*/
$input_datas_is_utf8=true; // indicate if stored DATAS in DATABASE are in UTF8 ou LATAM 
function mySendEmail($emailRT, $what, $state, $dataobj, $useremail){
  global $debug_tmp; // true : we store the content of the mail into the LOG file.
  global $enableEmail;  // true : email is activated 
  global $debugfile; 
  global $email_admin; 
  global $email_admin_reports; 
  global $email_superadmin; 
  global $email_fromadmin; 
  global $email_support;
  global $email_sales;  
  global $phpVersion; 
  global $ENABLE_EMAILS_TEMPLATES;
  global $EMAILS_TEMPLATES_ENH;

  global $input_datas_is_utf8;

  //if (!$debug_tmp) 
  $enableEmail=true;

  // Z6.8.2 - all templates are stored in UTF8 format 
  if ($EMAILS_TEMPLATES_ENH) define('EMAIL_FORMAT_UTF8', true);

  $input_datas_is_utf8=true; // keep if as utf8 
  
  $message=""; 
  $htmlmessage="";
    
  $emailrules = $emailRT[$what][$state]; 

  logfile('', "{mySendEmail} : what=$what and state=$state", __LINE__); 
  if (!$emailrules)  logfile('notice', "{mySendEmail}  : no email rule found for this ",__LINE__); 

  foreach($emailrules as $key => $theemailrule){  

      // Z6.8.2 exit if the rule is disabled
      if ($EMAILS_TEMPLATES_ENH && !$theemailrule['en']) {
        logfile('', "{mySendEmail} : email sending is DISABLED for this rule"); 
      } else 
      {
        // reset vars
        $message=""; 
        $htmlmessage="";
        
        // Pour envoyer un mail HTML, len-tête Content-type doit être défini
        $headers  = 'MIME-Version: 1.0' . "\r\n";
        if (EMAIL_FORMAT_UTF8) $headers .= 'Content-type: text/html; charset=utf-8' . "\r\n"; // for HTML documents
        else   $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; // for HTML documents

        // En-têtes additionnels
        if ($theemailrule["to"]=="USER") $emailto =  $useremail; 
        else if ($theemailrule["to"]=="ADMIN") $emailto =  $email_admin; 
        else if ($theemailrule["to"]=="ADMIN_REPORTS") $emailto =  $email_admin_reports; 
        else if ($theemailrule["to"]=="SUPPORT") $emailto =  $email_support; 
        else if ($theemailrule["to"]=="SALES") $emailto =  $email_sales; 
        else if ($theemailrule["to"]=="OWNER") $emailto =  $dataobj["emailto"]; 
        else if ($theemailrule["to"]=="SUPERADMIN") $emailto =  $email_superadmin;  
        else $emailto =  $email_admin; 
        
        // $headers .= "To: $emailto" . "\r\n";
        $headers .= "From: $email_fromadmin" . "\r\n";
        $headers .= "Cc: ". $theemailrule["cc"] . "\r\n";
        $headers .= "Bcc:". $theemailrule["bcc"] . "\r\n";
        
        // to define priority 
        if ($theemailrule["priority"] !=""){
          $headers .= "X-Priority: 1 (Higuest)\n"; 
          $headers .= "X-MSMail-Priority: High\n"; 
          $headers .= "Importance: High\n"; 
        }

        // destination user
        $recipient = $emailto;
        $stamp= date( 'Y-m-d H:i:s', time());
        
        // define subject with right encoding
        if (!$EMAILS_TEMPLATES_ENH){
          $subjectin =  $theemailrule["title"]; 
          if ($phpVersion>=5300)  $subject = '=?ISO-8859-1?Q?'.quoted_printable_encode($subjectin).'?=';
          else $subject = '=?ISO-8859-1?Q?'.my_quoted_printable_encode($subjectin).'?=';
        } else {
          $subject ="none";
        }
      
        // define content of the email 
        if ($ENABLE_EMAILS_TEMPLATES) // new Z5.1 - use template files for sending emails 
          $message = build_message_based_template($what, $state,  $theemailrule, $dataobj); 
        else 
          $message.= build_html_message($what, $state,  $theemailrule, $dataobj ); 
        
        //Z6.8.2 - correct the message and ssubject 
        if ($EMAILS_TEMPLATES_ENH && $message ){
           $fmessage =   $message['body'] ; 
           $subject =  $message['title'] ;
        } else {
          $fmessage = $message ; 
        }

        logfile('', "{mySendEmail} : EMAILS_TEMPLATES_ENH=$EMAILS_TEMPLATES_ENH and subject=$subject  ", __LINE__); 
        // wrap subject into HTML TAG 

        if ($message){
          if (($enableEmail)) {
            if (mail ("$recipient", "$subject", "$fmessage", "$headers")){
              $result= " Mail  : $subject sent  to $recipient ";
              logfile('', '{mySendEmail} : '.$result); 
            } 
            else  {
              $result= " $subject error  while sending to $recipient \n";  
              logfile('notice', $result); 
              logfile('notice', print_r(error_get_last(), true)); // $results contient l'affichage de print_r
            }
          } 
          // display the message content
          logfile('', $fmessage); 
        } else  
          logfile('notice', "{mySendEmail} : Email message not sent, Content is empty"); 

    } // end IF enable
  }// end foreach 
}



function my_quoted_printable_encode($input, $line_max = 75) { 
   $hex = array('0','1','2','3','4','5','6','7', 
                          '8','9','A','B','C','D','E','F'); 
   $lines = preg_split("/(?:\r\n|\r|\n)/", $input); 
   $linebreak = "=0D=0A=\r\n"; 
   /* the linebreak also counts as characters in the mime_qp_long_line 
    * rule of spam-assassin */ 
   $line_max = $line_max - strlen($linebreak); 
   $escape = "="; 
   $output = ""; 
   $cur_conv_line = ""; 
   $length = 0; 
   $whitespace_pos = 0; 
   $addtl_chars = 0; 

   // iterate lines 
   for ($j=0; $j<count($lines); $j++) { 
     $line = $lines[$j]; 
     $linlen = strlen($line); 

     // iterate chars 
     for ($i = 0; $i < $linlen; $i++) { 
       $c = substr($line, $i, 1); 
       $dec = ord($c); 

       $length++; 

       if ($dec == 32) { 
          // space occurring at end of line, need to encode 
          if (($i == ($linlen - 1))) { 
             $c = "=20"; 
             $length += 2; 
          } 

          $addtl_chars = 0; 
          $whitespace_pos = $i; 
       } elseif ( ($dec == 61) || ($dec < 32 ) || ($dec > 126) ) { 
          $h2 = floor($dec/16); $h1 = floor($dec%16); 
          $c = $escape . $hex["$h2"] . $hex["$h1"]; 
          $length += 2; 
          $addtl_chars += 2; 
       } 

       // length for wordwrap exceeded, get a newline into the text 
       if ($length >= $line_max) { 
         $cur_conv_line .= $c; 

         // read only up to the whitespace for the current line 
         $whitesp_diff = $i - $whitespace_pos + $addtl_chars; 

        /* the text after the whitespace will have to be read 
         * again ( + any additional characters that came into 
         * existence as a result of the encoding process after the whitespace) 
         * 
         * Also, do not start at 0, if there was *no* whitespace in 
         * the whole line */ 
         if (($i + $addtl_chars) > $whitesp_diff) { 
            $output .= substr($cur_conv_line, 0, (strlen($cur_conv_line) - 
                           $whitesp_diff)) . $linebreak; 
            $i =  $i - $whitesp_diff + $addtl_chars; 
          } else { 
            $output .= $cur_conv_line . $linebreak; 
          } 

        $cur_conv_line = ""; 
        $length = 0; 
        $whitespace_pos = 0; 
      } else { 
        // length for wordwrap not reached, continue reading 
        $cur_conv_line .= $c; 
      } 
    } // end of for 

    $length = 0; 
    $whitespace_pos = 0; 
    $output .= $cur_conv_line; 
    $cur_conv_line = ""; 

    if ($j<=count($lines)-1) { 
      $output .= $linebreak; 
    } 
  } // end for 

  return trim($output); 
} // end quoted_printable_encode 


/**-----------------------------------------------------------------------------
* This function crete the HTML content of the email 
* 
* @param  $what {string} identify which element trigerred the mail
* @param  $state {string} the state which triggered the mail 
* @param  $theemailrule {array} identify the email policy / rules associated
* @return $dataobj {array} contains the data to be displayed into the message
* 
* Note on Encoding of chars *********************************
*   - data sent from JavaScript are encoded into UTF-8 and then stored into Database.
*   - once taken from Database, as we indicate de "latin 1" encoding , we convert all string to Latin
*   using the function utf8_decode(); 
*
*-----------------------------------------------------------------------------*/

function build_html_message( $what, $state, $theemailrule, $dataobj ){

  global $fullfqdn; 
  global $SITE_NAME; 
  global $SITE_MOTTO; 
  global $SITE_CUSTOMER;
   
  $stamp2= date( 'Y-m-d H:i:s', time());
    
  $email_site_name=$SITE_NAME; 
  $email_site_title=$SITE_MOTTO; 
  $email_site_subtitle=$SITE_CUSTOMER;
  $email_footer=$SITE_NAME._(" respects your confidentiality");
  
  $htmlmessage  =""; 
  $htmlmessage .= '<html> <body>';
  $htmlmessage .= '  <table width="580" style="margin:0 auto;font-family:arial;border-bottom:1px dotted #ccc;" cellpadding="5" cellspacing="0" border="0">';
  $htmlmessage .= '    <tr style="background:#193D5E">';
  $htmlmessage .= '<td style="font-size:12px;color:#fff;padding:3px 5px"><b>'.$email_site_name.'</b> '.$email_site_title.'</td>';
  $htmlmessage .= '		<td style="text-align:right;color:#fff;font-size:12px;padding:3px">'.$email_site_subtitle.'</td>';
  $htmlmessage .= '	</tr>';  
  $htmlmessage .= '    <tr><td colspan="2">';
  $htmlmessage .= $theemailrule["msgheader"]; 
  $htmlmessage .= '  <h3 style="font-size:16px;font-weight:bold; padding: 0; margin: 5px 0 2px;" >';
  $htmlmessage .= $theemailrule["title"];
  $htmlmessage .= '	</h3>';
  if ($theemailrule["msginner"]) $htmlmessage .= '<div style="font-size:10px;">'.$theemailrule["msginner"].'</div>'; 
  
  $htmlmessage .= '	<div style="border-top: 3px solid #069; line-height:3px;margin:4px 0 4px;">&nbsp;</div>';
  
  $htmlmessage .= '    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-top:1px;padding-bottom:10px;border-bottom:1px dotted #ccc;">';
  
  if (($what=="cron"))  {
    $htmlmessage .= '<tr><td style="font-size:11px;"> '.$dataobj.' </td></tr>'; 
  }
  
  if (($what=="lost"))  {
    $htmlmessage .= '<tr><td style="font-size:11px;"> '._("Connection email/username : ").'<b>'.$dataobj["email"].'</b> </td></tr>'; 
    $htmlmessage .= '<tr><td style="font-size:11px;"> '._("New Password : ").'<b>'.$dataobj["password"].'</b> </td></tr>';
    $htmlmessage .= '<tr><td style="font-size:11px;"> '._("Connection URL : ").'<a style="color:#039" href="'.$fullfqdn.'#login">'._("Click HERE").'</td></tr>'; 
  }
  
  
  if (($what=="support") || ($what=="feedback") || ($what=="abuse")|| ($what=="remind") || ($what=="contact") || ($what=="contactuser"))  {
    if ($what=="support") { 
      $htmlmessage .= '<tr><td><b>'._("Reason : ").utf8_decode(stripslashes($dataobj["contactreason"])).'</b> </td></tr>';
    }
    $htmlmessage .= '<tr><td><b>'.utf8_decode(stripslashes($dataobj["emailtitle"])).'</b> </td></tr>';
    $htmlmessage .= '<tr><td>'.nl2br(utf8_decode(stripslashes($dataobj["emaildesc"]))).' </td></tr>';
    
    $htmlmessage .= '<tr><td></td></tr>';
    
    if ($what=="feedback") 
      $htmlmessage .= '<tr><td>'.utf8_decode($dataobj["userenv"]).' </td></tr>';
    
    $htmlmessage .= '<tr><td style="font-size:11px;"> '._("From : ").utf8_decode($dataobj["emailfrom"]).'</b> </td></tr>'; 
    // extended informations
    if ($what=="support") { 
      $htmlmessage .= '<tr><td style="font-size:11px;"> '._("Firstname : ").utf8_decode($dataobj["firstname"]).'</b> </td></tr>'; 
      $htmlmessage .= '<tr><td style="font-size:11px;"> '._("Lastname : ").utf8_decode($dataobj["lastname"]).'</b> </td></tr>'; 
      $htmlmessage .= '<tr><td style="font-size:11px;"> '._("Phone : ").utf8_decode($dataobj["phone"]).'</b> </td></tr>'; 
      $htmlmessage .= '<tr><td style="font-size:11px;"> '._("Procpny : ").utf8_decode($dataobj["procpny"]).'</b> </td></tr>'; 
    }

    $htmlmessage .= '<tr><td style="font-size:11px;"> '._("Date : ").utf8_decode($dataobj["emailstamp"]).'</b> </td></tr>'; 


  }
  
  if (($what=="ad") || ($what=="abuse")|| ($what=="remind")|| ($what=="user")  || ($what=="contact") || ($what=="contactuser")) {
    $htmlmessage .= '      <tr style="margin:2px 0 2px;">';
    $htmlmessage .= '        <td style="font-size:13px;">';
    
    if (($what=="ad") || ($what=="abuse")|| ($what=="remind") || ($what=="contact") || ($what=="contactuser"))  { 
      if ($what=="contactuser") 
        $htmlmessage .= '			<a style="color:#039" href="'.$fullfqdn.'#user-'.$dataobj["id"].'">';
      else 
        $htmlmessage .= '			<a style="color:#039" href="'.$fullfqdn.'#item-'.$dataobj["id"].'">';
      $htmlmessage .= '			<b>'.htmlspecialchars(utf8_decode(stripslashes($dataobj["title"]))).' (#'.$dataobj["id"].')</b>';
      $htmlmessage .= '			</a>';
    }
  

    if ($what=="user"){
    
     $htmlmessage .= '      <a style="color:#039" href="'.$fullfqdn.'#user-'.$dataobj["id"].'">'; 
     $htmlmessage .= '      <b>'.utf8_decode($dataobj["firstname"]).' '.utf8_decode($dataobj["lastname"]).' ('.$dataobj["email"].')</b>';
     $htmlmessage .= '      </a>';

    // send the payment URL if User is in 
     if (($state=="15") && ($theemailrule["to"]!="ADMIN")){
        $htmlmessage .='<br>'; 
        $htmlmessage .=_("Find below the payment url");
        $htmlmessage .='<br>'; 
        $htmlmessage .='<b><a href="'.$dataobj["paymenturl"].'" >'._("Click here to proceed to payment")."</a></b>   "; 
     }

     // send the password when connection is activated 
     if (($state=="40") && ($theemailrule["to"]!="ADMIN") && ($dataobj["password"]!='')){
        $htmlmessage .='<br>'; 
        $htmlmessage .=_("Welcome user mesaage first time"); 
        $htmlmessage .='<br>'; 
        $htmlmessage .='<b>'._("Connection email/username : ")."</b>   ". $dataobj["email"]; 
        $htmlmessage .='<br>'; 
        $htmlmessage .='<b>'._("New Password : ")."</b>   ". $dataobj["password"]; 
        $htmlmessage .='<br>'; 
     }

    }

    
    $htmlmessage .= '		</td>';
    $htmlmessage .= '      </tr>';

    // add author info
    if ($what=="ad")  {
      $htmlmessage .= '<tr><td colspan="2"> ';
      $htmlmessage .= ' <p style="color:#666;font-size:11px;margin:3px 0 3px;">'; 
      if (($theemailrule["to"]!="OWNER") && ($theemailrule["to"]!="USER"))
        $htmlmessage .= _("By").'<a href="'.$fullfqdn.'#user-'.$dataobj["userid"].'"> '.utf8_decode($dataobj["firstname"]).' '.utf8_decode($dataobj["lastname"]).'</a>('.$dataobj["uemail"].'), '; 
      $htmlmessage .= _("the").' '.$stamp2; 
      $htmlmessage .= ' </p>';
      $htmlmessage .= '</td></tr>';
      
      // add special message when in state 40
      if (($state=="40") && ($theemailrule["to"]!="ADMIN")){
        $htmlmessage .= '      <tr style="">';
        $htmlmessage .= '        <td style="font-size:12px;padding:10px 0px 2px 0px;">';
        $htmlmessage .=  _("You can print ad leaftlet from ");
        $htmlmessage .= '			<a style="color:#039" href="'.$fullfqdn.'leaflet.php#item-'.$dataobj["id"].'">'. _("here").'</a>';
        $htmlmessage .= '		     </td>';
        $htmlmessage .= '      </tr>';
      }
    }
    
    if  ($dataobj["msg"]!=""){
      $htmlmessage .= '      <tr style="">';
      $htmlmessage .= '        <td style="font-size:11px;padding:10px 0px 2px 0px;">';
      $htmlmessage .= '        <strong>'._("Note/Message : ").' </strong>'.nl2br(utf8_decode(stripslashes($dataobj["msg"])));
      $htmlmessage .= '		     </td>';
      $htmlmessage .= '      </tr>';
    }
  }
  
  $htmlmessage .= '    </table>';
  $htmlmessage .= $theemailrule["msgfooter"]; 
  $htmlmessage .= '<div style="border-top: 3px solid #ddd; line-height:3px;margin:0;padding:0;">&nbsp;</div>';
  $htmlmessage .= '<p style="color:#666666; font-size:11px;margin:4px 0 4px 0;" >'.$email_footer.'&#169; 2013, <a href="'.$fullfqdn.'"> '.$fullfqdn.'</a> </p>';
    
  $htmlmessage .= '</td></tr></table>';
  $htmlmessage .= '</body>';
  $htmlmessage .= '</html>';
  
  return $htmlmessage;
}


  // $input_datas_is_utf8=true; 
  function utf8_adapt($strin){
    global $input_datas_is_utf8;
    if ($input_datas_is_utf8) $out=$strin; 
    else $out = utf8_decode($strin);  
    return $out;
  }

/**
 * create an HTML message based on a template 
 * @param $what string    : the element (ad, user, ...)
 * @param $state string   : the state 
 * @param $theemailrule   : array containing the TITLE and TO 
 * @return string  : the email CONTENT (HTML or TEXT) 
 * @author Patrice COHAUT
 */
 
function build_message_based_template($what, $state, $theemailrule, $dataobj){

  // existing vocabulory 
  // [SITE_NAME], [SITE_MOTTO], [SITE_CUSTOMER],  [SITE_FQDN], [SITE_LOGO]
  // [EMAIL_TITLE], 
  // [AD_TITLE] , [AD_ID], [AD_URL] , [AD_LEAFLET_URL],
  // [CUR_DATE] , 
  // [USER_FIRSTNAME], [USER_LASTNAME], [USER_EMAIL],  [USER_URL],  [MESSAGE] 


  $tags_library = array(
    "general" => array('SITE_NAME', 'SITE_MOTTO', 'SITE_CUSTOMER',  'SITE_FQDN', 'SITE_LOGO', 'SITE_COPYRIGHT', 'CUR_DATE', 'CUR_YEAR', 'STATIC_EMAIL_IMAGE_URL', 'BANNER_EMAIL_IMAGE_URL')
    ,"ad"=> array('AD_TITLE' , 'AD_ID', 'AD_URL' , 'AD_LEAFLET_URL', 'PAY_URL')
    ,"user"=>array('USER_FIRSTNAME', 'USER_LASTNAME', 'USER_EMAIL',  'USER_URL', 'USER_IP', 'USER_IP_DETAILS')
    ,"cron"=>array('CRONMESSAGE')
    ,"notif"=>array('NOTIFMESSAGE')
    ,"lost"=>array('LOGIN', 'PASSWORD', 'LOGIN_URL')
    ,"reactivateaccount"=>array('LOGIN', 'PASSWORD', 'LOGIN_URL')
    ,"lost-link"=>array('RESET_URL')
  ,"service"=>array('SERVICE_NAME', 'SERVICE_SDESC', 'SERVICE_ID',  'USER_URL')
  ,"support"=>array('CONTACT_REASON', 'CONTACT_TITLE', 'CONTACT_DETAILS',  'CONTACT_ENV', 'CONTACT_EMAILFROM', 'CONTACT_FIRSTNAME', 'CONTACT_LASTNAME',  'CONTACT_PROCPNY', 'CONTACT_DATE')
    ,"feedback"=>array('CONTACT_REASON', 'CONTACT_TITLE', 'CONTACT_DETAILS',  'CONTACT_ENV', 'CONTACT_EMAILFROM', 'CONTACT_FIRSTNAME', 'CONTACT_LASTNAME',  'CONTACT_PROCPNY', 'CONTACT_DATE')
    ,"abuse"=>array('CONTACT_REASON', 'CONTACT_TITLE', 'CONTACT_DETAILS',  'CONTACT_ENV', 'CONTACT_EMAILFROM', 'CONTACT_FIRSTNAME', 'CONTACT_LASTNAME',  'CONTACT_PROCPNY', 'CONTACT_DATE')
    ,"remind"=>array('CONTACT_REASON', 'CONTACT_TITLE', 'CONTACT_DETAILS',  'CONTACT_ENV', 'CONTACT_EMAILFROM', 'CONTACT_FIRSTNAME', 'CONTACT_LASTNAME',  'CONTACT_PROCPNY', 'CONTACT_DATE')
    ,"contact"=>array('CONTACT_REASON', 'CONTACT_TITLE', 'CONTACT_DETAILS',  'CONTACT_ENV', 'CONTACT_EMAILFROM', 'CONTACT_FIRSTNAME', 'CONTACT_LASTNAME',  'CONTACT_PROCPNY', 'CONTACT_DATE')
    ,"contactuser"=>array('CONTACT_REASON', 'CONTACT_TITLE', 'CONTACT_DETAILS',  'CONTACT_ENV', 'CONTACT_EMAILFROM', 'CONTACT_FIRSTNAME', 'CONTACT_LASTNAME',  'CONTACT_PROCPNY', 'CONTACT_DATE')

  );    


  global $fullfqdn; 
  global $SITE_NAME; 
  global $SITE_MOTTO; 
  global $SITE_CUSTOMER; 
  global $debugfile;
  global $cust_lang_long;
  global $EMAILS_TEMPLATES_ENH; 
  global $EMAILS_TEMPLATES_DIR;
  global $LOGO_FQDN; 
  global $cust_site_copyright;
  global $STATIC_EMAIL_IMAGE_URL;

  if (!defined("CACHE_PATH")) define('CACHE_PATH', 'cache/');


  //Z6.2.0
  global $supportfeedback_name_translation; 

  if (!defined('EMAIL_TEMPLATE_VERSION')){
    if ($EMAILS_TEMPLATES_ENH) define('EMAIL_TEMPLATE_VERSION', "V2");
    else define('EMAIL_TEMPLATE_VERSION', "V1");
  }

  $stamp2= date( 'Y-m-d H:i:s', time());
  $dest = $theemailrule["to"]; // AMDIN, USER, OWNER 
  $map = array(); //mapping table between input data and reported value 

  // logfile('', "{build_message_based_template} : in the email templating function"); 

  $map["SITE_NAME"]= utf8_adapt($SITE_NAME); 
  $map["SITE_MOTTO"]= utf8_adapt($SITE_MOTTO); 
  $map["SITE_CUSTOMER"]= utf8_adapt($SITE_CUSTOMER); 
  $map["SITE_FQDN"]= $fullfqdn;
  $map["SITE_LOGO"]= str_replace('./',$fullfqdn, $LOGO_FQDN, $count); 
  $map["SITE_COPYRIGHT"]= $cust_site_copyright; 

  // images 
  $map["STATIC_EMAIL_IMAGE_URL"]=($STATIC_EMAIL_IMAGE_URL)? $STATIC_EMAIL_IMAGE_URL : ''; 

  
  $map["CUR_DATE"]= $stamp2;
  $map["CUR_YEAR"]= date("Y");
  $map["EMAIL_TITLE"]=$theemailrule["title"];
  
  //if (($what=="ad") || ($what=="user")){
  $map["AD_URL"]= $fullfqdn.'#item-'.$dataobj["id"]; 
  $map["AD_TITLE"]= htmlspecialchars(utf8_adapt(stripslashes($dataobj["title"])));
  $map["AD_ID"]= $dataobj["id"];
  $map["AD_LEAFLET_URL"]= $fullfqdn.'leaflet.php#item-'.$dataobj["id"];
  $map["USER_FIRSTNAME"]= utf8_adapt($dataobj["firstname"]);
  $map["USER_LASTNAME"]= utf8_adapt($dataobj["lastname"]);
  $map["USER_EMAIL"]=$dataobj["uemail"];
  $map["USER_URL"]= $fullfqdn.'#user-'.$dataobj["id"];
  $map["MESSAGE"] = nl2br(utf8_adapt(stripslashes($dataobj["msg"]))); 


  $map["MYSERVICES_URL"]= $fullfqdn.'#myservices';

  // for debug, display all content 
  // $map["MESSAGE"] .= serialize($dataobj);  

  if (($what=="cron"))  {
    $map["CRONMESSAGE"]=$dataobj; 
  }

   if (($what=="notif"))  {
    $map["NOTIFMESSAGE"]=$dataobj; 
  }

  if (($what=="lost")  || ($what=="reactivateaccount") )  {
     $map["LOGIN"] = $dataobj["email"]; 
     $map["PASSWORD"] = $dataobj["password"]; 
     $map["LOGIN_URL"]= $fullfqdn.'#login';
  }

  if (($what=="lost-link") )  {
     $map["RESET_URL"] = $fullfqdn.'#'.$dataobj["reseturl"]; 
  }
  if ( ($what=="user") || ($what=="core")){
     $map["USER_EMAIL"]=$dataobj["email"]; // special patch
     $map["LOGIN"] = $dataobj["email"]; 
     $map["PASSWORD"] = $dataobj["password"]; 
     $map["LOGIN_URL"]= $fullfqdn.'#login'; 
     $map["USER_IP"]= $dataobj["ip"];
     $map["USER_IP_DETAILS"]= $dataobj["ipdetails"];
   }

    if (($what=="service"))  {
     $map["SERVICE_NAME"] = $dataobj["name"]; 
     $map["SERVICE_SDESC"] = $dataobj["sdesc"]; 
     $map["SERVICE_ID"] = $dataobj["id"]; 
     // patch the USER_URL value 
     $map["USER_URL"]= $fullfqdn.'#user-'.$dataobj["userid"];
    
  }

   if ($state=="15"){
      $map["PAY_URL"]=$dataobj["paymenturl"];
   }

  //fwrite($debugfile,"-- Var assigned  ---");


  // get the template file name

  // -- generic rules
   $tpl_name=$dest."_".$what."_".$state.".html"; 

  // -- exceptions    
  if (($what=="ad") && ($dest=="USER" || $dest=="OWNER")) $tpl_name="owner_ad_".$state.".html";
  if (($what=="user") && ($dest=="USER" || $dest=="OWNER")) $tpl_name="owner_user_".$state.".html";

  if (($what=="curuser") && ($dest=="USER" || $dest=="OWNER")) $tpl_name="owner_user_".$state.".html";
  if (($what=="curuser") && ($dest=="ADMIN")) $tpl_name="admin_user_".$state.".html";

  if (($what=="service") && ($dest=="USER" || $dest=="OWNER")) $tpl_name="owner_service_".$state.".html";
    
  // cron
  if (EMAIL_TEMPLATE_VERSION!="V2") {
      if (($what=="cron")) $tpl_name="cron.html";
      if (($what=="notif")) $tpl_name="notif.html";
      if (($what=="lost-link")) $tpl_name="lost_password_link.html";
      if (($what=="lost")) $tpl_name="lost_password.html";
      if ($what=="remind") $tpl_name="user_reminder_00.html";
      if (($what=="reactivateaccount")) $tpl_name="reactivate_account.html";
  }

    if (($what=="support") || ($what=="feedback") || ($what=="abuse")|| ($what=="remind") || ($what=="contact") || ($what=="contactuser"))  
    {
      
     if ($what=="abuse"){
        $tpl_name="admin_abuse_00.html"; // for admin
        if ($dest=="USER")  $tpl_name="user_abuse_00.html";
      } else if ($what=="contact"){ // contact between USER and OWNER based on an ad
        if ($dest=="USER")  $tpl_name="user_contact_00.html";
        if ($dest=="OWNER")  $tpl_name="owner_contact_00.html";
      } else if ($what=="contactuser"){ // contact between USER and OWNER based on an ad
        if ($dest=="USER")  $tpl_name="user_contactuser_00.html";
        if ($dest=="OWNER")  $tpl_name="owner_contactuser_00.html";
      } else if ($what=="remind"){ // contact between USER and OWNER based on an ad
        if ($dest=="USER")  $tpl_name="user_remind_00.html"; 
      } else if (($dest=="USER" || $dest=="OWNER"))
        $tpl_name="owner_support_00.html";
        else 
        $tpl_name="admin_support_00.html";
    
      // assign variables
      $map["CONTACT_REASON"]=$supportfeedback_name_translation[$dataobj["contactreason"]];
      $map["CONTACT_TITLE"]=utf8_adapt(stripslashes($dataobj["emailtitle"]));
      $map["CONTACT_DETAILS"]=nl2br(utf8_adapt(stripslashes($dataobj["emaildesc"])));
      $map["CONTACT_ENV"]=utf8_adapt($dataobj["userenv"]);
      $map["CONTACT_EMAILFROM"]=utf8_adapt($dataobj["emailfrom"]);
      $map["CONTACT_FIRSTNAME"]=utf8_adapt($dataobj["firstname"]);
      $map["CONTACT_LASTNAME"]=utf8_adapt($dataobj["lastname"]);
      $map["CONTACT_PHONE"]=utf8_adapt($dataobj["phone"]);
      $map["CONTACT_PROCPNY"]=utf8_adapt($dataobj["procpny"]);
      $map["CONTACT_DATE"]=utf8_adapt($dataobj["emailstamp"]);

    }


  // lowercase all 
  $tpl_name=strtolower($tpl_name); 


  // dump the map for debug 
  $map_dump = print_r($map, true);
  logfile('debug', "{build_message_based_template} : $map_dump"); 

  // get the directory and full fqdn of the templated
  if (EMAIL_TEMPLATE_VERSION=="V2")
   if ($EMAILS_TEMPLATES_DIR) $tpl_dir= $EMAILS_TEMPLATES_DIR.$cust_lang_long.'/';
   else $tpl_dir= 'locale_emails/'.$cust_lang_long.'/';
  else $tpl_dir= 'emails_templates/'.$cust_lang_long.'/';
  $tpl_full_fqdn = $tpl_dir.$tpl_name;

  // log
  logfile('', "{build_message_based_template} :for WHAT=$what, STATE=$state > template FQDN = $tpl_full_fqdn :  DEST = $dest "); 

  if (file_exists($tpl_full_fqdn)) {
    $tpl_content = file_get_contents($tpl_full_fqdn);

    // format the email : 
    // create the final HTML BODY to be sent by email  
    $htmfull_emailtest = $tpl_content;
    
    if (EMAIL_TEMPLATE_VERSION=="V2") {
        $html_title =  get_innert_html_from_str($htmfull_emailtest, 'title');
        $htmfull_emailtest = get_innert_html_from_str($htmfull_emailtest, 'body');
    } else  {
      $htmfull_emailtest = utf8_adapt($tpl_content);
    }

    // check if other elements to add : 
    $inherited_content=  array( 
      array("tag"=>"<!--[ZADS_FOOTER]-->", "url"=>"admin_core_footer.html")
      ,array("tag"=>"<!--[ZADS_HEADER]-->", "url"=>"admin_core_header.html")
    ); 
    foreach ($inherited_content as $key => $inherit) {
      $inh_tag =  $inherit['tag']; 
      $inh_url =  $inherit['url']; 

      if (strpos($tpl_content, $inh_tag) !== false){
        $tlp_inh_fqdn  = $tpl_dir.$inh_url;
        if (file_exists ($tlp_inh_fqdn)) {
          $fc=file_get_contents($tlp_inh_fqdn);
          $fcb = $fc ;  // not in valid HTML format !
          $htmfull_emailtest = str_replace($inh_tag,$fcb, $htmfull_emailtest, $count);
          logfile('', "{build_message_based_template} : detected $inh_tag, adding content of $tlp_inh_fqdn "); 
        } 
      }  
    }

    // image banners
    $inh_tag='[BANNER_EMAIL_1_IMG_URL]'; 
    if (strpos($htmfull_emailtest, $inh_tag) !== false){
      $cache_banners = json_decode(file_get_contents(CACHE_PATH."banners.json"),true);
    if ($cache_banners) 
    {
        $idx=array_find_by_key($cache_banners['datas'], "position", "email_1");
      if ($idx){
        $thiselem=$cache_banners['datas'][$idx];
        $fcb = base64_decode(stripslashes($thiselem['htmlcode'])); 
        $htmfull_emailtest = str_replace('[BANNER_EMAIL_1_IMG_URL]',$fcb, $htmfull_emailtest, $count); 
        $fcb = stripslashes($thiselem['clicktrackingurl']);  
          $htmfull_emailtest = str_replace('[BANNER_EMAIL_1_CLICK_URL]',$fcb, $htmfull_emailtest, $count);  
      }
    }
    } 

    // process the final mapping 
    foreach ($map as $k => $v) {
      $htmfull_emailtest = str_replace("[".$k."]",$v, $htmfull_emailtest, $count);
    }
     
    // convert from UTF8 -> LATAM Format 
    // $htmfull_emailtest = utf8_adapt(stripslashes($htmfull_emailtest));  
    if (EMAIL_TEMPLATE_VERSION=="V2") {
      $out =array();$out['body'] = $htmfull_emailtest; $out['title'] = $html_title ; 
      return $out;
    }
    else return($htmfull_emailtest); 
  } 
  else {
    logfile('NOTICE', "{build_message_based_template} : $tpl_full_fqdn : file does not exist"); 
    return false; // no file content 
  }

}


function array_find_by_key($inAr, $keyname, $valuetofind){
  $out=false;
  if (count($inAr)>0){
    foreach ($inAr as $key1 => $value1) {
      foreach ($value1 as $key2 => $value2) {
        if ($key2==$keyname && $value2==$valuetofind){
          return $key1; 
        }
      }
    }
  }
  return $out; 
}

/**
 * create an HTML message based on a template 
 * @param $tpl_name the name of the HTML template 
 * @param $tpl_name the name of the HTML template 
 * @return mixed The resulting JSON string, or false if the argument was not an array.
 * @author Patrice COHAUT
 */

function build_message_based_template_OLD($what, $state, $theemailrule, $dataobj){

  // existing vocabulory 
  // [SITE_NAME], [SITE_MOTTO], [SITE_CUSTOMER],  [SITE_FQDN]
  // [AD_TITLE] , [AD_ID]
  // [CUR_DATE] , [AD_LEAFLET_URL],
  global $fullfqdn; 
  global $SITE_NAME; 
  global $SITE_MOTTO; 
  global $SITE_CUSTOMER; 
  global $debugfile;
  global $cust_lang_long;
  global $EMAILS_TEMPLATES_ENH; 
  global $EMAILS_TEMPLATES_DIR;
  
  //Z6.2.0
  global $supportfeedback_name_translation; 

  if ($EMAILS_TEMPLATES_ENH) define('EMAIL_TEMPLATE_VERSION', "V2");
  else define('EMAIL_TEMPLATE_VERSION', "V1");

  $stamp2= date( 'Y-m-d H:i:s', time());
  $dest = $theemailrule["to"]; // AMDIN, USER, OWNER 
  $map = array(); //mapping table between input data and reported value 

  // logfile('', "{build_message_based_template} : in the email templating function"); 

  $map["SITE_NAME"]= utf8_decode($SITE_NAME); $map["SITE_MOTTO"]= utf8_decode($SITE_MOTTO); $map["SITE_CUSTOMER"]= utf8_decode($SITE_CUSTOMER); 
  $map["SITE_FQDN"]= $fullfqdn;
  $map["CUR_DATE"]= $stamp2;
  $map["EMAIL_TITLE"]=$theemailrule["title"];
  
  //if (($what=="ad") || ($what=="user")){
  $map["AD_URL"]= $fullfqdn.'#item-'.$dataobj["id"]; 
  $map["AD_TITLE"]= htmlspecialchars(utf8_decode(stripslashes($dataobj["title"])));
  $map["AD_ID"]= $dataobj["id"];
  $map["AD_LEAFLET_URL"]= $fullfqdn.'leaflet.php#item-'.$dataobj["id"];
  $map["USER_FIRSTNAME"]= utf8_decode($dataobj["firstname"]);
  $map["USER_LASTNAME"]= utf8_decode($dataobj["lastname"]);
  $map["USER_EMAIL"]=$dataobj["uemail"];
  $map["USER_URL"]= $fullfqdn.'#user-'.$dataobj["id"];
  $map["MESSAGE"] = nl2br(utf8_decode(stripslashes($dataobj["msg"]))); 


  $map["MYSERVICES_URL"]= $fullfqdn.'#myservices';

  // for debug, display all content 
  // $map["MESSAGE"] .= serialize($dataobj);  


  if (($what=="cron"))  {
    $map["CRONMESSAGE"]=$dataobj; 
  }

   if (($what=="notif"))  {
    $map["NOTIFMESSAGE"]=$dataobj; 
  }

  if (($what=="lost")  ||($what=="reactivateaccount") )  {
     $map["LOGIN"] = $dataobj["email"]; 
     $map["PASSWORD"] = $dataobj["password"]; 
     $map["LOGIN_URL"]= $fullfqdn.'#login';
  }

  if (($what=="lost-link") )  {
     $map["RESET_URL"] = $fullfqdn.'#'.$dataobj["reseturl"]; 
  }
  if ( ($what=="user")){
     $map["USER_EMAIL"]=$dataobj["email"]; // special patch
     $map["LOGIN"] = $dataobj["email"]; 
     $map["PASSWORD"] = $dataobj["password"]; 
     $map["LOGIN_URL"]= $fullfqdn.'#login'; 
   }

    if (($what=="service"))  {
     $map["SERVICE_NAME"] = $dataobj["name"]; 
     $map["SERVICE_SDESC"] = $dataobj["sdesc"]; 
     $map["SERVICE_ID"] = $dataobj["id"]; 
     // patch the USER_URL value 
     $map["USER_URL"]= $fullfqdn.'#user-'.$dataobj["userid"];
    
  }

   if ($state=="15"){
      $map["PAY_URL"]=$dataobj["paymenturl"];
   }

  //fwrite($debugfile,"-- Var assigned  ---");
  
  // get the template file name
  if (($what=="ad") && ($dest=="USER" || $dest=="OWNER")) $tpl_name="owner_ad_".$state.".html";
  if (($what=="ad") && ($dest=="ADMIN")) $tpl_name="admin_ad_".$state.".html";

  if (($what=="user") && ($dest=="USER" || $dest=="OWNER")) $tpl_name="owner_user_".$state.".html";
  if (($what=="user") && ($dest=="ADMIN")) $tpl_name="admin_user_".$state.".html";

  if (($what=="curuser") && ($dest=="USER" || $dest=="OWNER")) $tpl_name="owner_user_".$state.".html";
  if (($what=="curuser") && ($dest=="ADMIN")) $tpl_name="admin_user_".$state.".html";

  if (($what=="service") && ($dest=="USER" || $dest=="OWNER")) $tpl_name="owner_service_".$state.".html";
  if (($what=="service") && ($dest=="ADMIN")) $tpl_name="admin_service_".$state.".html";
  

  // cron
  if (EMAIL_TEMPLATE_VERSION=="V2") {
    if (($what=="cron") && ($dest=="ADMIN_REPORTS")) $tpl_name="admin_reports_cron_".$state.".html"; 
    if (($what=="notif") || ($what=="lost-link")|| ($what=="remind") || ($what=="reactivateaccount")|| ($what=="lost")) $tpl_name=$dest."_".$what."_".$state.".html"; 
  }
  else {
    if (($what=="cron")) $tpl_name="cron.html";
    if (($what=="notif")) $tpl_name="notif.html";
    if (($what=="lost-link")) $tpl_name="lost_password_link.html";
    if (($what=="lost")) $tpl_name="lost_password.html";
    if ($what=="remind") $tpl_name="user_reminder_00.html";
    if (($what=="reactivateaccount")) $tpl_name="reactivate_account.html";
  }
  $tpl_name=strtolower($tpl_name); 


  
  if (($what=="support") || ($what=="feedback") || ($what=="abuse")|| ($what=="remind") || ($what=="contact") || ($what=="contactuser"))  
  {
    
   if ($what=="abuse"){
      $tpl_name="admin_abuse_00.html"; // for admin
      if ($dest=="USER")  $tpl_name="user_abuse_00.html";
    } else if ($what=="contact"){ // contact between USER and OWNER based on an ad
      if ($dest=="USER")  $tpl_name="user_contact_00.html";
      if ($dest=="OWNER")  $tpl_name="owner_contact_00.html";
    } else if ($what=="contactuser"){ // contact between USER and OWNER based on an ad
      if ($dest=="USER")  $tpl_name="user_contactuser_00.html";
      if ($dest=="OWNER")  $tpl_name="owner_contactuser_00.html";
    } else if ($what=="remind"){ // contact between USER and OWNER based on an ad
      if ($dest=="USER")  $tpl_name="user_remind_00.html"; 
    } else if (($dest=="USER" || $dest=="OWNER"))
      $tpl_name="owner_support_00.html";
      else 
      $tpl_name="admin_support_00.html";
  
    // assign variables
    $map["CONTACT_REASON"]=$supportfeedback_name_translation[$dataobj["contactreason"]];
    $map["CONTACT_TITLE"]=utf8_decode(stripslashes($dataobj["emailtitle"]));
    $map["CONTACT_DETAILS"]=nl2br(utf8_decode(stripslashes($dataobj["emaildesc"])));
    $map["CONTACT_ENV"]=utf8_decode($dataobj["userenv"]);
    $map["CONTACT_EMAILFROM"]=utf8_decode($dataobj["emailfrom"]);
    $map["CONTACT_FIRSTNAME"]=utf8_decode($dataobj["firstname"]);
    $map["CONTACT_LASTNAME"]=utf8_decode($dataobj["firstname"]);
    $map["CONTACT_PHONE"]=utf8_decode($dataobj["phone"]);
    $map["CONTACT_PROCPNY"]=utf8_decode($dataobj["procpny"]);
    $map["CONTACT_DATE"]=utf8_decode($dataobj["emailstamp"]);

  }

  // dump the map for debug 
  $map_dump = print_r($map, true);
  logfile('debug', "{build_message_based_template} : $map_dump"); 


  // get the content from the right file (depending on localizationn)
  $main_dir = 'emails_templates/'.$cust_lang_long;
  if (EMAIL_TEMPLATE_VERSION=="V2") {
    if ($EMAILS_TEMPLATES_DIR) $main_dir =  $EMAILS_TEMPLATES_DIR.$cust_lang_long;
    else $main_dir =  'locale_emails/'.$cust_lang_long;
  }
  $tpl_full_fqdn = $main_dir.'/'.$tpl_name;

  // Z6.8.2 - general footer & header 
  $tlp_header_fqdn  = $main_dir.'/header.html';
  $tlp_footer_fqdn  = $main_dir.'/footer.html';

  if (file_exists ($tlp_header_fqdn)) {
    $fc=file_get_contents($tlp_header_fqdn);
    $fct =  get_innert_html_from_str($fc, 'title');
    $fcb = get_innert_html_from_str($fc, 'body');
    $map["HEADER"]=$fcb;
  } else $map["HEADER"]='';

  if (file_exists ($tlp_footer_fqdn)) {
    $fc=file_get_contents($tlp_footer_fqdn);
    $fct =  get_innert_html_from_str($fc, 'title');
    $fcb = get_innert_html_from_str($fc, 'body');
    $map["FOOTER"]=$fcb;
  } else $map["FOOTER"]='';
  // end general footer and header 


  // log
  logfile('', "{build_message_based_template} :for WHAT=$what,  template FQDN = $tpl_full_fqdn :  DEST = $dest "); 

  if (file_exists($tpl_full_fqdn)) {
    $tpl_content = file_get_contents($tpl_full_fqdn);

    // format the email : 
    // create the final HTML BOD to be sent by email  
    $htmfull_emailtest = $tpl_content;
    
    if (EMAIL_TEMPLATE_VERSION=="V2") {
        $html_title =  get_innert_html_from_str($htmfull_emailtest, 'title');
        $htmfull_emailtest = get_innert_html_from_str($htmfull_emailtest, 'body');
    } else  {
      $htmfull_emailtest = utf8_decode($tpl_content);
    }

    foreach ($map as $k => $v) {
      $htmfull_emailtest = str_replace("[".$k."]",$v, $htmfull_emailtest, $count);
    }
     
    // convert from UTF8 -> LATAM Format 
    // $htmfull_emailtest = utf8_decode(stripslashes($htmfull_emailtest));  
    if (EMAIL_TEMPLATE_VERSION=="V2") {
      $out =array();$out['body'] = $htmfull_emailtest; $out['title'] = $html_title ; 
      return $out;
    }
    else return($htmfull_emailtest); 
  } 
  else {
    logfile('NOTICE', "{build_message_based_template} : $tpl_full_fqdn : file does not exist"); 
    return false; // no file content 
  }

}

function get_innert_html_from_str($tpl_content, $tagName){

    // $DOM = new DOMDocument;
    $DOM = new DOMDocument('1.0', 'UTF-8');
    // mandatory to forcethis to understand that this is UTF8 document 
    $tpl_content= '<meta http-equiv="Content-Type" content="text/html; charset=utf-8">'.$tpl_content;
    $DOM->loadHTML($tpl_content);
    $items = $DOM->getElementsByTagName($tagName);
    for ($i = 0; $i < $items->length; $i++){
      $result = get_inner_html($items->item($i)) ;
      return $result; 
    }
}


function get_inner_html( $node ) {
    $innerHTML= '';
    $children = $node->childNodes;
    foreach ($children as $child) {
        $innerHTML .= $child->ownerDocument->saveXML( $child );
    }
    return $innerHTML;
}


function format_invoice_number($what, $id){

  global $INVOICE_NUMBER_FORMAT; 
  global $INVOICE_WANNA_MODE; // special setting for wannanonces. 
  $thisinvnum=""; 

  if ($INVOICE_NUMBER_FORMAT){
    $thisinvnum = $INVOICE_NUMBER_FORMAT;
    $thisinvnum=str_replace('[TIMESTAMP]', date( 'Ymdhis', time()),$thisinvnum);
    
    // patch the what 
    $xwhat=$what; 
    if ($INVOICE_WANNA_MODE) 
      if ($what=="ad")  $xwhat="options"; 
      else if ($what=="service")  $xwhat="pack Pro"; 

    $thisinvnum=str_replace('[WHAT]', $xwhat ,$thisinvnum);
    $thisinvnum=str_replace('[ID]', $id ,$thisinvnum);
    
  } else {
    // default 
    $thisinvnum= date( 'Ymdhis', time()).'-'.$what.'-'.$id; 
  }

  return $thisinvnum; 

}




/**
 * Converts an associative array of arbitrary depth and dimension into JSON representation.
 *
 * NOTE: If you pass in a mixed associative and vector array, it will prefix each numerical
 * key with "key_". For example array("foo", "bar" => "baz") will be translated into
 * {'key_0': 'foo', 'bar': 'baz'} but array("foo", "bar") would be translated into [ 'foo', 'bar' ].
 *
 * @param $array The array to convert.
 * @return mixed The resulting JSON string, or false if the argument was not an array.
 * @author Andy Rusterholz
 */
function array_to_json( $array ){

    if( !is_array( $array ) ){
        return false;
    }

    $associative = count( array_diff( array_keys($array), array_keys( array_keys( $array )) ));
    if( $associative ){

        $construct = array();
        foreach( $array as $key => $value ){

            // We first copy each key/value pair into a staging array,
            // formatting each key and value properly as we go.

            // Format the key:
            if( is_numeric($key) ){
                $key = "key_$key";
            }
            $key = "'".addslashes($key)."'";

            // Format the value:
            if( is_array( $value )){
                $value = array_to_json( $value );
            } else if( !is_numeric( $value ) || is_string( $value ) ){
                $value = "'".addslashes($value)."'";
            }

            // Add to staging array:
            $construct[] = "$key: $value";
        }

        // Then we collapse the staging array into the JSON form:
        $result = "{ " . implode( ", ", $construct ) . " }";

    } else { // If the array is a vector (not associative):

        $construct = array();
        foreach( $array as $value ){

            // Format the value:
            if( is_array( $value )){
                $value = array_to_json( $value );
            } else if( !is_numeric( $value ) || is_string( $value ) ){
                $value = "'".addslashes($value)."'";
            }

            // Add to staging array:
            $construct[] = $value;
        }

        // Then we collapse the staging array into the JSON form:
        $result = "[ " . implode( ", ", $construct ) . " ]";
    }

    return $result;
}

/******************************************************************************
* this function take an input array of strings and check for badwords 
* @param     $inAr : an array of sting to search for 
* @param     $badwords : a string dcontaining the list of badwords in current language
* @return    an array of results containing 
*     success= True (badwods detected) | false = NO badwords detected)
*     badcount =  nbr of badwords detected 
*     badwordsfound =  Array of found badwords 
 ******************************************************************************/
function check_for_badwords($inAr, $badwords=false){
  
  global $ENABLE_BADWORDS_FILTER; // from settings.php 
  global $ENABLE_URL_NOSELF_FILTER; // detect URLs 
  global $cust_badwords;
  global $debug_tmp;

  // immadiate divert if function is not activated 
  if (!$ENABLE_BADWORDS_FILTER) return Array('success' => false );
  
  //if no badwords indicated here, check it from the SETTINGS files
  if (!$badwords) {
    $badwords = $cust_badwords; 
  }

  $success=false; $badcount=0;
  $sanInAr=array(); $sanIn=""; $bwf="";
  $tracex=""; // debug 

   $success=false; 

  // convetr to the same format 
  $badwordsAr = explode('|',$badwords);

  foreach($inAr as $inText){
     // $inText = utf8_decode($inText);
     $sanIn =  $inText;
    foreach($badwordsAr as $bw){
       $bw = trim($bw);
       if ($bw!=''){ // do it only if something displayed
         // if (preg_match($expr = '~(^|[^a-z0-9]?)('.$bw.'?)($|[^a-z0-9])~iU', $inText)){
         if (preg_match($expr = '~(^|[^a-z0-9]?)('.$bw.')($|[^a-z0-9])~iU', $inText)){
          $sanIn = preg_replace($expr,str_repeat("*",strlen($bw)), $sanIn); 
          $bwf .= "|".$bw;  $badcount+=1;
          $success=true; 
        } 
      }
    }
   
    // extend the check to URLs 
    if ($ENABLE_URL_NOSELF_FILTER){
      // $reg_exUrl = "/(http|https|ftp|ftps)\:\/\/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\/\S*)?/";
      $reg_exUrl ='@(http)?(s)?(://)?(([-\w]+\.)+([^\s]+)+[^,.\s])@';
      // logfile("debug","- url checking for :  ".$inText);
      if (preg_match_all($reg_exUrl,$inText,$foundurl)){
         $success=true; 
         $matches = array_unique($foundurl[0]);
         foreach($matches as $match) {
            //$replacement = "<a href=".$match.">".$match."";
            //$text = str_replace(" ".$match." ", " ".$replacement." ", $text);
            logfile("notice","{check_for_badwords}---- url match found !".$match,__LINE__);
            $bwf .= "|".trim($match); // add the dad words to result 
            $sanIn = preg_replace($reg_exUrl,str_repeat("*",strlen($match)), $sanIn); 
         }
       }
    }

    // finally allocate the value
    $sanInAr[] = $sanIn;

  }

  $bwf = substr(trim($bwf), 1 );
  $ret = Array (
          'success' => $success, // set to true when Badwords found ! 
          'bwc'=>$badcount,
          'bwf'=>$bwf, // lits of bad words found in the text (separated | )
          'sanout'=>$sanInAr
          ); 
  if ($debug_tmp==1){ // add debug info into the stream when working local
       $ret["xdebug"]= array(
          'inibadwords'=>$badwordsAr,
          'iniAr'=>$inAr,
          'trace'=> $tracex
        );  
     }

  return $ret; 
}



/******************************************************************************
 * this function secure POST/GET input parameters to prevent Injection 
 * @param     $string : the input 
 * @return    the sanitized input
 ******************************************************************************/
function secure_var($string) {
		// On regarde si le type de string est un nombre entier (int)
		if(ctype_digit($string))
		{
			//$string = intval($string); // was not working with SIRET  ! 
      $string = floatval($string);

		}
		// Pour tous les autres types
		else
		{
		  // if already protected, remove the Slash before applying the protection
      if (get_magic_quotes_gpc()) {
        $string = stripslashes($string);
      }
			$string = mysql_real_escape_string($string);
			$string = addcslashes($string, '%_');
		}
		return $string;
};


/******************************************************************************
 * this function update the files on the server based on the file array as input
 *  
 * @param     $imgArray : the Array containing the file description 
 *                  format  :  {file name} or {filename|filenameoriginal|size}
 * @return    a string containing the concatenation of each Array elements 
 ******************************************************************************/
function imgFileUpdate ($imgArray){
  
  global $target_path; 
  global $dest_path; 
  global $messagef; 
  
      // serialize the Image Names if multple images and move the images to the right folder. 
      // format of imgname can be : 
      // {file name} or {filename|filenameoriginal|size}
      if (
        $imgArray){
        $ix=1;
        foreach ($imgArray as $imgnameValue){
          // check if file already stored or not.   
          $arrImgnameValue = explode('tmp_',$imgnameValue); 
          //if($arrImgnameValue[0]=="tmp") {
          if (count($arrImgnameValue)>1) {
            $destimgnameValue = "file_".$arrImgnameValue[1]; // change the file name to indicate
            $realdestfilename=explode('|',$destimgnameValue); // extract the real file name
            $realdestfilename=$realdestfilename[0];
            
            $realsrcfilename=explode('|',$imgnameValue);$realsrcfilename= $realsrcfilename[0];
            
            // save image to the right location 
            $success = rename($target_path."".$realsrcfilename, $dest_path."".$realdestfilename); // save the main image
            // save thumbnail to the rihgt location
            $success2 = rename($target_path."tn_".$realsrcfilename, $dest_path."tn_".$realdestfilename); // save the thumbnail
            // save thumbnail number 2 (wider size for pinterest type display) to the rihgt location
            $success3 = rename($target_path."tn2_".$realsrcfilename, $dest_path."tn2_".$realdestfilename); // save the thumbnail
            
            $imgnameValue = $destimgnameValue;  // copy this name to save it on SQL
          }
          if ($success) $messagef .= "file storage successfull"; 
          else $messagef .= "error during the file renaming process"; 
          // build the hassh string
          if ($ix==1) $imgname.=$imgnameValue; else $imgname.=";".$imgnameValue;
          $ix+=1;  
        }        
      }
      
      return $imgname ; 
}; 



function checkLdapLogin($username,$userpass){

         $server = "ldap.sxb.bsf.alcatel.fr";
         $port = "389";  
         $basedn = "o=Alcatel";
         $resultout=array(); //store result [0] = code [1]=status text 

         $outCode=0;  
         $strtmp .=  "Connecting to Ldap server ...\n";
         $ds=@ldap_connect($server);
         
          if ($ds == -1){
            $strtmp .=   "Connection to LDAP server impossible \n ";
            $outCode=9999; 
          } else {
          
            //string filter
            $filter="(|(cn=" . $username . "))";
          
            $rs = @ldap_search( $ds, $basedn, $filter);
            $strtmp .= "nbr of found users for $username is  ".@ldap_count_entries($ds,$rs)."\n";

            if ($rs) {
                $result = @ldap_get_entries( $ds, $rs);
                
                if ($result["count"]==1) {
                $strtmp .= "DN=". $result[0]['dn'] ."\n";
                $strtmp .= "Email=". $result[0]['mail'][0] ."\n";
                $strtmp .= "SN=". $result[0]['sn'][0] ."\n";
                
                // make the binding 
                    $bs=@ldap_bind( $ds, $result[0]['dn'], $userpass);
                     if ($bs) {
                        $strtmp .= "Bind result is sucessull = $bs \n" ; 
                    }  else {
                        $strtmp .= "Erreur : ".ldap_error($ds)."\n"; 
                        $outCode=9999;
                        }   
                } else {
                  $strtmp .= "Too much result found for this user : \n"; 
                  $outCode=9999;
                }
             } else {
                $strtmp .= "No result found on Ldap server \n"; 
                $outCode=9997;
             }
          	 // put HERE TO DO lines 
             $strtmp .=  "Closing connection ...\n";
          	 @ldap_close($ds);
          } 
          
        $resultout[0] = $outCode;
        $resultout[1] = $strtmp;
        if ($outCode==0) $resultout[2] = $result[0];
          
      	return $resultout ; 
      	 
}

function generatePassword($length=9, $strength=8) {
	$vowels = 'aeuy';
	$consonants = 'bdghjmnpqrstvz';
	if ($strength & 1) {
		$consonants .= 'BDGHJLMNPQRSTVWXZ';
	}
	if ($strength & 2) {
		$vowels .= "AEUY";
	}
	if ($strength & 4) {
		$consonants .= '23456789';
	}
	if ($strength & 8) {
		$consonants .= '@#$%';
	}
 
	$password = '';
	$alt = time() % 2;
	for ($i = 0; $i < $length; $i++) {
		if ($alt == 1) {
			$password .= $consonants[(rand() % strlen($consonants))];
			$alt = 0;
		} else {
			$password .= $vowels[(rand() % strlen($vowels))];
			$alt = 1;
		}
	}
	return $password;
}; 



function are_dates_samedayoftheweek($date2){ 
  $dw1 = date('w');
  $dw2= date('w', strtotime($date2));
  if ($dw1==$dw2) return true;
  return false; 
}


function check_and_clean_data_per_pricingplan($indata, $what){
  global $general_catalogue;
  global $debugfile; 
  global $debug_tmp; 

  //if ($debug_tmp==1) fwrite($debugfile,"<br> cleaning plan : "); 
  //if ($debug_tmp==1) fwrite($debugfile," for  id= ". $indata['id']); 
  $outdata = $indata; // default bypass

  $planid=  $indata["plan"]; 
  //if ($debug_tmp==1) fwrite($debugfile," with plan = ". $indata['plan']); 

  if ($planid && $planid !=''){

    //if ($debug_tmp==1) fwrite($debugfile," .. in plan = ". $indata['plan']); 
    // get the associaed plan 
    $theplan = $general_catalogue['pricing_plan']['user'][$planid]['details']; 

    foreach ($theplan as $ple) {
      $pleAr = explode("_", $ple['n']);
      $ple_prefix =  $pleAr[0];
      $ple_field = $pleAr[1];
      $ple_val=$ple['val']; 

      if (($ple_prefix=="us") && (!$ple_val)) { 
        if ($outdata[$ple_field] || ($ple_field=="dispemail")){
          if ($ple_field=="dispemail") $outdata['email']='';
          else if ($ple_field=="protype") $toto=1; // do nothing
          else  $outdata[$ple_field]='';        
        }
      } 
    } // end foreach 
  }
  return $outdata; 
}


function check_salesLimits($what2, $action2){
 global $salesRights; 
 global $dbItemsTable;
 $res=true;
 
 $limit = $salesRights[$what2][$action2]; 
 if ($limit!="")
 {
  if ((($what2=="ad") || ($what2=="item")) && ($action2=="create")){
    $sql_sort="";  
    $filter="  WHERE `status` IN ('40') ";
    $queryadfull = "SELECT COUNT(`id`) as `nbads` FROM `$dbItemsTable`" .$filter." ". $sql_sort ; 
    $resultads = mysql_query($queryadfull);
    $row_ads = mysql_fetch_object($resultads); 
    if ((($row_ads->nbads)*1)>($limit*1)) {$res=false;$erroccode="MAX AD";} 
  }
 }
 
  // output the error and content. 
  if ($res) return  $res; // display nothing and continue processing
  else  {
      // prepare the output code 
     $message = "You have exceeded the commercial limits : ".$erroccode;             
     $json = array(
                  'success' => false,
                  'message' => $message,
                  'what' => $what2,
                  'action' => $action2
              );      
      // echo json_encode($json); 
      encode_json_and_send_with_compression($json); 
      exit();       
  }
};

function check_userRights($what2, $action2, $status2, $filter2){
  global $userRights; 
  global $debugfile; 
  global $debug_tmp; 
  global $curuser_is_admin;
  global $curuser_is_owner;
  global $curuser_id; 
  global $curuser_type;
  global $curuser_loclatlng;
  global $serverremoteaddr;
  global $ENABLE_USER_LOGS;
  global $_SESSION; 
  global $curuser_is_superadmin; //Z68 to identify super users in admin
  
  $output=true;
  $getnext=false;
  

  if ($debug_tmp==1){ 
    $m="{check_userRights} : ".$action2." / ".$what2." : ";  
    if ($userRights[$what2][$action2]) $m.="  found :  ". implode('|', $userRights[$what2][$action2]);  
    else $m.="  no restrictions  "; 
    logfile ('', $m,__LINE__); 


  }
  
  if ($userRights[$what2][$action2]!="")
  {
      // -- get back the root of the rule
      $xtype= $userRights[$what2][$action2];
      $xtypeout=0; // default value= no check
      if (is_array($xtype)) {
        $xtype2=$xtype; // save array
        $xtype=0; 
        foreach ($xtype2 as $key => $value) {
          //if ($debug_tmp==1){ fwrite($debugfile,"--> Rule found KEY-PAIR  : ".$key." - ".$value);  fwrite($debugfile,"\n");}
          if (($key=="status") && ($status2!="")) { $xtype=$value; break;  }
          else if (($key=="filter") && ($filter2!="")) {$xtype=$value; break;}  
        }
      }
      $xtypenum= $xtype+0; // convert to num if this is numeric 
      
      if (($xtypenum !="") && ($xtypenum!=0)){
        // -- launch the check 
        //if ($debug_tmp==1){ fwrite($debugfile,"--> One control found for this action  : ".$action2." - ".$what2." ->level = ". $xtype);  fwrite($debugfile,"\n");}
        // check session and verify same level as requested.    
        session_name("ZADSSESID"); 
        if ($_COOKIE["ZADSSESID"] !="") { // detect if a session is set . session_id does not give the result
          session_start();
          $init_session =  $_SESSION; 

          if (isset($_SESSION['user_type'])){
            if (isset($_SESSION['user_id'])) $curuser_id = $_SESSION['user_id'];  
            // double security 
            $xsessionusertype=$_SESSION['user_type']+0; 
            if ($xsessionusertype==9) $curuser_is_admin=true; 

            if (($xtype=="owner") || ($xsessionusertype>=$xtypenum)){
              $msg_extended = "---> Session is OK  : user=".$_SESSION['user']." - usertype=".$_SESSION['user_type']; 
              $output=true;
            }
            else {
              $msg_extended ="---> ERROR - User level not correct ! : user=".$_SESSION['user']." - usertype=".$_SESSION['user_type']; 
              $output=false; 
            }
          }
          else {
            $msg_extended ="---> ERROR - Session is not valid ! : user".$_SESSION['user']." - usertype".$_SESSION['user_type']; 
            $output=false; 
            }
        } else {
          $msg_extended ="---> ERROR - No Session ! : user=".$_SESSION['user']." - usertype=".$_SESSION['user_type'];
          $output=false;  // if no session, this mean user is not connected
        }
      } else {$getnext=true;}
  } else $getnext=true; 
  

  // next processing 
  if ($getnext) {
    //if ($debug_tmp==1){ fwrite($debugfile,"--> no control on this user action : ".$action2." - ".$what2." ");  fwrite($debugfile,"\n");}
    $output=true;  
    // check session to give general info 
    session_name("ZADSSESID"); 
    if ($_COOKIE["ZADSSESID"] !="") { // detect if a session is set . session_id does not give the result
      session_start();
      //if ($debug_tmp==1){ fwrite($debugfile,"--> Cookie detected with id/type/loc =  : ".$_SESSION['user_id']." - ".$_SESSION['user_type']." - ".$_SESSION['user_loclatlng']);  fwrite($debugfile,"\n");}

      // if this is a Logged user   
      if (isset($_SESSION['user_id']))  $curuser_id = $_SESSION['user_id'];  
      if (isset($_SESSION['user_type'])) {
        $curuser_type = $_SESSION['user_type']+0; 
        if ($curuser_type==9) $curuser_is_admin=true;

        // super admin identification
        if ($_SESSION['assocprojects']=="10") $curuser_is_superadmin=true;
      }

      // determine locatin rules =  #1 : user local cookie if set #2 use saved preference
      if (isset($_COOKIE['ZADS_LOCATION'])) {
        $cookietext  =  $_COOKIE['ZADS_LOCATION'];  // set default language
        $cookiecontentAr = Array ();
        $cookiecontentAr = parseStrToArr($cookietext);

        if ($cookiecontentAr['loclatlng']){
            $curuser_loclatlng = $cookiecontentAr['loclatlng']; 
        }
        else {
          if (isset($_SESSION['user_loclatlng']))
            $curuser_loclatlng = $_SESSION['user_loclatlng']; 
        }
      } else {
          if (isset($_SESSION['user_loclatlng']))
            $curuser_loclatlng = $_SESSION['user_loclatlng']; 
      }
      //if ($debug_tmp==1){ fwrite($debugfile,"--> default location set to =  : ".$curuser_loclatlng);  fwrite($debugfile,"\n");}

    } 
  }
  
  // output the error and content. 
  if ($output) return  $output; // display nothing and continue processing
  else  {
      // prepare the output code 
     $message = "This operation is not authorized !";             
     $json = array(
                  'success' => false,
                  'message' => $message,
                  'message_extended' =>$msg_extended,
                  'what' => $what2,
                  'action' => $action2,
                  'is_admin' =>$curuser_is_admin, 
                  'is_superadmin'=>$curuser_is_superadmin,
                  'curuser_id'=>$curuser_id,
                  'curuser_type'=>$curuser_type,
                  'xype' => $xtype,
                  'session_id'=>session_id(),
                  'allsession' =>$_SESSION, 
                  'initsession'=>$init_session 
                  
              );      
      echo json_encode($json); 
      logfile ('error',"{check_userRights} : ".$msg_extended ,__LINE__);
      
    // ----------------- SAVE TO LOG FILE ----------------------------
    if ($ENABLE_USER_LOGS){
       $laction="sec";$lwhat = "user";
       $luserid=$curuser_id;
       $ldesc = $message .':'.$what2.'-'.$action2.'|'. $serverremoteaddr;
       $lseverity = 2; 
       log_event($laction,$lwhat, '', $luserid, $ldesc, $lseverity);
    }
      
    exit();       
  }
}; 


// search into a param key=value&key=value for option and then check for the date 
function has_valid_paidoption($param, $searchedoptions){
  $o=false; $thisstamp = time(); 
  $rdata = parseStrToArr($param); 
  foreach ($rdata as $paidoption => $pvalue) {
    // check for matched string and then check for validity date
    if (strpos($paidoption,$searchedoptions) !== false){
      // found it 
      if ($pvalue >= $thisstamp) return true; 
    }
  }
  return $o ; 
}

// convert an array AR[key]=value into a start : key=value|kay=value, ... 
function parseArrToStr($inAr ,$format){
  $ret=''; 
  if (count($inAr) > 0 ){
    foreach ($inAr as $key => $value){
      $ret .="$key=$value|"; 
    }
    $ret=trim($ret,'|'); // remove the | char 
  } else $ret=""; 
  return $ret;
}

// convert anmulti-dim (2) array AR[key][1]=value into a start : key=value1;value2, ... 
function parse2DimsArrToStr($inAr ,$format){
  $ret='';  $valsub=''; 
  if (count($inAr) > 0 ){
    foreach ($inAr as $key => $value){
      $valsub=''; //Z6.5.4 correction
      if (is_array($value)){
         foreach ($value as $key2 => $value2){
           $valsub .="$value2;";
         }
         $ret .="$key=$valsub|"; 
      }
      else 
      $ret .="$key=$value|"; 
    }
    $ret=trim($ret,'|'); // remove the | char 
  } else $ret=""; 
  return $ret;
}



// convert a json array with {n:'', val:''} into a string value with &  
function json2Str($injson){
  $ret=''; 
  if (count($injson) > 0 ){
    foreach ($injson as  $elem){
      $ret .=$elem['n']."=".$elem['val']."&"; 
    }
    $ret=trim($ret,'&'); // remove the | char 
  } else $ret=""; 
  return $ret;
}


// convert a json array with {n:'', val:''} into a string value with &  
function json2StrWithouFreeText($injson){
  $ret=''; 
  if (count($injson) > 0 ){
    foreach ($injson as  $elem){
      if (strpos($elem['n'],"free_text")=== false)
        $ret .=$elem['n']."=".$elem['val']."&"; 
    }
    $ret=trim($ret,'&'); // remove the | char 
  } else $ret=""; 
  return $ret;
}


function parseStrToArr($instr, $format, $thisvar, $protype){
  
  global $general_catalogue; 
  global $lcur_user ; // local surrent user 
  global $SERVICES_PRO_FREE_OPTIONS_LIST;
  $returnedAr= array(); 
  $orig_instr=$instr; 

  // convert the string in the &name1=value1&name2=value2,... to an array 
  // logfile('debug', "{parseStrToArr} : instr =$instr, format=$format, $thisvar=$thisvar, pprotype=$protype, lcur-user=$lcur-user", __LINE__); 

  foreach(explode("&",$instr) as $elem) {
    $exclude=false;
      if  ($elem !="") {
        $elemAr = explode("=",$elem); 
        if (!$format)
          $returnedAr[$elemAr[0]] =$elemAr[1];  
        else if ($format=="forcedvar"){
          $thisvar[$elemAr[0]] = $elemAr[1];
          //array_push($thisvar,array($elemAr[0] => $elemAr[1])); 
          // $thisvar[$elemAr[0]] = "1430000000";
        }
        else if ($format=="paypalbom"){
          // serarch into the settings :
         
          foreach ($general_catalogue['payoptions']['options'] as  $opt) {
            if ($opt["name"]==$elemAr[0]){
            
              // case of HT/TTC prices
              if  ($lcur_user) {
                $lprice= ($lcur_user['protype']=="pro") ?   1*$opt["price_pro_ht"] : 1*$opt["price"]; 
              } else if ($protype){
                $lprice= ($protype=="pro") ?   1*$opt["price_pro_ht"] : 1*$opt["price"]; 
              } else 
                $lprice= 1*$opt["price"]; 

              if (($lcur_user['protype']=="pro" || $protype=="pro") && in_array($opt["name"], explode('+', $SERVICES_PRO_FREE_OPTIONS_LIST)))
                  $exclude=true;

              if (!$exclude){
               
                $xname=($opt["desc"] =="*" || $opt["desc"] =="" ) ? $opt["name"] : $opt["desc"] ;
                $xdesc = ($opt["desc"] =="*" || $opt["desc"] =="" ) ? $opt["name"] : $opt["desc"] ;
                $returnedAr[]=array(
                    "oi" =>$opt["oi"], 
                    "name"  => $xname, 
                    "desc"  => $xdesc, 
                    "qty" => 1, 
                    "price" =>$lprice,
                    "isrecurrent"=>$opt["isrecurrent"], 
                    "billingperiod"=>$opt["billingperiod"], 
                    "billingfrequency"=>$opt["billingfrequency"]
                  ); 
              }
              break;
            }
          }  
        }
      }
    }
    if ($format=="forcedvar") return $thisvar; 
    else return $returnedAr; 
}; 











/*
 * Get LatLong From Postcode
 *
 * @access  public
 * @param   string $postcode
 * @param   string $country
 * @param   string $gmapApiKey
 * @return  array(statusCode, accuracy, latitude, longitude);
 */
function getLatLongFromPostcode($postcode, $country, $gmapApiKey)
{

    $gmapApiKey=""; // to be completed
    /* remove spaces from postcode */
    $postcode = urlencode(trim($postcode));
 
    /* connect to the google geocode service */
    $file = "http://maps.google.com/maps/geo?q=$postcode,$country&amp;amp;output=csv&amp;amp;key=$gmapApiKey";
 
    $contents = file_get_contents($file);
    return explode(',', $contents);
}

function formatSizeVideo($html, $what){
  global $AD_VIDEO_SIZE_WIDTH; 
  // ad : 200x120 for generic size ZADS  /  300x180 for new size 
  // user : 320x200
  $patternh = "/height=\"[0-9]*\"/";
  $patternw = "/width=\"[0-9]*\"/";
  if ($what=="user"){
    $ret = preg_replace($patternw, 'width="320"', $html);
    $ret = preg_replace($patternh, 'height="190"', $ret);
  } else {
    if ($AD_VIDEO_SIZE_WIDTH) {
      $vid_w=$AD_VIDEO_SIZE_WIDTH ; 
      $vid_h=round((int)$AD_VIDEO_SIZE_WIDTH *0.6);  
      $ret = preg_replace($patternw, 'width="'.$vid_w.'"', $html);
      $ret = preg_replace($patternh, 'height="'.$vid_h.'"', $ret);
    }
    else {
      $ret = preg_replace($patternw, 'width="200"', $html);
      $ret = preg_replace($patternh, 'height="120"', $ret);
    }
  }

  return $ret; 
}

function RSS_header($type){

  global $rss_title; 
  global $rss_link; 
  global $rss_desc; 
  global $rss_site_url; 

  $rss_stamp= date ( "D, d M Y H:i:s" , time());
    

    
    /*
    $rss = "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>"; 
    */
    
    $rss = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"; 
    
    $rss .= "<rss version=\"2.0\" xmlns:atom=\"http://www.w3.org/2005/Atom\" xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\" >";
    $rss .= "<channel>" ;
    $rss .= "<title>".$rss_title." - ".$type."</title>" ;
    $rss .= "<link>".$rss_link.$type."</link>" ;
    $rss .= "<description>".$rss_desc."</description>" ;
    
    $rss .= "<language>fr</language>";
    $rss .= "<copyright>Copyright 2010-2011 ZADS.FR</copyright>";
    $rss .= "<pubDate>".$rss_stamp." GMT</pubDate>";
    $rss .= "<lastBuildDate>".$rss_stamp." GMT</lastBuildDate>";
    $rss .= "<ttl>3600</ttl>"; // in minutes 
    $rss .= "<image>";
    $rss .= "<title />";
    $rss .= "<url>".$rss_site_url."home_img/zadslogo80_3.png</url>";
    $rss .= "<link>http://www.zads.fr</link>";
    $rss .= "</image>";
    
    return $rss;
}; 


function db_list_services_w_paypalinfo($curuserid,$thisserviceid) {
  global $dbServicesTable;
  global $general_catalogue;


  $out = array();
  $this_user_id = $curuserid; 

  $where ='';
  if ($thisserviceid)  $where .=  " AND `id` = '$thisserviceid' " ; 

  $querymyservices = "SELECT *  FROM `$dbServicesTable` WHERE `userid` = '".$this_user_id."' $where"; 
  $resultmyservices = mysql_query($querymyservices);
  if ($resultmyservices) {
    $rowz = mysql_fetch_array($resultmyservices); 
    $out = $rowz; // save all

    // add extra infos
    $out['result']=true;

    // extra info for paypal
     $paypal_checkout_details= Array ();
     $theprice =$rowz['price'];
     $planid = $rowz['sid']; 
     $priceid=$rowz['priceid'];
      if ((float)$theprice > 0 ){
        // get back the catalogue element 
        $oi= json_find_elem_by_name($general_catalogue['payoptions']['options'],$planid); 
        //Z6.1.3 - change OI name 
        $scd =  $general_catalogue['pricing_plan']['user'][$oi["name"]]; 
        $oiname=  $scd['name'].'_'.$scd['us_protyp'].'_'.$priceid;
        $paypal_checkout_details["bom"][] = array("oi" =>$oi["oi"], "name"  => $oiname, "qty" => 1, "price" => $theprice,"isrecurrent"=>$oi["isrecurrent"], "billingperiod"=>$oi["billingperiod"],"billingfrequency"=>$oi["billingfrequency"] ); 

        $out['p_bom']=$paypal_checkout_details;         
      } 
  } else { logfile('error', mysql_error()); return false;}


  // send the results
  return $out; 
}


function db_list_ads_nbr($this_user_id){
  global $dbItemsTable;
  $totnbads_thisuser=0; 

  // -- get the total number of PUBLISHED adds from this user  !
  $querynbads = "SELECT `$dbItemsTable`.`id`  
                    FROM `$dbItemsTable` 
                    WHERE  `$dbItemsTable`.`userid` = '".$this_user_id."'
                            AND `$dbItemsTable`.`status` IN ( '15', '20', '40','45','46') 
                  "; 
  $resultnbads = mysql_query($querynbads);
  if ($resultnbads) {
    $thistotnbrow = mysql_num_rows($resultnbads);
    if ($thistotnbrow==0) $adlist_thisuser=";";
    else {
      $adlist_thisuser=";";
      while ($rowy = mysql_fetch_object($resultnbads)) { 
        $adlist_thisuser .=  $rowy->id .";";
        $totnbads_thisuser+=1;
      }
    }
  } else { logfile('error', mysql_error()); return false;}

  return $totnbads_thisuser; 
}



function db_list_services($curuserid, $extra_where,$thisserviceid, $more) {
  global $dbServicesTable; global $dbUsersTable ; 
  $out = array();
  $this_user_id = $curuserid; 

  $where ='';
  if ($extra_where=="activeorexpiredtrial") $where =  " AND `$dbServicesTable`.`sid` = 'trial' AND `$dbServicesTable`.`status` IN ('40','45','46','80') " ; 
  if ($extra_where=="servicesonly") $where =  " AND `$dbServicesTable`.`type` != 'trial' AND `$dbServicesTable`.`type` != 'base' " ; 
  if ($thisserviceid)  $where .=  " AND `$dbServicesTable`.`id` = '$thisserviceid' " ; 
  $sql_sort=" ORDER BY `$dbServicesTable`.`startdate` ";

  // add user details if more options required 
  if ($more)   
    $querymyservices = "SELECT `$dbServicesTable`.*, u.`firstname`, u.`lastname`, u.`email` AS 'uemail' FROM `$dbServicesTable`  LEFT JOIN `$dbUsersTable` u ON ( u.`id` = `$dbServicesTable`.`userid` )  WHERE `$dbServicesTable`.`userid` = '".$this_user_id."' $where $sql_sort"; 
  else   
    $querymyservices = "SELECT *  FROM `$dbServicesTable` WHERE `$dbServicesTable`.`userid` = '".$this_user_id."' $where $sql_sort"; 

  $resultmyservices = mysql_query($querymyservices);
  if ($resultmyservices) {
    while ($rowz = mysql_fetch_assoc($resultmyservices)) { 
      $out[] = $rowz;
    }
  } else { logfile('error', '{db_list_services} : SQL ERROR'.mysql_error()); return false;}
  // send the results
  return $out; 
}

function db_setexpiredtrial_services($thisid, $status="80", $priority="confirmed"){
  global $dbServicesTable; $dbThisTable = $dbServicesTable;
  // use the field PRIORITY to store "confirmed" vs "non confirmed" account
   $query2 = "UPDATE `".$dbThisTable."` SET   `status`='".$status."', `priority`='".$priority."'   WHERE ((`id` = '".$thisid."')) ";
   $result2 = mysql_query($query2);
   logfile('','{db_setexpiredtrial_services} query2 = '.$query2);
   if ($result2) return true;
   else { logfile('error', '{db_setexpiredtrial_services} SQL ERROR : '. mysql_error());}
}


function db_update_field_user($fieldname, $fieldvalue, $thisid){
  global $dbUsersTable;$dbThisTable = $dbUsersTable;
   $query2 = "UPDATE `".$dbThisTable."` SET `".$fieldname."`='".$fieldvalue."'WHERE ((`id` = '".$thisid."')) ";
   $result2 = mysql_query($query2);
   logfile('','query2 = '.$query2);
   if ($result2) return true;
   else { logfile('error', mysql_error());}
}


function db_gen_update_field($dbtable,$fieldname, $fieldvalue, $thisid){
  $dbThisTable = $dbtable;
   $query = "UPDATE `".$dbThisTable."` SET `".$fieldname."`='".$fieldvalue."'WHERE ((`id` = '".$thisid."')) ";
   $result = mysql_query($query);
   logfile('','Generic Update field function = '.$query);
   if ($result) return true;
   else { logfile('error', mysql_error()); return false;}
}




function db_update_services($field,$iterator, $userid,$catid){
  global $dbServicesTable;
  global $debug_tmp;

  $out = array(); $out['result']=false; // set to default = false 
  $dbThisTable = $dbServicesTable; 

  $limit = "";
  $sql_sort=" ORDER BY `firstpublisheddate` ASC ";
  $filter = " WHERE `userid` = '$userid' AND `status` IN ('40','45','46') ";
  $query = "SELECT *  FROM `$dbThisTable`" .$filter." ". $sql_sort .  $limit ; 
  $result = mysql_query($query);
  logfile('','{db_update_services} : get list of ACTIVE SERVICES for this user : '.$userid);

  // get details on user 
  // get user details
  $lcur_user = get_user_details($userid); 
  
  if (!$result) {
    $sqlerror =  "" . mysql_error(). "--".$query;
    logfile('error','{db_update_services} : SQL ERROR '.$sqlerror);
  }
  else {
    $canUpdate=false; 
    while ( $row = mysql_fetch_object ( $result ) ) {
      // convert options to array 
      $optsAr = parseStrToArr($row->options);
      logfile('','{db_update_services} : loop though packs  : name='.$row->name.' / xtype='.$row->type.'/ remains token = '.$row->remain);
      if  ($optsAr['ca_restriction'] == $catid || ($row->type=="trial") || ($lcur_user['protype']!="pro"  && $row->type=="base") ) {
        // we found it ! 
        $hasRemainToken=false; 
        if (intval($row->remain) > 1){
          $hasRemainToken=true;
          $new_status =  $row->status; // keep the status 
          $new_remain = intval($row->remain)-1;  

        }
        else if (intval($row->remain) == 1){
          $hasRemainToken=true;
          $new_status =  "80"; // set status to expired as this will move to 0 ! 
          $new_remain = intval($row->remain)-1;  
        } else {
          // remain is zero  ! 
          // do not accept creation! 
          $toto=1;
        }

        if ($hasRemainToken) {
          $canUpdate=true; 
          logfile('','{db_update_services} : found remaining token on service pack : '.$row->name);
          break;  
        }
        // make the query to update the element
       
        break; 
      } 
    } // end while
    // update the DB 
    if ($canUpdate){
       $query2 = "UPDATE `".$dbThisTable."` SET   
              `status`='".$new_status."',
              `remain`='".$new_remain."'
              WHERE ((`id` = '".$row->id."')) ";
        $result2 = mysql_query($query2);
        if ($result2) { 
          $out['id']=$row->id; $out['result']=true; $out['newstatus']=$new_status; 
          logfile('','{db_update_services} UPDATE SQL QUERY = '.$query2);
        } 
        else {
          $sqlerror =  "" . mysql_error(). "--".$query2;
          logfile('error','{db_update_services} : SQL ERROR '.$sqlerror);
        }
    } // end can update
    else {
     logfile('notice','{db_update_services} : NO TOKENS or NO TOCKENS left on active SERVICES');
     $out['result']=true; // said OK but no token changed ! 
   }
  }

  $out['hasRemainToken']=$hasRemainToken; // save if to be used for error messages 

  $out['cur_user']=$lcur_user; 

  // add elements if debug 
  if ($debug_tmp==1){ // add debug info into the stream when working local
    $out["xdebug"]= array(
        'querydbservices'=>$query,
        'querydbupdate'=>$query2,
        'sqlerror'=>$sqlerror
      );  
  }

  // send the results
  return $out; 

}; 

// $r=db_services_action('create', $ad_id, $cur_plan); // add the service
function db_services_action($action, $userid, $planid, $priceid, $usertype){
  global $dbServicesTable; 
  global $stamp; 
  global $general_catalogue; 
  global $debug_tmp;
  global $ALL_PRICE_FREEOFCHARGE;

  if (!$usertype) $usertype="par"; // default is particulier
  $planid = stripslashes($planid); 

  $out = array(); $out['result']=false; // set to default = false 
  $dbThisTable = $dbServicesTable; 
  $sqlerror =''; 
  $pl_options='';$pl_remain='9999'; 

  logfile('debug',"{db_services_action} - action=$action /  plan=$planid  / priceid=$priceid" ); 

  // get back elements from catalogue 
  $res= json_find_elem_by_id($general_catalogue['pricing_plan']['user'],$planid ); 
  if ($res){
    if ($action=="create"){
      // set the DURATION of the service 
      if ($res['duration']) {
        $endstamp = date( 'Y-m-d H:i:s',  time() + ($res['duration']*24*60*60) );
      } else $endstamp='';

      $pl_name= $res['name']; 
      $pl_id= $res['id']; 
      $pl_sdesc= addslashes($res['desc']); // secure it 
      $pl_ldesc= ''; // not used yet 
      $pl_type=$res['xtype'];

      // changed 24/10/2014 to remove free text issues
      $pl_options = json2StrWithouFreeText($res['details']);  

      // add main options on v2 packs
      if ($res['type']=="v2" &&  $priceid){
        // special patch for the case where we have only one price ! 
        if (count($res['price'])==1) $priceobj = $res['price'][0]; 
        else  $priceobj =  json_find_elem_by_n($res['price'],$priceid); 
        if ($priceobj) $pl_options.="&ad_nb=".$priceobj['ad_nb'];
        if ($res['ca_restriction']) $pl_options.="&ca_restriction=".$res['ca_restriction'];
        $pl_remain= $priceobj['ad_nb'];
      }

      // check for price value and if <> 0 then force to status 15 and createt OI to be purchased on PAYPAL 
      $theprice = ($usertype=="pro") ?  $priceobj['ht'] : $priceobj['ttc'] ;
      $price_vat=($usertype=="pro") ?  'ht' :'ttc' ;
      // set price formt to be with decimal . and not commas 
      $theprice = str_replace(',', '.', $theprice);
      $paypal_checkout_details= Array ();

      //Z6.7 added free plan for all ...
      if ($ALL_PRICE_FREEOFCHARGE) $theprice=0; 

      if ((float)$theprice > 0 ) {
        // get back the catalogue element 
        $oi= json_find_elem_by_name($general_catalogue['payoptions']['options'],$planid ); 
         //Z6.1.3 - change OI name 
        $scd =  $general_catalogue['pricing_plan']['user'][$oi["name"]]; 
        $oiname=  $scd['name'].'_'.$scd['us_protyp'].'_'.$priceid;
        $paypal_checkout_details["bom"][] = array("oi" =>$oi["oi"], "name"  => $oiname, "qty" => 1, "price" => $theprice, "isrecurrent"=>$priceobj["isrecurrent"], "billingperiod"=>$priceobj["billingperiod"],"billingfrequency"=>$priceobj["billingfrequency"]);  

        $thisstatus='15';
        $pl_paidoptions='priceid='.$priceid.'&amount='.$theprice;
        logfile('debug',"{db_services_action} - service price is not free ad  = ".$pl_paidoptions ); 

      } else {
        $thisstatus='40';
        logfile('debug',"{db_services_action} - service price is FREE OF CHARGE "); 

      }

      $query = "INSERT INTO `".$dbThisTable."` 
          ( `moddate`, `createdate`, `firstpublisheddate`, `startdate`, `enddate`,`status`, `name`, `sid`, `sdesc`, `ldesc`, `type`, `priority`, `userid`, `paymentdate`, `transactionid`, `paymentstatus`, `price`, `priceid`,`pricevat`,`options`, `remain`, `paidoptions` ) ";
      $query .= "VALUES ('$stamp', '$stamp','$stamp','$stamp', '$endstamp', '$thisstatus','$pl_name','$pl_id','$pl_sdesc','$pl_ldesc','$pl_type','','$userid','','','','$theprice','$priceid','$price_vat','$pl_options','$pl_remain','$pl_paidoptions');";       

    }

    $result = mysql_query($query);
    if ($result) {
      $out['result']=true;
      $out['status']=$thisstatus;
      $out['p_bom']=$paypal_checkout_details;
      if ($action == "create") 
        $out['id'] = mysql_insert_id(); // get last inserted element
    } else {
      $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
      logfile('error',$sqlerror ); 
    }
  } else logfile('error',"create service , plan $planid not found" ); 

  // add elements if debug 
 if ($debug_tmp==1){ // add debug info into the stream when working local
  $out["xdebug"]= array(
      'querydbservices'=>$query,
      'sqlerror'=>$sqlerror
    );  
  }

  // send the results
  return $out; 

}


/**-----------------------------------------------------------------------------
* this function delet all files, users and ads  
* @return true when a notification detected or false otherwise 
*-----------------------------------------------------------------------------*/
function db_deleteall($what, $typeoffield, $id){
  global $dbItemsTable ; 
  global $dbUsersTable;

  if ($what=="ad" && $typeoffield=="userid"){
    $dbThisTable = $dbItemsTable; 
    // delete all ads belinging to agiven user id 
    $filter="WHERE `$dbThisTable`.`id`='".$id."'";
    $query = "SELECT `$dbThisTable`.id FROM `$dbThisTable` ".$filter."  " ; 
    $result = @mysql_query($query);   
    logfile('notice', "- db_deleteall  ");      
    $cntx=0;
    if ($result) {
      while ($row = mysql_fetch_object($result)) { 
        delete_files("ad", $row->id);
        sql_delete_item("ad", $row->id);
      }
    } 
    else logfile('error', "-".mysql_error());
  }

  if ($what=="user" && $typeoffield=="id"){
     delete_files("user", $id);
     sql_delete_item("user", $id); // delete all from an item incuding logs and associated pictures
  }
  return true ; 

}



/**-----------------------------------------------------------------------------
* this function check for a given condition expressed in filed value and if confition is met, change to given state and notify the owver 
* @param ID  : ID of the service
* @param ID  : ID of the service
* @return true when a notification detected or false otherwise 
*-----------------------------------------------------------------------------*/

function check_and_notify_services($tcondition, $tstamp, $en_savelog, $en_sendemail){
  global $dbServicesTable;  

  $dbThisTable = $dbServicesTable;
  $out=''; 
  $now= date( 'Y-m-d H:i:s', time());

  if ($tcondition=="trial-willexpire"){
      $filter ="  WHERE  `$dbThisTable`.`status` IN ('40') "; 
      $filter .= " AND `$dbThisTable`.`type` = 'trial' ";
      $filter .= " AND `$dbThisTable`.`enddate` < '".$tstamp."'";
      $filter .= " AND `$dbThisTable`.`enddate` != 0 ";
      $action="update"; 
      $tnextstate="45";
  }

  if ($tcondition=="willexpire"){
      $filter ="  WHERE  `$dbThisTable`.`status` IN ('40') "; 
      $filter .= " AND `$dbThisTable`.`enddate` < '".$tstamp."'";
      $filter .= " AND `$dbThisTable`.`enddate` != 0 ";
      $action="update"; 
      $tnextstate="45";
  }
  if ($tcondition=="expired"){
      $filter ="  WHERE  `$dbThisTable`.`status` IN ('45') "; 
      $filter .= " AND `$dbThisTable`.`enddate` < '".$tstamp."'";
      $filter .= " AND `$dbThisTable`.`enddate` != 0 ";
      $action="update";
      $tnextstate="80";
  }

   if ($tcondition=="expiredtodelete"){
      $filter ="  WHERE  `$dbThisTable`.`status` IN ('80') "; 
      $filter .= " AND `$dbThisTable`.`enddate` < '".$tstamp."'";
      $filter .= " AND `$dbThisTable`.`type` != 'trial' ";
      $filter .= " AND `$dbThisTable`.`enddate` != 0 ";
      $action="delete";
      $tnextstate="";
  }


  if ($tcondition=="expiredtodelete_trialnotconfirmed"){
      $filter ="  WHERE  `$dbThisTable`.`status` IN ('80') "; 
      $filter .= " AND `$dbThisTable`.`enddate` < '".$tstamp."'";
      $filter .= " AND `$dbThisTable`.`type` = 'trial' ";
      $filter .= " AND `$dbThisTable`.`priority` = '' ";
      $filter .= " AND `$dbThisTable`.`enddate` != 0 ";
      $action="deepdelete";
      $tnextstate="";
  }

  if ($tcondition=="garbagecollection"){
      $filter ="  WHERE  `$dbThisTable`.`status` IN ('10','15','00') "; 
      $filter .= " AND `$dbThisTable`.`enddate` < '".$tstamp."'";
      $filter .= " AND `$dbThisTable`.`enddate` != 0 ";
      $action="delete";
      $tnextstate="";
  }

  $sql_sort="";  
  $querytop = "SELECT `$dbThisTable`.* FROM `$dbThisTable` ".$filter."  ". $sql_sort ; 
  $resulttop = @mysql_query($querytop);   
  logfile('notice', "- batch and notif | filter= $tcondition");      
  $cntx=0;
  if ($resulttop){
    while ($row = mysql_fetch_object($resulttop)) { 
      // take each one and change the status and notify that to user
      if ($action=="update"){
        $query = "UPDATE `".$dbThisTable."` SET   
            `moddate` = '".$now."',
            `status`='".$tnextstate."'
            WHERE ((`id` = '".$row->id."')) ";
      }

      if ($action=="delete"){
        $query = "DELETE FROM `".$dbThisTable."` WHERE ((`id` = '".$row->id."')) ";
      }


      if ($action=="deepdelete"){
        $query = "DELETE FROM `".$dbThisTable."` WHERE ((`id` = '".$row->id."')) ";

        db_deleteall('ad', 'userid',  $row->userid); 
        db_deleteall('user', 'id',  $row->userid); 

      }

      logfile('notice', '-- batch and notif | action | query = '.$query); 
      $result = @mysql_query($query); 
      if ($result) {   
        $cntx+=1;
      
        // ----------------- SAVE TO LOG FILE ----------------------------
        if ($en_savelog  && $result && ($ENABLE_ELEM_LOGS)){
          $laction="update";$lwhat = "user";$lstatus = $tnextstate; $luserid=0; // 0 = to say it's a robot ! 
          log_event($laction,$lwhat, $row->id, $luserid, $lstatus, 0);
        }

        // notifiy user by email    
        if ($en_sendemail) {
            notify_service_state_change($row->id,$tnextstate);
        }
      } else logfile('error', mysql_error());
          
    } // end while 
  } else logfile('error', mysql_error());
  
  // save for debug
  if ($cntx>0) $out .= '<br>'._("SERVICES NOTIFICATION ").$tcondition." = ".$cntx;  // log this and report it.
    //$outtext .= '<br>'.$queryUserwillexpire;

  return $out; 

}


/**-----------------------------------------------------------------------------
* this function trigger an email notification on services state changes
* @param ID  : ID of the service
* @param ID  : ID of the service
* @return true when a notification detected or false otherwise 
*-----------------------------------------------------------------------------*/

function notify_service_state_change($id, $newstate){
  global $dbServicesTable; 
  global $dbUsersTable;
  global $emailRoutingTable;
  global $SERVICES_NOTIFY_EN;

  $dbThisTable2 = $dbServicesTable;

  $filterx="WHERE `$dbThisTable2`.`id`='".$id."'";
  $queryx = "SELECT `$dbThisTable2`.*, `$dbUsersTable`.`firstname`, `$dbUsersTable`.`lastname`, `$dbUsersTable`.`email` AS `uemail`  FROM `$dbThisTable2` LEFT OUTER JOIN `$dbUsersTable` ON `$dbThisTable2`.`userid`= `$dbUsersTable`.`id`  ".$filterx; 
  $resultx = mysql_query($queryx);
  logfile('', '{notify_service_state_change} : pre-query to get info for EMAILs content : ');
  if ($resultx) {
    $rowx = mysql_fetch_array($resultx);
    $user_email =  $rowx['uemail'];

    if ($SERVICES_NOTIFY_EN && ($rowx['status']=="80" || $rowx['status']=="45"))
      mySendEmail($emailRoutingTable, "service", $rowx['status'], $rowx, $user_email); 
    return true ; 
  } else  logfile('error',  '{notify_service_state_change} : SQL ERROR  = '.mysql_error());
  return false ; 
}


/**-----------------------------------------------------------------------------
* Parses a user agent string into its important parts
* 
* @param string $u_agent
* @return array an array with browser, version and platform keys
*-----------------------------------------------------------------------------*/
function UserAgentParser( $u_agent ) { 

    $data = array();

    //# ^.+?(?<platform>Android|iPhone|iPad|Windows|Macintosh|Windows Phone OS)(?: NT)*(?: [0-9.]+)*(;|\))
    if (preg_match('/^.+?(?P<platform>BlackBerry|Android|iPhone|iPad|Windows|Macintosh|Windows Phone OS)(?: NT)*(?: [0-9.]+)*(;|\))/im', $u_agent, $regs)) {
        $data['platform'] = $regs['platform'];
    } else {
        $result = "";
    }

    //# (?<browser>Camino|Kindle|Firefox|Safari|MSIE|AppleWebKit|Chrome|IEMobile|Opera)(?:[/ ])(?<version>[0-9.]+)
    preg_match_all('%(?P<browser>Camino|Kindle|Firefox|Safari|MSIE|AppleWebKit|Chrome|IEMobile|Opera)(?:[/ ])(?P<version>[0-9.]+)%im', $u_agent, $result, PREG_PATTERN_ORDER);

    if( $result['browser'][0] == 'AppleWebKit' ) {
        if( ( $data['platform'] == 'Android' && !($key = 0) ) || $key = array_search( 'Chrome', $result['browser'] ) ) {
            $data['browser'] = 'Chrome';
        }elseif( $key = array_search( 'Kindle', $result['browser'] ) ) {
            $data['browser'] = 'Kindle';
        }elseif( $key = array_search( 'Safari', $result['browser'] ) ) {
            $data['browser'] = 'Safari';
        }else{
            $key = 0;
            $data['browser'] = 'webkit';
        }
        $data['version'] = $result['version'][$key];
    }elseif( $key = array_search( 'Opera', $result['browser'] ) ) {
        $data['browser'] = $result['browser'][$key];
        $data['version'] = $result['version'][$key];
    }elseif( $result['browser'][0] == 'MSIE' ){
        if( $key = array_search( 'IEMobile', $result['browser'] ) ) {
            $data['browser'] = 'IEMobile';
        }else{
            $data['browser'] = 'MSIE';
            $key = 0;
        }
        $data['version'] = $result['version'][$key];
    }else{
        $data['browser'] = $result['browser'][0];
        $data['version'] = $result['version'][0];
    }

    if( $data['browser'] == 'Kindle' ) {
        $data['platform'] = 'Kindle';
    }

    return $data;
}


function  get_IP_details($ip) {
    require_once ("inc/generic_API_client.php");
    $r=array(); 
    if(!filter_var($ip, FILTER_VALIDATE_IP)) {
        $r['message']= "Not a valid IP address!";
        $r['success']=false; 
    } else
    {
      // get IP address details 
      $url = "http://ipinfo.io/$ip" ; 
      $r= simple_rest_client($url, 'GET');

      if ($r['success']){
        $rstr=''; 
        foreach ( $r['response'] as $key => $value){
          $rstr .= "$key : $value \n<br>  " ;
        }
        $r['serialized'] = $rstr ;
      } else $r['serialized'] = "" ;
    } 
    return $r;
}


// social login - format user function 
function  social_formatUser($me, $network) {
  
  if ($network=="facebook"){
    if($me['id']){
    $me['thumbnail'] = $me['picture'] = 'http://graph.facebook.com/'.$me['id'].'/picture';
    }
  }

  if ($network=="linkedin"){
    if($me['id']){
      $me['thumbnail'] = $me['picture'] = $me['pictureUrl'];
      $me['first_name'] = $me['firstName']; 
      $me['last_name']=$me['lastName']; 
      $me['email']=$me['emailAddress'];
      $me['name']=$me['username']=$me['formattedName'];
    }
  }

  if ($network=="twitter"){
    if($me['id']){
      $me['thumbnail'] = $me['picture'] = $me['profile_image_url'];
      $m=explode(" ", $me['name']); 
      $me['first_name'] = $m[0]; 
      $me['last_name']=$m[1]; 
      $me['email']=''; // set to nothing to keep the email address for open for modifications
      $me['name']=$me['screen_name']; 
    }
  }





  return $me;
}


/**
* This function convert a text tring into an image file 
* @param string $text_in =  the text to convert 
* @param string $save =  the url where to save the file. if NULL, the image will be displayed directly  
* @param string $transparentbg =  boolean to indicate if we whant a transparent cbackground color or white color 
* @return nothing if save is NULL otherwise an Array with result and saved URL
*/
  function text_2_image($text_in, $save=null, $transparentbg=null, $font_size=null){

    // some variables to set
    if ($font_size) $font=$font_size;
    else $font  = 4;
    
    $width  = ImageFontWidth($font) * strlen($text_in);
    $height = ImageFontHeight($font);
    $r_error=''; 

    // get outputextension
    $url_pieces=explode('.',$save);
    $ext = $url_pieces[count($url_pieces)-1]; 
    $ext =  strtolower($ext); 

    // lets begin by creating an image
    $im = @imagecreatetruecolor($width,$height)
    or $r_error.="text-2-image : impossible to create true color image with $text_in";

    if ($transparentbg) {
      // add the transparent background
      imagealphablending($im, false); 
      imagesavealpha($img, true);
      $trans_colour = imagecolorallocatealpha($img, 0, 0, 0, 127);
      imagecolortransparent($im, $trans_colour); // VERY IMPORTANT !!!! 
      imagefill($img, 0, 0, $trans_colour);

      $ext='png' ;// force extension to be png 
      $url_pieces[count($url_pieces)-1]=$ext;
      $save = implode('.', $url_pieces); 

      $text_color = imagecolorallocate($im, 1, 1, 1); // not totaly black otherwise is indide transperenttest ! 

    } else {
      $white_background = imagecolorallocate($im, 255, 255, 255);
      imagefill($im, 0, 0, $white_background);

      //black text
      $text_color = imagecolorallocate($im, 0, 0, 0);
    }

    $r_imgstring = imagestring($im, $font, 0, 0,  $text_in, $text_color);

    
    // save it or send back directly the result 
    if ($save){
      if ($ext=="png") imagepng($im,$save);
      if ($ext=="jpg" || !$ext) imagejpeg($im,$save); 

         return array(
            'r_error'=>$r_error, 
            'savedurl'=>$save
          );
     } else {
        // header ("Content-type: image/png");
        // imagepng($im);

        // send this to a data file for displaying it 
        ob_start();
        imagepng($im);
        return  ob_get_clean();
     }

    }



function getTimeDifferenceToNowString($timeToCompare) {

        // get current time
        $currentTime = new Date();
        $currentTimeInSeconds = strtotime($currentTime);
        $timeToCompareInSeconds = strtotime($timeToCompare);

        // get delta between $time and $currentTime
        $delta = $currentTimeInSeconds - $timeToCompareInSeconds;

        // if delta is more than 7 days print the date
        if ($delta > 60 * 60 * 24 *7 ) {
            return $timeToCompare;
        }   

        // if delta is more than 24 hours print in days
        else if ($delta > 60 * 60 *24) {
            $days = $delta / (60*60 *24);
            return $days . _(" days ago");
        }

        // if delta is more than 60 minutes, print in hours
        else if ($delta > 60 * 60){
            $hours = $delta / (60*60);
            return $hours . _(" hours ago");
        }

        // if delta is more than 60 seconds print in minutes
        else if ($delta > 60) {
            $minutes = $delta / 60;
            return $minutes . _(" minutes ago");
        }

        // actually for now: if it is less or equal to 60 seconds, just say it is a minute
        return _("one minute ago");

    }


/// function to generate random number ///////////////
function random_generator($digits){
    srand ((double) microtime() * 10000000);
    //Array of alphabets
    $Alpha = array ("A", "B", "C", "D", "E","F","G","H","I","J","K","L","M","N","O","P","Q",
    "R","S","T","U","V","W","X","Y","Z");

    $random_generator="";// Initialize the string to store random numbers
    for($i=1;$i<$digits+1;$i++){ // Loop the number of times of required digits

    if(rand(1,2) == 1){// to decide the digit should be numeric or alphabet
      // Add one random alphabet 
      $rand_index = array_rand($Alpha);
      $random_generator .=$Alpha[$rand_index]; // One char is added
    }else{
      // Add one numeric digit between 1 and 10
      $random_generator .=rand(1,10); // one number is added
    } // end of if else

    } // end of for loop 

    return $random_generator;
} // end of function


// if(!function_exists("reformatDate")) 
// {
  // reformat a date in "string format" from one format to another
  // typical use is to convert from European format to US / SQL format
  function reformatDate($date, $from_format = 'd/m/Y', $to_format = 'Y-m-d') 
  {
    if ($date=='' || $date=="0000-00-00") return ''; // protection against Bug of PHP when default value is 0000-00-00 
    // remove time if exists 
    $date = explode(' ', $date)[0]; 
    $date_aux = date_create_from_format($from_format, $date);
    if ($date_aux===false) logfile('error', "{reformatDate} date formating error with input = $date"); 
    $date_out = date_format($date_aux,$to_format);
    return $date_out ; 
  }
// }


  function refreshCache($what){
    global $dbBannersTable;
    global $stamp;

    $dbThisTable = $dbBannersTable;

    // get only publshed ones and actives
    $join=""; 
    $filter = " WHERE `$dbThisTable`.`status` IN ('40','45')"; // published
    $filter .= " AND   ( `$dbThisTable`.`position` NOT LIKE  'news_%' ) "; // not a news
    $filter .= " AND   ( `$dbThisTable`.`position` NOT LIKE  'alert%' ) "; // not a news
    $filter .= " AND   ( NOW() BETWEEN `$dbThisTable`.`startdate` AND  `$dbThisTable`.`enddate` )  "; // publicehd

     //-- make the full query
    $query = "SELECT `$dbThisTable`.* FROM `$dbThisTable` ".$join .$filter." ". $sql_sort . " " . $limit ; 
    $result = mysql_query($query);
    $sqlerror=""; 
    if (!$result) $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;

    // get total number
    $totnbrofresults = mysql_num_rows($result);

    if ($totnbrofresults)
    {
      $idx=0;
      $bannerlist = Array ();
      while ($row = mysql_fetch_object($result)) 
      { 
          $outdata = Array (
                'htmlcode' => stripslashes($row->htmlcode),
                'clicktrackingurl'=>stripslashes($row->clicktrackingurl),
                'id'=> $row->id,
                'position'=> $row->position 
              );
         $bannerlist[$idx] = $outdata; 
         $idx+=1; 
      }
      $maxresults=$idx;  
      $out=array( "lastupdate"=>$stamp , "datas"=>$bannerlist); 
      file_put_contents(CACHE_PATH."banners.json", json_encode($out, JSON_PRETTY_PRINT)); 
    } else {
      $submessage= "no data"; 
      unlink(CACHE_PATH."banners.json");
    }
    return $sqlerror; 

  }



?>
