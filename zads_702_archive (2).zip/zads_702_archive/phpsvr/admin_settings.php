<?php

// ----------------------------------------------------------------------------
// Server Side Script for installation
//
// ----------------------------------------------------------------------------
// load libraries 
// require_once("settings/db_settings.php");  
// require_once("settings/settings.php"); 

require_once("multitenants_settings.php"); 
require_once($SETTINGS_PATH."db_settings.php");  
require_once($SETTINGS_PATH."settings.php");  
require_once("localization.php");
require_once("functions.php"); 

// set default timezone 
date_default_timezone_set('Europe/Paris');

header('Content-Type: application/json');

$debug ="";$debug_tmp = 0 ; // 0= server 1=local
if (( $_SERVER['SERVER_ADDR'] != "127.0.0.1") ||( !$_SERVER['SERVER_ADDR'] ))  $debug_tmp=0; else $debug_tmp=1; 
$nomessage = 0;  // 0= flag to indicate wether to end a message or not

// force the debug mode : 
//force a debug based on settings file Zads5.0
if ($ENABLE_DEBUG_MODE) $debug_tmp=1; 

if ($debug_tmp==1) {
	$_METHOD  = $_GET ; 
  $debugoutputfile = "debugoutput.htm"; // only if save=1
  $debugfile = fopen($debugoutputfile,"a"); if(!$debugfile) { echo "Error writing to the output file.\n";}
  logfile('', '[admin] --------------------------------------'); // start a new call of file 
  // Report all errors except E_NOTICE  and WARNINGS
  error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);
} 
else {
  // Report simple running errors
  error_reporting(E_ERROR |  E_PARSE);
}

error_reporting(E_ALL ^ (E_NOTICE | E_WARNING | E_DEPRECATED));



$databasehost = $DB_HOST;
$databaseusername =$DB_USERNAME;  
$databasepassword =$DB_PASSWORD;  

$databasename = $DB_NAME;  //cads = classified adds. 

$dbItemsTable = $DB_PREFIX.$DB_TABLE_ITEMS ; 
$dbCatsTable = $DB_PREFIX.$DB_TABLE_CATS; 
$dbUsersTable = $DB_PREFIX.$DB_TABLE_USERS; 
$dbStatsTable = $DB_PREFIX.$DB_TABLE_STATS; 
$dbLogsTable = $DB_PREFIX.$DB_TABLE_LOGS; 

$fullfqdn = $DOMAIN_FQDN; 

// initialize datas 
$curuser_is_admin=false; // global var to indicate it a user is logged and if he is admin 
$curuser_id=""; 
$curuser_type=0; 
$curuser_xtra_type="";

//  --- open socket to MySQL database
$con = mysql_connect ($databasehost,$databaseusername, $databasepassword);
if (!$con) { $status="ko"; $msg= _('Impossible to connect to MySQL  : ').mysql_error(); } 
else {$status="ok";$msg= _("MySQL : Correct connection to host");}

$dbcon = mysql_select_db ( $databasename );
if (!$dbcon) { $status="ko"; $msg= _('Impossible to connect to MySQL  : ').mysql_error(); }
else { $status="ok";$msg= _("MySQL : Correct connection to database :"). $databasename;}

mysql_query("SET NAMES 'utf8'");


// get some global date & time variables 
$todayweeknbr = date("W") ; 
$todaymonthnbr = date("m") ; // with 0
$todayyearnbr=date("Y"); // 4 char year
$stamp= date( 'Y-m-d H:i:s', time());


// ---- process the real requests

// define the access control of this 
$userRights =array (
  "settings" => array( 
     "create"=> "9"
  )
); 



// -------------- SERVLET FOR SETTINGS   ----------------------
if(isset($_POST["settings"])) {
	

  $origaction="settings"; 
  $action = $_POST["settings"]; 
  //$what = secure_var($_POST["what"]) ;            // SECURITY 
  $nav = secure_var($_POST["nav"]) ;
  $subnav = secure_var($_POST["subnav"]) ;
  $section = secure_var($_POST["section"]) ;

  $userid = $_POST["userid"]+0 ; 
  $curuserid = $_POST["curuserid"]+0 ;            // SECURITY - convert to int        

  check_userRights("settings", "create"); 

  $sql_filter=""; 
  $sql_sort="";
  $sql_limit="";


  // load the data model 
  require_once($SETTINGS_PATH."settings_model.php");
  $general_settings = json_decode(file_get_contents($SETTINGS_PATH."general.json"),true);


  //----- core of the processing part-----------------------------
  if ($action=="about"){
    $ret = array(); 
    $success = true;   

    // get myqsl version
    $version=0;
    $matches = array();
    $result = @mysql_query('SELECT VERSION()');
    $item = mysql_fetch_array ( $result );
    if(preg_match('/(\d{1,2}\.\d{1,2}\.\d{1,2})/',$item[0],$matches))
    $mysqlversion=$matches[1];


    // get database usage per table with total
    $sql = "SELECT 
         TABLE_NAME, table_rows, data_length, index_length, 
         round(((data_length + index_length) / 1024 / 1024),2) 'size_mb' 
        FROM information_schema.TABLES 
        WHERE table_schema = '$databasename' and TABLE_TYPE='BASE TABLE' and TABLE_NAME like '$DB_PREFIX%'
        ORDER BY data_length DESC
        ";
    $result = @mysql_query($sql);
    if  (!$result) $dbstore =  "Could not successfully run query from DB: " . mysql_error();
    else  {
      $db_total_size_mb=0; 
      // TH entry 
      $dbstore []= array( 'table name', 'nbr of entries', 'size in MB');
      
      // get the DATAs  
      while ($row = mysql_fetch_object($result)) {
        $dbstore []= array(
          $row->TABLE_NAME,
          $row->table_rows,
          $row->size_mb
        );
        $db_total_size_mb+= $row->size_mb;
      }
    }
    $ret['sql']=$sql; 


    //preprocessing forbackup info
    $backUpFilesAr =   dirList('backup/');
    $backUpFilesAr = $backUpFilesAr[0]; 
    if ($backUpFilesAr['file_extension']!="gz") $backUpFilesAr = 'No backup yet'; 

    // check install filepresent of not 
    if (file_exists("install.php")) { $install_action ='#specialaction=disableinstallfile'; $install_label="disable install file" ; $install_xtra="<a class='dm_button2 mr6' href='./phpsvr/install.php' target='_blank'><i class='icon icon-fa-link mr6'></i>go to install</a>";}
    else { $install_action ='#specialaction=enableinstallfile'; $install_label="enable install file" ; $install_xtra="";}

    // $TBYB_END_DATE='2016-03-31';
    if ($TBYB_END_DATE){
      $datefrom = explode("-", $TBYB_END_DATE);
      $tbybstamp=mktime(0,0,0,$datefrom[1], $datefrom[2], $datefrom[0]) ; 
      $tbybdatestring =  date("j F Y", $tbybstamp);
    }

    
    $ret[data] =array(
                  'zads_version' => ZADS_VERSION,
                  'about_subscription'=>$YOUR_SUBSCRIPTION,
                  'about_expire'=>$TBYB_END_DATE ? $tbybdatestring: "never", 
                  'Server IP'=>$_SERVER['SERVER_ADDR'],
                  'Server time'=>date('d/m/Y  H:i:s'). ' '.date_default_timezone_get(),
                  'php_version' => phpversion(),
                  'mysql_version' => $mysqlversion,
                  'server_software' => $_SERVER['SERVER_SOFTWARE'],
                  'changelog' => "<a class='dm_button2' href='./change.txt' target='_blank'><i class='icon icon-fa-file-text-o mr6'></i>see latest changes</a>",
                  'blog'=> "<a class='dm_button2' href='http://blog.zads.fr/' target='_blank'><i class='icon icon-fa-newspaper-o mr6'></i>see the blog</a>",
                  'support'=> "<a class='dm_button2' href='http://support.myzads.fr/' target='_blank'><i class='icon icon-fa-bug mr6'></i>report a bug</a>",
                  'php_extensions'=>array(
                      'gdlib' => extension_loaded('gd'), 
                      'gettext'=>extension_loaded('gettext'), 
                      'hash'=>extension_loaded('hash'), 
                      'zlib'=>extension_loaded('zlib'), 
                      'pdo'=>extension_loaded('PDO')
                  ), 
                  'session maxlifetime' => ini_get("session.gc_maxlifetime").' sec',
                  'php_ini'=>array(
                    'post_max_size' => ini_get('post_max_size'), 
                    'upload_max_filesize' => ini_get('upload_max_filesize'), 
                    'max_execution_time'=> ini_get('max_execution_time'), 
                    'max_input_time'=> ini_get('max_input_time')
                  ),
                  'mail settings'=>array(
                    'SendMail path (UNIX):' => ini_get("sendmail_path"), 
                    'SMTP server (Windows):' => ini_get("SMTP"),
                    'SMTP port (Windows):' => ini_get("smtp_port"),
                    'Add X header:' => ini_get("mail.add_x_header")
                  ), 
                  'lc_all' => setlocale(LC_ALL, 0),
                  'mysql_size_mb' => $db_total_size_mb .' MBytes',
                  'mysql_stats' => $dbstore,
                  'files_size'=>array(
                      'files_ads' => dirSize('../uploads/img/').' MBytes', 
                      'files_users' => dirSize('../uploads/user/').' MBytes', 
                      'files_admin' => dirSize('../uploads/files/').' MBytes',
                  ), 
                  'last_backup'=> $backUpFilesAr, 
                  'force_backup'=>"<a class='dm_button2 hasaction' zhref='#batch=forcedbackup' href='#'><i class='icon icon-fa-archive-o mr6'></i>force a backup</a>",
                  'debugfile'=>array(
                    'debug_file_name'=>  "<a class='dm_button2' href='./phpsvr/debugoutput.htm' target='_blank'><i class='icon icon-fa-link mr6'></i>view debugoutput.htm</a>",
                    'debug_file_size'=> human_filesize(filesize("debugoutput.htm")),
                    'debug_file_erase'=>  "<a class='dm_button2 hasaction' zhref='#specialaction=cleardebugfile' href='#'><i class='icon icon-fa-trash-o mr6'></i>Empty content</a>"
                  ),
                  'about_sitemap'=>array(
                    'sitemap_lastmod'=>date ("d F Y H:i:s.", filemtime("../sitemap.xml")),
                    'sitemap_size'=> human_filesize(filesize("../sitemap.xml")),
                    'sitemap_generate'=>  "<a class='dm_button2 hasaction' zhref='#specialaction=forcesitemapgeneration' href='#'><i class='icon icon-fa-cog mr6'></i>Update Sitemap</a>",
                    'sitemap_logs'=>  "<a class='dm_button2' href='./phpsvr/logs/seologs.html' target='_blank'><i class='icon icon-fa-link mr6'></i>view logs</a>"

                  ), 
                  'cron tests'=>array(
                    'cron hourly'=>  "<a class='dm_button2 hasaction' zhref='#specialaction=forcedcronhourly' href='#'><i class='icon icon-fa-cog mr6'></i>force hourly cron</a>",
                    'cron daily'=>  "<a class='dm_button2 hasaction' zhref='#specialaction=forcedcrondaily' href='#'><i class='icon icon-fa-cog mr6'></i>force daily cron</a>",
                    'cron weekly'=>  "<a class='dm_button2 hasaction' zhref='#specialaction=forcedcronweekly' href='#'><i class='icon icon-fa-cog mr6'></i>force weekly cron</a>",
                  ),
                  'about_install'=>  "<a class='dm_button2 hasaction mr6' zhref='".$install_action."' href='#'><i class='icon icon-fa-cog mr6'></i>".$install_label."</a>".$install_xtra

              );
  }


  //----- core of the processing part-----------------------------
  if ($action=="load"){


  	// get all sections details 
  	$sectionslist =  array(); 


    // get back the file name and location
    $thiselem = array(); 
    if (!$section) $section="general"; 
    foreach ($settingsmodel as $elem){
       if ($elem["n"]== $section){
        $thiselem= $elem; // allocate for this section
       }

       // save into $allsectionlist
       $patchedelem = array(); 
       $patchedelem = $elem; $patchedelem['furl']=''; $patchedelem['turl']='';$patchedelem['t']='';
       $sectionslist[] =$patchedelem;  
    }

    // retrieve from file only if ACL right for it 
    if ($thiselem["acl"] && ($_SESSION['assocprojects'] != $thiselem["acl"]) ) {
      $ret=false; $ret[sqlerror]= "This operation is not authorized !".$curuser_xtra_type ; $ret['sql2']=$_SESSION;
    }
    else 
    $ret = file_fetch_elem($thiselem);


    if ($ret[result]){
      $success = true;   
      //print_r($ret);
    } else {
      $success = false; 
      $message = $ret[sqlerror];
    }
  } // end of Action =load ! 


    //----- core of the processing part-----------------------------
  if ($action=="update"){
    
    $thisdata=$_REQUEST; // get all requests

    // get back the file name and location
    $thiselem = array(); 
    if (!$section) $section="general"; 
    foreach ($settingsmodel as $elem){
       if ($elem["n"]== $section){
        $thiselem= $elem; 
        break; 
       }
    }
    // retrieve from file 
    $ret = file_update_elem($thiselem, $thisdata);

    if ($ret[result]){
      $success = true;  
      $message ="Settings updated successfully";  
      //print_r($ret);
    } else {
      $success = false; 
      $message = $ret[sqlerror];
    }
  } // end of Action =update ! 


  //----- out the message -----------------------------
  // prepare the output code             
     $json = array(
                  'success' => $success,
                  'message' => $message,
                  'action' => $origaction,
                  'subaction' => $action,
                  'what' => $what,
                  'nav'=>$nav,
                  'subnav'=>$subnav,
                  'section'=>$section,
                  'sectionslist'=>$sectionslist,
                  'id'=>$id,
                  'userid' => $userid,
                  'curuserid' => $curuserid,
                  'data' => $ret[data]
              );
              
     // return the DOM ID location to display the elements          
     if ($nav=="sidebar")  $json["modid"] = $modid;
    
     if ($debug_tmp==1){ // add debug info into the stream when working local
       $json["xdebug"]= array(
                  'sql'=> $ret['sql'], 
                  'sqlerror'=> $ret['sqlerror'],
                  'sql2'=> $ret['sql2'],
                  'in'=> $ret['indata'], 
                  'thiselem'=> $thiselem
                );  
     }
    echo json_encode($json); 

}


?>