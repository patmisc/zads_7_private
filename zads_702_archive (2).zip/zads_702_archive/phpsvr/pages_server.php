<?php
// ----------------------------------------------------------------------------
// Server Side Script for installation
//
// ----------------------------------------------------------------------------
// load libraries 





error_reporting(E_ALL ^ (E_NOTICE | E_WARNING | E_DEPRECATED));

require_once("multitenants_settings.php"); 
require_once($SETTINGS_PATH."db_settings.php");  
require_once($SETTINGS_PATH."settings.php");
require_once("localization.php"); 
require_once($SETTINGS_PATH."home_settings_".$cust_lang_long.".php");  
require_once("functions.php");    

// force the debug mode : 
//force a debug based on settings file Zads5.0
if ($ENABLE_DEBUG_MODE) $debug_tmp=1; 

// connect to DB just for having the fun part of using MYSQL ESCAPE STRNG ! 
//  --- open socket to MySQL database 
// $databasehost = $DB_HOST;
// $databaseusername =$DB_USERNAME;  
// $databasepassword =$DB_PASSWORD;  
// $databasename = $DB_NAME;  //cads = classified adds. 
// //  --- open socket to MySQL database
// $con = mysql_connect ($databasehost,$databaseusername, $databasepassword)or die();
// mysql_select_db ( $databasename ) or die();


// -------------- SERVLET FOR SETTINGS   ----------------------
if(isset($_POST["action"])) {

	$action = $_POST["action"]; 
  	//$what = secure_var($_POST["what"]) ;            // SECURITY 
  	$pageid = secure_var($_POST["pageid"]) ;

  	$ret=false;

	if ($action=="get"){

		// map equal the home page 
		if ($pageid=="map") {
			if ($page_home_type_url) {
				// readthe file and ecode it into base64 before sending 
				$pcontent=file_get_contents($page_home_url);
				$pcontent = base64_encode(utf8_decode($pcontent)); 
				$ret['content_p'] = $pcontent; 

			} else {
				$pfp = $page_map_first_p;
				$pcp = $page_map_center_p;
				$plp = $page_map_last_p;

				 if (get_magic_quotes_gpc()){
					$ret['first_p'] = stripcslashes($pfp); 
					$ret['center_p'] = stripcslashes($pcp); 
					$ret['last_p'] = stripcslashes($plp); 

				 } else {
				 	$ret['first_p']=$pfp;  
				 	$ret['center_p']=$pcp; 
				 	$ret['last_p']=$plp;
				 }

				 // in zads 7.2.1, 	all these HTML code is saved as HTML in base68 to support all HTML tags 
				 // so no need to chage that. 

				 $ret['first_p'] = base64_encode(utf8_decode(base64_decode($ret['first_p']))); 
				 $ret['center_p'] = base64_encode(utf8_decode(base64_decode($ret['center_p']))); 
				 $ret['last_p'] = base64_encode(utf8_decode(base64_decode($ret['last_p']))); 
				 // $ret['center_p'] = base64_encode(utf8_decode($ret['center_p'])); 
				 // $ret['last_p'] = base64_encode(utf8_decode($ret['last_p'])); 

				}
			
		}; 
		
		$ret['page_home_type_url'] = $page_home_type_url ; 
		$success=true;
		$message=""; 
		
	}

 //----- out the message -----------------------------
  // prepare the output code             
     $json = array(
                  'success' => $success,
                  'message' => $message,
                  'action' => $action,
                  'pageid'=>$pageid,
                  'data' => $ret
              );
              
 
     // if ($debug_tmp==1){ // add debug info into the stream when working local
     //   $json["xdebug"]= array(
     //              'sql'=> $ret[sql], 
     //              'sqlerror'=> $ret[sqlerror],
     //              'sql2'=> $ret[sql2],
     //              'in'=> $ret[indata]
     //            );  
     // }
    echo json_encode($json); 

}

?>