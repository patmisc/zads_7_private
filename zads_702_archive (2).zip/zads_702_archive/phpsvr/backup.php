<?php

// load libraries 
$run_standalone=false;

if ($run_standalone){
    require_once("multitenants_settings.php"); 
    require_once($SETTINGS_PATH."db_settings.php");  
    require_once($SETTINGS_PATH."settings.php");
    require_once("localization.php");   
    require_once($SETTINGS_PATH."home_settings_".$cust_lang_long.".php");  

    $databasehost = $DB_HOST;
    $databaseusername =$DB_USERNAME;  
    $databasepassword =$DB_PASSWORD;  
    $databasename = $DB_NAME;  //cads = classified adds. 


    $dbItemsTable = $DB_PREFIX.$DB_TABLE_ITEMS ; 
    $dbCatsTable = $DB_PREFIX.$DB_TABLE_CATS; 
    $dbUsersTable = $DB_PREFIX.$DB_TABLE_USERS; 
    $dbStatsTable = $DB_PREFIX.$DB_TABLE_STATS; 
    $dbLogsTable = $DB_PREFIX.$DB_TABLE_LOGS; 
    $dbPaymentsTable = $DB_PREFIX.$DB_TABLE_PAYMENTS;
    $dbBannersTable = $DB_PREFIX.$DB_TABLE_BANNERS;

    $dbBookingsTable = $DB_PREFIX.$DB_TABLE_BOOKINGS;
    $dbPricingsTable = $DB_PREFIX.$DB_TABLE_PRICINGS;
    $dbSubscribersTable = $DB_PREFIX.$DB_TABLE_SUBSCRIBERS;
    $dbVFieldsTable = $DB_PREFIX.$DB_TABLE_VFIELDS;
    $dbServicesTable= $DB_PREFIX.$DB_TABLE_SERVICES;

    $dbVisitorsTable= $DB_PREFIX.$DB_TABLE_VISITORS; 


    $fullfqdn = $DOMAIN_FQDN; 

    $debugoutputfile = "debugoutput.htm"; // only if save=1

    //force a debug based on settings file Zads5.0
    if ($ENABLE_DEBUG_MODE) $debug_tmp=1; 
    $debug_level = ($DEBUG_LEVEL) ? $DEBUG_LEVEL : 7 ;

    if ($debug_tmp==1) {
    // debug output file 
      $debugfile = fopen($debugoutputfile,"a"); if(!$debugfile) { echo "Error writing to the output file.\n";}
      // Report all errors except E_NOTICE  and WARNINGS
      // error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);
    } 


    // ========= DEBUG - TEST OF THE FUNCTION IN STANDALONE ========================//
    $resfile= dump($DB_PREFIX);
    echo "Backup of files done in file : executed into $resfile <br>";
    echo "File size : ". filesize("./backup/".$resfile) ."<br>" ;  
    if ($resfile) mySendEmailWithAtt("","", "coucou", "the message", "./backup/", $resfile);

}



function dump($tableprefix)
{
 global $databasehost ;
 global $databasename ;
 global $databaseusername ;
 global $databasepassword ;
 global $dbLogsTable; 
 global $dbVisitorsTable;
 global $run_standalone; // true if this function is runing in direct standalone call

 //Connexion à la base
 $db = mysql_connect($databasehost, $databaseusername, $databasepassword) or die(mysql_error());
 mysql_select_db($databasename, $db) or die(mysql_error());

  mysql_query("SET NAMES 'utf8'");

 //on récupère la liste des tables de la base de données
 //$tables = mysql_list_tables($database, $db) or die(mysql_error());
 $sql = 'SHOW TABLES FROM '.$databasename;
 $tables = mysql_query($sql) or die(mysql_error());

 // si on ne veut pas récupérer les $ignore premières tables
 //for ($i=0; $i<$ignore; $i++) ($donnees = mysql_fetch_array($tables));

   $backup_path = "./backup/"; 
   $backup_filename=$tableprefix."_backup_".date("Y_m_d_H_i").".sql.gz"; 
   $backup_filefull = $backup_path.$backup_filename; 
   //$fp = fopen($backup_file,"w"); 
   $fp = gzopen($backup_filefull, 'w');
   if (!is_resource($fp)) {
    
    $msg = "unable to create Back-up file : $backup_filefull"; 
    if ($run_standalone) echo $msg; 
    else logfile("error", "{backup.php / dump} $msg");

    return false;
  }
   


  $stamp= date( 'Y-m-d H:i:s', time());
  $header = "
    -- Zads SQL dump 
    -- version 1.0.0 
    --
    -- Host: $databasehost
    -- Generation Time: $stamp
    ";
    gzwrite($fp, $header);

   // aller on boucle sur toutes les tables

   while ($donnees = mysql_fetch_array($tables))
   {
    
    $table = $donnees[0];

    if ( (($tableprefix == "") || (preg_match('/^'.$tableprefix.'/',$table))) && ($table!=$dbLogsTable) && ($table!=$dbVisitorsTable) ) 
    {
  
     // echo "--$table--$dbLogsTable-|-"; 
      // on récupère le create table (structure de la table)    
      $sql = 'SHOW CREATE TABLE '.$table;
      // WARNING : sometimes the tableexist but return nothing if no data ! 
      // $res = mysql_query($sql) or  die(mysql_error().$sql);
      $res = mysql_query($sql);
      if ($res)
      {
       $tableau = mysql_fetch_array($res);
       $tableau[1] .= ";\n";
       $insertions = $tableau[1];
       $octnb = gzwrite($fp, $insertions);
       
       $req_table = mysql_query('SELECT * FROM '.$table) or die(mysql_error());
       $nbr_champs = mysql_num_fields($req_table);
       while ($ligne = mysql_fetch_array($req_table))
       {
        $insertions = 'INSERT INTO '.$table.' VALUES (';
        for ($i=0; $i<$nbr_champs; $i++)
        {
         $insertions .= '\'' . mysql_real_escape_string($ligne[$i]) . '\', ';
        }
        $insertions = substr($insertions, 0, -2);
        $insertions .= ");\n";
        
        gzwrite($fp, $insertions);
        //fwrite($fp,$insertions);
       }
       mysql_free_result($res);
      } // fin if ($res)
      
      gzwrite($fp, "-- -------------------------------------------------------- \n");
    }
   }
   gzclose($fp);
  //fclose($fp);
 return $backup_filename;
}

/**-----------------------------------------------------------------------------
* This function evaluate for a given trigger if need to send an email or not.
* function fased on mail() function 
* 
* @param  $emailto {string} the emeil address of destination 
* @param  $emailfrom {string} the emeil address of destination 
* @param  $path {string} pat of the file (exmple $_SERVER['DOCUMENT_ROOT']."/your_path_here/";)
* @param  $filename {string} name of the file  (example: "somefile.zip")
* @return $dataobj {array} contains the data to be displayed into the message
* @param  $useremail {string} email address of the user triggering this action
* 
*-----------------------------------------------------------------------------*/
function mySendEmailWithAtt($emailto, $emailfrom, $emailtitle, $emailmessage, $path, $filename){
  global $debug_tmp; // true : we store the content of the mail into the LOG file.
  global $enableEmail;  // true : email is activated 
  global $debugfile; 
  global $email_admin; 
  global $email_fromadmin; 
  
  $message=""; 
  $htmlmessage="";
  $headers=""; 
  
  // reset vars
  $message=""; 
  $htmlmessage="";
  
    $file = $path.$filename;
    $file_size = filesize($file);
    $handle = fopen($file, "r");
    $content = fread($handle, $file_size);
    fclose($handle);
    $content = chunk_split(base64_encode($content));

    // define our boundary
    $semi_rand = md5(time()); 
    $mime_boundary = "==Multipart_Boundary_x{$semi_rand}x"; 
    
    $headers .= "To: $emailto" . "\r\n";
    $headers .= "From: $emailfrom" . "\r\n";
    $headers .= "Reply-To: $emailfrom" . "\r\n";

    // tell the header about the boundary
    $headers .= "\nMIME-Version: 1.0\n" . "Content-Type: multipart/mixed;\n" . " boundary=\"{$mime_boundary}\"";
                 
    // part 1: define the plain text email
    $message ="--{$mime_boundary}\n";
    $message .="Content-Type: text/plain; charset=\"iso-8859-1\"\n";
    $message .="Content-Transfer-Encoding: 7bit\n\n" . $emailmessage . "\n\n";
    //$message .= "--{$mime_boundary}\n";
        
    // part 2: send the attached file 
    /*
    $message .= "Content-Type: {\"application/octet-stream\"};\n";
    $message .= " name=\"$filename\"\n";
    $message .= "Content-Disposition: attachment;\n";
    $message .= " filename=\"$filename\"\n";
    $message .= "Content-Transfer-Encoding: base64\n\n" . $content . "\n\n";
    $message .= "--{$mime_boundary}\n";
    */
    
    $message .= "Content-Type: application/octet-stream; name=\"".basename($filename)."\"\n" . 
            "Content-Description: ".basename($filename)."\n" .
            "Content-Disposition: attachment;\n" . " filename=\"".basename($filename)."\"; size=".filesize($path.$filename).";\n" . 
            "Content-Transfer-Encoding: base64\n\n" . $content . "\n\n";
    
  
      // define subject
      //$subject =  utf8_decode($theemailrule["title"]) ;
      //$subject =  $theemailrule["title"] ;
      $subject = '=?iso-8859-1?q?'.$emailtitle.'?=';  // indicate encoding of the subject
      
      // destination user
      $recipient = $emailto;
       
      // define content of the email 
      //$message.= build_html_message($what, $state,  $theemailrule, $dataobj ); 
      //$message= "";
      $stamp= date( 'Y-m-d H:i:s', time());
      
      if (($debug_tmp!=1) || $enableEmail){
        if (mail ($recipient, $subject, $message, $headers))
           $result= "\n $stamp : Mail  : $subject sent  to $recipient "; 
        else   $result= "\n $stamp : Mail  : $subject ERROR while sending to $recipient ";  
      } else if ($debug_tmp==1){
         // write it to debug file 
          $result= "\n $stamp : Mail  = $subject sent  to $recipient ";  
          fwrite($debugfile,$result);
          fwrite($debugfile,$message);
          fwrite($debugfile,$headers);
      }
};

/* debug test */
/*
$to="patrice.cohaut@alcatel-lucent.com";
$sendermail = "ZADS Annonces <noreply@zads.fr>"; 
$emailtitle="coucou";
$emailmsg="coucou message";
$files[0]="./backup/backup_2011_10_18_13_01.sql.gz";
multi_attach_mail($to, $sendermail, $emailtitle, $emailmsg, $files); 
*/


function multi_attach_mail($to, $sendermail, $emailtitle,$emailmsg, $files){

    // email fields: to, from, subject, and so on
    $from = $sendermail; 
    $subject=$emailtitle; 
    $message = $emailmsg;
    $headers = "From: $from";
    $i=1;

    // boundary 
    $semi_rand = md5(time()); 
    $mime_boundary = "==Multipart_Boundary_x{$semi_rand}x"; 
 
    // headers for attachment 
    $headers .= "\nMIME-Version: 1.0\n" . "Content-Type: multipart/mixed;\n" . " boundary=\"{$mime_boundary}\""; 
 
    // multipart boundary 
    $message = "--{$mime_boundary}\n" . "Content-Type: text/plain; charset=\"iso-8859-1\"\n" .
    "Content-Transfer-Encoding: 7bit\n\n" . $message . "\n\n"; 
 
    // preparing attachments
    for($i=0;$i<count($files);$i++){
        if(is_file($files[$i])){
            $message .= "--{$mime_boundary}\n";
            $fp =    @fopen($files[$i],"rb");
        $data =    @fread($fp,filesize($files[$i]));
                    @fclose($fp);
            $data = chunk_split(base64_encode($data));
            $message .= "Content-Type: application/octet-stream; name=\"".basename($files[$i])."\"\n" . 
            "Content-Description: ".basename($files[$i])."\n" .
            "Content-Disposition: attachment;\n" . " filename=\"".basename($files[$i])."\"; size=".filesize($files[$i]).";\n" . 
            "Content-Transfer-Encoding: base64\n\n" . $data . "\n\n";
            }
        }
    $message .= "--{$mime_boundary}--";

    //$returnpath = "-f" . $sendermail;
    $ok = @mail($to, $subject, $message, $headers); 
    logfile('debug', "{multi_attach_mail} : result from email send  = $ok"); 
    if($ok){ return $i; } else { return 0; }
}




if ($run_standalone){
    /**-----------------------------------------------------------------------------
    * This function log an event into TEXT file(s)
    *-----------------------------------------------------------------------------*/
    function logfile($status, $msg){

      // status per SYSLOG definition 
      // PANIC (0) | ALERT (1) | CRTI (2) | ERROR (3) | WARNING (4) | NOTICE (5) | INFO (6) | DEBUG (7)
      $debug_matrix =  array (
          "PANIC" => 0, "ALERT" => 1, "CRTI" => 2, "ERROR" => 3, "WARNING" => 4, "NOTICE" => 5, "INFO" => 6, "DEBUG" => 7
          );

      global $debug_tmp; 
      global $debug_level;
      global $debugfile; 


      $style =""; $disp_status=""; 

      $_SEPARATOR=" - "; // separator 

      if ($debug_tmp==1) {

        if ($status=="") $status="DEBUG"; 
        if (strtolower($status)=="error" || strtolower($status)=="notice" || strtolower($status)=="warning") 
          $style="color:red;";

        $hm = "<div>"; 
        $hm .= "<span class='date' style='font-size:0.8em;'>".date('Y-m-d H:i:s',time()).'</span>'; 
        $hm .= $_SEPARATOR; 
        $hm .= '<span class="" style="'.$style.'">'. strtoupper($status).'</span>'; 
        $hm .= $_SEPARATOR; 
        //$hm .= strtolower($msg);
        $hm .= $msg;
        $hm .= "</div>"; 

        // final write to file if level if higher
        if ( $debug_matrix[strtoupper($status)]  <= intval($debug_level)) { 
          fwrite($debugfile,$hm);
        }
      }
      return true; 
    }
  }
?>
