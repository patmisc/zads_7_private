
<?php

error_reporting(E_ALL ^ (E_NOTICE | E_WARNING | E_DEPRECATED));

// include class
require_once('inc/SitemapGenerator.php');
require_once("init_settings.php");

function format_url_for_seo($in){

    $out=$in;
    $out = strtolower(utf8_decode(stripslashes($in)));
    //$out = strtolower(stripslashes($in));
    $out = mb_convert_encoding($out, "UTF-8");

    // $out = strtr($out, "éèêàç", "eeeac");
    // replace é and è and ê by e
    $out = str_replace("é","e", $out);
    $out = str_replace("è","e", $out);
    $out = str_replace('ê','e', $out);
    $out = str_replace('à','a', $out);
    $out = str_replace('ç','c', $out);
    //$out = strtolower(utf8_decode(stripslashes($out)));

    // replace space and other chars with '-'
    $out = preg_replace("![^a-z0-9]+!i", "-", $out);
    return $out; 
}; 


function update_robot($action){
    global $DOMAIN_FQDN;
    global $fullfqdn; 
    $basePath='../'; // dirty  ! 
    
    $debug_trail=""; 
    $robotsFileName = "robots.txt";

    $sitemapFullURL = $fullfqdn."sitemap.xml"; 
    
    if ($action =="disablerobots" || $action =="enablerobots"){
        $debug_trail .= " - $action "; 

        $robotsFile = explode("\n", file_get_contents($basePath.$robotsFileName));
        $robotsFileContent = "";
        foreach($robotsFile as $key=>$value) {
             unset($robotsFile[$key]); // delete all  ! 
        }
       
        $robotsFileContent .= "User-agent: *\n";
        if ($action =="enablerobots") {
            $robotsFileContent .= "Disallow: /stats/ \n";
        } else {
            $robotsFileContent .= "Disallow: /\n";
        }
        $robotsFileContent .= "\nSitemap: $sitemapFullURL\n";
        
        file_put_contents($basePath.$robotsFileName,$robotsFileContent);
    }

    $debug_trail .='------ BRAVO - finished <br>'; 
    return $debug_trail;
}    



function update_cache($action){
    global $DOMAIN_FQDN;
    global $fullfqdn; 
    $basePath='../'; // dirty  ! 
    
    $debug_trail=""; 
    $cacheFileName = ".htaccess";
    $dir_list=['../js/','../css/','../lib/','../map/','../lang/','../img/','../bg/','../fonts/','../uploads/img/','../uploads/files/']; 

    foreach ($dir_list as $key => $dir_elem) {
        $basename= $dir_elem.$cacheFileName; 
        if ($action =="disablecache") {
           $srcbasename = $basename ; 
           $result =  rename($srcbasename, $basename.'.cache');
        } else {
            $srcbasename =  $basename.'.cache';
            $result =  rename($srcbasename,$basename);
        } 
        $resultString= ($result)? "OK" : "FAILED"; 
        $debug_trail .="- $srcbasename $action $resultString";          
    }    

    $debug_trail .='------ BRAVO - finished <br>'; 
    return $debug_trail;
}    



// $r = generate_sitemap();  
// echo $r ;  
function generate_sitemap(){

        global $dbItemsTable; 
        global $dbCatsTable; 
        global $dbUsersTable; 
        global $fullfqdn ; 
        global $ESCF;
        global $trans;
        global $cust_lang_long;
        global $DOMAIN_FQDN;
        global $XTRA_XML_URL;


        global $cust_tandc_url;
        global $cust_pub_url;
        global $cust_aboutus_url;
        global $cust_faq_url;
        global $cust_demo_url;
        global $cust_help_url;
        global $XTRASITEMAP_XML_URL; // enable sitemap publishing


        global $DISABLE_ZETVU ;
        global $SEO_INCLUDE_ZETVU;
        global $ZETVU_VISIBLE_ACL;
        global $ZETVU_VISIBLE_ACL;
        global $ZETVU_AS_NEWS; 
        global $ZETVU_AS_VIDEO_TUTO;


        global $SEO_CATLIST; 

        $message = "";
        $success=false; 
        $what = ""; 
        $dbThisTable="";

        $debug_trail=""; 

        // create object

        // echo ('Welcome to ZADS.FR sitemap generator  ! <br>'); 

        $sitemap = new SitemapGenerator( $fullfqdn, '../');


        // General URL 
        $sitemap->addUrl($DOMAIN_FQDN,  date('c'),  'always',    '1');

        // --- part 1 : add the Main NaV 
        // $nav = Array ('home', 'sell', 'buy', 'shops'); 
        $nav = Array ('home', 'sell', 'buy', 'user'); 
            // already within a UL part , so display only the LI parts
        foreach ( $nav as $key => $value) {
            $link = $ESCF.$trans[$cust_lang_long][$value];
            $sitemap->addUrl($DOMAIN_FQDN.$link,  date('c'),  'always',    '1');
        }


        // --- part 3 : add the list of adds (first latest 300 ! )
        $dbThisTable = $dbItemsTable; 
        $filter = " WHERE `$dbThisTable`.`status` IN ('40','45', '46') AND `$dbThisTable`.`type` <> 'zetvu' "; // published
        $sql_sort=" ORDER by  `$dbThisTable`.`moddate` DESC ";
        $sql_limit =" LIMIT 0, 300"; 
        $sql_group ="";

        $query = "SELECT `$dbThisTable`.`title`, `$dbThisTable`.`id`, `$dbThisTable`.`description`
                  FROM `$dbThisTable` ".$join .$filter." ". $sql_sort . " " . $sql_group . " " .$sql_limit  ; 
        // make the real query 
        $result = @mysql_query($query);
        // add to sitemap 
        while ($row = mysql_fetch_object($result)) {
           $link = $ESCF.$trans[$cust_lang_long]['ad'].'/'.$row->id.'/'.format_url_for_seo($row->title);
           $sitemap->addUrl($DOMAIN_FQDN.$link,  date('c'),  'daily',    '0.8');
        }

    
        $debug_trail .= "... seo_catlist $SEO_CATLIST<br>"; 

        // --- part 2 : add the list of categories 
        if ($SEO_CATLIST=="all" || $SEO_CATLIST=="nonull") {

            $debug_trail .= "... in category listing <br>"; 
            
            $dbThisTable = $dbCatsTable; 
            $filter = " WHERE `$dbThisTable`.`status` IN ('40','45', '46') AND `$dbThisTable`.`id` != '9999'"; // published and the default catégory for zetevu
            $sql_sort=" ORDER by  `$dbThisTable`.`title` DESC ";
            $sql_limit =""; 
            $sql_group ="";



            if ($SEO_CATLIST=="nonull"){
                $join = " LEFT OUTER JOIN `$dbItemsTable` ON `$dbThisTable`.`id`= `$dbItemsTable`.`catid` ";
                $query = "SELECT `$dbThisTable`.`title`, `$dbThisTable`.`id`, `$dbThisTable`.`description`, COUNT(`$dbItemsTable`.`id`) as `nbads`
                      FROM `$dbThisTable` ".$join .$filter." ". $sql_sort . " " . $sql_group . " " .$sql_limit  ; 
            } else {
                $query = "SELECT `$dbThisTable`.`title`, `$dbThisTable`.`id`, `$dbThisTable`.`description`
                      FROM `$dbThisTable` ".$join .$filter." ". $sql_sort . " " . $sql_group . " " .$sql_limit  ; 
            }
        
            // make the real query 
            $result = @mysql_query($query);
            if (!$result) {$sqlerror=mysql_error();  logfile('error', '{generate_sitemap}'.mysql_error(). '|' . $query); }


            // add to sitemap 
            while ($row = mysql_fetch_object($result)) {
               if ($SEO_CATLIST=="nonull") $link = $ESCF.$trans[$cust_lang_long]['cat'].'/'.$row->id.'/'.format_url_for_seo($row->title).'('.$row->nbads.')';
               else $link = $ESCF.$trans[$cust_lang_long]['cat'].'/'.$row->id.'/'.format_url_for_seo($row->title);

               $sitemap->addUrl($DOMAIN_FQDN.$link,  date('c'),  'daily',    '0.5');
            }
        }

        // --- part 4 : add the list of published users (top 100)
        $dbThisTable = $dbUsersTable; 
        $filter = " WHERE `$dbThisTable`.`status` IN ('40','45', '46') AND `$dbThisTable`.`protype` IN ('pro','pub','par') AND `$dbThisTable`.`indir`= 'yes' "; // published
        $sql_sort=" ORDER by  `$dbThisTable`.`moddate` DESC ";
        $sql_limit =" LIMIT 0, 100"; 
        $sql_group ="";

        $query = "SELECT `$dbThisTable`.`procpny`, `$dbThisTable`.`id`, `$dbThisTable`.`bio`
                  FROM `$dbThisTable` ".$join .$filter." ". $sql_sort . " " . $sql_group . " " .$sql_limit  ; 
        // make the real query 
        $result = mysql_query($query);

        // add to sitemap 
        while ($row = mysql_fetch_object($result)) {
           $link = $ESCF.$trans[$cust_lang_long]['user'].'/'.$row->id.'/'.format_url_for_seo($row->procpny);
            $sitemap->addUrl($DOMAIN_FQDN.$link,  date('c'),  'daily',    '0.8');
        }


        // --- part 5 : add the list of zetvu/news  (top 20)
        if (!$DISABLE_ZETVU && $SEO_INCLUDE_ZETVU && ($ZETVU_VISIBLE_ACL=="0" || $ZETVU_VISIBLE_ACL==0)) {

            $dbThisTable = $dbItemsTable; 
            $filter = " WHERE `$dbThisTable`.`status` IN ('40','45', '46') AND  `$dbThisTable`.`type` = 'zetvu' "; // published
            $sql_sort=" ORDER by  `$dbThisTable`.`moddate` DESC ";
            $sql_limit =" LIMIT 0, 20"; 
            $sql_group ="";

            $query = "SELECT `$dbThisTable`.`title`, `$dbThisTable`.`id`, `$dbThisTable`.`description`
                      FROM `$dbThisTable` ".$join .$filter." ". $sql_sort . " " . $sql_group . " " .$sql_limit  ; 
            // make the real query 
            $result = mysql_query($query);
            // add to sitemap 
            while ($row = mysql_fetch_object($result)) {
               // get zetevu label
               if  ($ZETVU_AS_NEWS) $zetevuLabel = $trans[$cust_lang_long]['news'];
               else if  ($ZETVU_AS_VIDEO_TUTO) $zetevuLabel = $trans[$cust_lang_long]['videos'];
               else $zetevuLabel = $trans[$cust_lang_long]['zetevu'];

               // publich the links
               $link = $ESCF.$zetevuLabel.'/'.$row->id.'/'.format_url_for_seo($row->title);
               $sitemap->addUrl($DOMAIN_FQDN.$link,  date('c'),  'daily',    '0.8');
            }

        }

        // --- part 5 : add the link to footer links 

        // low footer
        // check if it's an url and if ./ then add the FQDN variable
        // TODO !!!! 
        //
        // if ($cust_tandc_url) $sitemap->addUrl($cust_tandc_url,  date('c'),  'monthly',    '0.3');
        // if ($cust_pub_url) $sitemap->addUrl($cust_pub_url,  date('c'),  'monthly',    '0.3');
        if ($cust_aboutus_url) $sitemap->addUrl($cust_aboutus_url,  date('c'),  'monthly',    '0.3');
        if ($cust_faq_url) $sitemap->addUrl($cust_faq_url,  date('c'),  'monthly',    '0.3');
        // if ($cust_demo_url) $sitemap->addUrl($cust_demo_url,  date('c'),  'monthly',    '0.3');
        if ($cust_help_url) $sitemap->addUrl($cust_help_url,  date('c'),  'monthly',    '0.3');


        // create sitemap
        $sitemap->createSitemap();
        $debug_trail .='... sitemap created <br>'; 

        // write sitemap as file
        $sitemap->writeSitemap();
        $debug_trail .='... sitemap written <br>'; 



        //6.8.1 - add sitemap extra file (XML already)
        //parse generated sitemap to find enf of file and replace it by the new end 
        if ($XTRASITEMAP_XML_URL) {

            $sitemaxxtra_url = $XTRASITEMAP_XML_URL;
            
            $debug_trail .="... will add xtraxml from $sitemaxxtra_url |"; 
            $sitemap_url = "../sitemap.xml";

            $sitemap_in = file_get_contents($sitemap_url);
            $sitemap_toadd = file_get_contents($sitemaxxtra_url);

            $debug_trail .=' in = '.strlen($sitemap_in).' + add '. strlen($sitemap_toadd).'|'; 

            // we insert it "on top" / take the FIRST URL only ! 
            $pos = strpos($sitemap_in,"<url>");
            if ($pos !== false) {
                $sitemap_merged = substr_replace($sitemap_in,$sitemap_toadd.'<url>',$pos,strlen("<url>"));
            }
            $debug_trail .='... out = '.strlen($sitemap_merged) ; 
            // write it back 
            file_put_contents($sitemap_url, $sitemap_merged);  
        }

        // update robots.txt file
        // $sitemap->updateRobots();

        // submit sitemaps to search engines
        //echo ('... sending sitemap to search engines<br>'); 
        if ($SITEMAP_PUBLISHING_EN) 
            $res=$sitemap->submitSitemap();
        
        foreach($res as $engine) {
            $debug_trail .= '<br> ---------- '; 
            foreach($engine as $key => $value){ 
                $debug_trail .="<br> $key = $value"; 
            }
          }

        $debug_trail .='------ BRAVO - finished <br>'; 

        return $debug_trail;
            
}




        ?>
