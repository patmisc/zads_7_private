<?php
/******************************************************************************
 * ZADS INIT_SETTINGS Server Script
 * 
 * Note :  works with DB_SETTINGS.PHP &  SETTINGS.PHP file & LOCALIZATION.PHP
 * LINKED LIB: Mobile_Detect.php 
 *  
 * @category   CorePackage
 * @package    ZADS
 * @author     Patrice COHAUT <patrice.cohaut@gmail.com>
 * @copyright  2015 PATMISC
 * @version    6.8.2 
 ******************************************************************************/
/* Disable direct access.*/
//if(!strcasecmp(basename($_SERVER['SCRIPT_NAME']),basename(__FILE__))) 
//die('ZADS- Direct Access to this file not allowed!');
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING | E_DEPRECATED));

// ---  generic part for ALL PHP file  ---//
require_once("multitenants_settings.php"); 
require_once($SETTINGS_PATH."db_settings.php");  
require_once($SETTINGS_PATH."settings.php"); 
require_once ('inc/Mobile_Detect.php');

$detect = new Mobile_Detect;
// Any mobile device (phones or tablets).
if ( $detect->isMobile() ) {
  $ismobile=true; 
} else $ismobile=false;

/* ---  LANGUAGE DETECTION  ---
*  $lang must be in ISO 639-1 Language Codes 
*    (see here for list : http://www.w3schools.com/tags/ref_language_codes.asp)
*/ 

// Report simple running errors
 error_reporting(E_ERROR |  E_PARSE);


/* step 0, construct the supported_languages_short and long lists  */
$supported_lang_short = array();
$supported_lang_long = '';
  foreach( $AUTHORIZED_LANGUAGES as $key => $value ){
    $supported_lang_short[] = $key; 
    $supported_lang_long .= $value.';' ; 
  } 


/**-----------------------------------------------------------------------------
* detect google bot 
*-----------------------------------------------------------------------------*/
function xdetect_googlebot() {
  if (strstr(strtolower($_SERVER['HTTP_USER_AGENT']), "googlebot")) return true ; 
  else return false ; 
}
 $isGoogleBot=xdetect_googlebot();

if ($isGoogleBot){
  // fisrt one
  $shortlangcode="fr"; 
  $longlangcode= $AUTHORIZED_LANGUAGES[$shortlangcode]; // default  =  first entry of the list ! 
}
// priority 1 =  COOKIES 
else if (isset($_COOKIE['ZADS_LOCAL'])){
  $cookietext  =  ($_COOKIE['ZADS_LOCAL']!='' ? $_COOKIE['ZADS_LOCAL'] : ''); // set default language
  $langcodeext= explode("lang=", $cookietext); 
  $longlangcode =$langcodeext[1];
  $shortlangcode= substr($longlangcode, 0, 2);
}
else { 
  // priority 2 =  BRWOSER language detection 
  // example of output of  HTTP_ACCEPT_LANGUAGE en-US,en;q=0.8,fr-FR;q=0.6,fr;q=0.4
  $browserfirstlang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);

  //$suplang = array("en", "fr", "nl");
  if (in_array($browserfirstlang, $supported_lang_short)) {
    $shortlangcode = $browserfirstlang; 
  } else $shortlangcode=$supported_lang_short[0]; 

  // final assigment  
  $longlangcode= $AUTHORIZED_LANGUAGES[$shortlangcode]; // default  =  first entry of the list ! 
}

// load the right file and set the variables : 
$cust_lang_short = $shortlangcode;  
$cust_lang = $cust_lang_short; 
$cust_lang_long = $longlangcode; 
$cust_dir = ($shortlangcode=="ar") ? 'rtl' :'ltr';  
$cust_lang_support =  $supported_lang_long;

include_once $SETTINGS_PATH."home_settings_".$cust_lang_long.".php"; 

// --------- setup for ajax crowling 
if ($SEO_DISPLAY_UGLY_URL) $ESCF= "?_escaped_fragment_="; // for test only ! 
else if ($SEO_FULL_PHP_SITE) $ESCF=""; // PHP full site 
else $ESCF='#!'; // production 



// check if const is defined
if (defined('URI_MODE')){
  if (URI_MODE=="static") $ESCF='';  
}

// for use in general purpose GLOBLA Variable! 
$uagent = $_SERVER['HTTP_USER_AGENT'];
$serverremoteaddr = $_SERVER['REMOTE_ADDR'];  


// -------- visitor / crawler tracker
if ($ENABLE_VISITORS_LOGS) {
  $serverremotehostx ='unknown';
  $serverremoteaddr = $_SERVER['REMOTE_ADDR'];  
  $debughostinfo = "remote host=".$serverremotehostx ." | remote ip= ". $serverremoteaddr;
  $uagent = $_SERVER['HTTP_USER_AGENT'];

  $thisip =  $serverremoteaddr;
  $thisua =  $uagent;

  // test session
  $a = session_id();
  if(empty($a)) { session_name("ZADSSESID"); session_start(); }
   $thisssid=  session_id();

  // test URL
  function CurrentPageURL() 
  {
  // $pageURL = $_SERVER['HTTPS'] == 'on' ? 'https://' : 'http://';
  $pageURL =  'http://';
  $pageURL .= $_SERVER['SERVER_PORT'] != '80' ? $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"] : $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
  return $pageURL;
  }

  $thisuri = CurrentPageURL(); 

  //  --- open socket to MySQL database
  $databasehost = $DB_HOST;
  $databaseusername =$DB_USERNAME;  
  $databasepassword =$DB_PASSWORD;  
  $databasename = $DB_NAME;  //cads = classified adds. 
  $dbVisitorsTable = $DB_PREFIX.$DB_TABLE_VISITORS;

  // $con = mysql_connect ($databasehost,$databaseusername, $databasepassword) or header('Location: ./phpsvr/install.php');
  $con = mysql_connect ($databasehost,$databaseusername, $databasepassword) or  die('Oups !! , ZADS install not completed !'. mysql_error());
  mysql_select_db ( $databasename ) or die('Oups !! , ZADS install not completed !'. mysql_error());


  // save to Visitor log file the elements
  $stamp= date( 'Y-m-d H:i:s', time());
  $query = "INSERT INTO `".$dbVisitorsTable."` 
          ( `date`, `uri`,`ip`, `ua`, `ssid`) ";
  $query .= "VALUES ( '$stamp', '$thisuri', '$thisip',  '$thisua', '$thisssid');";
  $result = mysql_query($query);

}
 





