<?php

/******************************************************************************
 * ZADS MAIN for bootstaping SITEMAP.XML access to get some logs on it 
 * @category   MAIN
 * @package    ZADS
 * @author     Patrice COHAUT <patrice.cohaut@gmail.com>
 * @copyright  2016 PATMISC
 * @version    1.0
 * @link       https://www.zads.fr
 * @notes      
 ******************************************************************************/

 
// get the debug / log file 
define("DIR_LIBS", 'inc/');
require_once(DIR_LIBS.'debug_logs_class.php'); 

$sitemapLogs = new debugClass([
	  'debug_level' => 7
    , 'enable_debug_mode' => true
    , 'debugoutputfile'=> 'logs/seologs.html'
]); 

// save in the log file
$uagent = $_SERVER['HTTP_USER_AGENT'];
$serverremoteaddr = $_SERVER['REMOTE_ADDR'];
$message="sitemap.xml requested by $serverremoteaddr , user agent = $uagent";
$status="info"; 
$sitemapLogs->log($status, $message);

//read and simply output the file 
$sitemapContent = file_get_contents('../sitemap.xml');
header('Content-type: application/xml');
echo $sitemapContent;

// close the debug element
$sitemapLogs->close();

?> 