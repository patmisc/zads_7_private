<?php
require_once("multitenants_settings.php"); 
require_once($SETTINGS_PATH."db_settings.php");  
require_once($SETTINGS_PATH."settings.php");
require_once("localization.php");  

// set default timezone 
date_default_timezone_set('Europe/Paris');

// Report all PHP errors
error_reporting(-1);

$debug ="";
$debug_tmp = 0 ; // 0= server 1=local
if (( $_SERVER['SERVER_ADDR'] != "127.0.0.1") ||( !$_SERVER['SERVER_ADDR'] ))  $debug_tmp=0; else $debug_tmp=1; 
$nomessage = 0;  // 0= flag to indicate wether to end a message or not


$databasehost = $DB_HOST;
$databaseusername =$DB_USERNAME;  
$databasepassword =$DB_PASSWORD;  
$databasename = $DB_NAME;  //cads = classified adds. 
$dbItemsTable = $DB_PREFIX.$DB_TABLE_ITEMS ; 
$dbCatsTable = $DB_PREFIX.$DB_TABLE_CATS; 
$dbUsersTable = $DB_PREFIX.$DB_TABLE_USERS; 
$dbStatsTable = $DB_PREFIX.$DB_TABLE_STATS; 

$fullfqdn = $DOMAIN_FQDN; 


$con = mysql_connect ($databasehost,$databaseusername, $databasepassword);
if (!$con) { $status="ko"; $msg= _('Impossible to connect to MySQL  : ').mysql_error(); echo $msg; die;} 
mysql_select_db ( $databasename ) or die();

// Where the file are located
$target_path_DEF = '../uploads/img/'; 
$target_path_from_root_DEF ="./files/";  
//$allowedextensions = array("jpeg", "jpg", "gif", "png", "JPEG", "GIF", "PNG", "JPG");

//****************** test start ********************
$id="174";
$sql_sort=""; 
$filter.="  WHERE `id` = '".$id."' ";

$dbThisTable = $dbItemsTable; 
$query = "SELECT imgname FROM `$dbThisTable`" .$filter." ". $sql_sort ; 
$result = mysql_query($query);
if (!$result) { $sqlerror =  "Could not successfully run query from DB: " . mysql_error()."--".$query;echo $sqlerror; die; 
}

$totnbrofresults = mysql_num_rows($result);
if ($totnbrofresults>0){
  $row = mysql_fetch_object($result);
  $filename = $row->imgname;
  send_download($filename); 
} else echo("no file found");


function send_download($filename){ 
  global $target_path_DEF;
    
  $i = pathinfo($filename);
  $ext = $i['extension']; 
  
  $file_path =  $target_path_DEF. $filename; 
  $file_size=@filesize($file_path); 

  // Determine Content Type 
  switch ($ext) { 
      case "pdf": $ctype="application/pdf"; break;
      case "rtf": $ctype="application/rtf"; break;
      case "exe": $ctype="application/octet-stream"; break; 
      case "zip": $ctype="application/zip"; break;
      case "tar": $ctype="application/x-tar"; break;  
      case "doc": $ctype="application/msword"; break; 
      case "docx": $ctype="application/vnd.openxmlformats-officedocument.wordprocessingml.document";break;
      case "xls": $ctype="application/vnd.ms-excel"; break; 
      case "ppt": $ctype="application/vnd.ms-powerpoint"; break; 
      case "pptx": $ctype="application/vnd.openxmlformats-officedocument.presentationml.presentation"; break;
      case "gif": $ctype="image/gif"; break; 
      case "png": $ctype="image/png"; break; 
      case "jpeg": 
      case "jpg": $ctype="image/jpg"; break; 
      default: $ctype="application/force-download"; 
   }  
   
    header("Pragma: public"); // required 
    header("Expires: 0"); 
    header("Cache-Control: must-revalidate, post-check=0, pre-check=0"); 
    header("Cache-Control: private",false); // required for certain browsers 
    header("Content-Type: $ctype"); 
    header("Content-Disposition: attachment; filename=\"".basename($filename)."\";" ); 
    header("Content-Transfer-Encoding: binary"); 
    header("Content-Length: ".$file_size); 
    ob_clean(); 
    flush(); 
    readfile( $file_path ); 
  
  exit; 
}


?>
