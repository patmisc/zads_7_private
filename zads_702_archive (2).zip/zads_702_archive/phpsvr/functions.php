<?php

/* detect the PHP version */ 
if(function_exists('phpversion')) $v = phpversion();
  elseif(PHP_VERSION) $v = PHP_VERSION;
  else $v =  'Impossible de d�tecter la version PHP';
$phpVersion = intval(str_replace('.','',$v));
//echo "PHPVERSION = $phpVersion <br>";
 

function secure_var($string) {
		// On regarde si le type de string est un nombre entier (int)
		if(ctype_digit($string))
		{
			$string = intval($string);
		}
		// Pour tous les autres types
		else
		{
		  // if already protected, remove the Slash before applying the protection
      if (get_magic_quotes_gpc()) {
        $string = stripslashes($string);
      }
			// $string = mysql_real_escape_string($string); // need to be connected to sql to do that
			$string = addcslashes($string, '%_');
		}
		return $string;
};


/**-----------------------------------------------------------------------------
 * Get the list of file in a directory and sort them by sortorder
 * @param directory $directory
 * @return integer
 *-----------------------------------------------------------------------------*/
function dirList ($directory, $sortOrder='newestFirst'){

    //Get each file and add its details to two arrays
    $results = array(); 
    $file_names=array();
    $file_dates=array();
    $debug='debug= ';

    $handler = opendir($directory);
    while ($file = readdir($handler)) {  
        if ($file != '.' && $file != '..' && $file != "robots.txt" && $file != ".htaccess"){
            $currentModified = filectime($directory."/".$file);
            $file_names[] = $file;
            $file_dates[] = $currentModified;
            $debug .=  ' -'.$file;  
        }  
        
    }
    closedir($handler);

    //Sort the date array by preferred order
    if ($sortOrder == "newestFirst"){
        arsort($file_dates);
    }else{
        asort($file_dates);
    }
    
    //Match file_names array to file_dates array
    $file_names_Array = array_keys($file_dates);
    foreach ($file_names_Array as $idx) {

      $p=pathinfo($file_names[$idx]); 

      $results[]= array(
        'file_name' => $file_names[$idx], 
        'file_date' => date( 'Y-m-d H:i:s', $file_dates[$idx]),
        'file_extension'=> $p['extension'] 
      );
    }
    return $results;


}

function human_filesize($bytes, $decimals = 2) {
    $sz = 'BKMGTP';
    $factor = floor((strlen($bytes) - 1) / 3);
    return sprintf("%.{$decimals}f", (int)$bytes / pow(1024, (int)$factor)) . @$sz[(int)$factor];
}


/**-----------------------------------------------------------------------------
 * Get the directory size
 * @param directory $directory
 * @return integer
 *-----------------------------------------------------------------------------*/
function dirSize($directory,$format='mb') {
    $size = 0;
    foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($directory)) as $file){
        $size+=$file->getSize();
    }

    // format
    if ($format=="mb") $size=round($size/1014/1024,2) ; 
    return $size;
} 

/**-----------------------------------------------------------------------------
* Parses a user agent string into its important parts
* 
* @param string $u_agent
* @return array an array with browser, version and platform keys
*-----------------------------------------------------------------------------*/
function UserAgentParser( $u_agent ) { 

    $data = array();

    //# ^.+?(?<platform>Android|iPhone|iPad|Windows|Macintosh|Windows Phone OS)(?: NT)*(?: [0-9.]+)*(;|\))
    if (preg_match('/^.+?(?P<platform>BlackBerry|Android|iPhone|iPad|Windows|Macintosh|Windows Phone OS)(?: NT)*(?: [0-9.]+)*(;|\))/im', $u_agent, $regs)) {
        $data['platform'] = $regs['platform'];
    } else {
        $result = "";
    }

    //# (?<browser>Camino|Kindle|Firefox|Safari|MSIE|AppleWebKit|Chrome|IEMobile|Opera)(?:[/ ])(?<version>[0-9.]+)
    preg_match_all('%(?P<browser>Camino|Kindle|Firefox|Safari|MSIE|AppleWebKit|Chrome|IEMobile|Opera)(?:[/ ])(?P<version>[0-9.]+)%im', $u_agent, $result, PREG_PATTERN_ORDER);

    if( $result['browser'][0] == 'AppleWebKit' ) {
        if( ( $data['platform'] == 'Android' && !($key = 0) ) || $key = array_search( 'Chrome', $result['browser'] ) ) {
            $data['browser'] = 'Chrome';
        }elseif( $key = array_search( 'Kindle', $result['browser'] ) ) {
            $data['browser'] = 'Kindle';
        }elseif( $key = array_search( 'Safari', $result['browser'] ) ) {
            $data['browser'] = 'Safari';
        }else{
            $key = 0;
            $data['browser'] = 'webkit';
        }
        $data['version'] = $result['version'][$key];
    }elseif( $key = array_search( 'Opera', $result['browser'] ) ) {
        $data['browser'] = $result['browser'][$key];
        $data['version'] = $result['version'][$key];
    }elseif( $result['browser'][0] == 'MSIE' ){
        if( $key = array_search( 'IEMobile', $result['browser'] ) ) {
            $data['browser'] = 'IEMobile';
        }else{
            $data['browser'] = 'MSIE';
            $key = 0;
        }
        $data['version'] = $result['version'][$key];
    }else{
        $data['browser'] = $result['browser'][0];
        $data['version'] = $result['version'][0];
    }

    if( $data['browser'] == 'Kindle' ) {
        $data['platform'] = 'Kindle';
    }
    return $data;
}

/**-----------------------------------------------------------------------------
* This read a text file with variable in PHP (Settings for example) and converts it to constant
*-----------------------------------------------------------------------------*/
function file_convert_var_2_const($filename){
  $ret = false; 

  $fp= fopen($filename, "r");
  $comments_pattern  = '/^(\*|\/\/|\/\*|<\?|\?>)/';
  if ($fp===FALSE){
    $error = "Cannot access '$path' to read contents"; 
    $ret=false; 
  } else {
    while (($line = fgets($fp)) !== false) {
      $line = trim($line);
      if ($line && !preg_match($comments_pattern, $line)) {
          $ps = explode("=", $line, 2); // split Key from value 
          if (count($ps)>=2) {
            $tkey = trim(trim(strtoupper(trim($ps[0]))),"$"); 
            $tval = explode(";", $ps[1], 2);
            $tval = trim($tval[0]);
            $tval = trim( $tval , '"');
            // print_r($ps);
            // echo '</br>';
            // echo "---".$tkey. ' /  value=  '.$tval.' <br>'; 
            if ($tval=="true" || $tval=="false") $xval = ($tval=="true") ? true : false;
            else $xval = stripcslashes($tval); 

            if (strlen($tkey) < 40) 
              define($tkey, $xval); // define this as a constant
          } 
            // else {
            // echo "*** rejected"; 
            // print_r($ps);
            // echo '</br>';

          // }
      }
    }
    fclose($fp); // close the file 
  }
  return $ret;   
};



/**-----------------------------------------------------------------------------
* check for a current session 
* 
* @param $what :{string} describe the object 
* @param $action :{string} describe the action to perform
* @return  tur if OK and JSON object if not authorized, echo a JSON message and exit the function
*-----------------------------------------------------------------------------*/
function check_userRightsOLD($what, $action){

  global $debugfile; 
  global $debug_tmp; 
  global $curuser_is_admin;
  global $curuser_id; 
  global $curuser_type;
  global $COOKIENAME; 
  $output=false;  
  
    // check session to give general info 
    //session_name($COOKIENAME); 
    session_name("ZADSSESID");
    if ($_COOKIE[$COOKIENAME] !="") { // detect if a session is set . session_id does not give the result
      session_start();
      if (isset($_SESSION['userid'])) $curuser_id = $_SESSION['userid'];  
      if (isset($_SESSION['usertype'])) {
        $curuser_type = $_SESSION['usertype']+0; 
        if ($action=="all" && $curuser_type>=8) {
          $curuser_is_admin=true;  
          $output=true;
        }
        if ($action=="my" && isset($curuser_id)) {
          $output=true;
        }
        }
    } 
  
  // output the error and content. 
  if ($output) return  $output; // display nothing and continue processing
  else  {
      // prepare the output code 
     $message = "This operation is not authorized !";             
     $json = array(
                  'success' => false,
                  'message' => $message,
                  'what' => $what,
                  'action' => $action
              );      
      echo json_encode($json); 
      exit();       
  }
}; 



/**-----------------------------------------------------------------------------
* check for a current session 
* 
* @param $what :{string} describe the object 
* @param $action :{string} describe the action to perform
* @return  tur if OK and JSON object if not authorized, echo a JSON message and exit the function
*-----------------------------------------------------------------------------*/
function check_userRights($what2, $action2, $status2, $filter2){
  global $userRights; 
  global $debugfile; 
  global $debug_tmp; 
  global $curuser_is_admin;
  global $curuser_id; 
  global $curuser_type;
  global $curuser_xtra_type; // extra type used for special purpose 
  global $curuser_loclatlng;
  global $serverremoteaddr;
  global $ENABLE_USER_LOGS;
  global $_SESSION; 
  
  $output=true;
  $getnext=false;
  
  // if ($debug_tmp==1){ 
  //   fwrite($debugfile,"<br> Test de droits d'usages sur (".$action2." - ".$what2.") : ");  
  //   fwrite($debugfile,"-- found =  ". implode('|', $userRights[$what2][$action2]));  
  //   fwrite($debugfile,"\n");

  // }

  if ($debug_tmp==1){ 
    $m="{check_userRights} : ".$action2." / ".$what2." : ";  
    if ($userRights[$what2][$action2]) $m.="  found :  ". implode('|', $userRights[$what2][$action2]);  
    else $m.="  no restrictions  "; 
    logfile ('', $m); 
  }

  if ($userRights[$what2][$action2]!="")
  {
      // -- get back the root of the rule
      $xtype= $userRights[$what2][$action2];
      $xtypeout=0; // default value= no check
      if (is_array($xtype)) {
        $xtype2=$xtype; // save array
        $xtype=0; 
        foreach ($xtype2 as $key => $value) {
          //if ($debug_tmp==1){ fwrite($debugfile,"--> Rule found KEY-PAIR  : ".$key." - ".$value);  fwrite($debugfile,"\n");}
          if (($key=="status") && ($status2!="")) { $xtype=$value; break;  }
          else if (($key=="filter") && ($filter2!="")) {$xtype=$value; break;}  
        }
      }
      $xtypenum= $xtype+0; // convert to num if this is numeric 
      
      if (($xtypenum !="") && ($xtypenum!=0)){
        // -- launch the check 
        //if ($debug_tmp==1){ fwrite($debugfile,"--> One control found for this action  : ".$action2." - ".$what2." ->level = ". $xtype);  fwrite($debugfile,"\n");}
        // check session and verify same level as requested.    
        session_name("ZADSSESID"); 
        if ($_COOKIE["ZADSSESID"] !="") { // detect if a session is set . session_id does not give the result
          session_start();
          $init_session =  $_SESSION; 
          
          if (isset($_SESSION['user_type'])){
            if (isset($_SESSION['user_id'])) $curuser_id = $_SESSION['user_id'];  
            // double security 
            $xsessionusertype=$_SESSION['user_type']+0; 
            if ($xsessionusertype==9) $curuser_is_admin=true;
            if (($xtype=="owner") || ($xsessionusertype>=$xtypenum)){
              $msg_extended = "---> Session is OK  : ".$_SESSION['user']." - ".$_SESSION['user_type']; 
              //if ($debug_tmp==1){ fwrite($debugfile,"---> Session is OK  : ".$_SESSION['user']." - ".$_SESSION['user_type']);  fwrite($debugfile,"\n");}
              $output=true;
            }
            else {
              $msg_extended ="---> ERROR - User level not correct ! : ".$_SESSION['user']." - ".$_SESSION['user_type']; 
              if ($debug_tmp==1){ fwrite($debugfile,"---> ERROR - User level not correct ! : ".$_SESSION['user_id']." - ".$_SESSION['user']." - ".$_SESSION['usertype']);  fwrite($debugfile,"\n");}
              $output=false; 
            }
          }
          else {
            $msg_extended ="---> ERROR - Session is not valid ! : ".$_SESSION['user']." - ".$_SESSION['user_type']; 
            //if ($debug_tmp==1){ fwrite($debugfile,"---> ERROR - Session is not valid ! : ".$_SESSION['user']." - ".$_SESSION['user_type']);  fwrite($debugfile,"\n");}
            $output=false; 
            }
        } else {
          $msg_extended ="---> ERROR - No Session ! : ".$_SESSION['user']." - ".$_SESSION['user_type'];
          //if ($debug_tmp==1){ fwrite($debugfile,"---> ERROR - No Session ! : ".$_SESSION['user']." - ".$_SESSION['user_type']);  fwrite($debugfile,"\n");}
          $output=false;  // if no session, this mean user is not connected
        }
      } else {$getnext=true;}
  } else $getnext=true; 
  

  // next processing 
  if ($getnext) {
    //if ($debug_tmp==1){ fwrite($debugfile,"--> no control on this user action : ".$action2." - ".$what2." ");  fwrite($debugfile,"\n");}
    $output=true;  
    // check session to give general info 
    session_name("ZADSSESID"); 
    if ($_COOKIE["ZADSSESID"] !="") { // detect if a session is set . session_id does not give the result
      session_start();
      //if ($debug_tmp==1){ fwrite($debugfile,"--> Cookie detected with id/type/loc =  : ".$_SESSION['user_id']." - ".$_SESSION['user_type']." - ".$_SESSION['user_loclatlng']);  fwrite($debugfile,"\n");}

      // if this is a Mogged user   
      if (isset($_SESSION['user_id']))  $curuser_id = $_SESSION['user_id'];  
      if (isset($_SESSION['user_type'])) {
        $curuser_type = $_SESSION['user_type']+0; 
        if ($curuser_type==9) $curuser_is_admin=true;
      }
      if (isset($_SESSION['assocprojects']))  $curuser_xtra_type = $_SESSION['assocprojects'];  

      // determine locatin rules =  #1 : user local cookie if set #2 use saved preference
      if (isset($_COOKIE['ZADS_LOCATION'])) {
        $cookietext  =  $_COOKIE['ZADS_LOCATION'];  // set default language
        $cookiecontentAr = Array ();
        $cookiecontentAr = parseStrToArr($cookietext);

        if ($cookiecontentAr['loclatlng']){
            $curuser_loclatlng = $cookiecontentAr['loclatlng']; 
        }
        else {
          if (isset($_SESSION['user_loclatlng']))
            $curuser_loclatlng = $_SESSION['user_loclatlng']; 
        }
      } else {
          if (isset($_SESSION['user_loclatlng']))
            $curuser_loclatlng = $_SESSION['user_loclatlng']; 
      }
      //if ($debug_tmp==1){ fwrite($debugfile,"--> default location set to =  : ".$curuser_loclatlng);  fwrite($debugfile,"\n");}

    } 
  }
  
  // output the error and content. 
  if ($output) return  $output; // display nothing and continue processing
  else  {
      // prepare the output code 
     $message = "This operation is not authorized !";             
     $json = array(
                  'success' => false,
                  'message' => $message,
                  'message_extended' =>$msg_extended,
                  'what' => $what2,
                  'action' => $action2,
                  'is_admin' =>$curuser_is_admin, 
                  'xype' => $xtype,
                  'session_id'=>session_id(),
                  'allsession' =>$_SESSION, 
                  'initsession'=>$init_session 
                  
              );      
      echo json_encode($json); 
      
    // ----------------- SAVE TO LOG FILE ----------------------------
    // if ($ENABLE_USER_LOGS){
    //    $laction="sec";$lwhat = "user";
    //    $luserid=$curuser_id;
    //    $ldesc = $message .':'.$what2.'-'.$action2.'|'. $serverremoteaddr;
    //    $lseverity = 2; 
    //    log_event($laction,$lwhat, '', $luserid, $ldesc, $lseverity);
    // }
      
    exit();       
  }
}; 



function parseStrToArr($instr, $format, $thisvar, $protype){
  
  global $general_catalogue; 
  global $lcur_user ; // local surrent user 
  global $SERVICES_PRO_FREE_OPTIONS_LIST;
  $returnedAr= array(); 
  $orig_instr=$instr; 

  // convert the string in the &name1=value1&name2=value2,... to an array 
  // logfile('debug', "{parseStrToArr} : instr =$instr, format=$format, $thisvar=$thisvar, pprotype=$protype, lcur-user=$lcur-user", __LINE__); 

  foreach(explode("&",$instr) as $elem) {
    $exclude=false;
      if  ($elem !="") {
        $elemAr = explode("=",$elem); 
        if (!$format)
          $returnedAr[$elemAr[0]] =$elemAr[1];  
        else if ($format=="forcedvar"){
          $thisvar[$elemAr[0]] = $elemAr[1];
          //array_push($thisvar,array($elemAr[0] => $elemAr[1])); 
          // $thisvar[$elemAr[0]] = "1430000000";
        }
        else if ($format=="paypalbom"){
          // serarch into the settings :
         
          foreach ($general_catalogue['payoptions']['options'] as  $opt) {
            if ($opt["name"]==$elemAr[0]){
            
              // case of HT/TTC prices
              if  ($lcur_user) {
                $lprice= ($lcur_user['protype']=="pro") ?   1*$opt["price_pro_ht"] : 1*$opt["price"]; 
              } else if ($protype){
                $lprice= ($protype=="pro") ?   1*$opt["price_pro_ht"] : 1*$opt["price"]; 
              } else 
                $lprice= 1*$opt["price"]; 

              if (($lcur_user['protype']=="pro" || $protype=="pro") && in_array($opt["name"], explode('+', $SERVICES_PRO_FREE_OPTIONS_LIST)))
                  $exclude=true;

              if (!$exclude){
               
                $xname=($opt["desc"] =="*" || $opt["desc"] =="" ) ? $opt["name"] : $opt["desc"] ;
                $xdesc = ($opt["desc"] =="*" || $opt["desc"] =="" ) ? $opt["name"] : $opt["desc"] ;
                $returnedAr[]=array(
                    "oi" =>$opt["oi"], 
                    "name"  => $xname, 
                    "desc"  => $xdesc, 
                    "qty" => 1, 
                    "price" =>$lprice,
                    "isrecurrent"=>$opt["isrecurrent"], 
                    "billingperiod"=>$opt["billingperiod"], 
                    "billingfrequency"=>$opt["billingfrequency"]
                  ); 
              }
              break;
            }
          }  
        }
      }
    }
    if ($format=="forcedvar") return $thisvar; 
    else return $returnedAr; 
}; 

function session_is_admin(){
  $curuser_is_admin=false;
  session_name("ZADSSESID"); 
  if ($_COOKIE["ZADSSESID"] !="") { // detect if a session is set . session_id does not give the result
    session_start();
    if (isset($_SESSION['user_type'])) {
      $curuser_type = $_SESSION['user_type']+0; 
      if ($curuser_type==9) $curuser_is_admin=true;
    }
  }
  return $curuser_is_admin;
}

/**-----------------------------------------------------------------------------
* This function encode and sens a json object with compression or not depending on settings 
*-----------------------------------------------------------------------------*/
function encode_json_and_send_with_compression($json){
  global $EN_GZIP ; 
  
  if ($EN_GZIP) {
    ob_start('ob_gzhandler');
  }
  echo json_encode($json); 
  return true ; 
}


/** Check for Magic Quotes and remove them **/
 
function stripSlashesDeep($value) {
    $value = is_array($value) ? array_map('stripSlashesDeep', $value) : stripslashes($value);
    return $value;
}
 
function removeMagicQuotes() {
if ( get_magic_quotes_gpc() ) {
    $_GET    = stripSlashesDeep($_GET   );
    $_POST   = stripSlashesDeep($_POST  );
    $_COOKIE = stripSlashesDeep($_COOKIE);
}
}
 
/** Check register globals and remove them **/
/**-----------------------------------------------------------------------------
* This function log time int global variable 
*-----------------------------------------------------------------------------*/
function unregisterGlobals() {
    if (ini_get('register_globals')) {
        $array = array('_SESSION', '_POST', '_GET', '_COOKIE', '_REQUEST', '_SERVER', '_ENV', '_FILES');
        foreach ($array as $value) {
            foreach ($GLOBALS[$value] as $key => $var) {
                if ($var === $GLOBALS[$key]) {
                    unset($GLOBALS[$key]);
                }
            }
        }
    }
}


/**-----------------------------------------------------------------------------
* This function log time int global variable 
*-----------------------------------------------------------------------------*/
function logtime($msg){
  global $t0;
  global $timing_trace;

  $deltatime= (microtime(true)-$t0); 
  $timing_trace.= "|$msg ".sprintf("%01.3f", $deltatime). "s "; 
  $t0=microtime(true); 
  return true;
}




/**-----------------------------------------------------------------------------
* This function log an event into TEXT file(s)
*-----------------------------------------------------------------------------*/
function logfile($status, $msg){

  // status per SYSLOG definition 
  // PANIC (0) | ALERT (1) | CRTI (2) | ERROR (3) | WARNING (4) | NOTICE (5) | INFO (6) | DEBUG (7)
  $debug_matrix =  array (
      "PANIC" => 0, "ALERT" => 1, "CRTI" => 2, "ERROR" => 3, "WARNING" => 4, "NOTICE" => 5, "INFO" => 6, "DEBUG" => 7
      );

  global $debug_tmp; 
  global $DEBUG_LEVEL; 
  global $debugfile; 


  $debug_level = ($DEBUG_LEVEL) ? $DEBUG_LEVEL : "7";

  // $debug_level="7";

  $style =""; $disp_status=""; 

  $_SEPARATOR=" - "; // separator 

  if ($debug_tmp==1) {

    if ($status=="") $status="DEBUG"; 

    if (strtolower($status)=="error" || strtolower($status)=="notice" || strtolower($status)=="warning") 
      $style="color:red;";

    $hm = "<div>"; 
    $hm .= "<span class='date' style='font-size:0.8em;'>".date('Y-m-d H:i:s',time()).'</span>'; 
    $hm .= $_SEPARATOR; 
    $hm .= '<span class="" style="'.$style.'">'. strtoupper($status).'</span>'; 
    $hm .= $_SEPARATOR; 
    //$hm .= strtolower($msg);
    $hm .= $msg;
    $hm .= "</div>"; 


    // final write to file if level if higher
    if ( $debug_matrix[strtoupper($status)]  <= intval($debug_level)) { 
      $ret = fwrite($debugfile,$hm); 
    }
  }
  return true; 
}






/**-----------------------------------------------------------------------------
* This function get and element from a file and return it into a json object
*-----------------------------------------------------------------------------*/
function file_fetch_elem($elem){

  // init some variables  
  $data=array(); 
  $ret=true; 
  
  $now = date( 'Y-m-d H:i:s', time()); 

  $path =  $elem["furl"]; 
  $tpath =  $elem["turl"]; 
  $result  = @file_get_contents($path);
 
  if ($result===FALSE){
    $error = "Cannot access '$path' to read contents"; 
    $ret=false; 
  } else {
    if ($elem["t"]=="json"){ // read a JSON structure 
      $thisdata = json_decode($result, true); // read 
      $thisdata = $thisdata[$elem["s"]]; // just send the right section  
    }
    if ($elem["t"]=="json-txt"){ // read a JSON structure with VALUES comming from a TEXT file
      $thisdata = json_decode($result, true); // read 
      $thisdata = $thisdata[$elem["s"]]; // just send the right section  
     
      // post processing = get back values from PHP file directly
      // read line by line and find the value associated 
      foreach ($thisdata as $i => $set){
        $found=false;
        //echo "--- $i - SEARCHING FOR  : ".$set['name']."<br>"; 
        $fp= fopen($tpath, "r");
        $comments_pattern  = '/^(\*|\/\/|\/\*|<\?|\?>)/';
        if ($fp) {
          while (($line = fgets($fp)) !== false) {
            $line = trim($line);
            if (!$found && $line && !preg_match($comments_pattern, $line)) {
              $ps = explode("=", $line, 2); // split Key from value 
              $tkey = strtolower(trim($ps[0])); 
              if (preg_match('/^\$'.$set["name"].'$/', $tkey)) {
                $tval = explode(";", $ps[1], 2);
                $tval = $tval[0];
                $tval = trim( $tval , '"');$ps[1] = trim( $tval , "\'");
                // echo "---".$set['name']. ' FOUND ! value=  '.$tval.' <br>'; 
                $found=true;

                // if format is base64, then decode it.itherwie send it as it is 
                if ($set['format']=="base64"){
                  $thisdata[$i]["value"] =   base64_decode($tval);
                } else {
                   $thisdata[$i]["value"] = stripcslashes($tval);
                }

              }

            }
          }
          fclose($fp); // close the file 
        } else {
            // error opening the file.
        }

      }

    }
    $data[data][] = $thisdata;  // push element
  }

  // add some datas
   $data['result'] =  $ret ;
   $data['sql'] = $elem;
   $data['sqlerror'] = $error;

    return $data ; // TRUE if ok.
  }

function file_update_elem($elem, $indatas){

  // init some variables  
  $data=array(); 
  $ret=true; 
  $trace='';

  $now = date( 'Y-m-d H:i:s', time()); 

  $path =  $elem["furl"]; 
  $tpath =  $elem["turl"];
  $result  = @file_get_contents($path); // correctly read ! 

  if ($result===FALSE){
    $error = "Cannot access '$path' to read contents"; 
    $ret=false; 
  } else {

    // for pur json, take tha payload and 
    if ($elem["t"]=="json") {

      // read the input fil
      $infile = json_decode($result, true); 
      // var_dump($infile); 
      $outfile = $infile; 
      // echo '-- out content = '; 
      // echo print_r($outfile['payoptions'], true); 
      // echo '--'; 
      foreach ($indatas as $key =>$value) { 
        if ($key == 'section') $tsection =  $value; 
        if ($key == 'payload') $tpayload =  $value;
      }; 

      // patching 
      $tsection=$elem["s"]; // take it from description file


      // strip the slashed of payload 
      if (get_magic_quotes_gpc()) {
        $tpayload = stripslashes($tpayload);
      }

      $outfile[$tsection] = json_decode($tpayload); 

      if (!$fp = fopen($tpath, 'w+')) {
        $error =  "Echec de l'ouverture du fichier";
        $ret=false;
      } else {
          // $catalogue= $_POST["payload"];
          // $catalogue = json_decode($catalogue);
          fwrite($fp, indent(json_encode($outfile)));
          fclose($fp);
          $ret=true;
      }
    }


    if ($elem["t"]=="json-txt") {
      $allsettings_json = json_decode($result, true); // read 
    
      // modify the table 
      $tracker='';
      $i=0; $j=0;
      //loop though each results of POST/GET received 
      foreach ($indatas as $key =>$value) { 
       
          if (  ($key != 'settings') &&  ($key != 'what') &&  ($key != 'forceflag') &&  ($key != 'prevstatus') 
            &&  ($key != 'curuserid') &&  ($key != 'userid')
            &&  ($key != 'section')   && ($key != '') && ($key != 'ZADSSESID') && ($key != 'PHPSESSID') &&  (!strpos($key, '__'))
          ){
          $k=0;
          $trace.=" | for ".$i.'->'.$key.' ,  ';
          foreach ($allsettings_json[$elem["s"]] as $set){
            // update the key 
            //$trace.= " |".$set['name'] ;
            if ($set['name']==$key) {
              // found a matching NAME / KEY pair
              // case of direct value into JSON file 
              if ($elem["t"]=="json"){
                  $allsettings_json[$elem["s"]][$k]['value']=$value; 
              }
              // case of value into a separated TXT file 
              if ($elem["t"]=="json-txt"){  
                // find the place and replace the line with the new content
                $fp= fopen($tpath, "r");
                $fpwrite= fopen($tpath.'.new', "w"); // create new file for writting

                $replaced = false;        
                $comments_pattern  = '/^(\*|\/\/|\/\*|<\?|\?>)/';

                while (!feof($fp)) {
                  $line = trim(fgets($fp));
                  if ($line && !preg_match($comments_pattern, $line)) {
                    $ps = explode("=", $line, 2); // split Key from value 
                    $tkey = strtolower(trim($ps[0])); 
                    if (preg_match('/^\$'.$set["name"].'$/', $tkey)) {
                      $tval = explode(";", $ps[1], 2);
                      $tcomments = $tval[1]; 
                      $replaced=true;
                      $extracomments="//!" ;
                      $extracomments="" ;
                      
                      // build and copy the new line 
                      if (($set['type']=="integer") || ($set['type']=="bool") || ($set['type']=="float")|| ($set['type']=="number")) {
                        if ($value=='') $value='""'; // case of integers with a blank value which causes a Bug to the system 
                        else  $value=$value;
                      }
                      else if ($set['type']=="phparray_lang"){
                        // POST variable is an array ! example  => array('fr'=>'fr_FR',
                        $t=""; 
                        foreach ($value as $k => $xval) {
                          if ($t!="")  $t.=",";
                          $t2A= explode('_',$xval); 
                          $t.= "'".$t2A[0]."'=>'".$xval."'"; 
                        }
                        if ($t) $value="array($t)";
                      }
                      else {
                        if ($set['format']=="base64"){
                          $value=base64_encode($value);
                        }

                        // remove any " char in the text Z6.5.1
                        $value=str_replace('"', "'" , $value);  
                        $value='"'.$value.'"';
                      } 


                      // case of NL for textarea 
                      if ($set['type']=="textarea" && !$set['format']=="base64") {
                        $value= nl2br($value); 
                        $value= str_replace("\r","",$value);
                        $value= str_replace("\n","",$value);
                      }
      
                      $trace.=" | ".$key.'='.$value;

                      // remove any ; into text to prevent breaks later, not for text area where HTMLcodecan be here  ! 
                       $value=str_replace(";", "," , $value);

                      // case of lower or upper case for KEY 
                      if ($elem["case"]=="low") $tkey = strtolower($key); 
                      else $tkey = strtoupper($key); 

                      $line =  "$".$tkey.'='.$value.';'.$tcomments.$extracomments;
                    }
                     
                  }
                  // make the real copy 
                  if ($line!="?>") $line .=PHP_EOL;  // spceial case to patch for end of line aggregation
                  fputs($fpwrite, $line);
                }

                // CLose and rename file for next round 
                fclose($fp); fclose($fpwrite);
                if ($replaced) rename($tpath.'.new', $tpath);
                else unlink($tpath.'.new');
                
              }
              $j+=1; // j =  number of elements modified really into the file
            }
            $k+=1;    
          } // end loop though settings 
          $i+=1; // i= nbr of elements as inputs 
        }
      }

      if ($i>=$j) {
        // duplicate and copy the values 
        //copy($path, $path.'_sav.'+time()); 
        //$fp = fopen($path, 'w');
        //if ($fp){
          //fwrite($fp,json_encode($allsettings_json));
          //fclose($fp);
          $data[data][] = $allsettings_json[$elem["s"]];  // push element
          $ret=true; 
        // } else {
        //   $error = "unable to open settings file for writting"; 
        //   $ret=false; 
        // }
      } else {
        $error = "Done but error in fields number (= not the same)"; 
        // warning , due to Cookies and other ^potential elements, this info could not be realiable as Cookies at attched to the request variable
        $ret=false; 
      }
    }
  }

  // add some datas
   $data['result'] =  $ret ;
   $data['sql'] = $path;
   $data['sql2'] = $trace;
   $data['sqlerror'] = $error;
   $data['indata']= $indatas;
   $data['infile']=$infile;
   
    return $data ; // TRUE if ok.
  }



  function getBrowser()
  {
      

      $u_agent = $_SERVER['HTTP_USER_AGENT'];
      $bname = 'Unknown';
      $platform = 'Unknown';
      $version= "";

      //First get the platform?
      if (preg_match('/linux/i', $u_agent)) {
          $platform = 'linux';
      }
      elseif (preg_match('/macintosh|mac os x/i', $u_agent)) {
          $platform = 'mac';
      }
      elseif (preg_match('/windows|win32/i', $u_agent)) {
          $platform = 'windows';
      }

      // Next get the name of the useragent yes separately and for good reason.
      if (preg_match('/MSIE/i',$u_agent) && !preg_match('/Opera/i',$u_agent))
      {
          $bname = 'Internet Explorer';
          $ub = "MSIE";
      }
      elseif (preg_match('/Firefox/i',$u_agent))
      {
          $bname = 'Mozilla Firefox';
          $ub = "Firefox";
      }
      elseif (preg_match('/Chrome/i',$u_agent))
      {
          $bname = 'Google Chrome';
          $ub = "Chrome";
      }
      elseif (preg_match('/Safari/i',$u_agent))
      {
          $bname = 'Apple Safari';
          $ub = "Safari";
      }
      elseif (preg_match('/Opera/i',$u_agent))
      {
          $bname = 'Opera';
          $ub = "Opera";
      }
      elseif (preg_match('/Netscape/i',$u_agent))
      {
          $bname = 'Netscape';
          $ub = "Netscape";
      }

      // Finally get the correct version number.
      $known = array('Version', $ub, 'other');
      $pattern = '#(?<browser>' . join('|', $known) .
      ')[/ ]+(?<version>[0-9.|a-zA-Z.]*)#';
      if (!preg_match_all($pattern, $u_agent, $matches)) {
          // we have no matching number just continue
      }

      // See how many we have.
      $i = count($matches['browser']);
      if ($i != 1) {
          //we will have two since we are not using 'other' argument yet
          //see if version is before or after the name
          if (strripos($u_agent,"Version") < strripos($u_agent,$ub)){
              $version= $matches['version'][0];
          }
          else {
              $version= $matches['version'][1];
          }
      }
      else {
          $version= $matches['version'][0];
      }

      // Check if we have a number.
      if ($version==null || $version=="") {$version="?";}


      $out=array(
          'userAgent' => $u_agent,
          'name'      => $bname,
          'version'   => $version,
          'platform'  => $platform,
          'pattern'    => $pattern
      );

      // serialize the array
      $rstr=''; 
        foreach ( $out as $key => $value){
          $rstr .= "$key : $value \n<br>  " ;
        }
      $out['html'] = $rstr ;
      return $out; 
  }


function file_update_one_elem($elemname, $elemvalue, $fileurl, $filetype='json-txt', $elemtype="string"){

  // init some variables  
  $data=array(); 
  $ret=true; 
  $trace='';

  $now = date( 'Y-m-d H:i:s', time()); 

  $path =  $fileurl ;
  $tpath =  $fileurl;
  $result  = @file_get_contents($path); // correctly read ! 


  // normalize all
  $elemname =  trim($elemname);
  $elemvalue=trim($elemvalue); 

  if ($result===FALSE){
    $error = "Cannot access '$path' to read contents"; 
    $ret=false; 
  } else {

    // for pur json, take the payload and 
    if ($filetype=="json") {
      // TODO LATER 
    }


    if ($filetype=="json-txt") {
      $allsettings_json = json_decode($result, true); // read 
    
      // modify the table 
      $tracker='';
      $i=0; $j=0;

      $value = $elemvalue;

      // find the place and replace the line with the new content
      $fp= fopen($tpath, "r");
      $fpwrite= fopen($tpath.'.new', "w"); // create new file for writting

      $replaced = false;        
      $comments_pattern  = '/^(\*|\/\/|\/\*|<\?|\?>)/';

      while (!feof($fp)) {
        $line = trim(fgets($fp));
        if ($line && !preg_match($comments_pattern, $line)) {
          $ps = explode("=", $line, 2); // split Key from value 
          $tkey = trim($ps[0]); 
          if (preg_match('/^\$'.$elemname.'$/', $tkey)) {
            $tval = explode(";", $ps[1], 2);
            $tcomments = $tval[1]; 
            $replaced=true;
            $extracomments="" ;
            
            // build and copy the new line 
            if (($elemtype=="integer") || ($elemtype=="bool") || ($elemtype=="float")|| ($elemtype=="number")) {
              if ($value=='') $value='""'; // case of integers with a blak value which causes a Bug to the system 
              else  $value=$value;
            }
            else {
              // remove any " char in the text Z6.5.1
              $value=str_replace('"', "'" , $value);  
              $value='"'.$value.'"';
            } 

            // case of NL for textarea 
            if ($elemtype=="textarea") {
              $value= nl2br($value); 
              $value= str_replace("\r","",$value);
              $value= str_replace("\n","",$value);
            }
            
            $trace.=" | ".$tkey.'='.$value;

            // remove any ; into text to prevent breaks later, not for text area where HTMLcodecan be here  ! 
            $value=str_replace(";", "," , $value);
            $line =  "$".$elemname.'='.$value.';'.$tcomments.$extracomments;
          }
           
        }
        // make the real copy 
        if ($line!="?>") $line .=PHP_EOL;  // spceial case to patch for end of line aggregation
        fputs($fpwrite, $line);
      } // end while end of file 

      // CLose and rename file for next round 
      fclose($fp); fclose($fpwrite);
      if ($replaced) rename($tpath.'.new', $tpath);
      else unlink($tpath.'.new');
                            
    }  // end if JSON TXT 

  } // end cano access file

  // add some datas
   $data['result'] =  $ret ;
   $data['path'] = $path;
   $data['trace'] = $trace;
   $data['key']= $tkey;
   $data['value']=$value;
   
    return $data ; // TRUE if ok.
}



function get_domain($url)
{
  $pieces = parse_url($url);
  $domain = isset($pieces['host']) ? $pieces['host'] : '';
  if (preg_match('/(?P<domain>[a-z0-9][a-z0-9\-]{1,63}\.[a-z\.]{2,6})$/i', $domain, $regs)) {
    return $regs['domain'];
  }
  return false;
}


/**
 * Check if file is on the blacklist.
 *
 * @param $file
 *   File name.
 * @return TRUE if file is not blacklisted.
 */
function ft_check_file($file) {
  // Check against file blacklist.

  if (FILEBLACKLIST != "") {
    $blacklist = explode(" ", strtolower(FILEBLACKLIST));
    if (in_array(strtolower($file), $blacklist)) {
      return FALSE;
    } else {
      return TRUE;
    }
  } else {
    return TRUE;
  }
}

/**
 * Check if file type is on the blacklist.
 *
 * @param $file
 *   File name.
 * @return TRUE if file is not blacklisted.
 */
function ft_check_filetype($file) {
  $type = strtolower(ft_get_ext($file));
  // Check if we are using a whitelist.
  if (FILETYPEWHITELIST != "") {
    // User wants a whitelist
    $whitelist = explode(" ", FILETYPEWHITELIST);
    if (in_array($type, $whitelist)) {
      return TRUE;
    } else {
      return FALSE;
    }
  } else {
    // Check against file blacklist.
    if (FILETYPEBLACKLIST != "") {
      $blacklist = explode(" ", FILETYPEBLACKLIST);
      if (in_array($type, $blacklist)) {
        return FALSE;
      } else {
        return TRUE;
      }
    } else {
      return TRUE;
    }
  }
}

/**
 * Check if directory is on the blacklist.
 *
 * @param $dir
 *   Directory path.
 * @return TRUE if directory is not blacklisted.
 */
function ft_check_dir($dir) {
  // Check against folder blacklist.
  if (FOLDERBLACKLIST != "") {
    $blacklist = explode(" ", FOLDERBLACKLIST);
    foreach ($blacklist as $c) {
      if (substr($dir, 0, strlen(ft_get_root().'/'.$c)) == ft_get_root().'/'.$c) {
        return FALSE;
      }
    }
    return TRUE;
  } else {
    return TRUE;
  }
}


/**
 * Get the current directory.
 *
 * @return The current directory.
 */
function ft_get_dir() {
  if (empty($_REQUEST['dir'])) {
    return ft_get_root();
  } else {
    return ft_get_root().$_REQUEST['dir'];
  }
}

/**
 * Get the name of the File Thingie file. Used in <form> actions.
 *
 * @return File name.
 */
function ft_get_self() {
  return basename($_SERVER['PHP_SELF']);
}

/**
 * Get the root directory.
 *
 * @return The root directory.
 */
function ft_get_root() {
  return DIR;
}


/**
 * Get a list of files in a directory with metadata.
 *
 * @param $dir
 *   The directory to scan.
 * @param $sort
 *   Sorting parameter. Possible values: name, type, size, date. Defaults to 'name'.
 * @return An array of files. Each item is an array:
 *   array(
 *     'name' => '', // File name.
 *     'shortname' => '', // File name.
 *     'type' => '', // 'file' or 'dir'.
 *     'ext' => '', // File extension.
 *     'writeable' => '', // TRUE if writeable.
 *     'perms' => '', // Permissions.
 *     'modified' => '', // Last modified. Unix timestamp.
 *     'size' => '', // File size in bytes.
 *     'extras' => '' // Array of extra classes for this file.
 *   )
 */
function ft_get_filelist($dir, $sort = 'name') {
  $filelist = array();
  $subdirs = array();
  if (ft_check_dir($dir) && $dirlink = @opendir($dir)) {
    // Creates an array with all file names in current directory.
    while (($file = readdir($dirlink)) !== false) {
      if (    $file != "." 
          &&  $file != ".." 
          &&  (EXCLUDETN && (strpos($file,"tn_")===false))
          && (
              (!is_dir("{$dir}/{$file}") && ft_check_file($file) && ft_check_filetype($file)) 
            || is_dir("{$dir}/{$file}") 
            && ft_check_dir("{$dir}/{$file}")
            )
        ) 
      { // Hide these two special cases and files and filetypes in blacklists.
        $c = array();

        
        $c['name'] = $file;
        // $c['shortname'] = ft_get_nice_filename($file, 20);
        $c['shortname'] = $file;
        $c['type'] = "file";
        $c['ext'] = ft_get_ext($file);
        $c['writeable'] = is_writeable("{$dir}/{$file}");

        // Grab extra options from plugins.
        $c['extras'] = array();
        //$c['extras'] = ft_invoke_hook('fileextras', $file, $dir);

        // File permissions.
        if ($c['perms'] = @fileperms("{$dir}/{$file}")) {
            if (is_dir("{$dir}/{$file}")) {
                  $c['perms'] = substr(base_convert($c['perms'], 10, 8), 2);
                } else {
                  $c['perms'] = substr(base_convert($c['perms'], 10, 8), 3);
                }
        }
            $c['modified'] = @filemtime("{$dir}/{$file}");
        $c['size'] = @filesize("{$dir}/{$file}");
        if (ft_check_dir("{$dir}/{$file}") && is_dir("{$dir}/{$file}")) {
          $c['size'] = 0;
          $c['type'] = "dir";
          if ($sublink = @opendir("{$dir}/{$file}")) {
            while (($current = readdir($sublink)) !== false) {
              if ($current != "." && $current != ".." && ft_check_file($current)) {
                $c['size']++;
              }
            }
            closedir($sublink);
          }
          $subdirs[] = $c;
        } else {
          $filelist[] = $c;
        }
      }
    }
    closedir($dirlink);
    // sort($filelist);

    // Obtain a list of columns
    $ext = array();
    $name = array();
    $date = array();
    $size = array();
    foreach ($filelist as $key => $row) {
      $ext[$key]  = strtolower($row['ext']);
      $name[$key] = strtolower($row['name']);
      $date[$key] = $row['modified'];
      $size[$key] = $row['size'];
    }

    if ($sort == 'type') {
      // Sort by file type and then name.
      array_multisort($ext, SORT_ASC, $name, SORT_ASC, $filelist);
    } elseif ($sort == 'size') {
      // Sort by filesize date and then name.
      array_multisort($size, SORT_ASC, $name, SORT_ASC, $filelist);
    } elseif ($sort == 'date') {
      // Sort by last modified date and then name.
      array_multisort($date, SORT_DESC, $name, SORT_ASC, $filelist);
    } else {
      // Sort by file name.
      array_multisort($name, SORT_ASC, $filelist);
    }
    // Always sort dirs by name.
    sort($subdirs);
    return array_merge($subdirs, $filelist);
  } else {
    return "dirfail";
  }
}

/**
* Get extension of a file name
*/
function ft_get_ext($name) 
{
  if (strstr($name, ".")) {
    $ext = str_replace(".", "", strrchr($name, "."));
  } else {
    $ext = "";
  }
  return $ext;
}


/**
* Indents a flat JSON string to make it more human-readable.
*
* @param string $json The original JSON string to process.
*
* @return string Indented version of the original JSON string.
*/
function indent($json) {

    $result      = '';
    $pos         = 0;
    $strLen      = strlen($json);
    $indentStr   = '  ';
    $newLine     = "\n";
    $prevChar    = '';
    $outOfQuotes = true;

    for ($i=0; $i<=$strLen; $i++) {

        // Grab the next character in the string.
        $char = substr($json, $i, 1);

        // Are we inside a quoted string?
        if ($char == '"' && $prevChar != '\\') {
            $outOfQuotes = !$outOfQuotes;

        // If this character is the end of an element,
        // output a new line and indent the next line.
        } else if(($char == '}' || $char == ']') && $outOfQuotes) {
            $result .= $newLine;
            $pos --;
            for ($j=0; $j<$pos; $j++) {
                $result .= $indentStr;
            }
        }

        // Add the character to the result string.
        $result .= $char;

        // If the last character was the beginning of an element,
        // output a new line and indent the next line.
        if (($char == ',' || $char == '{' || $char == '[') && $outOfQuotes) {
            $result .= $newLine;
            if ($char == '{' || $char == '[') {
                $pos ++;
            }

            for ($j = 0; $j < $pos; $j++) {
                $result .= $indentStr;
            }
        }

        $prevChar = $char;
    }

    return $result;
}




?>
