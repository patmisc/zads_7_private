<?php 
/**
* post_tweet.php
* Example of posting a tweet with OAuth
* Latest copy of this code: 
* http://140dev.com/twitter-api-programming-tutorials/hello-twitter-oauth-php/
* @author Adam Green <140dev@gmail.com>
* @license GNU Public License
*/


/* Disable direct access.*/
// if(!strcasecmp(basename($_SERVER['SCRIPT_NAME']),basename(__FILE__))) 
// die('ZADS- Direct Access to this file not allowed!');



// load settings including Tweeter settings
require_once("multitenants_settings.php"); 
require_once($SETTINGS_PATH."db_settings.php");  
require_once($SETTINGS_PATH."settings.php");
require_once("localization.php");  
 
  // Report simple running errors
  error_reporting(E_ERROR |  E_PARSE);

  // global vars
  $tw_screen_name = "saleszads"; 
  
  if(isset($_POST["tweet"])) {
  
    $action = $_POST["tweet"] ;
    $what =   $_POST["what"] ;
    $user=   $_POST["user"] ;
    $value=   $_POST["twstatus"] ;    
    //if ($user=="me") $user="saleszads"; 
    if (($action=="create") && ($what=="status")){
      require  'inc/tmhOAuth.php';
      $tmhOAuth = new tmhOAuth(array(
        'consumer_key'    => $TW_CONSUMER_KEY,
        'consumer_secret' => $TW_SECRET_KEY,
        'user_token'      => $TW_USER_TOKEN,
        'user_secret'     => $TW_USER_SECRET
      ));

      $result = post_tweet($value);
      echo $result;
    }
    
    if (($action=="list") && ($what=="status") && ($user=="me")){
      $result = get_my_tweet();
      echo $result;
    }
    
    if (($action=="list") && ($what=="status") && ($user=="home")){
      require  'inc/tmhOAuth.php';
      $tmhOAuth = new tmhOAuth(array(
        'consumer_key'    => $TW_CONSUMER_KEY,
        'consumer_secret' => $TW_SECRET_KEY,
        'user_token'      => $TW_USER_TOKEN,
        'user_secret'     => $TW_USER_SECRET
      ));
      
      $result = get_home_tweet();
      echo $result;
    }
    
    if (($action=="list") && ($what=="friends") && ($user=="me")){
      $result = get_my_friends();
      echo $result;
    }
    
  }
  
  function post_tweet($tweet_text) {
    global $tmhOAuth;
    
    $tmhOAuth->request('POST', $tmhOAuth->url('1/statuses/update'), array('status' => $tweet_text));
    if ($tmhOAuth->response['code'] == 200) {
      $res =$tmhOAuth->response['response'];
      $res = extract_json_twitter($res, "post_tweet"); 
    } else {
      $res =htmlentities($tmhOAuth->response['response']); 
    }
    return $res; 
  };
  
  function get_home_tweet() {
   global $tmhOAuth;  
   
    $tmhOAuth->request('GET', $tmhOAuth->url('1/statuses/home_timeline','json',array('count' => 10)));
    if ($tmhOAuth->response['code'] == 200) {
      $res= $tmhOAuth->response['response'] ;
      $res = extract_json_twitter($res, "home_tweet");  
    } else {
      $res =htmlentities($tmhOAuth->response['response']); 
    }
    return $res; 
  };
  
  function get_my_tweet() {
    global $tw_screen_name; 
    $nbrtweet = 3; 
    $callstr = 'http://api.twitter.com/1/statuses/user_timeline.json?count='.$nbrtweet.'&screen_name='.$tw_screen_name; 
    $res = call_noaut_API_twitter($callstr);
    $res = extract_json_twitter($res, "my_tweet"); 
    return $res; 
  };
  
  function get_my_friends() {
    global $tw_screen_name; 
    $callstr = 'http://api.twitter.com/1/statuses/friends.json?screen_name='.$tw_screen_name; 
    $res = call_noaut_API_twitter($callstr);
    $res = extract_json_twitter($res, "my_friends"); 
    return $res; 
  };
  
  function call_noaut_API_twitter($callstr) {		
    $ch = curl_init($callstr);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		$apiresponse = curl_exec($ch);
		curl_close($ch);
		if ($apiresponse) {
			//$json = json_decode($apiresponse, true);
			$json = $apiresponse;
		}
		return $json;
  };
  
  
  function extract_json_twitter($res, $what){
    $fulloutdata  = Array();   
    if (($what=="my_tweet") || ($what=="home_tweet")){
      if (count($res)>0 ){
        $res= json_decode($res,true) ; // convert Json into an Array
        foreach($res as $key => $resitem){ // loop throuhg the resul
          //echo "id=".$resitem["id"]; 
           $outdata = Array (
              'user_screen_name'=> $resitem["user"]["screen_name"], 
              'user_name'=> $resitem["user"]["name"], 
              'user_profile_image_url'=> $resitem["user"]["profile_image_url"], 
              'text'=> preg_replace('/((?:http|https|ftp):\/\/(?:[A-Z0-9][A-Z0-9_-]*(?:\.[A-Z0-9][A-Z0-9_-]*)+):?(\d+)?\/?[^\s\"\']+)/i','<a href="$1" rel="nofollow" target="blank">$1</a>',$resitem["text"]), 
              'created_at'=> $resitem["created_at"],
              'created_at_stamp'=> strtotime($resitem["created_at"])*1000
           );
           array_push($fulloutdata, $outdata); 
        } 
      }
    }
    if ($what=="my_friends"){
      if (count($res)>0 ){
        $res= json_decode($res,true) ; // convert Json into an Array
        foreach($res as $key => $resitem){ // loop throuhg the resul
          //echo "id=".$resitem["id"]; 
           $outdata = Array (
              'user_screen_name'=> $resitem["user"]["screen_name"], 
              'user_name'=> $resitem["user"]["name"], 
              'user_profile_image_url'=> $resitem["user"]["profile_image_url"], 
              'user_created_at'=> $resitem["user"]["created_at"],
              'user_created_at_stamp'=> strtotime($resitem["user"]["created_at"])*1000
           );
           array_push($fulloutdata, $outdata); 
        } 
      }
    }  
    
    if ($what=="post_tweet"){
      if (count($res)>0 ){
        $res= json_decode($res,true) ; // convert Json into an Array
        $resitem=$res;
          //echo "id=".$resitem["id"]; 
           $outdata = Array (
              'user_screen_name'=> $resitem["user"]["screen_name"], 
              'user_name'=> $resitem["user"]["name"], 
              'user_profile_image_url'=> $resitem["user"]["profile_image_url"], 
              'text'=> preg_replace('/((?:http|https|ftp):\/\/(?:[A-Z0-9][A-Z0-9_-]*(?:\.[A-Z0-9][A-Z0-9_-]*)+):?(\d+)?\/?[^\s\"\']+)/i','<a href="$1" rel="nofollow" target="blank">$1</a>',$resitem["text"]), 
              'created_at'=> $resitem["created_at"],
              'created_at_stamp'=> strtotime($resitem["created_at"])*1000
           );
           array_push($fulloutdata, $outdata); 
      }
    }  
    return json_encode($fulloutdata); 
  }; 

?>
