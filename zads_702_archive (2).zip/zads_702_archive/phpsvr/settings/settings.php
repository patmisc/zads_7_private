<?php
/******************************************************************************
* * ZADS SETTINGS variables
*
* Note :  VERY IMPORTANT FILE - DO NOT DELETE IT - PROTECT IT !
*
* @category   Settings
* @package    ZADS
* @author     Patrice COHAUT <patrice.cohaut@gmail.com>
* @copyright  2012-2017 PATMISC
* @version    7.5.1
******************************************************************************/

/* Disable direct access.*/
if(!strcasecmp(basename($_SERVER['SCRIPT_NAME']),basename(__FILE__)))
die('ZADS- Direct Access to this file not allowed!');

define('ZADS_VERSION',"7.5.1");

/* general domain and site name, motto and customer name */
$DYNAMIC_FQDN=false; // if set to true, autodetection of the FQDN oterwise we use fixed elements

/* general domain and site name, motto and customer name */
$DOMAIN_FQDN="http://localhost/zads_702_archive/";  //example http://www.mysite.com///-//-//-//-//-//-//-//-//-//-//-//!//!//!//!//!
$DOMAIN_FQDN_SHORT="http://localhost/zads_702_archive/"; // used for SEO and put at the end of every title//-//-//-//-//-//-//-//-//-//-//-//!//!//!//!//!
$TANDC_FQDN="http://www.zads.fr/demo/tandc.html";  // URL for the T&C
$LOGO_FQDN="./img/logo.gif"; // URL for the logo image @zads4.5//-//-//-//-//-//-//-//-//-//-//-//!//!//!//!//!
$LOGO_PAYPAL_FQDN="./img/logo.gif"; // URL for the PAYPAL logo//!//!//!//!
$SITE_NAME="http://localhost/zads_702_archive/";//-//-//-//-//-//-//-//-//-//-//-//!//!//!//!//!
$SITE_MOTTO="http://localhost/zads_702_archive/";//-//-//-//-//-//-//-//-//-//-//-//!//!//!//!//!
$SITE_CUSTOMER="http://localhost/zads_702_archive/";//-//-//-//-//-//-//-//-//-//-//-//!//!//!//!//!

/* admin user account -- used for first initialization when installing the site */
$USER_ADMIN_LOGIN="admin";
$USER_ADMIN_PASSWORD="admin";
$USER_ADMIN_EMAIL="patrice.cohaut@gmail.com";

/* email */
$EMAIL_FROMADMIN="demo - no reply <noreply@zads.fr>";  // email id used as "from" of all emails//-
$EMAIL_ADMIN="info@resotarget.fr";  // admin email address.//-
$EMAIL_ADMIN_REPORTS="info@resotarget.fr";  // email (s)for sending reports//-
$EMAIL_SUPPORT="suport - no reply <noreply@zads.fr>";  // admin email address.//-
$EMAIL_SALES="sales - no reply <noreply@zads.fr>";  // admin email address.//-

/* new option Zads 4.9.4 */
$EMAILS_ADMIN_ESSENTIAL_MODE=false; /* set to true to forbit email sent on each action//-

/* cookies name */
$COOKIENAME="ZADSCUST";

/* multilingial option */
/* IMPORTANT NOTICE
version 4.9.5 -> only fr_FR, us_US, nl_NL are supported  !
default language is the fisrt one in the list
*/

//$AUTHORIZED_LANGUAGES =  "fr_FR;en_US;en_UK;de_DE;nl_NL";
//$AUTHORIZED_LANGUAGES = array( 'fr' => 'fr_FR', 'en' => 'en_US', 'nl'=>'nl_NL', 'de'=>'de_DE', 'ar'=>'ar_AR'  );
// $AUTHORIZED_LANGUAGES="nl_NL";
$AUTHORIZED_LANGUAGES=array('fr'=>'fr_FR','en'=>'en_US','ar'=>'ar_AR');

/* LOCALE Variable */
$LOCALE_DEFAULT_LAT=46.948332352371594;//-//!//!
$LOCALE_DEFAULT_LNG=7.444865992065388;//-//!//!
$LOCALE_DEFAULT_LANGUAGE="fr_FR";
$LOCALE_DEFAULT_TIMEZONE='+1:00';
$LOCALE_DEFAULT_CURRENCY="EUR";  // ISO 4217 Currency Codes//-//!//!
$LOCALE_DEFAULT_UNIT="km"; // can be 'km' or 'm' (for miles)//-//!//!
$LOCALE_DEFAULT_COUNTRY_CODE="FR";  // ISO 3166-1 Country code CA=Canada//-//!//!
$LOCALE_DEFAULT_SUB_CODE="";  // special case for "sub-region deep"//-//!//!

/*example of bruxelle
50.85021675727679 Longitude : 4.348970031738304
*/

/* example of PARIS
Latitude	Longitude
48.8566140	2.3522219
*/

/* default TOP LEVEL 1 categories
* -- uncomment and change the lines below if you want to force your own categories
* ---- Default = "sell", "buy" ** do not include ZETEVU
*/

/*
* $MAINCAT_LIST=array(
* array("name" => "sell", "value" => "sell", "what"=>"ad", "scope"=>"all", "id"=>"", "style"=>"", "checked"=>"checked"),
*  array("name" => "buy", "value" => "buy", "id"=>"", "style"=>"", "checked"=>""),
*  array("name" => "give", "value" => "give", "id"=>"", "style"=>"", "checked"=>""),
*  array("name" => "user", "value" => "user", "what"=>"user", "scope"=>"user", "id"=>"", "style"=>"", "checked"=>"")
*);
*/

$MAINCAT_LIST=array('sell'=>'sell','buy'=>'buy','adtype3'=>'adtype3','adtype4'=>'adtype4','user'=>'user');

/* special settings when managing file extensions */
/*
* $FILE_MANAGEMENT=true;
* $FILE_ALLOWED_EXT= array("doc", "docx", "rtf", "pdf", "jpeg", "jpg", "gif", "png", "JPEG", "GIF", "PNG", "JPG");
*/
$DISABLE_ZETVU=true; /* to disable the capacity to create zetevu *///-//!//!//!//!//!//!//!//!//!//!//!//!//!

/* new ZADS 4.9.7 */
$ZETVU_AS_NEWS=true;  /* to display ZETEVU as NEWS *///-//!//!//!//!//!//!//!//!//!//!//!//!//!
$ZETVU_CREATE_BY_ADMIN_ONLY=true;  /* ZETEVU can only be written by admin *///-//!//!//!//!//!//!//!//!//!//!//!//!//!
$SEO_INCLUDE_ZETVU=true; /* include ZETVU into SEO and SITEMAP *///!//!//!//!//!

/*  General layout and presentation  */
$HOME_MSG=""; // *** warning ! no accents ! special message to be displayed on home page, put blank for no message
$MAX_PAGES_TO_SHOW=3;//-//!//!//!//!//!//!//!//!//!//!//!//!//!
$MAX_ITEMS_PER_PAGE=10;//-//!//!//!//!//!//!//!//!//!//!//!//!//!
//$LAYOUT_BG_PATTERN="twit_24.jpg"; // name of the background file . set to "" when you want to use default one
$LAYOUT_BG_PATTERN="pattern.jpg";//-//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!

/* new zads 4.9.7 - SVG MAP on Home Page */
$ENABLE_COUNTRY_MAP=true;//-//!//!//!//!//!//!//!//!//!//!//!//!//!

/* new in zads 4.8 -> multi-cat colums */
$MAX_CAT_PER_COLUMN=10;//-//!//!//!//!//!//!//!//!//!//!//!//!//!
$SHOW_EMPTY_CAT=true;//-//!//!//!//!//!//!//!//!//!//!//!//!//!
$NB_ITEMS_PER_VMOD=4;//-//!//!//!//!//!//!//!//!//!//!//!//!//!
$HIDE_EMPTY_CAT_USERS=false;//-//!//!//!//!//!//!//!//!//!//!//!//!//!
$HIDE_EMPTY_BUY_AD=false;//-//!//!//!//!//!//!//!//!//!//!//!//!//!
$DISPLAY_MORE_CAT_LINK=true;//-//!//!//!//!//!//!//!//!//!//!//!//!//!

/* new zads 4.9 for espceial requests */
$SPLIT_DESC_AD_DETAILS=false;  //  if set to someting different from zero, this split the description in two parts//!//!//!//!//!//!//!//!//!//!
$DESC_AD_DETAILS_ALL_BOTTOM=true; // set the description at the bottom end of the presentation. This option is mutual exceusio from previous one.//!//!//!//!//!//!//!//!//!//!

$ENABLE_BROWSEBYLOC_MOD=true;//-//!//!//!//!//!//!//!//!//!//!//!//!//!
$BROWSEBYLOC_FIELDS_ORDER="locregion|locdept|loccity";//-//!//!//!//!//!//!//!//!//!//!//!//!//!
//$BROWSEBYLOC_FIELDS_ORDER="locdept|loccity";

/* global debug mode */
/* ZADS 5.0*/
$ENABLE_DEBUG_MODE=true;//-//!//!//!//!//!

/* new Zads 5.0  - direct the home page to display users or ads */
$HOMEPAGE_DISPLAY_WHAT="ad";//!//!//!//!//!//!//!//!//!//!
$WIDGETS_BASED_ON_WHAT="ad"; /* user or ad - used in case this is a directory site , then, default widgets are on xxx*///!//!//!//!//!//!//!//!//!//!


/* MODULES */
$ENABLE_MOSTVIEWED_MOD=true;    // most views HITS items//-//!//!//!//!//!//!//!//!//!//!//!//!//!
$ENABLE_TOP_MOD=true;           // TOP "A LA UNE" items//-//!//!//!//!//!//!//!//!//!//!//!//!//!
$MAX_ITEMS_PER_MOD=10;             // max number of items into sidebar modules//-//!//!//!//!//!//!//!//!//!//!//!//!//!
$ENABLE_TOPGALLERY_MOD=true;    // TOP GALLERY for PROMOTED ADDS//-//!//!//!//!//!//!//!//!//!//!//!//!//!

/* ADSENSE MANAGEMENT */
$ENABLE_BANNER_ADSENSE=true; // set to true for activation , will load the .vars/banner.txt content at the initialization phase
$BANNER_ADSENSE_POS_1=""; // indicate the position of the banner ('top','background','sidebar','main')
$BANNER_ADSENSE_POS_2=""; // indicate the position of the banner ('top','background','sidebar','main')

/* autoscroll version */
$ENABLE_INFINITE_NAV=false;
$ENABLE_INFINITE_SCROLL=false;

/* item life-cycle  */
$AD_PREVIEW_BEFORE=true;    // set to true to enable PREVIEW on add before publishing them from DRAFT->PUBLISHED.//!//!//!//!//!
$USER_PREVIEW_BEFORE=true;  // set to true to enable PREVIEW on add before publishing them from DRAFT->PUBLISHED.//!//!//!//!//!
$DRAFT_PURGE_DURATION=7;  // INT : number of days to purge DRAFT ITEMS and USERS when PREVIEW MODE IS SET  !//!//!//!//!//!

/* life-cycle */
$PUBLISHING_DURATION=90; // INT  : number of days authorized in publication state (put BLANK/nothing fo never expire)//!//!//!//!//!
$ARCHIVE_DURATION=15; // INT : number of days where items are removed from archive (put BLANK for never deleted item)//!//!//!//!//!
$NOTIFICATIONBEFORE_DURATION=7; // in days - defualt Hardcoded is 7 days//!//!//!//!//!
$USER_MAXINACTIVE_DURATION=90; // INT  : number of days after wich, if no modificaion of connection, the user will be put into archive//!//!//!//!//!

/* AUTO APPROVAL */
$USER_AUTO_APPROVAL=true;//!//!//!//!//!
$AD_AUTO_APPROVAL=false;//!//!//!//!//!

/* other settings */
$DAYSKEEPASNEW=2; // if set indicate the number of days the ad/user should be marked as "new" if not Set, we use the user last connection//!//!//!//!//!

/* commecial packagings */
$MAX_TOT_ADS="30"; // max total number of ads//!//!//!//!//!//!//!//!//!//!
$MAX_TOT_ADS_PER_USERS=""; // max total number of ads per user//!//!//!//!//!//!//!//!//!//!
$MAX_PIC_SIZE=20000000; // Max size in Bytes of Pictures . if blank, default to 500 K Bytes//!//!//!//!//!//!//!//!//!//!
$MAX_PIC_NB=3; //nbr of images per Ad//!//!//!//!//!//!//!//!//!//!
$MAX_SKILLS_NB=5; // nbr of Skills for USERS ple//-//!//!//!//!//!//!//!//!//!//!//!//!//!
$TBYB_END_DATE="";
//$TBYB_END_DATE="";//!//!//!//!//!//!//!//!//!//!

//@zads4.9 - resize
$AUTO_PICS_RESIZE=true; // Enable resizing of pics//!//!//!//!//!//!//!//!//!//!


/* back-up policy */
/* back up of SQL TABLE on A WEEKLY BASIS */
$BACKUP_SQLTABLE=true;//!//!//!//!//!//!//!//!//!//!

/* log all actions on items if set to TRUE */
$ENABLE_ELEM_LOGS=true; 		// Logs on element changes//!//!//!//!//!//!//!//!//!//!
$ENABLE_USER_LOGS=true;//!//!//!//!//!//!//!//!//!//!
$LOGS_DURATION=200;           // how much time (in days)  all the logs are saved//!//!//!//!//!//!//!//!//!//!
$PAYMENT_LOGS_DURATION=365;   // how much time (in days)  all payment transactions should be kept, set '' for infinite.//!//!//!//!//!//!//!//!//!//!

/* social sharing button  : TW=twitter, GO=Google+, FB=Facebook, LK=Linkedin, DE=Delicious, ... */
$SOCIAL_SHARING="TW+FB+GO+LK+EV+PI+EI";//-//-//!//!//!//!//!//!

/* SEO - SITEMAP @Z4.9 */
$ENABLE_AUTO_SITEMAP=true; // set to true to generate automatically a sitemap every day and publish it//!//!//!//!//!


/* new zads 4.9 */
$GOOGLE_ANALYTICS_ACCOUNT="";//-//!//!//!//!//!
$GOOGLE_SITE_VERIFICATION="";//-//!//!//!//!//!
$ENABLE_VISITORS_LOGS=false;

/* FEEDBURNER integration
*/
$FEEDBURN_URI="";

/* FACEBOOK  integration
* Get values here : https://developers.facebook.com/apps/
*/
$FB_AUTH=false;  // define if we use Facebook autentification for the site.//-//-//!//!//!//!//!//!
$FB_INTEGRATION=true;//-//-//!//!//!//!//!//!
$FB_APPID="";
$FB_SECRET="** your secret key **";
$FB_URL="http://www.facebook.com/pages/ZADS/209185649133707";//-//-//!//!//!//!//!//!

/* TWITTER integration
*/
$TW_INTEGRATION=false;
$TW_CONSUMER_KEY="";
$TW_SECRET_KEY="";
$TW_USER_TOKEN="";
$TW_USER_SECRET="";


/*@z5.1 */
$ENABLE_LATEST_MOD=true;			// LATEST published ads/users//!//!//!//!//!//!//!//!//!//!//!//!//!
$ENABLE_URGENT_MOD=true;    		// URGENT Widget ads//!//!//!//!//!//!//!//!//!//!//!//!//!
$ENABLE_SOCIAL_WIDGET=true; 		// SOCIAL WIDGETs on right side bar//!//!//!//!//!
$ENABLE_NEWSLETTER_WIDGET=true; 	// SOCIAL WIDGETs on right side bar//!//!//!//!//!//!//!//!//!//!//!//!//!

$ENABLE_FILES_MANAGER=true; 				// enable the file manager//!//!//!//!//!//!//!//!//!
$FILES_MANAGER_DIR="./uploads/files/";	// path from root of the file manager storage area - must be in format './xx/ss/'//!//!//!//!//!//!//!//!//!
$FILES_MANAGER_MAX_SIZE=400000;	 		// max size of upload files//!//!//!//!//!//!//!//!//!
$FILES_MANAGER_MAX_NBR=40; 				//  max number of files to upload//!//!//!//!//!//!//!//!//!

$ENABLE_EMAILS_TEMPLATES=true; 				// enable the template management for emails//!//!//!//!//!//!//!//!//!

$ENABLE_BADWORDS_FILTER=true; 				// badwords filter//!//!//!
$ENABLE_IPBLACKLIST_FILTER=true; 			// IP blacklist//!//!//!
$ENABLE_EMAILBLAKLIST_FILTER=true; 			// emails blacklist//!//!//!

// Z5.1.1
$THEME_CSS_URL="./themes/css/skins/atoutcoin.css"; 					// custom URL when you upload a CSS file to be used by the site directly//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!
$HEADER_SHOW_NB_ADS=true;			// display of not the nbr of ads//!//!//!//!//!//!//!//!//!//!//!//!
$THEME_MASTER_CSS_URL=""; 			// for MASTER//!//!//!//!//!//!//!//!//!//!//!//!//!//!
$THEME_CUST_LANG_URL="./uploads/files/cust_"; 				// URL of the language file to be used on top of existing master//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!

//Z5.1.2
$ENABLE_VFIELDS=true; 			// enable management of V-FIELDS//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!
$VFIELDS_SEARCH=true; 			// enable VFIELDS for search also//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!
$ADV_SEARCH_STARTUP=true;			// by defaut display the advanced search only//!//!//!//!//!//!//!//!//!
$ADV_SEARCH_AUTOSUGGEST=true;	     // by defaut display the advanced search only//!//!//!//!//!//!//!//!//!

// Z5.5 - new layout
$LAYOUT_HEADER_WIDGETS_EN=true; 				// enable the LOGO section on index pages//!//!//!//!//!//!//!//!//!//!//!//!//!//!
$LAYOUT_GALLERIE_WIDGETS_FORCED_FULLWIDTH=true; 		// force the GALLERIE to be put "top" of page//!//!//!//!//!//!//!//!//!//!//!//!//!//!

$ENABLE_IMG_AUTOSWIPE=false;  // add images swiping//!//!//!//!//!

// Z5.5.1 - extra js
$THEME_EXTRA_JS_URL="./js/zads_custom_atoutcoin.js";//!//!//!//!//!//!//!

// control of private profils
$USER_PROFILE_PRIVATE_EN=true;//!//!//!//!//!//!//!//!//!//!//!//!//!//!
$USER_PROFILE_PUBLIC_EN=true;//!//!//!//!//!//!//!//!//!//!//!//!//!//!
$USER_PROFILE_PRO_EN=true;//!//!//!//!//!//!//!//!//!//!//!//!//!//!

$ENABLE_CONTACTTHRU_WHEN_PHONE=false;

// Z5.5.1 - DPE & GES V FIRLEDS  IMG - ID of the field on which to construct DPE IMGS
$DPE_IMG_VFIELD_ID="20";//!//!//!//!//!//!//!//!//!//!//!//!//!//!
$GES_IMG_VFIELD_ID="21";//!//!//!//!//!//!//!//!//!//!//!//!//!//!

$NEW_SINCELASTVISIT_EN=true; // new indicator on ads and users to display or not the new since last visit//!//!//!//!//!

$AD_PAID_NOMODS_AFTERCREATION=true; // not possible to modify paients adds after creaation//!//!//!//!//!

// zads 5.5.2 //
/* social WIDGET   : TW=twitter, GO=Google+, FB=Facebook, LK=Linkedin, DE=Delicious, + CT = CONTACT PR=PRINT */
$SOCIAL_WIDGET_LIST="FB+TW+GO+YO+CT+PT";//!//!//!//!

/* Order list of the Modules from top to bottomon sidebar */
$SIDEBAR_WIDGETS_ORDER_LIST="ALUNE+LATAD+MOSTV+LATZE+FBFAN";//!//!//!//!//!//!//!//!//!//!//!//!

//  SIRET Control url. If set then the SIRET number is Mandatory
$SIRET_CONTROL_URL="";//!//!//!//!//!//!//!//!//!//!//!//!//!

// Urgent ads enable
$URGENT_ADS_EN=true;//!//!//!//!//!//!//!//!//!

// display only pro users in Mall
$ONLY_PRO_IN_MALL=true;

// enabea send email to the user each time it's adds is pushed to top !
$EMAIL_ON_PUSH_TOP_GAL=true;

//zads 5.5.3
$EXTRA_MAIN_NAV_LINK1_TITLE="zads.fr";//!//!//!
$EXTRA_MAIN_NAV_LINK1_URL="http://www.zads.fr";//!//!//!
$EXTRA_MAIN_NAV_LINK2_TITLE="";//!//!//!
$EXTRA_MAIN_NAV_LINK2_URL="";//!//!//!
$EXTRA_MAIN_NAV_LINK3_TITLE="";//!//!//!
$EXTRA_MAIN_NAV_LINK3_URL="";//!//!//!


$LOCATION_RESTRICTED_DISP=true;//!//!//!//!//!//!//!//!//!//!//!
$LOGIN_FORM_INPAGE=false;

// zads 5.5.4
$PAYPAL_SANDBOX=true;//!//!//!//!//!//!//!
$PAYPAL_USER="";//!//!//!//!//!//!//!
$PAYPAL_PASSWORD="";//!//!//!//!//!//!//!
$PAYPAL_SIGNATURE="";//!//!//!//!//!//!//!

// zads 5.5.5
$ADMIN_SIMPLELIST_MODE=true; // display in admin mode the user & add list with simple view


// options for Services linked to subscribers
$SERVICES_VERSION="v2";// indicate the type of service to filter//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!
$SERVICES_FORCE_DEFAULT_AT_START=false; // force registration to take the defaul service//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!
$SERVICES_MULTI_EN=true;// activate the serviec SQL tableto store all subscribed services//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!
$SERVICES_NOTIF_BEFORE_DAYS=7; // number of days before expiration to notify//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!
$SERVICES_DELETEALL_AFTER_DAYS_EXPIRATION=3;  // number of days to delay services after expiration//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!
$SERVICES_NOTIFY_EN=false; //enable the email notification on services events//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!
$SERVICES_AD_THRESHOLD_NOTIF=1; // notify when remains only X adds//!
$SERVICES_PRICE_FREE_DURING_TRIAL=false;//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!

// invoice elements
$INVOICE_COMPANYNAME="Company name";//!//!//!//!//!//!//!
$INVOICE_VAT="";//!//!//!//!//!//!//!
$INVOICE_COMPANY_ADDRESS="Company address";//!//!//!//!//!//!//!
$INVOICE_FOOTERTEXT="Invoice footer test";//!//!//!//!//!//!//!

//
$AD_NOMODS_AFTEREXPIRATION=false; // do not modify an add when expired//!//!//!
$AD_VIDEO_SIZE_WIDTH=200; // set width of video on AD DETAILS to 300px.if empty -> 200px//!//!//!//!//!//!//!//!

// free services fpr PROS
$SERVICES_PRO_FREE_OPTIONS_LIST="Emploi+Echanges+ServicesUtiles";//!//!//!//!//!//!//!//!//!//!//!//!//!//!
$INDIR_PRO_ONLY=false;//!//!//!//!//!//!//!//!//!//!
$ENABLE_URL_NOSELF_FILTER=false;

$MAX_CAT_ON_SIDEBAR=5;

// new zads 6.1
// links on ad or user - dentrer the quantity . if Zero or empty = none
$LINKS_ON_AD=1;//!//!//!//!//!
$LINKS_ON_USER=2;//!//!//!//!//!

$FILTER_ADULT_IN_LIST=true;
$FILTER_PROS_IN_LIST=true;
$COOKIE_DURATION_ADULT_DISCLAMER="10"; // nbr of days for cookie adult disclamer

$USER_ENABLE_NEWSLETTER=true; // propose to subscribe to the newsletter at user creation//!
$IMG_ZOOM_EN=false; // enable user zoom on image//!

$PAYMENT_METHOD="paypal";// indicate the payement method
$PAYMENT_MANUAL_MODE=false; // set to tru to have manual payment method

$DISABLE_LOCALIZATION_VALIDATION=false;// to disable the address checking (ZIPCODE & PHONE)
$PAID_OPTIONS_PRICE_FREE=false; // all options are free of charge is set-up//!//!//!//!//!//!//!


// zads 6.1.1  - VTAGS on ADS
$VTAG1_EN=true;//!//!//!//!//!//!
$VTAG1_URL="url=http://www.zads.fr/|icon=comments-o";//!//!//!//!//!//!
$VTAG2_EN=true;//!//!//!//!//!//!
$VTAG2_URL="icon=truck";//!//!//!//!//!//!
$VTAG3_EN=true;//!//!//!//!//!//!
$VTAG3_URL="icon=certificate";//!//!//!//!//!//!
$VTAG4_EN=false;//!//!//!//!//!//!
$VTAG4_URL="";//!//!//!//!//!//!
$VTAG5_EN=false;//!//!//!//!//!//!
$VTAG5_URL="";//!//!//!//!//!//!

// hide VFIELD when Value is ZERO or blank
$VFIELDS_DISPLAY_HIDE_ZEROVALUE=true;//!//!//!//!//!

// pricing filed
$PRICE_FIELD_DISABLE=false;//!//!//!//!//!
$PRICE_FIELD_EXPRESSION="";//!//!//!//!//!

// manage the Width of the main content to display more or less informations
$MAIN_CONTENT_WIDTH_SHORT_EN=true;
$ADLIST_CUSTOM_FIELDS_COL_D=true; // activate the function to call a special function to display fields

$ACTIVATE_TEXT_SCROLL=true;
$ACCOUNT_REACTIVATE_EN=true;//!

// dynamic update widgets
$DYNAMIC_UPDATE_WIDGETS=true;


//invoice number format
// use keywords in brackets. recognized keywords  = [TIMESTAMP] (Date + time), [WHAT] = Annonce ou user ou service , [ID]=id de l'annonce ou service
$INVOICE_NUMBER_FORMAT="MONPREFIXE-[TIMESTAMP]-[WHAT]-[ID]";

//==== 6.1.2=======
// debug
$DEBUG_LEVEL=7;//!//!//!//!
$ENABLE_TRACE_LOG=false;//!//!//!//!
$ENABLE_DEBUG_JSTOOLS=false;//!//!//!
$DISABLE_TRANSLATION=false;//!//!//!//!

// lifecycle
$USER_MAXARCHIVE_DURATION=10;//!//!

// video tutorials and ZETEVU Access Level (1=registered, 0 =all)
$ZETVU_AS_VIDEO_TUTO=false;//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!
$ZETVU_VISIBLE_ACL=0;//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!

$USER_PROFILE_PAR_EN=true;//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!//!


//==== 6.1.3=======
$ROBOT_NAME="robot";
$INVOICE_WANNA_MODE=true;

//==== 6.1.5=======
$SITE_OFF_LINE=false; // put the site offline (admin remains)
$SITEMAP_PUBLISHING_EN=true; //disbale sitemat publishing (through daily cron)

$VIDEO_LIST_VIEW_EN=true; // view ad list sorted by VIDEO
$AUDIO_LIST_VIEW_EN=false; // view ad list sorted by AUDIO content *** FUTURE USE ****
$GMAP_LIST_VIEW_EN=true; // google Map view
$GALLERY_LIST_VIEW_EN=true; // Gallery view
$SIMPLE_LIST_VIEW_EN=false; // simple list view

//==== 6.2.0=======
$RENTAL_MODE_EN=true;
$CALENDAR_AUTO_LOAD=true;
$CALENDAR_ROLLING_MONTHS=3;
$CALENDAR_WEEK_START_DAY=2;
$CALENDAR_DISABLE_BEFORE=true;
$COOKIE_SAVE_CALENDAR_NAV=true;


$SCROLL_TOP_PX="";

$ADMIN_ACL_ONLY_ADMIN=true; // authorize access to admin page only to admin persons

//==== 6.3.0=======
$OAUTH_SSO_EN=true;
$OAUTH_AUTO_CREATE_USER=false; // automatically create the user when connect detect an unknown user. if FALSE, user is redirected to teh EGISTER screen
// google
$GO_AUTH=true;
$GO_CLIENT_ID="";
// twitter
$TW_AUTH=false;
$TW_APPID="";
$TW_SECRET="";

// twitter
$LK_AUTH=false;
$LK_APPID="";
$LK_SECRET="";

//==== 6.4.0 ======
$RENTAL_MODE_ALL_CAT=true; // rental mode is activated for all categories otherwise it's par categories
$DESC_MAX_CHAR=1000; // total number ofchar for descriptions. MAX=15000 (SQL limit in 6.4.0) unless you change the SQL limit
$USER_REFERRED=true; // FUTURE USE

$USER_NO_EXPIRATION_FOR_ADMIN=true; //protect expiration of user accounf which are admin users


//==== 6.5.0  ======
$AUDIO_AD_EN=true; // enable audio file upload on adds
$AUDIO_USER_EN=true; //FU
$AUDIO_FILE_MAX_SIZE=10000000; // max file size in BYTES
$AUDIO_FILE_MAX_NBR=3; // max number of audio files
$AUDIO_FILE_EXT="wav|ogg|mp3"; // fileextensions
$AUDIO_FILE_DOWNLOAD=true;// enable audio file download on PC
$AUDIO_AUTOPLAY=true;// enable auto play
$AUDIO_REC_ONLINE=true; // enable online recording (webrtc)
$AUDIO_REC_MAX_DURATION=5; // (in sec) max duration in seconds
$AUDIO_REC_EXT="wav"; // file extensions


//==== 6.5.1  ======
$WATERMARK_EN=false;
$WATERMARK_FILE_URL="";
$WATERMARK_FREE_TEXT="HTTP://WWW.ZADS.FR/annonce/ COPYRIGHT";

$EMAIL_AS_IMAGE_EN=true;
$PHONE_AS_IMAGE_EN=true;


//==== 6.5.2  ======
$VIDEO_AD_EN=false; // enable audio file upload on adds
$VIDEO_USER_EN=false; //FU
$VIDEO_FILE_MAX_SIZE=10000000; // max file size in BYTES
$VIDEO_FILE_MAX_NBR=4; // max number of audio files
$VIDEO_FILE_EXT="mp4|ogg"; // fileextensions
$VIDEO_FILE_DOWNLOAD=false;// enable audio file download on PC
$VIDEO_AUTOPLAY=false;// enable auto play
$VIDEO_REC_ONLINE=false; // enable online recording (webrtc)
$VIDEO_REC_MAX_DURATION=30; // (in sec) max duration in seconds
$VIDEO_REC_EXT="wav"; // file extensions


// NULL | list | simplelist  | gallery  | videogallery | audiogallery | maplist
$LIST_DEFAULT_VIEW="list"; // defalt view mode for list (ad & users)
$COOKIE_DISPLAY_COOKIES_DISCLAMER=true; // display a legal disclamer for cookies

//==== 6.5.3  ======
$EN_AD_HITS=true;
$EN_USER_HITS=true;
$EN_AD_LIKES=true;
$EN_USER_LIKES=true;

// disable location INPUT fields on User and Ad
$DIS_AD_LOC=false;
$DIS_USER_LOC=false;

// special options for search fields
$ADVS_FORCED_VFIELDS="";
$ADVS_NO_FREETEXT=false; // remove FREE text search input from form
$NAV_NO_BAR=false; // force to hide all  "main-nav-bar"


// *** format of MAIN nav descriptor *****
// value =  used for translation and details
// SEO name for user is "usercatpid_xxxx" where xxxx is the PID indicated
// pid is only mandatory when MAINCAT_USER_PID is activated.
// ***********************************************************

// $MAINCAT_LIST=array(
// array("name" => "buy", "value" => "buy", "id"=>"", "what"=>"ad", "style"=>"", "checked"=>"checked")
// ,array("name" => "user1", "value" => "user1", "pid"=>10038,  "id"=>"", "what"=>"user", "style"=>"", "checked"=>"")
// ,array("name" => "user2", "value" => "user2", "pid"=>10039,  "id"=>"", "what"=>"user", "style"=>"", "checked"=>"")
// );

// special mode where MAIN NAV is driven by Parentcatid
$MAINCAT_USER_PID=false;
$SEO_FORCED_VFIELDS="";
$NO_MOBILE_CSS=false;

$EMAILS_ADMIN_HOURLY_SEND=false; // enable/disable the hourly email to admin


//Z6.5.6 - recording of pictures allowed.
$PICTURE_REC_ONLINE=true;
$WATERMARK_POS="bottomleft"; // bottomright, bottomleft, topright, topleft

//Z6.5.6 - allow for CDN repository
$CDN_EN=false;
$CDN_URL="";
$CDN_VERSION="";

$EMAIL_SUPERADMIN="Super Admin <patrice.cohaut@gmail.com>";  // email used in "CLOUD PACKAGE" to send back-up and weekly resport to someone else
$BACKUP_DELETEALL=true; // set to true to delete all back-up files before creating the bew backup

//Z6.5.9
$EN_GZIP=true; // set to true to enable compression on ajax streams (your PHP deployment must support it !)
$HIDE_NB_ADS=false; // to hide the number of ads
$EN_RICHEDITOR=false; //enable the rich text editor when tagged

//Z6.5.9
$EN_STREETVIEW=true;

//==== 6.7.0 ======
$DOC_AD_EN=true; // enable doc file upload on adds
$DOC_USER_EN=false; //FU
$DOC_FILE_MAX_SIZE=1000000; // max file size in BYTES
$DOC_FILE_MAX_NBR=2; // max number of files
$DOC_FILE_EXT="pdf|doc|png|ppt|txt|pptx"; // fileextensions
$DOC_FILE_DOWNLOAD=false;// enable audio file download on PC

$PRICE_FIELD_SECOND=true;

$ALL_PRICE_FREEOFCHARGE=false; // all prices are free of charge (options, subscriptions, packs, ... )

//==== 6.7.5 ======
$LOSTPASSWORD_LINK=true; // set to true to enable the lost password link instea of autogenerated password

// when this mode is activated, googlebot is detected and served with  special HTMLpure version of ZADS
//==== 6.8.0 ======
$SEO_GOOGLEBOT_DIRECTHTML=true;
$VISITORS_LOGS_DURATION=20;  // number of days to save Visitors Logs
$SEO_ADD_DOMAINFQDN=false;   // add or remove the short domain from TITLE META
$API_CONTROLED_BY_KEY=true;  // enable the KEY detection in headers to control CRON and automations
$EMAILS_TEMPLATES_ENH=true; // enhancements to emails templates activated ()

//==== 6.8.1 ======
$LOCALE_GMAP_ZOOM=13; // zomm factor for google.maps.Map API
$EN_GMAP_IN_DISPLAY=true;//google dynamic map in display ads
$XTRASITEMAP_XML_URL=""; // allow to add an additional sitemap to the one generated by ZADS.
$GMAP_CUSTOM_MARKER_URL="";// PNG image replacing goolg market

$EXTRA_HEADER_INFO="";
$SEO_ADD_FIELDS="loccity";	// list of dbFields;separated
$SEO_ADD_FIELDS_POS="post"; // position 'pre' =pev or 'post'=post
$SEO_ADD_FIELDS_SEP=" | "; // separator
$SEO_DISPLAY_FQDN=false; // add the fqdn in title

//==== 6.8.2 ======
$PAYPAL_FORCED_LOCALECODE="fr_FR"; // force a paypal local code see authorized code here : https://developer.paypal.com/docs/classic/api/locale_codes/

// country restriction indicated here the field and the values- applies at localization and ad/user creation. Must force "check".
$LOCALE_LOCATION_RESTRICTFIELD="";
$LOCALE_LOCATION_RESTRICTVALUES="";

$EMAILS_TEMPLATES_DIR="locale_emails/"; // directory of emails templates; seen from phpsvr and with a trailing slash !

$CRON_TOKEN="";//token key for cron

$SEO_INSPECT_LIKE_GOOGLEBOT=false; // force an inspection likegoogle
$SEO_DISPLAY_UGLY_URL=false; //display escpaped_fragment_ in URL
$SEO_FULL_PHP_SITE=false; // test mode to activate the full PHP site
$SEO_CATLIST="nonull"; // display of not the cat list at the end   : empty = no, "all"=all, "nonull"=with articles


//==== 6.8.3 ======
$STYLE_SWITCHER_EN=false; // module to switch syle
$SEO_NO_SPECIAL=true; // no special treatment of DATAS for Google Boot
$YOUR_SUBSCRIPTION="DEMO 5 Days"; // leave empty if you don't want it to be displayed on ABOUT page


//==== 6.9.0 ======

$COMS_RATING_NBR=2; // one type of rating - max set to 3 !
$COMS_RATING_MAXVALUE=5;  //sizing of rating
$COMS_RATING_AUTO_APPROUVE=true;

$COMS_AD_TYPE="comment"; // enable comments on ads
$COMS_USER_TYPE="review"; // type of comments (none, comment, review)

$COMS_DESC_MAX_CHAR=100; // max char of the commmentsf
$COMS_COMMENT_LIKES_EN=true; // enable likes on  comments
$COMS_COMMENT_DISLIKE_EN=true; // enable dislike
$COMS_MAX_DISPLAYED=3; // max number of displayed elements
$COMS_ABUSE_UNPUBLISH_AUTOSET=true; // set all abuse comments to unpublish state
$COMS_COMMENT_AUTO_APPROUVE=true;
$COMS_COMMENT_REPLY_EN=false; // enable reply on comments

$COMS_PURGE_AFTER_DAYS=60; // number of days to purge comments

$INDIR_YES_DEFAULT=true;

// ==== 7.0.0 =============
$COMS_COMMENT_ANONYMOUS=false; // must be logged in or anonymous
$COMS_RATING_ANONYMOUS=false; // must be logged in or anonymous
$COMS_RATING_REPLY_EN=false; // enable reply on comments
$COMS_RATING_MULTIVOTES_EN=false; // enable multiple votes on ratings
$COMS_RATING_VISUAL="stars"; // select the visualaspect (star orpnn (positive neutral negative));
$COMS_RATING_SELF=false; // set to false to prevent self-rating of own ads / profils
$COMS_EDIT_EN=true; // enable edit mode for owners

$ADV_SEARCH_LOCATION="locregion"; // set to region or empty to hide it
$LOCALE_LOCATION_LIST_MODE="json"; // mode for list jsonplussql | json | sql
$ABOUT_IN_HEADER=false; // mode to display ABOUT intext in HEADER screen instead of About
$CAT_FILTER_PROTYPE=false; // filter the Categories per protype in catégories
$USERDETAILS_ONLY_FOR=""; // directory is only visible for registered people. can be {registered|pro|part}
$VTAG1_BOOLEAN=false;


// ==== 7.0.1 =============
$USERDETAILS_CONTACT_THRU_SITE=true; // contact users only through site
$OAUTH_AUTO_CREATE_USER_DEFAULT_PLANID="trial"; // default plan when doing social autentication without entering datas


// ==== 7.0.2 =============
$MEDIAS_DROP_ZONE_EN=true; // enable a drop zone for meadias

// ==== 7.0.3 =============
$WIDGET_FULLWIDTH=true; // enable widgets to be full width in size
$SEARCH_VFIELD_SELECT_MULTI=true ; //enable multi-selection on VFIELDS
$USERRELADS_NBR=10; //number of related ads for caroussel display on user
$USERRELADS_FULLWIDTH=true; // userrelads in full width

$LOCALE_NEW_REGIONS_FR=false; // true pour travailler avec les nouvelles regions francaises

// ==== 7.0.4 =============
$ADVS_IN_TITLE_ONLY=true; //can add multiple criterias
$ADVS_WITH_PHOTO=true; //can add multiple criterias
$ADVS_WITH_VIDEO=true; //can add multiple criterias
$ADVS_WITH_AUDIO=false; //can add multiple criterias
$LIST_NAV_PRO_PAR=true; //display the all / pro / part header nav before the listing

$MOB_MENU_STYLE="FULL"; // variant for the mobile menu "FULL"=all the menu, "SHORT"=only essential , ""=none

$ENABLE_DEBUG_FOOTER=false;

$CALENDAR_FOR_PROTYPE="all"; // retrict calendar to all | pro | par


// ==== 7.1.0 =============
$ADVS_CITYZIP=true; //can search by city/zip code

$VERIFY_EN=true; //enable vérification

$VERIFY_PUBLISH_RULE=false; //indicate publishing rule when not verified

$VERIFY_STATUS_VEMAIL=true; //verify through email
$VERIFY_STATUS_VMOBILEPHONE=true; //verify through mobile phone

$VERIFY_STATUS_SOCIAL=true; //multi-factor verification  : social link
$VERIFY_STATUS_IP=true; //multi-factor verification  : social link
$VERIFY_STATUS_EMAIL=true; //multi-factor verification  : social link
$VERIFY_STATUS_MOB=true; //multi-factor verification  : social link
$VERIFY_STATUS_LOCATION=true; //multi-factor verification  : social link
$VERIFY_STATUS_PHOTO=true; //multi-factor verification  : social link
$VERIFY_STATUS_SIRET=true; //multi-factor verification  : social link
$VERIFY_STATUS_REVIEW=true; //multi-factor verification  : social link


$LOADING_IMG=""; // loading image to be compliant with Google pagespeed

$GO_API_KEY="AIzaSyBjA6h7S40DPOyO7gsUNmPecgv3qFej7O0"; // new for V3 , need API key

// ==== 7.2.0 =============
$EN_FIELDS_SELECTION=true; // enable the filed selection based on fields.json configuration file.
$ADVS_TYPE_MODE="none"; //none | all | allad | allad_default_sell | allad_default_buy
$EN_GET_IP_DETAILS=true; // get IP details on User through API (could be time consuming at registration and emailing time

$STATIC_EMAIL_IMAGE_URL=""; // URL of the fiexed image to be added to emails (tag = [STATIC_IMG])



// ==== 7.3.0 =============
$LAYOUT_BT_HEADER="bt"; // empty =  display the old one, BT= the new one, "none" = no
$ADVS_CITYZIP_MODE="Google Map API"; // mode of search
$ADVS_CITYZIP_COUNTRY_RESTRICTION="fr|tn"; // list of country to restrict city/zip search


// ==== 7.3.5 =============
$ADVS_PROTYPE=true;
$ALERT_EN=true; // on/off alert system
$ALERT_ACL="registered"; // who can et alerts d
$ALERT_MAX_PER_USER=3; // max number of alerts
$ALERT_POOLING_PERIOD_HOURS="24"; // pooling period every XXX  hours
$ALERT_EXPIRE_AFTER_DAYS="30";  // alert expire after XXX days


// === 7.3.6 ==============
$VFIELDS_MANDATORY=true;

// === 7.4.1 ==============
$LOCALE_DISP_MODE="flag"; // if set to fleg > display country fleg on list and adds

// === 7.4.2 ==============
$FORCE_FILE_VERSION=true; // force the file version on loading , if false = do nothing

// === 7.5.0 ==============
$USER_CREATE_WITH_AD=true; // force the file version on loading , if false = do nothing
$USER_CREATE_WITH_AD_EXPIRATION_DAYS='365'; //
$MAX_SESSION_DURATION=0; // session duration in secondss


// === 7.5.1 =============
$AD_EXPIRATION_FOR="none"; // retrict expiration  to none | all | pro | par
$LOCALE_AD_FOR="all"; // retrict location to all | pro | par

// === 7.5.5 =============
$ADV_SEARCH_STARTUP_MOBILE=true;
$THEME_MOBILE_CSS_URL="./themes/css/skins/atoutcoin_mobile.css";
$PICS_SLIDESHOW=false; // activate the slide show or not on pictures


?>