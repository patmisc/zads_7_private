<?php
/******************************************************************************
* * ZADS SETTINGS variables
* 
* Note :  VERY IMPORTANT FILE - DO NOT DELETE IT
*  
* @category   Settings
* @package    ZADS
* @author     Patrice COHAUT <patrice.cohaut@gmail.com>
* @copyright  2010-2012 PATMISC
* @version    3.6
******************************************************************************/

/* Disable direct access.*/
if(!strcasecmp(basename($_SERVER['SCRIPT_NAME']),basename(__FILE__))) 
die('ZADS- Direct Access to this file not allowed!');

/* database access */ 
/* --- INSERT HERE YOUR DATABASE CREDENTIALS ---*/
define('ZADSINSTALLED',FALSE); // to indicate if already modified or not
/* database access */ 
/* --- INSERT HERE YOUR DATABASE CREDENTIALS ---*/
$DB_HOST="%CONFIG-DBHOST";
$DB_USERNAME="%CONFIG-DBUSER";  
$DB_PASSWORD="%CONFIG-DBPASS";  
$DB_PREFIX="%CONFIG-DBPREFIX"; 
$DB_NAME="%CONFIG-DBNAME"; 

/* default name of tables */  
$DB_TABLE_ITEMS="items"; 
$DB_TABLE_CATS="cats"; 
$DB_TABLE_USERS="users"; 
$DB_TABLE_STATS="stats";
$DB_TABLE_LOGS="logs";
$DB_TABLE_PAYMENTS="payments";
$DB_TABLE_BANNERS="banners";
$DB_TABLE_VISITORS="visitors";

/* zads 5.2 */
$DB_TABLE_SUBSCRIBERS="subscribers"; 
$DB_TABLE_VFIELDS = "vfields"; 

/* zads 6.0 */ 
$DB_TABLE_SERVICES="services";

// zads 6.2.0 
$DB_TABLE_BOOKINGS="bookings";
$DB_TABLE_PRICINGS="pricings";

// zads 6.7.0 
$DB_TABLE_KEYS="keys"; 

// zads 6.8.3 
$DB_TABLE_COMS="coms"; 



?>
