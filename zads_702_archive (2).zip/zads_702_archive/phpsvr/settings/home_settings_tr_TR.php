<?php

$cust_lang="tr";

// define variable to be used for a specific customer site on home page
$cust_title="Fransadaki Türklerin seri ilan sitesi | SSahibinden satılık, kiralık, ikinci el";//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!
$cust_motto= "Seri ilanlar | Ana Sayfa | ilannonce.fr";
$cust_name="İlannonce FRANCE"; // used for main title

$cust_description="www.ilannonce.fr www.ilannonce.fr www.ilannonce.fr www.ilannonce.fr www.ilannonce.fr www.ilannonce.fr www.ilannonce.fr www.ilannonce.fr";//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!

$cust_keywords="Fransadaki turkler, fransadaki turk site, fransadaki turk siteleri, bleu blanc turc, ilannonce.fr, annonces turcophiles, fransada'ki turklerin ilan sitesi, fransa ilan site, www.ilannonce.fr";//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!

$cust_site_name="SERİ İLAN SÍTESİ"; // TEST TO BE USED FOR SITE NAME//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!
$cust_site_motto="FRASANDA'Kİ TÜRKLERİN SERİ İLAN SİTESİ"; // TEST TO BE USED FOR SITE NAME//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!

$cust_site_owner_accronym="ILANNONCE FRANCE"; // TEST TO BE USED FOR T&C//!//!//!//!//!//!//!//!//!//!
$cust_site_owner_long="ILANNONCE FRANCE"; // TEST TO BE USED FOR T&C//!//!//!//!//!//!//!//!//!//!

$cust_logo_uri="http://ilannonce.fr/uploads/files/tmp_20150512-111808.png"; //logo of the company//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!
$cust_favicon_uri="http://ilannonce.fr/uploads/files/tmp_20150512-101416.png"; //logo of the company//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!

// deprecated  !!!!
$cust_logo_alt="Company name alt"; // name of the company attahced as ALT attribute to logo image

$cust_loading_msg="Seri ilan siteniz yükleniyor ...";//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!

// main footer :
$cust_facebook_url="https://www.facebook.com/ilannonce.fr";//!//!//!//!//!//!//!//!//!
$cust_twitter_url="https://twitter.com/ilannonceFR";//!//!//!//!//!//!//!//!//!
/* new Z4.9.7 */
$cust_gplus_url="https://plus.google.com/116527311501379386206/posts";//!//!//!//!//!//!//!//!//!

/* new ZADS 5.0 */
$cust_about_footer_desc="ilannonce.fr, Fransadaki Türklerin ilk seri ilan sitesi";//-//-//-//!//!//!//!//!//!//!//!//!//!

// low footer
$cust_tandc_url="http://www.ilannonce.fr//tandc_fr_zads.php";//!//!//!//!//!//!//!//!//!
$cust_pub_url="contact";//!//!//!//!//!//!//!//!//!
$cust_contactus_url="contact";//!//!//!//!//!//!//!//!//!
$cust_aboutus_url="http://www.ilannonce.fr/tandc_fr_zads.php";//!//!//!//!//!//!//!//!//!

$cust_faq_url="http://ilannonce.fr/uploads/files/FAQ.php";//!//!//!//!//!//!//!//!//!
$cust_demo_url="";//!//!//!//!//!//!//!//!//!
$cust_help_url="";//!//!//!//!//!//!//!//!//!



// zads4.9 - HTML SNAPSHOT for SEO

$trans = array();
$trans[$cust_lang_long]=array();
$trans[$cust_lang_long]['home']="Ana-Sayfa";
$trans[$cust_lang_long]['sell']="Satıyorum";
$trans[$cust_lang_long]['buy']="Arıyorum";

$trans[$cust_lang_long]['shops']="Butikler";
$trans[$cust_lang_long]['ad']="ilanlar";
$trans[$cust_lang_long]['cat']="Kategoriler";
$trans[$cust_lang_long]['user']="satıcı";
$trans[$cust_lang_long]['login']="giriş yapmak için";
//$trans[$cust_lang_long]['admin'] = "admin";
$trans[$cust_lang_long]['create_user']="kayıt olma";

$trans[$cust_lang_long]['edit_profile']="profili-düzenle";
$trans[$cust_lang_long]['create_ad']="ilan-oluşturmak";
$trans[$cust_lang_long]['create_cat']="kategori-oluşturmak";
$trans[$cust_lang_long]['myprofile']="profilim";
$trans[$cust_lang_long]['mydashboard']="Dashboardum";

$trans[$cust_lang_long]['dashboard']="Dashboard";


// zads4.9.7 - SEO for Region
$trans[$cust_lang_long]['region']="bölge";
$trans[$cust_lang_long]['dept']="il";
$trans[$cust_lang_long]['map']="harita";
$trans[$cust_lang_long]['zetevu']="zetevu";


// Z5.1
$trans[$cust_lang_long]['settings']="yapılandırma";

$trans[$cust_lang_long]['filesmanager']="dosyalarım";
$trans[$cust_lang_long]['vfieldsmanager']="yönetici-alanları";
$trans[$cust_lang_long]['emailsmanager']="yönetici-epostaları";



$trans[$cust_lang_long]['banners']="reklam";
$trans[$cust_lang_long]['create_vfield']="alan-oluşturmak";


$trans[$cust_lang_long]['add_service']="hizmetler-eklemek";
$trans[$cust_lang_long]['myservices']="hizmetlerim";
$trans[$cust_lang_long]['myinvoices']="faturalarım";



//  social youtube
$cust_youtube_url="https://www.youtube.com/channel/UCxxxxSmHUuf3J5tRHKgEwvw";//!//!//!//!//!//!//!


// z5.1 badwords (here because need to be localized)
$cust_badwords="conne|merde|pede|pédé|pedes|pédés|encul|bougnoul|connard|couille|branle|connasse|salope|bite|fuck|putain|trouduk|enfoiré|pédoque|gouine|tapette|baltringue|grognasse|pédale|pouffiasse|pétasse|enflure|bordel";//!

// z5.0.1 - STATIC page content - MAP
$page_map_first_p="";//!//!//!//!//!//!
$page_map_center_p="<div id='toto'  class='map_in_center' z-height='' z-width='' z-zoom='1.55' z-action='MAP'></div>";
$page_map_last_p="";//!//!//!//!//!//!

// z5.5.7 - add external HTML file
$page_home_url="";//!//!//!//!//!//!//!//!//!//!//!
$page_home_type_url=false; // indicate if we use url or fixed text//!//!//!//!//!//!//!//!//!


// régles générales de diffusion
$cust_rgda_url="http://www.ilannonce.fr/rgda_fr_zads.php";//!//!//!//!//!//!//!//!//!
$cust_pricing_url="";//!//!//!//!//!//!//!
$cust_whoweare_url="http://www.ilannonce.fr/tandc_fr_zads.php";//!//!//!//!//!//!//!
$cust_blog_url="";//!//!//!//!//!//!//!
$cust_forum_url="";//!//!//!//!//!//!//!


//6.4.0
$trans[$cust_lang_long]['ads']="yönetici-reklamlar";
$trans[$cust_lang_long]['cats']="yönetici-kategoriler ";
$trans[$cust_lang_long]['users']="yönetici-kullanıcılar";
$trans[$cust_lang_long]['bookings']="yönetici-rezervasyonları";
$trans[$cust_lang_long]['services']="yönetici-hizmetler";
$trans[$cust_lang_long]['logs']="yönetici-günlükleri";
$trans[$cust_lang_long]['subscribers']="yönetici-Aboneler";
$trans[$cust_lang_long]['invoices']="yönetici-fatura";
$trans[$cust_lang_long]['users']="yönetici-kullanıcılar";

//6.5.1
$cust_cookie_url="http://www.ilannonce.fr//tandc_fr_zads.php";


//6.5.3
$trans[$cust_lang_long]['usercatpid_10038']="user1";
$trans[$cust_lang_long]['usercatpid_10039']="user2";

//6.5.5
$page_home_is_php=false;
$page_home_php_url="home_page_alt.php";



?>