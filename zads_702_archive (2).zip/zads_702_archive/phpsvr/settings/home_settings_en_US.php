<?php

$cust_lang="en";

// define variable to be used for a specific customer site on home page
$cust_title="Petites annonces | accueil | Powered by ZADS.FR";//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!
$cust_motto= "Petites annonces | accueil | Powered by ZADS.FR";
$cust_name="COMPANY NAME"; // used for main title

$cust_description="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi ut ";//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!

$cust_keywords="Petites annonces, autre mot clef ";//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!

$cust_site_name="NOM DU SITE"; // TEST TO BE USED FOR SITE NAME//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!
$cust_site_motto="la devise du site"; // TEST TO BE USED FOR SITE NAME//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!

$cust_site_owner_accronym="PATMISC"; // TEST TO BE USED FOR T&C//!//!//!//!//!//!//!//!//!//!
$cust_site_owner_long="Patrice COHAUT"; // TEST TO BE USED FOR T&C//!//!//!//!//!//!//!//!//!//!

$cust_logo_uri="./img/logo.gif"; //logo of the company//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!
$cust_favicon_uri=""; //logo of the company//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!

// deprecated  !!!!
$cust_logo_alt="Company name alt"; // name of the company attahced as ALT attribute to logo image

$cust_loading_msg="ZADS en en cours de chargement ...";//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!

// main footer :
$cust_facebook_url="http://www.facebook.com/pages/ZADS/209185649133707";//!//!//!//!//!//!//!//!//!
$cust_twitter_url="http://twitter.com/#!/saleszads";//!//!//!//!//!//!//!//!//!
/* new Z4.9.7 */
$cust_gplus_url="https://plus.google.com/109137779427091029876/";//!//!//!//!//!//!//!//!//!

/* new ZADS 5.0 */
$cust_about_footer_desc="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi ut est varius nisl ultrices varius vel eget magna. Fusce iaculis mattis ";//-//-//-//!//!//!//!//!//!//!//!//!//!

// low footer
$cust_tandc_url="./tandc_fr_zads.php";//!//!//!//!//!//!//!//!//!
$cust_pub_url="pub";//!//!//!//!//!//!//!//!//!
$cust_contactus_url="contact";//!//!//!//!//!//!//!//!//!
$cust_aboutus_url="./tandc_fr_zads.php";//!//!//!//!//!//!//!//!//!

$cust_faq_url="./faq_fr_zads.php";//!//!//!//!//!//!//!//!//!
$cust_demo_url="http://demo6.zads.fr";//!//!//!//!//!//!//!//!//!
$cust_help_url="";//!//!//!//!//!//!//!//!//!




// zads4.9 - HTML SNAPSHOT for SEO

$trans = array();
$trans[$cust_lang_long]=array();
$trans[$cust_lang_long]['home']="home";
$trans[$cust_lang_long]['sell']="sell";
$trans[$cust_lang_long]['buy']="buy";

$trans[$cust_lang_long]['shops']="shops";
$trans[$cust_lang_long]['ad']="ad";
$trans[$cust_lang_long]['cat']="cat";
$trans[$cust_lang_long]['user']="user";
$trans[$cust_lang_long]['login']="login";
//$trans[$cust_lang_long]['admin'] = "admin";
$trans[$cust_lang_long]['create_user']="register";

$trans[$cust_lang_long]['edit_profile']="editer-profile";
$trans[$cust_lang_long]['create_ad']="create-ad";
$trans[$cust_lang_long]['create_cat']="create-category";
$trans[$cust_lang_long]['myprofile']="my-profile";
$trans[$cust_lang_long]['mydashboard']="mon-dashboard";

$trans[$cust_lang_long]['dashboard']="dashboard";



// zads4.9.7 - SEO for Region
$trans[$cust_lang_long]['region']="region";
$trans[$cust_lang_long]['dept']="dept";
$trans[$cust_lang_long]['map']="map";
$trans[$cust_lang_long]['zetevu']="zetevu";

// Z5.1
$trans[$cust_lang_long]['settings']="settings";

$trans[$cust_lang_long]['filesmanager']="filesmanager";
$trans[$cust_lang_long]['vfieldsmanager']="vfieldsmanager";
$trans[$cust_lang_long]['emailsmanager']="emailsmanager";
$trans[$cust_lang_long]['routes']="admin-routes-emails";



$trans[$cust_lang_long]['banners']="banners";
$trans[$cust_lang_long]['create_vfield']="create-field";


$trans[$cust_lang_long]['add_service']="add-service";
$trans[$cust_lang_long]['myservices']="my-services";
$trans[$cust_lang_long]['myinvoices']="my-invoices";


//  social youtube
$cust_youtube_url="http://youtube.com";//!//!//!//!//!//!//!


// z5.1 badwords (here because need to be localized)
$cust_badwords="conne|merde|pede|pédé|pedes|pédés|encul|bougnoul|connard|couille|branle|connasse|salope|bite|fuck|putain|trouduk|enfoiré|pédoque|gouine|tapette|baltringue|grognasse|pédale|pouffiasse|pétasse|enflure|bordel";//!

// z5.0.1 - STATIC page content - MAP
$page_map_first_p="Bienvenue sur la <b>Demo de ZADS, LA solution de Petites Annonces publiques ou privées, sous forme de script ou hébergé</b>. <br>Vous avez besoin d'une plateforme de vente ou d'échange de biens ou services ? ZADS est la solution ! Simple, moderne et adaptable pour votre site public , votre Enterprise, votre Club ou votre mairie ou communauté. Hébergez le chez vous ou chez nous pour une mise en place rapide.<br /><br /><div class='block_categories_hp'> <h3>Facile de créer votre widget sur page d'accueil</h3> <ul class='categories'> <li class='category_title cathpemploi'> <a title='Offres emploi' href='./#!categorie/76/emploi---services'> <span class='category_img'> ,</span> <span class='category_title'>Offres emploi</span> </a> </li> <li class='category_title cathpauto-moto'> <a title='Auto - Moto' href='./#!categorie/20/vehicules'> <span class='category_img'> ,</span> <span class='category_title'>Auto - Moto</span> </a> </li> <li class='category_title cathpventeimmobilier'> <a title='Vente immobilier' href='./#!categorie/30/maison'> <span class='category_img'> ,</span> <span class='category_title'>Immobilier</span> </a> </li>   </ul> </div>";//!//!//!//!//!//!
$page_map_center_p="<div class='map_in_center' id='toto' z-height='' z-width='' z-zoom='2.0' z-action='MAP'></div>";
$page_map_last_p="<div id='catslist' z-action='DISPLAY_CATS_AD'></div><br /><br />Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse ultrices fringilla gravida. Phasellus at commodo orci, id volutpat dolor. Vivamus sodales tempor nulla, quis varius dolor tempus sit amet. Nullam pretium diam augue, vitae tincidunt sapien molestie eget. Sed et venenatis dui, eu gravida odio. Sed sodales nec arcu vel ultrices. Sed sit amet sapien pulvinar, pretium velit et, pulvinar quam. Nunc laoreet in arcu euismod auctor.";//!//!//!//!//!//!

// z5.5.7 - add external HTML file
$page_home_url="";//!//!//!//!//!//!//!//!//!//!//!
$page_home_type_url=false; // indicate if we use url or fixed text//!//!//!//!//!//!//!//!//!


// régles générales de diffusion
$cust_rgda_url="./rgda_fr_zads.php";//!//!//!//!//!//!//!//!//!
$cust_pricing_url="";//!//!//!//!//!//!//!
$cust_whoweare_url="./qui_sommes_nous_fr.php";//!//!//!//!//!//!//!
$cust_blog_url="http://blog.zads.fr";//!//!//!//!//!//!//!
$cust_forum_url="";//!//!//!//!//!//!//!


//6.4.0
$trans[$cust_lang_long]['ads']="admin-ads";
$trans[$cust_lang_long]['cats']="admin-categories";
$trans[$cust_lang_long]['users']="admin-users";
$trans[$cust_lang_long]['bookings']="admin-bookings";
$trans[$cust_lang_long]['services']="admin-services";
$trans[$cust_lang_long]['logs']="admin-logs";
$trans[$cust_lang_long]['subscribers']="admin-subscribers";
$trans[$cust_lang_long]['invoices']="admin-invoices";
$trans[$cust_lang_long]['users']="admin-users";
$trans[$cust_lang_long]['visitors']="admin-visitors";

//6.5.1
$cust_cookie_url="./cookies_fr_zads.php";


//6.5.3
$trans[$cust_lang_long]['usercatpid_10038']="user1";
$trans[$cust_lang_long]['usercatpid_10039']="user2";

//6.5.5
$page_home_is_php=false;
$page_home_php_url="home_page_alt.php";

//Z6.5.7
$cust_contact_phone="";


//6.8.0 - newseo
$trans[$cust_lang_long]['about']="about";
$trans[$cust_lang_long]['news']="news";
$trans[$cust_lang_long]['videos']="videos";

//6.8.0
$trans[$cust_lang_long]['zetvu']="zetevu";

//7.0.0 
$trans[$cust_lang_long]['coms']="coms";
$trans[$cust_lang_long]['coms_review']="review";
$trans[$cust_lang_long]['coms_comment']="comment";





?>
