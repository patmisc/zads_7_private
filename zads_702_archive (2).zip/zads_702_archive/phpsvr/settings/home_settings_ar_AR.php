<?php

$cust_lang="ar"; 

// define variable to be used for a specific customer site on home page
$cust_title = "Petites annonces | accueil | Powered by ZADS.FR"; 
$cust_motto = "Petites annonces | accueil | Powered by ZADS.FR"; 
$cust_name ="COMPANY NAME"; // used for main title 

$cust_description="Vendre, acheter, &eacute;changer des produits et services pour les employ&eacute;s ".$cust_name." . powered by ZADS.fr";
$cust_keywords="Petites annonces, communaut&eacute;, plateforme, collaboration, troc, zads, &eacute;changer, entreprises, comit&eacute;, annonce, club, classified ads, vendre, amis ";

$cust_site_name ="PETITES ANNONCES"; // TEST TO BE USED FOR SITE NAME 
$cust_logo_uri="img/zads_top_logo_ie2.jpg"; //logo of the company 
$cust_favicon_uri="img/zads_top_logo_ie2.jpg"; //logo of the company 
$cust_logo_alt="Company name alt"; // name of the company attahced as ALT attribute to logo image

$cust_loading_msg =  "ZADS en en cours de chargement ..."; 

// main footer :
$cust_facebook_url="http://www.facebook.com/pages/ZADS/209185649133707"; 
$cust_twitter_url="http://twitter.com/#!/saleszads"; 

// low footer
$cust_tandc_url= $DOMAIN_FQDN."tandc_fr.html"; 
$cust_pub_url=$DOMAIN_FQDN."pub_fr.html"; 
$cust_contactus_url="contact"; 
$cust_aboutus_url=$DOMAIN_FQDN."about_fr.html"; 
$cust_faq_url=$DOMAIN_FQDN."faq_fr.html"; 
$cust_demo_url=$DOMAIN_FQDN."faq_fr.html"; 
$cust_help_url=$DOMAIN_FQDN."faq_fr.html"; 
	
?>
