<?php

$cust_lang="fr";

// define variable to be used for a specific customer site on home page
$cust_title="Petites annonces | accueil | Powered by ZADS.FR";//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!
$cust_motto= "Petites annonces | accueil | Powered by ZADS.FR";
$cust_name="COMPANY NAME"; // used for main title

$cust_description="des é et des à et des ê ";//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!

$cust_keywords="Petites annonces, autre mot clef ";//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!

$cust_site_name="NOM DU SITE"; // TEST TO BE USED FOR SITE NAME//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!
$cust_site_motto="la devise du site avec des é et à et i"; // TEST TO BE USED FOR SITE NAME//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!

$cust_site_owner_accronym="PATMISC"; // TEST TO BE USED FOR T&C//!//!//!//!//!//!//!//!//!//!
$cust_site_owner_long="Patrice COHAUT"; // TEST TO BE USED FOR T&C//!//!//!//!//!//!//!//!//!//!

$cust_logo_uri="./img/logo.gif"; //logo of the company//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!
$cust_favicon_uri="./img/logo.gif"; //logo of the company//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!

// deprecated  !!!!
$cust_logo_alt="Company name alt"; // name of the company attahced as ALT attribute to logo image

$cust_loading_msg="ZADS en en cours de chargement ...";//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!

// main footer :
$cust_facebook_url="http://www.facebook.com/pages/ZADS/209185649133707";//!//!//!//!//!//!//!//!//!
$cust_twitter_url="https://twitter.com/saleszads";//!//!//!//!//!//!//!//!//!
/* new Z4.9.7 */
$cust_gplus_url="https://plus.google.com/109137779427091029876/";//!//!//!//!//!//!//!//!//!

/* new ZADS 5.0 */
$cust_about_footer_desc="des é et des à et des ê ";//-//-//-//!//!//!//!//!//!//!//!//!//!

// low footer
$cust_tandc_url="./pages/tandc_fr_zads.php";//!//!//!//!//!//!//!//!//!
$cust_pub_url="pub";//!//!//!//!//!//!//!//!//!
$cust_contactus_url="contact";//!//!//!//!//!//!//!//!//!
$cust_aboutus_url="./pages/tandc_fr_zads.php";//!//!//!//!//!//!//!//!//!

$cust_faq_url="./pages/faq_fr_zads.php";//!//!//!//!//!//!//!//!//!
$cust_demo_url="http://demo6.zads.fr";//!//!//!//!//!//!//!//!//!
$cust_help_url="tests";//!//!//!//!//!//!//!//!//!

// zads4.9 - HTML SNAPSHOT for SEO

$trans = array();
$trans[$cust_lang_long]=array();
$trans[$cust_lang_long]['home']="accueil";
$trans[$cust_lang_long]['sell']="je-vends";
$trans[$cust_lang_long]['buy']="je-cherche";

$trans[$cust_lang_long]['shops']="boutiques";
$trans[$cust_lang_long]['ad']="annonces";
$trans[$cust_lang_long]['cat']="categorie";
$trans[$cust_lang_long]['user']="vendeur";
$trans[$cust_lang_long]['login']="se-connecter";
//$trans[$cust_lang_long]['admin'] = "admin";
$trans[$cust_lang_long]['create_user']="s-enregistrer";

$trans[$cust_lang_long]['edit_profile']="editer-profil";
$trans[$cust_lang_long]['create_ad']="creer-annonce";
$trans[$cust_lang_long]['create_cat']="creer-categorie";
$trans[$cust_lang_long]['myprofile']="mon-profil";
$trans[$cust_lang_long]['mydashboard']="mon-tableau-de-bord";

$trans[$cust_lang_long]['dashboard']="tableau-de-bord";



// zads4.9.7 - SEO for Region
$trans[$cust_lang_long]['region']="region";
$trans[$cust_lang_long]['dept']="dept";
$trans[$cust_lang_long]['map']="carte";
$trans[$cust_lang_long]['zetevu']="zetevu";

// Z5.1
$trans[$cust_lang_long]['settings']="configuration";

$trans[$cust_lang_long]['filesmanager']="mes-fichiers";
$trans[$cust_lang_long]['vfieldsmanager']="admin-champs";
$trans[$cust_lang_long]['emailsmanager']="admin-emails";
$trans[$cust_lang_long]['routes']="admin-routes-emails";



$trans[$cust_lang_long]['banners']="publicites";
$trans[$cust_lang_long]['create_vfield']="creer-champ";


$trans[$cust_lang_long]['add_service']="ajouter-service";
$trans[$cust_lang_long]['myservices']="mes-services";
$trans[$cust_lang_long]['myinvoices']="mes-factures";
$trans[$cust_lang_long]['myalerts']="mes-alertes";


//  social youtube
$cust_youtube_url="http://youtube.com";//!//!//!//!//!//!//!


// z5.1 badwords (here because need to be localized)
$cust_badwords="conne|merde|pede|pédé|pedes|pédés|encul|bougnoul|connard|couille|branle|connasse|salope|bite|fuck|putain|trouduk|enfoiré|pédoque|gouine|tapette|baltringue|grognasse|pédale|pouffiasse|pétasse|enflure|bordel";//!

// z5.0.1 - STATIC page content - MAP
$page_map_first_p="DQo8IS0tIA0KPHRhYmxlIGJvcmRlcj0iMSIgY2VsbHBhZGRpbmc9IjEiIGNlbGxzcGFjaW5nPSIxIiBoZWlnaHQ9IjEwNCIgd2lkdGg9IjY5OSI+DQogICAgICAgICAgICAgICAgPHRib2R5Pg0KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj4NCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIHN0eWxlPSJ2ZXJ0aWNhbC1hbGlnbjogdG9wOyBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMTg5LCAzMywgMzQpOyB3aWR0aDogMzElOyB0ZXh0LWFsaWduOiBjZW50ZXI7Ij4NCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwPjxzdHJvbmc+PHNwYW4gc3R5bGU9ImZvbnQtc2l6ZToxNHB4OyI+PHNwYW4gc3R5bGU9ImNvbG9yOiByZ2IoMjU1LCAyNTUsIDI1NSk7Ij5QQU5FTDE8L3NwYW4+PC9zcGFuPjwvc3Ryb25nPjwvcD4NCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwPjxzcGFuIHN0eWxlPSJjb2xvcjojZmZmZmZmOyI+Qk9YMTwvc3Bhbj48L3A+DQogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cD48c3BhbiBzdHlsZT0iY29sb3I6I2ZmZmZmZjsiPnh4eDwvc3Bhbj48L3A+DQogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cD48YSBocmVmPSJodHRwOi8vd3d3LnphZHMuZnIvIj48c3BhbiBzdHlsZT0iY29sb3I6I2ZmZmZmZjsiPkVuIHNhdm9pciBwbHVzLi4uPC9zcGFuPjwvYT48L3A+DQogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+DQogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBzdHlsZT0idmVydGljYWwtYWxpZ246IHRvcDsgYmFja2dyb3VuZC1jb2xvcjogcmdiKDI1NSwgMTI4LCAwKTsgd2lkdGg6IDMxJTsgdGV4dC1hbGlnbjogY2VudGVyOyI+DQogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cD48c3BhbiBzdHlsZT0iZm9udC1zaXplOjE0cHg7Ij48c3Ryb25nPjxzcGFuIHN0eWxlPSJjb2xvcjogcmdiKDI1NSwgMjU1LCAyNTUpOyI+UEFORUwyPC9zcGFuPjwvc3Ryb25nPjwvc3Bhbj48L3A+DQogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cD48c3BhbiBzdHlsZT0iY29sb3I6I2ZmZmZmZjsiPkJPWCAyPC9zcGFuPjwvcD4NCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwPjxzcGFuIHN0eWxlPSJjb2xvcjojZmZmZmZmOyI+eHh4PC9zcGFuPjwvcD4NCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwPjxhIGhyZWY9Imh0dHA6Ly93d3cuemFkcy5mci8iPjxzcGFuIHN0eWxlPSJjb2xvcjojZmZmZmZmOyI+RW4gc2F2b2lyIHBsdXMuLi48L3NwYW4+PC9hPjwvcD4NCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD4NCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIHN0eWxlPSJ2ZXJ0aWNhbC1hbGlnbjogdG9wOyBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMCwgMTI4LCAxOTIpOyB3aWR0aDogMzElOyB0ZXh0LWFsaWduOiBjZW50ZXI7Ij4NCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwPjxzcGFuIHN0eWxlPSJmb250LXNpemU6MTRweDsiPjxzdHJvbmc+PHNwYW4gc3R5bGU9ImNvbG9yOiByZ2IoMjU1LCAyNTUsIDI1NSk7Ij5QQU5FTDM8L3NwYW4+PC9zdHJvbmc+PC9zcGFuPjwvcD4NCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwPjxzcGFuIHN0eWxlPSJjb2xvcjojZmZmZmZmOyI+Qk9YIDM8L3NwYW4+PC9wPg0KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHA+PHNwYW4gc3R5bGU9ImNvbG9yOiNmZmZmZmY7Ij54eHg8L3NwYW4+PC9wPg0KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHA+PGEgaHJlZj0iaHR0cDovL3d3dy56YWRzLmZyLyI+PHNwYW4gc3R5bGU9ImNvbG9yOiNmZmZmZmY7Ij5FbiBzYXZvaXIgcGx1cy4uLjwvc3Bhbj48L2E+PC9wPg0KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPg0KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+DQogICAgICAgICAgICAgICAgPC90Ym9keT4NCjwvdGFibGU+DQotLT4NCg0KDQpCaWVudmVudWUgc3VyIGxhIDxiPkRlbW8gZGUgWkFEUywgTEEgc29sdXRpb24gZGUgUGV0aXRlcyBBbm5vbmNlcyBwdWJsaXF1ZXMgb3UgcHJpdsOpZXMsIHNvdXMgZm9ybWUgZGUgc2NyaXB0IG91IGjDqWJlcmfDqTwvYj4uIDxicj5Wb3VzIGF2ZXogYmVzb2luIGQndW5lIHBsYXRlZm9ybWUgZGUgdmVudGUgb3UgZCfDqWNoYW5nZSBkZSBiaWVucyBvdSBzZXJ2aWNlcyA/IFpBRFMgZXN0IGxhIHNvbHV0aW9uICEgU2ltcGxlLCBtb2Rlcm5lIGV0IGFkYXB0YWJsZSBwb3VyIHZvdHJlIHNpdGUgcHVibGljICwgdm90cmUgRW50ZXJwcmlzZSwgdm90cmUgQ2x1YiBvdSB2b3RyZSBtYWlyaWUgb3UgY29tbXVuYXV0w6kuIEjDqWJlcmdleiBsZSBjaGV6IHZvdXMgb3UgY2hleiBub3VzIHBvdXIgdW5lIG1pc2UgZW4gcGxhY2UgcmFwaWRlLjxiciAvPjxiciAvPg0KDQo8IS0tDQo8ZGl2IGNsYXNzPSdibG9ja19jYXRlZ29yaWVzX2hwJz4gPGgzPkNhdMOpZ29yaWVzIGF1IHRvcDwvaDM+IDx1bCBjbGFzcz0nY2F0ZWdvcmllcycgICB6LWFjdGlvbj0nRElTUExBWV9DQVRfSURTJyB6LWlkcz0nMjB8MzB8NzYnPiAgPC91bD4gPC9kaXY+DQotLT4NCg0KDQo8ZGl2IGNsYXNzPSJibG9ja19jYXRlZ29yaWVzX2hwMiIgIGRhdGEtYWN0aW9uPSJESVNQTEFZX0NBVF9JRFNfVjIiIGRhdGEtaWRzPSIyMHwzMHw3NnwzNiInICBkYXRhLWljb25zPSJjYXJ8aG9tZXxicmllZmNhc2V8bGFwdG9wIj4NCjwvZGl2Pg0KDQoNCg0K";//!//!//!//!//!//!
$page_map_center_p="PCEtLSA8ZGl2IGNsYXNzPScnPjxkaXYgY2xhc3M9J2xlZnQgYmxvY2tfbGVmdF9ocCcgc3R5bGU9J3dpZHRoOjIwMHB4JyA+PGJyPjxwPkxhIHBhZ2UgZCdhY2N1ZWlsIGVzdCB0b3RhbGVtZW50IHBlcnNvbm5hbGlzYWJsZSBhdmVjIGRlcyBhY3Rpb25zIHN1ciBsZXMgPHNwYW4gc3R5bGU9J2NvbG9yOm9yYW5nZScgIHotYWN0aW9uPSdBRFNfTlVNQkVSJz48L3NwYW4+IHByw6lzZW50ZXMuIDwvcD48YnI+PGEgaHJlZj0nIycgY2xhc3M9J2RtX2J1dHRvbjInIHotYWN0aW9uPSdDUkVBVEVfQUQnPjxpIGNsYXNzPSdpY29uLWZhLXBlbmNpbC1zcXVhcmUtbyc+PC9pPiBDcsOpZXIgbW9uIGFubm9uY2UgPC9hPjxiciAvPjxwPk9uIHBldXQgYWpvdXRlciBkdSB0ZXh0ZSBsaWJyZSBvdSBkZXMgYXR0cmlidXRzIDxiPmR5bmFtaXF1ZXM8L2I+IGNvbW1lIGxlcyBib3V0b25zIGNpLWRlc3NvdXM8L3A+PGJyIC8+PGEgaHJlZj0nIycgY2xhc3M9J2RtX2J1dHRvbjInIHotYWN0aW9uPSdDUkVBVEVfVVNFUic+PGkgY2xhc3M9J2ljb24tZmEtdXNlcic+PC9pPiBTJ2VucmVnaXN0cmVyPC9hPjxiciAvPjxiciAvPjxhIGhyZWY9JyMnIGNsYXNzPSdkbV9idXR0b24yJyB6LWFjdGlvbj0nQ09OVEFDVCc+PGkgY2xhc3M9J2ljb24tZmEtZW52ZWxvcGUnPjwvaT4gTm91cyBjb250YWN0ZXI8L2E+PGJyIC8+PC9kaXY+PGRpdiBjbGFzcz0ncmlnaHQnIGlkPSd0b3RvJyB6LWhlaWdodD0nNTAwJyB6LXdpZHRoPSc0ODAnIHotem9vbT0nJyB6LWFjdGlvbj0nTUFQJz48L2Rpdj48YnIgLz48ZGl2IGNsYXNzPSdjbGVhcic+PC9kaXY+PC9kaXY+IA0KLS0+DQoNCjxkaXYgY2xhc3M9ImNsZWFyZml4Ij4NCg0KPGRpdiAgY2xhc3M9ImNvbC1tZC04Ij4NCjxkaXYgY2xhc3M9InJvdyI+DQo8YSBocmVmPSJhY3Rpb249bGlzdCZmZm9yY2VkbG9jb3VudHJ5PWZyIiB6LWFjdGlvbj0iQUpBWCIgIGNsYXNzPSJjb2wtbWQtNyAiPjxpbWcgc3JjPSIuL2ltZy9jYXJ0ZV9mci5wbmciIGNsYXNzPSJmdWxsd2lkdGgiIC8+PC9hPg0KPGEgaHJlZj0iYWN0aW9uPWxpc3QmZmZvcmNlZGxvY291bnRyeT10biIgei1hY3Rpb249IkFKQVgiIGNsYXNzPSJjb2wtbWQtNSAiPjxpbWcgc3JjPSIuL2ltZy9jYXJ0ZV90bi5wbmciIGNsYXNzPSJmdWxsd2lkdGgiIC8+PC9hPg0KPC9kaXY+DQo8L2Rpdj4NCg0KPGRpdiAgY2xhc3M9ImNvbC1tZC00Ij4NCjxkaXYgY2xhc3M9ImxvY190aXRsZSI+IFJlZ2lvbnMgYXUgdG9wPC9kaXY+DQogIDxkaXYgaWQ9J2xvY2xpc3QnIHotbWF4PSIxMCIgei1hY3Rpb249J0RJU1BMQVlfTE9DX0xJU1QnPjwvZGl2Pg0KPC9kaXY+DQo8L2Rpdj4NCg0K";
$page_map_last_p="TG9yZW0gaXBzdW0gZG9sb3Igc2l0IGFtZXQsIGNvbnNlY3RldHVyIGFkaXBpc2NpbmcgZWxpdC4gU3VzcGVuZGlzc2UgdWx0cmljZXMgZnJpbmdpbGxhIGdyYXZpZGEuIFBoYXNlbGx1cyBhdCBjb21tb2RvIG9yY2ksIGlkIHZvbHV0cGF0IGRvbG9yLiBWaXZhbXVzIHNvZGFsZXMgdGVtcG9yIG51bGxhLCBxdWlzIHZhcml1cyBkb2xvciB0ZW1wdXMgc2l0IGFtZXQuIE51bGxhbSBwcmV0aXVtIGRpYW0gYXVndWUsIHZpdGFlIHRpbmNpZHVudCBzYXBpZW4gbW9sZXN0aWUgZWdldC4gU2VkIGV0IHZlbmVuYXRpcyBkdWksIGV1IGdyYXZpZGEgb2Rpby4gU2VkIHNvZGFsZXMgbmVjIGFyY3UgdmVsIHVsdHJpY2VzLiBTZWQgc2l0IGFtZXQgc2FwaWVuIHB1bHZpbmFyLCBwcmV0aXVtIHZlbGl0IGV0LCBwdWx2aW5hciBxdWFtLiBOdW5jIGxhb3JlZXQgaW4gYXJjdSBldWlzbW9kIGF1Y3Rvci48YnIgLz48YnIgLz48YnIgLz48ZGl2IGlkPSdjYXRzbGlzdCcgei1hY3Rpb249J0RJU1BMQVlfQ0FUU19BRCc+PC9kaXY+";//!//!//!//!//!//!


// z5.5.7 - add external HTML file
$page_home_url="";//!//!//!//!//!//!//!//!//!//!//!
$page_home_type_url=false; // indicate if we use url or fixed text//!//!//!//!//!//!//!//!//!


// régles générales de diffusion
$cust_rgda_url="./pages/rgda_fr_zads.php";//!//!//!//!//!//!//!//!//!
$cust_pricing_url="";//!//!//!//!//!//!//!
$cust_whoweare_url="./pages/qui_sommes_nous_fr_zads.php";//!//!//!//!//!//!//!
$cust_blog_url="http://blog.zads.fr";//!//!//!//!//!//!//!
$cust_forum_url="";//!//!//!//!//!//!//!


//6.4.0
$trans[$cust_lang_long]['ads']="admin-annonces";
$trans[$cust_lang_long]['cats']="admin-categories";
$trans[$cust_lang_long]['users']="admin-usagers";
$trans[$cust_lang_long]['bookings']="admin-reservations";
$trans[$cust_lang_long]['services']="admin-services";
$trans[$cust_lang_long]['logs']="admin-logs";
$trans[$cust_lang_long]['subscribers']="admin-subscribers";
$trans[$cust_lang_long]['invoices']="admin-factures";
$trans[$cust_lang_long]['users']="admin-usagers";
$trans[$cust_lang_long]['visitors']="admin-visitors";

//6.5.1
$cust_cookie_url="./pages/cookies_fr_zads.php";


//6.5.3
$trans[$cust_lang_long]['usercatpid_10038']="user1";
$trans[$cust_lang_long]['usercatpid_10039']="user2";

//6.5.5
$page_home_is_php=false;
$page_home_php_url="";

//Z6.5.7
$cust_contact_phone="";


//6.8.0 - newseo
$trans[$cust_lang_long]['about']="a-propos";
$trans[$cust_lang_long]['news']="nouvelles";
$trans[$cust_lang_long]['videos']="videos";

//6.8.0
$trans[$cust_lang_long]['zetvu']="zetevu";

//7.0.0
$trans[$cust_lang_long]['coms']="coms";
$trans[$cust_lang_long]['coms_review']="revues";
$trans[$cust_lang_long]['coms_comment']="commentaires";

// ==== 7.0.5 =============

$cust_site_copyright="ZADS 2016";



?>