<?php

$cust_lang="fr";

// define variable to be used for a specific customer site on home page
$cust_title="Petites annonces | accueil | Powered by ZADS.FR";//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!
$cust_motto= "Petites annonces | accueil | Powered by ZADS.FR";
$cust_name="COMPANY NAME"; // used for main title

$cust_description="des é et des à et des ê ";//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!

$cust_keywords="Petites annonces, autre mot clef ";//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!

$cust_site_name="NOM DU SITE"; // TEST TO BE USED FOR SITE NAME//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!
$cust_site_motto="la devise du site avec des é et à et i"; // TEST TO BE USED FOR SITE NAME//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!

$cust_site_owner_accronym="PATMISC"; // TEST TO BE USED FOR T&C//!//!//!//!//!//!//!//!//!//!
$cust_site_owner_long="Patrice COHAUT"; // TEST TO BE USED FOR T&C//!//!//!//!//!//!//!//!//!//!

$cust_logo_uri="http://localhost/zads_702_archive/uploads/files/tmp_20170603-100002.png"; //logo of the company//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!
$cust_favicon_uri="./img/logo.gif"; //logo of the company//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!

// deprecated  !!!!
$cust_logo_alt="Company name alt"; // name of the company attahced as ALT attribute to logo image

$cust_loading_msg="ZADS en en cours de chargement ...";//-//-//-//-//-//!//!//!//!//!//!//!//!//!//!

// main footer :
$cust_facebook_url="http://www.facebook.com/pages/ZADS/209185649133707";//!//!//!//!//!//!//!//!//!
$cust_twitter_url="https://twitter.com/saleszads";//!//!//!//!//!//!//!//!//!
/* new Z4.9.7 */
$cust_gplus_url="https://plus.google.com/109137779427091029876/";//!//!//!//!//!//!//!//!//!

/* new ZADS 5.0 */
$cust_about_footer_desc="des é et des à et des ê ";//-//-//-//!//!//!//!//!//!//!//!//!//!

// low footer
$cust_tandc_url="./pages/tandc_fr_zads.php";//!//!//!//!//!//!//!//!//!
$cust_pub_url="pub";//!//!//!//!//!//!//!//!//!
$cust_contactus_url="contact";//!//!//!//!//!//!//!//!//!
$cust_aboutus_url="./pages/tandc_fr_zads.php";//!//!//!//!//!//!//!//!//!

$cust_faq_url="./pages/faq_fr_zads.php";//!//!//!//!//!//!//!//!//!
$cust_demo_url="http://demo6.zads.fr";//!//!//!//!//!//!//!//!//!
$cust_help_url="tests";//!//!//!//!//!//!//!//!//!

// zads4.9 - HTML SNAPSHOT for SEO

$trans = array();
$trans[$cust_lang_long]=array();
$trans[$cust_lang_long]['home']="accueil";
$trans[$cust_lang_long]['sell']="je-vends";
$trans[$cust_lang_long]['buy']="je-cherche";

$trans[$cust_lang_long]['shops']="boutiques";
$trans[$cust_lang_long]['ad']="annonces";
$trans[$cust_lang_long]['cat']="categorie";
$trans[$cust_lang_long]['user']="vendeur";
$trans[$cust_lang_long]['login']="se-connecter";
//$trans[$cust_lang_long]['admin'] = "admin";
$trans[$cust_lang_long]['create_user']="s-enregistrer";

$trans[$cust_lang_long]['edit_profile']="editer-profil";
$trans[$cust_lang_long]['create_ad']="creer-annonce";
$trans[$cust_lang_long]['create_cat']="creer-categorie";
$trans[$cust_lang_long]['myprofile']="mon-profil";
$trans[$cust_lang_long]['mydashboard']="mon-tableau-de-bord";

$trans[$cust_lang_long]['dashboard']="tableau-de-bord";



// zads4.9.7 - SEO for Region
$trans[$cust_lang_long]['region']="region";
$trans[$cust_lang_long]['dept']="dept";
$trans[$cust_lang_long]['map']="carte";
$trans[$cust_lang_long]['zetevu']="zetevu";

// Z5.1
$trans[$cust_lang_long]['settings']="configuration";

$trans[$cust_lang_long]['filesmanager']="mes-fichiers";
$trans[$cust_lang_long]['vfieldsmanager']="admin-champs";
$trans[$cust_lang_long]['emailsmanager']="admin-emails";
$trans[$cust_lang_long]['routes']="admin-routes-emails";



$trans[$cust_lang_long]['banners']="publicites";
$trans[$cust_lang_long]['create_vfield']="creer-champ";


$trans[$cust_lang_long]['add_service']="ajouter-service";
$trans[$cust_lang_long]['myservices']="mes-services";
$trans[$cust_lang_long]['myinvoices']="mes-factures";
$trans[$cust_lang_long]['myalerts']="mes-alertes";


//  social youtube
$cust_youtube_url="http://youtube.com";//!//!//!//!//!//!//!


// z5.1 badwords (here because need to be localized)
$cust_badwords="conne|merde|pede|pédé|pedes|pédés|encul|bougnoul|connard|couille|branle|connasse|salope|bite|fuck|putain|trouduk|enfoiré|pédoque|gouine|tapette|baltringue|grognasse|pédale|pouffiasse|pétasse|enflure|bordel";//!

// z5.0.1 - STATIC page content - MAP
$page_map_first_p="PHRhYmxlIGJvcmRlcj0iMSIgY2VsbHBhZGRpbmc9IjEiIGNlbGxzcGFjaW5nPSIxIiBoZWlnaHQ9IjEwNCIgd2lkdGg9IjY5OSI+DQogICAgICAgICAgICAgICAgPHRib2R5Pg0KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj4NCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIHN0eWxlPSJ2ZXJ0aWNhbC1hbGlnbjogdG9wOy8qIGJhY2tncm91bmQtY29sb3I6IHJnYig0NSwgMTgxLCAyMTYpOyAqL3dpZHRoOiA1MCU7dGV4dC1hbGlnbjogY2VudGVyOyI+DQoNCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwPjxzcGFuIHN0eWxlPSIvKiBjb2xvcjojZmZmZmZmOyAqLyI+RMOpcG9zZXIgdm90cmUgYW5ub25jZSBHUkFUVUlURU1FTlQ8L3NwYW4+PC9wPg0KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgDQogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cD48YSBzdHlsZT0id2lkdGggOiA5MCU7bWFyZ2luLXRvcCA6IDEwcHg7YmFja2dyb3VuZC1jb2xvcjogb3JhbmdlO2JvcmRlcjogMHB4OyIgY2xhc3M9ImJ0biBidG4tcHJpbWFyeSIgaHJlZj0iIyIgei1hY3Rpb249IkNSRUFURV9BRCI+PHNwYW4gc3R5bGU9ImZvbnQtc2l6ZToyNXB4Ij5KJ2Fubm9uY2U8L3NwYW4+PC9hPjwvcD4NCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD4NCjwhLS0NCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIHN0eWxlPSJ2ZXJ0aWNhbC1hbGlnbjogdG9wOyBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMTI2LCAxODMsIDEyOCk7IHdpZHRoOiA1MCU7IHRleHQtYWxpZ246IGNlbnRlcjsiPg0KPHA+PHN0cm9uZz48c3BhbiBzdHlsZT0iZm9udC1zaXplOjE0cHg7Ij48c3BhbiBzdHlsZT0iY29sb3I6IHJnYigyNTUsIDI1NSwgMjU1KTsiPlBST0ZFU1NJT05ORUxTPC9zcGFuPjwvc3Bhbj48L3N0cm9uZz48L3A+DQogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cD48c3BhbiBzdHlsZT0iY29sb3I6I2ZmZmZmZjsiPkTDqXBvc2VyIHZvdHJlIGFubm9uY2UgR1JBVFVJVEVNRU5UPC9zcGFuPjwvcD4NCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIA0KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHA+PGEgc3R5bGU9IndpZHRoIDogOTAlOyBtYXJnaW4tdG9wIDogMTBweCIgY2xhc3M9ImJ0biBidG4tc3VjY2VzcyIgaHJlZj0iIyIgei1hY3Rpb249J0NSRUFURV9BRCc+PHNwYW4gc3R5bGU9IiI+Sidhbm5vbmNlPC9zcGFuPjwvYT48L3A+DQogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+DQogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgDQogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj4gDQoNCiAgICAgICAgICAgICAgICA8L3Rib2R5Pg0KPC90YWJsZT4NCjwhLS0NCjxwIGNsYXNzPSIiPg0KPHNwYW4gY2xhc3M9ImxhYmVsLXNpdGVuYW1lIiA+YXRvdXRjb2luLmNvbTwvc3Bhbj4gZXN0IHVuPGI+IGF0b3V0PC9iPiBkYW5zIHRvdXQgbGVzIGNvaW5zICEgIEVuIGNvbW1lbsOnYW50IHBhciBsZSBjb2luIGRlIGxhIHJ1ZSBldCBlbiBhbGxhbnQganVzcXUnw6AgbCdhdXRyZSBib3V0IGRlIGxhIEZyYW5jZSBldCBwb3VycXVvaSBwYXMgdHJhdmVyc2VyIDxiPmxhIG3DqWRpdGVycmFuw6llPC9iPiAuICANCjxzcGFuIGNsYXNzPSJsYWJlbC1zaXRlbmFtZSIgPmF0b3V0Y29pbi5jb208L3NwYW4+IGVzdCBsJ2VtcGxhY2VtZW50IGlkw6lhbGUgcG91ciB2ZW5kcmUsIGFjaGV0ZXIsIHByb3Bvc2VyIG91IGRlbWFuZGVyIHVuIHNlcnZpY2UsIGV0IGF1c3NpIHVuIG1veWVuIHBvdXIgbGVzIHRvdXJpc3RlIHF1aSBwZXV2ZW50IGTDqW5pY2hlciB1biBsb2dlbWVudCBwb3VyIGxldXJzIHZhY2FuY2VzIGVuIFR1bmlzaWUgDQo8L3A+DQotLT48L3RyPjwvdGJvZHk+PC90YWJsZT4NCg==";//!//!//!//!//!//!
$page_map_center_p="PGRpdiBjbGFzcz0nJz4NCjxkaXYgY2xhc3M9ImxlZnQiIGlkPSdmcicgei1oZWlnaHQ9JzQyMCcgei13aWR0aD0nNDIwJyBkYXRhLWNvdW50cnk9IkZSIiB6LXpvb209Jycgei1hY3Rpb249J01BUDInPjwvZGl2Pg0KPGRpdiBjbGFzcz0ibGVmdCIgaWQ9J3RuJyB6LWhlaWdodD0nNDg1JyB6LXdpZHRoPSczMDAnIGRhdGEtY291bnRyeT0iVE4iIHotem9vbT0nJyB6LWFjdGlvbj0nTUFQMic+PC9kaXY+DQo8ZGl2IGNsYXNzPSdjbGVhcic+PC9kaXY+DQo8L2Rpdj4=";
$page_map_last_p="PCEtLQ0KTG9yZW0gaXBzdW0gZG9sb3Igc2l0IGFtZXQsIGNvbnNlY3RldHVyIGFkaXBpc2NpbmcgZWxpdC4gU3VzcGVuZGlzc2UgdWx0cmljZXMgZnJpbmdpbGxhIGdyYXZpZGEuIFBoYXNlbGx1cyBhdCBjb21tb2RvIG9yY2ksIGlkIHZvbHV0cGF0IGRvbG9yLiBWaXZhbXVzIHNvZGFsZXMgdGVtcG9yIG51bGxhLCBxdWlzIHZhcml1cyBkb2xvciB0ZW1wdXMgc2l0IGFtZXQuIE51bGxhbSBwcmV0aXVtIGRpYW0gYXVndWUsIHZpdGFlIHRpbmNpZHVudCBzYXBpZW4gbW9sZXN0aWUgZWdldC4gU2VkIGV0IHZlbmVuYXRpcyBkdWksIGV1IGdyYXZpZGEgb2Rpby4gU2VkIHNvZGFsZXMgbmVjIGFyY3UgdmVsIHVsdHJpY2VzLiBTZWQgc2l0IGFtZXQgc2FwaWVuIHB1bHZpbmFyLCBwcmV0aXVtIHZlbGl0IGV0LCBwdWx2aW5hciBxdWFtLiBOdW5jIGxhb3JlZXQgaW4gYXJjdSBldWlzbW9kIGF1Y3Rvci4NCi0tPg0KPGRpdiBpZD0nY2F0c2xpc3QnIHotYWN0aW9uPSdESVNQTEFZX0NBVFNfQUQnPjwvZGl2Pg==";//!//!//!//!//!//!


// z5.5.7 - add external HTML file
$page_home_url="";//!//!//!//!//!//!//!//!//!//!//!
$page_home_type_url=false; // indicate if we use url or fixed text//!//!//!//!//!//!//!//!//!


// régles générales de diffusion
$cust_rgda_url="./pages/rgda_fr_zads.php";//!//!//!//!//!//!//!//!//!
$cust_pricing_url="";//!//!//!//!//!//!//!
$cust_whoweare_url="./pages/qui_sommes_nous_fr_zads.php";//!//!//!//!//!//!//!
$cust_blog_url="http://blog.zads.fr";//!//!//!//!//!//!//!
$cust_forum_url="";//!//!//!//!//!//!//!


//6.4.0
$trans[$cust_lang_long]['ads']="admin-annonces";
$trans[$cust_lang_long]['cats']="admin-categories";
$trans[$cust_lang_long]['users']="admin-usagers";
$trans[$cust_lang_long]['bookings']="admin-reservations";
$trans[$cust_lang_long]['services']="admin-services";
$trans[$cust_lang_long]['logs']="admin-logs";
$trans[$cust_lang_long]['subscribers']="admin-subscribers";
$trans[$cust_lang_long]['invoices']="admin-factures";
$trans[$cust_lang_long]['users']="admin-usagers";
$trans[$cust_lang_long]['visitors']="admin-visitors";

//6.5.1
$cust_cookie_url="./pages/cookies_fr_zads.php";


//6.5.3
$trans[$cust_lang_long]['usercatpid_10038']="user1";
$trans[$cust_lang_long]['usercatpid_10039']="user2";

//6.5.5
$page_home_is_php=false;
$page_home_php_url="";

//Z6.5.7
$cust_contact_phone="";


//6.8.0 - newseo
$trans[$cust_lang_long]['about']="a-propos";
$trans[$cust_lang_long]['news']="nouvelles";
$trans[$cust_lang_long]['videos']="videos";

//6.8.0
$trans[$cust_lang_long]['zetvu']="zetevu";

//7.0.0
$trans[$cust_lang_long]['coms']="coms";
$trans[$cust_lang_long]['coms_review']="revues";
$trans[$cust_lang_long]['coms_comment']="commentaires";

// ==== 7.0.5 =============

$cust_site_copyright="ZADS 2016";



?>