<?php

/*
 n= name (logical); 
 s=section (); 
 t=type of file (json|php|txt); 
 furl= file url ; i=icon name 
*/ 
// include_once $SETTINGS_PATH."home_settings_".$cust_lang_long.".php"; 

$settingsmodel = Array (
    
    //, array( 'n'=>'payoptions', 't'=>'json', 's'=>'payoptions',  'i'=>'credit-card', 'furl' => $SETTINGS_PATH.'general.json')
    array( 'n'=>'general', 't'=>'json-txt', 's'=>'site_details',  'i'=>'home', 'furl' => $SETTINGS_PATH.'general.json',  'turl' => $SETTINGS_PATH.'settings.php')
    , array( 'n'=>'general2', 't'=>'json-txt', 's'=>'site_metas',  'i'=>'home', 'furl' => $SETTINGS_PATH.'general.json',  'turl' => $SETTINGS_PATH.'home_settings_'.$cust_lang_long.'.php', 'local' => true, 'case' =>'low')
    , array( 'n'=>'sitepages', 't'=>'json-txt', 's'=>'site_pages',  'i'=>'book', 'furl' => $SETTINGS_PATH.'general.json',  'turl' => $SETTINGS_PATH.'home_settings_'.$cust_lang_long.'.php', 'local' => true, 'case' =>'low')

    //, array( 'n'=>'site_pages', 't'=>'json-txt', 's'=>'site_pages',  'i'=>'file-alt', 'furl' => $SETTINGS_PATH.'general.json',  'turl' => $SETTINGS_PATH.'home_settings_fr_FR.php', 'case' =>'low')

    , array( 'n'=>'links', 't'=>'json-txt', 's'=>'site_links',  'i'=>'link', 'furl' => $SETTINGS_PATH.'general.json',  'turl' => $SETTINGS_PATH.'home_settings_'.$cust_lang_long.'.php', 'local' => true, 'case' =>'low')

    , array( 'n'=>'mainnav', 't'=>'json-txt', 's'=>'site_nav',  'i'=>'bookmark', 'furl' => $SETTINGS_PATH.'general.json',  'turl' => $SETTINGS_PATH.'settings.php')
    , array( 'n'=>'searchnav', 't'=>'json-txt', 's'=>'nav_search',  'i'=>'search', 'furl' => $SETTINGS_PATH.'general.json',  'turl' => $SETTINGS_PATH.'settings.php')

    , array( 'n'=>'layout', 't'=>'json-txt', 's'=>'site_layout',  'i'=>'th-large', 'furl' => $SETTINGS_PATH.'general.json',  'turl' => $SETTINGS_PATH.'settings.php')
    , array( 'n'=>'locale', 't'=>'json-txt', 's'=>'site_locale',  'i'=>'globe', 'furl' => $SETTINGS_PATH.'general.json',  'turl' => $SETTINGS_PATH.'settings.php')
    , array( 'n'=>'lifecycle', 't'=>'json-txt', 's'=>'life_cycle',  'i'=>'refresh', 'furl' => $SETTINGS_PATH.'general.json',  'turl' => $SETTINGS_PATH.'settings.php')
    //, array( 'n'=>'packaging', 't'=>'json', 's'=>'packaging',  'i'=>'truck', 'furl' => $SETTINGS_PATH.'general.json')
    , array( 'n'=>'emails', 't'=>'json-txt', 's'=>'emails',  'i'=>'envelope-o', 'furl' => $SETTINGS_PATH.'general.json',  'turl' => $SETTINGS_PATH.'settings.php')

    //, array( 'n'=>'adsense', 't'=>'json', 's'=>'adsense',  'i'=>'bullhorn', 'furl' => $SETTINGS_PATH.'general.json')
    // , array( 'n'=>'admin', 't'=>'json', 's'=>'user_admin_details',  'i'=>'cog', 'furl' => $SETTINGS_PATH.'general.json')
    , array( 'n'=>'social', 't'=>'json-txt', 's'=>'social',  'i'=>'cloud', 'furl' => $SETTINGS_PATH.'general.json',  'turl' => $SETTINGS_PATH.'settings.php')
    , array( 'n'=>'coms', 't'=>'json-txt', 's'=>'coms',  'i'=>'comments', 'furl' => $SETTINGS_PATH.'general.json',  'turl' => $SETTINGS_PATH.'settings.php')
    , array( 'n'=>'badwords', 't'=>'json-txt', 's'=>'site_badwords',  'i'=>'ban', 'furl' => $SETTINGS_PATH.'general.json',  'turl' => $SETTINGS_PATH.'home_settings_'.$cust_lang_long.'.php', 'local' => true, 'case' =>'low')
    , array( 'n'=>'security', 't'=>'json-txt', 's'=>'security',  'i'=>'shield', 'furl' => $SETTINGS_PATH.'general.json',  'turl' => $SETTINGS_PATH.'settings.php')
    , array( 'n'=>'services', 't'=>'json-txt', 's'=>'services',  'i'=>'reorder', 'furl' => $SETTINGS_PATH.'general.json',  'turl' => $SETTINGS_PATH.'settings.php')
    , array( 'n'=>'payoptions', 't'=>'json', 's'=>'payoptions',  'i'=>'credit-card', 'furl' => $SETTINGS_PATH.'catalogue.json',  'turl' => $SETTINGS_PATH.'catalogue.json')
    , array( 'n'=>'pricingplan', 't'=>'json', 's'=>'pricing_plan',  'i'=>'user', 'furl' => $SETTINGS_PATH.'catalogue.json',  'turl' => $SETTINGS_PATH.'catalogue.json')

    //, array( 'n'=>'pricingplan', 't'=>'json', 's'=>'pricing_plan',  'i'=>'credit-card', 'furl' => $SETTINGS_PATH.'catalogue.json',  'turl' => $SETTINGS_PATH.'catalogue.json')
    , array( 'n'=>'paypal', 't'=>'json-txt', 's'=>'paypal',  'i'=>'credit-card', 'furl' => $SETTINGS_PATH.'general.json',  'turl' => $SETTINGS_PATH.'settings.php')
    , array( 'n'=>'fields', 't'=>'json-txt', 's'=>'fields',  'i'=>'tags', 'furl' => $SETTINGS_PATH.'general.json',  'turl' => $SETTINGS_PATH.'settings.php')
    , array( 'n'=>'userfields', 't'=>'json', 's'=>'userfields',  'i'=>'tags', 'furl' => $SETTINGS_PATH.'fields.json',  'turl' => $SETTINGS_PATH.'fields.json')
    , array( 'n'=>'adfields', 't'=>'json', 's'=>'adfields',  'i'=>'tags', 'furl' => $SETTINGS_PATH.'fields.json',  'turl' => $SETTINGS_PATH.'fields.json')
    
    , array( 'n'=>'alerts', 't'=>'json-txt', 's'=>'alerts',  'i'=>'bell', 'furl' => $SETTINGS_PATH.'general.json',  'turl' => $SETTINGS_PATH.'settings.php')

    , array( 'n'=>'calendars', 't'=>'json-txt', 's'=>'calendars',  'i'=>'calendar', 'furl' => $SETTINGS_PATH.'general.json',  'turl' => $SETTINGS_PATH.'settings.php')
    , array( 'n'=>'others', 't'=>'json-txt', 's'=>'others',  'i'=>'gear', 'furl' => $SETTINGS_PATH.'general.json',  'turl' => $SETTINGS_PATH.'settings.php')
    , array( 'n'=>'superadmin', 't'=>'json-txt', 's'=>'superadmin',  'i'=>'gear', 'acl'=> '10', 'furl' => $SETTINGS_PATH.'general.json',  'turl' => $SETTINGS_PATH.'settings.php')
    , array( 'n'=>'multitenant', 't'=>'json-txt', 's'=>'multitenant',  'i'=>'gear', 'acl'=> '10', 'furl' => 'startup.json',  'turl' => 'multitenants_settings.php')

);


?>
