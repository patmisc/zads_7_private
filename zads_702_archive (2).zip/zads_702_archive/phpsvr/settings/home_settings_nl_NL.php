<?php

$cust_lang="nl"; 

// define variable to be used for a specific customer site on home page
$cust_title = "tweedehandsmartphones | accueil | Powered by ZADS"; 
$cust_motto = "tweedehandsmartphones| accueil | Powered by ZADS"; 
$cust_name ="TWEEDEHANDSSMARTPHONES (NL)"; // used for main title 

$cust_description="Vendre, acheter, &eacute;changer des smartphones -  powered by ZADS.FR";
$cust_keywords="style petites annonces, vendre, gsm occasion, smartphone occasion, accessoires, réparation, iphone, samsung, nokia";

$cust_site_name ="TWEEDEHANDSSMARTPHONES (NL)"; // TEST TO BE USED FOR SITE NAME 
$cust_logo_uri="img/logosmart.png"; //logo of the company 
$cust_favicon_uri="img/logosmart.png"; //logo of the company 
$cust_logo_alt="Company name alt"; // name of the company attahced as ALT attribute to logo image

$cust_loading_msg =  "TWEEDEHANDSSMARTPHONES wordt opgeladen ..."; 

// main footer :
$cust_facebook_url="http://www.facebook.com/pages/ZADS/209185649133707"; 
$cust_twitter_url="http://twitter.com/#!/saleszads"; 

// low footer
$cust_tandc_url="http://test.smartphoneoccasion.be/tandc_fr.html"; 
$cust_pub_url="http://test.smartphoneoccasion.be/pub_fr.html"; 
$cust_contactus_url="mailto:adsforphones@gmail.com"; 
$cust_aboutus_url="http://test.smartphoneoccasion.be/about_fr.html"; 
$cust_faq_url="http://test.smartphoneoccasion.be/faq_fr.html"; 
$cust_demo_url="http://test.smartphoneoccasion.be/faq_fr.html"; 
$cust_help_url="http://test.smartphoneoccasion.be/faq_fr.html";
$cust_sitemap_url="http://test.smartphoneoccasion.be/sitemap.html";  
	
?>
