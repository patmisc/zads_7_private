<?php
/******************************************************************************
 * ZADS MIGRATION SCRIPT FOR LOKAWEB 
 * 
 * @category   MIGRATION SCRIPT
 * @package    ZADS
 * @author     Patrice COHAUT <patrice.cohaut@gmail.com>
 * @copyright  2014 PATMISC
 * @version    6.1
 ******************************************************************************/
// load libraries 
// require_once("settings/db_settings.php");  
require_once("multitenants_settings.php"); 
require_once($SETTINGS_PATH."settings.php");
require_once("localization.php");

// set default timezone 
date_default_timezone_set('Europe/Paris');

// Report all PHP errors
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING | E_DEPRECATED));

ini_set('max_execution_time', 300); // 300 seconds

$debug ="";
$debug_tmp = 0 ; // 0= server 1=local
if (( $_SERVER['SERVER_ADDR'] != "127.0.0.1") ||( !$_SERVER['SERVER_ADDR'] ))  $debug_tmp=0; else $debug_tmp=1; 
$nomessage = 0;  // 0= flag to indicate wether to end a message or not

// debug output file 
$debugoutputfile = "debugoutput.htm"; // only if save=1
 

// ---- send header ----------//
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>ZADS Installer</title>
  <meta http-equiv="Content-Language" content="French" />
  <meta http-equiv="content-type" content="text/html; charset=iso-8859-15"/>
  <link rel="stylesheet" type="text/css" href="install_style.css" media="all"/>
</head>
<body id="">
  <div id="">
    <div class="header">
      <a title="" href="http://www.zads.fr/"><img src="img/zadslogo80_3.png"" alt="ZADS logo" width="109" height="57"></a>	
      <span class="motto"><strong>Plateforme de petites annonces communautaires</strong></span>
    </div>

<?php

// --- make a precheck of bd config file existance ---- //
define('CONFIGFILE',$SETTINGS_PATH.'db_settings.php');
define('CONFIGFILE_TEMPLATE',$SETTINGS_PATH.'db_settings.sample.php');
ob_start();
if(!file_exists(CONFIGFILE)) {
  echo_flush('ko', 'DB Config file does not exist, we will create one from default template','');
  if (!copy(CONFIGFILE_TEMPLATE,CONFIGFILE )) {
    echo_flush('ko', 'failed to copy $file...','');
    exit ; 
  } else {
    display_dbsetupform(); 
  }
  exit ;
} else {
    $configfile=file_get_contents(CONFIGFILE); //Get the goodies...peek and tell.
    if (isset($_POST["action"])  && $_POST["action"]=="updatemysqlsettings"){
      // replace and save 
      if (!($fp = @fopen(CONFIGFILE,'r+'))) {
        $msg='Unable to open config file for writing. Permission denied!';
        echo_flush('ko', $msg,'');
      } else {
        $configfile= str_replace("define('ZADSINSTALLED',FALSE);","define('ZADSINSTALLED',TRUE);",$configfile);
        $configfile= str_replace('%CONFIG-DBHOST',$_POST['dbhost'],$configfile);
        $configfile= str_replace('%CONFIG-DBNAME',$_POST['dbname'],$configfile);
        $configfile= str_replace('%CONFIG-DBUSER',$_POST['dbuser'],$configfile);
        $configfile= str_replace('%CONFIG-DBPASS',$_POST['dbpass'],$configfile);
        $configfile= str_replace('%CONFIG-DBPREFIX',$_POST['prefix'],$configfile);
      
        if ($configfile){
          @fclose($fp);
          $fp = @fopen(CONFIGFILE,'w'); // position cursor at the beg 
           if (fwrite($fp,$configfile)){ 
              echo_flush('ok', 'DB Config file updated','');
              require_once($SETTINGS_PATH."db_settings.php");
              echo_flush('ok', _('DB Config file exists, default DB Prefix is :').'<b>'. $DB_PREFIX.'</b>','');
          }
          else { 
            echo_flush('ok', 'error in writting config file','');
          }
        }
      }
      @fclose($fp);

    } else {

      if(preg_match("/define\('OSTINSTALLED',FALSE\)\;/i",$configfile) || strpos($configfile,'%CONFIG-DBHOST')){
        $msg=_('Configuration file not correctly defined !');
        echo_flush('ko', $msg,'');
        display_dbsetupform();
        exit; 
      } else {
        require_once($SETTINGS_PATH."db_settings.php");
        echo_flush('ok', _('DB Config file exists, default DB Prefix is :').'<b>'. $DB_PREFIX.'</b>','');
      }
    }
    echo '</br>';
}


// --- display menu -----//
$chain=false; 
if (isset($_GET["step"])) {
  $step = $_GET["step"]; 
  
  if ($step=='full') {$step='check'; $chain=true;} else  {$chain=false;}
  echo str_pad(_('Starting processing ...'),4096)."<br />\n"; 
  if (ob_get_level() == 0) { // 0 if buffer is disabled . then enable it
      ob_start();
  }
}
else { 
  // display the menu 
  $tmphtml = ""; 
  $tmphtml .='<div class="main_menu">';
  $tmphtml .= '<div class="title">'._(' ZADS MIGRATION ').'</div>'; 
  $tmphtml .='<ul class="nemu">';
  $tmphtml .= '<li><a href="?step=check">'._('Check environment').'</a><br></li>';
  $tmphtml .= '<br>';
  $tmphtml .= '<li><a href="?step=migrate_ads">'._('Migrate tbl_hebergements -> Ads').'</a><br></li>';
  $tmphtml .= '<li><a href="?step=migrate_users">'._('Migrate tbl_proprietaires -> Users').'</a><br></li>';
  $tmphtml .= '<br>';
  $tmphtml .= '<li><a href="?step=patch_imgnames">'._('patch_imgnames in ADs').'</a><br></li>';
  $tmphtml .= '<li><a href="?step=patch_nullindes">'._('patch_nullindes in ADs').'</a><br></li>';


  $tmphtml .= '<li><a href="?step=special">'._('special').'</a><br></li>';
  $tmphtml .= '<li><a href="?step=cleandebugfile">'._('Clean Debug file').'</a><br></li>';
  $tmphtml .='</ul>';
  $tmphtml .='</div>';
  echo $tmphtml; 
  exit; 
}

// DB connection
  $databasehost = $DB_HOST;
  $databaseusername =$DB_USERNAME;  
  $databasepassword =$DB_PASSWORD;  
  
  $databasename = $DB_NAME;  //cads = classified adds. 
  
  $dbItemsTable = $DB_PREFIX.$DB_TABLE_ITEMS ; 
  $dbCatsTable = $DB_PREFIX.$DB_TABLE_CATS; 
  $dbUsersTable = $DB_PREFIX.$DB_TABLE_USERS; 
  $dbStatsTable = $DB_PREFIX.$DB_TABLE_STATS; 
  $dbLogsTable = $DB_PREFIX.$DB_TABLE_LOGS; 
  $dbPaymentsTable = $DB_PREFIX.$DB_TABLE_PAYMENTS;
  $dbBannersTable = $DB_PREFIX.$DB_TABLE_BANNERS;
  $dbVisitorsTable = $DB_PREFIX.$DB_TABLE_VISITORS;
  $dbServicesTable = $DB_PREFIX.$DB_TABLE_SERVICES;

  // @Z5.5
  $dbSubscribersTable = $DB_PREFIX.$DB_TABLE_SUBSCRIBERS;
  $dbVFieldsTable = $DB_PREFIX.$DB_TABLE_VFIELDS;
  

  $fullfqdn = $DOMAIN_FQDN; 



  // nouvelles tables lokaweb 
  $tbl_hebergement="tbl_hebergement"; 
  $tbl_photo_hebergement = "tbl_photo_hebergement";
  $tbl_proprietaire = "tbl_proprietaire";
  $tbl_zone="tbl_zone";


  
// ------------- Connection to database ------------- 

if (($step!="check")){  
  // connect to database whatever the menu is 
  //  --- open socket to MySQL database
  $con = mysql_connect ($databasehost,$databaseusername, $databasepassword) or die();
  //set desired encoding just in case mysql charset is not UTF-8 - Thanks to FreshMedia
  if ($con) {  
    @mysql_query('SET NAMES "UTF8"');
    @mysql_query('SET COLLATION_CONNECTION=utf8_general_ci');
  }
  mysql_select_db ( $databasename ) or die();
}


// -------------------MIGRATE HEBERGEMENTS ---------------------------------
if (($step=='migrate_ads')) { 

  $t0=microtime(true); 
  echo str_pad('<h1 class="start">'._('migrate_ads  ...').'</h1>',4096)."\n";  
  $stamp= date( 'Y-m-d H:i:s', time());  

  // $limit=" LIMIT 0, 500"; 
  $limit=''; 
  $filter=" WHERE  `he_date` >  '2012-01-01 00:00:00' AND  `he_hebergement` !=  '' "; 
  $group =""; 
  $join= " LEFT JOIN `$tbl_zone` z1 ON `he_id_zone`= z1.`zo_id_zone` ";
  $join .= " LEFT JOIN `$tbl_zone` z2 ON z1.`zo_id_zone_parent`= z2.`zo_id_zone` ";
  $order =" ORDER by `he_date` ASC ";

  $query = "SELECT  he.*, z1.`zo_zone` as he_dept,  z2.`zo_zone` as he_reg  FROM `$tbl_hebergement` he $join $filter $group $order $limit  " ; 
  //echo ($query); return false;

  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; echo_flush('ko', $msg,''); }
  else {

    $nbrows = mysql_num_rows($result); 
  
    $msg= "Found <b>$nbrows</b>HEBERGEMENTS to be migrated <br>\n";
    echo_flush('ok', $msg,''); 

    // time tracker
    $deltatime= (microtime(true)-$t0); 
    $msg= "Processed in :<b>".sprintf("%01.3f", $deltatime). "</b> sec <br>\n "; 
    echo_flush('info', $msg,'');

    $t0=microtime(true); 
    $cnt=0; $max_pics=0; 
    while ($row = mysql_fetch_array($result)) {
      $cnt+=1; 


    // get the picture elements
    //       `phe_id_photo_hebergement` int(11) NOT NULL AUTO_INCREMENT,
    // `phe_id_hebergement` int(11) NOT NULL,
    // `phe_photo_1` varchar(255) NOT NULL,
    // `phe_photo_2` varchar(255) NOT NULL,
    // `phe_photo_3` varchar(255) NOT NULL,
    // `phe_date` datetime NOT NULL,
    // `phe_publie` smallint(6) NOT NULL DEFAULT '1',
    // `phe_rang` int(11) NOT NULL,

    $this_he_id=$row['he_id_hebergement'];
    
    $slq_imgname='';

    $limit=" LIMIT 0, 3"; 
    $filter=" WHERE  `phe_id_hebergement` =  '$this_he_id' AND `phe_photo_2` !='' "; 
    $group =""; 
    $order=" order by `phe_rang` ASC "; 
    $query3 = "SELECT  * FROM `$tbl_photo_hebergement`" .$filter." ". $group." ". $order ." ". $limit ; 
    $result3 = mysql_query($query3);
    if (!$result3)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query3; echo_flush('ko', $msg,''); }
    else {
      $nb_pics = mysql_num_rows($result3); 
      if ($nb_pics>$max_pics) $max_pics=$nb_pics; 
      $msg= "$cnt - AD # ".$this_he_id." as  <b>".$nb_pics." </b> PICTURES , max is $max_pics <br>\n";
      if ($nb_pics){
        while ($row3 = mysql_fetch_array($result3)) {
          $ppiece=explode('/',$row3['phe_photo_2']);
          $picname = $ppiece[count($ppiece)-1]; 
          $slq_imgname.= ";". $picname.'|lokaweb_img|0';
        } 
        $slq_imgname= ltrim ($slq_imgname,';'); // remove the leading char
      }
      $msg .= $slq_imgname."</br>";
      //echo_flush('ok', $msg,''); 
    }

    /* image format */
    // finenameondisk|originalnam|size;finenameondisk|originalnam|size; 
    // file_20140426-053848.jpg|a-team.jpg|194581;file_20140426-053855.jpg|125324-quatchi-la-mascotte-de-vancouver-2010-650x0-1.jpg|31787
    $imgname=$slq_imgname;
    //continue;

      // update the dates by copying MODDATE to createdate & first published dates 
      //$idtmpx = $row['id']; 
      //$newdate =  $row['moddate']; 
      $limit2="";
// CREATE TABLE IF NOT EXISTS `tbl_hebergement` (
//   `he_id_hebergement` int(11) NOT NULL AUTO_INCREMENT,
//   `he_id_proprietaire` int(11) NOT NULL,
//   `he_id_type_hebergement` varchar(100) NOT NULL,
//   `he_id_destination` tinyint(4) NOT NULL DEFAULT '1',
//   `he_id_zone` int(11) DEFAULT NULL,
//   `he_id_ville` int(11) NOT NULL DEFAULT '500',
//   `he_adresse` varchar(255) NOT NULL,
//   `he_code_postal` varchar(20) NOT NULL,
//   `he_ville` varchar(100) NOT NULL,
//   `he_pays` varchar(100) NOT NULL,
//   `he_hebergement` varchar(255) NOT NULL,
//   `he_nombre_personne` int(4) NOT NULL,
//   `he_nombre_etoile` int(4) NOT NULL,
//   `he_nombre_piece` int(4) NOT NULL,
//   `he_nombre_chambre` int(4) NOT NULL,
//   `he_nombre_salle_douche` mediumint(4) NOT NULL,
//   `he_nombre_salle_bain` mediumint(4) NOT NULL,
//   `he_nombre_wc` mediumint(4) NOT NULL,
//   `he_nombre_lit_2_place` mediumint(4) NOT NULL,
//   `he_nombre_lit_1_place` mediumint(4) NOT NULL,
//   `he_nombre_canape_lit` mediumint(4) NOT NULL,
//   `he_nombre_lit_bebe` mediumint(4) NOT NULL,
//   `he_surface` int(5) NOT NULL,
//   `he_surface_2` int(5) DEFAULT NULL,
//   `he_surface_terrain` int(6) NOT NULL,
//   `he_prix_min` int(6) NOT NULL,
//   `he_prix_max` int(6) NOT NULL,
//   `he_prix_periode` varchar(100) NOT NULL,
//   `he_prix_mobilhome_min` int(6) NOT NULL,
//   `he_prix_mobilhome_max` int(6) NOT NULL,
//   `he_prix_mobilhome_periode` varchar(50) NOT NULL,
//   `he_prix_maj` date NOT NULL,
//   `he_descriptif` text NOT NULL,
//   `he_coord` varchar(50) NOT NULL,
//   `he_url` varchar(255) NOT NULL,
//   `he_date_lien_direct` date NOT NULL,
//   `he_url_retour` varchar(255) NOT NULL,
//   `he_url_video` varchar(255) DEFAULT NULL,
//   `he_type_a_la_une` tinyint(4) NOT NULL DEFAULT '1',
//   `he_phrase_a_la_une` varchar(140) NOT NULL,
//   `he_date` datetime NOT NULL,
//   `he_date_tete_de_liste` date NOT NULL,
//   `he_coup_de_coeur` date DEFAULT NULL,
//   `he_espace_promotion` date DEFAULT NULL,
//   `he_phrase_espace_promotion` varchar(255) DEFAULT NULL,
//   `he_date_video` date NOT NULL DEFAULT '0000-00-00',
//   `he_date_camping` date NOT NULL,
//   `he_date_hotel` date NOT NULL,
//   `he_date_site_perso` date NOT NULL DEFAULT '0000-00-00',
//   `he_date_appreciation` date NOT NULL,
//   `he_date_a_la_une` date NOT NULL,
//   `he_date_pack_annonce` date NOT NULL,
//   `he_publie` tinyint(1) NOT NULL,
//   `he_cgv` binary(1) NOT NULL,
//   PRIMARY KEY (`he_id_hebergement`),
//   KEY `he_id_zone` (`he_id_zone`),
//   KEY `he_id_type_hebergement` (`he_id_type_hebergement`),
//   KEY `he_id_ville` (`he_id_ville`)
// ) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9299 ;


      // make the conversion OLD ->  NEW
      $thisid=$row['he_id_hebergement'];
      $userid=$row['he_id_proprietaire']; 
      $stamp= date( 'Y-m-d H:i:s', time());
      
      if (my_detect_encoding($row['he_descriptif']) == "ENCODED" || my_detect_encoding($row['he_hebergement']) == "ENCODED" ){
        $title = addslashes(($row['he_hebergement']));
        $description = addslashes(($row['he_descriptif']));
        $location= addslashes($row['he_adresse'].','.$row['he_code_postal'].' '.$row['he_ville'].','.$row['he_pays']);
        $locdept=addslashes($row['he_dept']); 
        $locregion=addslashes($row['he_reg']);
        $loczipcode=addslashes($row['he_code_postal']); 
        $loccity=addslashes($row['he_ville']); 

      } else {
        $title = addslashes(utf8_encode2($row['he_hebergement']));
        $description = addslashes(utf8_encode2($row['he_descriptif']));
        $location= addslashes(utf8_encode2($row['he_adresse'].','.$row['he_code_postal'].' '.$row['he_ville'].','.$row['he_pays']));

        $locdept=addslashes(utf8_encode2($row['he_dept'])); 
        $locregion=addslashes(utf8_encode2($row['he_reg']));
        $loczipcode=addslashes(utf8_encode2($row['he_code_postal'])); 
        $loccity=addslashes(utf8_encode2($row['he_ville'])); 

      }


      $status='40';
      $type='sell';
      $logs='imported'; // special

      if ($row['he_url']){
        $links= $row['he_url'].';'.$row['he_url'];
      } else $links='';


      $vf_str = '';
      
      // process the vfields
      $destination_to_vfield  =  array (
          "1" => "mer"
          ,"2" => "campagne"
          ,"3" => "montagne"
          ,"4" => "ville"
      );
      if ($destination_to_vfield[$row['he_id_destination']]) {
         $destid = $destination_to_vfield[$row['he_id_destination']];
         $vf_str.='|4='.$destid; 
      } 

      $vf_str.='|5='.$row['he_nombre_personne'];
      $vf_str.='|6='.$row['he_nombre_etoile'];

      $vf_str.='|7='.$row['he_nombre_piece'];
      $vf_str.='|8='.$row['he_nombre_chambre'];
      $vf_str.='|9='.$row['he_nombre_salle_douche'];
      $vf_str.='|10='.$row['he_nombre_salle_bain'];
      $vf_str.='|11='.$row['he_nombre_wc'];
      $vf_str.='|12='.$row['he_nombre_lit_2_place'];
      $vf_str.='|13='.$row['he_nombre_lit_1_place'];
      $vf_str.='|14='.$row['he_nombre_canape_lit'];
      $vf_str.='|15='.$row['he_nombre_lit_bebe'];

      $vf_str.='|16='.$row['he_surface'];
      $vf_str.='|17='.$row['he_surface_terrain'];
      
      $vf_str.='|18='.$row['he_prix_min'];
      $vf_str.='|19='.$row['he_prix_max'];

      $cat_vfields_str= ltrim ($vf_str,'|'); // remove the leading char

      // update the coordonées  48.4928302|7.710150699999986
      $pieces = explode(",", $row['he_coord']);
      if (count($pieces)>1) {
        $theloclat=$pieces[0]; 
        $theloclng=$pieces[1]; 
        $loclatlng=str_replace(",","|", $row['he_coord']);; 
      }

      // mapping categories
      // (1, 'appartement', '', 0, 2),
      // (2, 'maison / villa', '', 0, 1),
      // (3, 'gîte', '', 0, 3),
      // (4, 'chambre d’hôte', '', 0, 4),
      // (5, 'camping', 'Tarification à l''année selon nombre d''étoile', 1, 5),
      // (6, 'insolite', '', 0, 6),
      // (7, 'mobilhome', 'Je certifie sur l''honneur être un particulier et non pas un professionnelle du camping ou de loisirs de plein air', 0, 7),
      // (8, 'chalet', '', 0, 8),
      // (9, 'bungalow', 'Je certifie sur l''honneur être un particulier et non pas un professionnelle du camping ou de loisirs de plein air', 0, 9),
      // (10, 'château / manoir', '', 0, 10),
      // (11, 'bâteau / voilier / péniche', '', 0, 11),
      // (12, 'studio', '', 0, 2),
      // (15, 'hôtel', 'Tarification à l''année : 45 Euros TTC', 1, 15);

      // 10041 apartement  1/12
      // 10040 maisons 2/6/8/10/
      // 10039 gites et chambres d'hôtes 3/4 **
      // 10038 mobilhomes 5/7/9

      $type_to_catid  =  array (
          "1" => "10041"
          ,"2" => "10040"
          ,"3" => "10039"
          ,"4" => "10039"
          ,"5" => "10038"
          ,"6" => "10040"
          ,"7" => "10038"
          ,"8" => "10040"
          ,"9" => "10038"
          ,"10" => "10040"
          ,"11" => "10099"
          ,"12" => "10040"
          ,"15" => "10099"
      );

      if ($type_to_catid[$row['he_id_type_hebergement']]) {
         $catid = $type_to_catid[$row['he_id_type_hebergement']];
      } else  $catid=''; 

      $price='';
      $pricetype='';
      $paid_param=''; 

      $username='';
      $phone='';
      $email='';
     
    
 
      $loccountrycode=''; 
      $lochash=''; 
      $lochashregion=''; 
       
      $vtag1=''; 
      $vtag2=''; 
      $vtag3=''; 
      $vtag4=''; 
      $vtag5='';

      $priority= 'high';
      $urgent= '';
      $videoembed='';
      $video2='';     

      $dbThisTable = $dbItemsTable; 
        
      $query2 = "INSERT INTO `".$dbThisTable."` 
        (`logs`,`id`, `userid`, `moddate`,`createdate`,`firstpublisheddate`, `crondate`, `title`, `description`,  `priority`,`urgent`,`catid`, `vfields`, `type`,`price`,`pricetype`,`paidoptions`,`imgname`, `videoembed`, `video2`, `status`,`username`,`phone`, `email`,`location`,`loclatlng`, `loclat`,  `loclng`,  `loczipcode`, `loccity`, `locdept`, `locregion`, `loccountrycode`, `lochash`, `lochashregion`,`links`,`vtag1`,`vtag2`,`vtag3`,`vtag4`,`vtag5`) ";
      $query2 .= "VALUES ('$logs', '$thisid', '$userid', '$stamp', '$stamp','$stamp','$stamp', '$title', '$description',  '$priority','$urgent','$catid', '$cat_vfields_str', '$type','$price','$pricetype', '$paid_param', '$imgname','$videoembed','$video2','$status','$username','$phone','$email','$location','$loclatlng','$theloclat','$theloclng','$loczipcode','$loccity','$locdept','$locregion','$loccountrycode','$lochash','$lochashregion','$links', '$vtag1', '$vtag2','$vtag3', '$vtag4', '$vtag5');";       

      $result2 = mysql_query($query2);
      // $result2=true;
      if ($result2){
        $nbrows2 = mysql_affected_rows();
        if ($nbrows2 > 0) {
          $msg= "$cnt - AD ".$thisid." inserted  : -- Encoding =  <b>".my_detect_encoding($row['he_descriptif']) ." </b>-- ".$row['he_hebergement']." </b> <br>\n";
          echo_flush('ok', $msg,''); 
        }
      } else  {  $msg = "Invalid SQL request : $query2  /  " . mysql_error(); echo_flush('ko', $msg,'');}
    } 
    // end while 
  } // end -if 

  // time tracker
  $deltatime= (microtime(true)-$t0); 
  $msg= "Processed in :<b>".sprintf("%01.3f", $deltatime). "</b> sec <br>\n "; 
  echo_flush('info', $msg,''); 


  $step="end"; // forward to menu end 
}

// -------------------MIGRATE USERS ---------------------------------
if (($step=='migrate_users')) { 
  $t0=microtime(true); 
  echo str_pad('<h1 class="start">'._('migrate_users  ...').'</h1>',4096)."\n";  
  $stamp= date( 'Y-m-d H:i:s', time());  

  $limit=" LIMIT 0, 5"; $limit="";
  // $filter=" WHERE  `tomigrate` = 1  AND `pr_id_proprietaire` = '5837' "; 
  $filter=" WHERE  `tomigrate` = 2  "; 

  $group =""; 
  $query = "SELECT  *  FROM `$tbl_proprietaire`" .$filter." ". $group." ". $limit ; 
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; echo_flush('ko', $msg,''); }
  else {

    $nbrows = mysql_num_rows($result); 
  
    $msg= "Found $nbrows USERS to be updated  <br>\n";
    echo_flush('ok', $msg,''); 
    $cnt=0; $max_pics=0; 
    while ($row = mysql_fetch_array($result)) {
      $cnt+=1; 
      $thisid = $row['pr_id_proprietaire']; 
      
    // CREATE TABLE IF NOT EXISTS `tbl_proprietaire` (
    //   `pr_id_proprietaire` int(11) NOT NULL AUTO_INCREMENT,
    //   `tomigrate` tinyint(1) NOT NULL,
    //   `pr_mail` varchar(255) NOT NULL,
    //   `pr_mdp` varchar(32) NOT NULL,
    //   `pr_mdp_non_crypte` varchar(50) NOT NULL,
    //   `pr_civilite` varchar(20) NOT NULL,
    //   `pr_nom` varchar(100) NOT NULL,
    //   `pr_prenom` varchar(100) NOT NULL,
    //   `pr_adresse` varchar(255) NOT NULL,
    //   `pr_code_postal` varchar(10) NOT NULL,
    //   `pr_ville` varchar(100) NOT NULL,
    //   `pr_pays` varchar(50) NOT NULL,
    //   `pr_telephone` varchar(20) NOT NULL,
    //   `pr_portable` varchar(20) NOT NULL,
    //   `pr_fax` varchar(20) NOT NULL,
    //   `pr_langue` varchar(50) NOT NULL,
    //   `pr_date` datetime NOT NULL,
    //   `pr_date_envoi` date NOT NULL,
    //   `pr_publie` binary(1) NOT NULL DEFAULT '0',
    //   `pr_newsletter` tinyint(4) NOT NULL DEFAULT '0',
    //   `pr_he_date_lien_direct` tinyint(1) NOT NULL,
    //   `pr_he_date_video` tinyint(1) NOT NULL,
    //   `pr_he_date_site_perso` tinyint(1) NOT NULL,
    //   `pr_he_date_appreciation` tinyint(1) NOT NULL,
    //   PRIMARY KEY (`pr_id_proprietaire`)
    // ) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8146 ;

      $thisid =  $row['pr_id_proprietaire']; 
      $username=''; 

      // civilités
      // M.
      // Mlle
      // Mme
      // m
      $male = array("M.", "m");
      if (in_array($row['pr_civilite'],$male )){
        $gender='male';
      } else $gender='female';
     
    
      $auth=''; 
      $username=$row['pr_nom'];
      $password=$row['pr_mdp']; 
      $usertype=0; // default 
      $firstname=$row['pr_prenom'];
      $lastname=$row['pr_nom'];
      $email=$row['pr_mail']; 
      $phone=$row['pr_telephone'];
      $phone2=$row['pr_fax'];


      if (my_detect_encoding($row['pr_adresse']) == "ENCODED" || my_detect_encoding($row['pr_ville']) == "ENCODED" )
        $location= addslashes(utf8_encode2($row['pr_adresse'].','.$row['pr_code_postal'].' '.$row['pr_ville'].','.$row['pr_pays']));
      else       
        $location= addslashes(utf8_encode2($row['pr_adresse'].','.$row['pr_code_postal'].' '.$row['pr_ville'].','.$row['pr_pays']));

      $loclatlng='';
      $theloclat='';
      $theloclng='';
      $loczipcode='';
      $loccity='';
      $locdept='';
      $locregion='';
      $loccountrycode='';
      $lochash='';
      $lochashregion='';


      $stamp= date( 'Y-m-d H:i:s', time());
      $status='80'; // publiched account 
      $desc3='imported'; // special

      $avatarimgname='';
      $folioimgname=''; 

      $userid=0; 
      $locale=''; 
      
      $probannerimgname='';
      $skills='';

      $priority='high';
      $protype='par';
      $indir='yes'; 
      $plan='plan_2';

      if ($row['pr_newsletter']==1)
      $in_newletter='yes'; else $in_newletter='';

      // save the language 
      $desc2=$row['pr_langue'];

      $procpny=''; 
      $prosiret=''; 
      $prowebsite=''; 
      $social=''; 
      $bio=''; 
      $paid_param='';

      $longdesc='';
      $videoembed='';
      $serverremoteaddr='';
      $openhours='';
      $uagent=''; 
      $desc2='';
      
     
      $email2='';
      $cat2='';
      $cat3='';
      $links='';
      $address2=''; 
      $date2=''; 
      $user_vfields_str=''; 


      $dbThisTable = $dbUsersTable; 
      $query2 = "INSERT INTO `".$dbThisTable."` 
              (`id`, `username`, `auth`, `gender`, `password`,  `usertype`, `firstname`, `lastname`,  `email`, `phone`, `registerdate`, `moddate`, `lastvisitdate`, `status`, `avatarimg`,`folioimg`, `userid`, `locale`,`location`,`loclatlng`, `loclat`,  `loclng`, `loczipcode`, `loccity`, `locdept`, `locregion`, `loccountrycode`, `lochash`, `lochashregion`, `probannerimg`, `skills`, `priority`, `protype`, `indir`,  `banclicks`, `procpny`, `prosiret`, `prowebsite`,  `social`,  `bio`, `paidoptions`,`plan`, `longdesc`,`videoembed`,`openhours`, `ip`,`useragent`,`desc2` , `desc3`, `phone2`, `email2`, `cat2`, `cat3`, `links`, `address2`, `date2`,`vfields`,`newsletter`  )"; 
      $query2 .= "VALUES 
              ('$thisid', '$username', '$auth', '$gender', '$password', '$usertype', '$firstname', '$lastname','$email', '$phone', '$stamp','$stamp','$stamp','$status','$avatarimgname','$folioimgname', '$userid', '$locale', '$location','$loclatlng','$theloclat','$theloclng','$loczipcode','$loccity','$locdept','$locregion','$loccountrycode','$lochash','$lochashregion','$probannerimgname','$skills','$priority','$protype','$indir',  '0', '$procpny', '$prosiret', '$prowebsite', '$social', '$bio', '$paid_param','$plan','$longdesc' ,'$videoembed','$serverremoteaddr','$openhours','$uagent', '$desc2','$desc3','$phone2','$email2','$cat2','$cat3','$links','$address2', '$date2', '$user_vfields_str', '$in_newletter');";
        
      $result2 = mysql_query($query2);
      // $result2=true;
      if ($result2){
        $nbrows2 = mysql_affected_rows();
        if ($nbrows2 > 0) {
          $msg= "$cnt - USER ".$thisid." inserted  :  <b> $firstname - $lastname </b>  <br>\n";
          echo_flush('ok', $msg,''); 
        }
      } else  {  $msg = "Invalid SQL request : $query2  /  " . mysql_error(); echo_flush('ko', $msg,'');}

    } // end while 
  } // end -if 

  // time tracker
  $deltatime= (microtime(true)-$t0); 
  $msg= "Processed in :<b>".sprintf("%01.3f", $deltatime). "</b> sec <br>\n "; 
  echo_flush('info', $msg,''); 


  $step="end"; // forward to menu end 
}


// -------------------MIGRATE USERS (PART 1 = MARKING all USERS TO BE MIGRATED ---------------------------------
if (($step=='migrate_users_part1')) { 
  echo str_pad('<h1 class="start">'._('migrate_users  ...').'</h1>',4096)."\n";  
  $stamp= date( 'Y-m-d H:i:s', time());  

  $limit=" LIMIT 0, 30"; $limit="";
  $filter=" WHERE  `he_date` <  '2012-01-01 00:00:00' AND  `he_hebergement` !=  '' "; 
  $group =""; 
  $query = "SELECT  DISTINCT `he_id_proprietaire` AS 'userid'  FROM `$tbl_hebergement`" .$filter." ". $group." ". $limit ; 
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; echo_flush('ko', $msg,''); }
  else {

    $nbrows = mysql_num_rows($result); 
  
    $msg= "Found $nbrows USERS to be marked <br>\n";
    echo_flush('ok', $msg,''); 
    $cnt=0; $max_pics=0; 
    while ($row = mysql_fetch_array($result)) {
      $cnt+=1; 
      $this_userid = $row['userid']; 
      $msg= "User id is $this_userid <br>\n";
      echo_flush('ok', $msg,'');
      
    // CREATE TABLE IF NOT EXISTS `tbl_proprietaire` (
    //   `pr_id_proprietaire` int(11) NOT NULL AUTO_INCREMENT,
    //   `tomigrate` tinyint(1) NOT NULL,
    //   `pr_mail` varchar(255) NOT NULL,
    //   `pr_mdp` varchar(32) NOT NULL,
    //   `pr_mdp_non_crypte` varchar(50) NOT NULL,
    //   `pr_civilite` varchar(20) NOT NULL,
    //   `pr_nom` varchar(100) NOT NULL,
    //   `pr_prenom` varchar(100) NOT NULL,
    //   `pr_adresse` varchar(255) NOT NULL,
    //   `pr_code_postal` varchar(10) NOT NULL,
    //   `pr_ville` varchar(100) NOT NULL,
    //   `pr_pays` varchar(50) NOT NULL,
    //   `pr_telephone` varchar(20) NOT NULL,
    //   `pr_portable` varchar(20) NOT NULL,
    //   `pr_fax` varchar(20) NOT NULL,
    //   `pr_langue` varchar(50) NOT NULL,
    //   `pr_date` datetime NOT NULL,
    //   `pr_date_envoi` date NOT NULL,
    //   `pr_publie` binary(1) NOT NULL DEFAULT '0',
    //   `pr_newsletter` tinyint(4) NOT NULL DEFAULT '0',
    //   `pr_he_date_lien_direct` tinyint(1) NOT NULL,
    //   `pr_he_date_video` tinyint(1) NOT NULL,
    //   `pr_he_date_site_perso` tinyint(1) NOT NULL,
    //   `pr_he_date_appreciation` tinyint(1) NOT NULL,
    //   PRIMARY KEY (`pr_id_proprietaire`)
    // ) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8146 ;

      // update the dates by copying MODDATE to createdate & first published dates
      $sub_step=1; 
      if ($sub_step==1) {
        $limit2="";
        $filter2="WHERE (`pr_id_proprietaire` = '".$this_userid."') ";     
        $query2 = "UPDATE `".$tbl_proprietaire."` SET   
             `tomigrate`= 2
             ".$filter2. " ". $limit2;
        $result2 = mysql_query($query2);
        if ($result2){
          $nbrows2 = mysql_affected_rows();
          if ($nbrows2 > 0) {
            $msg= "$cnt - USER ".$this_userid." marked as TOBEMIGRATED <br>\n";
            echo_flush('ok', $msg,''); 
          }
        } else  {  $msg = "Invalid SQL request : $query2  /  " . mysql_error(); echo_flush('ko', $msg,'');}

      }

    } // end while 
  } // end -if 

  $step="end"; // forward to menu end 
}






// get list of regionsfrom DB
// SELECT distinct `locregion`, count(`id`) as 'nbid'  FROM `z6items` WHERE 1 group by `locregion`



// -------------------PATCH IMAGES NAMES  ---------------------------------
if (($step=='patch_imgnames')) { 
  echo str_pad('<h1 class="start">'._('Patch images names  ...').'</h1>',4096)."\n";  
  $stamp= date( 'Y-m-d H:i:s', time());  

  //$limit=" LIMIT 0, 30"; 
  $limit="";
  $filter=" WHERE `imgname` !='' "; 
  $group =""; 
  $query = "SELECT  `imgname`, `id`   FROM `$dbItemsTable`" .$filter." ". $group." ". $limit ; 
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; echo_flush('ko', $msg,''); }
  else {

    $nbrows = mysql_num_rows($result); 
  
    $msg= "Found $nbrows IMG to be marked <br>";
    echo_flush('ok', $msg,''); 
    echo "<br/>"; 
    $cnt=0; $max_pics=0; 
    while ($row = mysql_fetch_array($result)) {
      $cnt+=1; 
      $p=$row['imgname'];
      $thisid=$row['id'];
      echo $cnt." ----- processing  : $p  : ";
      $ppiece=explode('-M',$p);
      $newname=''; 
      foreach ($ppiece as $value) {
        # code...
        $newname .=$value;
      }

        $limit2="";
        $filter2="WHERE (`id` = '".$thisid."') ";     
        $query2 = "UPDATE `".$dbItemsTable."` SET   
             `imgname`= '$newname'
             ".$filter2. " ". $limit2;
        $result2 = mysql_query($query2);

        // $result2=true;
        // $result2 = rename('../uploads/img/'.$p,'../uploads/img/'.$newname);

      if ($result2) { 
        // echo " --> EXTST \n<br/>";
        echo " --> $thisid UPDATED  from $p TO :  $newname  \n<br/>";
        //echo " --> COULD rename $p T0 : <b>$newname</b>  \n<br/>";
      } else  {  $msg = "Invalid SQL request : $query2  /  " . mysql_error(); echo_flush('ko', $msg,'');}

      echo "<br/>";  

    
    } // end while 
  } // end -if 

  $step="end"; // forward to menu end 
}


// -------------------PATCH NULL in DESIGNATIONS ---------------------------------
if (($step=='patch_nullindes')) { 
  echo str_pad('<h1 class="start">'._('Patch images names  ...').'</h1>',4096)."\n";  
  $stamp= date( 'Y-m-d H:i:s', time());  

  $limit=" LIMIT 0, 300"; 
  //$limit="";
  $filter=" WHERE `imgname` !='' and `id`=9192 "; 
  $group =""; 
  $order =" ORDER by `moddate` ASC ";
  $query = "SELECT  `description`, `id`   FROM `$dbItemsTable` $filter $group $order $limit " ; 
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; echo_flush('ko', $msg,''); }
  else {

    $nbrows = mysql_num_rows($result); 
  
    $msg= "Found $nbrows DESC to be marked <br>";
    echo_flush('ok', $msg,''); 
    echo "<br/>"; 
    $cnt=0; $max_pics=0; 
    while ($row = mysql_fetch_array($result)) {
      $cnt+=1; 
      // $thisdesc=stripslashes($row['description']);
      $thisid=$row['id'];

      $outdata = Array (
                    'desc' => stripslashes($row['description'])
                  );
      
      $json_txt = json_encode($outdata); 

      $thisdes_out= json_decode($json_txt); 
      var_dump($thisdes_out);
      $thisdesc=$thisdes_out->desc;


      echo json_last_error();
      echo "<br/>"; 
      echo $cnt." ----- processing  : $thisid  : ";
      echo " --> DESC =  ".utf8_encode($thisdesc)." \n<br/>";
      echo " --> DESC =  ".utf8_decode($thisdesc)." \n<br/>";


     
      // foreach ($ppiece as $value) {
      //   # code...
      //   $newname .=$value;
      // }

      //   $limit2="";
      //   $filter2="WHERE (`id` = '".$thisid."') ";     
      //   $query2 = "UPDATE `".$dbItemsTable."` SET   
      //        `imgname`= '$newname'
      //        ".$filter2. " ". $limit2;
      //   $result2 = mysql_query($query2);

      //   // $result2=true;
      //   // $result2 = rename('../uploads/img/'.$p,'../uploads/img/'.$newname);

      // if ($result2) { 
      //   // echo " --> EXTST \n<br/>";
      //   echo " --> $thisid UPDATED  from $p TO :  $newname  \n<br/>";
      //   //echo " --> COULD rename $p T0 : <b>$newname</b>  \n<br/>";
      // } else  {  $msg = "Invalid SQL request : $query2  /  " . mysql_error(); echo_flush('ko', $msg,'');}

      echo "<br/>";  

    
    } // end while 
  } // end -if 

  $step="end"; // forward to menu end 
}





// ------------------- CREATE SAMPLE of CATAEGORIES ---------------------------------
if (($step=='createcats')) { 
  echo str_pad('<h1 class="start">'._('Creating Template Categories ...').'</h1>',4096)."\n";  
  $stamp= date( 'Y-m-d H:i:s', time());  
  $status="ok";
  if (!$chain) $admin_id = "";
  $query = "
  INSERT INTO `".$dbCatsTable."` (`id`, `moddate`, `title`, `description`, `catid`, `type`, `priority`, `price`, `imgname`, `dirurl`, `location`, `userid`, `username`, `phone`, `email`, `status`, `logs`, `hits`) VALUES
  ('', '".$stamp."', 'Co-voiturage', 'co-voiturage', 0, '', '', 0, 'file_20101209-214929.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'PuÃ©riculture', 'Tout pour bÃ©bÃ©.', 0, '', '', 0, 'file_20101209-213701.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Automobile', 'Tout sur l''automobile et piÃ©ces dÃ©tachÃ©es', 0, '', '', 0, 'file_20101209-215826.JPG', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Deux roues', 'Deux roues', 0, '', '', 0, 'file_20101209-213635.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Garde d''enfants', 'Garde d''enfants', 0, '', '', 0, 'file_20101209-214910.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Immobilier', 'Immobilier', 0, '', '', 0, 'file_20101209-220051.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'VillÃ©giature / tourisme', 'VillÃ©giature / tourisme', 0, '', '', 0, 'file_20101209-220155.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Informatique', 'Informatique', 0, '', '', 0, 'file_20101209-214845.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'TV / Hi-Fi / Photo', 'TV / Hi-Fi / Photo', 0, '', '', 0, 'file_20101209-213512.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'ElectromÃ©nager', 'ElectromÃ©nager', 0, '', '', 0, 'file_20101209-213604.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Sports', 'Sports', 0, '', '', 0, 'file_20101209-214722.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Animaux', 'Animaux', 0, '', '', 0, 'file_20101209-213531.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Emploi / Cours', 'Emploi / Cours', 0, '', '', 0, 'file_20101209-213153.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Mode / BeautÃ©', 'Mode / BeautÃ©', 0, '', '', 0, 'file_20101209-213031.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Loisirs', 'Loisirs', 0, '', '', 0, 'file_20101209-220026.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Rencontres2', 'Rencontres', 0, '', '', 0, 'file_20101209-214552.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Meubles/Mobi', 'Meubles/Mobilier', 0, '', '', 0, 'file_20101209-212903.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Jeux / Jouets', 'Jeux / Jouets', 0, '', '', 0, 'file_20101209-214656.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Divers', 'divers', '', '', '', 0, '', NULL, '', $admin_id, '', '', '', '40', '', 0),
  ('', '".$stamp."', 'Spectacles', 'Spectacles', 0, '', '', 0, 'file_20101209-212805.jpg', NULL, '', $admin_id, '', '', '', '40', '', 0);
  "; 
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; }
  else $msg =  _("MySQL : creation of DEFAULT CATEGORIES sucessful !").'\n\r';
  echo_flush($status, $msg,''); 
  
  $step="end"; 
}





// -------------------PATCH DATES  ---------------------------------
if (($step=='patchddates')) { 
  echo str_pad('<h1 class="start">'._('Patching the dates  ...').'</h1>',4096)."\n";  
  $stamp= date( 'Y-m-d H:i:s', time());  

  $limit=""; 
  $filter=" WHERE `createdate` is null "; 
  $group =""; 
  $query = "SELECT  id, moddate FROM `$dbItemsTable`" .$filter." ". $group." ". $limit ; 
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; echo_flush('ko', $msg,''); }
  else {

    $nbrows = mysql_num_rows($result); 
  
    $msg= "Found $nbrows ads without a creation date <br>\n";
    echo_flush('ok', $msg,''); 
    $cnt=0; 
    while ($row = mysql_fetch_array($result)) {
      $cnt+=1; 
      // update the dates by copying MODDATE to createdate & first published dates 
      $idtmpx = $row['id']; 
      $newdate =  $row['moddate']; 
      $limit2="";
      $filter2="WHERE (`id` = '".$row['id']."') ";     
      $query2 = "UPDATE `".$dbItemsTable."` SET   
           `createdate`= '".$newdate."', 
           `firstpublisheddate`= '".$newdate."',
           `crondate`= '".$newdate."'
           ".$filter2. " ". $limit2;
      $result2 = mysql_query($query2);
      if ($result2){
        $nbrows2 = mysql_affected_rows();
        if ($nbrows2 > 0) {
          $msg= "$cnt - AD ".$row['id']." updated with date= $newdate <br>\n";
          echo_flush('ok', $msg,''); 
        }
      } else  {  $msg = "Invalid SQL request : $query2  /  " . mysql_error(); echo_flush('ko', $msg,'');}
    } // end while 
  } // end -if 

  $step="end"; // forward to menu end 
}


// -------------------PATCH PROTYPE  ---------------------------------
if (($step=='patchprotype')) { 
  echo str_pad('<h1 class="start">'._('Patching the PROTYPE->INDIR  ...').'</h1>',4096)."\n";  
  $stamp= date( 'Y-m-d H:i:s', time());  

  $limit=""; 
  $filter=" WHERE `protype` IN ('pub','pro') AND `indir` = '' "; 
  $group =""; 
  $query = "SELECT  id, moddate FROM `$dbUsersTable`" .$filter." ". $group." ". $limit ; 
  $result = mysql_query($query);
  if (!$result)  { $status="ko"; $msg= _("Could not successfully run query from DB: ").mysql_error(). "--".$query; echo_flush('ko', $msg,''); }
  else {

    $nbrows = mysql_num_rows($result); 
  
    $msg= "Found $nbrows users to patch <br>\n";
    echo_flush('ok', $msg,''); 
    $cnt=0; 
    while ($row = mysql_fetch_array($result)) {
      $cnt+=1; 
      // update the dates by copying MODDATE to createdate & first published dates 
      $limit2="";
      $filter2="WHERE (`id` = '".$row['id']."') ";     
      $query2 = "UPDATE `".$dbUsersTable."` SET   
           `indir`= 'yes'
           ".$filter2. " ". $limit2;
      $result2 = mysql_query($query2);
      if ($result2){
        $nbrows2 = mysql_affected_rows();
        if ($nbrows2 > 0) {
          $msg= "$cnt - AD ".$row['id']." updated with indir= yes <br>\n";
          echo_flush('ok', $msg,''); 
        }
      } else  {  $msg = "Invalid SQL request : $query2  /  " . mysql_error(); echo_flush('ko', $msg,'');}
    } // end while 
  } // end -if 

  $step="end"; // forward to menu end 
}




// ------------------- CLEAN DEBUG FILE  ---------------------------------
if (($step=='cleandebugfile')) { 
  
  echo str_pad('<h1 class="start">'._('Cleaning the debug file ...').'</h1>',4096)."\n";  
  $debugfile = fopen($debugoutputfile,"w"); if(!$debugfile) { echo "Error writing to the output file.\n";}
  else fwrite($debugfile,'file cleaned upon request<br>');
  fclose($debugfile);

  $step="end"; 
}





if (($step=='end')) {  
  // ------------------- End of INSTALL Process --------------------------------- 
  ob_end_flush();
  echo str_pad('<h1 class="end">'._('... end of processing.').'</h1>',4096)."\n"; 
  echo '<a href="?">'._('Go back to main menu').'</a><br>';
}


/*------------------------------------------------------------------------------*/
?>
    </div>
  </body>
</html>
<?php


function utf8_encode2($str) { 

    $final_str = $str; 

    $final_str = str_replace('œ', '&#339;',  $final_str); 
    $final_str = str_replace('’', '&#2019;', $final_str); 
    $final_str = str_replace('“', '&#201C;', $final_str); 
    $final_str = str_replace('”', '&#201D;', $final_str); 
    $final_str = str_replace('…', '&#2026;', $final_str); 
    $final_str = str_replace('€', '&#8364;', $final_str); 

    $final_str = str_replace('ê', 'e', $final_str); 
    
    $final_str = str_replace('À', 'A', $final_str); 
    $final_str = str_replace('ç', 'c', $final_str); 
    $final_str = str_replace('Ç', 'C', $final_str); 

    $final_str = str_replace('•', '-', $final_str); 
    $final_str = str_replace('°', ' ', $final_str);
    $final_str = str_replace('—', '-', $final_str);
    $final_str = str_replace('›', '>', $final_str); 

  
    $final_str = str_replace('Ê', 'E', $final_str);
    $final_str = str_replace('É', 'E', $final_str);
    $final_str = str_replace('Ë', 'E', $final_str);
    $final_str = str_replace('Â', 'A', $final_str);
    $final_str = str_replace('È', 'E', $final_str);
    $final_str = str_replace('–', '-', $final_str);
    $final_str = str_replace('Ô', 'O', $final_str);
    $final_str = str_replace('Ö', 'O', $final_str);
    $final_str = str_replace('Ï', 'I', $final_str);
    $final_str = str_replace('Î', 'I', $final_str);
    $final_str = str_replace('Œ', 'OE', $final_str);

    $final_str = str_replace('ù', 'u', $final_str);
    $final_str = str_replace('û', 'u', $final_str);
    $final_str = str_replace('Û', 'U', $final_str);

    $final_str = str_replace('×', 'x', $final_str);

  

    $final_str = utf8_encode($final_str); 

    $final_str = str_replace(utf8_encode('&#339;') , 'Å“',     $final_str); 
    $final_str = str_replace(utf8_encode('&#2019;'), 'â€™', $final_str); 
    $final_str = str_replace(utf8_encode('&#201C;'), 'â€œ', $final_str); 
    $final_str = str_replace(utf8_encode('&#2026;'), 'â€¦', $final_str); 
    $final_str = str_replace(utf8_encode('&#201D;'), 'â€', $final_str); 
    $final_str = str_replace(utf8_encode('&#8364;'), 'â‚¬', $final_str); 

    return $final_str; 
}

function my_detect_encoding($string){

// $enc = mb_detect_encoding($string, "UTF-8,ISO-8859-1");
// return $enc;


// $special_chars = array(
//   'Ã', 
//   '©',
//   'ù','û','ü',
//   'ÿ',
//   'à','â','ä','å','æ',
//   'ç',
//   'é','è','ê','ë',
//   'ï','î',
//   'ô','','ö','ó','ø',
//   'ü');

  if (preg_match('/Ã/', $string)) return 'ENCODED'; else return '-';
  // return mb_check_encoding($string, 'UTF-8');


}


function isUTF8($string) {
    return (utf8_encode(utf8_decode($string)) == $string);
}

function is_utf8($string) {

    // From http://w3.org/International/questions/qa-forms-utf-8.html
    return preg_match('%^(?:
          [\x09\x0A\x0D\x20-\x7E]            # ASCII
        | [\xC2-\xDF][\x80-\xBF]             # non-overlong 2-byte
        |  \xE0[\xA0-\xBF][\x80-\xBF]        # excluding overlongs
        | [\xE1-\xEC\xEE\xEF][\x80-\xBF]{2}  # straight 3-byte
        |  \xED[\x80-\x9F][\x80-\xBF]        # excluding surrogates
        |  \xF0[\x90-\xBF][\x80-\xBF]{2}     # planes 1-3
        | [\xF1-\xF3][\x80-\xBF]{3}          # planes 4-15
        |  \xF4[\x80-\x8F][\x80-\xBF]{2}     # plane 16
    )*$%xs', $string);

} // function is_utf8


/*------------------------------------------------------------------------------
* create a random array of string and ouput the result in a consolidated string
-----------------------------------------------------------------------------*/

function array_random($ar, $nb){
  $tmpstr="";
  
  if (!$nb) $nb=1; 
  for ($j=0;$j<$nb;$j++) {
    $i = rand(0, count($ar)-1);
    $tmpstr.=$ar[$i]; 
  }
  return  $tmpstr;
  
};
 
/*------------------------------------------------------------------------------
* $sstatus : status {'ok', 'ko'}
* $mmsg : STRING message to be displayed 
* $what2do : STRING -{'Die' or ''} . If 'die', do a PHP EXIT
-----------------------------------------------------------------------------*/
function echo_flush($sstatus, $mmsg, $what2do){

  if ((!$what2do)|| ($what2do=='')) $what2do="echo"; 
   
    $stamp= date( 'Y-m-d H:i:s', time());
    $tmpstr = '<div class="item"><div class="icon '.$sstatus.'"></div><div class="time">'.$stamp.'</div><div class="spacer">:</div><div class="status '.$sstatus.'">'.$sstatus.'</div><div class="spacer">:</div><div class="msg">'.$mmsg.'</div></div>'; 
    if (($what2do=="die") && ($sstatus=="ko")) {
      ob_end_flush(); 
      die ($tmpstr . str_pad(_('... end of processing.'),4096)."<br />\n"); 
    }
    else {
      echo $tmpstr;
      flush();
      ob_flush();
      // usleep(500000);
      //usleep(100000);
    } 
};

function check_php_compatibility($ext){
  global $cstat; 
  if (!extension_loaded($ext)) {
    $st="ko";$cstat=false;
  }  else $st="ok";  
  echo_flush($st,_('compatibility with PHP_').$ext,'');
};


function check_apache_compatibility($ext){
   global $cstat;   
   foreach (apache_get_modules() as $module){
    if ($module==$ext) {
      echo_flush('ok',_('compatibility with APACHE_').$ext,'');
      return true;
      } 
   }
   echo_flush('ko',_('compatibility with APACHE_').$ext,'');
   $cstat=false;
   return false;
};

function test_email($context){
  global $EMAIL_FROMADMIN;
  global $EMAIL_ADMIN; 

  $serverx =  "- addr=".$_SERVER["SERVER_ADDR"]; 
  $serverx .= "- name=".$_SERVER['SERVER_NAME'];
  $serverx .= "- software=".$_SERVER['SERVER_SOFTWARE'];
  $serverx .= "- protocol=".$_SERVER['SERVER_PROTOCOL'];
  $servernamex = $_SERVER['SERVER_NAME']; 
  
  $misc =  "- doc root=".$_SERVER["DOCUMENT_ROOT"];
  $misc .=  "- user agent=".$_SERVER["HTTP_USER_AGENT"];
  $misc .=  "- request uri=".$_SERVER["REQUEST_URI"];
  
  $serverremotehostx =  "- addr=".$_SERVER['REMOTE_ADDR'];
  //$serverremotehostx .= "- host=". $_SERVER['REMOTE_HOST']; // is not working in all cases
  $serverremotehostx .= "- port=". $_SERVER['REMOTE_PORT'];    
  
  $debug = "server:".$serverx ."  <br>\n| remote host: ". $serverremotehostx."  <br>\n| misc: ". $misc; 
  
  // test to send a Mail 
  $recipient ="sales@zads.fr";
  $sujet =  "Test email from ZADS AUTOTEST";    
  $message= " envoi d'email de test  sur cet hebergement <br>\n $debug"; 
  $message.= "$debug \n";
  $htmlmessage = ""; 
  $htmlmessage .= "<img src=\"\"</a>";
  $htmlmessage .= "<h1>Title H1</h1> ";
  $htmlmessage .= "<h2>Title H2</h2> ";
  $htmlmessage .= "<h3>Title H3</h3> ";
  $htmlmessage .= "<a href=\"www.zads.fr\">Link to ZADS web site</a> ";
  $htmlmessage .="<p> description longue <p><div style=\"color:#000000; border:1px solid #000000; padding:10px; margin:0px auto;\">mise en forme avec du div</div><br><b>c'est en gras<b>"; 
  $message.=$htmlmessage; 
  $email="noreply@".$servernamex; 
  $emailname="ZADS - no reply";        
  // Pour envoyer un mail HTML, l'en-tête Content-type doit être défini
  $headers  = 'MIME-Version: 1.0' . "\r\n";
  $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; // for HTML documents
  
  // En-têtes additionnels
  /*
  $headers .= "To: Mary <mary@example.com>, Kelly <kelly@example.com>" . "\r\n";
  $headers .= "From: $emailname <$email>" . "\r\n";
  $headers .= "Cc: patrice.cohaut@alcatel-lucent.com" . "\r\n";
  $headers .= "Bcc: patrice.cohaut@alcatel-lucent.com, patrice.cohaut@gmail.com" . "\r\n";
  */
  
  // to define priority 
  $headers .= "X-Priority: 1 (Higuest)\n"; 
  $headers .= "X-MSMail-Priority: High\n"; 
  $headers .= "Importance: High\n"; 



  // match this if context is set 
  if ($context=="realparams"){
    $sujet =  "Test email from ZADS with REAL PARAMS";    
    $headers .= "From: $EMAIL_FROMADMIN <$email>" . "\r\n";
    $recipient =$EMAIL_ADMIN;
  }

  
  if (mail ("$recipient", "$sujet", "$message", "$headers"))
    echo_flush('ok',_('text MAIL function'),''); 
  else  
    echo_flush('ko',_('text MAIL function'),''); 
};

?>
