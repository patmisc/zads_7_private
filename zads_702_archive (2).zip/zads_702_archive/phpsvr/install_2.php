<?php
/******************************************************************************
 * ZADS INSTALL script
 * 
 * Note :  works with SETTINGS.PHP file
 *  
 * @category   InstallationPackage
 * @package    ZADS
 * @author     Patrice COHAUT <patrice.cohaut@gmail.com>
 * @copyright  2010-2012-2013 PATMISC
 * @version    4.7 
 ******************************************************************************/
// load libraries 


test_email();



/*------------------------------------------------------------------------------
* $sstatus : status {'ok', 'ko'}
* $mmsg : STRING message to be displayed 
* $what2do : STRING -{'Die' or ''} . If 'die', do a PHP EXIT
-----------------------------------------------------------------------------*/
function echo_flush($sstatus, $mmsg, $what2do){

  if ((!$what2do)|| ($what2do=='')) $what2do="echo"; 
   
    $stamp= date( 'Y-m-d H:i:s', time());
    $tmpstr = '<div class="item"><div class="icon '.$sstatus.'"></div><div class="time">'.$stamp.'</div><div class="spacer">:</div><div class="status '.$sstatus.'">'.$sstatus.'</div><div class="spacer">:</div><div class="msg">'.$mmsg.'</div></div>'; 
    if (($what2do=="die") && ($sstatus=="ko")) {
      ob_end_flush(); 
      die ($tmpstr . str_pad(_('... end of processing.'),4096)."<br />\n"); 
    }
    else {
      echo $tmpstr;
      flush();
      ob_flush();
      usleep(500000);
    } 
};



function test_email(){

  $serverx =  "- addr=".$_SERVER["SERVER_ADDR"]; 
  $serverx .= "- name=".$_SERVER['SERVER_NAME'];
  $serverx .= "- software=".$_SERVER['SERVER_SOFTWARE'];
  $serverx .= "- protocol=".$_SERVER['SERVER_PROTOCOL'];
  $servernamex = $_SERVER['SERVER_NAME']; 
  
  $misc =  "- doc root=".$_SERVER["DOCUMENT_ROOT"];
  $misc .=  "- user agent=".$_SERVER["HTTP_USER_AGENT"];
  $misc .=  "- request uri=".$_SERVER["REQUEST_URI"];
  
  $serverremotehostx =  "- addr=".$_SERVER['REMOTE_ADDR'];
  //$serverremotehostx .= "- host=". $_SERVER['REMOTE_HOST']; // is not working in all cases
  $serverremotehostx .= "- port=". $_SERVER['REMOTE_PORT'];    
  
  $debug = "server:".$serverx ."  <br>\n| remote host: ". $serverremotehostx."  <br>\n| misc: ". $misc; 
  
  // test to send a Mail 
  $recipient ="patrice.cohaut@gmail.com";
  $sujet =  "Test email";    
  $message= " envoi d'email fonctionner sur cet hebergement <br>\n $debug"; 
  $message.= "$debug \n";
  $htmlmessage = ""; 
  $htmlmessage .= "<img src=\"\"</a>";
  $htmlmessage .= "<h1>Title H1</h1> ";
  $htmlmessage .= "<h2>Title H2</h2> ";
  $htmlmessage .= "<h3>Title H3</h3> ";
  $htmlmessage .= "<a href=\"www.zads.fr\">Link to ZADS web site</a> ";
  $htmlmessage .="<p> description longue <p><div style=\"color:#000000; border:1px solid #000000; padding:10px; margin:0px auto;\">mise en forme avec du div</div><br><b>c'est en gras<b>"; 
  $message.=$htmlmessage; 
  $email="noreply@".$servernamex; 
  $emailname="ZADS - no reply";        
  // Pour envoyer un mail HTML, l'en-t�te Content-type doit �tre d�fini
  $headers  = 'MIME-Version: 1.0' . "\r\n";
  $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; // for HTML documents
  
  // En-t�tes additionnels
  /*
  $headers .= "To: Mary <mary@example.com>, Kelly <kelly@example.com>" . "\r\n";
  $headers .= "From: $emailname <$email>" . "\r\n";
  $headers .= "Cc: patrice.cohaut@alcatel-lucent.com" . "\r\n";
  $headers .= "Bcc: patrice.cohaut@alcatel-lucent.com, patrice.cohaut@gmail.com" . "\r\n";
  */
  
  // to define priority 
  $headers .= "X-Priority: 1 (Higuest)\n"; 
  $headers .= "X-MSMail-Priority: High\n"; 
  $headers .= "Importance: High\n"; 
  
  if (mail ("$recipient", "$sujet", "$message", "$headers"))
    echo_flush('ok',_('text MAIL function'),''); 
  else  
    echo_flush('ko',_('text MAIL function'),''); 
};

?>
