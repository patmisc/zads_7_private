<?php
/******************************************************************************
 * ZADS FILE MANEGER SERVER 
 * 
 * Note :  works with DB_SETTINGS.PHP &  SETTINGS.PHP file & LOCALIZATION.PHP
 * LINKED LIB: facebook.php ; 
 *  
 * @category   CorePackage
 * @package    ZADS
 * @author     Patrice COHAUT <patrice.cohaut@gmail.com>
 * @copyright  2013 PATMISC
 * @version    5.0
 ******************************************************************************/
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING | E_DEPRECATED));

require_once("multitenants_settings.php"); 
require_once($SETTINGS_PATH."settings.php"); 
require_once("functions.php");   

// set default timezone 
date_default_timezone_set('Europe/Paris');



//force a debug based on settings file Zads5.0
if ($ENABLE_DEBUG_MODE) $debug_tmp=1; 
$trace='';

if (!session_is_admin()) die ('not the right access level') ; // exit if not ADMIN 
if (!$ENABLE_FILES_MANAGER) die ('files management is disabled'); //exit clause

// -------------- SERVLET FOR ACTIONS   ----------------------
if( isset($_POST["files"]) || isset($_POST["res"]) || isset($_POST["pages"])) {


	if  (isset($_POST["files"])) { $subaction = $_POST["files"]; $action= "files"; }
	else if (isset($_POST["res"]))  { $subaction = $_POST["res"];$action= "res"; }
	else if (isset($_POST["pages"]))  { $subaction = $_POST["pages"];$action= "pages"; }

	ft_settings_load($action); // load settings specific to this module

	if ($action=="res") $action =  "files";
	$success=false; $message="Ajax Call not recognized"; 

  	$ret=false;
  	$sort = isset($_POST["sort"]) ? $_POST["sort"] : null; //possible values are  : name, type, size, date
	$trace.="-- $subaction --";
 	//----- LIST -----------------------------
	if ($subaction=="list"){
		$trace.="-- $subaction --";
		$message=""; 
		// get the list of files - use default DIRECTORY for seurity reason 
		$files = ft_get_filelist(ft_get_dir(), $sort);

		if (!is_array($files)) {
			$success=false;
			$message="Could not open directory"; 
			$ret=false; 
		} else {
			$success=true;
			foreach ($files as $c) {
				$toto=1;// FUTURE PROCESSING /FILTERING 
			}
			$ret = $files; 
			$message=""; 
		}
	}

	//----- DELETE -----------------------------
	if ($subaction=="delete"){
		$message="";
		$trace.="-- in delete --"; 

		if  (isset($_POST["fname"])){ // fine name is defined 
			$file = $_POST["fname"]; 
			// delete the file and the tn associated
			if (!empty($file) && ft_check_file($file)) {
				// file exist -> do it on the file 
				if (!@unlink(ft_get_dir().$file)) {
					  $message='Main file could not be deleted.';
				} else {
					  $success=true; 
				}
				// file exist -> do it on the tn 
				if (!@unlink(ft_get_dir()."tn_".$file)) {
					  $message.='TN file could not be deleted.';
				} else {
					  $success=true; 
				}
			} else {
				$message='File could not be deleted.'; 
			}
		}
	}

	//----- READ  -----------------------------
	if ($subaction=="read"){
		$message="";
		$trace.="-- in read --"; 

		if  (isset($_POST["fname"])) { // fine name is defined 
			$filename = $_POST["fname"]; 
			$ret = array();
			$ret['name'] = $filename;
			$ret['htmlencoded'] = base64_encode(utf8_decode(file_get_contents(DIR.$filename)));
			$success=true;
		}
	}

	//----- EDIT  -----------------------------
	if ($subaction=="save"){
		$message="";
		$trace.="-- in save --"; 

		$htmlcode = $_POST["htmlcode"] ;
		$subject = $_POST["subject"] ;
		$fname = $_POST["fname"] ;

		$fnamear = explode(".",$fname);
		$fnamenoext = $fnamear[0];
		$fnameext = $fnamear[1];

		// get the variable  
    	// $htmlcode =  utf8_encode(base64_decode($htmlcode)); // remove the / added by magic quote option
    	// get the variable 
		if (get_magic_quotes_gpc())
    		$htmlcode =  stripcslashes($htmlcode); // remove the / added by magic quote option

		$filepath = DIR.$fname; 
		$filepathbak = DIR.$fnamenoext.'_'.date("Ymd-His").".bak";

		if ($htmlcode) {
        	$status = file_put_contents($filepath, $htmlcode);
        } else $status=false; // force an error

        if (!$status) {
			$success=false;
			$message="Error in updating content"; 
			$ret=false; 
		} else {
			$success=true;
			$ret = true; 
			$message=""; 
		}
	
	}

 //----- out the message -----------------------------
  // prepare the output code             
     $json = array(
                  'success' => $success,
                  'message' => $message,
                  'action' => $action,
                  'subaction'=>$subaction,
                  'rooturl'=>DIRFROMROOT,
                  'data' => $ret,
                  'trace'=>$trace
              );
              
 
     // if ($debug_tmp==1){ // add debug info into the stream when working local
     //   $json["xdebug"]= array(
     //              'sql'=> $ret[sql], 
     //              'sqlerror'=> $ret[sqlerror],
     //              'sql2'=> $ret[sql2],
     //              'in'=> $ret[indata]
     //            );  
     // }
    echo json_encode($json); 

}



// //$files = ft_get_filelist(ft_get_dir());
// $files = ft_get_filelist('../img/');
// var_dump($files) ;

 
//*********** settings part **********************/
$ft = array();
$ft['settings'] = array();
function ft_settings_load($options) {
  global $ft;
  global $ENABLE_FILES_MANAGER;			// enable the file manager 
  global $FILES_MANAGER_DIR;	// path from root of the file manager storage area - must be in format './xx/ss/'
  global $FILES_MANAGER_MAX_SIZE; 		// max size of upload files 
  global $FILES_MANAGER_MAX_NBR; 
  global $trace ; 
  
  if (($options=="files" || $options=="res") && $FILES_MANAGER_DIR) {
  	$ft["settings"]["DIR"]               = ".".$FILES_MANAGER_DIR; // Your default directory. Do NOT include a trailing slash!
  	$ft["settings"]["DIRFROMROOT"]       = $FILES_MANAGER_DIR; // Your default directory. Do NOT include a trailing slash!

  }else if ($options=="pages" ) {
  	$ft["settings"]["DIR"]               = "../pages/"; // Your default directory. Do NOT include a trailing slash!
  	$ft["settings"]["DIRFROMROOT"]       = "./pages/"; // Your default directory. Do NOT include a trailing slash!
  }
  else { 
  	$ft["settings"]["DIR"]               = "../uploads/files/"; // Your default directory. Do NOT include a trailing slash!
  	$ft["settings"]["DIRFROMROOT"]       = "./uploads/files/"; // Your default directory. Do NOT include a trailing slash!
  }

  $trace.="-- -".$ft["settings"]["DIRFROMROOT"] ;

  $ft["settings"]["EXCLUDETN"]         = TRUE; // Exckude the file with a name starting with tn_ (=thumbnails)
  $ft["settings"]["LANG"]              = "en"; // Language. Do not change unless you have downloaded language file.
  $ft["settings"]["MAXSIZE"]           = ($FILES_MANAGER_MAX_SIZE) ? $FILES_MANAGER_MAX_SIZE : 2000000; // Maximum file upload size - in bytes.
  //$ft["settings"]["PERMISSION"]        = 0644; // Permission for uploaded files.
  //$ft["settings"]["DIRPERMISSION"]     = 0777; // Permission for newly created folders.
  $ft["settings"]["UPLOAD"]            = TRUE; // Set to FALSE if you want to disable file uploads.
  $ft["settings"]["CREATE"]            = TRUE; // Set to FALSE if you want to disable file/folder/url creation.
  $ft["settings"]["FILEACTIONS"]       = TRUE; // Set to FALSE if you want to disable file actions (rename, move, delete, edit, duplicate).
  $ft["settings"]["SHOWDATES"]         = FALSE; // Set to a date format to display last modified date (e.g. 'Y-m-d'). See http://dk2.php.net/manual/en/function
  
  $ft["settings"]["FILEBLACKLIST"]     = "ft2.php ft.css config.php index.php config.sample.php LICENSE README.markdown .DS_store .gitignore"; // Specific files.
  $ft["settings"]["FOLDERBLACKLIST"]   = "plugins js css locales data"; // Specifies folders that will not be shown. No starting or trailing slashes!
  $ft["settings"]["FILETYPEBLACKLIST"] = "phtml php3 php4 php5"; // File types that are not allowed for upload.
  $ft["settings"]["FILETYPEWHITELIST"] = ""; // Add file types here to *only* allow those types to be uploaded.
  $ft["settings"]["LIMIT"]             = 0; // Restrict total dir file usage to this amount of bytes. Set to "0" for no limit.



  foreach ($ft["settings"] as $k => $v) {
    define($k, $v);
  }

}





?>