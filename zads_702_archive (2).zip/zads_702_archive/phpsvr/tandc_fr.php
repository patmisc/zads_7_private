
<?php 
  // ----- INIT ESSENTIAL SETTINGS =  LANGUAGE  ----// 
  
  include_once "./phpsvr/init_settings.php";

?> 

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr">

<head>
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-15"/>

  <title><?php echo $cust_title;?></title>
  <meta name="description" content="<?php echo $cust_description;?>"/>
  <meta name="keywords" lang="<?php echo $cust_lang;?>" content="<?php echo $cust_keywords;?>" /> 
 
  <!-- CSS --> 
  <link rel="stylesheet" type="text/css" media="all" href="style.css" />     
	<link rel="stylesheet" type="text/css" href="theme_style.css" media="all" />
	
  <link rel="shortcut icon" type="image/x-icon" href="<?php echo $cust_favicon_uri;?>"> 
  <link rel="icon" type="image/x-icon" href="<?php echo $cust_favicon_uri;?>">

</head>

<body id="top">

<!-- MODL BOX !!!! BUT BE PUT FIRST  after the body ********* --> 
      <!-- #customize your modal window here -->
      <div id="boxes">
      	<div id="dialog" class="mbox-window">
      	  <!-- empty space for mbox-header-->
      	  <div class="clearer">&nbsp;</div>
        	<div id="mbox-body">
          </div>  		
      		<div id="mbox-footer"> <a href="#" id="close" class="close"></a></div>
        </div>
       	<div id="mask"></div><!-- Do not remove div#mask, because you'll need it to fill the whole screen -->
      </div>

  <div id="network">
  	<div id="network-wrapper" class="center-wrapper">

      <div class="left"> 
      </div> 
 
      <div class="right">
  			<ul class="tabbed" id="network-tabs">
  				<li class="current-tab"><a href="<?php echo $DOMAIN_FQDN;?>"><?php echo $cust_site_name;?></a></li>
  			</ul>
  			<div class="clearer">&nbsp;</div>
	  </div>
  		 		
  		<div class="clearer">&nbsp;</div>
  	</div>
  </div>

  <div id="site">
	<div class="center-wrapper">

		<div id="header">
      
			<div id="site-title">		      
        <img src="<?php echo $LOGO_FQDN;?>" width="109" height="57">
				<h1 id="motto"><?php echo $cust_name;?></h1>
				<div class="clearer">&nbsp;</div>
		  </div>
			<div class="clearer">&nbsp;</div>

			<div id="navigation">
				
				<div id="main-nav">
          <div id="main-nav-links">
  					<ul class="tabbed">
  					</ul>
  				</div>
  			


					<div class="clearer">&nbsp;</div>

				</div>
				
				<div id="sub-nav" style="display : none ;">
					
				</div>
				<div class="clearer">&nbsp;</div>
			</div>

		</div>

		<div class="main" id="main-two-columns">
		
            <div class="tc-maintext">
            
            	<!-- Print Icon   -->
             <div id="tc-toolbar" class="right">
             <div class="level1 right" id="item-print" onclick="javascript:window.print();"><span class="icon"></span><div><a href="#" title="" name="manage_ad">imprimer</a></div></div>
             </div>
            
            <p>
			       <h1>Informations l&eacute;gales </h1>
			       <p>&nbsp;</p>
			
			       <h1>Conditions G&eacute;n&eacute;rales d'Utilisation (rev 1.0 - 07 D&eacute;cembre 2010) </h1>
            </p>
   
</div>

			<div class="clearer">&nbsp;</div>

		</div>

    <div id="footer">
    

        <span id="copyright" class="totranslate">&copy; 2013-2014 ZADS</span>
      
        <span class="text-separator">&rarr;</span> 
        <a href="<?php echo $cust_aboutus_url;?> " class="totranslate">A propos</a> 
       
        <?php  if ($cust_tandc_url) { ?>
        <span class="text-separator">|</span>
        <a href="<?php echo $cust_tandc_url;?> " class="totranslate" >Infos l�gales et CGU</a>
        <?php } ?>
        
        <?php  if ($cust_pub_url) { ?>
        <span class="text-separator">|</span> 
        <a href="<?php echo $cust_pub_url;?> " class="totranslate" >Publicit�</a>
        <?php } ?>
        
        <?php  if ($cust_contactus_url) { ?>
        <span class="text-separator">|</span> 
        <a href="<?php echo $cust_contactus_url;?> " class="totranslate" >Nous contacter</a>
        <?php } ?>
        
        <?php  if ($cust_help_url) { ?>
        <span class="text-separator">|</span>
        <a href="<?php echo $cust_help_url;?> " class="totranslate" >F.A.Q</a>
        <?php } ?>
      
  
      <div class="clearer">&nbsp;</div>
    </div>

	</div>
</div>

</body>
</html>
