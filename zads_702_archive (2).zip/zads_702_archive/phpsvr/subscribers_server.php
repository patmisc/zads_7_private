<?php
/******************************************************************************
 * ZADS Main Server Script
 * 
 * Note :  works with DB_SETTINGS.PHP &  SETTINGS.PHP file & LOCALIZATION.PHP
 * LINKED LIB: facebook.php ; 
 *  
 * @category   CorePackage
 * @package    ZADS
 * @author     Patrice COHAUT <patrice.cohaut@gmail.com>
 * @copyright  2013 PATMISC
 * @version    4.7
 ******************************************************************************/


error_reporting(E_ALL ^ (E_NOTICE | E_WARNING | E_DEPRECATED));

/* detect the PHP version */ 
if(function_exists('phpversion')) $v = phpversion();
elseif(PHP_VERSION) $v = PHP_VERSION; else $v =  'Impossible de détecter la version PHP';
$phpVersion = intval(str_replace('.','',$v));


// load libraries & settings 
require_once("multitenants_settings.php"); 
require_once($SETTINGS_PATH."db_settings.php");  
require_once($SETTINGS_PATH."settings.php");
require_once("localization.php"); 
require_once($SETTINGS_PATH."home_settings_".$cust_lang_long.".php");  
 
require_once("functions.php");   


// default translatons 
$TEMPLATE_ACCOUNT_VALIDATION_SUBJECT = _("Your subscription validation"); 
$TEMPLATE_ACCOUNT_UNSUBSCRIBE_SUBJECT = _("Your subscription is now inactive"); 


$general_settings = json_decode(file_get_contents("settings/general.json"),true);
// set default timezone 
date_default_timezone_set('Europe/Paris');

// ---- manage Debug elements  --//
$debugoutputfile = "debugoutput.htm"; // only if save=1
$debug_tmp=($ENABLE_DEBUG_MODE) ? 1 : 0 ; 
if ($debug_tmp==1) {
  $debugfile = fopen($debugoutputfile,"a"); if(!$debugfile) { echo "Error writing to the output file.\n";}
  logfile('', '[SUBSCRIBERS_SERVER] --------------------------------------', __LINE__); // start a new call of file 
} 


// --- Declare and connect to database  -----//
$databasehost = $DB_HOST;
$databaseusername =$DB_USERNAME;  
$databasepassword =$DB_PASSWORD;  

$databasename = $DB_NAME;  //cads = classified adds. 
$dbItemsTable = $DB_PREFIX.$DB_TABLE_ITEMS ; 
$dbCatsTable = $DB_PREFIX.$DB_TABLE_CATS; 
$dbUsersTable = $DB_PREFIX.$DB_TABLE_USERS; 
$dbStatsTable = $DB_PREFIX.$DB_TABLE_STATS; 
$dbLogsTable = $DB_PREFIX.$DB_TABLE_LOGS; 
$dbPaymentsTable = $DB_PREFIX.$DB_TABLE_PAYMENTS;
$dbBannersTable = $DB_PREFIX.$DB_TABLE_BANNERS;

// @Z5.5
$dbSubscribersTable = $DB_PREFIX.$DB_TABLE_SUBSCRIBERS;
$dbVFieldsTable = $DB_PREFIX.$DB_TABLE_VFIELDS;


//  --- open socket to MySQL database
$con = mysql_connect ($databasehost,$databaseusername, $databasepassword)or die();
mysql_select_db ( $databasename ) or die();

 
// ---- statistics on Useragent -----// 
$serverremotehostx="unknown"; 
$serverremoteaddr = $_SERVER['REMOTE_ADDR'];  
$debughostinfo = "remote host=".$serverremotehostx ." | remote ip= ". $serverremoteaddr; 
// UserAgent informations for statistics 
$uagentArr = UserAgentParser($_SERVER['HTTP_USER_AGENT']);
$uagent_os = $uagentArr['platform']; 
$uagent_version =$uagentArr['version'];
$uagent_browser =$uagentArr['browser']; 



// --- Common variables used for SERVERS --------/
// today week number in "string format" 08W21 eg
$todayyw=date("y")."w".date("W") ; 
$todayweeknbr = intval(date("W")) ; 
$todaymonthnbr = intval(date("m")) ; 
$todayyearnbr=intval(date("y"));
$stamp= date( 'Y-m-d H:i:s', time());
$fullfqdn = $DOMAIN_FQDN; 
$dbThisTable=""; 
$message = "";
$success=false; 
$what = ""; 


// ############# ACTIONS = .. ###########################
if (isset($_POST["subscribers"]) ) {

  $success=true;
  // global var for check if session is set or not 
  $curuser_is_admin=false; // global var to indicate it a user is logged and if he is admin 
  $curuser_id=""; $curuserid=""; $curuser_type=0; 
  
  $totnbrofresults = 1; 
  $action = $_POST["subscribers"]; if ($action=="") die('action NULL received - cheating ?'); // SECURITY protection
  $what = $_POST["what"]; if (!$what) $what="user";
  
  $from = $_POST["from"];
  $hid = secure_var(trim($_POST["hashid"]));
  $hashid = secure_var(trim($_POST["hashid"]));      
  $hash = secure_var(trim($_POST["hash"]));                         // SECURITY - convert to int 
     
  // elements for user initialization
  $email=  secure_var(strtolower(trim($_POST["email"]))) ;    // SECURED
  $locale=  secure_var($_POST["locale"]) ;    // SECURED 
  $subfeeds =  secure_var($_POST["subfeeds"]); // SECURED
  
  // elements for supportrequest 
  $name= secure_var(trim($_POST["name"])) ;    // SECURED
  $msg= secure_var(trim($_POST["msg"])) ;    // SECURED

  $nav=$_POST["nav"];

  $outcode = 0; 
  $thishash = 0; 

  $dbThisTable = $dbSubscribersTable; 
  
  if ($action=="create"){
      if ($what=="user"){
         
         // default variables 
         $status="20"; // by default the account is PENDING VALIDATION 
         $hashid = $email.strval(time());$hashid = hash('sha1',$hashid);
                
         $query = "INSERT INTO `".$dbThisTable."` 
              (`hashid`, `activation`,`os`, `browser`, `version`,  `subfeeds`, `username`, `auth`, `gender`, `password`,  `usertype`, `firstname`, `lastname`,  `email`, `phone`, `registerdate`, `lastemaildate`, `moddate`, `lastvisitdate`, `status`, `avatarimg`, `locale`,`location`, `priority`)"; 
         $query .= "VALUES 
              ('$hashid', '0', '$uagent_os','$uagent_browser','$uagent_version','$subfeeds', '', '', '', '', '', '', '','$email', '', '$stamp','$stamp','$stamp','$stamp','$status','',  '$locale', '','');";


         $thishash = $hashid; //save the hash

         // pre-query for checking if declared email  already exits
         $pre_filter = "WHERE ((`email` = '".$email."')) ";
         $pre_query = "SELECT email, username FROM `$dbThisTable`" .$pre_filter; 
         $make_pre_query=true; 
          $pre_result = mysql_query($pre_query);
          if ($pre_result && (mysql_num_rows($pre_result)!=0)){
              $pre_row = mysql_fetch_object($pre_result); 
                if ($pre_row->email==$email) 
                  $sqlerror =  "|ERR-U-EMAIL|$email|This email is already in use";
                $success=false;
                $outcode = 99998;  $thisemail = $email;
          }
          $thisemail = $email;

          // make the real query 
          if ($success){
              $result = mysql_query($query);  
              $sqlerror=""; 
              if (!$result) $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
              else {
                if ($action == "create") $lastdbinsertid = mysql_insert_id(); 
                else $lastdbinsertid = $ad_id; 
  
                $query2 = "SELECT * FROM `$dbThisTable` WHERE `id`=$lastdbinsertid"; 
               
                $result2 = mysql_query($query2);
                if (!$result2) $sqlerror =  "Could not successfully run query from DB: " . mysql_error()."--".$query2;
                else {
                  $row = mysql_fetch_object($result2); 
                      if (($what=="user")){
                      $data[0] = Array (
                          'id'=> $row->id, 
                          'hashid'=> $row->hashid, 
                          'firstname' => $row->firstname,
                          'lastname'=> $row->lastname,
                          'email'=> $row->email,
                          'status'=> $row->status,
                          'activation'=> $row->activation,
                          'registerdate'=> $row->registerdate,
                          'lastvisitdate'=> $row->lastvisitdate,
                          'lastemaildate'=> $row->lastemaildate,
                          'registerdatestamp'=>  strtotime( $row->registerdate)*1000,
                          'lastvisitdatestamp'=>  strtotime( $row->lastvisitdate)*1000,
                          'lastemaildatestamp'=>  strtotime( $row->lastemaildate)*1000,
                          'locale'=> stripslashes($row->locale),
                          'moddatestamp'=>  strtotime( $row->moddate)*1000
                           );
                           
                        // send a validation email                         
                        single_send_emails($TEMPLATE_ACCOUNT_VALIDATION_BODY, $TEMPLATE_ACCOUNT_VALIDATION_SUBJECT, $data[0]['email'], 'accountvalidation', $data[0]['hashid']) ; 
                        
                        }
                } // end final OUTPUT query 
                
              } // end first query 
              
          } // end SUCEESS  
     }  // end what=USER

    } // end create action
    

    //------------ Validation of User registration ----------------
    if (($action=="validate") || ($action=="update") || ($action=="publish") || ($action=="unpublish")){
      if ($what=="user"){
         
         // prequery to check if Hashid exists 
         $pre_filter = "WHERE ((`hashid` = '".$hashid."')) ";
         $pre_query = "SELECT email FROM `$dbThisTable`" .$pre_filter; 
          // make the prequery 
          $pre_result = mysql_query($pre_query);
          if ($pre_result && (mysql_num_rows($pre_result)==0)){
            $sqlerror =  "|ERR-$action-ACCOUNT|$hid|This code is not recognized";
            $success=false;
          } else { $prerow = mysql_fetch_object($pre_result); } // get data for future use  
          // prepare the QUERY STRING
          if ($success){  
             // final query 
            if  (($action=="validate")|| ($action=="publish")) {
              $query = "UPDATE `".$dbThisTable."` SET   
                `status` = '40',
                `activation` = '1',
                `moddate` = '$stamp' 
                WHERE ((`hashid` = '".$hid."')) ";

               $status="40";
            }

             if  ($action=="unpublish") {
              $query = "UPDATE `".$dbThisTable."` SET   
                `status` = '20',
                `activation` = '1',
                `moddate` = '$stamp' 
                WHERE ((`hashid` = '".$hid."')) ";

                $status="20";
            }
                    
            // if  ($action=="unsubscribe"){
            //     $query = "DELETE FROM `".$dbThisTable."` 
            //     WHERE ((`hashid` = '".$hid."')) ";
            // }

            // MAKE THE QUERY 
            $result = mysql_query($query);  
            $sqlerror=""; 
            if (!$result) $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
            else {
            
                if (($action=="validate") || ($action=="update") ||  ($action=="publish") ||  ($action=="unpublish")){
                  $query2 = "SELECT * FROM `$dbThisTable` WHERE `hashid`= '$hashid' "; 
                  $result2 = mysql_query($query2);
                  if (!$result2) $sqlerror =  "Could not successfully run query from DB: " . mysql_error()."--".$query2;
                  else {
                    $row = mysql_fetch_object($result2); 
                        if (($what=="user")){
                        $data[0] = Array (
                            'id'=> $row->id, 
                            'hashid'=> $row->hashid, 
                            'firstname' => $row->firstname,
                            'lastname'=> $row->lastname,
                            'email'=> $row->email,
                            'status'=> $row->status,
                            'activation'=> $row->activation,
                            'subfeeds'=> $row->subfeeds,
                            'registerdate'=> $row->registerdate,
                            'lastvisitdate'=> $row->lastvisitdate,
                            'lastemaildate'=> $row->lastemaildate,
                            'registerdatestamp'=>  strtotime( $row->registerdate)*1000,
                            'lastvisitdatestamp'=>  strtotime( $row->lastvisitdate)*1000,
                            'lastemaildatestamp'=>  strtotime( $row->lastemaildate)*1000,
                            'locale'=> stripslashes($row->locale),
                            'moddatestamp'=>  strtotime( $row->moddate)*1000
                             );   

                              $thishash = $row->hashid; //save the hash
                              $thisemail = $row->email;                  
                        }
                  } // end final OUTPUT query 
                }
                
            } // end query loop
          } // end success of first pre-query 
      }
    } // end section 
    

    //------------ DISPLAY of DELETE   ----------------
    if (($action=="delete") || ($action=="unsubscribe")){
        // check that Hash id ans email are corrects from the database and send a confirmation 
        
        $thisemail = $email;
        $status="80";  // indicate we are in the status 

         // pre-query for checking if declared email  already exits
        if ($email) // email is not always present 
          $pre_filter = "WHERE ((`email` = '".$email."') AND (`hashid` = '".$hashid."') ) ";
        else 
          $pre_filter = "WHERE ( (`hashid` = '".$hashid."') ) ";

         $pre_query = "SELECT email FROM `$dbThisTable`" .$pre_filter; 
         $make_pre_query=true; 
          $pre_result = mysql_query($pre_query);
          if ($pre_result && (mysql_num_rows($pre_result)!=0)){   
            $success=true; // we found it, we can continue ! 
        
          } else {
            // no data found 
            $sqlerror =  "|ERR-U-EMAIL|$email|This hash or email is unknown.";
            $success=false;
            $outcode = 99998; 
          }

            // MAKE THE QUERY 
          if ($success){
            $query = "DELETE FROM `".$dbThisTable."` WHERE ((`hashid` = '".$hashid."')) ";
            $result = mysql_query($query);  
            $sqlerror=""; 
            if (!$result) 
              $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
            else {
              $toto=1;
              // send a confirmation email that you have                         
              single_send_emails($TEMPLATE_ACCOUNT_UNSUBSCRIBE_BODY, $TEMPLATE_ACCOUNT_UNSUBSCRIBE_SUBJECT, $thisemail, 'accountunsubscribe', $hashid) ; 
        
            }
          } // end success 

    } // end delete and unsubscribe 



     //------------ DISPLAY or LIST  ----------------
    //----- LIST action -----------------------------
    if ($action=="list") {

      // get back additional variables 
      if (isset($_POST["page"]))$paged = $_POST["page"]+0; else  $paged =1;  
      $nav=$_POST["nav"];

      if (isset($_POST["eppage"])) $eppage =$_POST["eppage"]*1;
      else  $eppage=50; 



      // number of elements per pages 
      
      $sort=$_POST["sort"];
      $sortoriginal = $sort;
      $sort=explode("_",$sort); 
      $sort_dir = $sort[1];
      $sort_by = $sort[0];
      
      // filter
      $faction =  secure_var($_POST["faction"]) ;
      $fseverity =  secure_var($_POST["fseverity"]);
      $fstatus = secure_var($_POST["fstatus"]) ;
      
      $search=trim(secure_var($_POST["search"])); // SECURITY 


      // sorting option 
      if ($sort_by) {
        if ($sort_by=="date") $sort_by="registerdate"; // patch 
        $sql_sort ="  ORDER BY `$dbThisTable`.`".$sort_by."` ".$sort_dir;
      }
      else 
      $sql_sort.=" ORDER BY `registerdate` DESC ";  
      
      if ($id) {
        $filter.="  WHERE `what` IN ('$what') AND `action` NOT IN ('auth','msg','sec','cron','error') AND `whatid` = '$id' ";
        $limit=" LIMIT 0, 30 "; // no limit on the request
      } else {
        // filter
        // if ($what) $filter.="  WHERE `what` IN ('$what')"; 
        if ($eppage) {
            $itemstart = ((int)$paged -1) * $eppage; 
            $limit = "LIMIT ".$itemstart.", $eppage"; 
        } else $limit=""; 
      } 
      
      // // search condition
      // if ($search)  
      //   if ($filter=="")  $filter.="  WHERE ((`whatid` =  '".$search."') OR (`$dbItemsTable`.`title` like  '%".$search."%') OR (`$dbCatsTable`.`title` like  '%".$search."%') OR (`$dbUsersTable`.`username` like  '%".$search."%'))  "; 
      //   else  $filter.="  AND ((`whatid` = '".$search."') OR (`$dbItemsTable`.`title` like  '%".$search."%') OR (`$dbCatsTable`.`title` like  '%".$search."%') OR (`$dbUsersTable`.`username` like  '%".$search."%')) ";

      // other filters conditions : 
      if ($faction || $fseverity){
        if ($faction){
          if ($faction=="lc") {
              $tmpstr=""; 
              foreach ($laction_authorized_values as $value) {
                $tmpstr .= " '".$value."',"; 
              } $tmpstr = substr($tmpstr, 0,strlen($tmpstr)-1); //remove the last ','
               $corefilter= " `action` NOT IN ( $tmpstr ) "; 
          } else $corefilter = "((`action` =  '".$faction."'))"; 
          if ($filter=="")  $filter.="  WHERE $corefilter "; else $filter.="  AND $corefilter "; 
           
        }      
        if ($fseverity){
          $corefilter = "((`severity` =  '".substr($fseverity,1)."'))"; 
          if ($filter=="")  $filter.="  WHERE $corefilter "; else $filter.="  AND $corefilter ";         
        }
      }
      // case of status filter
      if ($fstatus){
        $corefilter = "((`status` =  '".$fstatus."'))"; 
        if ($filter=="")  $filter.="  WHERE $corefilter "; else $filter.="  AND $corefilter ";    
      }

      $join="";
      
      // make a pre-query to get total list of results 
      $queryfull = "SELECT `$dbThisTable`.`id` FROM `$dbThisTable` " .$join .$filter." ". $sql_sort;
      $resultfull = @mysql_query($queryfull);
      $maxresults = mysql_num_rows($resultfull);
      
      //-- make the full query
      $query = "SELECT `$dbThisTable`.*  FROM `$dbThisTable` ".$join .$filter." ". $sql_sort . " " . $limit ; 
      $result = @mysql_query($query);
      $totnbrofresults = @mysql_num_rows($result);
       
      $idx=0;
      
      if (($totnbrofresults) && ($totnbrofresults !=0)){
        $idx=0;
        $outdata=""; 
        // first item is generic
        $data = Array ();
        $idx=0;
        while ($row = mysql_fetch_object($result)) { 
          $thistate= explode("|",$row->desc); 
          $thistate = $thistate[0]; 
          $outdata = Array (
              'id' => $row->id ,
              'registerdate' => $row->registerdate,
              'hashid' => $row->hashid,
              'email'=> $row->email,
              'status'=>  $row->status
              );
         $data[$idx] = $outdata; 
         $idx+=1; 
        }
       } else {
        $data = Array ();
       }
      $success=true;
    }



     

    
     // --------- COMMON TO ALL TYPE OF ACTIONS --------------------//
      
     // manage the errors and messages
    
     if (!$sqlerror) {
        // get message template from table for special cases
        if ($returned_msg[$what][$status])
          $message = $returned_msg[$what][$status];           
        else 
          $message = "Yay! Everything went well!";
      }
     else {
        $message = "Doh! Something happened : ".$sqlerror;
        if ($outcode==0) $outcode = 99999; 
        $success = true; // force a sucess whatever happens 
      }

     if ($sqlerror=="") {
        $success=true;
    }


      
    // prepare the output code             
     $json = array(
                  'success' => $success,
                  'message' => $message,
                  'outcode' => $outcode,
                  'what' => 'subscribers',
                  'search'=>$search,
                  'action' => 'subscribers',
                  'subaction'=>$action,
                  'from' => $from,
                  'email' =>$thisemail,
                  'hashid' =>$thishash,
                  'paged' => $paged,
                  'eppage'=>$eppage,
                  'totnb'=>$maxresults,
                  'sort'=>$sortoriginal,
                  'fstatus'=>$fstatus,
                  'view'=>$vieworiginal,
                  'nav'=>$nav,
                  'status'=>$status,
                  //'adid'=>$rxadid,
                  'thisnb'=>$totnbrofresults,
                  'data' => $data,
                  'datafeeds' => $datafeeds

              );
              
     if ($debug_tmp==1){ // add debug info into the stream when working local
       $json["xdebug"]= array(
                  'query'=> $query,
                  'pre_query'=>$pre_query,
                  'queryfull'=> $queryfull, 
                  'isadminuser'=>$curuser_is_admin,
                  'limitfilter'=>$limit
                );  
     }
              
    echo json_encode($json); 

}

/**-----------------------------------------------------------------------------
* This function evaluate for a given trigger if need to send an email or not.
* function fased on mail() function 
* 
* @param  $bodymessage {string} the HTML message to be sent 
* @param  $subject {string} the subject / Tittle
* @return $forcedTo {string-OPTIONAL } when we want to force emailing to a given person
* 
*-----------------------------------------------------------------------------*/
function single_send_emails($bodymessage, $subjectin, $emailto, $emailtype, $var1){
  global $debug_tmp; // true : we store the content of the mail into the LOG file.
  global $debugfile; 
  global $debug;

  // from existing tmp1.php
  global $fullfqdn; 
  global $SITE_NAME; 
  global $SITE_MOTTO; 
  global $SITE_CUSTOMER; 
  global $debugfile;
  global $cust_lang_long;

  global $EMAIL_FROMADMIN; 
  global  $EMAIL_ADMIN;

  global $EMAILS_TEMPLATES_ENH; 
  global $EMAILS_TEMPLATES_DIR;
  
  //Z6.2.0
  global $supportfeedback_name_translation; 

  if ($EMAILS_TEMPLATES_ENH) define('EMAIL_TEMPLATE_VERSION', "V2");
  else define('EMAIL_TEMPLATE_VERSION', "V1");

  $tpl_name="";
  $html_title=""; 

  $enableEmail=true; // global variable to enable of not emails
    
  // ---------- Pour envoyer un mail HTML, len-tête Content-type doit être défini
  $headers  = 'MIME-Version: 1.0' . "\r\n";
  //$headers .= 'Content-type: text/html; charset=utf-8' . "\r\n"; // for HTML documents
  $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; // for HTML documents
  $headers .= "From: $EMAIL_FROMADMIN" . "\r\n";
  $headers .= "Reply-To: $EMAIL_FROMADMIN" . "\r\n";
  

  // -------- define content of the email 
  $message=""; 

  $map = array(); //mapping table between input data and reported value 

  $map["SITE_NAME"]= $SITE_NAME; $map["SITE_MOTTO"]= $SITE_MOTTO; $map["SITE_CUSTOMER"]= $SITE_CUSTOMER; 
  $map["SITE_FQDN"]= $fullfqdn;
  $map["CUR_DATE"]= $stamp2;



   if ($emailtype=='accountvalidation') {
    $tpl_name="user_newsletter_validation_20.html";
    if ($var1) {
          // match the messsage with the HASHID
          $yourvalidationurl = $fullfqdn."#validationid=".$var1; 
          $yourunsubscribeurl = $fullfqdn."#unsubscribeid=".$var1; 
          $map["YOUR_VALIDATION_URL"]= $yourvalidationurl;
          $map["YOUR_UNSUBSCRIBE_URL"]= $yourunsubscribeurl;
          $map["YOUR_EMAIL"]= $emailto;
    }
   }
      
  if ($emailtype=='accountunsubscribe') {
    $tpl_name="user_newsletter_unsubscribe_80.html";
    if ($var1) {
         $toto=1; // nothing to do in fact  ! 
    }
   }



  // get the content from the right file (depending on localizationn)
  $main_dir = 'emails_templates/'.$cust_lang_long;
  if (EMAIL_TEMPLATE_VERSION=="V2") {
    if ($EMAILS_TEMPLATES_DIR) $main_dir =  $EMAILS_TEMPLATES_DIR.$cust_lang_long;
    else $main_dir =  'locale_emails/'.$cust_lang_long;
  }
  $tpl_full_fqdn = $main_dir.'/'.$tpl_name;

    // get the content from the right file (depending on localizationn)
    // $tpl_full_fqdn =  'emails_templates/'.$cust_lang_long.'/'.$tpl_name;
    logfile('debug', "-- DEST = $emailto  ---"); 
    logfile('debug', "-- FQDN = $tpl_full_fqdn  ---"); 


    $errno=''; 
    if (file_exists($tpl_full_fqdn)) {

      $tpl_content = file_get_contents($tpl_full_fqdn);

      // format the email : 
      // create the final HTML BOD to be sent by email  

      if (EMAIL_TEMPLATE_VERSION=="V2") {
          $html_title =  get_innert_html_from_str($tpl_content, 'title');
          $htmfull_emailtest = get_innert_html_from_str($tpl_content, 'body');
      } else  {
        $htmfull_emailtest = utf8_decode($tpl_content);
      }

      foreach ($map as $k => $v) {
        $htmfull_emailtest = str_replace("[".$k."]",$v, $htmfull_emailtest, $count);
      }
     
      // convert from UTF8 -> LATAM Format 
      // $htmfull_emailtest = utf8_decode(stripslashes($htmfull_emailtest));  
      $message.=$htmfull_emailtest; 
    } else $errno = " - file : $tpl_full_fqdn not found ! - "; 


    //$finalheaders =$headers. "To: $emailto" . "\r\n";
    $finalheaders =$headers;

    $recipient = $emailto;
    $stamp= date( 'Y-m-d H:i:s', time());
    
    $emailcount=0; 
    $emailHasError=false; 

    // manage subject 
    if ($html_title) $subjectin = $html_title; 
    if ($phpVersion>=5300)
      $subject = '=?ISO-8859-1?Q?'.quoted_printable_encode($subjectin).'?=';
    else
      $subject = '=?ISO-8859-1?Q?'.$subjectin.'?=';
  
      if ($message){
        if (($enableEmail)){
          if (mail ("$recipient", "$subject", "$message", "$finalheaders")){
            $result= "\n $stamp : Mail  : $subject sent  to $recipient "; 
            $emailcount+=1;
          }
          else  $result= "\n $stamp : Mail  : $subject **** ERROR **** while sending to $recipient \n";  

          logfile('debug', $result); 
        } 

        logfile('debug', $message); 
      } else  
      logfile('debug', "Email message not sent - Message Was EMPTY : $errno  \n"); 

    return $emailcount; 
}


function get_innert_html_from_str($tpl_content, $tagName){

    // $DOM = new DOMDocument;
    $DOM = new DOMDocument('1.0', 'UTF-8');
    // mandatory to forcethis to understand that this is UTF8 document 
    $tpl_content= '<meta http-equiv="Content-Type" content="text/html; charset=utf-8">'.$tpl_content;
    $DOM->loadHTML($tpl_content);
    $items = $DOM->getElementsByTagName($tagName);
    for ($i = 0; $i < $items->length; $i++){
      $result = get_inner_html($items->item($i)) ;
      return $result; 
    }
}


function get_inner_html( $node ) {
    $innerHTML= '';
    $children = $node->childNodes;
    foreach ($children as $child) {
        $innerHTML .= $child->ownerDocument->saveXML( $child );
    }
    return $innerHTML;
}

// ----------- end of file  --------------------------
?>