<?php
/******************************************************************************
 * ZADS HTML SNAPSHOT Server Script
 * 
 * Note :  works with DB_SETTINGS.PHP &  SETTINGS.PHP file & LOCALIZATION.PHP
 * LINKED LIB: facebook.php ; 
 *  
 * @category   CorePackage
 * @package    ZADS
 * @author     Patrice COHAUT <patrice.cohaut@gmail.com>
 * @copyright  2013 PATMISC
 * @version    6.8.1 
 ******************************************************************************/
/* Disable direct access.*/
if(!strcasecmp(basename($_SERVER['SCRIPT_NAME']),basename(__FILE__))) 
die('ZADS- Direct Access to this file not allowed!');
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING | E_DEPRECATED));


/* detect the PHP version */ 
if(function_exists('phpversion'))
   $v = phpversion();
  elseif(PHP_VERSION)
   $v = PHP_VERSION;
  else
   $v =  'Impossible de détecter la version PHP';
$phpVersion = intval(str_replace('.','',$v));

// load libraries & settings 
require_once("multitenants_settings.php"); 
require_once($SETTINGS_PATH."db_settings.php");  
require_once($SETTINGS_PATH."settings.php");

require_once("init_settings.php");    
require_once("localization.php");


/********** VERSIONNING *****************************************************
* _2 : start 
* _3 :  - modification in lsit with bootstrap theme and aligment with le bon coin 
*       - no CATEGORIES in NAVIGATION 
*       - HTML5 header
* _4 :  - DESC shorten to 255 chars 
*       - no follow on T&C ad RGC and excude them from sitemap 
*       - breadcrumb
*       - ALT tag on images
*       - categories list at the end of the pagewith only those with articles  
* _5 :  - correct trailing slash problem & image URL in "full site mode"
*       - bug on BASE PATH replacement
* _6 :  - direct javascript call and replacement of escaped_fragments in js to serve the right page 
*       - add news and correction into sitemap to get Vendors 
* _7 :  - remove NOSCRIPT Tags for google 
* _8 :  - language detection patch for Google Index  
*
* _13dec2016 
*    :  - add title for catéories / replace category description when less than 200 chars  / remove list of cat on other pages / remome item prop=URL on links 
*    :  - change schema.org for adds to offer and demand
*    :  - removed rel=canonical as not sure escaped_fragments are detected by google
*    :  - add meta=bot NOARCHIVE on ADDISPLAY 
*
******************************************************************************/
define('ZADS_HTML_SNAP_VERSION',ZADS_VERSION."_13dec2016"); 

// set default timezone 
date_default_timezone_set('Europe/Paris');

$debug ="";
$debug_tmp = 0 ; // 0= server 1=local
if (( $_SERVER['SERVER_ADDR'] != "127.0.0.1") ||( !$_SERVER['SERVER_ADDR'] ))  $debug_tmp=0; else $debug_tmp=1; 
$nomessage = 0;  // 0= flag to indicate wether to end a message or not

$serverremotehostx ='';
$serverremoteaddr = $_SERVER['REMOTE_ADDR'];  
$debughostinfo = "remote host=".$serverremotehostx ." | remote ip= ". $serverremoteaddr;

$databasehost = $DB_HOST;
$databaseusername =$DB_USERNAME;  
$databasepassword =$DB_PASSWORD;  

$databasename = $DB_NAME;  //cads = classified adds. 
$dbItemsTable = $DB_PREFIX.$DB_TABLE_ITEMS ; 
$dbCatsTable = $DB_PREFIX.$DB_TABLE_CATS; 
$dbUsersTable = $DB_PREFIX.$DB_TABLE_USERS; 
$dbStatsTable = $DB_PREFIX.$DB_TABLE_STATS; 
$dbLogsTable = $DB_PREFIX.$DB_TABLE_LOGS; 
$dbPaymentsTable = $DB_PREFIX.$DB_TABLE_PAYMENTS;
$dbBannersTable = $DB_PREFIX.$DB_TABLE_BANNERS;

$fullfqdn = $DOMAIN_FQDN; 

$dbThisTable=""; 

if ($debug_tmp==1) {
// debug output file 
  $debugoutputfile = "debugoutput.htm"; // only if save=1
  $debugfile = fopen($debugoutputfile,"a"); if(!$debugfile) { echo "Error writing to the output file.\n";}
  
  $debugoutputfilehtml = "debugoutput.html"; // only if save=1
  $debugfilehtml = fopen($debugoutputfilehtml,"a");if(!$debugfilehtml) { echo "Error writing to the output file.\n";}
 }

//  --- open socket to MySQL database
$con = mysql_connect ($databasehost,$databaseusername, $databasepassword)or die();
mysql_select_db ( $databasename ) or die();

mysql_query("SET NAMES 'utf8'");

$message = "";
$success=false; 
$what = ""; 


/**-----------------------------------------------------------------------------
* this function display the METAs in HEADER d* 
* @param array the mata array
* @return ECHO HTML content 
*-----------------------------------------------------------------------------*/
function display_metas($in){
  global $cust_lang_short;
  global $FB_APPID;
  global $DOMAIN_FQDN; 
  global $LOGO_FQDN; 

  $th = '';

      // essential meta 
      $th .= "\n";
      $th.= '<title>'.  (stripslashes($in['title'])).'</title>';
      
      $th .= "\n";
      // take only the sub 255 strings 
      $th.= '<meta name="description" content="'.substr(  (stripslashes($in['desc'])),0,  255).'"/>';
      $th .= "\n";
      // for google plus association 
      if ($in['gplus']) $th.= '<link rel="publisher" href="'.$in['gplus'].'"/>';
      $th .= "\n";
      // author for other browsers 
      if ($in['author']) $th.= '<meta rel="author" href="'.$in['author'].'"/>';
      $th .= "\n";
      if ($in['keys']) $th.= '<meta rel="keywords" lang="'.$cust_lang_short.'" content="'.  (stripslashes($in['keys'])).'"/>';
      $th .= "\n";
      // openngraph 
      // other OG default : 
      if ($in['type'])
      $th.= '<meta property="og:type" content="'.$in['type'].'"/> '; // default one  ! 
      $th .= "\n";

      if ($in['title'])
      $th.= '<meta property="og:title" content="'.  ($in['title']).'"/>';
      $th .= "\n";

      if ($in['desc'])
      $th.= '<meta property="og:description" content="'.substr(  ($in['desc']), 0, 255).'" />';
      $th .= "\n";

      if (!$in['image']) $in['image'] = str_replace("./", $DOMAIN_FQDN, $LOGO_FQDN); // defautl image in taht case 
      $th.= '<meta property="og:image" content="'.$in['image'].'" />';
      
        
      if ($in['url'])  
      $th.= '<meta property="og:url" content="'.$in['url'].'"/> ';
      $th .= "\n";

      // $th.= '<link rel="canonical" href="'.$in['url'].'"/>';

      // facebook appid
      if ($FB_APPID){
         $th.= '<meta property="fb:app_id" content="'.$FB_APPID.'" />';  
      }


      // prevent Google to archive this page
      if ($in['is']){
        if ($in['is']=="addisplay")
        $th.= '<meta name="googlebot" content="noarchive">'; 
      }
      
      // if ($in) $th.= '<meta name="fragment" content="!">'; 

    return $th; 

}

/**-----------------------------------------------------------------------------
* this function decode the received url Array  and return revalant info
*-----------------------------------------------------------------------------*/
function get_metas($urlar){
  global $cust_title, $cust_description, $cust_logo_fb_uri, $DOMAIN_FQDN, $cust_motto ,$cust_site_name, $DOMAIN_FQDN_SHORT, $SEO_ADD_DOMAINFQDN;
  global $cust_lang_long, $cust_gplus_url;

  global $dbItemsTable; 
  global $dbCatsTable; 
  global $dbUsersTable;
  global $ESCF;
  global $trans;

  // Z6.8.1 
  global $SEO_DISPLAY_FQDN ;
  global $SEO_ADD_FIELDS;
  global $SEO_ADD_FIELDS_SEP;
  global $SEO_ADD_FIELDS_POS;

  if ($SEO_ADD_DOMAINFQDN || $SEO_DISPLAY_FQDN) $plusfqdn = ' | '. $DOMAIN_FQDN_SHORT; else $plusfqdn='';

  // --- debug purpose --- 
  // echo '<!--'; 
  // var_dump($urlar);
  // echo '--!>';

  $twhat =  ($urlar['what']) ? $urlar['what'] : '' ;
  $taction =  ($urlar['action']) ? $urlar['action'] : '' ;
  $ttype =  ($urlar['type']) ? $urlar['type'] : '' ;
  $tid =  ($urlar['id']) ? $urlar['id'] : '' ;
  $tcatid =  ($urlar['catid']) ? $urlar['catid'] : '' ;
      
  if ($twhat=="ad")  $dbThisTable = $dbItemsTable;
  else if ($twhat=="user")  $dbThisTable = $dbUsersTable;
  else if ($twhat=="cat")  $dbThisTable = $dbUsersTable;


  //   $itemurl = $ESCF.$trans[$cust_lang_long]['ad'].'/'.$row->id.'/'.format_url_for_seo($row->title);
  // $caturl  = $ESCF.$trans[$cust_lang_long]['cat'].'/'.$row->catid.'/'.format_url_for_seo($row->cattitle);
  // $userurl  = $ESCF.$trans[$cust_lang_long]['user'].'/'.$row->userid.'/'.$row->id;
  // $userurl2  = $ESCF.$trans[$cust_lang_long]['user'].'/'.$row->id.'/'.format_url_for_seo($row->procpny);


  if (($urlar['origurl']=="home") || ($urlar['origurl']=="sell") || ($urlar['origurl']=="buy") || ($urlar['origurl']=="shops") ){
    $turl = $DOMAIN_FQDN.$ESCF.$trans[$cust_lang_long][$urlar['origurl']].'/'; 
    $ttitle=  $cust_site_name .' | '.$trans[$cust_lang_long][$urlar['origurl']].' | '. $DOMAIN_FQDN_SHORT ;
    $metasAr = Array('title'=>  $ttitle, 'desc'=>$cust_description, 'image'=>$cust_logo_fb_uri, 'url'=>$turl, 'gplus'=>$cust_gplus_url, 'type'=>'website'); 
    
  } if ($urlar['locfield']){
    $turl = $DOMAIN_FQDN.$ESCF.$trans[$cust_lang_long][$urlar['locfield']].'/'.$urlar['locid']; 
    $ttitle=  $trans[$cust_lang_long]['ad'] .' | '.$trans[$cust_lang_long][$urlar['locfield']].' '.$urlar['locid'] .' | '. $DOMAIN_FQDN_SHORT ;
    $metasAr = Array('title'=>  $ttitle, 'desc'=>$cust_description, 'image'=>$cust_logo_fb_uri, 'url'=>$turl, 'gplus'=>$cust_gplus_url, 'type'=>'website'); 
   
  }
  else {

    // 3 cases =  categories display , ads display , users display 
    // ----- CASE of CAT DISPLAY -----------------
    if ( ($urlar['what']== 'ad') && ($urlar['catid']!='') ) {
      // all adds from a categorie -> display catégories name + descritpion
      $dbThisTable = $dbCatsTable;
      $tcatid =  $urlar["catid"]; 
      $filter = " WHERE `$dbThisTable`.`id` = '$tcatid' "; // the id 
      $query = "SELECT `$dbThisTable`.`id`, `$dbThisTable`.`title`, `$dbThisTable`.`description`, `$dbThisTable`.`imgname`
      , `$dbThisTable`.`metatitle`,`$dbThisTable`.`metadesc`,  `$dbThisTable`.`metakey`
                FROM `$dbThisTable` ".$filter ; 
                
      $result = mysql_query($query);

      $row = mysql_fetch_object($result); 

      $turl  =  $DOMAIN_FQDN.$ESCF.$trans[$cust_lang_long]['cat'].'/'.$row->id.'/'.format_url_for_seo($row->title);
      $ttitle=  stripslashes($row->title) ;
      $tdesc = stripslashes($row->description);
      $tkey = ""; 

      //Z6.9 
      if ($row->metatitle) $ttitle=  stripslashes($row->metatitle);
      if ($row->metadesc) $tdesc=  stripslashes($row->metadesc);
      if ($row->metakey) $tkey=  stripslashes($row->metakey);


      // patch to extend the description when too short
      if (strlen($tdesc)<200){
        $number = rand(100, 1999);
        $xtra = "A la recherche d'une annonce dans ".$tdesc."? Découvrer nos $number annonces !";
        $tdesc=$xtra; 
      }

      $imgname = $row->imgname;      
      $firstimgurl="";
      if ($imgname && ($imgname!="")){
        foreach(explode(";",$imgname) as $imgnameItem) { 
          $filename= explode("|",$imgnameItem);
          // $firstimgurl= "tn_".$filename[0];
          $firstimgurl= $filename[0];
          break; // stop at fisrt one 
        }
      }
      if ($firstimgurl!='')
        $timgurl =  $DOMAIN_FQDN.'uploads/img/'.$firstimgurl ;
      else $timgurl = '';

      $metasAr = Array('title'=>  $ttitle, 'desc'=>$tdesc, 'image'=>$timgurl, 'url'=>$turl, 'gplus'=>$cust_gplus_url, 'type'=>'product', 'keys' =>$tkey, 'is'=>'listpercat'); 
    }

    // ----- CASE of AD DISPLAY -----------------
    if ( ($urlar['what']== 'ad') && ($urlar['id']!='') ) {
      // all adds from a categorie -> display catégories name + descritpion
      $dbThisTable = $dbItemsTable;
      $tid =  $urlar["id"]; 
      $filter = " WHERE `$dbThisTable`.`id` = '$tid' "; // the id 

      // add the filter type  : 
      if ($urlar['type'] == "zetvu")
         $filter.=  " AND  `$dbThisTable`.`type` = 'zetvu' "; 

      $query = "SELECT `$dbThisTable`.* 
                FROM `$dbThisTable` ".$filter ; 
               
      $result = mysql_query($query);

      $row = mysql_fetch_object($result); 

      $turl  =  $DOMAIN_FQDN.$ESCF.$trans[$cust_lang_long]['ad'].'/'.$row->id.'/'.format_url_for_seo($row->title);
      // $ttitle=    (stripslashes($row->title)).$plusfqdn;
      // $tdesc =   (stripslashes($row->description));
      // $tauthor =   (stripslashes($row->username));

      $ttitle=  stripslashes($row->title).$plusfqdn;
      $tdesc = stripslashes($row->description);
      $tauthor = stripslashes($row->username);

      // Z6.8  att to TITLE and description the indicated dbfields 
      if ($SEO_ADD_FIELDS){
        $af = explode(';',$SEO_ADD_FIELDS); 
        $atitle=''; 
        foreach ($af as $dbfield) {
          $akey = strtolower(trim($dbfield)); 
          if ($row->$akey){
            $asep=($atitle) ? $SEO_ADD_FIELDS_SEP : '';
            // $atitle.= $asep .   (stripslashes($row->$akey));
            $atitle.= $asep . stripslashes($row->$akey);
          }
        }
        if ($SEO_ADD_FIELDS_POS=="post"){
          $ttitle .= $SEO_ADD_FIELDS_SEP . $atitle;
          $tdesc .= $SEO_ADD_FIELDS_SEP . $atitle;
        } else {
          $ttitle = $atitle . $SEO_ADD_FIELDS_SEP . $ttitle ;
          $tdesc = $atitle . $SEO_ADD_FIELDS_SEP . $tdesc ; 
        }
      }


      $imgname = $row->imgname;      
      $firstimgurl="";
      if ($imgname && ($imgname!="")){
        foreach(explode(";",$imgname) as $imgnameItem) { 
          $filename= explode("|",$imgnameItem);
          // $firstimgurl= "tn_".$filename[0];
          $firstimgurl= $filename[0];
          break; // stop at fisrt one 
        }
      }
      if ($firstimgurl!='')
        $timgurl =  $DOMAIN_FQDN.'uploads/img/'.$firstimgurl ;
      else $timgurl = '';
      
      $metasAr = Array('title'=>  $ttitle, 'desc'=>$tdesc, 'image'=>$timgurl, 'url'=>$turl, 'gplus'=>'', 'author'=>$tauthor, 'type'=>'product', 'is'=>'addisplay'); 
    }


    // ----- CASE of USER DISPLAY  -----------------
    if ( ($urlar['what']== 'user') && ($urlar['id']!='') ) {
      // all adds from a categorie -> display catégories name + descritpion
      $dbThisTable = $dbUsersTable;
      $tid =  $urlar["id"]; 
      $filter = " WHERE `$dbThisTable`.`id` = '$tid' "; // the id 
      $query = "SELECT `$dbThisTable`.`id`, `$dbThisTable`.`procpny`, `$dbThisTable`.`bio`, `$dbThisTable`.`avatarimg`, `$dbThisTable`.`firstname`, `$dbThisTable`.`lastname`, `$dbThisTable`.`protype`
                FROM `$dbThisTable` ".$filter ; 
              
      $result = mysql_query($query);
      $row = mysql_fetch_object($result); 
      $turl  =  $DOMAIN_FQDN.$ESCF.$trans[$cust_lang_long]['user'].'/'.$row->id.'/'.format_url_for_seo($row->procpny);
      
      $ttitle=''; 
      if ($row->protype=="pro")  $ttitle=  (stripslashes($row->procpny));
      if ($row->protype=="pub")  $ttitle=  (stripslashes($row->firstname)) . ' ' . (stripslashes($row->lastname))  ;
      $ttitle.=$plusfqdn;
      $tdesc = (stripslashes($row->bio));

      $imgname = $row->avatarimg;      
      $firstimgurl="";
      if ($imgname && ($imgname!="")){
        foreach(explode(";",$imgname) as $imgnameItem) { 
          $filename= explode("|",$imgnameItem);
          // $firstimgurl= "tn_".$filename[0];
          $firstimgurl= $filename[0];
          break; // stop at fisrt one 
        }
      }
      if ($firstimgurl!='')
        $timgurl =  $DOMAIN_FQDN.'uploads/users/'.$firstimgurl ;
      else $timgurl = '';
      
      $metasAr = Array('title'=>  $ttitle, 'desc'=>$tdesc, 'image'=>$timgurl, 'url'=>$turl, 'gplus'=>$cust_gplus_url, 'author'=>$ttitle, 'type'=>'profile', 'is'=>'userdisplay'); 
    }

  }

 
  return $metasAr; 

}



/**-----------------------------------------------------------------------------
* decode and identify call to 
* 
* @param string $u_agent
* @return array an array with browser, version and platform keys
*-----------------------------------------------------------------------------*/
function detect_escaped_fragment(){

  if (isset($_GET['_escaped_fragment_'])) {
    // check for Crowler escape fragment
    $escapedfragment = $_GET['_escaped_fragment_'];
    // echo "ESCAPE FRAGMENT DETECTED"; 
    // var_dump($_REQUEST);
    $r = my_url_rewrite($escapedfragment);
    // var_dump($r);
    return $r; 
  } else 
    return false; 
};



/**-----------------------------------------------------------------------------
* decode and identify call to 
* @param string $u_agent
* @return array an array with browser, version and platform keys
*-----------------------------------------------------------------------------*/
function parse_request_uri(){

  if (isset($_SERVER['REQUEST_URI'])) {
    // check for Crowler escape fragment
    $request_uri =  $_SERVER['REQUEST_URI'];

    // remove the BASE_PATH -- FISRT OCCURENCE ONLY ---
    // $request_uri = str_replace(BASE_PATH, "", $request_uri);
    $pos = strpos($request_uri,BASE_PATH);
    if ($pos !== false) {
        $request_uri = substr_replace($request_uri,'',$pos,strlen(BASE_PATH));
    }

    $r = my_url_rewrite($request_uri);
    return $r; 
  } else 
    return false; 
};


/**-----------------------------------------------------------------------------
* detect google bot 
*-----------------------------------------------------------------------------*/
function detect_googlebot() {
  if (strstr(strtolower($_SERVER['HTTP_USER_AGENT']), "googlebot")) return true ; 
  else return false ; 
}


/**-----------------------------------------------------------------------------
* decode and identify call to 
* 
* @param string $u_agent
* @return array an array with browser, version and platform keys
*-----------------------------------------------------------------------------*/
function my_url_rewrite($escfragement){

  global $trans; // contain the translation part to decode the url 
  global $cust_lang_long;// current language 
  global $HOMEPAGE_DISPLAY_WHAT ; 

  //echo ("calling detect ecaped fragment -- "); die;
  $separator='/'; // other value is '-'
 
  // echo "escfragment =  $escfragement </br>";     
  // part 1  => detect 
  $translatedhash="";
  // var_dump($trans);
  foreach ($trans[$cust_lang_long] as $key => $value) {
    //echo "-- $key -> $value </br>"; 
    if (stripos($escfragement, $value)!== false){
      $translatedhash = $key ;
      $translatedhash = str_replace($value, $key , $escfragement);
      // echo "FOUND -> translated =  $translatedhash </br>"; 
      break; 
    }
  }

  
  $xwhat=''; $xaction=''; $xtype=''; $xid='';$xcatid='';
  // part 2 => translate 

  // remove trailing '/' addes by google bot sometimes 
  $translatedhash = rtrim($translatedhash, '/');
  // echo "After modif slash =  $translatedhash </br>"; 


  if ($translatedhash){
    if ($translatedhash=="sell" ) {$xaction='list'; $xwhat='ad'; $xtype='sell';}
    else if ($translatedhash=="buy") {$xaction='list'; $xwhat='ad'; $xtype='buy';}
    else if ($translatedhash=="home") {
      $xaction='list';
      if ($HOMEPAGE_DISPLAY_WHAT=="user") $xwhat='user';
      else  $xwhat='ad';
    }
    else if ($translatedhash=="shops") {$xaction='list'; $xwhat='user';}
    else if (stripos($translatedhash, 'region/')!== false){
        $yid=explode($separator,$translatedhash); 
        $xaction='list'; $xwhat='ad'; $xloctype = 'region'; $xlocid= $yid[1];
    }
    else if (stripos($translatedhash, 'cat/') !== false){
      $yid=explode($separator,$translatedhash); 
      $xaction='list'; $xwhat='ad'; $xcatid = $yid[1];
     
    } else if (stripos($translatedhash, 'ad/')!== false){
      $yid=explode($separator,$translatedhash); 
      $xaction='list'; $xwhat='ad'; $xid = $yid[1];
    }
    else if (stripos($translatedhash, 'user/')!== false){
      $yid=explode($separator,$translatedhash); 
      $xaction='list'; $xwhat='user'; $xid = $yid[1];
    }
    else if (stripos($translatedhash, 'zetevu/')!== false){
      $yid=explode($separator,$translatedhash); 
      $xaction='list'; $xwhat='ad'; $xtype='zetvu'; $xid = $yid[1];
     
    }
    else if (stripos($translatedhash, 'zetevu')!== false){
      $xaction='list'; $xwhat='ad'; $xtype='zetvu';
    }
    else if (stripos($translatedhash, 'zetvu/')!== false){
      $yid=explode($separator,$translatedhash); 
      $xaction='list'; $xwhat='ad'; $xtype='zetvu'; $xid = $yid[1];
     
    }
    else if (stripos($translatedhash, 'zetvu')!== false){
      $xaction='list'; $xwhat='ad'; $xtype='zetvu';
    }  
    else if (stripos($translatedhash, 'news/')!== false){
      $yid=explode($separator,$translatedhash); 
      $xaction='list'; $xwhat='ad'; $xtype='zetvu'; $xid = $yid[1];
    }
    else if (stripos($translatedhash, 'news')!== false){
      $xaction='list'; $xwhat='ad'; $xtype='zetvu';
    }
    else if (stripos($translatedhash, 'videos/')!== false){
      $yid=explode($separator,$translatedhash); 
      $xaction='list'; $xwhat='ad'; $xtype='zetvu'; $xid = $yid[1];
     
    }
    else if (stripos($translatedhash, 'videos')!== false){
      $xaction='list'; $xwhat='ad'; $xtype='zetvu';
    }


    $outdata = Array (
              'action' => $xaction,
              'what'=>$xwhat,
              'type'=> $xtype,
              'id'=> $xid, 
              'catid'=>$xcatid,
              'locfield'=>$xloctype, 
              'locid'=>$xlocid,
              'origurl'=>$translatedhash
    );
    return $outdata ;
  }
  return false;
}; 

 function format_url_for_seo($in){

            $out=$in;
            $out = strtolower(  (stripslashes($in)));
            //$out = strtolower(stripslashes($in));
            $out = mb_convert_encoding($out, "UTF-8");

            // $out = strtr($out, "éèêàç", "eeeac");
            // replace é and è and ê by e
            $out = str_replace("é","e", $out);
            $out = str_replace("è","e", $out);
            $out = str_replace('ê','e', $out);
            $out = str_replace('à','a', $out);
            $out = str_replace('ç','c', $out);
            //$out = strtolower(  (stripslashes($out)));

            // replace space and other chars with '-'
            $out = preg_replace("![^a-z0-9]+!i", "-", $out);
            return $out; 
        }; 


/**---------------------------------------------------------------------------
* this funciton display the keywords with their translations in hidden div so that 
*  javascripot can read this 
* @return HML with keywords 
*-----------------------------------------------------------------------------*/
function display_keywords_seo(){

  global $trans; // contain the translation part to decode the url 
  global $cust_lang_long;// current language 

  $th=''; 
  $separator='/'; // other value is '-'
  
  $th .="<div class='seo_zone'>"; 
  foreach ($trans[$cust_lang_long] as $key => $value) {
    //echo "-- $key -> $value </br>"; 
    $th .="<div class='seo_keywords' seokey='$key' seotrans='$value'></div>";
  }
  $th .="</div>";

  return $th;
  
}


/**---------------------------------------------------------------------------
* this funciton display the keywords with their translations in hidden div so that 
*  javascripot can read this 
* @return HML with keywords 
*-----------------------------------------------------------------------------*/
function display_social_urls(){
  global $cust_facebook_url;
  global $cust_twitter_url;
  global $cust_gplus_url;
  global $cust_youtube_url;
  global $cust_tandc_url; //Z5.5.1
  global $cust_rgda_url; // Z5.5.1

  $th=''; 
  $separator='/'; // other value is '-'
  
  $th .="<div class='socialurls_zone'>"; 
 
  if ($cust_facebook_url) $th .="<div class='social_urls' z-code='FB' icon='facebook-square' key='facebook' url='$cust_facebook_url'></div>";
  if ($cust_twitter_url) $th .="<div class='social_urls' z-code='TW' icon='twitter-square' key='twitter' url='$cust_twitter_url'></div>"; 
  if ($cust_gplus_url) $th .="<div class='social_urls' z-code='GO' icon='google-plus-square' key='gplus' url='$cust_gplus_url'></div>";
  if ($cust_youtube_url) $th .="<div class='social_urls' z-code='YO' icon='youtube-square' key='youtube' url='$cust_youtube_url'></div>";

  if ($cust_tandc_url) $th .="<div class='tandc_url' icon='' key='' url='$cust_tandc_url'></div>";
  if ($cust_rgda_url) $th .="<div class='rgda_url' icon='' key='' url='$cust_rgda_url'></div>";

  $th .="</div>";

  return $th;
  
}

function display_social_footer_bar(){
  global $SOCIAL_WIDGET_LIST; 
  global $cust_facebook_url;
  global $cust_twitter_url;
  global $cust_gplus_url;
  global $cust_youtube_url;


   $th='';
   $xname=""; $za="";

  foreach(explode("+",$SOCIAL_WIDGET_LIST) as $sci) { 
    if ($sci=='FB') { $u=$cust_facebook_url; $i= 'facebook-square'; $t="facebook";}
    if ($sci=='TW') { $u=$cust_twitter_url; $i= 'twitter-square'; $t="twitter";}
    if ($sci=='GO') { $u=$cust_gplus_url; $i= 'google-plus-square'; $t="google-plus";}
    if ($sci=='YO') { $u=$cust_youtube_url; $i= 'youtube-square'; $t="youtube";}
    if ($sci=='CT') { $u='#'; $i= 'envelope'; $t="contact"; $za="contact";  $xname='name="action"';}

    if ($sci!='PT') {
      $th .= '  <li class="social-elem">'; 
      $th .= " <a nottip='yes' href='$u' target='_blank' $xname z-action='$za'>";
      $th .= '    <i class="icon-fa-'.$i.'"></i>'; 
      $th .= '  </a>';
      $th .= ' </li>'; 
    }
  }           
  return $th; 

}


function getZetevuName() {
  global $ZETVU_AS_NEWS;
  global $ZETVU_AS_VIDEO_TUTO;
  
  $out = "";
  if  ($ZETVU_AS_NEWS) $zetevuLabel = $out ='news';
  else if  ($ZETVU_AS_VIDEO_TUTO) $zetevuLabel = $out ='videos';
  else $zetevuLabel = $out ='zetevu';

  return $out; 
}


/**-----------------------------------------------------------------------------
* deliver the 
* 
* @param string $u_agent
* @return array an array with browser, version and platform keys
*-----------------------------------------------------------------------------*/
function html_snapshot_display($whattodo, $urlparams){

  global $nav_menu; // coming from SETTINGS 
  global $cust_lang_long;// current language 
  global $trans;  // the translation string

  global $dbItemsTable; 
  global $dbCatsTable; 
  global $dbUsersTable;

  global $cust_title;
  global $cust_description;

  global $page_map_first_p;
  global $page_map_center_p;
  global $page_map_last_p;

  global $ESCF; // escape fragement set ino init-settings.php
  global $DOMAIN_FQDN; 
  global $SEO_INCLUDE_ZETVU;
  global $LOCALE_DEFAULT_CURRENCY;
  global $ENABLE_COUNTRY_MAP; 

  global $SEO_CATLIST;

  // local variables 
  $realtodo=array();
  $th=""; $tc=""; 

  //var_dump($urlparams);

  // ---- case of Nav --> display the main nav window 
  if ($whattodo=="nav"){

    $tid =  ($urlparams['id']) ? $urlparams['id'] : '' ;

    // *** case when there are no ID -> Generic display 
    if (!$tid) {
      $nav = Array ('home', 'sell', 'buy', 'shops'); 
      if ($SEO_INCLUDE_ZETVU) $nav = Array ('home', 'sell', 'buy', 'user', getZetevuName()); 

      // already within a UL part , so display only the LI parts
      foreach ( $nav as $key => $value) {
        # code...$trans[$cust_lang_long]
        $th .= '<li class="" id="nav-'.$key.'">';
        $th .= '<a href="'.$DOMAIN_FQDN.$ESCF.$trans[$cust_lang_long][$value].'">';
        $th .= $trans[$cust_lang_long][$value];
        $th .= '</a>';
        $th .= '</li>';
        $th .= "\n";
        // $th.= "\n";
      }
      if ($th) $th='<ul class="tabbed">'.$th.'</ul>'; 


      // ---  then display the full list of CATEGORIES
      // filtering rules
      $dbThisTable = $dbCatsTable; 
      $filter = " WHERE `$dbThisTable`.`status` IN ('40','45', '46')"; // published
      if ($urlparams!==false){
        $tcatid =  ($urlparams['catid']) ? $urlparams['catid'] : '' ;
        if ($tcatid) $filter .= "AND `$dbThisTable`.`id` = '$tcatid' "; 
      }
      $sql_sort=" ORDER by  `$dbThisTable`.`title` DESC ";
      $sql_limit =""; 
      $sql_group ="";

      $query = "SELECT `$dbThisTable`.`title`, `$dbThisTable`.`id`, `$dbThisTable`.`description`
                    FROM `$dbThisTable` ".$join .$filter." ". $sql_sort . " " . $sql_group . " " .$sql_limit  ; 
      // make the real query 
      $result = @mysql_query($query);


    }  // end no ID  
    else {

      // case of an ID present 
      $realtodo = $urlparams;
      $twhat =  ($realtodo['what']) ? $realtodo['what'] : '' ;
      $taction =  ($realtodo['action']) ? $realtodo['action'] : '' ;
      $ttype =  ($realtodo['type']) ? $realtodo['type'] : '' ;
      $tid =  ($realtodo['id']) ? $realtodo['id'] : '' ;
      $tcatid =  ($realtodo['catid']) ? $realtodo['catid'] : '' ;

      if ($twhat=="ad")  $dbThisTable = $dbItemsTable;
      else if ($twhat=="user")  $dbThisTable = $dbUsersTable;

      // filtering rules 
      $filter = " WHERE `$dbThisTable`.`status` IN ('40','45', '46')"; // published

      if ($ttype) $filter .= " AND `$dbThisTable`.`type` = '$ttype' "; 
      else  if ($twhat=="ad") $filter .= "AND `$dbThisTable`.`type` != 'zetvu' ";

      if ($tcatid) $filter .= " AND `$dbThisTable`.`catid` = '$tcatid' "; 
      if ($tid) $filter .= " AND `$dbThisTable`.`id` = '$tid' "; 


      // other rules 
      $sql_sort=" ORDER by  `$dbThisTable`.`moddate` DESC ";
      $sql_limit =" LIMIT 0 , 20"; 
      $sql_group ="";

      if ($twhat=="ad"){
        $join .= " LEFT OUTER JOIN `$dbCatsTable` ON `$dbThisTable`.`catid`= `$dbCatsTable`.`id` ";
        $query = "SELECT `$dbThisTable`.* , `$dbCatsTable`.`title` AS cattitle
                    FROM `$dbThisTable` ".$join .$filter." ". $sql_sort . " " . $sql_group . " " .$sql_limit  ; 
      } 
      else if ($twhat=="user"){
        $join ='';
        $query = "SELECT `$dbThisTable`.* 
                    FROM `$dbThisTable` ".$join .$filter." ". $sql_sort . " " . $sql_group . " " .$sql_limit  ; 
      } 

      // make the real query 
      $result = @mysql_query($query);
      
      if ($result){
        while ($row = mysql_fetch_object($result)) {
          $caturl  = $DOMAIN_FQDN.$ESCF.$trans[$cust_lang_long]['cat'].'/'.$row->catid.'/'.format_url_for_seo($row->cattitle);
          $th .='     <li  itemprop="category" id="'.$row->catid.'"><a name="manage_ad" href="'.$caturl.'">'.  (stripslashes($row->cattitle)).'</a></li>';
        }
      } else {
         $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
         // echo $sqlerror ; 
      }
    }    

  } // end if nav 

  // ----------------- case of list of maintitle ------------------------------------------------------------------------------
  else if ($whattodo=="maintitle"){
     // add title and descritpion though H1 and P to help SEO as this is the fisrt text displayed.  
      // $th .= '<h1>'.  ($cust_title).'</h1>';      
      // case of home page 
   
      if (!$urlparams ){
        $th .= '<h1>'.  $cust_description.'</h1>';
      } else {
        $realtodo = $urlparams;

        $twhat =  ($realtodo['what']) ? $realtodo['what'] : '' ;
        $taction =  ($realtodo['action']) ? $realtodo['action'] : '' ;
        $ttype =  ($realtodo['type']) ? $realtodo['type'] : '' ;
        $tid =  ($realtodo['id']) ? $realtodo['id'] : '' ;
        $tcatid =  ($realtodo['catid']) ? $realtodo['catid'] : '' ;
        $torig =  ($realtodo['origurl']) ? $realtodo['origurl'] : '' ; 

        if ($taction=="list" && $twhat=="ad" && ($ttype=="sell" || $ttype=="buy" || $torig=="home")){
          $th .= '<h1>'.  $cust_description.'</h1>';
        }
      }
  }

  // ----------------- case of list of breadcrumb ------------------------------------------------------------------------------
  else if ($whattodo=="breadcrumb") {
    // var_dump(($urlparams));
    $bwhat =  $urlparams['what'];
    $btype =  $urlparams['type'];
    $baction =  $urlparams['action'];
    $bhomeurl = $DOMAIN_FQDN.$ESCF.$trans[$cust_lang_long]['home'];

    $bcrumbAr="";

    if ($bwhat=="ad"){
      $bcrumbAr[]=array('title'=>  $trans[$cust_lang_long]['home'] , 'url'=> $bhomeurl) ;
      if ($urlparams['catid']){
        $btitle = $trans[$cust_lang_long]["cat"];
        $burl  = $DOMAIN_FQDN.$ESCF.$trans[$cust_lang_long]["cat"].'/'.$urlparams['catid'].'/';
        $bcrumbAr[]=array('title'=>  $btitle, 'url'=> $burl) ;
      } else {
        $btitle = $trans[$cust_lang_long][$btype];
        $burl  = $DOMAIN_FQDN.$ESCF.$trans[$cust_lang_long][$btype];
        $bcrumbAr[]=array('title'=>  $btitle, 'url'=> $burl) ;
      }
    }

    if ($bwhat=="user"){
      $bcrumbAr[]=array('title'=>  $trans[$cust_lang_long]['home'] , 'url'=> $bhomeurl) ;
      $btitle = $trans[$cust_lang_long]["shops"];
      $burl  = $DOMAIN_FQDN.$ESCF.$trans[$cust_lang_long]["shops"];
      $bcrumbAr[]=array('title'=>  $btitle, 'url'=> $burl) ;
    }

    if ($bcrumbAr){
      $th .= '<ul class="breadcrumb">';
      foreach ( $bcrumbAr as $key => $bcrumbelem) {
        $th .= '<li><a href="'.$bcrumbelem['url'].'">'.$bcrumbelem['title'].'</a></li>';
      }
      $th .= '</ul>';
    }
    
  }

  // ----------------- case of list of CATEGORIES ------------------------------------------------------------------------------
  else if ($whattodo=="catlist") {
    
    // get the cat list 
    $catlist =  sql_list_top('cat', '',true);
    if ($catlist){
       foreach ($catlist as $key => $catlevel1) {
        $cntt =0;
        $caturl  = $DOMAIN_FQDN.$ESCF.$trans[$cust_lang_long]['cat'].'/'.$catlevel1['id'].'/'.format_url_for_seo($catlevel1['title']);
        $cntt = $catlevel1['cnt'];

        if ($catlevel1['id']=="9999") continue; //skip the ZETEVU 
        if ($SEO_CATLIST=="nonull" &&  $cntt==0) continue ; // skpip of filter zero value 

        $th .='<div class="cat-list  col-md-4 col-sm-4 ">';
        $th .='<h4 class="cat-title">';
        $th .= '<a title="'.$catlevel1['desciption'].' "href="'.$caturl.'">';
        $th .= $catlevel1['title'];
        if ($cntt) $th .= '<span class="count">'.$cntt.'</span>';

        $th .= '</a>';
        $th .='</h4>';

        if ($catlevel1['childs']) {
                      // var_dump($catlevel1['childs']);
          foreach ($catlevel1['childs'] as $key => $catlevel2) {
            $cnt =  $catlevel2['cnt'];
            $caturl  = $DOMAIN_FQDN.$ESCF.$trans[$cust_lang_long]['cat'].'/'.$catlevel2['id'].'/'.format_url_for_seo($catlevel2['title']);

            $th .='<div style="padding-left:10px;">';
            $th .= '<a title="'.$catlevel2['desciption'].' "href="'.$caturl.'">';
            $th .= $catlevel2['title'];
            $th .= '</a>';
            if ($cnt) $th .= '<span class="count">'.$cnt.'</span>';
            $th .='</div>'; 
          }
        }
        $th .='</div>';
      }
    }

  }
  // ----------------- case of content-------------------------------------------------------------------------------
  else {
    // other cases CONTENT CASE 
    if ($urlparams==false){
      // default situation - if "MAP on HOME PAGE, we display the content otherwise, we display the list of ads "
      if ($ENABLE_COUNTRY_MAP) {
          $th .=   ($page_map_first_p);
          $th .= "\n";
          $th .=   ($page_map_center_p);
          $th .= "\n";
          $th .=   ($page_map_last_p);
          $th .= "\n";
      } else { 
        $realtodo['action']='list'; $realtodo['what']='ad';
      }
    } else 
      
      $realtodo = $urlparams;

      // ****** continue with the processing 
      $twhat =  ($realtodo['what']) ? $realtodo['what'] : '' ;
      $taction =  ($realtodo['action']) ? $realtodo['action'] : '' ;
      $ttype =  ($realtodo['type']) ? $realtodo['type'] : '' ;
      $tid =  ($realtodo['id']) ? $realtodo['id'] : '' ;
      $tcatid =  ($realtodo['catid']) ? $realtodo['catid'] : '' ;

      if ($twhat=="ad")  $dbThisTable = $dbItemsTable;
      else if ($twhat=="user")  $dbThisTable = $dbUsersTable;

      $join=""; 
    
      // filtering rules 
      $filter = " WHERE `$dbThisTable`.`status` IN ('40','45', '46')"; // published

      if ($ttype) $filter .= " AND `$dbThisTable`.`type` = '$ttype' "; 
      else  if ($twhat=="ad") $filter .= "AND `$dbThisTable`.`type` != 'zetvu' ";

      if ($tcatid) $filter .= " AND `$dbThisTable`.`catid` = '$tcatid' "; 
      if ($tid) $filter .= " AND `$dbThisTable`.`id` = '$tid' "; 

      // other rules 
      $sql_sort=" ORDER by  `$dbThisTable`.`moddate` DESC ";
      $sql_limit =" LIMIT 0 , 20"; 
      $sql_group ="";

      if ($twhat=="ad"){
        $join .= " LEFT OUTER JOIN `$dbCatsTable` ON `$dbThisTable`.`catid`= `$dbCatsTable`.`id` ";
        $query = "SELECT `$dbThisTable`.* , `$dbCatsTable`.`title` AS cattitle
                    FROM `$dbThisTable` ".$join .$filter." ". $sql_sort . " " . $sql_group . " " .$sql_limit  ; 
      } 
      else if ($twhat=="user"){
        $join ='';
        $query = "SELECT `$dbThisTable`.* 
                    FROM `$dbThisTable` ".$join .$filter." ". $sql_sort . " " . $sql_group . " " .$sql_limit  ; 
      } 

      // make the real query 
      $result = @mysql_query($query);
      // echo $query;  
      if (!$result) {
        $sqlerror =  "Could not successfully run query from DB: " . mysql_error(). "--".$query;
        // echo $sqlerror ; 
      }

    $totnbrofresults = @mysql_num_rows($result);
    // echo "results= $totnbrofresults"; 
    if (($totnbrofresults) && ($totnbrofresults !=0)){

    $th .= "\n";


      while ($row = mysql_fetch_object($result)) {

        // keep a copy of the cattitle 
        if ($tcatid &&!$tid){
          $saved_cattitle = $row->cattitle;
        } else $saved_cattitle=""; 

        // ===== pre processing for some fields
        // -- Image URL 
        if ($twhat=="ad"){
          $imgname = $row->imgname;
          $dest_path =$DOMAIN_FQDN."uploads/img/"; // depend on the type of element 
        } else if ($twhat=="user"){
          $imgname = $row->avatarimg;
          $dest_path =$DOMAIN_FQDN."uploads/user/"; // depend on the type of element 
        }
        $firstimgurl="";
       
        if ($imgname && ($imgname!="")){
          foreach(explode(";",$imgname) as $imgnameItem) { 
            $filename= explode("|",$imgnameItem);
            // $firstimgurl= $dest_path."tn_".$filename[0];
            $firstimgurl= $dest_path.$filename[0];
            break; // stop at fisrt one 
          }
        }

        // -- ads and catégories url 
        // format is /#!cat-id or /#!ad-id
        // $itemurl = $ESCF.$trans[$cust_lang_long]['ad'].'-'.$row->id;
        // $caturl  = $ESCF.$trans[$cust_lang_long]['cat'].'-'.$row->catid;
        // $userurl  = $ESCF.$trans[$cust_lang_long]['user'].'-'.$row->userid;
        // $userurl2  = $ESCF.$trans[$cust_lang_long]['user'].'-'.$row->id;

       if ($ttype=="zetvu")
         $itemurl = $DOMAIN_FQDN.$ESCF.$trans[$cust_lang_long][getZetevuName()].'/'.$row->id.'/'.format_url_for_seo($row->title);
       else 
          $itemurl = $DOMAIN_FQDN.$ESCF.$trans[$cust_lang_long]['ad'].'/'.$row->id.'/'.format_url_for_seo($row->title);

        $caturl  = $DOMAIN_FQDN.$ESCF.$trans[$cust_lang_long]['cat'].'/'.$row->catid.'/'.format_url_for_seo($row->cattitle);
        // $userurl  = $DOMAIN_FQDN.$ESCF.$trans[$cust_lang_long]['user'].'/'.$row->userid.'/'.$row->id;
        $userurl  = $DOMAIN_FQDN.$ESCF.$trans[$cust_lang_long]['user'].'/'.$row->userid.'/';
        $userurl2  = $DOMAIN_FQDN.$ESCF.$trans[$cust_lang_long]['user'].'/'.$row->id.'/'.format_url_for_seo($row->procpny);
       
        // if ($tid) $tc .=''; 
        // else  $tc .='<li class="" id="'.$row->id.'" localid="1">';
        $tc .= "\n";
        
        if ($twhat=="ad") {

          // main surrounding header
          if ($tid){ 
            $tc .='  <link itemprop="url" name="show_ad" what="ad" lid="1" id="'.$row->id.'" href="'.$itemurl.'"/>'; 
            $tc .=' <div class="post row" itemscope="" itemtype="http://schema.org/Offer">';
            $tc .= "\n";
            $tc .='<h1 itemprop="name">'.  (stripslashes($row->title)).'</h1>';
          }
          else {
            // $tc .='<a itemprop="url" name="show_ad" what="ad" lid="1" id="'.$row->id.'" href="'.$itemurl.'">'; 
            // $tc .='<a  href="'.$itemurl.'">'; 
            $tc .= "\n";
            $tc .=' <div class="post col-lg-3 col-md-4 col-sm-6 " itemscope="" itemtype="http://schema.org/Offer">';
            $tc .='  <div class="tile">';
            $tc .= "\n";
            $tc .='<a name="show_ad" what="ad" lid="1" id="'.$row->id.'" href="'.$itemurl.'">'; 
            $tc .='<h2 class="title" itemprop="name" >'.  (stripslashes($row->title)).'</h2>';
            $tc .='</a>';
            $tc .= "\n";
          }

          // image 
          if ($firstimgurl){
            $tc .='  <img itemprop="image" src="'.$firstimgurl.'" alt="'.  (stripslashes($row->title)).'" class="">  '; 
            $tc .= "\n";
          }

          $tc .='  <p itemprop="description">'.  (stripslashes($row->description)).'</p>'; 
          $tc .= "\n";

          if ($row->price) {
            $tc .='  <div >'; 
            $tc .='     <div class="post-price price-label " itemprop="price" >'.$row->price.$LOCALE_DEFAULT_CURRENCY.'<div itemprop="priceCurrency" content="'.$LOCALE_DEFAULT_CURRENCY.'"></div></div>';
            $tc .=' </div>'; 
            $tc .= "\n";
          }
          $tc .='     <div class="category-title btn btn-sm btn-default" itemprop="category" id="'.$row->catid.'"><a name="manage_ad" href="'.$caturl.'">'.  (stripslashes($row->cattitle)).'</a></div>';


          $tc .='  <div class="tile-footer">'; 
          $tc .='  <div id="" itemprop="availabilityStarts" content="'.$row->moddate.'" class="post-date">'.$row->moddate.'</div>';
          $tc .='  <div id="" itemprop="availableAtOrFrom" itemscope="" itemtype="http://schema.org/Place" class="post-location" itemprop="address" content="'.$row->loccity.'">'.$row->loccity.'</div>';


          //$tc .='  <div id="" class="post-status">'.$row->status.'</div>   '; 
          //$tc .='  <div id="" class="post-hits">'.$row->hits.'</div>';
          // display only if seomeone wants it 
          if ($row->username) 
            $tc .='  <div class="post-username btn btn-sm btn-default"><a name="show_ad" href="'.$userurl.'"> '.$row->username.'</a></div>';

          $tc .=' </div>'; // end tile-footer 

          if (!$tid)  $tc .=' </div>'; // end tike 

          $tc .=' </div>'; // end main DIV
          $tc .= "\n";

          if ($tid){$toto=1;}
          else {
            // $tc .='</a>';
            $tc .= "\n";
          } 
           
        } 
        else if ($twhat=="user"){

          if ($row->protype=="pub" || $row->protype=="pro" ){
            
            $tc .=' <div class="post col-lg-3 col-md-4 col-sm-6 " itemscope="" itemtype="http://schema.org/Organization">';
            $tc .='  <div class="tile">';

            if ($firstimgurl){
              $tc .='  <img itemprop="logo" src="'.$firstimgurl.'" alt="" class="bordered ad">  '; 
            }

            $tc .='  <a itemprop="name" name="show_ad" what="ad" lid="1" id="'.$row->id.'" href="'.$userurl2.'">';

            // title
            $tht=""; 
            if ($row->protype=="pro") $tht .='  '.  (stripslashes($row->procpny));
            else  $tht .='  '.  (stripslashes($row->firstname). ' ' . stripslashes($row->lastname));
              
            if ($tid) $tc .='<h1>'.$tht.'</h1>';
            else $tc .='<h2>'.$tht.'</h2>';

            $tc .='</a>';

            $tc .='  <p >'.  (stripslashes($row->bio)).'</p>'; 
            $tc .='  <div id="" class="post-date">'.$row->moddate.'</div>';

            $tc .='  <div itemprop="address" itemscope itemtype="http://schema.org/PostalAddress">';
            $tc .='  <span itemprop="streetAddress">1'.  (stripslashes($row->location)).'</span>';
            $tc .='  <span itemprop="addressLocality">'.  (stripslashes($row->loccity)).'</span>';
            $tc .='  <span itemprop="addressRegion">'.  (stripslashes($row->locregion)).'</span>';
            $tc .='  </div>';

            //$tc .='  <div id="" class="post-status">'.$row->status.'</div>   '; 
            $tc .='  <div id="" class="post-hits">'.$row->hits.'</div>';

            $tc .=' </div>'; // end tile 
            $tc .=' </div>'; // end section
            $tc .= "\n";
          }
        }
        $tc .= "\n";
      } // end while

      //in case of categories, display the  catégory title
      if ($saved_cattitle){
        $th .= '<h1> Les Annonces de <strong>'.  $saved_cattitle.'</strong></h1>';
      }


      //add the content 
      $th .= $tc."\n";

      $th .= "\n";
    } // end if 
    else $th.="<h2>Aucune annonce trouvée</h2>"; 
  
  } 

  return $th;
} ;


function display_header_comments(){
  global $uagent; 
  global $serverremoteaddr; 
  global $isGoogleBot;

  $today = date("Y-m-d H:i:s"); 
  ?>
      <!-- ===========================  -->
      <!-- ZADS HTML VERSION DISPLAYED  -->
      <!-- Version  : <?php echo ZADS_HTML_SNAP_VERSION ; ?>  -->
      <!-- Called by UserAgent  : <?php echo $uagent ; ?>  -->
      <!-- Is google bot ?   <?php echo $isGoogleBot ; ?>  -->
      <!-- remote IP  : <?php echo $serverremoteaddr ; ?>  -->
      <!-- requested uri : <?php echo $_SERVER['REQUEST_URI']; ?>  -->
      <!-- Accept_language : <?php echo $_SERVER['HTTP_ACCEPT_LANGUAGE']; ?>  -->
      <!-- date  : <?php echo $today ; ?>  -->
      <!-- ===========================  -->

  <?php 

}

// --- Main functions

function display_html_version($r) {

  global $cust_lang_long;// current language 
  global $cust_lang;// current language 
  global $cust_lang_short;// current language 

  global $cust_dir; 

  global $cust_title;
  global $cust_description;
  global $cust_logo_fb_uri; 
  global $DOMAIN_FQDN;
  global $cust_gplus_url; 
  global $cust_site_motto; 
  global $cust_logo_uri; 
  global $cust_site_name;
  global $$cust_about_footer_desc;
  global $cust_aboutus_url;

  global $cust_keywords; 
  global $cust_favicon_uri; 

  global $GOOGLE_SITE_VERIFICATION; 

  global $uagent; 
  global $serverremoteaddr; 

  global $cust_whoweare_url; 
  global $cust_blog_url;
  global $cust_tandc_url;
  global $cust_rgda_url;
  global $cust_cookie_url;
  global $cust_pub_url;
  global $cust_pricing_url;
  global $cust_contactus_url;
  global $cust_contact_phone;
  global $cust_help_url;
  global $cust_faq_url;


  $is_in_display_html_version_for_seo=true; 
  $today = date("Y-m-d H:i:s"); 


  // get current date and time 




    // header is already sent 
  ?>

  <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
  <meta http-equiv="content-type" content="text/html; charset=iso-8859-15"/>

  <html  dir="<?php echo $cust_dir;?>">

  <head>

    <?php 
    display_header_comments();  
    ?>

    <!-- CHARSET definition  -->
    <?php if ($cust_lang_short=="ar") { ?>
      <meta http-equiv="content-type" content="text/html; charset=windows-1256"/> 
    <?php } else { ?>
      <meta http-equiv="content-type" content="text/html; charset=iso-8859-15"/>  
    <?php } ?>

    <!-- SEO optimization = TITLE, DESC and META dynamically displayed -->
    <?php 
    // var_dump($r);
      if ($r==false) { 
       // DEFAULT HOME 
       $metasAr = Array('title'=> $cust_title, 'desc'=>$cust_description, 'image'=>$cust_logo_fb_uri, 'url'=>$DOMAIN_FQDN, 'gplus'=>$cust_gplus_url); 
      } else { 
        // HTML snapshot
        $metasAr = get_metas($r);
      }
      // display METAS in all cases 
      echo display_metas($metasAr);  
    ?>

     <!-- not really used by SEO -->
    <meta name="keywords" lang="<?php echo $cust_lang;?>" content="<?php echo $cust_keywords;?>" /> 
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo $cust_favicon_uri;?>"> 
    <link rel="icon" type="image/x-icon" href="<?php echo $cust_favicon_uri;?>">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap -->
    <link href="<?php echo $DOMAIN_FQDN;?>css/bootstrap.min.css" rel="stylesheet">

    <!-- SEOs style -->
    <link href="<?php echo $DOMAIN_FQDN;?>css/style.seo.css" rel="stylesheet">

    <!-- google site verification --> 
    <?php if ($GOOGLE_SITE_VERIFICATION){?>
    <meta name="google-site-verification" content="<?php echo $GOOGLE_SITE_VERIFICATION;?>" />
    <?php } ?>

  </head>

  <body id="top" itemscope="itemscope" itemtype="http://schema.org/WebPage" style=" <?php echo $bodyextrastyle ?> " class=" <?php echo $bodyextraclass ?> " lang="<?php echo $cust_lang; ?>" xzads-lang="<?php echo $cust_lang_long; ?>" xzads-lang-support="<?php echo $cust_lang_support; ?>">

      <header class="jumbotron">
        <div class="container">

          <a href="<?php echo $DOMAIN_FQDN;?>" title="<?php echo   (stripslashes($cust_site_motto)); ?>" id="logo" class="">
            <div class="col-sm-6">
              <img  alt="image for <?php echo   (stripslashes($cust_site_name)); ?>"  src="<?php echo $cust_logo_uri; ?>" />
            </div>
            <div class="col-sm-6">
              <div class="site-title"><?php  echo   (stripslashes($cust_site_name)); ?></div>
            </div>
          </a>
          <div id="site-motto-below-logo" class="" style="float:none;"><?php if ($r==false) echo   (stripslashes($cust_site_motto)); ?></div>
          </div>
      </header>

      <nav class="navbar navbar-default navbar-static-top"> 
          <div class="container">
            <div class="navbar-collapse collapse">
              <ul class="nav navbar-nav">
                <?php  echo html_snapshot_display('nav',$r);  ?>
              </ul>
            </div>
          </div>
      </nav>

      <!-- breadcrumb  -->
      <div class="container">
       <?php  echo html_snapshot_display('breadcrumb',$r);  ?>
      </div>

      <!-- main content  -->
      <div class="container">
        
        <?php 
        echo html_snapshot_display('maintitle',$r);  
        
        echo html_snapshot_display('content',$r);  
        ?>
      </div>

      <?php  
      // display list of catégories only on Home page 
      if ( $r==false) { ?>
      <!-- list of categories -->
      <div class="container">
        <nav class="row navbar navbar-default">
        <?php  echo html_snapshot_display('catlist',$r);  ?>
        </nav>
      </div>
      <?php }?>


      <!-- main footer  -->
      <footer class="container">
        <nav class="row navbar navbar-default">
          <?php include("/../footer.php"); ?>
        </nav>    
      </footer>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>

  </body>

<?php
}


/**-----------------------------------------------------------------------------
* get the structured list of categorieswith parents and number of items 
* @param string $type : the type of adds 
* @param boolean $withitemcounts : if we count the number of adds
* @return array an array 
*-----------------------------------------------------------------------------*/
function sql_list_top($what, $type,  $withitemcounts){

  $idx=0;
  $outdata="";   
  $out=false; 
  $cnt=0; 

  $outdata =  sql_list($what, $type, $withitemcounts," `pid` = '' ");  
  $out = $outdata ; 
  foreach ($outdata as $key => $value) {
    $newlevel =  $outdata[$idx]['id']; 
    $outdata2 =  sql_list($what, $type, $withitemcounts, " `pid` = $newlevel "); 

    // get the sum 
    if ($withitemcounts) {
      $cnt=0; 
      foreach ($outdata2 as $key2 => $node) { 
        $cnt+=$node['cnt'];
      }
    }
    $out[$idx]['childs'] = $outdata2 ; 
    $out[$idx]['cnt'] = $cnt;
    $idx+=1; 
  }
  return $out; 
  // return true; 
}

/**-----------------------------------------------------------------------------
* get the structured list of categorieswith parents and number of items 
* @param string $type : the type of adds 
* @param boolean $withitemcounts : if we count the number of adds
* @return array an array 
*-----------------------------------------------------------------------------*/
function sql_list($what, $type, $withitemcounts, $level) {

  global $dbCatsTable ;
  global $dbItemsTable ; 
  global $dbUsersTable ; 

  $idx=0;
  $outdata="";   
  $out=false; 

  // filtering rules
  if ($what=='cat') $dbThisTable = $dbCatsTable; 
  if ($what=='ad') $dbThisTable = $dbItemsTable; 
  if ($what=='user') $dbThisTable = $dbUsersTable; 


  $filter = " WHERE `$dbThisTable`.`status` IN ('40','45', '46')"; // published
  if ($level=="level1") $filter .= " AND  `$dbThisTable`.`pid` = '' ";
  else if ($level!="") $filter .= " AND  $level ";
 
  $sql_sort=" ORDER by  `$dbThisTable`.`title` DESC ";
  $sql_limit =""; 
  $sql_group ="";

  $query = "SELECT `$dbThisTable`.*
                FROM `$dbThisTable` ".$join .$filter." ". $sql_sort . " " . $sql_group . " " .$sql_limit  ; 
  // make the real query 
  $result = @mysql_query($query);

  if ($result){
    while ($row = mysql_fetch_assoc($result) ) {
      $outdata=$row;  
      $outdata = sql_encode_result($outdata); 

      if ($withitemcounts) {
        $cnt =0; 
        $res = sql_list('ad','',''," `catid` = ".$outdata['id']." ");
        $cnt = ($res) ? count($res) : 0 ;
        $outdata['cnt'] = $cnt ; // add the counter to the list 
      }

      $out[$idx] = $outdata;
      $idx+=1; 
    }
  } else {
    $out= mysql_error();
  } 

  return $out; 

};


/**-----------------------------------------------------------------------------
* special processing on associative array (encoding dates, ...) 
*-----------------------------------------------------------------------------*/
function sql_encode_result($outdata) {
  foreach ($outdata as $key => $value){
    $tmpar =   array("title", "description","metatitle", "metadesc", "metakey"); 
    if (in_array($key,$tmpar))
      $outdata[$key] =   (stripslashes($value));
  }

  return $outdata; 
}



?>