<?php 
/******************************************************************************
 * ZADS BOOTSTRAP PHP file for loading all libraries and others 
 * 
 *  
 * @category   CorePackage
 * @package    ZADS
 * @author     Patrice COHAUT <patrice.cohaut@gmail.com>
 * @copyright  2017  PATMISC
 * @version    7.5.0
 ******************************************************************************/

header('Content-Type: application/json');
define('SENTINEL', 1); // used for includes files

if (!defined("CACHE_PATH")) define('CACHE_PATH', 'cache/');

$timing_trace=''; $t0=microtime(true);  

/* detect the PHP version */ 
if(function_exists('phpversion')) $v = phpversion();
elseif(PHP_VERSION) $v = PHP_VERSION; else $v =  'Impossible de détecter la version PHP';
$phpVersion = intval(str_replace('.','',$v));

// load libraries & settings 
require_once("multitenants_settings.php"); 
define("DIR_LIBS", 'inc/');
define("DIR_SETTINGS", $SETTINGS_PATH);


// set default timezone 
date_default_timezone_set('Europe/Paris');

require_once("functions.php");

// set general actions / security
unregisterGlobals(); 

require_once(DIR_SETTINGS."db_settings.php");  
require_once(DIR_SETTINGS."settings.php");
file_convert_var_2_const(DIR_SETTINGS."db_settings.php");  
file_convert_var_2_const(DIR_SETTINGS."settings.php"); 

require_once("localization.php");   
require_once(DIR_SETTINGS."home_settings_".$cust_lang_long.".php");

// get catalogue elements  
$general_settings = json_decode(file_get_contents($SETTINGS_PATH."general.json"),true);
$general_catalogue = json_decode(file_get_contents($SETTINGS_PATH."catalogue.json"),true);


//add facebook SDK for autentification via Facebook
if ($FB_AUTH) require_once ("fb_sdk/src/facebook.php");

$debug ="";
$debug_tmp = 0 ; // 0= server 1=local
if (( $_SERVER['SERVER_ADDR'] != "127.0.0.1") ||( !$_SERVER['SERVER_ADDR'] ))  $debug_tmp=0; else $debug_tmp=1; 
$debugoutputfile = "debugoutput.htm"; // only if save=1
//force a debug based on settings file Zads5.0
if ($ENABLE_DEBUG_MODE) $debug_tmp=1; 
$debug_level = ($DEBUG_LEVEL) ? $DEBUG_LEVEL : 7 ;

if ($debug_tmp==1) {
// debug output file 
  $debugfile = fopen($debugoutputfile,"a"); if(!$debugfile) { echo "Error writing to the output file.\n";}
  logfile('', '[core 1] --------------------------------------', __LINE__); // start a new call of file 
  // Report all errors except E_NOTICE  and WARNINGS
  error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);
} 
else { error_reporting(E_ERROR |  E_PARSE); }

error_reporting(E_ALL ^ (E_NOTICE | E_WARNING | E_DEPRECATED));
set_exception_handler('zads_uncatched_exception_handler'); //only for uncatched exceptions
set_error_handler("zads_error_handler"); // for classical errors


$nomessage = 0;  // 0= flag to indicate wether to end a message or not
$serverremotehostx ='unknown';
$serverremoteaddr = $_SERVER['REMOTE_ADDR'];  
$debughostinfo = "remote host=".$serverremotehostx ." | remote ip= ". $serverremoteaddr;
$uagent = $_SERVER['HTTP_USER_AGENT'];
$useragent = $_SERVER['HTTP_USER_AGENT'];



// Local essential classes for debug and DB managemen
if (DB_MODE=="both" || DB_MODE=="pdo"){
	
	require_once(DIR_LIBS.'db_class.php'); 
	
	$dbb = new dbClass([
	    'database_type' => 'mysql'
	    ,'database_name' => DB_NAME
	    ,'server' => DB_HOST
	    ,'username' => DB_USERNAME
	    ,'password' => DB_PASSWORD
	    ,'prefix' => DB_PREFIX
	    ,'charset' => 'utf8'
	    ,'option' => [
			PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
			PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
		]
	]);

}


if (DB_MODE=="both" || DB_MODE=="mysql"){

	$databasehost = $DB_HOST;
	$databaseusername =$DB_USERNAME;  
	$databasepassword =$DB_PASSWORD;  

	$databasename = $DB_NAME;  //cads = classified adds. 
	$dbItemsTable = $DB_PREFIX.$DB_TABLE_ITEMS ; 
	$dbCatsTable = $DB_PREFIX.$DB_TABLE_CATS; 
	$dbUsersTable = $DB_PREFIX.$DB_TABLE_USERS; 
	$dbStatsTable = $DB_PREFIX.$DB_TABLE_STATS; 
	$dbLogsTable = $DB_PREFIX.$DB_TABLE_LOGS; 
	$dbPaymentsTable = $DB_PREFIX.$DB_TABLE_PAYMENTS;
	$dbBannersTable = $DB_PREFIX.$DB_TABLE_BANNERS;

	$dbBookingsTable = $DB_PREFIX.$DB_TABLE_BOOKINGS;
	$dbPricingsTable = $DB_PREFIX.$DB_TABLE_PRICINGS;
	$dbVisitorsTable= $DB_PREFIX.$DB_TABLE_VISITORS; 

	$dbSubscribersTable = $DB_PREFIX.$DB_TABLE_SUBSCRIBERS;
	$dbVFieldsTable = $DB_PREFIX.$DB_TABLE_VFIELDS;
	$dbServicesTable= $DB_PREFIX.$DB_TABLE_SERVICES;
	$dbKeysTable = $DB_PREFIX.$DB_TABLE_KEYS;
	$dbComsTable = $DB_PREFIX.$DB_TABLE_COMS;

	$dbAlertsTable= $DB_PREFIX.$DB_TABLE_ALERTS;


	//  --- open socket to MySQL database
	$con = mysql_connect ($databasehost,$databaseusername, $databasepassword); 
	if (!$con) {
	  logfile('error', "{main} : mysql_connect : ". mysql_error(), __LINE__); 
	  die();
	}
	$dbcon = mysql_select_db ( $databasename ); 
	if (!$dbcon) {
	  logfile('error', "{main} : mysql_select_db : ". mysql_error(), __LINE__); 
	  die();
	}
	mysql_query("SET NAMES 'utf8'") ;
	mysql_query('SET COLLATION_CONNECTION=utf8_general_ci');

}


$dbThisTable=""; 

$fullfqdn = $DOMAIN_FQDN; 


function zads_uncatched_exception_handler(Exception $e){
    echo "!!!! Got an exception !!!";
    echo $e->getMessage(); // just the message
    echo '<table>'.$e->xdebug_message.'</table>' ; 
    // script is stopped here 
}

// Gestionnaire d'erreurs
function zads_error_handler($errno, $errstr, $errfile, $errline)
{
   if (!(error_reporting() & $errno)) {
        // Ce code d'erreur n'est pas inclus dans error_reporting()
        return;
    }

    logfile('error', $errno.' - line=' . $errline .' - file=' . $errfile.' - message=' .$errstr);

    switch ($errno) {
    case E_USER_ERROR:
        echo "<b>Mon ERREUR</b> [$errno] $errstr<br />\n";
        echo "  Erreur fatale sur la ligne $errline dans le fichier $errfile";
        exit(1);
        break;

    case E_USER_WARNING:
        echo "<b>Mon ALERTE</b> [$errno] $errstr<br />\n";
        break;

    case E_USER_NOTICE:
        echo "<b>Mon AVERTISSEMENT</b> [$errno] $errstr<br />\n";
        break;

    default:
        echo "Type d'erreur inconnu : [$errno] $errstr<br />\n";
        break;
    }

    /* Ne pas exécuter le gestionnaire interne de PHP */
    return true;
}






