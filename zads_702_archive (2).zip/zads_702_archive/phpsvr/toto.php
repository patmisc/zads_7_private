<?php
echo "coucou footer";

?>