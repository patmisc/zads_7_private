 
<!-- 
    complementary FOOTER.PHP file inserted in all ZADS pages (main and sub)  
    CANNOT BE USED ALONE ! 
    ZADS  version  : 6.0.0 
-->


 <div id="footer"> <!--  start FOOTER -->
      <div id="footer-content"> <!--  start FOOTER -->
      
      <?php  if ($is_in_display_html_version_for_seo) { $toto=1;} else { ?> 
       <?php  if (isset($cust_site_copyright) && $cust_site_copyright!="") { ?>
        <span id="copyright" class=""><?php echo $cust_site_copyright;?></span>
        <?php } else { ?>
        <span id="copyright" class="totranslate">COPYRIGHT</span>
        <?php } ?>
      <?php } ?> 

        <?php  if ($cust_whoweare_url) { ?>
        <span class="text-separator">&rarr;</span> 
        <a name="footer-aboutus" class="footer-links totranslate " href="<?php echo $cust_whoweare_url;?>" >Who we are ?</a> 
        <?php } ?>

        <?php  if ($cust_blog_url) { ?>
        <span class="text-separator">&rarr;</span> 
        <a name="footer-blog" class="footer-links totranslate " href="<?php echo $cust_blog_url;?>" >The blog</a> 
        <?php } ?>   
        
        <?php  if ($cust_tandc_url) { ?>
        <span class="text-separator">|</span>
        <a href="<?php echo $cust_tandc_url;?> "  rel="nofollow"  class="totranslate" >Legal information</a>
        <?php } ?>

        <?php  if ($cust_rgda_url) { ?>
        <span class="text-separator">|</span>
        <a href="<?php echo $cust_rgda_url;?> " rel="nofollow"  class="totranslate" >General rules of diffusion</a>
        <?php } ?>


        <?php  if ($cust_cookie_url) { ?>
        <span class="text-separator">|</span>
        <a href="<?php echo $cust_cookie_url;?> " rel="nofollow"  class="totranslate" >Cookies</a>
        <?php } ?>
        
        <?php  if ($cust_pub_url) { ?>
        <span class="text-separator">|</span> 
        <a name="footer-pub" class="footer-links totranslate" xzads-contact-reason="advertising" href="<?php echo $cust_pub_url;?>" >Advertising</a>
        <?php } ?>

        <?php  if ($cust_pricing_url) { ?>
        <span class="text-separator">|</span> 
        <a name="footer-pricing" class="footer-links totranslate"  href="<?php echo $cust_pricing_url;?>">Pricing</a>
        <?php } ?>

        <?php  if ($cust_contactus_url) { 
            if ($cust_contactus_url=="contact") { $href="#"; $xtrta = ' rel="nofollow" ';}
            else { $href = $cust_contactus_url ; $xtrta = ' ';}
            ?>
        <span class="text-separator">|</span> 
        <a name="footer-contactus" class="footer-links totranslate"  <?php echo $xtrta;?>  xzads-contact-reason="information" href="<?php echo $href;?>"  >Contact us</a>
        <?php } ?>

        <?php  if ($cust_contact_phone) { ?>
        <span class="text-separator">|</span> 
        <a name="footer-phoneus" alt="Call us now!" title="Call us now!" class="footer-links alttotranslate" href="tel:<?php echo $cust_contact_phone;?>" ><i class="icon-fa-phone mr6"></i><?php echo $cust_contact_phone;?></a>
        <?php } ?>
        
        <?php  if ($cust_help_url) { ?>
        <span class="text-separator">|</span>
        <a name="footer-help" class="footer-links totranslate" xzads-contact-reason="support" href="<?php echo $cust_help_url;?>"  >Help</a>
        <?php } ?>

        <?php  if ($cust_faq_url) { ?>
        <span class="text-separator">|</span>
        <a name="footer-faq" class="footer-links totranslate" xzads-contact-reason="faq" href="<?php echo $cust_faq_url;?>"  >F.A.Q</a>
        <?php } ?>
      
  
      <div class="clearer">&nbsp;</div>
    </div> <!--  end FOOTER CONTENT-->

    <!--  start FOOTER FOR MOBILE  -->
    <div id="footer-content-mob" class="hideit"> 
         <ul class="social-footer">
              <?php  echo display_social_footer_bar(); ?>
        </ul>
        <div class="clearer">&nbsp;</div>
    </div> <!--  end FOOTER MOBILE CONTENT-->

    <!--  debug footer  -->
    <?php  if ($ENABLE_DEBUG_FOOTER) { ?>
    <div id="footer-content-debug" class=""> 
        DEBUG : <span class="debug-version"> Version : <?php  echo ZADS_VERSION; ?> </span>
        | CSS : <span class="debug-css-normal hideit">NORMAL</span><span class="debug-css-mobile hideit">MOBILE</span><span class="debug-css-tablet hideit">TABLET</span>
        | SIZES : <span class="debug-sizes"></span>
    </div>


    <?php } ?>


 </div> <!--  end FOOTER -->

